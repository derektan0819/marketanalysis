---
title: "India Economy and Markets 印度经济与市场"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [印度, India, RBI, Nifty, Sensex]
tags: [regions, asia]
as_of: 2026-10
---
# India Economy and Markets 印度经济与市场

## Definition 定义
India is a large, fast-growing emerging economy with a young population. The Reserve Bank of India (RBI) sets the repo rate; the main equity indices are the Nifty 50 and the Sensex.
印度是庞大且增长较快的新兴经济体，人口年轻。印度储备银行（RBI）设定回购利率；主要股指是 Nifty 50 和 Sensex。

## What to watch 看什么
- Policy: RBI Monetary Policy Committee decisions on the repo rate and liquidity. 政策：RBI 货币政策委员会的回购利率和流动性决定。
- Data: CPI (food prices weigh heavily), GDP, PMIs, monsoon and trade data. 数据：CPI（食品占比高）、GDP、PMI、季风和贸易数据。
- External: India imports most of its oil, so oil prices affect the rupee and the trade balance; foreign portfolio flows move equities and the currency. 外部：印度大量进口原油，油价影响卢比和贸易差额；外资流入流出影响股市和汇率。
- Role in global portfolios: its weight in emerging-market indices has grown, so global flows matter. 在新兴市场指数中的权重上升，全球资金流向很重要。

## Related 相关
[[Emerging Markets Overview]], [[Exchange Rate]], [[WTI and Brent Crude]], [[Global Central Banks]], [[Regions Guide]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- Primary sources: Reserve Bank of India, Ministry of Statistics and Programme Implementation (MoSPI), SEBI, NSE and BSE.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.
