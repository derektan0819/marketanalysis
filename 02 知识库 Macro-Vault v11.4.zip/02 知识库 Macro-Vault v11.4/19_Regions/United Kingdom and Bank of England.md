---
title: "United Kingdom and Bank of England 英国与英格兰银行"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [英国, 英格兰银行, BoE, UK gilts]
tags: [regions, europe]
as_of: 2026-10
---
# United Kingdom and Bank of England 英国与英格兰银行

## Definition 定义
The Bank of England (BoE) sets Bank Rate through its Monetary Policy Committee (MPC). UK government bonds are called gilts, and the pound (GBP) is a major reserve and trading currency.
英格兰银行（BoE）通过货币政策委员会（MPC）设定基准利率。英国国债称为 gilts，英镑是主要的储备和交易货币。

## What to watch 看什么
- Policy: MPC decisions, vote split and minutes. 政策：MPC 决议、投票分歧和会议纪要。
- Data: CPI including services inflation and wage growth (ONS), GDP, labour data. 数据：含服务业通胀和工资增速的 CPI、GDP、就业数据。
- Gilt market: fiscal announcements can move gilt yields sharply. In September 2022 gilt yields spiked and pension funds using liability-driven investment (LDI) strategies came under stress, which forced the BoE to intervene. 财政消息可使 gilt 收益率剧烈波动，2022 年 9 月就出现过养老金 LDI 压力。
- Link: UK yields can spill over to other bond markets ([[Global Rates Spillover to US Markets]]). 英国收益率可外溢到其他债市。

## Related 相关
[[Global Central Banks]], [[Global Rates Spillover to US Markets]], [[Sovereign Debt and Fiscal Sustainability]], [[Regions Guide]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- Primary sources: Bank of England, Office for National Statistics (ONS), Office for Budget Responsibility (OBR), UK Debt Management Office.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.
