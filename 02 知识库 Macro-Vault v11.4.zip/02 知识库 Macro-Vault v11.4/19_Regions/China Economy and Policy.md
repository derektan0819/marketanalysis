---
title: "China Economy and Policy 中国经济与政策"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [中国经济, 中国政策, China economy, PBoC]
tags: [regions, asia]
as_of: 2026-10
---
# China Economy and Policy 中国经济与政策

## Definition 定义
China is the world's second-largest economy and the largest buyer of many commodities. Policy comes from the State Council, the National Development and Reform Commission and the People's Bank of China (PBoC). This note covers China itself; [[China Linkages to US Markets]] covers the US link.
中国是第二大经济体，也是许多大宗商品的最大买家。政策来自国务院、国家发改委和中国人民银行。本笔记讲中国自身，对美国市场的联系见 [[China Linkages to US Markets]]。

## What to watch 看什么
- Policy tools: the loan prime rate (LPR), reserve requirement ratio (RRR), targeted lending and fiscal support. 政策工具：贷款市场报价利率（LPR）、存款准备金率、定向贷款和财政支持。
- Data: official manufacturing PMI, industrial production, retail sales, fixed-asset investment, property investment, credit data ([[China Official PMI and Activity Data]]). 数据：官方 PMI、工业增加值、社零、固定资产投资、房地产投资、信贷。
- Structural issues: the property sector, local-government debt, demographics and export dependence. 结构问题：房地产、地方政府债务、人口和出口依赖。
- Markets: onshore CNY and offshore CNH ([[USD-CNH]]), onshore A-shares and Hong Kong-listed shares can differ. 在岸 CNY 与离岸 CNH，A 股与港股可能走势不同。
- Global link: stimulus tends to lift commodity demand expectations ([[China Policy to Commodities and Asia]]). 刺激政策通常抬升对大宗商品的需求预期。

## Related 相关
[[China Linkages to US Markets]], [[USD-CNH]], [[China Official PMI and Activity Data]], [[Copper Price]], [[China Policy to Commodities and Asia]], [[Regions Guide]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- Primary sources: National Bureau of Statistics, PBoC, CFETS. Chinese statistics can be revised or discontinued; record the release and the definition used.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.
