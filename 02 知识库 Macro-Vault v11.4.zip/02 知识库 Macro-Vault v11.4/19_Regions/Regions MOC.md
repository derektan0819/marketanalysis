---
title: "Regions MOC — 地区"
tags: [index, moc]
created: 2026-10-27
updated: 2026-10-27
source: "自动整理：完整列出 19_Regions 的全部文件（2026-10-27）"
---

# Regions MOC — 地区

[[00_Index/Master Index|总索引]] · [[HOME|首页]]

本文件夹共 8 个文件，其中笔记 8 篇。以下按路径完整列出，笔记显示标题。

## 先读

- [[19_Regions/Regions Guide|Regions 全球区域]]

## 笔记

- [[19_Regions/China Economy and Policy|China Economy and Policy 中国经济与政策]]
- [[19_Regions/Emerging Markets Overview|Emerging Markets Overview 新兴市场概览]]
- [[19_Regions/Euro Area and ECB|Euro Area and ECB 欧元区与欧洲央行]]
- [[19_Regions/India Economy and Markets|India Economy and Markets 印度经济与市场]]
- [[19_Regions/Japan Economy and BoJ|Japan Economy and BoJ 日本经济与日本央行]]
- [[19_Regions/Middle East and Oil Exporters|Middle East and Oil Exporters 中东与产油国]]
- [[19_Regions/Regions Guide|Regions 全球区域]]
- [[19_Regions/United Kingdom and Bank of England|United Kingdom and Bank of England 英国与英格兰银行]]
