---
title: "Emerging Markets Overview 新兴市场概览"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [新兴市场, EM, Emerging markets]
tags: [regions, global]
as_of: 2026-10
---
# Emerging Markets Overview 新兴市场概览

## Definition 定义
Emerging markets (EM) are developing economies with growing financial markets, for example in Asia, Latin America, the Middle East and Eastern Europe. They are not one block: commodity exporters and importers react differently.
新兴市场（EM）是金融市场不断发展的发展中经济体，分布在亚洲、拉美、中东和东欧。它们不是一个整体：大宗商品出口国和进口国的反应不同。

## What drives EM 驱动因素
- The dollar and US yields: a stronger dollar and higher US rates tend to pressure EM currencies and bonds, especially for borrowers in dollar debt. 美元走强和美债收益率上升通常压制新兴市场货币和债券。
- Commodity prices and China demand. 大宗商品价格和中国需求。
- Capital flows: foreign money can leave quickly (a 'sudden stop'); reserve adequacy and current-account balance matter. 资本可能快速撤出；外汇储备充足度和经常账户很重要。
- Local factors: politics, inflation, central-bank credibility. 本地因素：政治、通胀、央行公信力。
- Instruments: hard-currency bonds (dollar-denominated), local-currency bonds, equities, currencies; each has different risks. 工具：硬通货债券、本币债券、股票、货币，风险各不相同。

## Related 相关
[[Dollar Funding Stress to Emerging Markets]], [[DXY]], [[Foreign Exchange Reserves and Reserve Currencies]], [[India Economy and Markets]], [[China Economy and Policy]], [[Regions Guide]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- Index definitions (for example the MSCI Emerging Markets Index and JPMorgan bond indices) differ in country weights; name the index used.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.
