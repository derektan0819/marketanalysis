---
title: "Japan Economy and BoJ 日本经济与日本央行"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [日本, 日本央行, BoJ, Japan]
tags: [regions, asia]
as_of: 2026-10
---
# Japan Economy and BoJ 日本经济与日本央行

## Definition 定义
Japan is the world's major developed economy with a long history of very low interest rates. The Bank of Japan (BoJ) policy matters globally because of yen carry trades and Japan's large holdings of foreign assets.
日本是长期超低利率的主要发达经济体。日本央行（BoJ）政策影响全球，因为涉及日元套利交易和日本持有的大量海外资产。

## What to watch 看什么
- Policy: the BoJ ended negative interest rates and yield curve control in 2024; verify current settings on the BoJ site. 日本央行已在 2024 年结束负利率和收益率曲线控制，请核对最新设置。
- Data: core CPI, the quarterly Tankan survey, wage negotiations in spring, GDP. 数据：核心 CPI、短观调查（Tankan）、春季工资谈判、GDP。
- Yen: weakness raises import costs; fast strength can unwind carry trades; the Ministry of Finance can intervene ([[FX Intervention and Currency Regimes]]). 日元：过弱抬高进口成本，急升可能引发套利平仓。
- Global link: Japanese investors are large holders of foreign bonds and equities, so domestic rate changes can shift flows abroad. 日本投资者是海外债券和股票的大买家，国内利率变化会改变资金流向。

## Related 相关
[[Yen and Carry Trade]], [[USD-JPY]], [[Japan CPI and Tankan]], [[Yen Carry Unwind to Global Risk Assets]], [[Global Central Banks]], [[Regions Guide]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- Primary sources: Bank of Japan, Statistics Bureau of Japan, Ministry of Finance.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.
