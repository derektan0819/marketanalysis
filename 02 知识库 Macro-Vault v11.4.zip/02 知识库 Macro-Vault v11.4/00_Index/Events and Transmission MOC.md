---
title: "Events and Transmission MOC — 事件与传导"
tags: [index, moc]
created: 2026-10-27
updated: 2026-10-27
source: "自动整理：按主题分组的入口（2026-10-27）"
---

# Events and Transmission MOC — 事件与传导

[[00_Index/Master Index|总索引]] · [[HOME|首页]]

事件发生后，影响如何一步步传到股票、债券、美元、商品和加密资产。

## 利率与政策

- [[02_Transmission/Fed Decision to Markets|Fed Decision to Markets 联储决议传导]]
- [[02_Transmission/Rate Hike Transmission|Rate Hike Transmission 加息传导]]
- [[02_Transmission/Treasury Yield to Equity Valuation|Treasury Yield to Equity Valuation 国债收益率传导到估值]]
- [[02_Transmission/Global Rates Spillover to US Markets|Global Rates Spillover to US Markets 全球利率外溢]]
- [[02_Transmission/Yen Carry Unwind to Global Risk Assets|Yen Carry Unwind to Global Risk Assets 日元套利交易平仓到全球风险资产]]
- [[21_US_Treasuries/Treasury Cross Asset Transmission|美债怎样影响股票、银行、房产、美元和黄金]]

## 经济数据

- [[02_Transmission/Inflation Surprise Transmission|Inflation Surprise Transmission 通胀超预期传导]]
- [[02_Transmission/Jobs Report to Markets|Jobs Report to Markets 就业报告传导]]
- [[02_Transmission/Consumer Spending to Retail and Credit|Consumer Spending to Retail and Credit 消费传导]]

## 财报与产业链

- [[02_Transmission/Earnings to Market Transmission|Earnings to Market Transmission 财报传导]]
- [[02_Transmission/Mega-Cap Earnings to Index|Mega-Cap Earnings to Index 超大市值传导]]
- [[02_Transmission/Chip Earnings to AI Stocks|Chip Earnings to AI Stocks 芯片财报传导到 AI 股票]]
- [[02_Transmission/Hyperscaler Capex to Chip Chain|Hyperscaler Capex to Chip Chain 云巨头资本开支传导到芯片产业链]]
- [[02_Transmission/Memory Price Cycle|Memory Price Cycle 存储价格周期]]
- [[02_Transmission/Korea Memory Stocks and US Chip Stocks|Korea Memory Stocks and US Chip Stocks 韩国内存股与美国芯片股传导]]
- [[02_Transmission/Bank Earnings to Market|Bank Earnings to Market 银行财报传导]]

## 美元、商品与地缘政治

- [[02_Transmission/Strong USD to US Multinationals|Strong USD to US Multinationals 强美元传导]]
- [[02_Transmission/Dollar and Real Yields to Gold and Crypto|Dollar and Real Yields to Gold and Crypto 美元与实际收益率到黄金和加密]]
- [[02_Transmission/Dollar Funding Stress to Emerging Markets|Dollar Funding Stress to Emerging Markets]]
- [[02_Transmission/Oil Price Transmission|Oil Price Transmission 油价传导]]
- [[02_Transmission/Oil Revenue to Sovereign Funds and Global Assets|Oil Revenue to Sovereign Funds and Global Assets]]
- [[02_Transmission/China Policy to Commodities and Asia|China Policy to Commodities and Asia]]
- [[02_Transmission/Export Controls and Tariffs|Export Controls and Tariffs 出口管制与关税传导]]
- [[02_Transmission/Tariffs to Prices and Earnings|Tariffs to Prices and Earnings]]

## 信用与银行

- [[02_Transmission/Private Credit Stress to Banks and Markets|Private Credit Stress to Banks and Markets]]
- [[02_Transmission/Bank Capital Rules to Bank Earnings|Bank Capital Rules to Bank Earnings 银行资本规则传导]]

## 加密资产

- [[02_Transmission/Crypto Sentiment to US Equities|Crypto Sentiment to US Equities 加密市场情绪传导到美股]]

## 事件分析手册与案例

- [[10_Playbooks/Fed Day Playbook|Fed Day Playbook / FOMC 日分析流程]]
- [[10_Playbooks/Data Release Playbook|Data Release Playbook / 宏观数据发布流程]]
- [[10_Playbooks/Geopolitical Shock Playbook|Geopolitical Shock Playbook]]
- [[10_Playbooks/Global Central Bank Meeting Playbook|Global Central Bank Meeting Playbook]]
- [[10_Playbooks/Market Selloff Playbook|Market Selloff Playbook]]
- [[10_Playbooks/Case Study Samsung Q3 2026 Preliminary Earnings|Case Study Samsung Q3 2026 Preliminary Earnings]]
- [[10_Playbooks/Worked Example Hyperscaler Capex Raise|Worked Example: Hyperscaler Capex Raise / 云厂商资本开支上调示例]]
- [[21_US_Treasuries/Treasury Scenario Worked Examples|美债因果解释示例：怎样写得看懂]]
- [[21_US_Treasuries/Treasury Yield Curve Scenarios|曲线变化：牛陡、熊陡、牛平、熊平]]
- [[05_Templates/Macro Event Analysis|Macro Event Analysis / 宏观事件分析]]

## 事件日历（带日期）

- [[12_Data/US Release Calendar 2026-10-27|美国数据与财报发布日历 2026-10-27]]

## 相关文件夹

- [[02_Transmission/Transmission MOC|Transmission MOC — 传导路径]]
- [[10_Playbooks/Playbooks MOC|Playbooks MOC — 操作手册]]
