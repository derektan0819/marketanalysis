---
title: "整理方案与改名对照表"
aliases: [整理方案与改名对照表, Reorganization Plan]
tags: [index, system, reorganization]
created: 2026-10-27
updated: 2026-10-27
source: "本次整理盘点（2026-10-27），备份见项目根目录 knowledge-backup-20261027/"
---
# 整理方案与改名对照表 — 2026-10-27

[[HOME|首页]] · [[00_Index/Master Index|总索引]] · [[00_Index/Reorganization Report 2026-10-27|整理报告]]

本页记录 2026-10-27 这次整理的完整方案、命名规则和每一个被移动文件的“旧路径 → 新路径”，可据此逐条还原。

## 1. 范围

- 知识库根目录是 `knowledge/Macro-Vault/`：网站默认监控这个文件夹，Obsidian 也以它为 Vault 根。任务里写的 `knowledge/00-索引/…`、`knowledge/99-归档/` 均落在这个根目录内，否则网站和 Obsidian 都看不到。
- 原始内容来自 `seed/Macro-Vault-v11.4.zip`，按网站首次启动的同样方式（去掉外层 `Macro-Vault/`）解包；网站以后启动时发现文件夹已存在，不会覆盖。
- 整理前完整备份：项目根目录 `knowledge-backup-20261027/`（544 个文件，138,608,089 字节，逐文件比对一致）。

## 2. 盘点结论（整理前）

| 项目 | 结果 |
|---|---:|
| 文件总数 | 544 |
| Markdown 笔记 | 401 |
| JSON / HTML / TXT / PY / CSV / JSONL | 91 / 16 / 14 / 14 / 5 / 1 |
| 图片与其他附件 | 0 |
| 未完成的下载残片（隐藏文件） | 2 |
| 内部链接（含标题、段落定位） | 6,419 |
| 失效链接 | 0 |
| 孤立笔记（无任何链接进出） | 0 |
| 从 HOME 无法到达的笔记 | 0 |
| 缺少 frontmatter 的笔记 | 110 |
| 真正需要合并的重复笔记 | 0 |
| 疑似密钥 | 0 |

## 3. 方案选择与理由

采用“**保留原目录 + 新增 00_Index 索引层 + 少量安全移动**”（2026-10-27 经用户确认）。

理由：库内自动化程序 `99_Automation/engine` 与约 250 处 JSON 数据引用写死了现有路径，包括 `04_Companies`、`12_Data`、`13_Sources`、`14_Reports`、`15_System`、`99_Automation`，以及 `05_Templates/One Page Research Brief.md`、`09_Fundamentals/Earnings Quality.md`、`09_Fundamentals/GAAP vs Non-GAAP.md`、`10_Playbooks/Financial Reading Coverage.md`、`10_Playbooks/Industry KPI Checklist.md`、`10_Playbooks/US Treasury Research Playbook.md`、`21_US_Treasuries/US Treasury Knowledge Map.md`、根目录 `CLAUDE.md`、`HOME.md`、`Today Dashboard.md`、`Review Queue.md`、`Prediction Scorecard.md`。整体改目录会让程序悄悄少读笔记或在旧位置重新生成文件。网站本身只从压缩包读取规则，不受影响。

## 4. 目录结构

建议的九大类不再体现为文件夹改名，而是体现为 `00_Index` 里的总索引和主题 MOC：

| 建议分类 | 对应位置 | 入口 |
|---|---|---|
| 00 索引 | `00_Index/`（新） | [[00_Index/Master Index\|总索引]]、[[00_Index/Knowledge Index\|全库索引]]、[[00_Index/START HERE\|第一次使用]]、[[00_Index/Obsidian Navigation Guide\|使用说明]]、[[00_Index/Glossary\|术语表]] |
| 01 宏观框架 | `01_Concepts`（宏观部分）、`03_Indicators`、`19_Regions`、`17_Bank_Regulation` | [[00_Index/Macro Framework MOC\|宏观框架 MOC]] |
| 02 市场与资产 | `01_Concepts`（市场部分）、`03_Indicators`（行情类）、`08_Sectors`、`21_US_Treasuries` | [[00_Index/Markets and Assets MOC\|市场与资产 MOC]] |
| 03 公司与财报 | `04_Companies`、`09_Fundamentals`、财报类 Playbook 与模板 | [[00_Index/Companies and Earnings MOC\|公司与财报 MOC]] |
| 04 事件与传导 | `02_Transmission`、事件类 Playbook | [[00_Index/Events and Transmission MOC\|事件与传导 MOC]] |
| 05 马来西亚 | `11_Malaysia` | [[11_Malaysia/Malaysia MOC\|马来西亚 MOC]] |
| 06 每日与每周 | `06_Daily`、`07_Weekly`、`14_Reports` | [[00_Index/Daily and Weekly MOC\|每日与每周 MOC]] |
| 90 模板 | `05_Templates` | [[05_Templates/Templates MOC\|模板 MOC]] |
| 99 附件 | 当前没有图片或附件，不建空文件夹 | 以后加入图片时放 `00_Attachments/`（见命名规则） |
| 归档 | 沿用已有的 `20_Archive/`，不另建 `99_归档` | [[20_Archive/Archive MOC\|归档 MOC]] |
| 系统与数据 | `12_Data`、`13_Sources`、`15_System`、`16_TestCases`、`99_Automation`、`00_Inbox`、`18_Videos` | 见总索引“系统与数据” |

马来西亚、模板、系统三类各只对应一个文件夹，总索引直接链到该文件夹的 MOC，不在 `00_Index` 再建同名 MOC，避免出现两篇同名笔记导致裸链接有歧义。

整理后的顶层结构：

```text
Macro-Vault/
├─ HOME.md  CLAUDE.md  AI START HERE.md  Today Dashboard.md
│  Review Queue.md  Prediction Scorecard.md  SHA256SUMS.txt   ← 入口与程序文件，原位
├─ 00_Index/            ★ 新：总索引、五个分类 MOC、整理方案、整理报告
│                         ← 移入 Knowledge Index、START HERE、Obsidian Navigation Guide、Glossary
├─ 00_Inbox … 21_US_Treasuries、99_Automation   原位不动，各加一篇 <主题> MOC.md
├─ 15_System/Release History/   ← 根目录 10 篇版本说明与验收记录
└─ 20_Archive/Partial Downloads/ ← 2 个未下载完的隐藏残片
```

## 5. 命名规则

1. 语言沿用现有的英文文件名和文件夹名；中文名写在 H1 标题和 frontmatter 的 `title`、`aliases` 里，Obsidian 搜索和快速切换都能用中文找到。
2. 顶层文件夹：两位数编号 + 下划线 + 英文词组，词间用下划线，如 `21_US_Treasuries`。子文件夹用英文词组，可含空格（沿用 `Run History`），股票代码全大写（`NVDA`）。
3. 笔记名：英文、每个实词首字母大写、词间空格，如 `Business Cycle and Recession.md`。只允许字母、数字、空格、`.`、`-`、`_`；不得含 `& ? # % [ ] | ^ : / \ " ' < > *`。
4. 日期一律 `YYYY-MM-DD`：每日笔记 `YYYY-MM-DD.md`；带日期的笔记 `<名称> YYYY-MM-DD.md`。程序生成的运行编号（如 `20261019T070744Z-4e0381`）和来源编号（`SRC-` + 24 位十六进制）保持程序格式。
5. 同类笔记格式一致：文件夹索引 `<主题> MOC.md`；分类索引 `00_Index/<分类> MOC.md`；公司数据 `<TICKER> - Data History.md`；版本说明 `V<版本> Release Notes.md`。
6. 新建笔记的文件名在全库唯一；同名文件只允许出现在程序管理的公司与运行目录中，且一律用完整路径链接。
7. 图片与附件以后放 `00_Attachments/`，文件名同第 3、4 条，用 `![[00_Attachments/文件名.png]]` 嵌入。

## 6. frontmatter 规则

- 只给“完全没有 frontmatter”的笔记补齐，字段统一为 `title`、`tags`、`created`、`updated`、`source`。已有 frontmatter 的 291 篇不改动。
- `title`：取 H1 标题；没有 H1 时取文件名。`tags`：按所在文件夹，沿用库内已有标签词（如 `company`、`playbook`、`system`、`sources`）。`created`、`updated`：取原压缩包内的文件时间。`source`：来源记录卡填其“官方下载地址”，其余写 `待补充`。
- 有意不补的两类，共 36 篇：
  - `13_Sources/Raw/*.md`（21 篇）：第三方原文的提取文本，程序会把全文当证据送给 AI，加元数据会混进证据正文。
  - `14_Reports/Run History/*/*/Evidence.md`（15 篇）：按运行编号固定的证据快照，保持原样以便审计。
- 注意：`Evidence Index`、`Company Research Index`、`Source Index`、`Run History Index`、`Review Queue`、`Prediction Scorecard` 和来源记录卡由程序整篇重写。若以后运行 `99_Automation/engine/vault.py`，这些文件新补的 frontmatter 会消失，内容不受影响。
- 步骤 4 的新增笔记另加 `verified: 2026-10-27`。

## 7. MOC 规则

- 每个顶层文件夹一篇 `<主题> MOC.md`，完整列出该文件夹（含子文件夹）的全部文件；笔记显示 H1 标题，机器文件（JSON、CSV、HTML 等）单列一节。
- `00_Index/Master Index.md` 按九大类链接所有 MOC，所以每篇笔记都能从总索引两步内点到。
- 原有的导览页（如 `Malaysia Guide`、`US Treasury Knowledge Map`、`Bank Regulation Map`）保留原文，MOC 只链接它们，不改写。
- `HOME.md` 和 `00_Index/Knowledge Index.md` 各加一行指向总索引，其余原文不动。

## 8. 重复笔记处理

没有合并任何笔记。32 对内容相似度超过 50% 的笔记属于两类：同一天三次自动运行留下的报告快照（每份简报都用段落定位指向本次运行自己的证据），以及同一模板生成的不同公司笔记（AMZN、MSFT、NVDA 等）。同名的 `13_Sources/Raw/SRC-*.md`（原文）与 `13_Sources/Records/SRC-*.md`（记录卡）作用不同。合并任何一组都会破坏证据链。

## 9. 旧路径 → 新路径 对照表

共移动 16 个文件，没有改文件名。指向它们的 54 处链接都只写文件名，移动后在全库仍唯一，Obsidian 照常解析，因此没有改写任何链接文字。

| # | 旧路径 | 新路径 | 指向它的链接 |
|---:|---|---|---:|
| 1 | `Knowledge Index.md` | `00_Index/Knowledge Index.md` | 2 |
| 2 | `START HERE.md` | `00_Index/START HERE.md` | 3 |
| 3 | `Obsidian Navigation Guide.md` | `00_Index/Obsidian Navigation Guide.md` | 5 |
| 4 | `Glossary.md` | `00_Index/Glossary.md` | 2 |
| 5 | `V11 Release Notes.md` | `15_System/Release History/V11 Release Notes.md` | 2 |
| 6 | `V11.1 Release Notes.md` | `15_System/Release History/V11.1 Release Notes.md` | 4 |
| 7 | `V11.2 Release Notes.md` | `15_System/Release History/V11.2 Release Notes.md` | 2 |
| 8 | `V11.2 Verification.md` | `15_System/Release History/V11.2 Verification.md` | 4 |
| 9 | `V11.3 Release Notes.md` | `15_System/Release History/V11.3 Release Notes.md` | 2 |
| 10 | `V11.3 Verification.md` | `15_System/Release History/V11.3 Verification.md` | 7 |
| 11 | `V11.4 Release Notes.md` | `15_System/Release History/V11.4 Release Notes.md` | 4 |
| 12 | `V11.4 Verification.md` | `15_System/Release History/V11.4 Verification.md` | 6 |
| 13 | `Build Verification.md` | `15_System/Release History/Build Verification.md` | 7 |
| 14 | `Obsidian Link Audit.md` | `15_System/Release History/Obsidian Link Audit.md` | 4 |
| 15 | `13_Sources/Raw/.SRC-821ba21da94c21df60d729fd.html.UcWjjn` | `20_Archive/Partial Downloads/.SRC-821ba21da94c21df60d729fd.html.UcWjjn` | 0 |
| 16 | `13_Sources/Raw/.SRC-9c13f4e336126491246ce357.html.c1Yns4` | `20_Archive/Partial Downloads/.SRC-9c13f4e336126491246ce357.html.c1Yns4` | 0 |

第 15、16 项是没下载完的隐藏残片（分别是正式文件的 41% 和 82%），正式文件 `SRC-821ba…html`、`SRC-9c13f…html` 完整保留在原处。

两处只涉及纯文字、不是链接的旧提法：`99_Automation/engine/vault.py` 的帮助文字写着 “See START HERE.md”（文件现在在 `00_Index/`）；`SHA256SUMS.txt` 和 `16_TestCases/*.json` 是整理前的历史校验记录，里面的旧路径和旧哈希保持原样，不代表文件丢失。

## 10. 还原方法

**逐条还原移动**（在 `knowledge/Macro-Vault/` 内执行）：

```bash
cd "knowledge/Macro-Vault"
mv "00_Index/Knowledge Index.md" "Knowledge Index.md"
mv "00_Index/START HERE.md" "START HERE.md"
mv "00_Index/Obsidian Navigation Guide.md" "Obsidian Navigation Guide.md"
mv "00_Index/Glossary.md" "Glossary.md"
for f in "V11 Release Notes" "V11.1 Release Notes" "V11.2 Release Notes" "V11.2 Verification" \
         "V11.3 Release Notes" "V11.3 Verification" "V11.4 Release Notes" "V11.4 Verification" \
         "Build Verification" "Obsidian Link Audit"; do
  mv "15_System/Release History/$f.md" "$f.md"
done
# 第 15、16 行的两个下载残片已按你的决定于 2026-10-27 第二轮删除；需要时从备份复制回原位置：
cp -p "../../knowledge-backup-20261027/Macro-Vault/13_Sources/Raw/.SRC-821ba21da94c21df60d729fd.html.UcWjjn" "13_Sources/Raw/"
cp -p "../../knowledge-backup-20261027/Macro-Vault/13_Sources/Raw/.SRC-9c13f4e336126491246ce357.html.c1Yns4" "13_Sources/Raw/"
```

新增的 MOC、补全笔记、补加的 frontmatter 和 HOME 里新增的那一行，清单见 [[00_Index/Reorganization Report 2026-10-27|整理报告]]。

**整体还原到整理前**：关闭网站后，用项目根目录的 `knowledge-backup-20261027/` 替换 `knowledge/`，再到网站“同步中心”点“重新扫描文件夹”。
