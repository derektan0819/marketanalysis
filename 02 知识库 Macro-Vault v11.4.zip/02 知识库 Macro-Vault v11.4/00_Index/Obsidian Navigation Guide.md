---
title: "Obsidian 链接与图谱使用说明"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [guide, obsidian]
version: "11.1"
---
# Obsidian 链接与图谱使用说明

[[HOME|首页]] · [[Today Dashboard|今日看板]] · [[Obsidian Link Audit|本次检查结果]]

## 每天怎样看

1. 打开 [[Today Dashboard]]，点击公司名称进入一页简报。
2. 点击简报中的证据 ID，定位到当次快照对应的数字。八季表里的数字也可以点击。
3. 在证据页点击“输入”，追溯派生季度、FCF 或利润率的计算；点击“来源”，进入来源记录和保存正文。
4. 在公司入口切换当前判断、判断历史和历次报告。历史报告的证据固定在当次运行，不会跳到后来更新的数据。

## 图中的 point 和连线代表什么

圆点是笔记，连线是内部引用。引用可以表示导航、方法关联、证据来源或计算依赖；**不能仅凭一条连线推断因果关系、投资方向或预测正确**。

公司档案里的“分析框架”说明行业／宏观笔记如何用于研究；具体事实仍需以有时间和出处的证据为准。

五家公司的 Latest Brief、Current Thesis 等文件名相同，这是分目录保存的结构。新版生成的公司链接使用完整路径，避免串到其他公司；图上名称相同时，点击后以正文顶部的 ticker 和文件路径识别。需要聚焦一家公司时，从其 Company Profile 打开“局部图谱”，深度设为 1–2。

## 看板与图谱保持清楚

打开全局图谱的筛选设置。查看研究主题、公司和当前判断时，可在 Search files 输入：

```text
-path:"13_Sources/Raw" -path:"13_Sources/Records" -path:"14_Reports/Run History/" -path:"20_Archive"
```

这只筛选图中显示的节点，不删除证据，也不影响正文中的点击跳转。需要检查完整证据网络时清空筛选。Existing files only 可以隐藏尚未创建的笔记节点；本次检查已单独检出空链接和不存在的目标，无需靠隐藏来通过检查。

可选分组：用 `path:"04_Companies/NVDA"` 等条件为不同公司着色，用 `path:"01_Concepts"`、`path:"08_Sectors"` 区分概念和行业。

## JSON、CSV 和原始下载文件

日常阅读使用 Markdown 简报、证据页和来源记录。JSON／CSV 是机器可读附件；若 Obsidian 没有显示这些文件，在 Settings → Files and links 打开 Show all file types（部分旧版叫 Detect all file extensions），再用系统编辑器打开。原始 SEC 提交文件可能包含图片编码；优先读来源页中的 EX-99 正文。

保存正文以文本代码块展示，避免原始文件中的方括号、附件编码或伪造指令形成假链接。完整下载原件及其 SHA-256 校验值保留。

## 更新和自检

在仓库目录运行：

```bash
python3 99_Automation/engine/vault.py audit
```

会检查本地链接目标、同名歧义、标题／段落定位、表格别名、首页可达性、快照引用路径和原件哈希。外部网址不会逐个联网检测；路径通过也不表示财报语义已经核验。

如需根据已有快照重建证据索引和导航：

```bash
python3 99_Automation/engine/vault.py rebuild-navigation
```

此命令不抓取新数据、不调用 AI，保留当前判断和档案中生成导航标记之外的文字。正常 `run` 也会更新这些索引。程序会覆盖其生成的数据表、简报、看板、证据页和索引；个人备注请放在独立笔记或 Company Profile／Current Thesis 的非生成导航区域。

## 把 v11.1 放进 Obsidian

将 ZIP 解压到新目录，在 Obsidian 选择“打开文件夹作为仓库”，选中包含 HOME.md 的 Macro-Vault 文件夹。保留旧仓库备份，并迁入你后来新增或修改的个人笔记。不要把 Macro-Vault 再嵌套进已打开的 Macro-Vault 内，否则完整路径链接会失去正确的仓库根目录。

交付检查是在文件层面完成；没有连接你电脑里的 Obsidian，也没有测试你的插件或主题。

## 官方说明

- [内部链接与定位](https://obsidian.md/help/links)
- [图谱、筛选与局部图谱](https://obsidian.md/help/plugins/graph)
- [支持的文件格式](https://obsidian.md/help/file-formats)
- [文件与链接设置](https://obsidian.md/help/settings)
