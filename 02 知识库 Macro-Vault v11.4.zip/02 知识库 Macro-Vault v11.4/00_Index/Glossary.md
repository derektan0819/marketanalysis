---
title: "Glossary 术语表"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [术语表, 词汇表, Glossary]
tags: [glossary]
as_of: 2026-10
---
# Glossary 术语表

> Bilingual quick reference. Definitions are short on purpose; follow the linked note for the mechanism. Where a term appears in your lecture slides, the slides take priority.
> 中英对照速查表。释义刻意简短；机制请看链接的笔记。若课程讲义中有该术语，以讲义为准。


## Macro 宏观

| Term | 中文 | Meaning 释义 | Note |
|---|---|---|---|
| GDP | 国内生产总值 | Total value of goods and services produced / 一国产出的总价值 | [[GDP]] |
| Real vs nominal | 实际 vs 名义 | Real is adjusted for inflation; nominal is not / 实际值剔除通胀，名义值不剔除 |  |
| CPI | 消费者物价指数 | Consumer price index, a main inflation gauge / 主要通胀指标之一 | [[CPI]] |
| Core CPI | 核心CPI | CPI excluding food and energy / 不含食品和能源的CPI | [[CPI]] |
| PCE | 个人消费支出价格指数 | Price index from consumer spending; the Fed's preferred gauge / 基于个人消费支出的价格指数，美联储偏好的通胀指标 | [[PCE Inflation]] |
| Disinflation | 通胀放缓 | Inflation falling but still positive / 通胀下降但仍为正 | [[Inflation]] |
| Deflation | 通缩 | Falling price level / 物价水平下降 | [[Inflation]] |
| Stagflation | 滞胀 | Weak growth plus high inflation / 增长疲弱加高通胀 | [[Stagflation]] |
| Recession | 衰退 | Broad, significant, lasting decline in activity / 经济活动大范围、持续的显著下降 | [[Business Cycle and Recession]] |
| Soft landing | 软着陆 | Inflation falls without a recession / 通胀回落而没有衰退 |  |
| Hard landing | 硬着陆 | Inflation control comes with a recession / 控制通胀的同时出现衰退 |  |
| Dual mandate | 双重使命 | The Fed's goals: maximum employment and stable prices / 美联储目标：充分就业与物价稳定 | [[Labor Market]] |
| Nonfarm payrolls | 非农就业 | Monthly count of jobs added outside farms / 每月新增非农就业岗位数 | [[Nonfarm Payrolls]] |
| Unemployment rate | 失业率 | Share of the labor force without a job and seeking one / 劳动力中无工作且在找工作者的占比 | [[Unemployment Rate]] |
| Participation rate | 劳动参与率 | Share of the working-age population in the labor force / 工作年龄人口中进入劳动力的占比 | [[Labor Market]] |
| Leading indicator | 领先指标 | Moves before the economy turns / 先于经济转折变动的指标 | [[Business Cycle and Recession]] |
| YoY / MoM / QoQ | 同比 / 环比 | Change versus a year / month / quarter earlier / 与上年同期/上月/上季度相比的变化 |  |
| Annualized rate | 年化率 | A period's change scaled to a yearly pace / 把某一期的变化折算成年率 | [[GDP]] |
| Seasonally adjusted | 季节性调整 | Removes regular seasonal patterns / 剔除规律性的季节因素 |  |
| Fiscal deficit | 财政赤字 | Government spending above revenue / 政府支出超过收入 | [[Fiscal Policy]] |
| Trade balance | 贸易差额 | Exports minus imports / 出口减进口 | [[Trade Balance]] |
| Tariff | 关税 | Tax on imported goods / 对进口商品征收的税 | [[Export Controls and Tariffs]] |
| Output gap | 产出缺口 | Actual output versus potential output / 实际产出与潜在产出之差 |  |

## Rates and Bonds 利率与债券

| Term | 中文 | Meaning 释义 | Note |
|---|---|---|---|
| Federal funds rate | 联邦基金利率 | Rate banks charge each other overnight; the Fed sets a target range / 银行间隔夜拆借利率，美联储设定目标区间 | [[Federal Funds Rate]] |
| Basis point (bp) | 基点 | 1 bp = 0.01 percentage point / 1个基点 = 0.01个百分点 |  |
| Yield | 收益率 | Return on a bond if held to maturity, at the current price / 按当前价格持有至到期的回报率 | [[US Treasury Market]] |
| Coupon | 票息 | Fixed interest paid by a bond / 债券支付的固定利息 |  |
| Duration | 久期 | Sensitivity of a bond's price to rate changes / 债券价格对利率变化的敏感度 |  |
| Treasury (bill, note, bond) | 美国国债（短/中/长期） | US government debt, by maturity / 按期限分类的美国政府债务 | [[US Treasury Market]] |
| Yield curve | 收益率曲线 | Yields across maturities / 不同期限的收益率 | [[Yield Curve]] |
| Inversion | 倒挂 | Short-term yields above long-term yields / 短端收益率高于长端 | [[Yield Curve]] |
| Term premium | 期限溢价 | Extra yield for holding long bonds / 持有长期债券的额外收益 | [[Term Premium]] |
| Real yield | 实际收益率 | Yield adjusted for inflation / 经通胀调整后的收益率 | [[Real Interest Rates]] |
| TIPS | 通胀保值国债 | Treasuries whose principal adjusts with inflation / 本金随通胀调整的国债 | [[Real Interest Rates]] |
| Breakeven inflation | 盈亏平衡通胀率 | Nominal yield minus TIPS yield / 名义收益率减 TIPS 收益率 | [[Real Interest Rates]] |
| Credit spread | 信用利差 | Extra yield over government bonds for credit risk / 相对政府债多出的信用风险补偿 | [[Credit Spread]] |
| Investment grade (IG) | 投资级 | Higher-rated corporate bonds / 评级较高的公司债 | [[Credit Markets]] |
| High yield (HY) | 高收益债 | Lower-rated bonds paying higher yields / 评级较低、收益较高的债券 | [[Credit Markets]] |
| Default | 违约 | Failure to pay as promised / 未按约定还款 |  |
| QE / QT | 量化宽松 / 量化紧缩 | Central bank buying / shrinking bond holdings / 央行购买/缩减持债 | [[QE and QT]] |
| Dot plot | 点阵图 | FOMC members' rate projections / FOMC成员对利率的预测 | [[Fed and FOMC]] |
| Forward guidance | 前瞻指引 | Central bank signals about future policy / 央行对未来政策的暗示 | [[Monetary Policy]] |
| Neutral rate | 中性利率 | Rate that neither stimulates nor restrains growth / 既不刺激也不抑制增长的利率 | [[Interest Rates]] |
| Repo | 回购协议 | Short-term borrowing secured by securities / 以证券为担保的短期借款 | [[Liquidity]] |
| Bank reserves | 银行准备金 | Bank deposits held at the central bank / 银行存放在央行的资金 | [[Fed Balance Sheet]] |

## Equities and Earnings 股票与财报

| Term | 中文 | Meaning 释义 | Note |
|---|---|---|---|
| EPS | 每股收益 | Earnings per share / 每股盈利 | [[Valuation Multiples]] |
| P/E | 市盈率 | Price divided by earnings per share / 股价除以每股收益 | [[Valuation Multiples]] |
| Forward P/E | 预期市盈率 | P/E using expected future earnings / 用预期盈利计算的市盈率 | [[Valuation Multiples]] |
| EV/EBITDA | 企业价值倍数 | Enterprise value divided by EBITDA / 企业价值除以息税折旧摊销前利润 | [[Valuation Multiples]] |
| Free cash flow (FCF) | 自由现金流 | Operating cash flow minus capex / 经营现金流减资本开支 | [[Cash Flow and FCF]] |
| Gross / operating margin | 毛利率 / 营业利润率 | Profit as a share of revenue at each level / 各层级利润占收入的比例 | [[Profitability Ratios]] |
| ROE | 净资产收益率 | Net income divided by shareholders' equity / 净利润除以股东权益 | [[Profitability Ratios]] |
| Guidance | 业绩指引 | Management's own outlook / 管理层给出的前景预期 | [[Guidance]] |
| Consensus | 市场一致预期 | Average analyst estimate from a named provider / 某数据商的分析师平均预期 | [[Consensus and Expectations]] |
| Beat / miss | 超预期 / 不及预期 | Result above / below consensus / 结果高于/低于一致预期 | [[Consensus and Expectations]] |
| Priced in | 已反映于价格 | Expectation already reflected in the price / 预期已体现在价格中 | [[Priced In]] |
| Buyback | 股票回购 | Company repurchases its own shares / 公司回购自己的股票 | [[Share Buybacks and Dividends]] |
| Dividend yield | 股息率 | Annual dividend divided by price / 年股息除以股价 | [[Share Buybacks and Dividends]] |
| GAAP / Non-GAAP | GAAP / 非GAAP | Standard accounting vs adjusted measures / 标准会计口径与调整后口径 | [[GAAP vs Non-GAAP]] |
| Capex | 资本开支 | Spending on long-lived assets / 对长期资产的投入 | [[Capex Cycle]] |
| Backlog | 在手订单 | Orders received but not yet delivered / 已接订单但尚未交付 |  |
| Read-across | 跨公司启示 | Using one company's news to assess others / 用一家公司的消息评估其他公司 | [[Read-Across]] |
| Implied move | 隐含波动幅度 | Move size priced by options / 期权定价隐含的波动幅度 | [[Options and Implied Move]] |
| Earnings call | 业绩电话会 | Management call after the release / 财报发布后管理层的电话会议 | [[Earnings Day Mechanics]] |
| Earnings quality | 盈利质量 | How reliable and cash-backed reported earnings are / 报告盈利的可靠程度和现金支撑 | [[Earnings Quality]] |

## Market Structure 市场结构

| Term | 中文 | Meaning 释义 | Note |
|---|---|---|---|
| Market cap | 市值 | Share price times shares outstanding / 股价乘以流通股数 | [[Index Weighting and Concentration]] |
| Cap-weighted index | 市值加权指数 | Weights stocks by market cap / 按市值给成分股分配权重 | [[Index Weighting and Concentration]] |
| Breadth | 市场广度 | How many stocks participate in a move / 有多少股票参与了行情 | [[Market Breadth]] |
| VIX | 恐慌指数 | Index of expected S&P 500 volatility from options / 基于期权的标普500预期波动率指数 | [[VIX]] |
| Short interest | 空头持仓 | Shares sold short and not yet covered / 已卖空但尚未回补的股数 | [[Short Interest and Positioning]] |
| Short squeeze | 轧空 | Forced short covering pushes a price up / 空头被迫回补推高价格 | [[Short Interest and Positioning]] |
| Liquidity | 流动性 | Ease of trading and availability of funding / 交易的难易与资金的可得性 | [[Liquidity]] |
| Bid-ask spread | 买卖价差 | Gap between the best buy and sell prices / 最优买价与卖价之差 |  |
| ETF | 交易所交易基金 | Fund traded like a stock / 像股票一样交易的基金 | [[Passive Flows and ETFs]] |
| Risk-on / risk-off | 风险偏好 / 避险 | Appetite for or retreat from risk assets / 对风险资产的偏好或回避 | [[Risk-On Risk-Off]] |
| Sector rotation | 板块轮动 | Money moving between sectors / 资金在板块间流动 | [[Sector Rotation]] |
| Cyclical / defensive | 周期 / 防御 | Sensitive vs less sensitive to the economy / 对经济敏感或不敏感 | [[Sector Rotation]] |
| Volatility | 波动率 | Size of price swings / 价格波动的幅度 | [[VIX]] |
| Drawdown | 回撤 | Peak-to-trough decline / 从高点到低点的下跌 |  |
| Correlation | 相关性 | How closely two assets move together / 两种资产同向变动的程度 |  |
| Hedge | 对冲 | Position that offsets another risk / 抵消另一风险的头寸 |  |
| Leverage | 杠杆 | Using borrowed money to magnify exposure / 用借来的钱放大敞口 | [[Leverage and Coverage]] |
| Margin call | 追加保证金通知 | Demand for more collateral on a leveraged position / 杠杆头寸被要求补充抵押品 |  |
| After-hours trading | 盘后交易 | Trading outside regular hours, often thin / 常规时段之外的交易，通常较清淡 | [[Earnings Day Mechanics]] |

## Banking and Regulation 银行与监管

| Term | 中文 | Meaning 释义 | Note |
|---|---|---|---|
| CET1 | 普通股一级资本 | Highest-quality bank capital / 最高质量的银行资本 | [[Basel III and Capital Ratios]] |
| RWA | 风险加权资产 | Assets weighted by risk / 按风险加权的资产 | [[Basel III and Capital Ratios]] |
| Tier 1 / Tier 2 | 一级 / 二级资本 | Layers of regulatory capital / 监管资本的层级 | [[Basel III and Capital Ratios]] |
| Leverage ratio | 杠杆率 | Capital divided by total exposure, not risk-weighted / 资本除以总暴露，不做风险加权 | [[Basel III and Capital Ratios]] |
| LCR | 流动性覆盖率 | Liquid assets versus 30-day stressed outflows / 流动性资产相对30天压力流出 | [[Liquidity Rules LCR and NSFR]] |
| NSFR | 净稳定资金比率 | Stable funding versus required stable funding / 稳定资金相对所需稳定资金 | [[Liquidity Rules LCR and NSFR]] |
| HQLA | 优质流动性资产 | Cash and similar easily sold assets / 现金及易于变现的类似资产 | [[Liquidity Rules LCR and NSFR]] |
| G-SIB | 全球系统重要性银行 | Bank whose failure could harm the global system / 倒闭可能危及全球体系的银行 | [[Basel III and Capital Ratios]] |
| Stress test | 压力测试 | Loss estimate under a hypothetical severe scenario / 假设严重情景下的损失估算 | [[Stress Tests and Capital Buffers]] |
| Stress capital buffer | 压力资本缓冲 | Bank-specific buffer set by stress tests / 由压力测试决定的银行专属缓冲 | [[Stress Tests and Capital Buffers]] |
| Net interest income (NII) | 净利息收入 | Interest earned minus interest paid / 赚取的利息减支付的利息 | [[Bank Metrics]] |
| Net interest margin (NIM) | 净息差 | NII relative to earning assets / 净利息收入相对生息资产的比率 | [[Bank Metrics]] |
| Provision for credit losses | 信贷损失拨备 | Expense set aside for expected loan losses / 为预期贷款损失计提的费用 | [[Bank Metrics]] |
| NPL | 不良贷款 | Loans unlikely to be repaid in full / 难以全额收回的贷款 | [[Bank Metrics]] |
| Deposit beta | 存款贝塔 | Share of rate changes passed to depositors / 利率变动中传导给储户的比例 | [[Bank Metrics]] |
| Unrealized loss (AOCI) | 未实现损失 | Mark-to-market loss not yet sold / 尚未卖出的按市值计价损失 | [[Bank Runs and Deposit Insurance]] |
| FDIC | 联邦存款保险公司 | US deposit insurer / 美国存款保险机构 | [[Bank Runs and Deposit Insurance]] |
| Bank run | 挤兑 | Many depositors withdraw at once / 大量储户同时取款 | [[Bank Runs and Deposit Insurance]] |
| Systemic risk | 系统性风险 | Risk that failure spreads across the system / 风险在整个体系内扩散 | [[Bank Regulation Map]] |
| Lender of last resort | 最后贷款人 | Central bank lending to solvent but illiquid banks / 央行向有偿付能力但缺流动性的银行放款 | [[Bank Regulation Map]] |
| Volcker Rule | 沃尔克规则 | Limits bank proprietary trading / 限制银行自营交易 | [[Dodd-Frank and Volcker Rule]] |
| Collateral | 抵押品 | Asset pledged to secure a loan / 为担保贷款而质押的资产 | [[Secured Lending and Collateral]] |
| Security interest | 担保权益 | Right in collateral securing an obligation / 为担保债务而对抵押品享有的权利 | [[Secured Lending and Collateral]] |
| Perfection | 完善（担保权益） | Steps that protect priority against third parties / 保护对第三人优先顺位的步骤 | [[Secured Lending and Collateral]] |
| Priority | 优先顺位 | Order in which creditors are paid / 债权人受偿的顺序 | [[Secured Lending and Collateral]] |
| Covenant | 契约条款 | Promise or restriction in a loan agreement / 贷款协议中的承诺或限制 |  |

## Securities Law 证券法

| Term | 中文 | Meaning 释义 | Note |
|---|---|---|---|
| SEC | 美国证券交易委员会 | US securities regulator / 美国证券监管机构 | [[Securities Law Basics]] |
| 10-K / 10-Q | 年报 / 季报 | Annual / quarterly report / 年度/季度报告 | [[SEC Filings and Earnings Release]] |
| 8-K | 重大事项报告 | Report of specified material events / 特定重大事项的报告 | [[SEC Filings and Earnings Release]] |
| Prospectus | 招股说明书 | Offering document for securities / 证券发行文件 | [[Securities Law Basics]] |
| MNPI | 重大非公开信息 | Material non-public information / 重大的未公开信息 | [[Securities Law Basics]] |
| Insider trading | 内幕交易 | Trading on MNPI in breach of a duty / 违反义务利用 MNPI 交易 | [[Securities Law Basics]] |
| Regulation FD | 公平披露规则 | Limits selective disclosure / 限制选择性披露 | [[Securities Law Basics]] |
| Sarbanes-Oxley (SOX) | 萨班斯-奥克斯利法案 | 2002 law on reporting and controls / 2002年关于财务报告与内控的法律 | [[Securities Law Basics]] |
| Materiality | 重大性 | Whether info would matter to a reasonable investor / 信息是否会影响理性投资者 | [[Securities Law Basics]] |

## Islamic Finance 伊斯兰金融

| Term | 中文 | Meaning 释义 | Note |
|---|---|---|---|
| Shariah | 伊斯兰教法 | Islamic law governing finance / 规范金融的伊斯兰教法 | [[Islamic Finance Basics]] |
| Riba | 利息/高利 | Interest, prohibited / 被禁止的利息 | [[Islamic Finance Basics]] |
| Gharar | 过度不确定性 | Excessive uncertainty, avoided in contracts / 合同中应避免的过度不确定性 | [[Islamic Finance Basics]] |
| Maysir | 赌博 | Gambling, prohibited / 被禁止的赌博 | [[Islamic Finance Basics]] |
| Murabahah | 成本加成买卖 | Cost-plus sale with disclosed margin / 披露成本并加利润的买卖 | [[Islamic Finance Basics]] |
| Ijarah | 租赁 | Leasing / 租赁 | [[Islamic Finance Basics]] |
| Musharakah | 合伙 | Partnership sharing profit and loss / 共享盈亏的合伙 | [[Islamic Finance Basics]] |
| Mudarabah | 信托合伙（利润分成） | Capital from one party, expertise from the other / 一方出资、一方出专业能力 | [[Islamic Finance Basics]] |
| Sukuk | 伊斯兰债券（资产支持证书） | Asset-backed or asset-based certificates / 资产支持或资产基础的证书 | [[Islamic Finance Basics]] |
| Takaful | 伊斯兰保险 | Mutual-cooperation insurance / 基于互助的保险 | [[Islamic Finance Basics]] |

## Global expansion 全球扩展 (v10)

| Term | 中文 | Meaning 释义 | Note |
|---|---|---|---|
| Sovereign wealth fund (SWF) | 主权基金 | State-owned long-term investment fund / 国家所有的长期投资基金 | [[Sovereign Wealth Funds]] |
| Foreign exchange reserves | 外汇储备 | Foreign assets held by a central bank / 央行持有的外币资产 | [[Foreign Exchange Reserves and Reserve Currencies]] |
| Private credit | 私募信贷 | Direct lending by non-bank funds / 非银行基金直接放贷 | [[Private Credit and Shadow Banking]] |
| Duration | 久期 | Price sensitivity to yield changes / 价格对收益率的敏感度 | [[Duration and Convexity]] |
| Convexity | 凸性 | Change in duration as yields move / 久期随收益率的变化 | [[Duration and Convexity]] |
| WACC | 加权平均资本成本 | Blended cost of debt and equity / 债务与股权的综合成本 | [[DCF and Cost of Capital]] |
| Tariff | 关税 | Tax on imports / 对进口商品征税 | [[Trade Tariffs and Supply Chains]] |
| Implied volatility | 隐含波动率 | Volatility priced into options / 期权价格中隐含的波动率 | [[Market Volatility and Options Positioning]] |
| OAS | 期权调整利差 | Bond spread over Treasuries adjusted for options / 调整期权后相对国债的利差 | [[IG and HY Credit Spreads]] |
| MOVE Index | 美债波动率指数 | Expected Treasury volatility / 美债预期波动率 | [[MOVE Index]] |
| HICP | 欧元区调和CPI | Euro-area inflation measure / 欧元区通胀指标 | [[Euro Area HICP]] |
| Tankan | 短观调查 | BoJ business survey / 日本央行企业调查 | [[Japan CPI and Tankan]] |
| Dot plot | 点阵图 | FOMC rate-path projections / 美联储利率路径预测 | [[FOMC Projections Dot Plot]] |
| REIT | 房地产投资信托 | Listed property-owning trust / 持有物业的上市信托 | [[Real Estate and REITs]] |
| Emerging markets | 新兴市场 | Developing economies with growing markets / 市场不断发展的发展中经济体 | [[Emerging Markets Overview]] |

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## 美债常用词（v11.4）

| 术语 | 中文与阅读入口 |
|---|---|
| Coupon / YTM / total return | 票息／到期收益率／总回报：[[21_US_Treasuries/Treasury Cash Flows and Bond Pricing]] |
| Clean / dirty price | 净价／全价：[[21_US_Treasuries/Treasury Clean Price and Settlement]] |
| DV01 / key rate duration | 每 bp 金额敏感度／关键期限久期：[[21_US_Treasuries/Treasury DV01 and Key Rate Duration]] |
| Bull / bear steepening | 牛陡／熊陡：[[21_US_Treasuries/Treasury Yield Curve Scenarios]] |
| Par / spot / forward | 平价／零息／远期收益率：[[21_US_Treasuries/Treasury Spot Forward and Par Yields]] |
| Breakeven / real yield | 通胀补偿／实际收益率：[[21_US_Treasuries/Treasury Real Yields and Breakevens]] |
| TIPS / FRN / STRIPS | [[21_US_Treasuries/Treasury TIPS Mechanics]] · [[21_US_Treasuries/Treasury Floating Rate Notes]] · [[21_US_Treasuries/Treasury STRIPS]] |
| Tail / WI / bid-to-cover | 拍卖尾差／发行前报价／投标倍数：[[03_Indicators/Treasury Auctions]] |
| Repo / SOFR / haircut | 回购融资／隔夜担保利率／抵押品折扣：[[21_US_Treasuries/Treasury Repo SOFR and Collateral]] |
| TGA / ON RRP | 财政账户／隔夜逆回购：[[21_US_Treasuries/Treasury TGA Reserves and RRP]] |
| TIC / custodial bias | 跨境持仓统计／托管偏差：[[21_US_Treasuries/Treasury Holders and TIC]] |
| CTD / basis | 最便宜可交割券／基差：[[21_US_Treasuries/Treasury Futures and Basis Trade]] |

完整主题入口：[[21_US_Treasuries/US Treasury Knowledge Map]]。
