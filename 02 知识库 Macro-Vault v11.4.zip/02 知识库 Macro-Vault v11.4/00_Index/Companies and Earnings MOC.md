---
title: "Companies and Earnings MOC — 公司与财报"
tags: [index, moc]
created: 2026-10-27
updated: 2026-10-27
source: "自动整理：按主题分组的入口（2026-10-27）"
---

# Companies and Earnings MOC — 公司与财报

[[00_Index/Master Index|总索引]] · [[HOME|首页]]

财报怎么读、财报季怎么看、重点公司档案，以及大公司财报如何传导到整体市场。

## 财报阅读步骤

- [[09_Fundamentals/SEC Filings and Earnings Release|SEC Filings and Earnings Release SEC文件与财报发布]]
- [[09_Fundamentals/Financial Statements|Financial Statements 三大财务报表]]
- [[09_Fundamentals/Profitability Ratios|Profitability Ratios 盈利能力指标]]
- [[09_Fundamentals/Cash Flow and FCF|Cash Flow and FCF 现金流与自由现金流]]
- [[09_Fundamentals/Earnings Quality|Earnings Quality 盈利质量]]
- [[09_Fundamentals/GAAP vs Non-GAAP|GAAP vs Non-GAAP GAAP与非GAAP]]
- [[09_Fundamentals/Leverage and Coverage|Leverage and Coverage 杠杆与偿债能力]]
- [[09_Fundamentals/Bank Metrics|Bank Metrics 银行关键指标]]
- [[09_Fundamentals/Valuation Multiples|Valuation Multiples 估值倍数]]
- [[09_Fundamentals/DCF and Cost of Capital|DCF and Cost of Capital 现金流折现与资本成本]]
- [[10_Playbooks/Financial Reading Coverage|Financial Reading Coverage]]
- [[10_Playbooks/Industry KPI Checklist|Industry KPI Checklist]]

## 财报季与市场预期

- [[01_Concepts/Earnings Season|Earnings Season 财报季]]
- [[01_Concepts/Earnings Day Mechanics|Earnings Day Mechanics 财报日机制]]
- [[01_Concepts/Guidance|Guidance 管理层指引]]
- [[01_Concepts/Read-Across|Read-Across 关联传导]]
- [[03_Indicators/Earnings Estimate Revisions|Earnings Estimate Revisions 盈利预测修正]]
- [[10_Playbooks/Earnings Read-Across Playbook|Earnings Read-Across Playbook / 财报关联传导手册]]
- [[10_Playbooks/Thesis Change Log|Thesis Change Log]]

## 重点公司（美国）

- [[04_Companies/Companies Guide|Company Research]]
- [[04_Companies/Company Research Index|Company Research Index]]
- [[04_Companies/AMZN/Company Profile|Amazon — 公司研究档案]]
- [[04_Companies/AMZN/Latest Brief|AMZN — 发生了什么，接下来怎么看]]
- [[04_Companies/GOOGL/Company Profile|Alphabet — 公司研究档案]]
- [[04_Companies/GOOGL/Latest Brief|GOOGL — 发生了什么，接下来怎么看]]
- [[04_Companies/JPM/Company Profile|JPMorgan Chase — 公司研究档案]]
- [[04_Companies/JPM/Latest Brief|JPM — 发生了什么，接下来怎么看]]
- [[04_Companies/MSFT/Company Profile|Microsoft — 公司研究档案]]
- [[04_Companies/MSFT/Latest Brief|MSFT — 发生了什么，接下来怎么看]]
- [[04_Companies/NVDA/Company Profile|NVIDIA — 公司研究档案]]
- [[04_Companies/NVDA/Latest Brief|NVDA — 发生了什么，接下来怎么看]]
- [[04_Companies/AAPL/Company Profile|Apple — 公司研究档案]]
- [[04_Companies/AVGO/Company Profile|Broadcom — 公司研究档案]]
- [[04_Companies/META/Company Profile|Meta Platforms — 公司研究档案]]
- [[04_Companies/TSLA/Company Profile|Tesla — 公司研究档案]]

## 大公司如何影响整体市场

- [[02_Transmission/Mega-Cap Earnings to Index|Mega-Cap Earnings to Index 超大市值传导]]
- [[02_Transmission/Earnings to Market Transmission|Earnings to Market Transmission 财报传导]]
- [[02_Transmission/Chip Earnings to AI Stocks|Chip Earnings to AI Stocks 芯片财报传导到 AI 股票]]
- [[02_Transmission/Hyperscaler Capex to Chip Chain|Hyperscaler Capex to Chip Chain 云巨头资本开支传导到芯片产业链]]
- [[02_Transmission/Bank Earnings to Market|Bank Earnings to Market 银行财报传导]]

## 财报模板

- [[05_Templates/Company Earnings Analysis|Company Earnings Analysis]]
- [[05_Templates/Earnings Read-Across Analysis|Earnings Read-Across Analysis / 财报关联传导分析]]
- [[05_Templates/One Page Research Brief|公司／事件 — 发生了什么，接下来怎么看]]
- [[05_Templates/Weekly Earnings Calendar|Weekly Earnings Calendar / 每周财报日历]]

## 财报日历（带日期）

- [[12_Data/US Release Calendar 2026-10-27|美国数据与财报发布日历 2026-10-27]]

## 相关文件夹

- [[04_Companies/Companies MOC|Companies MOC — 公司]]
- [[09_Fundamentals/Fundamentals MOC|Fundamentals MOC — 财务基础]]
