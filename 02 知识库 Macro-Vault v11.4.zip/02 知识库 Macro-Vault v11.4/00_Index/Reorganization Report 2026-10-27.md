---
title: "整理报告 2026-10-27"
aliases: [整理报告-20261027, Reorganization Report]
tags: [index, system, reorganization]
created: 2026-10-27
updated: 2026-10-27
source: "本次整理的扫描与校验记录（2026-10-27）"
---
# 整理报告 2026-10-27

[[HOME|首页]] · [[00_Index/Master Index|总索引]] · [[00_Index/Reorganization Plan and Path Map|整理方案与改名对照表]]

本次只改动 `knowledge/Macro-Vault/` 内部，并在项目根目录建了备份 `knowledge-backup-20261027/`。方案选择、命名规则和每个文件的“旧路径 → 新路径”见整理方案。

## 1. 整理前后对比

| 项目 | 整理前 | 整理后 |
|---|---:|---:|
| 文件总数 | 544 | 584 |
| Markdown 笔记 | 401 | 441 |
| 顶层文件夹 | 23 | 24 |
| 子文件夹 | 42 | 44 |
| 根目录文件 | 21 | 7 |
| 内部链接（含标题、段落定位） | 6,419 | 7,577 |
| 失效链接 | 0 | 0 |
| 标题／段落定位错误 | 0 | 0 |
| 孤立笔记（无链接进出） | 0 | 0 |
| 从 HOME 无法到达 | 0 | 0 |
| 从总索引无法到达 | （原无总索引） | 0 |
| 缺少 frontmatter | 110 | 36（有意保留，见第 4 节） |
| MOC／索引笔记（本次新建） | 0 | 29 |
| 疑似密钥 | 0 | 0 |

**文件数对账：** 备份 544 个文件全部能按对照表找到（缺失 0 个）：452 个完全未变，92 个只有新增内容（逐行比对，删改 0 处）。本次没有合并任何笔记，所以没有“已归档的合并文件”需要扣除；两个下载残片只是移到 `20_Archive/Partial Downloads/`，仍计在内。新增文件 40 个（见第 3 节），544 + 40 = 584。

**目录变化：** 新建 `00_Index/`；新建 `15_System/Release History/` 与 `20_Archive/Partial Downloads/` 两个子文件夹；根目录从 21 个文件减到 7 个（`HOME.md`、`CLAUDE.md`、`AI START HERE.md`、`Today Dashboard.md`、`Review Queue.md`、`Prediction Scorecard.md`、`SHA256SUMS.txt`）。其余 23 个文件夹原位不动。

## 2. 合并清单

**0 篇。** 32 对相似度超过 50% 的笔记是同日三次自动运行的报告快照（每份简报用段落定位指向本次运行自己的证据）和同一模板生成的不同公司笔记；同名的 `13_Sources/Raw` 与 `13_Sources/Records` 分别是原文和记录卡。合并会破坏证据链，因此没有可合并、也没有需要归档的重复笔记。

## 3. 新增笔记清单

### 补全的知识笔记（9 篇，马来西亚 0 篇）

- [[12_Data/US Macro Snapshot 2026-10-27]] — 美国宏观与市场数据快照：利率、通胀、就业、ECI、GDP、工业生产、耐用品、财政、美债收益率、三大指数、油价、JPM、OPR。来源：美联储、BLS、BEA、财政部、EIA、S&P DJI、Nasdaq、Census、JPMorgan Chase、BNM；verified: 2026-10-27
- [[12_Data/US Release Calendar 2026-10-27]] — 2026-10 至 12 月的美国数据与大公司财报日程。来源：美联储、BLS、BEA、FRED、Microsoft、Alphabet、Amazon、Apple、Meta、JPMorgan Chase；verified: 2026-10-27
- [[03_Indicators/Employment Cost Index]] — 就业成本指数怎么读。来源：BLS https://www.bls.gov/eci/；verified: 2026-10-27
- [[03_Indicators/Federal Budget and Monthly Treasury Statement]] — 联邦预算与月度财政报表怎么读。来源：U.S. Treasury https://fiscal.treasury.gov/accounting/monthly-treasury-statement/；verified: 2026-10-27
- [[03_Indicators/Industrial Production and Capacity Utilization]] — 工业生产与产能利用率怎么读。来源：Federal Reserve G.17 https://www.federalreserve.gov/releases/g17/current/default.htm；verified: 2026-10-27
- [[03_Indicators/Senior Loan Officer Survey]] — 高级信贷员调查怎么读。来源：Federal Reserve https://www.federalreserve.gov/data/sloos.htm；verified: 2026-10-27
- [[03_Indicators/Durable Goods Orders]] — 耐用品与核心资本品订单怎么读。来源：Census M3 https://www.census.gov/manufacturing/m3/index.html（经 FRED 核对口径）；verified: 2026-10-27
- [[08_Sectors/Utilities]] — 公用事业板块：驱动因素与交易特征。来源：MSCI / S&P DJI GICS https://www.msci.com/our-solutions/indexes/gics；verified: 2026-10-27
- [[08_Sectors/Materials]] — 原材料板块：驱动因素与交易特征。来源：MSCI / S&P DJI GICS https://www.msci.com/our-solutions/indexes/gics；verified: 2026-10-27

### 索引与说明（31 篇）

- [[00_Index/Master Index]] — 总索引，按九大类链接全部 MOC
- 分类 MOC（5 篇）：[[00_Index/Macro Framework MOC]] · [[00_Index/Markets and Assets MOC]] · [[00_Index/Companies and Earnings MOC]] · [[00_Index/Events and Transmission MOC]] · [[00_Index/Daily and Weekly MOC]]
- 文件夹 MOC（23 篇）：[[00_Inbox/Inbox MOC]] · [[01_Concepts/Concepts MOC]] · [[02_Transmission/Transmission MOC]] · [[03_Indicators/Indicators MOC]] · [[04_Companies/Companies MOC]] · [[05_Templates/Templates MOC]] · [[06_Daily/Daily MOC]] · [[07_Weekly/Weekly MOC]] · [[08_Sectors/Sectors MOC]] · [[09_Fundamentals/Fundamentals MOC]] · [[10_Playbooks/Playbooks MOC]] · [[11_Malaysia/Malaysia MOC]] · [[12_Data/Data MOC]] · [[13_Sources/Sources MOC]] · [[14_Reports/Reports MOC]] · [[15_System/System MOC]] · [[16_TestCases/Test Cases MOC]] · [[17_Bank_Regulation/Bank Regulation MOC]] · [[18_Videos/Videos MOC]] · [[19_Regions/Regions MOC]] · [[20_Archive/Archive MOC]] · [[21_US_Treasuries/US Treasuries MOC]] · [[99_Automation/Automation MOC]]
- [[00_Index/Reorganization Plan and Path Map]] 与本报告

## 4. 修改过的已有笔记（只新增，不删改）

- `HOME.md`：导航表新增一行“按主题浏览全部笔记 → 总索引”。
- `00_Index/Knowledge Index.md`：“Start here”列表首行新增总索引入口。
- 在 17 篇笔记里追加了指向新笔记或数据快照的链接，原有文字不动：
  - `03_Indicators/CPI.md`（第 16 行后）：最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]
  - `03_Indicators/PCE Inflation.md`（第 16 行后）：最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]
  - `03_Indicators/Nonfarm Payrolls.md`（第 16 行后）：最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]；相关指标 [[Employment Cost Index]]
  - `03_Indicators/Unemployment Rate.md`（第 16 行后）：最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]
  - `03_Indicators/US GDP Report.md`（第 16 行后）：最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]；相关指标 [[Durable Goods Orders]]、[[Industrial Production and Capacity Utilization]]
  - `03_Indicators/Federal Funds Rate.md`（第 16 行后）：最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]；会议日程 [[12_Data/US Release Calendar 2026-10-27|发布日历]]
  - `03_Indicators/US 10-Year Treasury Yield.md`（第 16 行后）：最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]；财政供给 [[Federal Budget and Monthly Treasury Statement]]
  - `03_Indicators/US Equity Indices.md`（第 16 行后）：最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]
  - `03_Indicators/WTI and Brent Crude.md`（第 17 行后）：最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]
  - `03_Indicators/PMI.md`（第 16 行后）：2026-10-27 新增相关：[[Industrial Production and Capacity Utilization]]、[[Durable Goods Orders]]
  - `11_Malaysia/OPR.md`（第 16 行后）：最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]（第 9 节）
  - `01_Concepts/Labor Market.md`（第 27 行后）：2026-10-27 新增相关：[[Employment Cost Index]]
  - `01_Concepts/Capex Cycle.md`（第 16 行后）：2026-10-27 新增相关：[[Durable Goods Orders]]、[[Industrial Production and Capacity Utilization]]
  - `01_Concepts/Credit Markets.md`（第 27 行后）：2026-10-27 新增相关：[[Senior Loan Officer Survey]]
  - `01_Concepts/Fiscal Policy.md`（第 16 行后）：2026-10-27 新增相关：[[Federal Budget and Monthly Treasury Statement]]
  - `08_Sectors/US Sectors Map.md`（第 55 行后）：2026-10-27 新增板块：[[Utilities]]、[[Materials]]
  - `04_Companies/JPM/Company Profile.md`（第 23 行后）：## 2026-10-27 补充：最新季度数据（表格 3 行）
- 补 frontmatter 74 篇（title、tags、created、updated、source）：04_Companies 21 篇，10_Playbooks 3 篇，12_Data 1 篇，13_Sources 27 篇，14_Reports 1 篇，15_System 13 篇，99_Automation 6 篇，根目录 2 篇。其中 26 篇来源记录卡的 source 填官方下载地址，其余写“待补充”。完整清单见附录。
- 有意不补 frontmatter 36 篇：`13_Sources/Raw/*.md` 21 篇（第三方原文提取文本，程序会整篇送给 AI 作证据）和 `14_Reports/Run History/*/*/Evidence.md` 15 篇（按运行编号固定的证据快照）。

## 5. 更新数据清单（每行：指标、旧值 → 新值、数据日期、来源与网址；写入日期均为 2026-10-27）

- 联邦基金利率目标区间：3.50%–3.75% → 3.75%–4.00%；数据日期 2026-09-16 决议，09-17 生效；来源 Federal Reserve https://www.federalreserve.gov/newsevents/pressreleases/monetary20260916a.htm
- 2026 年各次 FOMC 结果：1、3、4、6、7 月维持；9 月加息 25 个基点；数据日期 2026-01 至 2026-09；来源 Federal Reserve https://www.federalreserve.gov/monetarypolicy/openmarket.htm
- 余下 FOMC 会议：10-27–28；12-08–09（附 SEP）；数据日期 2026 日程；来源 Federal Reserve https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm
- CPI-U 环比 / 同比：0.6% / 3.7%；数据日期 2026-09（10-14 发布）；来源 BLS https://www.bls.gov/news.release/cpi.nr0.htm
- 核心 CPI 环比 / 同比：0.3% / 2.6%；数据日期 2026-09；来源 BLS https://www.bls.gov/news.release/cpi.nr0.htm
- PCE 价格指数 环比 / 同比：0.3% / 3.4%；数据日期 2026-08（09-30 发布）；来源 BEA https://www.bea.gov/news/2026/personal-income-and-outlays-august-2026
- 核心 PCE 环比 / 同比：0.2% / 3.0%；数据日期 2026-08；来源 BEA https://www.bea.gov/news/2026/personal-income-and-outlays-august-2026
- 非农就业变化：+2.9 万；数据日期 2026-09（10-02 发布）；来源 BLS https://www.bls.gov/news.release/empsit.nr0.htm
- 7 月非农（修正）：+2.1 万 → -1.0 万；数据日期 2026-07；来源 BLS https://www.bls.gov/news.release/empsit.nr0.htm
- 8 月非农（修正）：+16.2 万 → +13.3 万；数据日期 2026-08；来源 BLS https://www.bls.gov/news.release/empsit.nr0.htm
- 失业率：4.2%；数据日期 2026-09；来源 BLS https://www.bls.gov/news.release/empsit.nr0.htm
- 平均时薪：37.81 美元；环比 +0.1%，同比 +3.0%；数据日期 2026-09；来源 BLS https://www.bls.gov/news.release/empsit.nr0.htm
- ECI 民用总薪酬：季环比 +0.9%；12 个月 +3.4%（工资 +3.2%，福利 +3.8%）；数据日期 2026 Q2（07-31 发布）；来源 BLS https://www.bls.gov/news.release/eci.nr0.htm
- 实际 GDP（年化）：2.2%（第三次估计）；Q1 修正为 2.5%；数据日期 2026 Q2（09-30 发布）；来源 BEA https://www.bea.gov/data/gdp/gross-domestic-product
- 工业生产 环比：+0.7%；制造业 +0.3%；数据日期 2026-09（10-16 发布）；来源 Federal Reserve G.17 https://www.federalreserve.gov/releases/g17/current/default.htm
- 产能利用率：76.9%，低于 1972–2025 均值 2.5 个百分点；数据日期 2026-09；来源 Federal Reserve G.17 https://www.federalreserve.gov/releases/g17/current/default.htm
- 耐用品新订单（季调）：3,384.58 亿美元；数据日期 2026-08；来源 Census M3 经 FRED https://fred.stlouisfed.org/series/DGORDER
- 核心资本品新订单（季调）：876.40 亿美元；数据日期 2026-08；来源 Census M3 经 FRED https://fred.stlouisfed.org/series/NEWORDER
- 联邦财年赤字：2025 财年 1.7754 万亿 → 2026 财年 1.9925 万亿美元；数据日期 2026 财年（截至 2026-09-30）；来源 U.S. Treasury Fiscal Data MTS 表 1 https://api.fiscaldata.treasury.gov/services/api/fiscal_service/v1/accounting/mts/mts_table_1?filter=record_date:eq:2026-09-30
- 联邦财年收入 / 支出：5.4033 万亿 / 7.3958 万亿美元；数据日期 2026 财年；来源 U.S. Treasury Fiscal Data MTS 表 1 https://api.fiscaldata.treasury.gov/services/api/fiscal_service/v1/accounting/mts/mts_table_1?filter=record_date:eq:2026-09-30
- 9 月单月财政：赤字 269.0 亿美元（2025 年 9 月盈余 1,979.4 亿）；数据日期 2026-09；来源 U.S. Treasury Fiscal Data MTS 表 1 https://api.fiscaldata.treasury.gov/services/api/fiscal_service/v1/accounting/mts/mts_table_1?filter=record_date:eq:2026-09-30
- 3 个月美债收益率：4.17 → 4.22；数据日期 2026-10-01 → 2026-10-26；来源 U.S. Treasury Daily Par Yield Curve https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/2026/all?type=daily_treasury_yield_curve&field_tdr_date_value=2026&page&_format=csv
- 2 年期美债收益率：4.78 → 4.68；数据日期 2026-10-01 → 2026-10-26；来源 U.S. Treasury Daily Par Yield Curve https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/2026/all?type=daily_treasury_yield_curve&field_tdr_date_value=2026&page&_format=csv
- 10 年期美债收益率：5.24 → 5.00（库内旧值约 5.05%，10-19 日报）；数据日期 2026-10-01 → 2026-10-26；来源 U.S. Treasury Daily Par Yield Curve https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/2026/all?type=daily_treasury_yield_curve&field_tdr_date_value=2026&page&_format=csv
- 30 年期美债收益率：5.61 → 5.31；数据日期 2026-10-01 → 2026-10-26；来源 U.S. Treasury Daily Par Yield Curve https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/2026/all?type=daily_treasury_yield_curve&field_tdr_date_value=2026&page&_format=csv
- S&P 500 收盘：7,659.44（10-16，库内日报）→ 7,623.68；数据日期 2026-10-23；来源 S&P DJI 经 FRED https://fred.stlouisfed.org/series/SP500
- 纳斯达克综合指数 收盘：26,140.03（10-16，库内日报）→ 26,169.38；数据日期 2026-10-26；来源 Nasdaq 经 FRED https://fred.stlouisfed.org/series/NASDAQCOM
- 道琼斯工业平均指数 收盘：52,002（10-16，库内日报）→ 52,361.58；数据日期 2026-10-26；来源 S&P DJI 经 FRED https://fred.stlouisfed.org/series/DJIA
- WTI 现货：约 100.6（10-19 期货报道，口径不同）→ 107.89 美元/桶；数据日期 2026-10-20；来源 EIA 经 FRED https://fred.stlouisfed.org/series/DCOILWTICO
- JPM 净利润：211.55 亿（2026-06-30）→ 153 亿美元；数据日期 2026 Q3（10-13 发布）；来源 JPMorgan Chase 3Q26 新闻稿 https://www.jpmorganchase.com/content/dam/jpmc/jpmorgan-chase-and-co/investor-relations/documents/quarterly-earnings/2026/3rd-quarter/6c1f8114-1be4-4174-8292-f75bbb59bc21.pdf
- JPM 稀释每股收益：7.70 → 5.57 美元；数据日期 2026 Q3；来源 JPMorgan Chase 3Q26 新闻稿 https://www.jpmorganchase.com/content/dam/jpmc/jpmorgan-chase-and-co/investor-relations/documents/quarterly-earnings/2026/3rd-quarter/6c1f8114-1be4-4174-8292-f75bbb59bc21.pdf
- JPM 净利息收入：255.11 亿 → 271 亿美元；数据日期 2026 Q3；来源 JPMorgan Chase 3Q26 新闻稿 https://www.jpmorganchase.com/content/dam/jpmc/jpmorgan-chase-and-co/investor-relations/documents/quarterly-earnings/2026/3rd-quarter/6c1f8114-1be4-4174-8292-f75bbb59bc21.pdf
- JPM 营收：报告口径 502 亿；管理口径 509 亿美元；数据日期 2026 Q3；来源 JPMorgan Chase 3Q26 新闻稿 https://www.jpmorganchase.com/content/dam/jpmc/jpmorgan-chase-and-co/investor-relations/documents/quarterly-earnings/2026/3rd-quarter/6c1f8114-1be4-4174-8292-f75bbb59bc21.pdf
- 马来西亚 OPR：2.75%（维持）；数据日期 2026-09-03 MPC；来源 Bank Negara Malaysia https://www.bnm.gov.my/monetary-stability/opr-decisions

发布日程（写入 [[12_Data/US Release Calendar 2026-10-27]]）：

- 10-27：Census 9 月耐用品订单预告；来源 FRED https://fred.stlouisfed.org/series/DGORDER
- 10-28：FOMC 声明（会议 10-27–28）；来源 Federal Reserve https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm
- 10-28：Microsoft 2027 财年 Q1 财报（盘后）；来源 Microsoft https://news.microsoft.com/source/2026/10/07/microsoft-announces-quarterly-earnings-release-date-69/
- 10-28：Alphabet Q3 电话会 4:30 p.m. ET；来源 Alphabet https://abc.xyz/investor/news/news-details/2026/Alphabet-Announces-Date-of-Third-Quarter-2026-Financial-Results-Conference-Call-2026-8tpGZsLS6v/default.aspx
- 10-29：BEA 下次发布（GDP、PCE）；来源 BEA https://www.bea.gov/data/gdp/gross-domestic-product
- 10-29：Amazon Q3 电话会 5:00 p.m. ET；来源 Amazon https://ir.aboutamazon.com/events/event-details/2026/Q3-2026-Amazoncom-Inc-Earnings-Conference-Call/default.aspx
- 10-30：BLS 第三季度 ECI；来源 BLS https://www.bls.gov/schedule/news_release/eci.htm
- 11-02：Apple 2026 财年 Q4 业绩 5:00 p.m. ET；来源 Apple https://investor.apple.com/investor-relations/event-details/2026/FY-26-Fourth-Quarter-Results/default.aspx
- 11-06：BLS 10 月就业报告；来源 BLS https://www.bls.gov/news.release/empsit.nr0.htm
- 11-10：BLS 10 月 CPI；来源 BLS https://www.bls.gov/news.release/cpi.nr0.htm
- 11-24：G.17 年度修订；来源 Federal Reserve G.17 https://www.federalreserve.gov/releases/g17/current/default.htm
- 12-09：FOMC 声明（会议 12-08–09，附 SEP）；来源 Federal Reserve https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm
- 10-21（已发生）：Meta Q3 财报（盘后）；来源 Meta https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-to-Announce-Third-Quarter-2026-Results/default.aspx
- 10-13（已发生）：JPMorgan Chase Q3 财报；来源 JPMorgan Chase 3Q26 新闻稿 https://www.jpmorganchase.com/content/dam/jpmc/jpmorgan-chase-and-co/investor-relations/documents/quarterly-earnings/2026/3rd-quarter/6c1f8114-1be4-4174-8292-f75bbb59bc21.pdf

明细与限制见 [[12_Data/US Macro Snapshot 2026-10-27]]。只有标“修正”的两行是同一数据的前后版本，其余“旧值 → 新值”是不同日期的观测。

## 6. 待核实清单

- 9 月 CPI 里推高整体通胀的具体分项（未核对分项表）。
- 9 月耐用品订单预告值（10-27 发布；Census 官网当天两次访问失败，FRED 尚未更新）。
- 2026 财年月度财政报表（MTS）的正式发布日期（官方接口只给数据，不给发布日）。
- Bank Negara Malaysia 下一次 MPC 会议日期。
- JPM 2026 年第二季度净利润是否含一次性项目（影响新旧两季能否比较）。
- NVIDIA 2027 财年第三季度财报日期（官方页面未找到）。
- 美联储 10 月高级信贷员调查（SLOOS）发布日期。
- FOMC 10-28 声明的具体时间（按惯例 2:00 p.m. ET，本次未单独核实）。
- 原材料板块在标普 500 中的当前权重（笔记中未写数字）。
- GICS 板块定义 PDF 只通过搜索摘要读取，未直接打开原文（公用事业、原材料两篇）。

## 7. 仍需你决定的事项

- **用一键启动器时的知识库位置：** `MacroVault.app` 和 `MacroVault-OneClick-Mac.command` 会把程序装到 `~/Library/Application Support/MacroVault/App`，并在那里另外解包一份**未整理**的 `knowledge/`。如果你用启动器运行网站，请在首次启动前把整理好的 `knowledge/` 复制过去，或在网站设置里把监控路径改为 `MacroVault-RAG/knowledge/Macro-Vault`。用 `Start-Mac.command` 或 `run.py` 直接运行则无需处理。
- **291 篇已有 frontmatter 字段不统一**（用 tags、aliases、as_of 等，多数没有 title、created、updated、source）。按要求本次没动。要不要统一补齐这四个字段？
- **36 篇有意不加 frontmatter 的原文与证据快照**，是否保持原样？
- **程序会重写的笔记：** 若以后运行 `99_Automation/engine/vault.py`，`Evidence Index`、`Company Research Index`、`Source Index`、`Run History Index`、`Review Queue`、`Prediction Scorecard` 和来源记录卡会被整篇重写，本次补的 frontmatter 会消失（内容不受影响）。是否需要调整程序？本次没有改任何代码。
- **两个下载残片**（约 14.7 MB）已移到 `20_Archive/Partial Downloads/`，正式文件完整。是否删除？
- **历史校验记录：** `SHA256SUMS.txt` 与 `16_TestCases/*.json` 记录的是整理前的路径和哈希，与现在不符。保留作历史，还是重新生成？
- **`vault.py` 帮助文字**仍写“See START HERE.md”，文件已移到 `00_Index/`。代码没改。
- **备份文件夹与 git：** `.gitignore` 只忽略 `knowledge/`，不含 `knowledge-backup-20261027/`。若用 git，它会显示为未跟踪文件；本次按约束没改 `.gitignore`。
- **公司覆盖：** 只有 AMZN、GOOGL、JPM、MSFT、NVDA 五家有档案。AAPL、META、AVGO、TSLA 等指数权重大的公司没有。是否用库内程序补建（需要你的 SEC 抓取设置）？
- **网站研究模式的必读规则**每次从 `seed/Macro-Vault-v11.4.zip` 读取，不读 `knowledge/`。新增笔记会进入普通检索，但不会进入“必读规则”。
- **两份说明文件的名字：** 按“沿用英文”的决定，用的是 `Reorganization Plan and Path Map.md` 和 `Reorganization Report 2026-10-27.md`，并加了中文别名“整理方案与改名对照表”“整理报告-20261027”，Obsidian 里用中文也能搜到。若你更想要中文文件名，可以改，链接需要同步更新。

## 8. 自检

| 检查 | 结果 |
|---|---|
| 1. 备份完整 | 544 个文件、138,608,089 字节，与解包后的原文件夹逐文件一致；整理结束时备份仍为同样的文件数和字节数 |
| 2. 失效链接 / 孤立笔记 | 0 / 0；从 HOME 和从总索引无法到达的笔记均为 0 / 0 |
| 3. 对照表覆盖 | 移动 16 个文件，对照表 16 行，逐一对应；按对照表映射后备份文件缺失 0 个 |
| 4. 数据点有来源、网址、日期 | 34 个数据点与 14 个日程均带来源名称、网址、数据日期，写入日期 2026-10-27 |
| 5. knowledge/ 以外的改动 | 整理前后对 423 个文件做 SHA-256 比对：0 个改动、新增或删除（备份文件夹除外） |

## 下一步

在网站“同步中心”点“重新扫描文件夹”，让索引跟上新的文件路径。旧对话里引用的路径会提示来源变化，这是正常的。

## 9. 第二轮补做（2026-10-27，按你的答复）

| 事项 | 你的决定 | 处理结果 |
|---|---|---|
| 已有 frontmatter 的 291 篇字段不统一 | 要补 | 291 篇只补缺少的 title、created、updated、source，原有字段一个没改。<br>日期取原资料包里该文件的日期；有 `created_at`、`updated_at` 的按原值；今天改过正文的，updated 写 2026-10-27。<br>source 查不到的写“待补充”，引擎生成的写“MacroVault 自动化引擎生成”。<br>14 篇模板写空白占位 `""`，按模板新建笔记时再填。 |
| 36 篇原文和证据快照 | 整理好 | 全部加了 frontmatter，正文一字未改。<br>21 篇原文：source 是对应 `.meta.json` 里的原始网址，created 是抓取日期。<br>15 篇证据页：source 是那次运行的数据快照。<br>库内校验程序只核对 `.html` 和 `.json` 原始文件（`99_Automation/engine/vault.py` 第 307–311 行），所以校验值不受影响。 |
| 2 个下载残片 | 没有影响就删 | 已确认两者都是完整文件的前半截（5,242,880 和 9,437,184 字节），完整文件的 SHA-256 与记录一致，也没有程序或笔记引用。<br>两个残片已删除，空文件夹 `20_Archive/Partial Downloads/` 一并删除。备份里仍保留，还原方法见[[00_Index/Reorganization Plan and Path Map\|整理方案]]第 10 节。 |
| SHA256SUMS.txt 与测试记录 | 不必要就不用 | 网站和库内程序都不读取 SHA256SUMS.txt，所以保留原样作历史，不重新生成。 |
| 补 AAPL、META、AVGO、TSLA | 要 | 新增 4 篇公司档案（见下文），加入公司索引和“公司与财报”分类索引，并在 3 篇板块笔记的 Related 下各加一行入口。<br>没有加入自动化名单 `settings.json`，所以这 4 家没有一页简报和八季数据。 |
| 启动器（第 1 项） | 希望双击就能用；同意改 `knowledge/` 以外的文件 | 已用整理后的知识库重新打包 Mac、Windows 启动器和 `MacroVault.app`，见下文“启动器重新打包”。 |

### 新增笔记（4 篇）

- [[04_Companies/AAPL/Company Profile|Apple — 公司研究档案]]
- [[04_Companies/META/Company Profile|Meta Platforms — 公司研究档案]]
- [[04_Companies/AVGO/Company Profile|Broadcom — 公司研究档案]]
- [[04_Companies/TSLA/Company Profile|Tesla — 公司研究档案]]

### 新增数据（写入日期均为 2026-10-27；单位百万美元，每股收益除外）

- **AAPL 2026 财年第三季度**（截至 2026-06-27，发布 2026-07-30）：营收 109,417（上年同期 94,036）；净利润 29,789；稀释每股收益 2.02 美元，其中关税退款贡献 0.11 美元。来源：[Apple 新闻稿](https://www.apple.com/newsroom/2026/07/apple-reports-third-quarter-results/)、[SEC 8-K 附件 99.1](https://www.sec.gov/Archives/edgar/data/0000320193/000032019326000018/a8-kex991q3202606272026.htm)
- **META 2026 年第三季度**（截至 2026-09-30，发布 2026-10-21）：营收 64,601（51,242）；营业利润 12,988（20,535），含 98.9 亿美元和解费用；净利润 9,860；稀释每股收益 3.83 美元。指引：第四季度营收 730–760 亿美元，2026 全年资本开支 1,350–1,450 亿美元。来源：[Meta 新闻稿](https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-Reports-Third-Quarter-2026-Results/default.aspx)、[SEC 8-K 附件 99.1](https://www.sec.gov/Archives/edgar/data/0001326801/000162828026066700/meta-09302026xexhibit991.htm)
- **AVGO 2026 财年第三季度**（截至 2026-08-02，发布 2026-09-02）：营收约 296 亿美元（上年同期 15,952）；AI 半导体营收 167 亿美元，同比 +221%；稀释每股收益 GAAP 2.68 美元、非 GAAP 3.32 美元。指引：第四季度营收约 348 亿美元。来源：[SEC 8-K 附件 99](https://www.sec.gov/Archives/edgar/data/0001730168/000173016826000076/avgo-08022026x8kxex99.htm)
- **TSLA 2026 年第三季度**（截至 2026-09-30，发布 2026-10-21）：营收 28,046（28,095）；营业利润 718（1,624）；GAAP 稀释每股收益 0.22 美元；自由现金流 1,531（3,990）；交付 486,532 辆。来源：[SEC 8-K 附件 99.1](https://www.sec.gov/Archives/edgar/data/0001318605/000162828026066738/exhibit9914.htm)

### 新增待核实

- META、AVGO、TSLA 下一次财报的日期。
- Broadcom 投资者关系网站访问被拒（HTTP 403），数字改按同一新闻稿的 SEC 8-K 附件。
- AVGO 上年同期的利润数据没有逐项核对，档案里用“—”表示。

### 第二轮自检

- **文件数：** 584 − 2（删除的残片）+ 4（公司档案）= 586 个文件，其中笔记 445 篇、链接 7,650 条（含本节新增的 5 条）。
- **链接与 frontmatter：** 失效链接 0，孤立笔记 0，从首页或总索引进不去的 0，缺 frontmatter 的 0，疑似密钥 0。
- **只新增：** 与第二轮开始前的快照逐行比对，已有笔记删改 0 行。唯一被替换的一行，是 JPM 档案里第一轮我自己写的 `updated: 2026-10-19`，改为 `2026-10-27`，因为这篇今天加过内容。另外我生成的 4 篇索引重新生成了一遍。
- **`knowledge/` 以外：** 423 个文件中 422 个指纹不变。根目录的 `.DS_Store` 被更新，`MacroVault-RAG/.DS_Store` 是新出现的。这是 macOS 访达保存窗口显示方式的隐藏文件，不是项目内容，本次的命令都不会写这类文件。
- **备份：** 仍是 544 个文件、138,608,089 字节。

### 启动器重新打包（你已同意改动 `knowledge/` 以外的文件）

- **先备份：** 7 个原文件（共 15 个文件）备份到项目根目录的 `launcher-backup-20261027/`，指纹逐个比对一致。
- **知识库压缩包：** `MacroVault-RAG/seed/Macro-Vault-v11.4.zip` 换成整理后的知识库。
  - 586 个文件，与 `knowledge/Macro-Vault` 逐字节一致。
  - 文件名和外层文件夹 `Macro-Vault/` 与原包相同。
  - 网站研究模式要读的 9 个必读规则文件都能唯一找到，大小都在上限内。
- **怎么生成的：** 用项目自带的 `scripts/build_mac_launcher.py`、`build_windows_launcher.py`、`build_mac_app.py` 重新生成三个启动器，脚本本身没改。
  - 运行时把 `knowledge-backup-20261027/` 排除在打包之外，否则 138 MB 的备份会被一起装进启动器。
  - `SOURCE_MANIFEST.json` 由脚本自动刷新，只有知识库压缩包这一项的校验值变了。
  - 网站程序代码一个文件都没改。
- **核对结果：**
  - 两个启动器的脚本部分只变了一行，就是内嵌校验值。
  - 内嵌的 83 个文件中，只有知识库压缩包和清单两项变化，其余逐字节相同；82 个应用文件全部符合清单。
  - `MacroVault.app` 签名有效，里面的启动器与新版一致。
  - 两个 `.zip` 解压后与原文件一致，解压出的 App 签名仍有效。
- **没有实际运行启动器：** 这台 Mac 只有 Python 3.9，一运行启动器就会下载并打开 Python 安装程序。Windows 启动器仍没有在 Windows 实机上运行过。
- **只对没装过的电脑有效：** 已经装过 MacroVault 的电脑会保留原来那份知识库，程序不会覆盖。这台 Mac 还没装过（安装目录里只有 10:53 一次被取消的打开记录）。

## 附录：补 frontmatter 的 74 篇

- `Prediction Scorecard.md` — tags: [system, predictions]；source: 待补充
- `Review Queue.md` — tags: [system, review]；source: 待补充
- `04_Companies/Company Research Index.md` — tags: [company, index, generated]；source: 待补充
- `04_Companies/AMZN/Company Profile.md` — tags: [company, amzn]；source: 待补充
- `04_Companies/AMZN/Current Thesis.md` — tags: [company, amzn]；source: 待补充
- `04_Companies/AMZN/Evidence Index.md` — tags: [company, amzn]；source: 待补充
- `04_Companies/AMZN/Thesis History.md` — tags: [company, amzn]；source: 待补充
- `04_Companies/GOOGL/Company Profile.md` — tags: [company, googl]；source: 待补充
- `04_Companies/GOOGL/Current Thesis.md` — tags: [company, googl]；source: 待补充
- `04_Companies/GOOGL/Evidence Index.md` — tags: [company, googl]；source: 待补充
- `04_Companies/GOOGL/Thesis History.md` — tags: [company, googl]；source: 待补充
- `04_Companies/JPM/Company Profile.md` — tags: [company, jpm]；source: 待补充
- `04_Companies/JPM/Current Thesis.md` — tags: [company, jpm]；source: 待补充
- `04_Companies/JPM/Evidence Index.md` — tags: [company, jpm]；source: 待补充
- `04_Companies/JPM/Thesis History.md` — tags: [company, jpm]；source: 待补充
- `04_Companies/MSFT/Company Profile.md` — tags: [company, msft]；source: 待补充
- `04_Companies/MSFT/Current Thesis.md` — tags: [company, msft]；source: 待补充
- `04_Companies/MSFT/Evidence Index.md` — tags: [company, msft]；source: 待补充
- `04_Companies/MSFT/Thesis History.md` — tags: [company, msft]；source: 待补充
- `04_Companies/NVDA/Company Profile.md` — tags: [company, nvda]；source: 待补充
- `04_Companies/NVDA/Current Thesis.md` — tags: [company, nvda]；source: 待补充
- `04_Companies/NVDA/Evidence Index.md` — tags: [company, nvda]；source: 待补充
- `04_Companies/NVDA/Thesis History.md` — tags: [company, nvda]；source: 待补充
- `10_Playbooks/Financial Reading Coverage.md` — tags: [playbook]；source: 待补充
- `10_Playbooks/Industry KPI Checklist.md` — tags: [playbook]；source: 待补充
- `10_Playbooks/Thesis Change Log.md` — tags: [playbook]；source: 待补充
- `12_Data/Data Guide.md` — tags: [data, guide]；source: 待补充
- `13_Sources/Source Index.md` — tags: [sources, index]；source: 待补充
- `13_Sources/Records/SRC-01f576137f26e339d42bae12.md` — tags: [sources, source-record]；source: https://news.samsung.com/global/samsung-electronics-announces-earnings-guidance-for-third-quarter-2026
- `13_Sources/Records/SRC-08308d5b92d92472bdc27b22.md` — tags: [sources, source-record]；source: https://data.sec.gov/submissions/CIK0001652044.json
- `13_Sources/Records/SRC-0d22ae2e56e5e9209f93b78c.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/19617/000162828026065582/0001628280-26-065582.txt
- `13_Sources/Records/SRC-174f3bdf69743dba0ce516d7.md` — tags: [sources, source-record]；source: https://data.sec.gov/api/xbrl/companyfacts/CIK0001018724.json
- `13_Sources/Records/SRC-1cf41a59f7a0f9bd19d142ef.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/1045810/000104581026000073/0001045810-26-000073.txt
- `13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466.md` — tags: [sources, source-record]；source: https://data.sec.gov/api/xbrl/companyfacts/CIK0001652044.json
- `13_Sources/Records/SRC-1db8a6c89a58e018e4171fc7.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/nvda-20260125.htm
- `13_Sources/Records/SRC-2b259bd14aae3c6cda610019.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/msft-20260331.htm
- `13_Sources/Records/SRC-37b983f4389f983f2f7b570c.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/nvda-20260726.htm
- `13_Sources/Records/SRC-76097bd5d0676a2af912246a.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/goog-20260630.htm
- `13_Sources/Records/SRC-7ab958b0ea29ba91248ed4e8.md` — tags: [sources, source-record]；source: https://data.sec.gov/submissions/CIK0001045810.json
- `13_Sources/Records/SRC-7f583d5afbbe74d9038418ff.md` — tags: [sources, source-record]；source: https://data.sec.gov/api/xbrl/companyfacts/CIK0000019617.json
- `13_Sources/Records/SRC-821ba21da94c21df60d729fd.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/jpm-20251231.htm
- `13_Sources/Records/SRC-989578e077b325a53283a75a.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/1652044/000165204426000066/0001652044-26-000066.txt
- `13_Sources/Records/SRC-9c13f4e336126491246ce357.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/jpm-20260630.htm
- `13_Sources/Records/SRC-a6776da28e9dbc899140e410.md` — tags: [sources, source-record]；source: https://data.sec.gov/submissions/CIK0001018724.json
- `13_Sources/Records/SRC-a67d23125031be722818082a.md` — tags: [sources, source-record]；source: https://data.sec.gov/submissions/CIK0000789019.json
- `13_Sources/Records/SRC-a7294589a5aaa86bbd9cc776.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/goog-20251231.htm
- `13_Sources/Records/SRC-c1ec319cd0b030514ec1e7fd.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/amzn-20260630.htm
- `13_Sources/Records/SRC-cdfdbabdeb7969a82d193e80.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/1018724/000101872426000024/0001018724-26-000024.txt
- `13_Sources/Records/SRC-df4f13151968a6aacad9041d.md` — tags: [sources, source-record]；source: https://data.sec.gov/api/xbrl/companyfacts/CIK0001045810.json
- `13_Sources/Records/SRC-e06ad19d0d6e580ca33905ef.md` — tags: [sources, source-record]；source: https://data.sec.gov/submissions/CIK0000019617.json
- `13_Sources/Records/SRC-e518cf203523282fcc91b24d.md` — tags: [sources, source-record]；source: https://data.sec.gov/api/xbrl/companyfacts/CIK0000789019.json
- `13_Sources/Records/SRC-eb223ffcdc5663a094a6b31e.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/amzn-20251231.htm
- `13_Sources/Records/SRC-ee4a8840d145293adfaac731.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/msft-20260630.htm
- `13_Sources/Records/SRC-fd41fbb8d4e31433b10eee67.md` — tags: [sources, source-record]；source: https://www.sec.gov/Archives/edgar/data/789019/000119312526323632/0001193125-26-323632.txt
- `14_Reports/Run History Index.md` — tags: [reports, index]；source: 待补充
- `15_System/AI Output Contract.md` — tags: [system]；source: 待补充
- `15_System/Build Notes and Limitations.md` — tags: [system]；source: 待补充
- `15_System/MCP Integration Contract.md` — tags: [system]；source: 待补充
- `15_System/Release History/Build Verification.md` — tags: [system, release-history]；source: 待补充
- `15_System/Release History/Obsidian Link Audit.md` — tags: [system, release-history]；source: 待补充
- `15_System/Release History/V11 Release Notes.md` — tags: [system, release-history]；source: 待补充
- `15_System/Release History/V11.1 Release Notes.md` — tags: [system, release-history]；source: 待补充
- `15_System/Release History/V11.2 Release Notes.md` — tags: [system, release-history]；source: 待补充
- `15_System/Release History/V11.2 Verification.md` — tags: [system, release-history]；source: 待补充
- `15_System/Release History/V11.3 Release Notes.md` — tags: [system, release-history]；source: 待补充
- `15_System/Release History/V11.3 Verification.md` — tags: [system, release-history]；source: 待补充
- `15_System/Release History/V11.4 Release Notes.md` — tags: [system, release-history]；source: 待补充
- `15_System/Release History/V11.4 Verification.md` — tags: [system, release-history]；source: 待补充
- `99_Automation/AI Adapter Setup.md` — tags: [automation]；source: 待补充
- `99_Automation/AI Analysis Prompt.md` — tags: [automation]；source: 待补充
- `99_Automation/Daily Update Workflow.md` — tags: [automation]；source: 待补充
- `99_Automation/Lite Opener.md` — tags: [automation]；source: 待补充
- `99_Automation/Local Scheduling.md` — tags: [automation]；source: 待补充
- `99_Automation/Prompts.md` — tags: [automation]；source: 待补充
