---
title: "Markets and Assets MOC — 市场与资产"
tags: [index, moc]
created: 2026-10-27
updated: 2026-10-27
source: "自动整理：按主题分组的入口（2026-10-27）"
---

# Markets and Assets MOC — 市场与资产

[[00_Index/Master Index|总索引]] · [[HOME|首页]]

美股指数与板块、美债与信用、大宗商品、美元与加密资产。

## 美股指数与市场结构

- [[01_Concepts/Index Weighting and Concentration|Index Weighting and Concentration 指数权重与集中度]]
- [[01_Concepts/Market Breadth|Market Breadth 市场广度]]
- [[01_Concepts/Passive Flows and ETFs|Passive Flows and ETFs 被动资金与ETF]]
- [[01_Concepts/Sector Rotation|Sector Rotation 板块轮动]]
- [[01_Concepts/Equity Risk Premium|Equity Risk Premium 股权风险溢价]]
- [[01_Concepts/Share Buybacks and Dividends|Share Buybacks and Dividends 回购与分红]]
- [[01_Concepts/Short Interest and Positioning|Short Interest and Positioning 持仓与空头]]
- [[01_Concepts/Risk-On Risk-Off|Risk-On Risk-Off 风险偏好]]
- [[01_Concepts/Priced In|Priced In 已被市场计入]]
- [[01_Concepts/Consensus and Expectations|Consensus and Expectations 市场一致预期]]
- [[01_Concepts/Asset Allocation and Diversification|Asset Allocation and Diversification 资产配置与分散]]
- [[03_Indicators/US Equity Indices|US Equity Indices 美国股指]]
- [[03_Indicators/Global Equity Indices|Global Equity Indices 全球股指]]
- [[03_Indicators/SOX Index|SOX Index 费城半导体指数]]

## 波动率与衍生品

- [[01_Concepts/Market Volatility and Options Positioning|Market Volatility and Options Positioning 波动率与期权持仓]]
- [[01_Concepts/Options and Implied Move|Options and Implied Move 期权与隐含波动]]
- [[01_Concepts/Derivatives Basics|Derivatives Basics 衍生品基础]]
- [[03_Indicators/VIX|VIX 恐慌指数]]
- [[03_Indicators/MOVE Index|MOVE Index 美债波动率指数]]

## 美股板块

- [[08_Sectors/US Sectors Map|US Sectors Map 美国11大板块]]
- [[08_Sectors/US Big Tech|US Big Tech 美国大型科技股]]
- [[08_Sectors/Semiconductors|Semiconductors 半导体]]
- [[08_Sectors/AI Value Chain|AI Value Chain AI产业链]]
- [[08_Sectors/Cloud and Software|Cloud and Software 云与软件]]
- [[08_Sectors/US Banks|US Banks 美国银行业]]
- [[08_Sectors/Insurance and Asset Managers|Insurance and Asset Managers]]
- [[08_Sectors/Healthcare and Pharma|Healthcare and Pharma]]
- [[08_Sectors/Consumer Staples and Discretionary|Consumer Staples and Discretionary]]
- [[08_Sectors/Energy Oil and Gas|Energy Oil and Gas]]
- [[08_Sectors/Industrials and Defense|Industrials and Defense]]
- [[08_Sectors/Real Estate and REITs|Real Estate and REITs]]
- [[08_Sectors/Data Centers and Power|Data Centers and Power 数据中心与电力]]
- [[08_Sectors/Memory Chips|Memory Chips 存储芯片]]
- [[08_Sectors/Foundry and Advanced Packaging|Foundry and Advanced Packaging 晶圆代工与先进封装]]
- [[08_Sectors/Semiconductor Equipment|Semiconductor Equipment 半导体设备]]
- [[08_Sectors/Utilities|Utilities 公用事业]]
- [[08_Sectors/Materials|Materials 原材料]]

## 美债与利率市场

- [[01_Concepts/US Treasury Market|US Treasury Market 美国国债市场]]
- [[01_Concepts/Yield Curve|Yield Curve 收益率曲线]]
- [[01_Concepts/Duration and Convexity|Duration and Convexity 久期与凸性]]
- [[03_Indicators/US 10-Year Treasury Yield|US 10-Year Treasury Yield 美国10年期国债收益率]]
- [[03_Indicators/Treasury Auctions|Treasury Auctions 国债拍卖]]
- [[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]]

## 信用

- [[01_Concepts/Credit Spread|Credit Spread 信用利差]]
- [[03_Indicators/IG and HY Credit Spreads|IG and HY Credit Spreads 投资级与高收益信用利差]]

## 大宗商品

- [[01_Concepts/Commodity Prices|Commodity Prices 大宗商品价格]]
- [[01_Concepts/Gold|Gold 黄金]]
- [[03_Indicators/Gold Price|Gold Price 黄金价格]]
- [[03_Indicators/Copper Price|Copper Price 铜价]]
- [[03_Indicators/WTI and Brent Crude|WTI and Brent Crude 原油价格]]
- [[03_Indicators/Natural Gas Prices|Natural Gas Prices 天然气价格]]

## 科技与半导体数据

- [[03_Indicators/Hyperscaler Capex|Hyperscaler Capex 云巨头资本开支]]
- [[03_Indicators/Global Semiconductor Sales|Global Semiconductor Sales 全球半导体销售额]]
- [[03_Indicators/DRAM Contract Prices|DRAM Contract Prices DRAM 合约价]]
- [[03_Indicators/TSMC Monthly Revenue|TSMC Monthly Revenue 台积电月度营收]]
- [[03_Indicators/Korea Semiconductor Exports|Korea Semiconductor Exports 韩国半导体出口]]
- [[03_Indicators/KOSPI|KOSPI 韩国综合股价指数]]
- [[01_Concepts/Korea Market and KOSPI|Korea Market and KOSPI 韩国市场与KOSPI]]

## 加密资产

- [[01_Concepts/Crypto Assets Overview|Crypto Assets Overview 加密资产概览]]
- [[01_Concepts/Crypto and Macro Linkages|Crypto and Macro Linkages 加密资产与宏观的联系]]
- [[01_Concepts/Crypto Leverage and Liquidations|Crypto Leverage and Liquidations 加密市场的杠杆与强平]]
- [[01_Concepts/Crypto Market Structure and Venues|Crypto Market Structure and Venues 加密市场结构与交易场所]]
- [[01_Concepts/Spot Bitcoin ETFs and Flows|Spot Bitcoin ETFs and Flows 现货比特币ETF与资金流]]
- [[01_Concepts/Stablecoins|Stablecoins 稳定币]]
- [[03_Indicators/Bitcoin and Ether Price|Bitcoin and Ether Price 比特币与以太币价格]]
- [[03_Indicators/Crypto Funding Rate and Open Interest|Crypto Funding Rate and Open Interest 资金费率与未平仓合约]]
- [[03_Indicators/Spot Bitcoin ETF Flows|Spot Bitcoin ETF Flows 现货比特币ETF资金流]]
- [[03_Indicators/Stablecoin Supply|Stablecoin Supply 稳定币供应量]]

## 最新数据（带日期）

- [[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]

## 相关文件夹

- [[08_Sectors/Sectors MOC|Sectors MOC — 板块与行业]]
- [[21_US_Treasuries/US Treasuries MOC|US Treasuries MOC — 美债]]
- [[03_Indicators/Indicators MOC|Indicators MOC — 经济与市场指标]]
