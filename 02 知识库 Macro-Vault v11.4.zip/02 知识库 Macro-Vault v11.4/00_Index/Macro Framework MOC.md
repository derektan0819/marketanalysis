---
title: "Macro Framework MOC — 宏观框架"
tags: [index, moc]
created: 2026-10-27
updated: 2026-10-27
source: "自动整理：按主题分组的入口（2026-10-27）"
---

# Macro Framework MOC — 宏观框架

[[00_Index/Master Index|总索引]] · [[HOME|首页]]

利率、通胀、就业、增长、财政、信贷、汇率与全球央行。先看概念，再看对应指标怎么读。

## 利率与美联储

- [[01_Concepts/Interest Rates|Interest Rates 利率]]
- [[01_Concepts/Fed and FOMC|Fed and FOMC 联储与FOMC]]
- [[01_Concepts/Monetary Policy|Monetary Policy 货币政策]]
- [[01_Concepts/Fed Balance Sheet|Fed Balance Sheet 联储资产负债表]]
- [[01_Concepts/QE and QT|QE and QT 量化宽松与量化紧缩]]
- [[01_Concepts/Market-Implied Rate Expectations|Market-Implied Rate Expectations 市场隐含的利率预期]]
- [[01_Concepts/Real Interest Rates|Real Interest Rates 实际利率]]
- [[01_Concepts/Term Premium|Term Premium 期限溢价]]
- [[01_Concepts/Liquidity|Liquidity 流动性]]
- [[03_Indicators/Federal Funds Rate|Federal Funds Rate 联邦基金利率]]
- [[03_Indicators/Fed Funds Futures|Fed Funds Futures 联邦基金利率期货]]
- [[03_Indicators/FOMC Projections Dot Plot|FOMC Projections Dot Plot 美联储点阵图]]

## 通胀

- [[01_Concepts/Inflation|Inflation 通货膨胀]]
- [[01_Concepts/Stagflation|Stagflation 滞胀]]
- [[03_Indicators/CPI|CPI 消费者物价指数]]
- [[03_Indicators/PCE Inflation|PCE Inflation PCE通胀]]
- [[03_Indicators/PPI|PPI 生产者物价指数]]

## 就业

- [[01_Concepts/Labor Market|Labor Market 劳动力市场]]
- [[03_Indicators/Nonfarm Payrolls|Nonfarm Payrolls 非农就业]]
- [[03_Indicators/Unemployment Rate|Unemployment Rate 失业率]]
- [[03_Indicators/JOLTS|JOLTS 职位空缺与劳动力流动调查]]
- [[03_Indicators/Jobless Claims|Jobless Claims 初请失业金人数]]
- [[03_Indicators/Employment Cost Index|Employment Cost Index 就业成本指数]]

## 增长、消费与周期

- [[01_Concepts/GDP|GDP 国内生产总值]]
- [[01_Concepts/Business Cycle and Recession|Business Cycle and Recession 经济周期与衰退]]
- [[01_Concepts/Inventory Cycle|Inventory Cycle 库存周期]]
- [[01_Concepts/Capex Cycle|Capex Cycle 资本开支周期]]
- [[01_Concepts/US Consumer and Housing|US Consumer and Housing 美国消费与房地产]]
- [[03_Indicators/US GDP Report|US GDP Report 美国GDP报告]]
- [[03_Indicators/Retail Sales|Retail Sales 零售销售]]
- [[03_Indicators/PMI|PMI 采购经理人指数]]
- [[03_Indicators/Consumer Confidence|Consumer Confidence 消费者信心]]
- [[03_Indicators/Housing Starts|Housing Starts 新屋开工]]
- [[03_Indicators/Case-Shiller Home Price Index|Case-Shiller Home Price Index 凯斯-席勒房价指数]]
- [[03_Indicators/Trade Balance|Trade Balance 贸易差额]]
- [[03_Indicators/Industrial Production and Capacity Utilization|Industrial Production and Capacity Utilization 工业生产与产能利用率]]
- [[03_Indicators/Durable Goods Orders|Durable Goods Orders 耐用品订单]]

## 财政与政府债务

- [[01_Concepts/Fiscal Policy|Fiscal Policy 财政政策]]
- [[01_Concepts/Sovereign Debt and Fiscal Sustainability|Sovereign Debt and Fiscal Sustainability 主权债务与财政可持续性]]
- [[21_US_Treasuries/Treasury Debt Ceiling and Payment Risk|债务上限、支付风险与财政可持续性]]
- [[03_Indicators/Federal Budget and Monthly Treasury Statement|Federal Budget and Monthly Treasury Statement 联邦预算与月度财政报表]]

## 信贷与金融稳定

- [[01_Concepts/Credit Markets|Credit Markets (High Yield and Private Credit) 信贷市场（高收益债与私募信贷）]]
- [[01_Concepts/Private Credit and Shadow Banking|Private Credit and Shadow Banking 私募信贷与影子银行]]
- [[17_Bank_Regulation/Bank Regulation Map|Bank Regulation Map 银行监管地图]]
- [[03_Indicators/Senior Loan Officer Survey|Senior Loan Officer Survey 高级信贷员调查]]

## 汇率与美元

- [[01_Concepts/Exchange Rate|Exchange Rate 汇率]]
- [[01_Concepts/FX Intervention and Currency Regimes|FX Intervention and Currency Regimes 汇率制度与外汇干预]]
- [[01_Concepts/FX Market Structure and Quoting|FX Market Structure and Quoting 外汇市场结构与报价]]
- [[01_Concepts/Foreign Exchange Reserves and Reserve Currencies|Foreign Exchange Reserves and Reserve Currencies 外汇储备与储备货币]]
- [[01_Concepts/Yen and Carry Trade|Yen and Carry Trade 日元与套息交易]]
- [[03_Indicators/DXY|DXY 美元指数]]
- [[03_Indicators/EUR-USD|EUR/USD 欧元兑美元]]
- [[03_Indicators/USD-JPY|USD/JPY 美元兑日元]]
- [[03_Indicators/USD-CNH|USD/CNH 美元兑离岸人民币]]
- [[03_Indicators/USD-MYR|USD/MYR 美元兑马来西亚令吉]]

## 全球央行与地区

- [[01_Concepts/Global Central Banks|Global Central Banks 全球主要央行]]
- [[01_Concepts/China Linkages to US Markets|China Linkages to US Markets 中国与美国市场的联系]]
- [[01_Concepts/Geopolitics and Export Controls|Geopolitics and Export Controls 地缘政治与出口管制]]
- [[01_Concepts/Trade Tariffs and Supply Chains|Trade, Tariffs and Supply Chains 贸易、关税与供应链]]
- [[01_Concepts/Sovereign Wealth Funds|Sovereign Wealth Funds 主权基金]]
- [[03_Indicators/China Official PMI and Activity Data|China Official PMI and Activity Data 中国官方PMI与活动数据]]
- [[03_Indicators/Euro Area HICP|Euro Area HICP 欧元区调和CPI]]
- [[03_Indicators/Japan CPI and Tankan|Japan CPI and Tankan 日本CPI与短观]]
- [[19_Regions/Regions Guide|Regions 全球区域]]

## 最新数据（带日期）

- [[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]
- [[12_Data/US Release Calendar 2026-10-27|美国数据与财报发布日历 2026-10-27]]

## 相关文件夹

- [[01_Concepts/Concepts MOC|Concepts MOC — 概念]]
- [[03_Indicators/Indicators MOC|Indicators MOC — 经济与市场指标]]
- [[19_Regions/Regions MOC|Regions MOC — 地区]]
- [[17_Bank_Regulation/Bank Regulation MOC|Bank Regulation MOC — 银行监管]]
