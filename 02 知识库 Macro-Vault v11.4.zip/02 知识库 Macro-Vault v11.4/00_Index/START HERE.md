---
title: "从这里开始 — Macro-Vault v11.4"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [start, v11]
version: "11.4"
---
# 从这里开始 — Macro-Vault v11.4

目标：让 AI 替你找资料、读财报、比较历季变化，交付一页结论与有条件的前瞻判断。你处理影响核心结论的例外。

## 1. 打开新版
解压 Macro-Vault-v11.4.zip，在 Obsidian 选择“打开文件夹作为仓库”，选择解压后的 Macro-Vault 文件夹。先读 [[AI START HERE]]、[[HOME]]、[[V11.4 Release Notes]]。
旧仓库先保留；不要直接覆盖你的个人笔记。把你自己的笔记复制到本仓库相应位置。20_Archive/v10 中保留部分旧原稿，只作历史追溯。

## 最直接的用法：把文件交给 AI

把本 ZIP 上传给能读取压缩包的 AI，并发送 [[AI START HERE]] 里的指令。若该 AI 不能解压，则解压后提供入口、协议、模板及目标公司的资料包与原文；不要默认它已经读到所有文件。
同一家公司继续研究时，把上次报告／结构化记录一起给它。只给新资料、不提供旧判断，AI 无法可靠比较“为什么改口”。
先看 [[Readable Report Example]] 理解新版格式；该例完全虚构，不是投资判断。

## 2. 先看已经生成的资料
进入 04_Companies 下的 NVDA、MSFT、AMZN、GOOGL、JPM：
- Latest Brief.md：本次资料状态、一页简报。
- TICKER - Data History.md：最近八个可用季度；缺失不补零。
- Financial Observations.csv：全部原始观察与计算输入索引。
- Current Thesis.md：持续维护的研究判断；单纯数据刷新不改动。配置 AI 后，首次／修正／撤回提案通过格式、引用与一致性检查会自动保存旧版本再更新。
- AI Research Packet.json：可交给 AI 的资料包，包含规则、数据、原文和截断说明。

本包带实际抓取结果；成功/失败及截止时间以 [[Build Verification]] 和看板为准。它不是实时行情终端。抓到文件并不代表 AI 已完整阅读。

## 3. 在 Mac 运行数据更新
需要 Python 3.10 或更新版本。打开终端，先输入 cd 和一个空格，把 Macro-Vault 文件夹拖进终端，按回车。
然后执行：
```bash
python3 99_Automation/engine/vault.py doctor
export SEC_USER_AGENT='YourName MacroVault your-real-email@example.com'
python3 99_Automation/engine/vault.py run
```
把示例姓名和邮箱换成你真实的应用识别及联系方式。该环境变量只对当前终端有效；自动运行时也需要设置。也可把相同识别信息填入 settings.json 的 sec_user_agent（不要填写任何密码/API key）。

仅更新一家：
```bash
python3 99_Automation/engine/vault.py run --tickers NVDA
python3 99_Automation/engine/vault.py audit
python3 99_Automation/engine/vault.py review
```
网络抓取有缓存，公开接口按约每秒四次以内访问，并在暂时失败时有限重试。检查到错误时保留明确状态，不编造数字。首次运行可能需数分钟。

## 4. 接上你使用的 AI
现在可以手动把某公司的 AI Research Packet.json 及 [[AI Analysis Prompt]] 交给能读取文件的 AI。要全自动，请看 [[AI Adapter Setup]]。
本包不包含你的 AI 账户、密钥、收费订阅或已登录会话。analysis_command 为空时，数据流程能运行，但不会假装已经完成 AI 阅读或给出前瞻结论。

## 5. 设置自动运行
确认单次 run 成功后，再用 [[Local Scheduling]] 在你的电脑或服务器安装定时运行。仅下载这个 ZIP 不会自动启动定时任务；电脑关机或睡眠也不会可靠运行。

## 能力边界
已实现：SEC 申报发现、来源留档、标准 XBRL 指标、季度处理、八季表、结构/算术校验、资料包、命令式 AI 连接、一页简报、看板、预测登记及可匹配财务指标的到期核对。
需要配置/继续接入：你的 AI 命令、公司 IR 与电话会来源、行业自定义指标、发布前共识、价格/估值/宏观市场数据。财报语义核验不会因下载成功而自动通过。
所有研究及预测保留证据和未知项；本包没有交易或下单功能。


## 点击路径

[[Today Dashboard|今日看板]] → 公司简报 → 人类可读的证据链接。八季表的数字可直接定位当次证据。
[[Obsidian Navigation Guide]] 说明图谱用法；[[V11.4 Verification]] 记录本版检查。仅下载或上传 ZIP 不会自动运行后台程序；规则文件也不能保证任意 AI 百分百服从。

## 美债知识怎样用

在 [[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] 按问题进入；给 AI 分析时读 [[10_Playbooks/US Treasury Research Playbook]]。纯美债研究可复制 [[05_Templates/US Treasury Research Sheet]] 记录来源。本版补知识、解释和关联，自动引擎仍需要另外接入市场数据才能有真实行情。
