---
title: "Knowledge Index — 原主题索引"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
tags: [home]
---
# Knowledge Index — 原主题索引

> **Operating rule:** This is a knowledge base, not a live data feed. No report is `Verified` merely because it reads fluently. Use [[Publication Gate]] before treating a report as final.

## Start here
- [[00_Index/Master Index|Master Index 总索引]] — 按主题浏览全部笔记（2026-10-27 新增）
- [[CLAUDE]] — research and evidence rules
- [[Source Registry]] — preferred authoritative sources
- [[Citation and Evidence Standard]] — what counts as evidence
- [[Publication Gate]] — final checks before a report is marked verified
- [[Data Dictionary and Schema]] — standard fields for financial data
- [[Earnings Read-Across Playbook]] — company earnings workflow
- [[Data Release Playbook]] · [[Fed Day Playbook]] · [[Daily 15-Minute Routine]]

## Research areas
- Concepts: [[Consensus and Expectations]], [[Guidance]], [[Priced In]], [[Read-Across]], [[Earnings Day Mechanics]], [[Interest Rates]], [[Inflation]], [[Fed and FOMC]], [[Yield Curve]], [[US Treasury Market]]
- Transmission: [[Earnings to Market Transmission]], [[Hyperscaler Capex to Chip Chain]], [[Fed Decision to Markets]], [[Treasury Yield to Equity Valuation]], [[Chip Earnings to AI Stocks]]
- Indicators: [[CPI]], [[PCE Inflation]], [[Nonfarm Payrolls]], [[JOLTS]], [[US GDP Report]], [[Retail Sales]], [[PMI]], [[Federal Funds Rate]], [[US 10-Year Treasury Yield]], [[VIX]], [[TSMC Monthly Revenue]], [[Global Semiconductor Sales]]
- Sectors: [[AI Value Chain]], [[Semiconductors]], [[Memory Chips]], [[Foundry and Advanced Packaging]], [[Data Centers and Power]], [[US Big Tech]], [[US Banks]]
- Fundamentals: [[Financial Statements]], [[GAAP vs Non-GAAP]], [[Earnings Quality]], [[Cash Flow and FCF]], [[Profitability Ratios]], [[Leverage and Coverage]], [[Valuation Multiples]], [[Bank Metrics]]
- Templates: [[Company Earnings Analysis]], [[Earnings Read-Across Analysis]], [[Macro Event Analysis]], [[Sector Analysis]], [[Daily Summary]], [[Weekly Summary]]

## Quality and future automation
- [[Data Dictionary and Schema]] — canonical fields and definitions
- [[Source Capture Template]] — source-level provenance
- [[Report Manifest Template]] — report-level metadata
- [[MCP Integration Contract]] — future tool integration requirements; no connector is assumed to exist
- [[QA Test Plan]] — expected behavior for missing, conflicting and invalid data

## Workflow status meanings
- `Draft`: generated or edited, not fully checked.
- `Needs Review`: one or more material checks failed or evidence conflicts.
- `Verified`: all required checks passed against recorded evidence; this is not a guarantee of future market outcomes.
- `Superseded`: replaced by a newer version; preserve the old record.

## Folder map
See [[CLAUDE]] for the full folder map. Use internal wikilinks for navigation and direct external citations for factual claims.

## Added in v3 / 新增内容
- Glossary: [[Glossary]] — bilingual terms 中英术语表
- New concepts 新概念: [[Business Cycle and Recession]], [[Stagflation]], [[Labor Market]], [[Real Interest Rates]], [[Term Premium]], [[Equity Risk Premium]], [[QE and QT]], [[Credit Markets]]
- New indicators 新指标: [[Housing Starts]], [[Case-Shiller Home Price Index]]
- New transmission 新传导链: [[Bank Capital Rules to Bank Earnings]]
- Bank regulation 银行监管 (17_Bank_Regulation): [[Bank Regulation Map]], [[Basel III and Capital Ratios]], [[Stress Tests and Capital Buffers]], [[Liquidity Rules LCR and NSFR]], [[Bank Runs and Deposit Insurance]], [[Dodd-Frank and Volcker Rule]], [[Securities Law Basics]], [[Secured Lending and Collateral]], [[Islamic Finance Basics]]
- Free-version prompt 免费版开场白: [[Lite Opener]], [[Prompts]]

## Also in the vault / 其他已有笔记
- Transmission: [[Rate Hike Transmission]], [[Jobs Report to Markets]]
- Concepts: [[Share Buybacks and Dividends]]
- Sectors: [[US Sectors Map]]
- Example: [[Worked Example Hyperscaler Capex Raise]]
- System: [[Build Notes and Limitations]]
- Malaysia (secondary 次要): [[Malaysia Guide]], [[OPR]], [[Malaysia Banking Sector]], [[Malaysia EE Exports]], [[Strong USD to Ringgit]], [[Malaysia Semiconductor Back-End]], [[US Tech to Malaysia Semiconductor Stocks]], [[Malaysia Bank Regulation and Islamic Finance]]
- Folder guides 文件夹说明: [[Inbox Guide]], [[Companies Guide]], [[Daily Guide]], [[Weekly Guide]], [[Data Guide]], [[Reports Guide]]

## Added in v4 / 新增内容
- Overall market view 整体市场分析: [[Market Overview Checklist]] (playbook), [[Market Overview Analysis]] (template)
- Global 全球: [[Global Central Banks]], [[Yen and Carry Trade]], [[China Linkages to US Markets]], [[Global Rates Spillover to US Markets]]
- Rate expectations 利率预期: [[Market-Implied Rate Expectations]], [[Fed Funds Futures]]
- Other: [[Gold]]
- Updated: [[Rate Hike Transmission]] (less absolute wording), [[Source Registry]] (global sources), [[Prompts]] (prompt 10)

## Added in v5 / 新增内容
- Korea 韩国: [[Korea Market and KOSPI]], [[KOSPI]], [[Korea Semiconductor Exports]], [[Korea Memory Stocks and US Chip Stocks]]
- Case study 案例: [[Case Study Samsung Q3 2026 Preliminary Earnings]] (status: Needs Review)
- Crypto 加密资产: [[Crypto Assets Overview]], [[Spot Bitcoin ETFs and Flows]], [[Stablecoins]], [[Crypto Leverage and Liquidations]], [[Crypto and Macro Linkages]], [[Spot Bitcoin ETF Flows]], [[Crypto Sentiment to US Equities]]
- Updated: [[Source Registry]] (Korea and crypto sources), [[Prompts]] (prompts 11 and 12), [[Market Overview Checklist]]

## Added in v6 / 新增内容
- Daily update with impact judgment 每日更新与影响判断: [[Daily Update Workflow]] (trigger `今日更新`), [[Daily Impact Update]] (template), [[Prediction Log]] (judgment tracking, trigger `复盘`)
- Worked example 示例日报: [[2026-10-16]] (status: Draft)
- Updated: [[CLAUDE]] (rules 13–16 on forward-looking judgments), [[Prompts]] (prompts 13 and 14), [[Daily Guide]], [[Data Guide]]
- Updated in v5.1: wording in several indicator notes made conditional; frontmatter added to six guide notes
- Daily report 日报: [[2026-10-19]] (Draft; first full run of the workflow, with three horizons for index, AI/semiconductors and banks)

## Added in v7 / 新增内容
- Wider coverage 更全面的覆盖: [[Cross-Asset Daily Coverage]] (FX, crypto, commodities, rates and global indices added to the daily update)
- Updated: [[Daily Update Workflow]], [[Daily Impact Update]], [[Source Registry]] (FX and commodity sources), [[Prompts]], [[CLAUDE]]
- Report [[2026-10-19]] now includes FX, crypto and commodities

## Added in v8 / 新增内容
- Cross-asset conclusion 跨资产结论: every daily and weekly conclusion now has a line for FX, crypto, commodities and global indices ([[Crypto and FX Daily Checklist]], [[Daily Impact Update]], [[Daily Summary]], [[Weekly Summary]], [[Lite Opener]])
- FX 外汇: [[FX Market Structure and Quoting]], [[FX Intervention and Currency Regimes]], [[EUR-USD]], [[USD-JPY]], [[USD-CNH]], [[USD-MYR]]
- Crypto 加密: [[Crypto Market Structure and Venues]], [[Bitcoin and Ether Price]], [[Crypto Funding Rate and Open Interest]], [[Stablecoin Supply]]
- Commodities and global indices 大宗商品与全球指数: [[Gold Price]], [[WTI and Brent Crude]], [[Global Equity Indices]]
- Transmission 传导链: [[Dollar and Real Yields to Gold and Crypto]], [[Yen Carry Unwind to Global Risk Assets]]
- Updated: [[CLAUDE]], [[Cross-Asset Daily Coverage]], [[Daily Update Workflow]], [[Prompts]] (prompt 15), [[Source Registry]], [[QA Test Plan]]; the six Malaysia notes now use the same 'Evidence and limitations' heading as other folders

## Added in v9 / 新增内容
- Your own videos 你自己加的视频: [[Video Guide]] (folder `18_Videos`), [[Video Note]] (template), [[Video Linking Playbook]] (how to link a video to the Vault and use both sides later), prompts 16 and 17 in [[Prompts]]
- Updated: [[CLAUDE]] (rules 17–19), [[Daily Update Workflow]], [[Inbox Guide]], [[Source Registry]], [[QA Test Plan]]

## Added in v10 / 新增内容 (global, non-Malaysia focus)
- Regions 区域: [[Regions Guide]], [[Euro Area and ECB]], [[United Kingdom and Bank of England]], [[Japan Economy and BoJ]], [[China Economy and Policy]], [[India Economy and Markets]], [[Emerging Markets Overview]], [[Middle East and Oil Exporters]]
- Concepts 概念: [[Sovereign Wealth Funds]], [[Foreign Exchange Reserves and Reserve Currencies]], [[Private Credit and Shadow Banking]], [[Duration and Convexity]], [[Asset Allocation and Diversification]], [[Derivatives Basics]], [[Market Volatility and Options Positioning]], [[Trade Tariffs and Supply Chains]], [[Sovereign Debt and Fiscal Sustainability]]
- Fundamentals 基本面: [[DCF and Cost of Capital]]
- Sectors 行业: [[Energy Oil and Gas]], [[Healthcare and Pharma]], [[Consumer Staples and Discretionary]], [[Industrials and Defense]], [[Real Estate and REITs]], [[Insurance and Asset Managers]]
- Indicators 指标: [[Copper Price]], [[Natural Gas Prices]], [[IG and HY Credit Spreads]], [[MOVE Index]], [[Treasury Auctions]], [[Euro Area HICP]], [[China Official PMI and Activity Data]], [[Japan CPI and Tankan]], [[FOMC Projections Dot Plot]]
- Transmission 传导链: [[Tariffs to Prices and Earnings]], [[China Policy to Commodities and Asia]], [[Oil Revenue to Sovereign Funds and Global Assets]], [[Private Credit Stress to Banks and Markets]], [[Dollar Funding Stress to Emerging Markets]]
- Playbooks 流程: [[Global Central Bank Meeting Playbook]], [[Geopolitical Shock Playbook]], [[Market Selloff Playbook]], [[Weekly Review Routine]]
- Updated: [[CLAUDE]], [[Glossary]], [[Source Registry]], [[Prompts]] (prompt 18), [[QA Test Plan]], [[Cross-Asset Daily Coverage]]


当前操作入口见 [[HOME]]；旧 v3–v10 内容是版本历史。

## 美债完整学习与研究入口（v11.4）

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] 按主题连接 25 篇专题笔记、原有核心概念、[[10_Playbooks/US Treasury Research Playbook|AI 研究流程]] 与 [[05_Templates/US Treasury Research Sheet|取证表]]。先读债种与定价，再沿相关链接查找曲线、拍卖、资金市场、ETF、跨资产及 MYR 回报。

[[V11.4 Release Notes|本版变更]] · [[V11.4 Verification|本版验证]]
