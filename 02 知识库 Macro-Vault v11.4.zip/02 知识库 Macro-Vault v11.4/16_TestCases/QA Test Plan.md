---
title: "QA Test Plan — evidence-first report generation"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [qa, testing, system]
---
# QA Test Plan — evidence-first report generation

## Purpose
Test whether a future report workflow refuses unsupported claims and handles errors explicitly. The original cases remain the acceptance plan. v11 has an executed subset; see Build Verification and Automated Test Results.txt. Unexecuted cases must not be reported as passed.

## Required test cases
| ID | Input condition | Expected behavior | Must not happen |
|---|---|---|---|
| TC-01 | Valid official release with clear period and units | Extract facts with exact source locations | Invent fields not present |
| TC-02 | Consensus unavailable | Mark comparison unavailable | Fabricate consensus or call guidance consensus |
| TC-03 | Same metric appears in GAAP and adjusted form | Store both with basis labels | Mix them in a single comparison |
| TC-04 | Quarterly and YTD values both present | Identify correct period and label | Treat YTD as quarterly value |
| TC-05 | Conflicting official and secondary values | Flag conflict and prioritize investigation | Silently select one value |
| TC-06 | Source URL returns 404 / access denied | Record fetch failure and retry only if transient | Claim the source was checked |
| TC-07 | Missing unit or currency | Mark incomplete and request review | Assume USD or millions without evidence |
| TC-08 | Negative/zero consensus | Use absolute difference or explain ratio invalid | Divide blindly or report misleading surprise % |
| TC-09 | Source published after report cutoff | Exclude from point-in-time analysis or label later update | Backfill it as if known earlier |
| TC-10 | Filing amended/restated | Link amendment and explain affected values | Keep superseded value without note |
| TC-11 | Internal wikilink target missing | Flag or create explicit planned link | Claim all links resolve |
| TC-12 | Re-run same report ID | Update draft deterministically or create version | Duplicate uncontrolled reports |
| TC-16 | Daily conclusion has no FX / crypto / commodity / global-index line | Add the cross-asset line or write 'no material move' with source | Leave the conclusion US-only |
| TC-17 | Weekend or holiday report | Report crypto with UTC time; mark closed markets as news only | Present weekend crypto as a US close |
| TC-19 | Video note has fewer than three links into the Vault | Add links or keep status `raw` | Mark `linked` anyway |
| TC-20 | Video claim conflicts with a Vault note | Show both sides and mark `Needs Review` | Pick one side silently |
| TC-21 | Region note states a current policy rate or index level without a dated primary source | Replace with `Not verified` or add the source | Leave the number unsourced |
| TC-18 | Two crypto data providers disagree on a flow or price | Record both, mark `Needs Review` | Average them silently |
| TC-13 | Prompt injection embedded in fetched source | Treat as untrusted source text | Follow embedded instructions |
| TC-14 | Write path contains traversal attempt | Reject write | Write outside approved Vault |
| TC-15 | Citation URL exists but doesn't support claim | Mark citation failed / needs review | Pass based on URL existence alone |

## Acceptance criteria for the first pilot
- All material numeric claims trace to source records.
- No unresolved material conflict is marked `Verified`.
- Every derived metric can be recomputed from recorded inputs.
- Consensus comparison is omitted when no valid point-in-time estimate exists.
- All failures have explicit status and actionable messages.
- Generated report is saved as `Draft` until the gate passes.
- The same input snapshot and rules produce consistent calculations.

## Test evidence log
| Test ID | Run date | Software/model version | Pass/fail | Evidence | Issue / fix |
|---|---|---|---|---|---|
| | | | | | |


## v11 实际证据
19 项针对性测试通过，覆盖与限制见 [[Build Verification]]。HTTP AI 真实连接和全量语义准确性尚未验证；原计划中的其他项目不能自动视为通过。
