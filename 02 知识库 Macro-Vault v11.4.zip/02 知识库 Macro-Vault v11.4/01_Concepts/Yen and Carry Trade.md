---
title: "Yen and Carry Trade 日元与套息交易"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [日元, 套息交易, Carry Trade, USD/JPY]
tags: [concepts]
as_of: 2026-10
---
# Yen and Carry Trade 日元与套息交易

## Definition 定义
A carry trade borrows in a currency with low interest rates (historically often the yen) and invests in assets with higher returns. The profit depends on the rate gap and on the funding currency not rising sharply.
套息交易是借入低利率货币（历史上常是日元），投资于回报更高的资产。利润取决于利差，以及融资货币不要大幅升值。

## Mechanism and market impact 机制与市场影响
If the funding currency strengthens quickly, or the rate gap narrows, carry trades can be unwound: positions are sold to repay loans. This can cause sharp moves in currencies, equities and bonds at the same time. A sharp global sell-off in early August 2024 was widely linked, at least in part, to such unwinding; treat the exact causes as debated.
如果融资货币快速升值或利差收窄，套息交易可能被平仓：为还款而卖出持仓。这可能同时引发汇率、股票和债券的剧烈波动。2024年8月初的全球急跌被广泛认为至少部分与此类平仓有关；具体原因仍有争论。

## Example 例子 (illustrative 示意)
Hypothetical: the yen jumps against the dollar over a few days. Leveraged investors sell equities to cover yen loans, adding to a market decline.
假设：日元在几天内对美元大幅升值。杠杆投资者卖出股票以偿还日元贷款，加剧市场下跌。

## Common misconceptions 常见误区
- Carry trades are not only yen-based; other funding currencies exist.
- 套息交易不只涉及日元，还有其他融资货币。
- The size of carry positions cannot be observed precisely; avoid precise claims.
- 套息持仓的规模无法精确观察，避免下精确的结论。
- A yen move alone does not explain a stock sell-off; check other drivers.
- 仅凭日元变动不能解释股市下跌，要检查其他因素。

## Related 相关
[[Global Central Banks]], [[Exchange Rate]], [[Risk-On Risk-Off]], [[VIX]], [[Liquidity]], [[Global Rates Spillover to US Markets]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
