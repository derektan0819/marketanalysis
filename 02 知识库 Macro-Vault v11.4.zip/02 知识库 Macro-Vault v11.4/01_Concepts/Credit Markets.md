---
title: "Credit Markets (High Yield and Private Credit) 信贷市场（高收益债与私募信贷）"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [信贷市场, 高收益债, 私募信贷, High Yield, Private Credit]
tags: [concepts]
as_of: 2026-10
---
# Credit Markets (High Yield and Private Credit) 信贷市场（高收益债与私募信贷）

## Definition 定义
Investment-grade (IG) bonds are issued by borrowers rated BBB-/Baa3 or higher; high-yield (HY) bonds are rated below that and pay more for higher default risk. Leveraged loans are loans to heavily indebted companies. Private credit is lending by non-bank funds directly to companies.
投资级（IG）债券的发行人评级在 BBB-/Baa3 及以上；高收益（HY）债券评级更低，因违约风险更高而收益更高。杠杆贷款是向高负债公司发放的贷款。私募信贷是非银行基金直接向企业放贷。

## Mechanism and market impact 机制与市场影响
Credit spreads, default rates and issuance volume show how easy or hard it is for companies to borrow. Widening HY spreads and rising defaults signal stress that can spread to banks, equities and hiring. Private credit is less transparent, so stress can be harder to see.
信用利差、违约率和发债规模反映企业融资的难易。高收益债利差扩大和违约上升是压力信号，可能传导到银行、股市和招聘。私募信贷透明度较低，压力更难被发现。

## Example 例子 (illustrative 示意)
Hypothetical: HY spreads widen sharply while Treasury yields fall. This suggests investors are pricing higher default risk, not higher rates.
假设：高收益债利差大幅扩大，而国债收益率下降。这说明投资者定价的是更高的违约风险，而不是更高的利率。

## Common misconceptions 常见误区
- HY is not the same as 'junk to avoid'; the higher yield is compensation for risk, and risk can be well or poorly priced.
- 高收益债不等于“垃圾要回避”；更高的收益是风险补偿，风险定价可能合理也可能不合理。
- Private credit data is limited; avoid strong claims without a named source.
- 私募信贷数据有限，没有明确来源就不要下强结论。

## Related 相关
[[Credit Spread]], [[Liquidity]], [[Bank Metrics]], [[US Banks]], [[Risk-On Risk-Off]], [[Bank Regulation Map]]
2026-10-27 新增相关：[[Senior Loan Officer Survey]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
