---
title: "QE and QT 量化宽松与量化紧缩"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [量化宽松, 量化紧缩, QE, QT, Quantitative Easing]
tags: [concepts]
as_of: 2026-10
---
# QE and QT 量化宽松与量化紧缩

## Definition 定义
Quantitative easing (QE): a central bank buys bonds (such as Treasuries and mortgage-backed securities), creating bank reserves and lowering long-term yields. Quantitative tightening (QT): the central bank shrinks its holdings, usually by letting bonds mature without reinvesting (runoff).
量化宽松（QE）：央行购买债券（如国债和抵押贷款支持证券），创造银行准备金并压低长期收益率。量化紧缩（QT）：央行缩减持债，通常是让债券到期后不再续买（缩表）。

## Mechanism and market impact 机制与市场影响
QE tends to lower long-term yields, ease financial conditions and support risk assets through portfolio rebalancing and signaling. QT does the reverse, gradually reducing reserves and removing a buyer from the Treasury market. The size of the effect is debated.
QE 通常压低长期收益率、放松金融条件，并通过资产组合再平衡和信号作用支撑风险资产。QT 则相反，逐步减少准备金，并让国债市场少了一个买家。影响的大小存在争议。

## Example 例子 (illustrative 示意)
Hypothetical: the central bank announces it will slow its monthly runoff. Markets may read this as a less tight stance, even though the policy rate is unchanged.
假设：央行宣布放慢每月缩表规模。即使政策利率不变，市场也可能解读为立场不那么紧。

## Common misconceptions 常见误区
- QT is not the central bank selling all its bonds at once.
- QT 不是央行一次性卖光债券。
- Balance-sheet size and the policy rate are separate tools.
- 资产负债表规模和政策利率是两个独立工具。
- For the current status of the Fed's balance-sheet policy, check the latest FOMC statement.
- 美联储资产负债表政策的最新状态，请查看最新的 FOMC 声明。

## Related 相关
[[Fed Balance Sheet]], [[Monetary Policy]], [[Liquidity]], [[US Treasury Market]], [[Term Premium]], [[Fed and FOMC]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Supply Refunding and Buybacks|发行、季度再融资与财政部回购]]：不仅看发多少债，还要看期限、到期偿还与谁来承接。
- [[21_US_Treasuries/Treasury TGA Reserves and RRP|TGA、银行准备金与 ON RRP]]：发行美债怎样移动现金，取决于钱原来在哪里。

## 准备金与市场价格的限制

QT 到期不续作与主动卖债不是同一操作。美联储资产变化对准备金的影响，还要结合 TGA、ON RRP、流通现金等负债变化；不能把 QT 金额一比一当成从股票撤走的资金。具体现金路径见 [[21_US_Treasuries/Treasury TGA Reserves and RRP]]；财政部回购与 QE 的区别见 [[21_US_Treasuries/Treasury Supply Refunding and Buybacks]]。
