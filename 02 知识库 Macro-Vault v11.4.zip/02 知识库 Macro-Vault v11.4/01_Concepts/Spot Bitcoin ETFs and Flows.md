---
title: "Spot Bitcoin ETFs and Flows 现货比特币ETF与资金流"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [比特币ETF, 现货ETF, IBIT, ETF资金流]
tags: [concepts]
as_of: 2026-10
---
# Spot Bitcoin ETFs and Flows 现货比特币ETF与资金流

## Definition 定义
A spot Bitcoin ETF holds actual Bitcoin (with a custodian) and trades like a stock. The US SEC approved the first spot Bitcoin ETFs in January 2024; spot Ether ETFs followed later. Authorized participants create and redeem shares in response to demand.
现货比特币 ETF 持有真实的比特币（由托管机构保管），像股票一样交易。美国 SEC 于2024年1月批准了首批现货比特币 ETF，之后又有现货以太币 ETF。授权参与者根据需求创建和赎回份额。

## Mechanism and market impact 机制与市场影响
ETF inflows require the fund to buy Bitcoin, so flows are used as a sentiment and demand indicator. But flows reflect purchases that have already happened, and they can be a result of price moves as much as a cause. Some holders use ETFs in hedged strategies (for example, buying ETF shares and selling futures), which is not a directional bet. Different data providers report slightly different flow figures.
ETF 资金流入要求基金购买比特币，所以资金流常被用作情绪和需求指标。但资金流反映的是已经发生的买入，既可能是价格变动的原因，也可能是结果。一些持有人把 ETF 用在对冲策略中（例如买入 ETF 份额同时卖出期货），那不是方向性押注。不同数据提供方公布的资金流数字略有差异。

## Example 例子 (illustrative 示意)
Hypothetical: in a week of large inflows, the price does not rise. Reasons could include hedged buyers, offsetting selling elsewhere, or inflows following an earlier price rise.
假设：某周资金大量流入，价格却没有上涨。原因可能是对冲型买家、其他渠道的卖出抵消，或资金流入发生在此前的价格上涨之后。

## Common misconceptions 常见误区
- Inflows do not guarantee a price rise.
- 资金流入不保证价格上涨。
- ETF flows cover only part of the market, not offshore exchanges or other products.
- ETF 资金流只覆盖市场的一部分，不包括海外交易所和其他产品。
- A single day of flows is noisy; look at several sessions and the data source.
- 单日资金流噪音很大，要看多个交易日并注明数据来源。

## Related 相关
[[Crypto Assets Overview]], [[Spot Bitcoin ETF Flows]], [[Passive Flows and ETFs]], [[Crypto and Macro Linkages]], [[Risk-On Risk-Off]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
