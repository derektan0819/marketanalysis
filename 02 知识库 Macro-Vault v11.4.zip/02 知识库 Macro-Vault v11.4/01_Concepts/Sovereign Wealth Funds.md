---
title: "Sovereign Wealth Funds 主权基金"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [主权基金, 主权财富基金, SWF]
tags: [concepts, global]
as_of: 2026-10
---
# Sovereign Wealth Funds 主权基金

## Definition 定义
A sovereign wealth fund (SWF) is a state-owned investment fund, usually funded by commodity revenue, fiscal surpluses or foreign-exchange reserves, that invests mainly in foreign assets for the long term.
主权基金（SWF）是国家所有的投资基金，资金通常来自大宗商品收入、财政盈余或外汇储备，主要长期投资海外资产。

## Mechanism and market impact 机制与市场影响
- Types: stabilization funds (cushion budgets against commodity swings), savings funds for future generations, and development funds. 类型：稳定基金、代际储蓄基金、发展基金。
- Versus central-bank reserves: reserves are held for liquidity and currency defence and are conservative; SWFs seek returns over a long horizon and can hold equities, real estate and private assets. 与央行外汇储备不同：储备重视流动性和稳定，主权基金追求长期回报。
- Examples by name (sizes change, check each fund's own report): Norway's Government Pension Fund Global, China Investment Corporation, Abu Dhabi Investment Authority, GIC and Temasek in Singapore, Kuwait Investment Authority, Saudi Public Investment Fund, Qatar Investment Authority, and Khazanah Nasional in Malaysia. 例子仅列名称，规模以各基金年报为准。
- Market effect: they are large, patient buyers of bonds, equities, real estate and private deals, and can cushion selloffs, but their flows are hard to observe in real time. 市场影响：体量大、期限长，可缓冲抛售，但资金流难以实时观察。
- Link to oil: when oil revenue rises, more money is recycled into global assets ([[Oil Revenue to Sovereign Funds and Global Assets]]). 与油价联动：油价高时更多资金回流全球资产。
- Transparency varies; the voluntary Santiago Principles set disclosure and governance standards. 透明度不一，自愿性的圣地亚哥原则设有披露和治理标准。

## Related 相关
[[Foreign Exchange Reserves and Reserve Currencies]], [[Middle East and Oil Exporters]], [[Oil Revenue to Sovereign Funds and Global Assets]], [[Commodity Prices]], [[US Treasury Market]], [[Asset Allocation and Diversification]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- Ranking and size figures come from fund reports or aggregators such as SWFI and the International Forum of Sovereign Wealth Funds; they differ by method and date, so record the provider.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.
