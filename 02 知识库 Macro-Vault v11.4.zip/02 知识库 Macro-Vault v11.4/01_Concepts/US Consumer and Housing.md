---
title: "US Consumer and Housing 美国消费与房地产"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [美国消费与房地产]
tags: [concepts]
---
# US Consumer and Housing 美国消费与房地产

## Definition 定义
Consumer spending is roughly two-thirds of US GDP. Housing is the most rate-sensitive part of the consumer economy, with mortgage rates linked to long-term Treasury yields.
消费支出约占美国 GDP 的三分之二。房地产是消费经济中对利率最敏感的部分，抵押贷款利率与长期国债收益率挂钩。

## Market impact 市场影响
Weak consumers hurt retailers, restaurants, card lenders and banks' credit costs. High mortgage rates slow home sales and affect builders and related industries.
消费走弱会冲击零售、餐饮、信用卡贷款机构和银行的信贷成本；高抵押贷款利率会拖慢房屋销售，影响建筑商及相关行业。

## Related 相关
[[Retail Sales]], [[Consumer Confidence]], [[Consumer Spending to Retail and Credit]], [[US 10-Year Treasury Yield]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: higher mortgage rates reduce affordability and slow housing turnover, affecting related spending such as furniture and moving.
假设：抵押贷款利率上升，降低购房负担能力、减缓换房，影响家具、搬家等相关消费。

## Common misconceptions 常见误区
- Consumers are not uniform. High-income and low-income households behave differently, and averages hide this.
- 消费者不是铁板一块。高收入和低收入家庭的行为不同，平均数会掩盖这一点。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Cross Asset Transmission|美债怎样影响股票、银行、房产、美元和黄金]]：先找收益率变化的来源，再分别解释估值、经营与融资。
