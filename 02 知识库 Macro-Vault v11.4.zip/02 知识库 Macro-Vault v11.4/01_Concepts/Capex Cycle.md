---
title: "Capex Cycle 资本开支周期"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [资本开支周期]
tags: [concepts]
---
# Capex Cycle 资本开支周期

## Definition 定义
Phases when companies raise or cut their investment spending.
企业提高或削减投资支出的不同阶段。

## Market impact 市场影响
One firm's capex is another's revenue: cloud capex becomes chip, equipment and data-centre revenue. Rising capex lifts suppliers; cuts or 'digestion' periods hit them first.
一家公司的资本开支就是另一家公司的收入：云厂商的资本开支会变成芯片、设备和数据中心的收入。开支上升利好供应商；削减或“消化期”最先冲击供应商。

## Related 相关
[[Hyperscaler Capex]], [[Inventory Cycle]], [[AI Value Chain]]
2026-10-27 新增相关：[[Durable Goods Orders]]、[[Industrial Production and Capacity Utilization]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: a cloud company raises its annual capex plan. Chip, equipment and power suppliers may see order expectations rise before the spender's own profit changes.
假设：一家云公司上调年度资本开支计划。芯片、设备和电力供应商的订单预期可能先上升，而花钱的公司自己的利润还没变化。

## Common misconceptions 常见误区
- Higher capex is not automatically good for the spender: it cuts near-term free cash flow and only pays off if demand follows.
- 资本开支增加对花钱的公司不一定是好事：短期自由现金流下降，只有需求跟上才会回本。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
