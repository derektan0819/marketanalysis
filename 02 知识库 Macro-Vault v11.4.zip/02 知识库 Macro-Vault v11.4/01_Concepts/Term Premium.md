---
title: "Term Premium 期限溢价"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [期限溢价]
tags: [concepts]
as_of: 2026-10
---
# Term Premium 期限溢价

## Definition 定义
The extra yield investors demand for holding a long-term bond instead of rolling over short-term bonds. It is not directly observable and is estimated by models, so estimates differ by provider.
投资者持有长期债券（而不是不断滚动短期债券）所要求的额外收益。它无法直接观察，由模型估算，不同机构的估算结果会不同。

## Mechanism and market impact 机制与市场影响
A rising term premium can push long-term yields up without any change in expected policy rates, tightening financial conditions and lowering equity valuations. Drivers can include inflation uncertainty, heavy Treasury supply and reduced central-bank bond holdings.
期限溢价上升可以在政策利率预期不变的情况下推高长期收益率，收紧金融条件并压低股票估值。驱动因素可能包括通胀不确定性、国债供给量大，以及央行持债减少。

## Example 例子 (illustrative 示意)
Hypothetical: the 10-year yield rises while the expected path of the policy rate is unchanged. This suggests a higher term premium rather than a change in rate expectations.
假设：10年期收益率上升，而政策利率的预期路径没变。这说明更可能是期限溢价上升，而不是利率预期改变。

## Common misconceptions 常见误区
- Do not quote a single term-premium estimate as fact; name the model and the date.
- 不要把单一的期限溢价估算当成事实，要注明模型和日期。
- A move in long yields is not always a term-premium story; separate expectations from premium.
- 长端收益率变动不一定是期限溢价的故事，要区分预期与溢价。

## Related 相关
[[Yield Curve]], [[US Treasury Market]], [[US 10-Year Treasury Yield]], [[Fed Balance Sheet]], [[QE and QT]], [[Real Interest Rates]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Yield Curve Scenarios|曲线变化：牛陡、熊陡、牛平、熊平]]：先看哪一端在动，再解释增长、通胀与供给。
- [[21_US_Treasuries/Treasury Real Yields and Breakevens|实际利率、盈亏平衡通胀和期限溢价]]：同样是 10 年收益率上涨，背后的原因可能完全不同。
- [[21_US_Treasuries/Treasury Supply Refunding and Buybacks|发行、季度再融资与财政部回购]]：不仅看发多少债，还要看期限、到期偿还与谁来承接。

## 避免重复分解

“预期短期名义利率＋期限溢价”与“实际收益率＋通胀补偿”是不同视角，不能把两组结果再全部相加。期限溢价不是屏幕上可直接成交的报价，模型可能估计为负且会修订。短期政策预期看似不动，也不能只凭长债上涨就排除流动性、测量或更远期预期的变化。详见 [[21_US_Treasuries/Treasury Real Yields and Breakevens]]。
