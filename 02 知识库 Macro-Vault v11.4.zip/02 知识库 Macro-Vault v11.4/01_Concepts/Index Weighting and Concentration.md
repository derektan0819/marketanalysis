---
title: "Index Weighting and Concentration 指数权重与集中度"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [指数权重与集中度]
tags: [concepts]
---
# Index Weighting and Concentration 指数权重与集中度

## Definition 定义
The S&P 500 is weighted by float-adjusted market value, so larger companies move the index more. The Nasdaq-100 is also cap-weighted; the Dow is price-weighted across 30 stocks.
标普 500 按自由流通市值加权，市值越大的公司对指数影响越大；纳斯达克 100 同样按市值加权；道琼斯是 30 只股票的价格加权。

## Market impact 市场影响
A company's contribution to the index is roughly its weight times its return. A handful of mega-cap companies hold a large share of index weight (verify current figures), so their earnings can move the whole market.
一家公司对指数的贡献大约是权重乘以涨跌幅。少数超大市值公司占据很高的指数权重（请核实最新数据），因此它们的财报可以带动整个市场。

## Related 相关
[[US Equity Indices]], [[Passive Flows and ETFs]], [[Mega-Cap Earnings to Index]], [[Market Breadth]]

## Example 例子 (illustrative 示意，非真实数据)
In a cap-weighted index, a few mega-cap stocks can dominate the index return on a given day.
在市值加权指数中，少数超大市值股票可能主导某一天的指数涨跌。

## Common misconceptions 常见误区
- 'The S&P 500 is up' does not mean most stocks are up. Check breadth or an equal-weight comparison.
- “标普500上涨”不代表多数股票上涨。要看市场广度或等权重指数作对比。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
