---
title: "Credit Spread 信用利差"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [信用利差]
tags: [concepts]
---
# Credit Spread 信用利差

## Definition 定义
The extra yield on corporate bonds or loans over government bonds, compensating for default risk.
企业债券或贷款相对政府债券多出的收益率，用来补偿违约风险。

## Market impact 市场影响
Widening spreads signal rising stress and tighter financing conditions; banks tend to raise provisions and tighten lending.
利差扩大代表压力上升、融资条件收紧；银行往往提高拨备并收紧放贷。

## Related 相关
[[Yield Curve]], [[Liquidity]], [[Risk-On Risk-Off]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: when recession fears rise, the yield gap between corporate bonds and Treasuries widens as investors demand more compensation for default risk.
假设：衰退担忧上升时，企业债与国债的收益率差扩大，因为投资者要求更多违约风险补偿。

## Common misconceptions 常见误区
- Spread widening is not the same as yields rising: Treasury yields can fall while spreads widen.
- 利差扩大不等于收益率上升：国债收益率可能下降，而利差同时扩大。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
