---
title: "Guidance 管理层指引"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [管理层指引]
tags: [concepts]
---
# Guidance 管理层指引

## Definition 定义
Management's forecast for upcoming revenue, margins, spending and demand.
管理层对未来收入、利润率、支出和需求的预测。

## Market impact 市场影响
Guidance often moves a stock more than the quarter just reported, and it drives read-across to suppliers and peers. For chip companies, demand and capex commentary matter most.
指引往往比刚公布的季度更能推动股价，并传导到供应商和同行。对芯片公司，需求和资本开支的评论最关键。

## Related 相关
[[Consensus and Expectations]], [[Read-Across]], [[Capex Cycle]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: a company beats the current quarter but guides next quarter below consensus. The stock can fall because the market prices the future.
假设：公司当季超预期，但下季度指引低于一致预期。股价仍可能下跌，因为市场定价的是未来。

## Common misconceptions 常见误区
- Guidance is management's view, not consensus, and it may be set conservatively. Compare it with a timestamped consensus.
- 指引是管理层的看法，不是一致预期，而且可能偏保守。要与有时间戳的一致预期对比。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
