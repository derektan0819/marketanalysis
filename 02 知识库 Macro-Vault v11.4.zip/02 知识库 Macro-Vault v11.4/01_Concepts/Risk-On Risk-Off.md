---
title: "Risk-On Risk-Off 风险偏好"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [风险偏好]
tags: [concepts]
---
# Risk-On Risk-Off 风险偏好

## Definition 定义
Shifts in investor mood between seeking higher-risk assets (risk-on) and fleeing to safe assets (risk-off).
投资者情绪在追逐高风险资产（risk-on）与逃向避险资产（risk-off）之间切换。

## Market impact 市场影响
Risk-off typically lifts the USD, US Treasuries and gold, and pressures equities, credit and emerging markets. Risk-on does the reverse.
避险情绪通常推高美元、美国国债和黄金，并压制股票、信用债和新兴市场；风险偏好上升则相反。

## Related 相关
[[Exchange Rate]], [[Credit Spread]], [[VIX]], [[Liquidity]]

## Example 例子 (illustrative 示意，非真实数据)
In risk-off periods, investors often sell equities and credit and buy Treasuries, the dollar or gold.
避险（risk-off）时期，投资者常卖出股票和信用资产，买入国债、美元或黄金。

## Common misconceptions 常见误区
- Correlations are not fixed. Stocks and bonds can fall together when inflation is the main problem, as in 2022.
- 相关性不是固定的。当通胀是主要问题时，股票和债券可能一起下跌，2022年就是如此。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.


See also: [[Market Overview Checklist]], [[Yen and Carry Trade]], [[Gold]]

See also: [[Crypto and Macro Linkages]]

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Return Drivers and Portfolio Roles|美债回报来源、期限匹配与组合用途]]：利息、价格、再投资与汇率都要进入总回报。
