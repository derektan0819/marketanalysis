---
title: "Priced In 已被市场计入"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [已被市场计入]
tags: [concepts]
---
# Priced In 已被市场计入

## Definition 定义
When expected news is already reflected in the share price.
预期中的消息已经反映在股价里。

## Market impact 市场影响
Good news that merely meets very high expectations can produce a 'sell the news' fall. Markets trade the gap between reality and what is priced.
好消息若只是符合很高的预期，可能出现“利好出尽”式下跌。市场交易的是现实与已计价预期之间的差距。

## Related 相关
[[Consensus and Expectations]], [[Valuation Multiples]], [[Sector Rotation]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: a stock rallies ahead of a widely expected rate cut, then falls after the cut is announced ('sell the news').
假设：市场普遍预期降息，股价提前上涨，宣布降息后反而下跌（“利好出尽”）。

## Common misconceptions 常见误区
- 'Priced in' is unfalsifiable if used loosely. Point to evidence of expectations: futures, options, consensus.
- “已经反映在价格里”如果随便用就无法验证。要指出预期的证据：期货、期权、一致预期。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.


See also: [[Market-Implied Rate Expectations]]
