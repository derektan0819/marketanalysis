---
title: "Stagflation 滞胀"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [滞胀]
tags: [concepts]
as_of: 2026-10
---
# Stagflation 滞胀

## Definition 定义
A combination of weak growth, high inflation and often rising unemployment. The 1970s are the classic reference period.
增长疲弱、通胀高企、失业常常上升同时出现的状态。1970年代是经典参照期。

## Mechanism and market impact 机制与市场影响
It creates a policy dilemma: raising rates to fight inflation can deepen the slowdown, while cutting rates to support growth can fuel inflation. Stocks and bonds can both struggle, because higher inflation hurts bond values and weaker growth hurts earnings.
这造成政策两难：加息抑制通胀会加深放缓，降息支持增长又可能助长通胀。股票和债券可能同时承压，因为通胀损害债券价值，增长走弱损害盈利。

## Example 例子 (illustrative 示意)
Hypothetical: energy prices jump, inflation rises, and hiring slows at the same time. The central bank must weigh price stability against employment.
假设：能源价格飙升、通胀上升、招聘同时放缓。央行必须在物价稳定与就业之间权衡。

## Common misconceptions 常见误区
- High inflation alone is not stagflation; weak growth must be present too.
- 单有高通胀不是滞胀，还必须有增长疲弱。
- Stagflation is a scenario to monitor, not a label to apply to any bad data point.
- 滞胀是需要观察的情景，不能随便套在任何一个坏数据上。

## Related 相关
[[Inflation]], [[Monetary Policy]], [[Commodity Prices]], [[Business Cycle and Recession]], [[Labor Market]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
