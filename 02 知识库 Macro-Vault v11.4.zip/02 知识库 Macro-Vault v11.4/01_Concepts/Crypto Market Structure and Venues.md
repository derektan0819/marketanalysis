---
title: "Crypto Market Structure and Venues 加密市场结构与交易场所"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [加密市场结构, Crypto venues, 交易所, 永续合约]
tags: [concepts, crypto]
as_of: 2026-10
---
# Crypto Market Structure and Venues 加密市场结构与交易场所

## Definition 定义
Crypto trades on centralized exchanges, decentralized exchanges and, for Bitcoin and Ether in the US, through exchange-traded funds. Derivatives, mainly perpetual futures, are a large share of trading.
加密资产在中心化交易所、去中心化交易所交易；在美国，比特币和以太币也可通过交易所交易基金（ETF）持有。衍生品（主要是永续合约）占交易量很大一部分。

## Mechanism and market impact 机制与市场影响
- **24/7 trading** means weekend gaps in US-linked prices do not exist in crypto; news that arrives on a weekend is priced there first. 全天候交易，周末消息会先在加密市场反映。
- **Spot, ETF and futures prices differ** in time and level. An ETF trades only in US hours; its flows come from creations and redemptions ([[Spot Bitcoin ETFs and Flows]]). 现货、ETF 和期货的价格在时间和水平上不同。
- **Leverage and funding.** Perpetual futures use funding payments to track spot; crowded positions raise liquidation risk ([[Crypto Funding Rate and Open Interest]], [[Crypto Leverage and Liquidations]]). 杠杆和资金费率。
- **Custody and counterparty risk.** Exchange failures, hacks or stablecoin de-pegs are risks that equities do not have in the same form ([[Stablecoins]]). 托管和对手方风险。
- **Regulation varies by country and changes often.** Record the jurisdiction and the date of any rule. 各国监管不同且常变，须记录辖区和日期。

## Related 相关
[[Crypto Assets Overview]], [[Bitcoin and Ether Price]], [[Spot Bitcoin ETF Flows]], [[Stablecoin Supply]], [[Crypto and Macro Linkages]], [[Crypto Sentiment to US Equities]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Market structure, venue rankings and regulation change quickly; verify against current primary sources (regulators, issuers, exchanges). as_of: 2026-10.
- Data providers differ; record which one was used and the UTC time.
- Educational background, not investment advice.
