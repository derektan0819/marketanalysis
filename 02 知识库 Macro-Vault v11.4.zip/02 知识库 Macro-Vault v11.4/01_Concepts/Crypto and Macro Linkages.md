---
title: "Crypto and Macro Linkages 加密资产与宏观的联系"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [加密与宏观, 比特币与利率, 去美元化叙事]
tags: [concepts]
as_of: 2026-10
---
# Crypto and Macro Linkages 加密资产与宏观的联系

## Definition 定义
Hypothesized links between crypto prices and macro conditions: real interest rates and liquidity (tighter conditions can pressure speculative assets), the dollar, risk appetite (crypto sometimes trades with high-growth technology stocks) and regulatory or institutional developments such as ETF access.
关于加密资产价格与宏观环境之间联系的假设：实际利率和流动性（收紧的环境可能压制投机性资产）、美元、风险偏好（加密资产有时与高增长科技股同向波动）以及监管或机构层面的发展，例如 ETF 的出现。

## Mechanism and market impact 机制与市场影响
These links are not stable. In some periods crypto has moved with the Nasdaq; in others it has moved on crypto-specific events (leverage, exchanges, regulation). A 'debasement' or 'fiscal-dollar-weakness' narrative is sometimes used to explain buying, but it is an interpretation, not an established cause. Treat each explanation as one hypothesis and look for alternatives.
这些联系并不稳定。在某些时期加密资产与纳斯达克同向变动，在另一些时期则由加密行业自身的事件（杠杆、交易所、监管）驱动。有时会用“货币贬值”或“财政压力导致美元走弱”的叙事来解释买盘，但那是一种解读，不是已确立的原因。把每种解释当作一个假设，并寻找替代解释。

## Example 例子 (illustrative 示意)
Hypothetical: real yields rise and the Nasdaq falls the same day crypto falls. This is co-movement; it does not prove yields caused the crypto move. Check crypto-specific news and leverage data.
假设：实际收益率上升，纳斯达克和加密资产在同一天下跌。这只是同向变动，不能证明收益率导致了加密资产的下跌。要查看加密行业的特有消息和杠杆数据。

## Common misconceptions 常见误区
- Correlation is not constant; do not assume a hedge or a risk asset label always applies.
- 相关性不是恒定的；不要假设“对冲资产”或“风险资产”的标签永远适用。
- Narratives (such as 'digital gold') are explanations after the fact unless supported by data.
- 叙事（例如“数字黄金”）除非有数据支持，否则只是事后的解释。
- Same-day co-movement alone does not prove causation.
- 仅凭同一天同向变动不能证明因果关系。

## Related 相关
[[Crypto Assets Overview]], [[Real Interest Rates]], [[Liquidity]], [[DXY]], [[Risk-On Risk-Off]], [[Gold]], [[Market Overview Checklist]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
