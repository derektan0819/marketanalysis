---
title: "Global Central Banks 全球主要央行"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [全球央行, ECB, BOJ, PBoC, BoE]
tags: [concepts]
as_of: 2026-10
---
# Global Central Banks 全球主要央行

## Definition 定义
Besides the Federal Reserve, four central banks matter most for US markets. ECB (euro area): its deposit facility rate is its main policy rate signal. BOJ (Japan): kept ultra-low or negative rates and yield curve control for years, and began moving away from them in 2024; check current policy. BoE (UK): sets Bank Rate. PBoC (China): uses tools such as the Loan Prime Rate (LPR) and the reserve requirement ratio (RRR).
除美联储外，对美国市场影响最大的是四家央行。ECB（欧元区）：存款便利利率是其主要政策利率信号。BOJ（日本）：多年维持超低或负利率和收益率曲线控制，并从2024年起逐步退出，请核实当前政策。BoE（英国）：设定基准利率（Bank Rate）。PBoC（中国）：使用贷款市场报价利率（LPR）和存款准备金率（RRR）等工具。

## Mechanism and market impact 机制与市场影响
Rate gaps between countries move currencies and capital flows. If other central banks raise rates while the Fed holds, the dollar may weaken and foreign demand for Treasuries can change. Global yields tend to move together, so a jump in foreign long-term yields can pull US yields up as well. See [[Global Rates Spillover to US Markets]].
各国利率差会推动汇率和资金流向。如果其他央行加息而美联储不动，美元可能走弱，外国对美国国债的需求也可能改变。全球收益率往往同向变动，所以海外长期收益率大涨可能带动美国收益率上升。见 [[Global Rates Spillover to US Markets]]。

## Example 例子 (illustrative 示意)
Hypothetical: the BOJ signals faster tightening while US rates are steady. The yen strengthens, and investors who borrowed in yen to buy higher-yielding assets may reduce positions (see [[Yen and Carry Trade]]).
假设：日本央行释放更快收紧的信号，而美国利率不变。日元走强，借日元买入高收益资产的投资者可能减仓（见 [[Yen and Carry Trade]]）。

## Common misconceptions 常见误区
- US-focused does not mean US-only; foreign policy shifts can matter for the dollar, Treasuries and risk appetite.
- 以美国为主不代表只看美国；海外政策变化会影响美元、美债和风险偏好。
- Do not assume all central banks move in step; their cycles differ.
- 不要假设所有央行步调一致，它们的周期不同。
- Policy details change; always verify the latest official statement.
- 政策细节会变，务必核实最新官方声明。

## Related 相关
[[Monetary Policy]], [[Fed and FOMC]], [[Exchange Rate]], [[DXY]], [[Yen and Carry Trade]], [[China Linkages to US Markets]], [[Global Rates Spillover to US Markets]], [[Interest Rates]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
