---
title: "Interest Rates 利率"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [利率]
tags: [concepts]
---
# Interest Rates 利率

## Definition 定义
The price of borrowing money: set by central banks (policy rates) and by markets (Treasury yields, loan rates).
借钱的价格：由央行（政策利率）和市场（国债收益率、贷款利率）共同决定。

## Market impact 市场影响
Higher rates raise borrowing costs, reduce the present value of future earnings, and usually support the currency. Lower rates do the opposite.
利率上升会提高借贷成本、降低未来盈利的现值，通常支撑货币；降息则相反。

## Related 相关
[[Monetary Policy]], [[Federal Funds Rate]], [[Yield Curve]], [[US Treasury Market]]

## Example 例子 (illustrative 示意，非真实数据)
A higher discount rate lowers the present value of far-away cash flows, so long-duration growth stocks tend to be more rate-sensitive.
贴现率上升会降低远期现金流的现值，所以久期长的成长股通常对利率更敏感。

## Common misconceptions 常见误区
- 'Rates up = stocks down' is not a law. It depends on why rates rise: stronger growth and higher inflation have different effects.
- “利率上升=股票下跌”不是定律。要看利率为什么上升：增长走强和通胀上升的影响不同。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Cash Flows and Bond Pricing|票息、价格、收益率与真实回报]]：解释为什么票息固定，市场价格却每天改变。
