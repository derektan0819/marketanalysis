---
title: "Market-Implied Rate Expectations 市场隐含的利率预期"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [利率预期, FedWatch, 联邦基金利率期货, 隐含概率]
tags: [concepts]
as_of: 2026-10
---
# Market-Implied Rate Expectations 市场隐含的利率预期

## Definition 定义
The path of future policy rates that markets are pricing, read from instruments such as federal funds futures, overnight index swaps and short-term Treasury yields. Tools such as CME FedWatch convert futures prices into implied probabilities of rate changes (verify the tool and its current method).
市场定价所反映的未来政策利率路径，可从联邦基金利率期货、隔夜指数掉期和短期国债收益率等工具中读出。CME FedWatch 等工具把期货价格转换成加息或降息的隐含概率（请核实工具及其最新方法）。

## Mechanism and market impact 机制与市场影响
'Priced in' needs evidence, and this is the main evidence for rates. Compare the implied path with the Fed's own projections (the dot plot). After a data release or a Fed meeting, check how the implied path changed: the change, not the level, is the market's surprise. The 2-year yield is a quick proxy for the expected policy path.
“已被定价”需要证据，对利率来说这就是主要证据。把隐含路径与美联储自己的预测（点阵图）对比。数据或议息会议之后，看隐含路径如何变化：变化而不是水平才是市场的意外。2年期收益率是预期政策路径的快速参考。

## Example 例子 (illustrative 示意)
Illustrative: a federal funds futures contract is quoted as 100 minus the expected average policy rate for the month. A price of 95.75 implies an expected rate of about 4.25%. If the price rises to 95.90 after weak data, the implied rate falls to about 4.10%, so the market now expects a lower path.
示意：联邦基金利率期货的报价是100减去该月预期平均政策利率。价格95.75意味着预期利率约4.25%。如果数据疲弱后价格升到95.90，隐含利率降到约4.10%，说明市场现在预期的路径更低。

## Common misconceptions 常见误区
- Implied probabilities are not forecasts or the Fed's intentions; they include risk premia and can change within hours.
- 隐含概率不是预测，也不是美联储的意图；它包含风险溢价，几小时内就可能变化。
- A 90% implied chance of a cut can still end in no cut.
- 隐含90%的降息概率，结果仍可能没有降息。
- Always record the tool, the timestamp and the meeting date.
- 一定要记录所用工具、时间和对应的会议日期。

## Related 相关
[[Priced In]], [[Fed and FOMC]], [[Fed Decision to Markets]], [[Fed Day Playbook]], [[Fed Funds Futures]], [[Federal Funds Rate]], [[Interest Rates]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Yield Curve Scenarios|曲线变化：牛陡、熊陡、牛平、熊平]]：先看哪一端在动，再解释增长、通胀与供给。
