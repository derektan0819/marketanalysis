---
title: "Stablecoins 稳定币"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [稳定币, Stablecoin, USDT, USDC]
tags: [concepts]
as_of: 2026-10
---
# Stablecoins 稳定币

## Definition 定义
Stablecoins are tokens designed to keep a stable value, usually one US dollar. Many are backed by reserve assets such as cash and short-term US Treasury bills. They are the main payment and trading currency inside crypto markets and a link between crypto and the traditional financial system.
稳定币是旨在保持稳定价值（通常是1美元）的代币。许多由现金和短期美国国债等储备资产支持。它们是加密市场内部主要的支付和交易货币，也是加密市场与传统金融体系之间的纽带。

## Mechanism and market impact 机制与市场影响
Issuers that hold Treasury bills are buyers of short-term US government debt, so large stablecoin growth can matter for the Treasury market. Risks include loss of the peg, poor reserve quality and redemption runs, which resemble bank-run dynamics (see [[Bank Runs and Deposit Insurance]]). The US passed a federal stablecoin law in 2025 (the GENIUS Act); verify the current status and implementing rules.
持有国库券的发行人是短期美国国债的买家，所以稳定币的大幅增长可能影响国债市场。风险包括脱锚、储备质量差和赎回挤兑，这与银行挤兑的机制相似（见 [[Bank Runs and Deposit Insurance]]）。美国在2025年通过了联邦稳定币法律（GENIUS Act）；请核实其现状和实施细则。

## Example 例子 (illustrative 示意)
Hypothetical: a stablecoin issuer's reserves are questioned, holders rush to redeem, and the issuer must sell reserve assets quickly. If reserves are short-term Treasuries, large sales could add pressure to that market.
假设：某稳定币发行人的储备被质疑，持有人争相赎回，发行人必须快速出售储备资产。如果储备是短期国债，大规模出售可能给该市场带来压力。

## Common misconceptions 常见误区
- 'Stable' does not mean risk-free: stablecoins have lost their pegs in the past.
- “稳定”不等于无风险：稳定币过去发生过脱锚。
- Not all stablecoins have the same reserves or legal structure; check each issuer's disclosures.
- 并非所有稳定币的储备或法律结构都相同，要看各发行人的披露。
- A stablecoin is not an insured bank deposit.
- 稳定币不是受保险的银行存款。

## Related 相关
[[Crypto Assets Overview]], [[US Treasury Market]], [[Liquidity]], [[Bank Runs and Deposit Insurance]], [[Bank Regulation Map]], [[Securities Law Basics]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
