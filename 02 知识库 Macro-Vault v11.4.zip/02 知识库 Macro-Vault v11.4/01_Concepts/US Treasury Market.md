---
title: "US Treasury Market 美国国债市场"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [美国国债市场]
tags: [concepts]
---
# US Treasury Market 美国国债市场

## Definition 定义
The market for US government debt and the global benchmark for risk-free rates. Treasuries are auctioned to finance deficits, refinance maturing debt and manage cash needs.
美国政府债券市场，是全球无风险利率的基准。国债通过拍卖发行，用于赤字融资、到期债务再融资及现金管理等需要。

## Market impact 市场影响
Treasury yields are a benchmark component of many discount and borrowing rates. Supply, demand and risk compensation can move them; credit, liquidity and other spreads also matter. Safe-haven demand may lower yields, but cash stress can trigger sales.
美债收益率是许多折现率和借贷利率的基准组成部分，还须加上信用、流动性等溢价。供给增加或需求偏弱可能抬高收益率，结果取决于市场预期与承接。避险需求可能压低收益率，但现金紧张也可能导致美债被卖出。

## Related 相关
[[US 10-Year Treasury Yield]], [[Yield Curve]], [[Fiscal Policy]], [[Treasury Yield to Equity Valuation]]

## Example 例子 (illustrative 示意，非真实数据)
The Treasury yield is the base 'risk-free' rate used to price many other assets, so a change in it moves valuations broadly.
国债收益率是为许多其他资产定价的基础“无风险”利率，它的变化会广泛影响估值。

## Common misconceptions 常见误区
- 'Risk-free' is a valuation benchmark convention, not a guarantee against every risk. Fixed-cash-flow Treasury prices move inversely to their yields.
- “无风险”是常用定价基准的表述，不代表信用或支付风险绝对为零，更不消除价格、通胀和汇率风险。固定现金流美债的价格与自身收益率反向变动。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Security Types|美债有哪些种类]]：先认清买的是什么，避免把短债、长债和 TIPS 当成同一种资产。
- [[21_US_Treasuries/Treasury Cash Flows and Bond Pricing|票息、价格、收益率与真实回报]]：解释为什么票息固定，市场价格却每天改变。
- [[21_US_Treasuries/Treasury Holders and TIC|谁持有美债：TIC 与买家结构]]：持仓减少未必等于抛售，间接投标者也不等于外国政府。
