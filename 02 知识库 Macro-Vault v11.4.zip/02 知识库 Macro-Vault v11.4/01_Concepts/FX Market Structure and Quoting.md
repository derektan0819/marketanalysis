---
title: "FX Market Structure and Quoting 外汇市场结构与报价"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [外汇市场结构, FX quoting, 货币对报价]
tags: [concepts, fx]
as_of: 2026-10
---
# FX Market Structure and Quoting 外汇市场结构与报价

## Definition 定义
A currency pair is written BASE/QUOTE. EUR/USD = 1.10 means one euro costs 1.10 US dollars. If the number rises, the base currency strengthens and the quote currency weakens. For USD/JPY, a rise means a stronger dollar and a weaker yen.
货币对写作 基础货币/报价货币。EUR/USD = 1.10 表示一欧元等于 1.10 美元。数字上升表示基础货币走强、报价货币走弱。USD/JPY 上升表示美元走强、日元走弱。

## Mechanism and market impact 机制与市场影响
- **Hours.** Spot FX trades around the clock on weekdays across Asian, European and US sessions, and is closed over the weekend. Crypto, by contrast, trades every day. 现货外汇在工作日全天交易，周末休市；加密货币则每天交易。
- **No single price.** There is no central exchange. Quotes differ by dealer and time; benchmarks such as central-bank reference rates and the London 4 p.m. fix are snapshots, not live prices. 外汇没有统一交易所，各银行报价不同；央行参考汇率和伦敦下午四点定盘价只是时点快照。
- **Pairs, not 'the dollar'.** DXY is a basket in which the euro is by far the largest weight, so it is not the same as the dollar against every currency. 要说明具体货币对；DXY 中欧元权重最大。
- **Rate gap drives much of the move.** Higher relative interest rates tend to attract capital, but risk sentiment, energy prices and policy intervention can override this. 利差是重要驱动，但风险情绪、能源价格和政策干预可能压过它。
- **Spot and forward.** Forward prices reflect the interest-rate gap between the two currencies; a forward premium is not a forecast. 远期价格反映两种货币的利差，不是预测。

## Related 相关
[[Exchange Rate]], [[DXY]], [[EUR-USD]], [[USD-JPY]], [[USD-CNH]], [[USD-MYR]], [[FX Intervention and Currency Regimes]], [[Global Central Banks]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Conventions here are general; check the data provider's own quote convention before using a number. as_of: 2026-10.
- Record pair, provider, UTC time and whether the figure is a quote or an official reference rate.
- Educational background, not trading advice.
