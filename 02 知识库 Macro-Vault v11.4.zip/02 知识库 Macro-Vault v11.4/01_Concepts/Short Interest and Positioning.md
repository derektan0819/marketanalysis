---
title: "Short Interest and Positioning 持仓与空头"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [持仓与空头]
tags: [concepts]
---
# Short Interest and Positioning 持仓与空头

## Definition 定义
Short interest is the amount of stock sold short. Positioning describes how crowded investors are on one side of a trade.
空头持仓是被卖空的股票数量；持仓描述投资者在某一方向上的拥挤程度。

## Market impact 市场影响
Crowded long positions can fall on good news that is not good enough. Heavy short positions can squeeze higher on mild good news.
拥挤的多头可能因“不够好”的好消息而下跌；大量空头可能因温和的好消息而被迫回补、推高股价。

## Related 相关
[[Priced In]], [[Options and Implied Move]], [[Passive Flows and ETFs]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: a heavily shorted stock gets good news, and short sellers buying back shares can amplify the rise (a short squeeze).
假设：被大量做空的股票出现利好，空头回补买入会放大涨幅（轧空）。

## Common misconceptions 常见误区
- High short interest does not guarantee a squeeze; it may reflect valid negative views, and the data is published with a delay.
- 空头持仓高不保证会轧空，可能只是反映合理的看空观点，而且数据公布有延迟。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
