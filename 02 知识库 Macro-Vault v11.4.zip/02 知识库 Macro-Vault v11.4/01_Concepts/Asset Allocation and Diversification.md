---
title: "Asset Allocation and Diversification 资产配置与分散"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [资产配置, 分散投资, Portfolio, Diversification]
tags: [concepts, portfolio]
as_of: 2026-10
---
# Asset Allocation and Diversification 资产配置与分散

## Definition 定义
Asset allocation is how a portfolio is split among asset classes such as equities, bonds, cash, commodities, real assets and alternatives. Diversification means holding assets that do not all move together.
资产配置是把组合分配到股票、债券、现金、大宗商品、实物资产和另类资产。分散投资是持有不会同涨同跌的资产。

## Mechanism and market impact 机制与市场影响
- Strategic allocation sets long-run weights from goals and risk tolerance; tactical changes are short-term deviations. 战略配置按目标和风险承受度设定长期权重，战术调整是短期偏离。
- Correlations are not fixed: assets that diversify in calm markets can fall together in a crisis, and the stock-bond relationship has changed over time ([[Risk-On Risk-Off]], [[Equity Risk Premium]]). 相关性会变，危机中常一起下跌。
- Rebalancing returns the portfolio to target weights; it forces selling what rose and buying what fell. 再平衡使组合回到目标权重。
- Look-through exposure: funds and ETFs can hide concentration in a few stocks or one currency ([[Index Weighting and Concentration]], [[Passive Flows and ETFs]]). 要看穿基金，注意集中度和货币暴露。
- Institutions such as sovereign funds and pension funds apply the same ideas at large scale ([[Sovereign Wealth Funds]]). 主权基金和养老金同样使用这些方法。

## Related 相关
[[Equity Risk Premium]], [[Risk-On Risk-Off]], [[Passive Flows and ETFs]], [[Sovereign Wealth Funds]], [[Derivatives Basics]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- This is general education about method, not a recommendation for any allocation. Past correlations and returns do not guarantee future ones.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury DV01 and Key Rate Duration|久期进阶：DV01 与不同期限的风险]]：把利率变动换成大致金额，并识别曲线并非一起移动。
- [[21_US_Treasuries/Treasury Funds and Direct Bonds|单只美债、美债 ETF 与现金工具]]：“持有到期”不能原封不动套在普通债券基金上。
- [[21_US_Treasuries/Treasury Return Drivers and Portfolio Roles|美债回报来源、期限匹配与组合用途]]：利息、价格、再投资与汇率都要进入总回报。
