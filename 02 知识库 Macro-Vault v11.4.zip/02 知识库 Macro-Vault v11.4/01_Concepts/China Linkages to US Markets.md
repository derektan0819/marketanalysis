---
title: "China Linkages to US Markets 中国与美国市场的联系"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [中国, 中美, 美中贸易]
tags: [concepts]
as_of: 2026-10
---
# China Linkages to US Markets 中国与美国市场的联系

## Definition 定义
China affects US markets mainly through four channels: trade and tariffs, revenue and supply-chain exposure of US companies, commodity demand, and technology restrictions (see [[Geopolitics and Export Controls]]). Policy at the PBoC and in Beijing can also change global growth expectations.
中国主要通过四个渠道影响美国市场：贸易与关税、美国公司的收入和供应链敞口、大宗商品需求，以及技术限制（见 [[Geopolitics and Export Controls]]）。中国央行和政府的政策也会改变全球增长预期。

## Mechanism and market impact 机制与市场影响
Check a company's disclosed revenue and supply exposure to China rather than assuming. A stimulus announcement or weak Chinese data can move commodities, semiconductor and consumer stocks with large China sales. Tariff or export-control news affects some sectors much more than the broad index.
要查公司披露的对中国收入和供应链敞口，而不是想当然。刺激政策或中国数据疲弱，可能影响大宗商品，以及在中国销量大的芯片和消费股。关税或出口管制消息对个别行业的影响远大于对大盘。

## Example 例子 (illustrative 示意)
Hypothetical: a US chip company discloses that a meaningful share of revenue comes from China. New restrictions raise questions about that revenue, while a company with little exposure is less affected.
假设：某美国芯片公司披露有相当比例的收入来自中国。新的限制引发对这部分收入的疑问，而敞口很小的公司受影响较小。

## Common misconceptions 常见误区
- 'China news hits all US stocks' is too broad; exposure differs a lot by company.
- “中国消息会冲击所有美股”太笼统，各公司的敞口差别很大。
- Chinese data quality and release practices differ; record the source and caveats.
- 中国数据的质量和发布方式不同，要记录来源和局限。
- Policy changes quickly; verify the latest official statements.
- 政策变化快，请核实最新官方声明。

## Related 相关
[[Geopolitics and Export Controls]], [[Export Controls and Tariffs]], [[Commodity Prices]], [[Semiconductors]], [[Global Central Banks]], [[Trade Balance]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
