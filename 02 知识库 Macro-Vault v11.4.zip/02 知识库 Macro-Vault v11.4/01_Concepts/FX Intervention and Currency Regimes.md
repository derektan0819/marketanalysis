---
title: "FX Intervention and Currency Regimes 汇率制度与外汇干预"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [汇率制度, 外汇干预, FX intervention]
tags: [concepts, fx]
as_of: 2026-10
---
# FX Intervention and Currency Regimes 汇率制度与外汇干预

## Definition 定义
A currency regime is the rule a country uses to manage its exchange rate: free float, managed float, or fixed peg. Intervention is when a central bank or finance ministry buys or sells currency to influence the rate.
汇率制度是一国管理汇率的规则：自由浮动、管理浮动或固定盯住。干预是央行或财政部买卖货币来影响汇率。

## Mechanism and market impact 机制与市场影响
- Under a free float the market sets the rate; under a managed float the authority limits what it considers disorderly moves; under a peg it defends a fixed rate. 自由浮动由市场决定；管理浮动下当局抑制其认为无序的波动；盯住制下当局捍卫固定汇率。
- Intervention can slow or reverse a move for a time, but it does not change the underlying rate gap by itself, so effects may fade. 干预可暂时减缓或扭转走势，但不改变利差，效果可能消退。
- Authorities often use verbal warnings first. A warning is not an intervention; only an official report confirms one. 口头警告不等于干预，只有官方报告才能确认。
- China manages the onshore renminbi (CNY) against a daily reference rate; the offshore rate (CNH) is freer. 中国对在岸人民币（CNY）设有每日中间价，离岸（CNH）更自由。
- Malaysia's ringgit regime is described by Bank Negara Malaysia; confirm the current wording on its site. 令吉制度以马来西亚国家银行的说明为准，请查官网最新表述。

## Related 相关
[[FX Market Structure and Quoting]], [[Yen and Carry Trade]], [[USD-JPY]], [[USD-CNH]], [[USD-MYR]], [[Global Central Banks]], [[Exchange Rate]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Regimes and official policies change; verify against the central bank or finance ministry before relying on a statement. as_of: 2026-10.
- Do not state that intervention happened or will happen unless an official source says so; 'level X triggers intervention' is a market belief, not a fact.
- Educational background, not trading advice.
