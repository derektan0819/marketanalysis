---
title: "Geopolitics and Export Controls 地缘政治与出口管制"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [地缘政治与出口管制]
tags: [concepts]
---
# Geopolitics and Export Controls 地缘政治与出口管制

## Definition 定义
Government restrictions on technology exports, tariffs and sanctions.
政府对技术出口的限制、关税和制裁。

## Market impact 市场影响
Can shrink addressable markets for US chip and equipment makers, reroute supply chains across Asia and cause sudden repricing. Effects depend on scope, exemptions and timing.
可能缩小美国芯片和设备厂商的可触达市场、改变亚洲各地的供应链路径，并引发突然的重新定价。影响取决于范围、豁免和时间。

## Related 相关
[[Export Controls and Tariffs]], [[Semiconductor Equipment]], [[AI Value Chain]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: new limits on selling advanced chips to a country shrink the addressable market for chip makers, to the extent they earn revenue there.
假设：对某国出售先进芯片的新限制，会缩小芯片公司的可触达市场，影响程度取决于它们在当地的收入占比。

## Common misconceptions 常见误区
- Headlines are not lasting impact. Check revenue exposure, substitution, exemptions and enforcement before concluding anything.
- 新闻标题不等于长期影响。下结论前先看收入敞口、替代方案、豁免和执行情况。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
