---
title: "Fiscal Policy 财政政策"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [财政政策]
tags: [concepts]
---
# Fiscal Policy 财政政策

## Definition 定义
Government decisions on spending and taxation.
政府在支出和税收方面的决策。

## Market impact 市场影响
Larger deficits can increase bond supply and push yields up; targeted spending or subsidies can boost specific sectors.
赤字扩大可能增加债券供应并推高收益率；定向支出或补贴可以提振特定行业。

## Related 相关
[[GDP]], [[Interest Rates]], [[Yield Curve]]
2026-10-27 新增相关：[[Federal Budget and Monthly Treasury Statement]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: higher government spending can lift growth, but a bigger deficit usually means more Treasury issuance, which can push yields up.
假设：政府支出增加可以提振增长，但赤字扩大通常意味着更多国债发行，可能推高收益率。

## Common misconceptions 常见误区
- Fiscal policy (Congress and the Treasury) is not monetary policy (the Fed). Deficits do not automatically cause inflation; context matters.
- 财政政策（国会和财政部）不等于货币政策（美联储）。赤字不会自动导致通胀，要看具体环境。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Supply Refunding and Buybacks|发行、季度再融资与财政部回购]]：不仅看发多少债，还要看期限、到期偿还与谁来承接。
- [[21_US_Treasuries/Treasury Debt Ceiling and Payment Risk|债务上限、支付风险与财政可持续性]]：把政治支付约束、利率负担和市场价格分开。
