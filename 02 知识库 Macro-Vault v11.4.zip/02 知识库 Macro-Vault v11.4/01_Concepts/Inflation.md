---
title: "Inflation 通货膨胀"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [通货膨胀]
tags: [concepts]
---
# Inflation 通货膨胀

## Definition 定义
A sustained rise in the general price level, which reduces purchasing power.
物价总体持续上涨，导致购买力下降。

## Market impact 市场影响
Higher inflation tends to push central banks toward higher rates, pressuring bond prices and growth stocks. Surprises versus expectations matter more than the level itself.
通胀上升通常促使央行加息，债券价格和成长股承压。相对预期的“意外”比通胀水平本身更重要。

## Related 相关
[[CPI]], [[PPI]], [[Interest Rates]], [[Monetary Policy]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: inflation falling from 4% to 3% is disinflation: prices still rise, only more slowly. Deflation means the price level itself falls.
假设：通胀从4%降到3%是通胀放缓（disinflation）：价格仍在涨，只是涨得慢。通缩（deflation）才是价格水平本身下降。

## Common misconceptions 常见误区
- Falling inflation does not mean prices are falling. Also separate headline from core, and MoM from YoY.
- 通胀下降不代表物价下降。还要区分整体与核心、环比与同比。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Real Yields and Breakevens|实际利率、盈亏平衡通胀和期限溢价]]：同样是 10 年收益率上涨，背后的原因可能完全不同。
