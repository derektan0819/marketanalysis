---
title: "Exchange Rate 汇率"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [汇率]
tags: [concepts]
---
# Exchange Rate 汇率

## Definition 定义
The price of one currency in terms of another. The US dollar is the world's main reserve and trading currency; its strength is tracked by the DXY index.
一种货币兑另一种货币的价格。美元是全球主要的储备和贸易货币，其强弱通过美元指数（DXY）追踪。

## Market impact 市场影响
A stronger dollar lowers the translated value of US multinationals' overseas earnings, pressures USD-priced commodities and emerging markets, and tightens global financial conditions. A weaker dollar does the opposite.
美元走强会减少美国跨国公司海外盈利折算成美元后的价值，压制以美元计价的大宗商品和新兴市场，并收紧全球金融环境；美元走弱则相反。

## Related 相关
[[DXY]], [[Strong USD to US Multinationals]], [[Federal Funds Rate]], [[Risk-On Risk-Off]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: a stronger dollar means a US multinational's overseas sales translate into fewer dollars, which can reduce reported revenue.
假设：美元走强，美国跨国公司的海外销售折算成美元后变少，报告收入可能下降。

## Common misconceptions 常见误区
- A 'strong' currency is not simply good or bad: exporters and importers, and producers and consumers, are affected differently.
- “强势货币”没有简单的好坏之分：出口商与进口商、生产者与消费者受到的影响不同。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.


See also: [[Global Central Banks]], [[Yen and Carry Trade]]

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Investing from Malaysia|马来西亚投资者：美元美债与 MYR 回报]]：美元赚了利息，换回马币仍可能亏损。
