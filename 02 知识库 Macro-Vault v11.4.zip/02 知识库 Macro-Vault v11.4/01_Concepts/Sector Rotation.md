---
title: "Sector Rotation 板块轮动"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [板块轮动]
tags: [concepts]
---
# Sector Rotation 板块轮动

## Definition 定义
Money shifting between sectors as views on growth, rates and risk change.
随着对增长、利率和风险的看法变化，资金在不同板块之间转移。

## Market impact 市场影响
Falling yields and rising growth expectations tend to favour growth and tech; rising yields or slowdown fears tend to favour defensive sectors. Banks depend on the rate and credit outlook.
收益率下降、增长预期上升时，资金倾向成长和科技；收益率上升或担心放缓时，倾向防御板块。银行则取决于利率和信贷前景。

## Related 相关
[[US 10-Year Treasury Yield]], [[Risk-On Risk-Off]], [[Priced In]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: when growth expectations improve, money moves from defensive sectors (utilities, staples) toward cyclical sectors.
假设：增长预期改善时，资金从防御板块（公用事业、必需消费）转向周期板块。

## Common misconceptions 常见误区
- Rotation is relative. A sector can fall less than the market and still fall.
- 轮动是相对的。某板块跌得比大盘少，仍然是下跌。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
