---
title: "Real Interest Rates 实际利率"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [实际利率, Real Yield]
tags: [concepts]
as_of: 2026-10
---
# Real Interest Rates 实际利率

## Definition 定义
The nominal interest rate adjusted for inflation. Approximation: real rate ≈ nominal rate − expected inflation. A market-based proxy is the yield on Treasury Inflation-Protected Securities (TIPS).
经通胀调整后的名义利率。近似公式：实际利率 ≈ 名义利率 − 预期通胀。市场上的参考指标是通胀保值国债（TIPS）的收益率。

## Mechanism and market impact 机制与市场影响
Higher real yields raise the return on safe assets and the discount rate on future cash flows, pressuring long-duration growth stocks and non-yielding assets such as gold. Breakeven inflation = nominal Treasury yield − TIPS yield of the same maturity.
实际收益率上升会提高安全资产的回报和未来现金流的贴现率，对久期长的成长股和不生息资产（如黄金）形成压力。盈亏平衡通胀率 = 同期限名义国债收益率 − TIPS 收益率。

## Example 例子 (illustrative 示意)
Illustrative numbers only: nominal yield 4.0%, expected inflation 2.5%, so real yield ≈ 1.5%. If the nominal yield stays at 4.0% but expected inflation falls to 2.0%, the real yield rises to about 2.0%.
仅为示意数字：名义收益率4.0%，预期通胀2.5%，实际收益率约1.5%。若名义收益率不变而预期通胀降到2.0%，实际收益率升至约2.0%。

## Common misconceptions 常见误区
- A higher nominal yield does not always mean tighter conditions: check whether the real yield moved.
- 名义收益率上升不一定代表更紧：要看实际收益率有没有变化。
- Expected inflation is not directly observable; breakevens include risk and liquidity effects.
- 预期通胀无法直接观察；盈亏平衡通胀率包含风险和流动性因素。

## Related 相关
[[Interest Rates]], [[Inflation]], [[US Treasury Market]], [[US 10-Year Treasury Yield]], [[Treasury Yield to Equity Valuation]], [[Term Premium]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Real Yields and Breakevens|实际利率、盈亏平衡通胀和期限溢价]]：同样是 10 年收益率上涨，背后的原因可能完全不同。
- [[21_US_Treasuries/Treasury TIPS Mechanics|TIPS 怎样抗通胀，又为什么会亏损]]：保护本金的通胀调整，与二级市场价格变化是两回事。
