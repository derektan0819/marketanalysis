---
title: "Yield Curve 收益率曲线"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [收益率曲线]
tags: [concepts]
---
# Yield Curve 收益率曲线

## Definition 定义
A plot of government bond yields across different maturities.
不同期限政府债券收益率的曲线。

## Market impact 市场影响
An inverted curve (short yields above long yields) has often preceded slowdowns. Curve steepness affects bank net interest margins.
曲线倒挂（短端高于长端）历来常先于经济放缓出现。曲线陡峭程度影响银行净息差。

## Related 相关
[[Interest Rates]], [[Credit Spread]], [[Monetary Policy]]

## Example 例子 (illustrative 示意，非真实数据)
An inverted curve (short-term yields above long-term yields) has historically been followed by slowdowns, but the timing has varied widely.
收益率曲线倒挂（短端收益率高于长端）在历史上之后常出现放缓，但时间差异很大。

## Common misconceptions 常见误区
- Inversion is not a timer. Curve moves can also reflect Treasury supply or term premium, not only growth expectations.
- 倒挂不是计时器。曲线变化也可能来自国债供给或期限溢价，不只是增长预期。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Yield Curve Scenarios|曲线变化：牛陡、熊陡、牛平、熊平]]：先看哪一端在动，再解释增长、通胀与供给。
- [[21_US_Treasuries/Treasury Spot Forward and Par Yields|平价、零息和远期收益率]]：官方 10 年收益率不等于某一张债的成交收益率。

## 先判断哪一端在动

解除倒挂可能是短端因增长担忧而快速下降，也可能是长端因期限补偿提高而上涨。两者都让长短端利差变大，但对债价和融资环境的含义不同。银行还受到存款成本、对冲和贷款损失影响，不能把“更陡”直接当作净息差必升。用 [[21_US_Treasuries/Treasury Yield Curve Scenarios]] 对照四类变化。
