---
title: "GDP 国内生产总值"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [国内生产总值]
tags: [concepts]
---
# GDP 国内生产总值

## Definition 定义
The total value of goods and services produced in an economy over a period.
一个经济体在一段时间内生产的商品与服务的总价值。

## Market impact 市场影响
Growth above expectations lifts earnings expectations and equities, but can also raise rate expectations. Weak growth does the reverse.
增长好于预期会提升盈利预期和股市，但也可能推高加息预期；增长疲弱则相反。

## Related 相关
[[Retail Sales]], [[PMI]], [[Trade Balance]], [[Fiscal Policy]]

## Example 例子 (illustrative 示意，非真实数据)
GDP is first published as an advance estimate and later revised, so the story can change after the first release.
GDP 先公布初值，之后会修正，所以第一次公布后的结论可能改变。

## Common misconceptions 常见误区
- GDP growth is not the same as stock returns: GDP looks backward, markets look forward. Also check whether a figure is quarterly annualized.
- GDP 增长不等于股市回报：GDP 看过去，市场看未来。还要留意数字是否为季度年化。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
