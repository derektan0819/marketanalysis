---
title: "Crypto Assets Overview 加密资产概览"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [加密货币, 比特币, 以太坊, Crypto, Bitcoin, Ether]
tags: [concepts]
as_of: 2026-10
---
# Crypto Assets Overview 加密资产概览

## Definition 定义
Crypto assets are digital assets recorded on blockchains. Main groups: Bitcoin (supply capped at 21 million coins), Ether (the native asset of the Ethereum smart-contract network), stablecoins (tokens meant to hold a fixed value, see [[Stablecoins]]) and thousands of other tokens. They trade on exchanges around the clock, including weekends.
加密资产是记录在区块链上的数字资产。主要类别：比特币（供应上限为2100万枚）、以太币（以太坊智能合约网络的原生资产）、稳定币（旨在保持固定价值的代币，见 [[Stablecoins]]）以及数以千计的其他代币。它们在交易所全天候交易，包括周末。

## Mechanism and market impact 机制与市场影响
Bitcoin and most tokens produce no earnings or cash flow, so P/E or discounted-cash-flow methods do not apply the same way. Prices are driven by liquidity, sentiment, flows (see [[Spot Bitcoin ETFs and Flows]]), leverage (see [[Crypto Leverage and Liquidations]]), regulation and narratives. Because markets run 24/7, crypto can react to news while US equities are closed.
比特币和大多数代币不产生盈利或现金流，所以市盈率或现金流折现等方法不能用同样的方式套用。价格受流动性、情绪、资金流（见 [[Spot Bitcoin ETFs and Flows]]）、杠杆（见 [[Crypto Leverage and Liquidations]]）、监管和叙事影响。由于市场全天候运行，美股休市时加密市场也能对消息做出反应。

US regulators: the SEC and the CFTC both have roles, and the split of responsibility has been a policy topic (verify the current framework).
美国监管：SEC 和 CFTC 都有职责，两者如何分工一直是政策议题（请核实现行框架）。

## Example 例子 (illustrative 示意)
Hypothetical: a crypto exchange fails or a major stablecoin loses its peg. Funds flow out of the ecosystem, leveraged positions are liquidated, and crypto-linked listed companies fall, even though the US stock market is not directly involved.
假设：一家加密交易所倒闭或一个主要稳定币脱锚。资金流出该生态，杠杆仓位被平仓，与加密相关的上市公司下跌，即使美国股市本身没有直接牵涉。

## Common misconceptions 常见误区
- 'Crypto is uncorrelated with stocks' is not reliable: the relationship changes with the market regime.
- “加密资产与股票不相关”并不可靠：相关性随市场环境而变。
- Price history is not proof of future behavior; drawdowns can be large.
- 历史价格不能证明未来表现，回撤可能很大。
- 'Fixed supply' does not guarantee a rising price.
- “供应固定”并不保证价格上涨。
- Crypto data from different sites can differ; record source and time.
- 不同网站的加密数据可能不同，要记录来源和时间。

## Related 相关
[[Spot Bitcoin ETFs and Flows]], [[Stablecoins]], [[Crypto Leverage and Liquidations]], [[Crypto and Macro Linkages]], [[Risk-On Risk-Off]], [[Liquidity]], [[Bank Regulation Map]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
