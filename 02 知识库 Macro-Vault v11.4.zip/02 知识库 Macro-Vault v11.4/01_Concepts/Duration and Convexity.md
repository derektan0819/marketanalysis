---
title: "Duration and Convexity 久期与凸性"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [久期, 凸性, Bond duration, Convexity]
tags: [concepts, rates]
as_of: 2026-10
---
# Duration and Convexity 久期与凸性

## Definition 定义
Duration measures how sensitive a bond's price is to a change in yield. Convexity measures how that sensitivity itself changes as yields move.
久期衡量债券价格对收益率变化的敏感度。凸性衡量这种敏感度本身随收益率变化的程度。

## Mechanism and market impact 机制与市场影响
- Approximation: percentage price change ≈ −(modified duration × change in yield) + ½ × convexity × (change in yield)². 近似公式见左。
- Illustration (not a market figure): a bond with modified duration 7 loses about 7% in price when yields rise by one percentage point, before the convexity adjustment. 示例：久期为 7 的债券，收益率上升一个百分点，价格约下跌 7%（未计凸性）。
- Longer maturity and lower coupon mean higher duration, so long bonds react more to rate moves ([[Yield Curve]], [[Term Premium]]). 期限越长、票息越低，久期越大。
- Positive convexity helps: price gains from a yield fall are larger than losses from an equal rise. 正凸性有利：收益率下降带来的收益大于同幅上升的损失。
- Why it matters: banks and insurers carry duration risk, and equity valuations of long-duration growth stocks are sensitive to discount rates ([[Treasury Yield to Equity Valuation]], [[Bank Metrics]]). 银行、保险和长久期成长股估值都受影响。

## Related 相关
[[Interest Rates]], [[US Treasury Market]], [[Yield Curve]], [[Term Premium]], [[Treasury Yield to Equity Valuation]], [[Rate Hike Transmission]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- Duration is an approximation for small yield changes; callable and mortgage bonds behave differently (negative convexity). Use the formula with dated inputs and show the calculation.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Cash Flows and Bond Pricing|票息、价格、收益率与真实回报]]：解释为什么票息固定，市场价格却每天改变。
- [[21_US_Treasuries/Treasury DV01 and Key Rate Duration|久期进阶：DV01 与不同期限的风险]]：把利率变动换成大致金额，并识别曲线并非一起移动。
- [[21_US_Treasuries/Treasury Floating Rate Notes|FRN 浮息美债：利率风险较低，收入会变]]：FRN 跟随短债参考利率，不是固定锁住今天的收益。

## 美债使用补充

这里的价格敏感度公式使用修正久期，收益率变动输入小数；不要把到期年数直接当久期。期限更长、票息更低通常更敏感，是其他条件接近时的比较。固定现金流国债通常有正凸性；含期权债券、MBS 等不能不加区分地套用。金额风险和非平行曲线变化见 [[21_US_Treasuries/Treasury DV01 and Key Rate Duration]]。
