---
title: "Private Credit and Shadow Banking 私募信贷与影子银行"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [私募信贷, 影子银行, Private credit, Non-bank lending]
tags: [concepts, credit]
as_of: 2026-10
---
# Private Credit and Shadow Banking 私募信贷与影子银行

## Definition 定义
Private credit is lending by non-bank funds directly to companies, often floating-rate and held outside public markets. Shadow banking is credit provided by non-bank institutions that are not regulated like banks.
私募信贷是非银行基金直接向公司放贷，常为浮动利率、不在公开市场交易。影子银行是不受银行式监管的非银行信贷机构。

## Mechanism and market impact 机制与市场影响
- Why it grew: tighter bank capital rules pushed some lending outside banks ([[Basel III and Capital Ratios]]), and investors wanted higher yields. 增长原因：银行资本监管趋严，投资者追求更高收益。
- Risks: loans are illiquid and valued by the manager rather than a market price, leverage may sit at the fund or the borrower, and funds that let investors redeem can face limits. 风险：贷款流动性差，估值由管理人决定，杠杆和赎回限制。
- Links to banks: banks lend to private-credit funds and other non-banks, so stress can come back to banks ([[Private Credit Stress to Banks and Markets]]). 与银行相连：银行向这些基金放贷，压力可能回到银行体系。
- Link to AI: some data-centre and AI financing sits in private and structured credit ([[Data Centers and Power]]). 部分数据中心与 AI 融资通过私募和结构化信贷完成。
- Signals to watch: defaults, payment-in-kind (PIK) usage, redemption limits, spreads ([[IG and HY Credit Spreads]]). 观察违约、实物支付（PIK）比例、赎回限制和利差。

## Related 相关
[[Credit Markets]], [[Credit Spread]], [[Secured Lending and Collateral]], [[Bank Runs and Deposit Insurance]], [[Private Credit Stress to Banks and Markets]], [[US Banks]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- Primary sources: Federal Reserve financial stability reports, IMF Global Financial Stability Report, BIS reports, SEC filings of listed lenders. Data are limited and partly self-reported.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.
