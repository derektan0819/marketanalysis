---
title: "Earnings Season 财报季"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [财报季]
tags: [concepts]
---
# Earnings Season 财报季

## Definition 定义
The weeks after each quarter ends when most listed companies report results. Large US banks usually start the season, followed by big tech and other sectors. Some companies (for example NVIDIA) have fiscal calendars that differ from the calendar year.
每个季度结束后大部分上市公司集中公布业绩的几周。美国通常由大银行开跑，随后是大型科技股和其他行业；部分公司（如 NVIDIA）的财年与自然年不同。

## Market impact 市场影响
Information arrives in a concentrated burst. Leaders' results set the read-across for the rest of the sector, and mega-cap results can move the whole index.
信息集中涌现。行业龙头的业绩为同行业其他公司定下关联传导的基调，超大市值公司的业绩还能带动整个指数。

## Related 相关
[[Read-Across]], [[Weekly Earnings Calendar]], [[Earnings Read-Across Playbook]], [[Mega-Cap Earnings to Index]]

## Example 例子 (illustrative 示意，非真实数据)
Large banks usually report early in a season, so their commentary can set the tone before mega-cap technology companies report.
大型银行通常在财报季初期公布，它们的评论会在大型科技股公布前先定下基调。

## Common misconceptions 常见误区
- A high share of 'beats' is not impressive by itself: expectations are often managed lower, so beating is common.
- “超预期”比例高本身没什么了不起：预期常被压低，所以超预期很常见。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
