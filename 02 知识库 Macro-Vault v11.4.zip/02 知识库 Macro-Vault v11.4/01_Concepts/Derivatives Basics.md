---
title: "Derivatives Basics 衍生品基础"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [衍生品, 期货, 期权, 互换, Derivatives]
tags: [concepts, derivatives]
as_of: 2026-10
---
# Derivatives Basics 衍生品基础

## Definition 定义
A derivative is a contract whose value depends on another asset or rate. The main types are forwards and futures, options and swaps.
衍生品是价值取决于另一资产或利率的合约。主要类型有远期和期货、期权和互换。

## Mechanism and market impact 机制与市场影响
- Futures: an agreement to buy or sell at a set price on a future date, traded on exchanges with daily margin settlement. 期货：约定未来按固定价格买卖，在交易所交易并每日结算保证金。
- Options: a call gives the right to buy and a put the right to sell at a strike price; the buyer's loss is limited to the premium. 期权：看涨期权赋予买入权，看跌期权赋予卖出权，买方最大损失是权利金。
- Swaps: two parties exchange cash flows, for example fixed-rate for floating-rate interest payments. 互换：双方交换现金流，例如固定利率换浮动利率。
- Uses: hedging a risk or taking a view; leverage magnifies both gains and losses ([[Crypto Leverage and Liquidations]]). 用途：对冲或表达观点；杠杆放大盈亏。
- Prices of options carry the market's expected volatility ([[Options and Implied Move]], [[Market Volatility and Options Positioning]]). 期权价格包含市场预期波动。

## Related 相关
[[Options and Implied Move]], [[Market Volatility and Options Positioning]], [[Fed Funds Futures]], [[Crypto Funding Rate and Open Interest]], [[Asset Allocation and Diversification]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- Contract specifications, margin rules and tax treatment differ by exchange and country; read the exchange's contract terms.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Futures and Basis Trade|美债期货、基差交易与杠杆风险]]：理解市场结构，不把基差收敛当成无风险收益。
