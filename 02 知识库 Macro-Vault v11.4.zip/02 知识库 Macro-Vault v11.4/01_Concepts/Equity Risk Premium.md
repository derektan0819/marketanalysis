---
title: "Equity Risk Premium 股权风险溢价"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [股权风险溢价, ERP]
tags: [concepts]
as_of: 2026-10
---
# Equity Risk Premium 股权风险溢价

## Definition 定义
The extra return investors expect from stocks over a risk-free asset such as a Treasury. It is not observable; it is estimated, and methods differ.
投资者期望股票相对无风险资产（如国债）多出的回报。它无法直接观察，只能估算，方法各不相同。

## Mechanism and market impact 机制与市场影响
When Treasury yields rise, the premium stocks offer over bonds shrinks unless earnings expectations rise too, which can pressure valuations. A rough comparison is earnings yield (1 ÷ P/E) versus the real or nominal Treasury yield.
国债收益率上升时，除非盈利预期同步上升，否则股票相对债券的溢价会缩小，可能压低估值。粗略比较方法是盈利收益率（1 ÷ 市盈率）与实际或名义国债收益率。

## Example 例子 (illustrative 示意)
Illustrative numbers only: a P/E of 20 gives an earnings yield of 5%. If the 10-year Treasury yields 4%, the gap is about 1 percentage point. If the Treasury yield rises to 5%, the gap disappears.
仅为示意数字：市盈率20对应盈利收益率5%。若10年期国债收益率4%，差距约1个百分点。若国债收益率升到5%，差距消失。

## Common misconceptions 常见误区
- A small gap is not a sell signal by itself; growth, inflation and risk appetite all matter.
- 差距小本身不是卖出信号；增长、通胀和风险偏好都有影响。
- The simple earnings-yield comparison ignores growth and is only a rough lens.
- 简单的盈利收益率比较忽略了增长，只是粗略的视角。

## Related 相关
[[Valuation Multiples]], [[Treasury Yield to Equity Valuation]], [[Real Interest Rates]], [[US 10-Year Treasury Yield]], [[Risk-On Risk-Off]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
