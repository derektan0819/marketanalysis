---
title: "Market Breadth 市场广度"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [市场广度]
tags: [concepts]
---
# Market Breadth 市场广度

## Definition 定义
How many stocks participate in a market move, for example advancing versus declining stocks, or equal-weighted versus cap-weighted indices.
有多少只股票参与了市场的走势，例如上涨与下跌股票数量，或等权与市值加权指数的对比。

## Market impact 市场影响
A rally driven by only a few mega-caps is fragile and depends on those companies' earnings. Broad participation signals healthier conditions.
仅由少数超大市值股票推动的上涨较为脆弱，取决于这些公司的财报；广泛参与代表更健康的状况。

## Related 相关
[[Index Weighting and Concentration]], [[Sector Rotation]], [[US Equity Indices]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: an index makes a record high while fewer stocks trade above their 200-day average. That is a narrow rally.
假设：指数创新高，但站在200日均线之上的股票越来越少。这是窄幅上涨。

## Common misconceptions 常见误区
- Weak breadth is a risk signal, not a timing tool; it does not predict an immediate fall.
- 市场广度变弱是风险信号，不是择时工具，不代表马上下跌。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
