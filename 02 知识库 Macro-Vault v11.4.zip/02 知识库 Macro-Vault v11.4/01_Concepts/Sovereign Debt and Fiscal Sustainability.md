---
title: "Sovereign Debt and Fiscal Sustainability 主权债务与财政可持续性"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [主权债务, 财政可持续性, Sovereign debt]
tags: [concepts, fiscal]
as_of: 2026-10
---
# Sovereign Debt and Fiscal Sustainability 主权债务与财政可持续性

## Definition 定义
Sovereign debt is borrowing by a national government. Fiscal sustainability asks whether the debt can be serviced without a sharp rise in taxes, inflation or default.
主权债务是国家政府的借款。财政可持续性是指债务能否在不大幅加税、引发通胀或违约的情况下偿还。

## Mechanism and market impact 机制与市场影响
- Key ratios: debt to GDP, deficit to GDP, and interest costs as a share of revenue. 关键比率：债务占 GDP、赤字占 GDP、利息占收入。
- The growth-rate link: debt is easier to carry when growth exceeds the interest rate and harder when rates rise above growth. 经济增长高于利率时债务较易承受。
- Borrowing in the home currency lowers default risk (the government can issue it), but can raise inflation or currency risk; foreign-currency debt is riskier ([[Emerging Markets Overview]]). 本币债务违约风险较低，外币债务风险更高。
- Market signals: auction demand, term premium, credit ratings and bond spreads ([[Treasury Auctions]], [[Term Premium]]). 市场信号：拍卖需求、期限溢价、评级和利差。
- Large buyers include central banks, pension funds and sovereign funds ([[Foreign Exchange Reserves and Reserve Currencies]]). 大买家包括央行、养老金和主权基金。

## Related 相关
[[Fiscal Policy]], [[US Treasury Market]], [[Term Premium]], [[Treasury Auctions]], [[United Kingdom and Bank of England]], [[Japan Economy and BoJ]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- Primary sources: national treasuries and debt-management offices, IMF Fiscal Monitor, rating agencies. Definitions of 'debt' differ (gross, net, general government); state which one is used.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Supply Refunding and Buybacks|发行、季度再融资与财政部回购]]：不仅看发多少债，还要看期限、到期偿还与谁来承接。
- [[21_US_Treasuries/Treasury Debt Ceiling and Payment Risk|债务上限、支付风险与财政可持续性]]：把政治支付约束、利率负担和市场价格分开。
