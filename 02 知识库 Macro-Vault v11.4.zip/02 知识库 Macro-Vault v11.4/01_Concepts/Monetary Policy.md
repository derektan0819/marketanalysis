---
title: "Monetary Policy 货币政策"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [货币政策]
tags: [concepts]
---
# Monetary Policy 货币政策

## Definition 定义
Central bank actions on interest rates and the balance sheet to pursue price stability and maximum employment. In the US this is the Federal Reserve.
央行通过利率和资产负债表来追求物价稳定和充分就业。在美国，这个机构是美联储。

## Market impact 市场影响
Policy shifts move Treasury yields, the dollar, bank margins and equity valuations. Markets react to changes in expected policy, not only to decisions.
政策转向会推动国债收益率、美元、银行利润率和股票估值。市场反应的是“预期政策的变化”，而不只是决定本身。

## Related 相关
[[Fed and FOMC]], [[Federal Funds Rate]], [[Interest Rates]], [[Inflation]]

## Example 例子 (illustrative 示意，非真实数据)
A central bank raises rates to cool inflation: borrowing costs rise and demand slows, but only after a lag.
央行加息抑制通胀：借贷成本上升、需求放缓，但会有时滞。

## Common misconceptions 常见误区
- Effects are not immediate. Policy works through rates, guidance and the balance sheet, and the lags can be long and uncertain.
- 效果不是立刻出现的。政策通过利率、指引和资产负债表起作用，时滞可能很长且不确定。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
