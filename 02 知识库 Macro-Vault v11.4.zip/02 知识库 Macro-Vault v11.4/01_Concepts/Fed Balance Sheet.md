---
title: "Fed Balance Sheet 联储资产负债表"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [联储资产负债表]
tags: [concepts]
---
# Fed Balance Sheet 联储资产负债表

## Definition 定义
The Fed's holdings of Treasuries and mortgage-backed securities. Buying assets (QE) adds liquidity; letting them run off (QT) removes it.
美联储持有的国债和抵押贷款支持证券。购买资产（QE）增加流动性；让其到期不续（QT）则减少流动性。

## Market impact 市场影响
Balance sheet changes affect long-term yields, bank reserves and market liquidity, independently of the policy rate.
资产负债表的变化会独立于政策利率，影响长期收益率、银行准备金和市场流动性。

## Related 相关
[[Fed and FOMC]], [[Liquidity]], [[US Treasury Market]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: when the Fed lets bonds mature without replacing them (runoff), bank reserves and system liquidity can decline over time.
假设：美联储让到期债券不再续买（缩表），银行准备金和系统流动性会逐渐下降。

## Common misconceptions 常见误区
- Balance-sheet policy is not the policy rate; they can move independently. Runoff is not the Fed selling everything at once.
- 资产负债表政策不等于政策利率，两者可以独立变化。缩表不是美联储一次性卖光资产。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury TGA Reserves and RRP|TGA、银行准备金与 ON RRP]]：发行美债怎样移动现金，取决于钱原来在哪里。

## 准备金与市场价格的限制

QT 到期不续作与主动卖债不是同一操作。美联储资产变化对准备金的影响，还要结合 TGA、ON RRP、流通现金等负债变化；不能把 QT 金额一比一当成从股票撤走的资金。具体现金路径见 [[21_US_Treasuries/Treasury TGA Reserves and RRP]]；财政部回购与 QE 的区别见 [[21_US_Treasuries/Treasury Supply Refunding and Buybacks]]。
