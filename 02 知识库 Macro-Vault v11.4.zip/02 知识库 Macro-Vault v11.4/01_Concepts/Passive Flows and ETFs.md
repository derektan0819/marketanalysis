---
title: "Passive Flows and ETFs 被动资金与ETF"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [被动资金与ETF]
tags: [concepts]
---
# Passive Flows and ETFs 被动资金与ETF

## Definition 定义
Index funds and ETFs buy and sell stocks in proportion to index weights, regardless of valuation.
指数基金和 ETF 按指数权重买卖股票，不考虑估值。

## Market impact 市场影响
Steady inflows add buying pressure to the largest stocks. Index inclusion, rebalancing and quarterly options-expiry days can cause sharp, mechanical moves.
持续流入会给最大的股票带来买盘；被纳入指数、再平衡以及每季度的期权到期日可能引发明显的机械性波动。

## Related 相关
[[Index Weighting and Concentration]], [[Market Breadth]], [[Short Interest and Positioning]]

## Example 例子 (illustrative 示意，非真实数据)
Money flowing into an index fund buys all constituents in proportion to their weights, which supports the largest names the most.
资金流入指数基金，会按权重买入所有成分股，对权重最大的股票支撑最大。

## Common misconceptions 常见误区
- Passive flows are not always the cause of a move; ETF flows can also be a result of price moves.
- 被动资金不一定是行情的原因；ETF 资金流也可能是价格变动的结果。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.


See also: [[Spot Bitcoin ETFs and Flows]]

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Funds and Direct Bonds|单只美债、美债 ETF 与现金工具]]：“持有到期”不能原封不动套在普通债券基金上。
