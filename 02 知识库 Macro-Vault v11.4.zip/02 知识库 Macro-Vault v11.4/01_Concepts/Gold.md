---
title: "Gold 黄金"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [黄金, Gold]
tags: [concepts]
as_of: 2026-10
---
# Gold 黄金

## Definition 定义
Gold is a non-yielding asset often treated as a safe haven and a store of value. Its price is quoted in dollars and responds to real interest rates, the dollar, risk sentiment and central-bank buying.
黄金是不生息资产，常被视为避险资产和价值储存。它以美元计价，受实际利率、美元、风险情绪和央行购金的影响。

## Mechanism and market impact 机制与市场影响
Higher real yields raise the opportunity cost of holding gold, which tends to pressure the price. A weaker dollar can support it. In stress, demand for safe assets can lift it. These effects can offset each other, so the relationship is not stable.
实际收益率上升会提高持有黄金的机会成本，往往压制金价。美元走弱可能支撑金价。压力时期对避险资产的需求可能推高金价。这些效应可能互相抵消，所以关系并不稳定。

## Example 例子 (illustrative 示意)
Hypothetical: real yields fall and the dollar weakens at the same time. Both factors tend to support gold, though other drivers may still dominate.
假设：实际收益率下降，同时美元走弱。这两个因素都倾向于支撑金价，但其他驱动因素仍可能占主导。

## Common misconceptions 常见误区
- Gold is not a reliable short-term inflation hedge; it often reacts more to real yields.
- 黄金并不是可靠的短期通胀对冲，它往往更多反应实际收益率。
- 'Safe haven' does not mean it never falls in a sell-off.
- “避险资产”不代表在抛售中不会下跌。
- Correlations with stocks, bonds and the dollar change over time.
- 与股票、债券和美元的相关性会随时间变化。

## Related 相关
[[Real Interest Rates]], [[Exchange Rate]], [[DXY]], [[Risk-On Risk-Off]], [[Commodity Prices]], [[Inflation]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Real Yields and Breakevens|实际利率、盈亏平衡通胀和期限溢价]]：同样是 10 年收益率上涨，背后的原因可能完全不同。
