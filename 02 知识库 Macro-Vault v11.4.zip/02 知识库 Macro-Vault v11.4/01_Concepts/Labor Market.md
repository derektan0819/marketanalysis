---
title: "Labor Market 劳动力市场"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [劳动力市场, 就业市场]
tags: [concepts]
as_of: 2026-10
---
# Labor Market 劳动力市场

## Definition 定义
The market for workers and jobs. Key measures: payrolls (jobs added), unemployment rate, participation rate, job openings, jobless claims and wage growth. The Fed has a dual mandate: maximum employment and stable prices.
工人与工作岗位的市场。关键指标：非农就业、失业率、劳动参与率、职位空缺、初请失业金和工资增速。美联储有双重使命：充分就业和物价稳定。

## Mechanism and market impact 机制与市场影响
A strong labor market supports consumer spending but can raise wage pressure and inflation, which can push the Fed toward tighter policy. So 'good news can be bad news' for stocks when inflation is the main concern, and the reverse when growth is the main concern.
强劲的劳动力市场支撑消费，但可能推高工资压力和通胀，使美联储倾向收紧。因此当市场主要担心通胀时，“好消息可能是坏消息”；当主要担心增长时则相反。

## Example 例子 (illustrative 示意)
Hypothetical: payrolls beat expectations and wages grow faster than expected. Yields rise on the expectation of fewer or later rate cuts.
假设：非农就业超预期，工资增速也高于预期。市场预期降息减少或推迟，收益率上升。

## Common misconceptions 常见误区
- One month of payrolls is noisy and often revised.
- 单月非农数据波动大，且常被修正。
- A low unemployment rate can coexist with a falling participation rate, so check both.
- 失业率低可能伴随劳动参与率下降，所以两者要一起看。

## Related 相关
[[Nonfarm Payrolls]], [[Unemployment Rate]], [[JOLTS]], [[Jobless Claims]], [[Jobs Report to Markets]], [[Fed and FOMC]], [[Inflation]]
2026-10-27 新增相关：[[Employment Cost Index]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
