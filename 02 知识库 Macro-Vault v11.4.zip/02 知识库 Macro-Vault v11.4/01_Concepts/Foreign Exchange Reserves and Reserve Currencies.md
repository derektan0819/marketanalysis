---
title: "Foreign Exchange Reserves and Reserve Currencies 外汇储备与储备货币"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [外汇储备, 储备货币, FX reserves]
tags: [concepts, global]
as_of: 2026-10
---
# Foreign Exchange Reserves and Reserve Currencies 外汇储备与储备货币

## Definition 定义
Foreign exchange reserves are foreign-currency assets (and gold) held by a central bank to pay for imports, repay external debt and defend its currency. A reserve currency is one that central banks hold in large amounts, led by the US dollar.
外汇储备是央行持有的外币资产（和黄金），用于支付进口、偿还外债和稳定汇率。储备货币是央行大量持有的货币，美元居首。

## Mechanism and market impact 机制与市场影响
- Reserves are mostly invested in safe, liquid assets such as government bonds, so central banks are major holders of US Treasuries ([[US Treasury Market]]). 储备主要投资于安全、流动的资产，央行是美债的重要持有者。
- Selling reserves to defend a currency drains them; low reserves relative to short-term debt raise crisis risk ([[Emerging Markets Overview]]). 动用储备护汇会消耗储备。
- Currency mix: the IMF's COFER data shows reserve currency shares by quarter; changes tend to be slow and partly reflect exchange-rate moves. IMF COFER 数据显示储备货币结构，变化通常缓慢，且部分来自汇率波动。
- Gold: many central banks hold gold and have been buyers in recent years ([[Gold]]). 许多央行持有黄金。
- Claims about the dollar losing its role need to be checked against COFER and payment data, not headlines. 美元地位下降的说法要用 COFER 等数据验证。

## Related 相关
[[Sovereign Wealth Funds]], [[Exchange Rate]], [[FX Intervention and Currency Regimes]], [[Gold]], [[US Treasury Market]], [[DXY]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- Primary sources: IMF COFER and each central bank's reserve statistics.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Holders and TIC|谁持有美债：TIC 与买家结构]]：持仓减少未必等于抛售，间接投标者也不等于外国政府。
