---
title: "Trade, Tariffs and Supply Chains 贸易、关税与供应链"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [关税, 贸易, 供应链, Tariffs]
tags: [concepts, trade]
as_of: 2026-10
---
# Trade, Tariffs and Supply Chains 贸易、关税与供应链

## Definition 定义
A tariff is a tax on imported goods. Trade policy also includes quotas, export controls and sanctions. Supply chains are the networks of firms and countries that produce and move goods.
关税是对进口商品征收的税。贸易政策还包括配额、出口管制和制裁。供应链是生产和运输商品的企业与国家网络。

## Mechanism and market impact 机制与市场影响
- Who pays: the cost is shared among foreign exporters, domestic importers, companies and consumers; the split depends on pricing power and substitutes. 谁来承担：由出口商、进口商、企业和消费者分担。
- Effects: higher prices for affected goods, margin pressure, rerouted trade through other countries, and possible retaliation ([[Export Controls and Tariffs]]). 影响：价格上升、利润承压、贸易转道、可能遭报复。
- Timing: exemptions, delays and legal challenges make the effective tariff rate differ from announced rates. 公布税率与实际有效税率常有差异。
- Sector exposure: semiconductors, autos, retail and agriculture react differently ([[Semiconductors]], [[Geopolitics and Export Controls]]). 不同行业反应不同。
- Currency offset: exchange-rate moves can partly offset tariffs ([[Exchange Rate]]). 汇率变动可部分抵消关税。

## Related 相关
[[Export Controls and Tariffs]], [[Tariffs to Prices and Earnings]], [[Geopolitics and Export Controls]], [[Inflation]], [[China Economy and Policy]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- Primary sources: USTR, US Customs and Border Protection, the WTO and national customs agencies. Announced and applied measures can differ; record the effective date.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.
