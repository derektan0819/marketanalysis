---
title: "Consensus and Expectations 市场一致预期"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [市场一致预期]
tags: [concepts]
---
# Consensus and Expectations 市场一致预期

## Definition 定义
The average analyst forecast for a company's revenue, earnings and guidance.
分析师对公司收入、盈利和指引的平均预测。

## Market impact 市场影响
Stocks react to results versus consensus, not to good or bad in absolute terms. A strong result that falls short of expectations can still drop.
股价反应的是“业绩相对预期”，而不是绝对好坏。很强的业绩若低于预期，股价仍可能下跌。

## Related 相关
[[Priced In]], [[Guidance]], [[Earnings Season]], [[Earnings Estimate Revisions]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: EPS grows year over year but lands below consensus. The stock can still fall because the market reacts to the gap versus expectations.
假设：每股收益同比增长，但低于市场一致预期。股价仍可能下跌，因为市场反应的是与预期的差距。

## Common misconceptions 常见误区
- 'Good results = stock up' is a common mistake. Company guidance is not consensus, and consensus must name a provider and a timestamp.
- 常见误区是“业绩好=股价涨”。公司指引不等于一致预期，一致预期必须注明提供方和时间。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
