---
title: "Liquidity 流动性"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [流动性]
tags: [concepts]
---
# Liquidity 流动性

## Definition 定义
How easily assets can be bought or sold, and how available funding is across the financial system.
资产买卖的难易程度，以及金融体系中资金的可得性。

## Market impact 市场影响
Tight liquidity amplifies sell-offs and raises funding costs for banks and companies.
流动性收紧会放大抛售，并提高银行和企业的融资成本。

## Related 相关
[[Credit Spread]], [[Monetary Policy]], [[Risk-On Risk-Off]]

## Example 例子 (illustrative 示意，非真实数据)
In stress, even good assets can sell at a discount because buyers disappear and bid-ask spreads widen.
压力时期，即使是好资产也可能折价出售，因为买家消失、买卖价差扩大。

## Common misconceptions 常见误区
- Liquidity is not the same as cash or money supply. Market liquidity and funding liquidity are different things.
- 流动性不等于现金或货币供应。市场流动性和融资流动性是两回事。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Repo SOFR and Collateral|Repo、SOFR 与美债抵押品]]：美债既是投资品，也是借美元时常用的抵押品。
- [[21_US_Treasuries/Treasury TGA Reserves and RRP|TGA、银行准备金与 ON RRP]]：发行美债怎样移动现金，取决于钱原来在哪里。
- [[21_US_Treasuries/Treasury Liquidity and Market Structure|美债流动性、交易商与新旧券]]：低信用风险不保证任何时候都能以理想价格成交。
