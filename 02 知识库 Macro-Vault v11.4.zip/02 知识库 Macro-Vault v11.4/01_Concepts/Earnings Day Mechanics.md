---
title: "Earnings Day Mechanics 财报日机制"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [财报日机制]
tags: [concepts]
---
# Earnings Day Mechanics 财报日机制

## Definition 定义
US companies release results as a press release (filed on Form 8-K) before the open or after the close, followed by an earnings call with analyst Q&A.
美国公司在开盘前或收盘后发布业绩新闻稿（以 8-K 表格提交），随后召开业绩电话会并进行分析师问答。

## Market impact 市场影响
The first move happens in after-hours or pre-market trading, driven by the headline numbers and guidance, and the call can reverse it. Compare the move with the options-implied move to judge whether it was a real surprise.
第一波反应出现在盘后或盘前交易，由数据和指引驱动，电话会可能使其反转。把涨跌幅与期权隐含波动比较，才能判断是否真的出乎意料。

## Related 相关
[[Options and Implied Move]], [[Consensus and Expectations]], [[Guidance]], [[SEC Filings and Earnings Release]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: a company reports after the close. The first reaction happens in thin after-hours trading; the earnings call can then reverse it.
假设：公司收盘后发布财报。第一波反应出现在成交稀薄的盘后，之后的业绩电话会可能让走势反转。

## Common misconceptions 常见误区
- The after-hours move is not the final reaction. Guidance and call commentary often matter more than the headline numbers.
- 盘后涨跌不是最终反应。指引和电话会上的说法，往往比头条数字更重要。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
