---
title: "Market Volatility and Options Positioning 波动率与期权持仓"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [波动率, 期权持仓, Gamma, Volatility]
tags: [concepts, volatility]
as_of: 2026-10
---
# Market Volatility and Options Positioning 波动率与期权持仓

## Definition 定义
Implied volatility is the volatility priced into options; realized volatility is what actually happened. Options positioning is how large traders and dealers hold options, which can affect how prices move around key levels.
隐含波动率是期权价格中隐含的波动率，实际波动率是已发生的波动。期权持仓指大型交易者和做市商持有期权的情况，会影响价格在关键价位附近的走势。

## Mechanism and market impact 机制与市场影响
- Implied versus realized: a gap between them shows how much protection costs relative to actual movement ([[VIX]]). 隐含与实际的差距反映保护成本。
- Skew: put options often cost more than calls because investors pay for downside protection. 偏斜：看跌期权常比看涨更贵。
- Dealer hedging: when dealers are short options, they may buy into rises and sell into falls to stay hedged, which can amplify moves; when they are long options the effect can dampen moves. 做市商对冲可能放大或抑制波动。
- Expiry dates: monthly and quarterly expiries and very short-dated options can concentrate positioning. 到期日会集中持仓。
- Bond volatility: the MOVE Index plays the VIX role for Treasuries ([[MOVE Index]]). 债券波动率指标是 MOVE。

## Related 相关
[[VIX]], [[MOVE Index]], [[Options and Implied Move]], [[Derivatives Basics]], [[Risk-On Risk-Off]], [[Earnings Day Mechanics]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- Dealer positioning is estimated from models and assumptions that differ across providers; treat it as a hypothesis, not a fact, and name the provider.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.
