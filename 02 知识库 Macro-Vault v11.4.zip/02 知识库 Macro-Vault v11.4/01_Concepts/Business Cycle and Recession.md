---
title: "Business Cycle and Recession 经济周期与衰退"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [经济周期, 衰退, Recession]
tags: [concepts]
as_of: 2026-10
---
# Business Cycle and Recession 经济周期与衰退

## Definition 定义
The business cycle is the repeating pattern of expansion, peak, contraction and trough in economic activity. A recession is a significant, broad and lasting decline in activity. In the US, the NBER business cycle committee dates recessions, usually well after they begin.
经济周期是经济活动在扩张、顶峰、收缩、谷底之间的反复变化。衰退是经济活动大范围、持续的显著下降。美国由 NBER 的经济周期委员会确定衰退日期，通常要在衰退开始很久之后才宣布。

## Mechanism and market impact 机制与市场影响
Slowing growth lowers earnings expectations (see [[Earnings Estimate Revisions]]), widens [[Credit Spread]], and often leads the central bank to cut rates. Equity markets tend to move before the official data, so stocks can bottom while the economy is still weak.
增长放缓会拉低盈利预期（见 [[Earnings Estimate Revisions]]）、扩大 [[Credit Spread]]，并常使央行降息。股市往往先于官方数据变动，所以经济仍弱时股市可能已经见底。

Indicator groups 指标分类: leading (e.g. new orders, claims, yield curve), coincident (e.g. payrolls, industrial output), lagging (e.g. unemployment rate, CPI).
领先指标（新订单、申请失业金、收益率曲线）、同步指标（就业、工业产出）、滞后指标（失业率、CPI）。

## Example 例子 (illustrative 示意)
Hypothetical: jobless claims rise for several weeks and the manufacturing PMI falls. These are leading signals of slowing, but neither alone proves a recession.
假设：申请失业金人数连续数周上升，制造业 PMI 下降。这是放缓的领先信号，但单独任何一个都不能证明衰退。

## Common misconceptions 常见误区
- 'Two consecutive quarters of negative GDP' is a popular rule of thumb, not the official US definition.
- “GDP 连续两个季度负增长”是流行的经验法则，不是美国官方定义。
- A recession call is not a market-timing call; markets price the future.
- 判断衰退不等于判断买卖时点；市场定价的是未来。

## Related 相关
[[GDP]], [[US GDP Report]], [[Yield Curve]], [[Jobless Claims]], [[PMI]], [[Unemployment Rate]], [[Stagflation]], [[Labor Market]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
