---
title: "Korea Market and KOSPI 韩国市场与KOSPI"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [韩国股市, KOSPI, KOSDAQ, 三星, SK海力士]
tags: [concepts]
as_of: 2026-10
---
# Korea Market and KOSPI 韩国市场与KOSPI

## Definition 定义
KOSPI is the main stock index of the Korea Exchange (KRX); KOSDAQ lists smaller, growth-oriented companies. KOSPI is heavily weighted toward semiconductors: Samsung Electronics and SK Hynix are among its largest members (check current weights). Both are major makers of DRAM and high-bandwidth memory (HBM), alongside Micron in the US.
KOSPI 是韩国交易所（KRX）的主要股指；KOSDAQ 上市的是规模较小、偏成长的公司。KOSPI 对半导体的权重很高：三星电子和 SK 海力士是其中最大的成分股之一（请核实最新权重）。两家公司都是 DRAM 和高带宽内存（HBM）的主要制造商，美国对应的是美光。

## Mechanism and market impact 机制与市场影响
Korea is an early read on memory chips for US investors: Samsung publishes preliminary earnings shortly after each quarter ends, SK Hynix reports later in the month, and Korean export data comes out on a fixed monthly schedule. Timing matters: the Korean market closes before the US market opens, so Korea reacts to the US close of the previous day, and US stocks then react to Korean news during the US session. See [[Korea Memory Stocks and US Chip Stocks]].
对美国投资者来说，韩国是内存芯片的早期信号：三星在每季度结束后不久公布初步业绩，SK 海力士在当月稍晚公布，韩国出口数据也按固定的月度时间发布。时间差很重要：韩国市场在美国开盘前收市，所以韩国反应的是前一天的美股收盘，而美股随后在美国交易时段对韩国的消息做出反应。见 [[Korea Memory Stocks and US Chip Stocks]]。

Other drivers 其他因素: the won–dollar exchange rate, foreign investor flows, shareholder-return policy (buybacks, share cancellation) and company-specific news.
韩元兑美元汇率、外资流向、股东回报政策（回购、注销股份）以及公司个别消息。

## Example 例子 (illustrative 示意)
Illustrative: when US memory and chip stocks fall sharply overnight, KOSPI may open lower the next morning because its heavyweights are memory makers. In one reported session in July 2026, an analyst linked a lower open to weakness in US semiconductor and memory stocks, higher oil prices and worries about further US tightening (see [[Case Study Samsung Q3 2026 Preliminary Earnings]] for the sources and caveats).
示意：美国内存和芯片股隔夜大跌时，KOSPI 次日早盘可能低开，因为它的权重股是内存厂商。2026年7月的一个交易日，有分析师把低开归因于美国半导体和内存股走弱、油价上涨以及对美国进一步收紧的担忧（来源和限制见 [[Case Study Samsung Q3 2026 Preliminary Earnings]]）。

## Common misconceptions 常见误区
- KOSPI is not a simple measure of the Korean economy; its moves can be dominated by a few chip stocks.
- KOSPI 不是衡量韩国经济的简单指标，少数芯片股就可能主导它的涨跌。
- A big Korean earnings number does not guarantee the stock rises; expectations may already include it.
- 韩国公司业绩数字很大，不保证股价上涨；预期可能已经包含了它。
- Korean moves do not reliably predict US moves; check timing, what each market already knew, and other drivers.
- 韩国市场的走势并不能可靠地预测美股；要看时间先后、各市场已知的信息，以及其他因素。
- Index levels from different websites can disagree; always record the source and date.
- 不同网站给出的指数点位可能不一致，一定要记录来源和日期。

## Related 相关
[[Memory Chips]], [[Memory Price Cycle]], [[DRAM Contract Prices]], [[Hyperscaler Capex to Chip Chain]], [[SOX Index]], [[Exchange Rate]], [[Index Weighting and Concentration]], [[KOSPI]], [[Korea Semiconductor Exports]], [[Korea Memory Stocks and US Chip Stocks]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
