---
title: "Options and Implied Move 期权与隐含波动"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [期权与隐含波动]
tags: [concepts]
---
# Options and Implied Move 期权与隐含波动

## Definition 定义
Option prices imply how much the market expects a stock to move. Around earnings, the implied move is often estimated from the price of at-the-money options.
期权价格反映市场预期股价会波动多少。财报前后，隐含波动幅度通常用平值期权价格估算。

## Market impact 市场影响
A stock can rise less than the implied move and still be seen as a disappointment, or fall after good news if positioning was crowded.
股价涨幅低于隐含波动幅度，仍可能被视为失望；若持仓过于拥挤，好消息之后也可能下跌。

## Related 相关
[[Earnings Day Mechanics]], [[Short Interest and Positioning]], [[VIX]]

## Example 例子 (illustrative 示意，非真实数据)
Hypothetical: options pricing implies a move of about a certain size around earnings. The actual move versus the implied move is the 'surprise'.
假设：期权定价隐含了财报前后某个幅度的波动。实际波动与隐含波动的对比，就是“意外”。

## Common misconceptions 常见误区
- The implied move shows expected size, not direction, and it includes a risk premium. It is not a forecast.
- 隐含波动幅度表示预期的大小，不是方向，并且包含风险溢价，它不是预测。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
