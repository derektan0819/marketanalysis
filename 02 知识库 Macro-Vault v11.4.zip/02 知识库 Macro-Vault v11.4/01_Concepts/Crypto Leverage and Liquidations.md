---
title: "Crypto Leverage and Liquidations 加密市场的杠杆与强平"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [杠杆, 强平, 永续合约, 资金费率, Liquidation]
tags: [concepts]
as_of: 2026-10
---
# Crypto Leverage and Liquidations 加密市场的杠杆与强平

## Definition 定义
Many crypto traders use leverage through perpetual futures (contracts with no expiry) on offshore and onshore exchanges. If the price moves against a leveraged position and margin falls too low, the exchange automatically closes it (liquidation). The funding rate is a periodic payment between long and short holders that keeps perpetual prices near spot prices.
许多加密交易者通过永续合约（无到期日的合约）使用杠杆。如果价格向不利方向变动、保证金过低，交易所会自动平仓（强平）。资金费率是多空持有者之间定期的付费，用来让永续合约价格贴近现货价格。

## Mechanism and market impact 机制与市场影响
Liquidations are forced sales, which push the price further, triggering more liquidations: a cascade. Because crypto trades 24/7 and leverage is high, moves can be sudden. Reported case: on 10 October 2025, a crypto sell-off triggered roughly 19 billion US dollars of leveraged liquidations within 24 hours, described by a news report as the largest such event in the industry's history (Cointelegraph, 24 August 2026; verify against exchange or data-provider records).
强平是被迫卖出，会进一步压低价格，触发更多强平，形成连锁反应。由于加密市场全天候交易且杠杆很高，波动可能来得很突然。案例：2025年10月10日，加密市场抛售在24小时内触发约190亿美元的杠杆强平，新闻报道称这是该行业历史上最大的一次（Cointelegraph，2026年8月24日；请对照交易所或数据提供方的记录核实）。

## Example 例子 (illustrative 示意)
Hypothetical: a price drop of a few percent liquidates highly leveraged long positions. The forced selling pushes the price down further, and the next group of positions is liquidated.
假设：价格下跌几个百分点就使高杠杆多头被强平。被迫卖出把价格进一步压低，下一批仓位又被强平。

## Common misconceptions 常见误区
- A large liquidation total does not by itself show the cause of the initial drop.
- 强平总额很大并不能说明最初下跌的原因。
- Reported liquidation figures vary by data provider and may not be audited.
- 不同数据提供方报告的强平数字不同，且可能未经审计。
- Leverage data is only partly observable.
- 杠杆数据只能部分观察到。

## Related 相关
[[Crypto Assets Overview]], [[Liquidity]], [[Risk-On Risk-Off]], [[Short Interest and Positioning]], [[Crypto and Macro Linkages]], [[Crypto Sentiment to US Equities]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
