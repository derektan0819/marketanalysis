---
title: "Fed and FOMC 联储与FOMC"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [联储与FOMC]
tags: [concepts]
---
# Fed and FOMC 联储与FOMC

## Definition 定义
The Federal Reserve has a dual mandate of maximum employment and stable prices, with a 2% inflation goal. The FOMC meets eight times a year to set the federal funds rate range and issues a statement. Quarterly projections (the dot plot) and a press conference add guidance; minutes follow about three weeks later.
美联储的双重使命是充分就业和物价稳定，通胀目标为 2%。FOMC 每年召开八次会议决定联邦基金利率区间并发布声明；每季度的预测（点阵图）和记者会提供进一步指引，会议纪要约三周后公布。

## Market impact 市场影响
Markets trade the change in expected policy, shown in fed funds futures and short-term Treasury yields. Changes in the statement's wording, the dots and the tone of the press conference often matter more than the decision itself.
市场交易的是预期政策的变化，体现在联邦基金期货和短期国债收益率上。声明措辞的变化、点阵图和记者会的语气，往往比决定本身更重要。

## Related 相关
[[Federal Funds Rate]], [[Fed Balance Sheet]], [[Fed Day Playbook]], [[Monetary Policy]]

## Example 例子 (illustrative 示意，非真实数据)
The FOMC statement is followed by a press conference. Markets often react to the change in wording versus the previous statement, not just the rate decision.
FOMC 声明之后是新闻发布会。市场常常对比上一份声明的措辞变化做出反应，而不只是看利率决定本身。

## Common misconceptions 常见误区
- The Fed does not set every rate; it sets a target range for the federal funds rate. Markets trade the expected future path, not only today's decision.
- 美联储并不设定所有利率，它设定的是联邦基金利率目标区间。市场交易的是预期的未来路径，不只是当天的决定。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
