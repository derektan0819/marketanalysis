---
title: "Share Buybacks and Dividends 回购与分红"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [回购与分红]
tags: [concepts]
---
# Share Buybacks and Dividends 回购与分红

## Definition 定义
The ways US companies return cash to shareholders: repurchasing shares or paying dividends.
美国公司向股东返还现金的方式：回购股票或派发股息。

## Market impact 市场影响
Buybacks reduce the share count, lift earnings per share and add demand for the stock. They depend on free cash flow and are often paused around earnings. Cutting buybacks is a negative signal.
回购减少股数、提升每股盈利，并增加对股票的需求；取决于自由现金流，且常在财报前后暂停。削减回购是负面信号。

## Related 相关
[[Cash Flow and FCF]], [[Valuation Multiples]], [[Bank Earnings to Market]]

## Example 例子 (illustrative 示意，非真实数据)
A buyback reduces the share count, so EPS can rise even if net income is flat.
回购会减少股数，所以即使净利润不变，每股收益也可能上升。

## Common misconceptions 常见误区
- Buybacks are not always good: value depends on the price paid, how they are funded, and whether they only offset stock-compensation dilution.
- 回购不一定是好事：价值取决于回购价格、资金来源，以及是否只是抵消股权激励带来的稀释。

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- This page defines a concept and describes a possible mechanism; it is not evidence that the mechanism caused a specific market move today.
- For current claims, cite a dated primary source or named data provider. Do not treat historical patterns as laws.
- State the conditions under which the mechanism is stronger or weaker, likely time lag, counterargument and what evidence would falsify the interpretation.
- For current market expectations or positioning, record provider and timestamp; these are not directly observable with certainty.
