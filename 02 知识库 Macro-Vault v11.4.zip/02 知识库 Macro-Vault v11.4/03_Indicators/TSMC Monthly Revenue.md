---
title: "TSMC Monthly Revenue 台积电月度营收"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [台积电月度营收]
tags: [indicators]
---
# TSMC Monthly Revenue 台积电月度营收

## Definition 定义
TSMC reports revenue monthly, around the 10th of the following month.
台积电每月公布营收，大约在次月 10 日前后。

## Market impact 市场影响
An early read on foundry demand and AI chip volumes ahead of quarterly results, with read-across to suppliers.
在季度财报之前，提前反映晶圆代工需求和 AI 芯片出货，并传导到供应商。

## Related 相关
[[Foundry and Advanced Packaging]], [[Global Semiconductor Sales]], [[Read-Across]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [TSMC Investor Relations](https://investor.tsmc.com/english)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Use official monthly revenue release; record TWD units, period, YoY/MoM and whether revenue is preliminary or later reported.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

