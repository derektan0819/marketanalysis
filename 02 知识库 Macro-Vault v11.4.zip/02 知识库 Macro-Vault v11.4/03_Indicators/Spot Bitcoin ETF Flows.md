---
title: "Spot Bitcoin ETF Flows 现货比特币ETF资金流"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [ETF资金流, IBIT资金流]
tags: [indicators]
as_of: 2026-10
---
# Spot Bitcoin ETF Flows 现货比特币ETF资金流

## Definition 定义
Daily net creation or redemption of shares in US spot Bitcoin ETFs, aggregated across funds. Inflows mean net creations; outflows mean net redemptions.
美国现货比特币 ETF 每日净创设或净赎回份额的汇总。流入表示净创设，流出表示净赎回。

## Market impact 市场影响
A rough gauge of institutional and advisor demand. It is better read over several sessions, and together with price, leverage and the data provider. See [[Spot Bitcoin ETFs and Flows]].
是机构和投资顾问需求的粗略指标。最好观察多个交易日，并结合价格、杠杆和数据提供方。见 [[Spot Bitcoin ETFs and Flows]]。

## Related 相关
[[Spot Bitcoin ETFs and Flows]], [[Crypto Assets Overview]], [[Passive Flows and ETFs]], [[Crypto and Macro Linkages]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** Fund issuers' own pages (for example, the issuer of each ETF) and named aggregators; aggregators can differ, so record which one you used.
- **Interpretation guardrail / 解读限制:** Record the trading date and time zone, the provider, and whether the figure covers all funds or a subset. Do not mix providers in one series. Flow figures reported in news can be revised.
- **Current value / 最新值:** Do not store an unsourced 'latest' number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
