---
title: "Stablecoin Supply 稳定币供应量"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [Stablecoin supply, USDT, USDC, 稳定币规模]
tags: [indicators, cross-asset]
as_of: 2026-10
---
# Stablecoin Supply 稳定币供应量

## Definition 定义
The total circulating value of stablecoins, tokens designed to hold a fixed value (usually one US dollar).
稳定币的流通总价值。稳定币是旨在保持固定价值（通常为一美元）的代币。

## Market impact 市场影响
Growth in supply is often read as more cash available to enter crypto markets, and a fall as cash leaving. It is also linked to demand for short-dated US Treasury bills held as reserves. A loss of the one-dollar peg is a stress signal. See [[Stablecoins]].
供应增长通常被理解为有更多现金可进入加密市场，下降则相反。它也与作为储备持有的短期美国国债需求有关。脱离一美元锚定是压力信号。见 [[Stablecoins]]。

## Related 相关
[[Stablecoins]], [[Crypto Assets Overview]], [[Liquidity]], [[Crypto and Macro Linkages]], [[Bitcoin and Ether Price]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** Issuer transparency pages and attestation reports (primary for each issuer); on-chain aggregators such as DefiLlama are secondary.
- **How to record / 记录方法:** Store the exact series or page URL, observation date and time with timezone (use UTC for FX and crypto), provider, units, publication and retrieval timestamps, and the prior value.
- **Interpretation guardrail / 解读限制:** Say which coins are included and whether the figure is circulating supply or reserves. Attestations are not full audits. Supply growth does not prove buying pressure.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus or market-implied expectations only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]], [[Cross-Asset Daily Coverage]].
