---
title: "Copper Price 铜价"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [Copper, Dr. Copper, 铜价]
tags: [indicators, global]
as_of: 2026-10
---
# Copper Price 铜价

## Definition 定义
The price of copper, usually quoted per tonne on the London Metal Exchange (LME) or per pound on COMEX. Copper is widely used in construction, power grids, electronics and electric vehicles.
铜价，通常以伦敦金属交易所（LME）每吨或纽约商品交易所（COMEX）每磅报价。铜广泛用于建筑、电网、电子和电动车。

## Market impact 市场影响
Often read as a gauge of industrial demand and China's activity, and increasingly of electrification and data-centre buildout. Supply disruptions, inventories and tariffs can move it without any change in demand. See [[Commodity Prices]].
常被视为工业需求和中国经济活动的风向标，也与电气化和数据中心建设相关。供应中断、库存和关税也会影响价格。见 [[Commodity Prices]]。

## Related 相关
[[Commodity Prices]], [[China Economy and Policy]], [[China Official PMI and Activity Data]], [[Data Centers and Power]], [[Trade Tariffs and Supply Chains]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** LME and CME Group for prices; International Copper Study Group (ICSG) for market balance data. Links in [[Source Registry]].
- **How to record / 记录方法:** Store the exact series or page URL, observation date, publication and retrieval timestamps, units, frequency, adjustment basis, prior value and revisions.
- **Interpretation guardrail / 解读限制:** Name the exchange, contract month and currency; LME and COMEX prices differ and the gap can reflect tariffs or logistics. Do not treat 'Dr. Copper' as a reliable forecast of recessions.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
