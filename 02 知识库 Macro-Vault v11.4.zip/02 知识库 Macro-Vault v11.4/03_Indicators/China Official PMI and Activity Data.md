---
title: "China Official PMI and Activity Data 中国官方PMI与活动数据"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [China PMI, 中国PMI, 工业增加值]
tags: [indicators, global]
as_of: 2026-10
---
# China Official PMI and Activity Data 中国官方PMI与活动数据

## Definition 定义
Monthly data from China's National Bureau of Statistics: the official manufacturing and non-manufacturing PMI, industrial production, retail sales, fixed-asset investment and property investment. The People's Bank of China publishes credit data such as total social financing.
中国国家统计局发布的月度数据：官方制造业和非制造业 PMI、工业增加值、社会消费品零售总额、固定资产投资和房地产投资。中国人民银行发布社会融资规模等信贷数据。

## Market impact 市场影响
A PMI above 50 signals expansion and below 50 contraction. The data guide expectations for commodity demand, Asian exports and policy stimulus. See [[China Economy and Policy]] and [[Copper Price]].
PMI 高于 50 表示扩张，低于 50 表示收缩。这些数据影响对大宗商品需求、亚洲出口和刺激政策的预期。

## Related 相关
[[China Economy and Policy]], [[China Linkages to US Markets]], [[Copper Price]], [[PMI]], [[USD-CNH]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** National Bureau of Statistics of China and the People's Bank of China. Links in [[Source Registry]].
- **How to record / 记录方法:** Store the exact series or page URL, observation date, publication and retrieval timestamps, units, frequency, adjustment basis, prior value and revisions.
- **Interpretation guardrail / 解读限制:** Official and private-sector PMIs differ in sample and sponsor; name which one and record the provider. Revisions and changes in what is published occur; note the definition used.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
