---
title: "FOMC Projections Dot Plot 美联储点阵图"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [Dot plot, SEP, 点阵图]
tags: [indicators, global]
as_of: 2026-10
---
# FOMC Projections Dot Plot 美联储点阵图

## Definition 定义
The Summary of Economic Projections (SEP), published four times a year after FOMC meetings, includes the 'dot plot' showing each participant's view of the appropriate federal funds rate path, plus projections for growth, unemployment and inflation.
经济预测摘要（SEP）每年四次随联邦公开市场委员会（FOMC）会议公布，其中的点阵图显示每位参与者对适当联邦基金利率路径的看法，并包含增长、失业和通胀预测。

## Market impact 市场影响
Markets compare the median dots with futures pricing ([[Fed Funds Futures]], [[Market-Implied Rate Expectations]]); a gap can move yields and the dollar. The dots are not a commitment.
市场把点阵图中位数与期货定价比较，差距可能影响收益率和美元。点阵图不是承诺。

## Related 相关
[[Fed and FOMC]], [[Federal Funds Rate]], [[Fed Funds Futures]], [[Market-Implied Rate Expectations]], [[Fed Day Playbook]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** Federal Reserve (FOMC projections materials). Links in [[Source Registry]].
- **How to record / 记录方法:** Store the exact series or page URL, observation date, publication and retrieval timestamps, units, frequency, adjustment basis, prior value and revisions.
- **Interpretation guardrail / 解读限制:** Quote the median and the range, with the meeting date. Projections change each quarter and come from individual views, not a committee decision.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
