---
title: "Earnings Estimate Revisions 盈利预测修正"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [盈利预测修正]
tags: [indicators]
---
# Earnings Estimate Revisions 盈利预测修正

## Definition 定义
Changes in analysts' forecasts after results and guidance.
业绩和指引公布后分析师预测的调整。

## Market impact 市场影响
Upward revisions often support a stock's momentum; the direction of revisions matters as much as the level.
上调预测通常支撑股价动能；修正的方向与水平同样重要。

## Related 相关
[[Consensus and Expectations]], [[Guidance]], [[Priced In]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [Named estimates provider required](https://www.sec.gov/edgar/search/)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** SEC filings provide actual results, not sell-side consensus. Record licensed provider, timestamp, metric basis and contributor count; do not infer revisions from news headlines.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

