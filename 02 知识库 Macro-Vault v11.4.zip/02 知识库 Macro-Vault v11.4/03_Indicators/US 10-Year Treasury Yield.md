---
title: "US 10-Year Treasury Yield 美国10年期国债收益率"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [美国10年期国债收益率]
tags: [indicators]
---
# US 10-Year Treasury Yield 美国10年期国债收益率

## Definition 定义
The benchmark long-term US interest rate, widely used to discount future cash flows.
美国长期利率基准，广泛用于对未来现金流折现。

## Market impact 市场影响
Rising yields can pressure valuations, especially for long-duration growth stocks, and can raise global borrowing costs. If yields rise because growth expectations improve, the equity effect can differ from a rise driven by inflation or term premium.
收益率上升会压低估值（尤其是成长股），并推高全球借贷成本。

## Related 相关
[[Yield Curve]], [[Valuation Multiples]], [[Sector Rotation]]
最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]；财政供给 [[Federal Budget and Monthly Treasury Statement]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [US Treasury daily rates](https://home.treasury.gov/resource-center/data-chart-center/interest-rates)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Specify nominal par yield, date and observation time. Do not confuse nominal yield with real yield or market intraday yield.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].


## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Spot Forward and Par Yields|平价、零息和远期收益率]]：官方 10 年收益率不等于某一张债的成交收益率。
- [[21_US_Treasuries/Treasury Data Sources and Definitions|美债数据源、单位与时间口径]]：知识库告诉 AI 去哪里取数，不等于已经接入行情。

## 10 年数据的口径

财政部日度 par curve 基于接近美东下午 3:30 的指示性买方报价等输入拟合，既不是每笔成交的平均值，也不是用户某张国债的可成交 YTM。需要解释新闻后的分钟级变化时，另取同窗口行情。

基准上升 25 bp 与债价下降 25% 完全不同。先拆实际收益率、通胀补偿、政策路径与期限补偿，再讨论估值和融资传导。来源：[财政部曲线方法](https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology)。
