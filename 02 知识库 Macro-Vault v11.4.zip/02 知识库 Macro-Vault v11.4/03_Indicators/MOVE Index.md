---
title: "MOVE Index 美债波动率指数"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [MOVE, 债券波动率]
tags: [indicators, global]
as_of: 2026-10
---
# MOVE Index 美债波动率指数

## Definition 定义
The ICE BofA MOVE Index measures expected volatility of US Treasury yields, based on option-implied volatility. It plays the role for bonds that the VIX plays for equities.
ICE BofA MOVE 指数衡量美债收益率的预期波动，从相关期权价格提取隐含波动。它对债券的作用类似于 VIX 对股票的作用。

## Market impact 市场影响
High readings mean bond markets expect large moves, which can tighten financial conditions and force deleveraging in rate-sensitive positions. See [[Market Volatility and Options Positioning]] and [[VIX]].
读数高表示债市预期大幅波动，可能收紧金融条件，迫使利率敏感头寸去杠杆。

## Related 相关
[[VIX]], [[Market Volatility and Options Positioning]], [[US Treasury Market]], [[Duration and Convexity]], [[Treasury Auctions]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** ICE for the index; confirm access and redistribution terms.
- **How to record / 记录方法:** Store the exact series or page URL, observation date, publication and retrieval timestamps, units, frequency, adjustment basis, prior value and revisions.
- **Interpretation guardrail / 解读限制:** State the date and time of the reading. Compare with its own history, not with VIX levels. A high MOVE does not say which direction yields will move.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Liquidity and Market Structure|美债流动性、交易商与新旧券]]：低信用风险不保证任何时候都能以理想价格成交。
- [[21_US_Treasuries/Treasury Futures and Basis Trade|美债期货、基差交易与杠杆风险]]：理解市场结构，不把基差收敛当成无风险收益。
- [[21_US_Treasuries/Treasury Data Sources and Definitions|美债数据源、单位与时间口径]]：知识库告诉 AI 去哪里取数，不等于已经接入行情。

## 使用时补充

MOVE 表达预期波动幅度，不能判断收益率向上还是向下，也不能直接与 VIX 点数比较。数据可能有收盘或不同盘中频率，引用时写提供方和时间。[ICE 指数说明](https://www.ice.com/fixed-income-data-services/index-solutions/intraday-indices)。融资与去杠杆机制见 [[21_US_Treasuries/Treasury Repo SOFR and Collateral]] 和 [[21_US_Treasuries/Treasury Futures and Basis Trade]]。
