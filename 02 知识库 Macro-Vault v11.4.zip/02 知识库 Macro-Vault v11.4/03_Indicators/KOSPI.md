---
title: "KOSPI 韩国综合股价指数"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [韩国综合指数]
tags: [indicators]
as_of: 2026-10
---
# KOSPI 韩国综合股价指数

## Definition 定义
The main stock index of the Korea Exchange, a market-capitalisation-weighted index of listed Korean companies. KOSDAQ is a separate market and index.
韩国交易所的主要股指，是韩国上市公司的市值加权指数。KOSDAQ 是另一个市场和指数。

## Market impact 市场影响
Because large semiconductor companies carry heavy weight, KOSPI can act as a rough gauge of memory-chip sentiment, but it also reflects the won, foreign flows and non-chip sectors. Compare it with the KRX semiconductor index and with the SOX to see whether a move is chip-specific.
由于大型半导体公司权重很高，KOSPI 可以粗略反映内存芯片的情绪，但它也反映韩元、外资流向和非芯片行业。把它与 KRX 半导体指数和 SOX 对比，可以看出走势是否只是芯片板块的变动。

## Related 相关
[[Korea Market and KOSPI]], [[SOX Index]], [[Index Weighting and Concentration]], [[Market Breadth]], [[Exchange Rate]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [Korea Exchange (KRX)](https://global.krx.co.kr/) (verify the exact page and data terms).
- **Interpretation guardrail / 解读限制:** Specify the exact index, close time (KST), data provider and currency. Index levels quoted by different sites can differ; during research for this vault, index levels from different sources were inconsistent, so no level is recorded here. Record the weights of major constituents with a date.
- **Current value / 最新值:** Do not store an unsourced 'latest' number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
