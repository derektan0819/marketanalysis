---
title: "PCE Inflation PCE通胀"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [PCE通胀]
tags: [indicators]
---
# PCE Inflation PCE通胀

## Definition 定义
The Personal Consumption Expenditures price index, published by the BEA. Core PCE is the inflation measure the Fed emphasises when judging its 2% goal.
个人消费支出价格指数，由 BEA 发布。核心 PCE 是美联储评估 2% 通胀目标时最看重的指标。

## Market impact 市场影响
PCE tends to confirm or modify the message from CPI; a surprise shifts expectations for the Fed.
PCE 通常印证或修正 CPI 传递的信号；出现意外会改变对美联储的预期。

## Related 相关
[[CPI]], [[Fed and FOMC]], [[Inflation]]
最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [BEA PCE price index](https://www.bea.gov/data/personal-consumption-expenditures-price-index)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Monthly; distinguish headline/core, MoM/YoY, nominal PCE versus PCE price index, and revisions.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

