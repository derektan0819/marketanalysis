---
title: "EUR/USD 欧元兑美元"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [EUR/USD, 欧元美元, EURUSD]
tags: [indicators, cross-asset]
as_of: 2026-10
---
# EUR/USD 欧元兑美元

## Definition 定义
The price of one euro in US dollars. It is the most traded currency pair and carries the largest weight in the DXY basket.
一欧元兑多少美元。这是交易量最大的货币对，也是美元指数（DXY）里权重最大的货币。

## Market impact 市场影响
A rising EUR/USD means a weaker dollar against the euro. It reflects the US-euro area rate gap, growth and energy-price differences, and risk sentiment. Because the euro dominates DXY, a DXY move can be mostly a EUR/USD move.
EUR/USD 上升表示美元兑欧元走弱。它反映美欧利差、增长差异、能源价格和风险情绪。由于欧元在 DXY 中占比最大，DXY 的变动往往主要来自 EUR/USD。

## Related 相关
[[DXY]], [[Exchange Rate]], [[Global Central Banks]], [[Federal Funds Rate]], [[Market-Implied Rate Expectations]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** ECB euro reference rates (daily reference, not a tradable quote) and Federal Reserve H.10 (noon New York buying rates); intraday quotes come from a named FX data provider. Links are in [[Source Registry]].
- **How to record / 记录方法:** Store the exact series or page URL, observation date and time with timezone (use UTC for FX and crypto), provider, units, publication and retrieval timestamps, and the prior value.
- **Interpretation guardrail / 解读限制:** State the quote convention (dollars per euro), the provider and the UTC time. ECB reference rates, H.10 rates and live quotes differ because they are taken at different times. Do not say 'the dollar rose' from this pair alone; see [[DXY]].
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus or market-implied expectations only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]], [[Cross-Asset Daily Coverage]].
