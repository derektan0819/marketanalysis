---
title: "Jobless Claims 初请失业金人数"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [初请失业金人数]
tags: [indicators]
---
# Jobless Claims 初请失业金人数

## Definition 定义
Weekly count of new unemployment insurance claims, published on Thursdays by the Department of Labor.
每周新申请失业救济的人数，由劳工部每周四发布。

## Market impact 市场影响
The most timely read on labour-market stress. A sustained rise raises recession worries and rate-cut expectations.
是反映劳动力市场压力最及时的指标。持续上升会引发衰退担忧和降息预期。

## Related 相关
[[Nonfarm Payrolls]], [[Unemployment Rate]], [[JOLTS]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [US Department of Labor UI claims](https://oui.doleta.gov/unemploy/claims.asp)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Weekly; distinguish initial and continuing claims, seasonality, holiday effects and revisions.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

