---
title: "Industrial Production and Capacity Utilization 工业生产与产能利用率"
aliases: [工业生产, 产能利用率, G.17, Industrial Production]
tags: [indicators]
created: 2026-10-27
updated: 2026-10-27
source: "Federal Reserve G.17 Industrial Production and Capacity Utilization https://www.federalreserve.gov/releases/g17/current/default.htm"
verified: 2026-10-27
---
# Industrial Production and Capacity Utilization 工业生产与产能利用率

## Definition 定义
The Federal Reserve's monthly G.17 release measures the real output of US manufacturing, mining, and electric and gas utilities (industrial production), and the share of available capacity in use (capacity utilization).
美联储每月发布的 G.17 统计衡量美国制造业、采矿业和电力燃气公用事业的实际产出（工业生产），以及现有产能被使用的比例（产能利用率）。

## Why it matters 为什么重要
- It is a hard-data check on survey indicators such as the [[PMI]]. 它是对 PMI 等调查数据的“硬数据”核对。
- Manufacturing output tracks the goods cycle, inventories and capital spending ([[Inventory Cycle]], [[Capex Cycle]]). 制造业产出反映商品周期、库存和资本开支。
- High capacity utilization can signal price pressure and a need for new investment; low utilization signals slack. 产能利用率高可能意味着价格压力和扩产需要；低则意味着闲置。

## How to read 怎么读
1. Look at manufacturing first; utilities output swings with the weather and mining with energy prices. 先看制造业；公用事业随天气波动，采矿业随能源价格波动。
2. Compare capacity utilization with its long-run average, which the release states. 把产能利用率与公告给出的长期均值比较。
3. Check revisions to prior months, and note the annual revision, which can rewrite history. 注意前几个月的修正，以及会改写历史数据的年度修订。

## Market impact 市场影响
Stronger output tends to support cyclical sectors such as industrials and materials, and can lift yields if it suggests a firmer economy. A run of declines points to a goods slowdown. Equity markets usually react more to the PMI and earnings than to this release, so treat it as confirmation.
产出走强通常利好工业、原材料等周期板块；若显示经济更强，也可能推高收益率。连续下降则提示商品部门放缓。股市对 PMI 和财报的反应通常大于对本数据的反应，宜作为确认信号使用。

## Related 相关
[[PMI]], [[Business Cycle and Recession]], [[Capex Cycle]], [[Inventory Cycle]], [[Durable Goods Orders]], [[US GDP Report]], [[Industrials and Defense]], [[Materials]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [Federal Reserve G.17](https://www.federalreserve.gov/releases/g17/current/default.htm)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Monthly and revised; one month of utilities or mining output can swing the headline. Industrial output is a minority of the US economy, so it does not measure total growth.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata. The 2026-10-27 reading is in [[12_Data/US Macro Snapshot 2026-10-27]].
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
