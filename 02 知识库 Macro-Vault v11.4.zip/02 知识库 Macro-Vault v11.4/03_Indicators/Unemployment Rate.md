---
title: "Unemployment Rate 失业率"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [失业率]
tags: [indicators]
---
# Unemployment Rate 失业率

## Definition 定义
Share of the labour force that is jobless and seeking work.
失业且正在找工作的人占劳动力的比例。

## Market impact 市场影响
A lagging indicator of the cycle. Rising unemployment hurts consumer spending and loan repayment quality.
属于滞后指标。失业率上升会拖累消费，并影响贷款还款质量。

## Related 相关
[[Nonfarm Payrolls]], [[Retail Sales]], [[GDP]]
最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [BLS Employment Situation](https://www.bls.gov/news.release/empsit.htm)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Monthly household-survey measure; include participation and employment-population ratio for context.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

