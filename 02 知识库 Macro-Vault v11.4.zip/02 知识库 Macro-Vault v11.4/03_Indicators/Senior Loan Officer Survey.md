---
title: "Senior Loan Officer Survey 高级信贷员调查"
aliases: [高级信贷员调查, SLOOS, 银行信贷标准]
tags: [indicators, credit]
created: 2026-10-27
updated: 2026-10-27
source: "Federal Reserve Senior Loan Officer Opinion Survey on Bank Lending Practices https://www.federalreserve.gov/data/sloos.htm"
verified: 2026-10-27
---
# Senior Loan Officer Survey 高级信贷员调查

## Definition 定义
The Federal Reserve's Senior Loan Officer Opinion Survey on Bank Lending Practices (SLOOS) asks up to 80 large domestic banks and 24 US branches and agencies of foreign banks how their lending standards and loan demand have changed. The Fed generally conducts it quarterly.
美联储的高级信贷员意见调查（SLOOS）询问最多 80 家美国大型银行和 24 家外资银行在美分支机构：贷款标准和贷款需求有什么变化。一般每季度一次。

## How to read 怎么读
1. The headline is a **net percentage**: the share of banks reporting tighter standards minus the share reporting easier standards. Positive means tightening on balance. 主要看“净百分比”：报告收紧的银行比例减去报告放松的比例，正数表示整体在收紧。
2. Read business loans (commercial and industrial), commercial real estate and consumer loans separately. 工商业贷款、商业地产贷款和消费贷款分开看。
3. Read standards and demand together: tighter standards with weaker demand is a stronger slowdown signal than either alone. 标准和需求一起看。
4. Special questions in each round often explain why banks are tightening. 每期的专题问题常解释收紧原因。

## Market impact 市场影响
Tighter lending standards usually come before slower loan growth and weaker business investment, and have tended to coincide with wider credit spreads and higher recession risk. Easing standards point the other way. The survey is quarterly and opinion-based, so it shows direction, not the size of the credit change.
贷款标准收紧通常先于贷款增速放缓和企业投资走弱，往往伴随信用利差扩大和衰退风险上升；放松则相反。它按季度、基于主观判断，只说明方向，不说明信贷变化的幅度。

## Related 相关
[[Credit Markets]], [[Credit Spread]], [[IG and HY Credit Spreads]], [[US Banks]], [[Bank Metrics]], [[Private Credit and Shadow Banking]], [[Business Cycle and Recession]], [[Private Credit Stress to Banks and Markets]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [Federal Reserve SLOOS](https://www.federalreserve.gov/data/sloos.htm)
- **How to record / 记录方法:** Store the survey round (for example “July 2026”), release date, loan category, question number, and the net percentage for standards and for demand.
- **Interpretation guardrail / 解读限制:** Large banks only; non-bank and private credit lending are not covered. Responses describe changes over the survey period, not the level of standards.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata. Release dates are tracked in [[12_Data/US Release Calendar 2026-10-27]].
- **Expectation comparison / 预期比较:** No market consensus is normally published for this survey; compare with the prior round.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
