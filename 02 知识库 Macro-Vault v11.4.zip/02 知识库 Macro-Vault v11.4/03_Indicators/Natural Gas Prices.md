---
title: "Natural Gas Prices 天然气价格"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [Henry Hub, TTF, JKM, 天然气价格]
tags: [indicators, global]
as_of: 2026-10
---
# Natural Gas Prices 天然气价格

## Definition 定义
Regional benchmarks for natural gas: Henry Hub (United States), TTF (Europe) and JKM (Asian LNG spot). Gas prices differ by region because transport by ship needs liquefaction.
天然气区域基准：Henry Hub（美国）、TTF（欧洲）和 JKM（亚洲 LNG 现货）。由于海运需要液化，各地价格不同。

## Market impact 市场影响
Gas affects power prices, inflation and industrial costs, especially in Europe and Asia. In the US, power demand and LNG exports link gas to data-centre growth. See [[Energy Oil and Gas]] and [[Data Centers and Power]].
天然气影响电价、通胀和工业成本，对欧洲和亚洲尤为明显。在美国，电力需求和 LNG 出口把天然气与数据中心增长联系起来。

## Related 相关
[[Energy Oil and Gas]], [[Data Centers and Power]], [[Commodity Prices]], [[Euro Area and ECB]], [[Middle East and Oil Exporters]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** EIA weekly natural gas storage report (US); ICE for TTF; IEA for market reports. Links in [[Source Registry]].
- **How to record / 记录方法:** Store the exact series or page URL, observation date, publication and retrieval timestamps, units, frequency, adjustment basis, prior value and revisions.
- **Interpretation guardrail / 解读限制:** Always name the benchmark and units (USD per MMBtu versus EUR per MWh). Weather drives short-term moves, so one cold week does not prove a trend.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
