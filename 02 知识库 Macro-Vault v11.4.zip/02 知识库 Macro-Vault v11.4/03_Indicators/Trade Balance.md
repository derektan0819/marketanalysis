---
title: "Trade Balance 贸易差额"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [贸易差额]
tags: [indicators]
---
# Trade Balance 贸易差额

## Definition 定义
Exports minus imports. The US runs a persistent goods trade deficit; tariffs and the dollar affect trade flows.
出口减进口。美国长期存在商品贸易逆差；关税和美元会影响贸易流向。

## Market impact 市场影响
Tariff changes can alter import prices, corporate margins and inflation, and hit specific sectors such as retailers and manufacturers.
关税变化会改变进口价格、企业利润率和通胀，并冲击零售商和制造商等特定行业。

## Related 相关
[[Export Controls and Tariffs]], [[Exchange Rate]], [[GDP]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [US Census International Trade](https://www.census.gov/foreign-trade/index.html)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Record goods/services coverage, nominal values, seasonal adjustment and revisions; BEA/Census releases may provide complementary tables.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

