---
title: "JOLTS 职位空缺与劳动力流动调查"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [职位空缺与劳动力流动调查]
tags: [indicators]
---
# JOLTS 职位空缺与劳动力流动调查

## Definition 定义
The Job Openings and Labor Turnover Survey from the BLS: openings, hires and quits.
BLS 的职位空缺与劳动力流动调查：空缺数、招聘数和离职数。

## Market impact 市场影响
Shows labour demand and wage pressure. Falling openings with stable layoffs suggest cooling without stress.
反映劳动力需求和工资压力。职位空缺下降而裁员稳定，意味着降温而非恶化。

## Related 相关
[[Nonfarm Payrolls]], [[Jobless Claims]], [[Inflation]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [BLS JOLTS](https://www.bls.gov/jlt/)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Monthly; openings, hires, quits and separations are distinct series and subject to revisions.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

