---
title: "Gold Price 黄金价格"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [Gold price, XAU/USD, 金价, 黄金]
tags: [indicators, cross-asset]
as_of: 2026-10
---
# Gold Price 黄金价格

## Definition 定义
The price of gold, normally in US dollars per troy ounce. Spot gold (XAU/USD) and COMEX futures are different instruments.
黄金价格，通常以美元每盎司计。现货黄金（XAU/USD）与纽约商品交易所（COMEX）期货是不同的品种。

## Market impact 市场影响
Gold often responds to real yields, the dollar, central-bank buying and safe-haven demand, but these can pull in different directions. See [[Gold]] and [[Real Interest Rates]].
黄金常受实际收益率、美元、央行购金和避险需求影响，但这些因素可能方向不同。见 [[Gold]] 和 [[Real Interest Rates]]。

## Related 相关
[[Gold]], [[Real Interest Rates]], [[DXY]], [[Commodity Prices]], [[Risk-On Risk-Off]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** LBMA Gold Price benchmark, the exchange for futures, and World Gold Council for demand data. Links in [[Source Registry]].
- **How to record / 记录方法:** Store the exact series or page URL, observation date and time with timezone (use UTC for FX and crypto), provider, units, publication and retrieval timestamps, and the prior value.
- **Interpretation guardrail / 解读限制:** Name spot or futures, the contract month and the time. A single-aggregator price is `unverified`. Do not state that gold fell because of one factor from same-day co-movement.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus or market-implied expectations only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]], [[Cross-Asset Daily Coverage]].
