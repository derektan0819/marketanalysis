---
title: "Hyperscaler Capex 云巨头资本开支"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [云巨头资本开支]
tags: [indicators]
---
# Hyperscaler Capex 云巨头资本开支

## Definition 定义
Capital spending by large cloud companies, disclosed in quarterly results and earnings calls.
大型云公司的资本开支，在季度业绩和业绩电话会中披露。

## Market impact 市场影响
A major demand signal for AI chips and the data-centre supply chain, though not the only one. Watch changes in guidance, not only actual spending, and check what the spending is allocated to.
是 AI 芯片和数据中心供应链最重要的需求信号。要看指引的变化，而不只是实际支出。

## Related 相关
[[Capex Cycle]], [[Hyperscaler Capex to Chip Chain]], [[AI Value Chain]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [Company Investor Relations and SEC filings](https://www.sec.gov/edgar/search/)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Aggregate only comparable definitions. Separate cash capex, PP&E purchases, finance leases and management-defined infrastructure investment.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

