---
title: "CPI 消费者物价指数"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [消费者物价指数]
tags: [indicators]
---
# CPI 消费者物价指数

## Definition 定义
Measures the average price change of a basket of consumer goods and services, published monthly by the BLS. Core CPI excludes food and energy.
衡量一篮子消费品和服务的平均价格变化，由 BLS 每月发布。核心 CPI 不含食品和能源。

## Market impact 市场影响
A reading above expectations can raise rate-hike expectations, which may push Treasury yields up, bond prices down, pressure growth stocks and lift the dollar. The size of the reaction depends on what was already priced in, the core versus headline split and the Fed's stance (see [[Inflation Surprise Transmission]]).
数据高于预期会推高加息预期：国债收益率上升、债券下跌、成长股承压，美元常常走强。

## Related 相关
[[Inflation]], [[PCE Inflation]], [[PPI]], [[Inflation Surprise Transmission]]
最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [BLS CPI](https://www.bls.gov/cpi/)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Monthly; distinguish headline CPI, core CPI, MoM, YoY, seasonally adjusted and not seasonally adjusted. Record table and release vintage.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

