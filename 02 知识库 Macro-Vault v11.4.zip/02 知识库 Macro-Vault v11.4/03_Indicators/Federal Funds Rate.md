---
title: "Federal Funds Rate 联邦基金利率"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [联邦基金利率]
tags: [indicators]
---
# Federal Funds Rate 联邦基金利率

## Definition 定义
The Fed's target range for overnight lending between banks, set by the FOMC at its eight meetings a year.
美联储对银行间隔夜拆借设定的目标区间，由 FOMC 每年八次会议决定。

## Market impact 市场影响
The anchor for short-term rates and USD funding costs globally. Changes, and especially changes in expected future rates, move Treasury yields, the dollar, equities and credit.
是短期利率和全球美元融资成本的锚。变动，尤其是对未来利率预期的变动，会推动国债收益率、美元、股票和信用债。

## Related 相关
[[Fed and FOMC]], [[Monetary Policy]], [[US Treasury Market]], [[Fed Decision to Markets]]
最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]；会议日程 [[12_Data/US Release Calendar 2026-10-27|发布日历]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [Federal Reserve FOMC](https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Record target range, effective rate if used, decision date and implementation context; these are different series.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].


## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Bills and Discount Yield|短债 Bill 的折价收益率怎么算]]：同一张短债可能显示不同年化收益率，先检查分母和日数。
- [[21_US_Treasuries/Treasury Repo SOFR and Collateral|Repo、SOFR 与美债抵押品]]：美债既是投资品，也是借美元时常用的抵押品。
