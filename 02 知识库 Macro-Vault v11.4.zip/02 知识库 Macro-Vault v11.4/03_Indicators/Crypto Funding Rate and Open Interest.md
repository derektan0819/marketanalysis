---
title: "Crypto Funding Rate and Open Interest 资金费率与未平仓合约"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [Funding rate, Open interest, 资金费率, 未平仓量, perpetual futures]
tags: [indicators, cross-asset]
as_of: 2026-10
---
# Crypto Funding Rate and Open Interest 资金费率与未平仓合约

## Definition 定义
Funding rate is the periodic payment between long and short holders of a perpetual futures contract; it keeps the contract price close to spot. Open interest is the value of contracts still open.
资金费率是永续合约多头和空头之间的定期支付，用来让合约价格贴近现货。未平仓合约是尚未平仓的合约总价值。

## Market impact 市场影响
A high positive funding rate with rising open interest suggests crowded long positions, which raises the risk of liquidation cascades if price falls. Negative funding suggests crowded shorts. These are positioning gauges, not predictions. See [[Crypto Leverage and Liquidations]].
资金费率偏高且未平仓量上升，说明多头拥挤，价格下跌时更容易引发连环爆仓；资金费率为负则说明空头拥挤。它们衡量仓位，不是预测。见 [[Crypto Leverage and Liquidations]]。

## Related 相关
[[Crypto Leverage and Liquidations]], [[Bitcoin and Ether Price]], [[Crypto Assets Overview]], [[Risk-On Risk-Off]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** The derivatives exchange itself, or a named aggregator (for example CoinGlass); record which venues are included.
- **How to record / 记录方法:** Store the exact series or page URL, observation date and time with timezone (use UTC for FX and crypto), provider, units, publication and retrieval timestamps, and the prior value.
- **Interpretation guardrail / 解读限制:** Funding interval (for example every 8 hours or hourly) and units (coin or US dollars) differ by venue. Aggregators can disagree; if they do, mark `Needs Review`. Do not average venues without saying so.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus or market-implied expectations only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]], [[Cross-Asset Daily Coverage]].
