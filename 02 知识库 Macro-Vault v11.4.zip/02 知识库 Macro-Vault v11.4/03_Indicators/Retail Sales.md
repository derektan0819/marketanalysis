---
title: "Retail Sales 零售销售"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [零售销售]
tags: [indicators]
---
# Retail Sales 零售销售

## Definition 定义
Value of sales at retail businesses; a gauge of consumer spending.
零售业销售额，用来衡量消费支出。

## Market impact 市场影响
Consumer spending is a large part of GDP; strong sales help retailers and consumer lenders, but may raise inflation concerns.
消费支出占 GDP 很大比重；销售强劲利好零售和消费信贷，但也可能引发通胀担忧。

## Related 相关
[[GDP]], [[Consumer Confidence]], [[CPI]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [US Census Retail Sales](https://www.census.gov/retail/index.html)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Monthly nominal sales; not inflation-adjusted by default. Identify control group if used and record revisions.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

