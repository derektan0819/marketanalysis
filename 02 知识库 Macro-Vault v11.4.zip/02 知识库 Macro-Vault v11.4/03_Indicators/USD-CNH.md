---
title: "USD/CNH 美元兑离岸人民币"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [USD/CNH, 离岸人民币, USDCNH, CNH]
tags: [indicators, cross-asset]
as_of: 2026-10
---
# USD/CNH 美元兑离岸人民币

## Definition 定义
The price of one US dollar in offshore renminbi (CNH, traded outside mainland China). Onshore renminbi is CNY, which trades in a band around a daily reference rate set by the People's Bank of China.
一美元兑多少离岸人民币（CNH，在中国大陆以外交易）。在岸人民币是 CNY，在中国人民银行每日中间价附近的区间内交易。

## Market impact 市场影响
CNH is a quick read on market views of China growth, China-US relations and capital flows. A gap between CNH and CNY can signal pressure. A weaker renminbi can affect Asian currencies, commodity demand expectations and the competitiveness of regional exporters. See [[China Linkages to US Markets]].
CNH 是市场对中国增长、中美关系和资本流动看法的快速读数。CNH 与 CNY 的价差可能反映压力。人民币走弱会影响亚洲货币、大宗商品需求预期和区域出口商的竞争力。见 [[China Linkages to US Markets]]。

## Related 相关
[[China Linkages to US Markets]], [[Exchange Rate]], [[DXY]], [[Commodity Prices]], [[USD-MYR]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** People's Bank of China and China Foreign Exchange Trade System (CFETS) for the onshore reference rate and official statements; offshore quotes from a named provider. Links in [[Source Registry]].
- **How to record / 记录方法:** Store the exact series or page URL, observation date and time with timezone (use UTC for FX and crypto), provider, units, publication and retrieval timestamps, and the prior value.
- **Interpretation guardrail / 解读限制:** Always say CNH or CNY. They are different markets and can differ for days. The daily reference rate is a policy signal, not a market price. Do not treat a CNH move as a policy change unless an official source says so.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus or market-implied expectations only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]], [[Cross-Asset Daily Coverage]].
