---
title: "Euro Area HICP 欧元区调和CPI"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [HICP, 欧元区通胀]
tags: [indicators, global]
as_of: 2026-10
---
# Euro Area HICP 欧元区调和CPI

## Definition 定义
The Harmonised Index of Consumer Prices, the euro area's main inflation measure, published by Eurostat. A flash estimate comes first, then the full release. The ECB aims for 2% inflation over the medium term.
调和消费者价格指数，由欧盟统计局发布的欧元区主要通胀指标，先公布初值再公布完整数据。欧洲央行的中期通胀目标是 2%。

## Market impact 市场影响
Core HICP (excluding energy, food, alcohol and tobacco) and services inflation guide ECB policy; surprises move euro yields and EUR/USD. See [[Euro Area and ECB]].
剔除能源、食品、酒精和烟草的核心 HICP 和服务业通胀影响欧洲央行政策，意外结果会影响欧元区收益率和 EUR/USD。

## Related 相关
[[Euro Area and ECB]], [[EUR-USD]], [[Inflation]], [[Global Central Banks]], [[CPI]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** Eurostat and the ECB. Links in [[Source Registry]].
- **How to record / 记录方法:** Store the exact series or page URL, observation date, publication and retrieval timestamps, units, frequency, adjustment basis, prior value and revisions.
- **Interpretation guardrail / 解读限制:** Say flash or final, headline or core, and the month. HICP and US CPI use different baskets and methods, so do not compare levels directly.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
