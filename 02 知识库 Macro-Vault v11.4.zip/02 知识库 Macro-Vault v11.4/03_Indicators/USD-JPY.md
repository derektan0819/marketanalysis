---
title: "USD/JPY 美元兑日元"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [USD/JPY, 美元日元, USDJPY]
tags: [indicators, cross-asset]
as_of: 2026-10
---
# USD/JPY 美元兑日元

## Definition 定义
The price of one US dollar in Japanese yen. A higher number means a weaker yen.
一美元兑多少日元。数字越大表示日元越弱。

## Market impact 市场影响
Sensitive to the US-Japan rate gap and to Bank of Japan policy. A weak yen supports Japanese exporters but raises import costs; a sharp yen rise can force carry-trade positions to close and spread to other risk assets. Intervention risk matters near politically sensitive levels. See [[Yen and Carry Trade]].
对美日利差和日本央行政策敏感。日元弱有利日本出口商，但抬高进口成本；日元急升可能迫使套利交易平仓，并波及其他风险资产。接近敏感价位时要留意干预风险。见 [[Yen and Carry Trade]]。

## Related 相关
[[Yen and Carry Trade]], [[Exchange Rate]], [[Global Central Banks]], [[Global Rates Spillover to US Markets]], [[Risk-On Risk-Off]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** Bank of Japan (policy statements and data), Japan Ministry of Finance (official intervention data, published after the fact), Federal Reserve H.10 for official daily rates. Links in [[Source Registry]]; confirm them before use.
- **How to record / 记录方法:** Store the exact series or page URL, observation date and time with timezone (use UTC for FX and crypto), provider, units, publication and retrieval timestamps, and the prior value.
- **Interpretation guardrail / 解读限制:** Quote convention is yen per dollar, the opposite direction from EUR/USD. A level that 'triggers intervention' is a market belief, not a fact; record intervention only after an official source reports it. Moves around Japanese data and policy meetings are conditional, not proof of a single cause.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus or market-implied expectations only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]], [[Cross-Asset Daily Coverage]].
