---
title: "DXY 美元指数"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [美元指数]
tags: [indicators]
---
# DXY 美元指数

## Definition 定义
The US Dollar Index, measuring the dollar against a basket of major currencies.
美元指数，衡量美元兑一篮子主要货币的强弱。

## Market impact 市场影响
A stronger dollar can pressure US multinationals' overseas earnings, USD-priced commodities and emerging markets, but the effect depends on hedging, revenue mix and why the dollar moved.
美元走强会压制美国跨国公司的海外盈利、以美元计价的大宗商品和新兴市场。

## Related 相关
[[Exchange Rate]], [[Strong USD to US Multinationals]], [[Federal Funds Rate]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [ICE US Dollar Index information](https://www.ice.com/products/194/US-Dollar-Index-Futures)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Record instrument/provider and timestamp; DXY is a specific currency basket, not the same as every broad USD index.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

