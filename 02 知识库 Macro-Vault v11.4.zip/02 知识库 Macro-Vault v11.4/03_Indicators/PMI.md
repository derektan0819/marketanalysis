---
title: "PMI 采购经理人指数"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [采购经理人指数]
tags: [indicators]
---
# PMI 采购经理人指数

## Definition 定义
Survey-based indices of business conditions, such as the ISM Manufacturing and Services PMIs and the S&P Global PMIs. Above 50 indicates expansion; below 50 indicates contraction.
基于调查的商业景气指数，例如 ISM 制造业和服务业 PMI 以及 S&P Global PMI。高于 50 代表扩张，低于 50 代表收缩。

## Market impact 市场影响
A timely read on growth. New orders, prices-paid and employment sub-indices add detail on demand, inflation and jobs.
能较早反映增长。新订单、价格和就业分项指数能进一步反映需求、通胀和就业。

## Related 相关
[[GDP]], [[Trade Balance]], [[Sector Rotation]]
2026-10-27 新增相关：[[Industrial Production and Capacity Utilization]]、[[Durable Goods Orders]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [ISM Report on Business](https://www.ismworld.org/supply-management-news-and-reports/reports/ism-report-on-business/)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Name the publisher (ISM or S&P Global), survey and sector. PMI is a diffusion index, not a percent growth rate.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

