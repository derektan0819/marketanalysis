---
title: "Korea Semiconductor Exports 韩国半导体出口"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [韩国出口, 半导体出口]
tags: [indicators]
as_of: 2026-10
---
# Korea Semiconductor Exports 韩国半导体出口

## Definition 定义
Korea publishes monthly trade data, typically on the first day of the following month, and partial-month export figures (for the first 10 and 20 days) during the month. Semiconductor exports are a closely watched line.
韩国按月公布贸易数据，通常在次月1日发布，月内还会公布前10天和前20天的出口数据。半导体出口是备受关注的项目。

## Market impact 市场影响
Strong chip exports can signal rising memory prices or volumes before company earnings arrive, so they can feed expectations for Samsung, SK Hynix and US memory makers. Weak data can raise questions about pricing or demand. Prices and volumes need to be separated.
芯片出口强劲可能在公司财报之前就显示内存价格或出货量上升，因此会影响市场对三星、SK 海力士和美国内存厂商的预期。数据疲弱则会引发对价格或需求的疑问。需要把价格与数量区分开。

## Related 相关
[[Korea Market and KOSPI]], [[DRAM Contract Prices]], [[Global Semiconductor Sales]], [[Memory Price Cycle]], [[Trade Balance]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** Korea Customs Service and Ministry of Trade, Industry and Energy (verify the current release pages and calendar).
- **Interpretation guardrail / 解读限制:** Check whether the figure is value or volume, the number of working days (the partial-month data is affected by calendar days), and whether it is year-over-year. The release calendar and revisions should be recorded.
- **Current value / 最新值:** Do not store an unsourced 'latest' number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
