---
title: "SOX Index 费城半导体指数"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [费城半导体指数]
tags: [indicators]
---
# SOX Index 费城半导体指数

## Definition 定义
The PHLX Semiconductor Index (SOX) tracks large US-listed semiconductor companies.
费城半导体指数（SOX）追踪美国上市的大型半导体公司。

## Market impact 市场影响
A quick gauge of chip sentiment, but heavily influenced by a few large names; read it together with breadth.
可快速反映芯片板块情绪，但受少数大公司影响很大，需结合广度一起看。

## Related 相关
[[Semiconductors]], [[Sector Rotation]], [[Chip Earnings to AI Stocks]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [Nasdaq Indexes](https://indexes.nasdaqomx.com/)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Verify exact index name, methodology, constituents and dated level. Index constituents/weights change.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].



See also: [[KOSPI]], [[Korea Memory Stocks and US Chip Stocks]]
