---
title: "Bitcoin and Ether Price 比特币与以太币价格"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [BTC, ETH, 比特币价格, 以太币价格, BTC ETH price]
tags: [indicators, cross-asset]
as_of: 2026-10
---
# Bitcoin and Ether Price 比特币与以太币价格

## Definition 定义
The market price of Bitcoin (BTC) and Ether (ETH), usually quoted in US dollars. Crypto trades 24 hours a day, every day, and different venues show slightly different prices.
比特币（BTC）和以太币（ETH）的市场价格，通常以美元计价。加密市场全天候交易，不同交易所的价格略有差异。

## Market impact 市场影响
A fast read on risk appetite and liquidity, especially around weekends when other markets are closed. Large moves are often amplified by leverage; see [[Crypto Leverage and Liquidations]]. Whether crypto moves with US equities or against them changes over time; see [[Crypto and Macro Linkages]].
快速反映风险偏好和流动性，尤其是其他市场休市的周末。大幅波动常被杠杆放大，见 [[Crypto Leverage and Liquidations]]。加密与美股是同向还是反向会随时间变化，见 [[Crypto and Macro Linkages]]。

## Related 相关
[[Crypto Assets Overview]], [[Crypto Leverage and Liquidations]], [[Spot Bitcoin ETF Flows]], [[Crypto and Macro Linkages]], [[Crypto Sentiment to US Equities]], [[Stablecoin Supply]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** A named reference-rate or index provider (for example CF Benchmarks or CoinGecko) or a named exchange; record which one. These are secondary data providers, not primary sources.
- **How to record / 记录方法:** Store the exact series or page URL, observation date and time with timezone (use UTC for FX and crypto), provider, units, publication and retrieval timestamps, and the prior value.
- **Interpretation guardrail / 解读限制:** There is no official close. Write the time in UTC and the convention used (for example the 00:00 UTC daily close). Last-trade price, index price and ETF price differ. Do not compare two providers in one series.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus or market-implied expectations only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]], [[Cross-Asset Daily Coverage]].
