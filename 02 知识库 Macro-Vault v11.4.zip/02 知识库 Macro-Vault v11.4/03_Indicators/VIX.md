---
title: "VIX 恐慌指数"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [恐慌指数]
tags: [indicators]
---
# VIX 恐慌指数

## Definition 定义
The CBOE Volatility Index, based on implied volatility of S&P 500 options.
CBOE 波动率指数，基于标普 500 期权的隐含波动率。

## Market impact 市场影响
High or spiking levels often coincide with fear and risk-off conditions; very low levels can coincide with complacency. Neither is a reliable timing signal on its own.
数值很高或飙升代表恐慌和避险；非常低则可能代表市场过于自满。

## Related 相关
[[Risk-On Risk-Off]], [[Liquidity]], [[DXY]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [Cboe VIX](https://www.cboe.com/tradable_products/vix/)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** VIX is options-implied expected volatility over a defined horizon, not direction or a guaranteed maximum move.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

