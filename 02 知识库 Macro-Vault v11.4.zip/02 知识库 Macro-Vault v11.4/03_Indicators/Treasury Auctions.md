---
title: "Treasury Auctions 国债拍卖"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [Bid-to-cover, tail, 国债拍卖, refunding]
tags: [indicators, global]
as_of: 2026-10
---
# Treasury Auctions 国债拍卖

## Definition 定义
Regular sales of US Treasury securities. Key measures are the bid-to-cover ratio, the tail (how far the result differs from the pre-auction yield) and the split between direct, indirect and primary-dealer buyers.
美国国债的定期发行。关键指标有投标倍数、尾差（结果与拍卖前收益率的差距）以及直接、间接和一级交易商的购买比例。

## Market impact 市场影响
Weak demand (a large tail, low bid-to-cover) can push yields higher; strong demand eases them. The quarterly refunding statement shows planned supply. See [[Sovereign Debt and Fiscal Sustainability]] and [[Term Premium]].
需求弱（尾差大、投标倍数低）会推高收益率，需求强则相反。季度再融资声明显示计划发行量。

## Related 相关
[[US Treasury Market]], [[Sovereign Debt and Fiscal Sustainability]], [[Term Premium]], [[US 10-Year Treasury Yield]], [[MOVE Index]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** US Treasury (TreasuryDirect auction results and quarterly refunding statements). Links in [[Source Registry]].
- **How to record / 记录方法:** Store the exact series or page URL, observation date, publication and retrieval timestamps, units, frequency, adjustment basis, prior value and revisions.
- **Interpretation guardrail / 解读限制:** Compare an auction with its own recent history and size; one auction is noisy. Do not claim a 'failed auction' unless the official results show it.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Clean Price and Settlement|净价、全价、应计利息与结算]]：报价不是最终扣款，先把价格和利息拆开。
- [[21_US_Treasuries/Treasury Supply Refunding and Buybacks|发行、季度再融资与财政部回购]]：不仅看发多少债，还要看期限、到期偿还与谁来承接。
- [[21_US_Treasuries/Treasury Holders and TIC|谁持有美债：TIC 与买家结构]]：持仓减少未必等于抛售，间接投标者也不等于外国政府。
- [[21_US_Treasuries/Treasury Data Sources and Definitions|美债数据源、单位与时间口径]]：知识库告诉 AI 去哪里取数，不等于已经接入行情。
- [[21_US_Treasuries/Treasury Misconceptions|美债常见误区检查表]]：生成结论前，先排除这些看似合理的错误。

## 怎样读拍卖结果，不把信号说反

发行公告列出证券、规模和日期；非竞争性投标接受最终拍卖利率，竞争性投标参与决定结果。成功投标者按统一拍卖结果定价，Bills 看贴现率、固定票息券看收益率、FRN 看相应贴现利差口径；不同债种不能混着比较。

对常见附息券，tail 通常指最终最高接受收益率高于拍卖截止前相应 when-issued（WI，发行前交易）收益率的差额；低于 WI 常称 stop-through。必须记录 WI 提供方与精确时间。假设最终为 4.25%、WI 为 4.23%，tail 是 +2 bp，不是 +0.02 bp；没有 WI 数据就标记无法计算。

Bid-to-cover 是投标金额与接受金额的比值，受投标策略和发行规模影响。要与同期限、同类型的近期拍卖比较，结合 tail、交易商承接份额与拍后价格，不能凭一次低倍数宣布“没人买”或“拍卖失败”。间接投标者也不等于外国央行。

若最终需求弱于此前定价，交易商可能需要承接更多库存并调整对冲，价格压力可在短期出现；但供给压力若早已被定价，拍后也可能反弹。长期结论应结合多次结果和净发行结构。

来源：[TreasuryDirect 拍卖流程](https://www.treasurydirect.gov/auctions/how-auctions-work/)。WI 属市场报价，需要额外取得对应时点证据。
