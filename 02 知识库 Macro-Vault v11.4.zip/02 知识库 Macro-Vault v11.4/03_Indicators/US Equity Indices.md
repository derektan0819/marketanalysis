---
title: "US Equity Indices 美国股指"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [美国股指]
tags: [indicators]
---
# US Equity Indices 美国股指

## Definition 定义
The S&P 500 (about 500 large US companies, market-cap weighted), the Nasdaq Composite and Nasdaq-100 (tech-heavy) and the Dow Jones Industrial Average (30 stocks, price-weighted).
标普 500（约 500 家美国大公司，市值加权）、纳斯达克综合指数和纳斯达克 100（科技股占比高）、道琼斯工业平均指数（30 只股票，价格加权）。

## Market impact 市场影响
The S&P 500 is the main benchmark for the US market. Compare it with the equal-weight version and the Nasdaq to see whether moves are broad or tech-driven.
标普 500 是美国市场的主要基准。与等权版本和纳斯达克比较，可看出走势是普涨还是由科技股驱动。

## Related 相关
[[Index Weighting and Concentration]], [[Market Breadth]], [[SOX Index]]
最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [Official index provider](https://www.spglobal.com/spdji/)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Specify exact index, price/total-return variant, close timestamp, currency and provider. Index weights must be dated.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

