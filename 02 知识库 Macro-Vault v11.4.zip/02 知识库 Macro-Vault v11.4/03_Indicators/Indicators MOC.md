---
title: "Indicators MOC — 经济与市场指标"
tags: [index, moc]
created: 2026-10-27
updated: 2026-10-27
source: "自动整理：完整列出 03_Indicators 的全部文件（2026-10-27）"
---

# Indicators MOC — 经济与市场指标

[[00_Index/Master Index|总索引]] · [[HOME|首页]]

本文件夹共 53 个文件，其中笔记 53 篇。以下按路径完整列出，笔记显示标题。

## 先读

- [[03_Indicators/Case-Shiller Home Price Index|Case-Shiller Home Price Index 凯斯-席勒房价指数]]
- [[03_Indicators/Employment Cost Index|Employment Cost Index 就业成本指数]]
- [[03_Indicators/MOVE Index|MOVE Index 美债波动率指数]]
- [[03_Indicators/SOX Index|SOX Index 费城半导体指数]]

## 笔记

- [[03_Indicators/Bitcoin and Ether Price|Bitcoin and Ether Price 比特币与以太币价格]]
- [[03_Indicators/CPI|CPI 消费者物价指数]]
- [[03_Indicators/Case-Shiller Home Price Index|Case-Shiller Home Price Index 凯斯-席勒房价指数]]
- [[03_Indicators/China Official PMI and Activity Data|China Official PMI and Activity Data 中国官方PMI与活动数据]]
- [[03_Indicators/Consumer Confidence|Consumer Confidence 消费者信心]]
- [[03_Indicators/Copper Price|Copper Price 铜价]]
- [[03_Indicators/Crypto Funding Rate and Open Interest|Crypto Funding Rate and Open Interest 资金费率与未平仓合约]]
- [[03_Indicators/DRAM Contract Prices|DRAM Contract Prices DRAM 合约价]]
- [[03_Indicators/DXY|DXY 美元指数]]
- [[03_Indicators/Durable Goods Orders|Durable Goods Orders 耐用品订单]]
- [[03_Indicators/EUR-USD|EUR/USD 欧元兑美元]]
- [[03_Indicators/Earnings Estimate Revisions|Earnings Estimate Revisions 盈利预测修正]]
- [[03_Indicators/Employment Cost Index|Employment Cost Index 就业成本指数]]
- [[03_Indicators/Euro Area HICP|Euro Area HICP 欧元区调和CPI]]
- [[03_Indicators/FOMC Projections Dot Plot|FOMC Projections Dot Plot 美联储点阵图]]
- [[03_Indicators/Fed Funds Futures|Fed Funds Futures 联邦基金利率期货]]
- [[03_Indicators/Federal Budget and Monthly Treasury Statement|Federal Budget and Monthly Treasury Statement 联邦预算与月度财政报表]]
- [[03_Indicators/Federal Funds Rate|Federal Funds Rate 联邦基金利率]]
- [[03_Indicators/Global Equity Indices|Global Equity Indices 全球股指]]
- [[03_Indicators/Global Semiconductor Sales|Global Semiconductor Sales 全球半导体销售额]]
- [[03_Indicators/Gold Price|Gold Price 黄金价格]]
- [[03_Indicators/Housing Starts|Housing Starts 新屋开工]]
- [[03_Indicators/Hyperscaler Capex|Hyperscaler Capex 云巨头资本开支]]
- [[03_Indicators/IG and HY Credit Spreads|IG and HY Credit Spreads 投资级与高收益信用利差]]
- [[03_Indicators/Industrial Production and Capacity Utilization|Industrial Production and Capacity Utilization 工业生产与产能利用率]]
- [[03_Indicators/JOLTS|JOLTS 职位空缺与劳动力流动调查]]
- [[03_Indicators/Japan CPI and Tankan|Japan CPI and Tankan 日本CPI与短观]]
- [[03_Indicators/Jobless Claims|Jobless Claims 初请失业金人数]]
- [[03_Indicators/KOSPI|KOSPI 韩国综合股价指数]]
- [[03_Indicators/Korea Semiconductor Exports|Korea Semiconductor Exports 韩国半导体出口]]
- [[03_Indicators/MOVE Index|MOVE Index 美债波动率指数]]
- [[03_Indicators/Natural Gas Prices|Natural Gas Prices 天然气价格]]
- [[03_Indicators/Nonfarm Payrolls|Nonfarm Payrolls 非农就业]]
- [[03_Indicators/PCE Inflation|PCE Inflation PCE通胀]]
- [[03_Indicators/PMI|PMI 采购经理人指数]]
- [[03_Indicators/PPI|PPI 生产者物价指数]]
- [[03_Indicators/Retail Sales|Retail Sales 零售销售]]
- [[03_Indicators/SOX Index|SOX Index 费城半导体指数]]
- [[03_Indicators/Senior Loan Officer Survey|Senior Loan Officer Survey 高级信贷员调查]]
- [[03_Indicators/Spot Bitcoin ETF Flows|Spot Bitcoin ETF Flows 现货比特币ETF资金流]]
- [[03_Indicators/Stablecoin Supply|Stablecoin Supply 稳定币供应量]]
- [[03_Indicators/TSMC Monthly Revenue|TSMC Monthly Revenue 台积电月度营收]]
- [[03_Indicators/Trade Balance|Trade Balance 贸易差额]]
- [[03_Indicators/Treasury Auctions|Treasury Auctions 国债拍卖]]
- [[03_Indicators/US 10-Year Treasury Yield|US 10-Year Treasury Yield 美国10年期国债收益率]]
- [[03_Indicators/US Equity Indices|US Equity Indices 美国股指]]
- [[03_Indicators/US GDP Report|US GDP Report 美国GDP报告]]
- [[03_Indicators/USD-CNH|USD/CNH 美元兑离岸人民币]]
- [[03_Indicators/USD-JPY|USD/JPY 美元兑日元]]
- [[03_Indicators/USD-MYR|USD/MYR 美元兑马来西亚令吉]]
- [[03_Indicators/Unemployment Rate|Unemployment Rate 失业率]]
- [[03_Indicators/VIX|VIX 恐慌指数]]
- [[03_Indicators/WTI and Brent Crude|WTI and Brent Crude 原油价格]]
