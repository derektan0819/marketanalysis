---
title: "US GDP Report 美国GDP报告"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [美国GDP报告]
tags: [indicators]
---
# US GDP Report 美国GDP报告

## Definition 定义
The BEA publishes advance, second and third estimates of quarterly GDP, split into consumption, investment, government spending and net exports.
BEA 发布季度 GDP 的初值、二次估值和三次估值，分为消费、投资、政府支出和净出口。

## Market impact 市场影响
Details matter more than the headline: consumer spending strength, business investment and revisions change the growth and rate outlook.
细节比总数更重要：消费强度、企业投资和修正值会改变增长和利率前景。

## Related 相关
[[GDP]], [[Retail Sales]], [[US Consumer and Housing]]
最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]；相关指标 [[Durable Goods Orders]]、[[Industrial Production and Capacity Utilization]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [BEA GDP](https://www.bea.gov/data/gdp/gross-domestic-product)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Quarterly; annualized QoQ growth differs from YoY growth; advance/second/third estimates can be revised.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

