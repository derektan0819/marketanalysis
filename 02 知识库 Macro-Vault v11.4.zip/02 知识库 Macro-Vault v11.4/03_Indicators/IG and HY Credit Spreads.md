---
title: "IG and HY Credit Spreads 投资级与高收益信用利差"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [OAS, 信用利差, credit spreads]
tags: [indicators, global]
as_of: 2026-10
---
# IG and HY Credit Spreads 投资级与高收益信用利差

## Definition 定义
The option-adjusted spread (OAS) of investment-grade (IG) and high-yield (HY) corporate bonds over comparable Treasuries.
投资级（IG）和高收益（HY）公司债相对同期限国债的期权调整利差（OAS）。

## Market impact 市场影响
Widening spreads show investors asking for more compensation for credit risk and often come before or with equity stress; tight spreads show confidence. HY reacts more than IG. See [[Credit Spread]] and [[Credit Markets]].
利差扩大说明投资者要求更高的信用风险补偿，常先于或伴随股市压力；利差收窄表示信心。高收益比投资级反应更大。

## Related 相关
[[Credit Spread]], [[Credit Markets]], [[Private Credit and Shadow Banking]], [[Risk-On Risk-Off]], [[US Banks]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** ICE index data (often shown through FRED) and bond-index providers. Check the provider's redistribution terms.
- **How to record / 记录方法:** Store the exact series or page URL, observation date, publication and retrieval timestamps, units, frequency, adjustment basis, prior value and revisions.
- **Interpretation guardrail / 解读限制:** Name the index and provider; they differ in composition. Spread level depends on ratings mix and duration, so compare like with like. Do not read one day's move as a regime change.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
