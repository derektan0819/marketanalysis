---
title: "Global Equity Indices 全球股指"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [Nikkei 225, Hang Seng, Shanghai Composite, Euro Stoxx 50, FBM KLCI, 全球股指, 富时马来西亚综合指数]
tags: [indicators, cross-asset]
as_of: 2026-10
---
# Global Equity Indices 全球股指

## Definition 定义
Major non-US stock indices: Nikkei 225 (Japan), Hang Seng (Hong Kong), Shanghai Composite (China), Euro Stoxx 50 (euro area) and FTSE Bursa Malaysia KLCI (Malaysia). KOSPI has its own note.
主要的非美国股指：日经225（日本）、恒生指数（香港）、上证综指（中国）、欧洲斯托克50（欧元区）和富时马来西亚综合指数 FBM KLCI（马来西亚）。韩国 KOSPI 另有笔记。

## Market impact 市场影响
Asian markets close before the US opens, so they react to the previous US session; European markets overlap with the US. Differences between markets help separate global moves from local ones. See [[KOSPI]] and [[Korea Market and KOSPI]].
亚洲市场在美股开盘前收盘，所以反映的是前一个美股交易日；欧洲市场与美股交易时间重叠。比较各市场有助于区分全球性波动与本地因素。见 [[KOSPI]] 和 [[Korea Market and KOSPI]]。

## Related 相关
[[KOSPI]], [[Korea Market and KOSPI]], [[China Linkages to US Markets]], [[Global Rates Spillover to US Markets]], [[US Equity Indices]], [[Malaysia Banking Sector]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** The index provider or exchange (for example Bursa Malaysia, Japan Exchange Group, HKEX) for official closes. Links in [[Source Registry]].
- **How to record / 记录方法:** Store the exact series or page URL, observation date and time with timezone (use UTC for FX and crypto), provider, units, publication and retrieval timestamps, and the prior value.
- **Interpretation guardrail / 解读限制:** State the market's local close time and convert to one timezone. Public holidays differ, so a missing session is not a zero move. Index composition changes; record the index, not just the country.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus or market-implied expectations only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]], [[Cross-Asset Daily Coverage]].
