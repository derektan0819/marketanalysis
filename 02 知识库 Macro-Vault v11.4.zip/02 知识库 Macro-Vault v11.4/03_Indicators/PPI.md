---
title: "PPI 生产者物价指数"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [生产者物价指数]
tags: [indicators]
---
# PPI 生产者物价指数

## Definition 定义
Measures prices received by producers. Often a leading signal for consumer prices.
衡量生产者出售商品的价格，常是消费者物价的领先信号。

## Market impact 市场影响
Rising PPI can squeeze margins if firms cannot pass costs on, and may foreshadow higher CPI, though the pass-through is uneven and lagged.
PPI 上升时，若企业无法转嫁成本，利润率会被压缩，也可能预示 CPI 上升。

## Related 相关
[[CPI]], [[Inflation]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [BLS PPI](https://www.bls.gov/ppi/)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Monthly producer-price measures; do not assume PPI mechanically predicts consumer inflation.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

