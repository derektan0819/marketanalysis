---
title: "WTI and Brent Crude 原油价格"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [WTI, Brent, 原油, 油价, crude oil]
tags: [indicators, cross-asset]
as_of: 2026-10
---
# WTI and Brent Crude 原油价格

## Definition 定义
WTI is the US benchmark crude (delivered at Cushing, Oklahoma); Brent is the international benchmark. Both are usually quoted as the front-month futures contract in US dollars per barrel.
WTI 是美国基准原油（在俄克拉荷马州库欣交割），布伦特是国际基准。两者通常以近月期货合约的美元每桶报价。

## Market impact 市场影响
Oil feeds headline inflation, energy-company earnings and trade balances, and shifts rate and currency expectations. See [[Oil Price Transmission]] and [[Inflation Surprise Transmission]].
油价影响整体通胀、能源公司盈利和贸易差额，并改变利率和汇率预期。见 [[Oil Price Transmission]] 和 [[Inflation Surprise Transmission]]。

## Related 相关
[[Oil Price Transmission]], [[Commodity Prices]], [[Inflation Surprise Transmission]], [[Geopolitics and Export Controls]], [[USD-MYR]]
最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** EIA and IEA for inventories and market reports; the exchange or a named data provider for prices. Links in [[Source Registry]].
- **How to record / 记录方法:** Store the exact series or page URL, observation date and time with timezone (use UTC for FX and crypto), provider, units, publication and retrieval timestamps, and the prior value.
- **Interpretation guardrail / 解读限制:** Name the contract month; the front-month rolls and can create a false jump. WTI and Brent can move differently, so do not use one for the other. Headlines on supply routes are conditional and can reverse.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus or market-implied expectations only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]], [[Cross-Asset Daily Coverage]].
