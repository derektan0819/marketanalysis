---
title: "Global Semiconductor Sales 全球半导体销售额"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [全球半导体销售额]
tags: [indicators]
---
# Global Semiconductor Sales 全球半导体销售额

## Definition 定义
Monthly global chip sales published by the SIA, based on WSTS data.
由 SIA 根据 WSTS 数据发布的每月全球芯片销售额。

## Market impact 市场影响
Shows the industry cycle and regional and segment trends; useful to confirm whether a turn is broad or limited to AI.
显示行业周期以及地区和细分趋势，可用来判断转折是全面性的还是只集中在 AI。

## Related 相关
[[Semiconductors]], [[Inventory Cycle]], [[TSMC Monthly Revenue]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [SIA / WSTS](https://www.semiconductors.org/)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Use dated release; record regional scope, monthly/quarterly basis, currency, rolling averages and forecast versus actual.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

