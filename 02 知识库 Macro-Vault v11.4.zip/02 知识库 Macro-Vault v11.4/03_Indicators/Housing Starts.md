---
title: "Housing Starts 新屋开工"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [新屋开工]
tags: [indicators]
as_of: 2026-10
---
# Housing Starts 新屋开工

## Definition 定义
A monthly report on new residential construction: housing starts, building permits and completions. Published by the US Census Bureau (jointly with HUD).
关于新建住宅的月度报告：新屋开工、建筑许可和竣工。由美国人口普查局（与住房和城市发展部联合）发布。

## Market impact 市场影响
Mortgage rates affect affordability and builder activity. Weak starts and permits can signal slowing housing demand; builders, building materials and housing-related lenders are most sensitive. Permits tend to lead starts.
抵押贷款利率影响购房负担和建筑商的动作。开工和许可走弱可能预示住房需求放缓；建筑商、建材和住房相关贷款机构最敏感。建筑许可通常领先开工。

## Related 相关
[[US Consumer and Housing]], [[Interest Rates]], [[Retail Sales]], [[US Banks]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** US Census Bureau new residential construction release (verify the current page).
- **Interpretation guardrail / 解读限制:** Monthly data is volatile and revised; check single-family versus multi-family, seasonally adjusted annual rate, and the revision to the prior month.
- **Current value / 最新值:** Do not store an unsourced 'latest' number here. Put dated observations in `12_Data` or a dated report.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
