---
title: "Japan CPI and Tankan 日本CPI与短观"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [Tankan, 日本CPI, 短观调查]
tags: [indicators, global]
as_of: 2026-10
---
# Japan CPI and Tankan 日本CPI与短观

## Definition 定义
Japan's consumer price index (published by the Statistics Bureau, with core excluding fresh food) and the Bank of Japan's quarterly Tankan survey of business conditions, expressed as a diffusion index.
日本消费者物价指数（由统计局发布，核心指数剔除生鲜食品）和日本央行每季度发布的企业短观调查（以扩散指数表示）。

## Market impact 市场影响
Inflation and wage trends shape BoJ rate decisions; the yen reacts to changes in the expected path. See [[Japan Economy and BoJ]] and [[Yen and Carry Trade]].
通胀和工资走势影响日本央行利率决策，日元对预期路径变化敏感。

## Related 相关
[[Japan Economy and BoJ]], [[Yen and Carry Trade]], [[USD-JPY]], [[Global Central Banks]], [[Inflation]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** Statistics Bureau of Japan and the Bank of Japan. Links in [[Source Registry]].
- **How to record / 记录方法:** Store the exact series or page URL, observation date, publication and retrieval timestamps, units, frequency, adjustment basis, prior value and revisions.
- **Interpretation guardrail / 解读限制:** Specify the CPI variant (headline, core, core-core). Diffusion index equals the share of positive answers minus negative answers, not a growth rate.
- **Current value / 最新值:** Do not store an unsourced "latest" number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp; otherwise mark the comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
