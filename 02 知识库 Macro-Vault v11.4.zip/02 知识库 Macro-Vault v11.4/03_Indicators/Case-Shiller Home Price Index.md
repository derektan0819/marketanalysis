---
title: "Case-Shiller Home Price Index 凯斯-席勒房价指数"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [凯斯-席勒房价指数, Case-Shiller]
tags: [indicators]
as_of: 2026-10
---
# Case-Shiller Home Price Index 凯斯-席勒房价指数

## Definition 定义
A home price index published by S&P Dow Jones Indices, built from repeat sales of the same homes. The national index and 20-city composite are widely followed. The FHFA House Price Index is an alternative measure.
由 S&P Dow Jones Indices 发布的房价指数，基于同一房屋的重复销售数据。全国指数和20城综合指数被广泛关注。FHFA 房价指数是另一种衡量方式。

## Market impact 市场影响
Home prices drive household wealth, mortgage credit quality and consumer confidence. Falling prices can raise concerns about bank loan losses and consumer spending. The index is a lagging indicator.
房价影响家庭财富、抵押贷款质量和消费者信心。房价下跌可能引发对银行贷款损失和消费的担忧。该指数是滞后指标。

## Related 相关
[[US Consumer and Housing]], [[Interest Rates]], [[Retail Sales]], [[US Banks]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** S&P Dow Jones Indices release, or the FRED series page (verify the exact series).
- **Interpretation guardrail / 解读限制:** It is reported with a lag and uses a three-month moving average, so it reflects sales from earlier months. Distinguish national versus 20-city and seasonally adjusted versus not.
- **Current value / 最新值:** Do not store an unsourced 'latest' number here.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
