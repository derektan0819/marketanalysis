---
title: "Durable Goods Orders 耐用品订单"
aliases: [耐用品订单, 核心资本品订单, Core Capital Goods Orders]
tags: [indicators]
created: 2026-10-27
updated: 2026-10-27
source: "U.S. Census Bureau Manufacturers' Shipments, Inventories, and Orders (M3) https://www.census.gov/manufacturing/m3/index.html；系列口径经 FRED DGORDER / NEWORDER 核对"
verified: 2026-10-27
---
# Durable Goods Orders 耐用品订单

## Definition 定义
The Census Bureau's monthly M3 survey reports new orders, shipments and inventories of manufactured goods. The advance durable goods report covers goods meant to last three years or more, such as machinery, computers, vehicles and aircraft.
美国人口普查局每月的 M3 调查公布制造业新订单、出货和库存。耐用品预告报告覆盖预计使用三年以上的商品，如机械、电脑、汽车和飞机。

## How to read 怎么读
1. The headline swings with aircraft orders, which arrive in large, irregular batches. Look first at orders excluding transportation. 总数受大额、不规则的飞机订单影响大，先看剔除运输设备后的订单。
2. **Core capital goods orders** (nondefense capital goods excluding aircraft) are the usual proxy for business equipment investment plans. **核心资本品订单**（非国防、不含飞机）常用来代表企业设备投资计划。
3. Core capital goods **shipments** feed into the equipment-investment estimate in GDP ([[US GDP Report]]). 核心资本品**出货**会进入 GDP 的设备投资估算。
4. Use three-month averages and check revisions; the advance report is revised in the full M3 release. 用三个月平均并检查修正；预告值会在完整 M3 报告中修正。

## Market impact 市场影响
Rising core orders suggest companies are committing to capital spending, which supports industrials, machinery makers and parts of the technology supply chain ([[Capex Cycle]], [[Hyperscaler Capex to Chip Chain]]). Falling orders point to caution. Orders are in nominal dollars, so part of a rise can be higher prices rather than more equipment.
核心订单上升说明企业在落实资本开支，利好工业、机械和部分科技供应链；下降则提示企业谨慎。订单以名义美元计，增长的一部分可能来自涨价而非设备数量增加。

## Related 相关
[[Capex Cycle]], [[Industrial Production and Capacity Utilization]], [[PMI]], [[Industrials and Defense]], [[Business Cycle and Recession]], [[Hyperscaler Capex]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [Census M3](https://www.census.gov/manufacturing/m3/index.html) · series on FRED: [DGORDER](https://fred.stlouisfed.org/series/DGORDER) (durable goods new orders), [NEWORDER](https://fred.stlouisfed.org/series/NEWORDER) (core capital goods new orders)
- **How to record / 记录方法:** Store the exact release or series URL, observation month, publication/retrieval timestamps, units (millions of dollars, seasonally adjusted), prior value and revisions.
- **Interpretation guardrail / 解读限制:** Nominal, volatile and revised; one aircraft order can dominate the headline. Census's site could not be reached on 2026-10-27, so the series definitions were checked on FRED, which cites the M3 survey.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata. The 2026-10-27 reading is in [[12_Data/US Macro Snapshot 2026-10-27]].
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
