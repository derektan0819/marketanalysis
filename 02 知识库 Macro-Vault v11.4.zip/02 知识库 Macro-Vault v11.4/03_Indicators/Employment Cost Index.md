---
title: "Employment Cost Index 就业成本指数"
aliases: [就业成本指数, ECI]
tags: [indicators]
created: 2026-10-27
updated: 2026-10-27
source: "BLS Employment Cost Index https://www.bls.gov/eci/"
verified: 2026-10-27
---
# Employment Cost Index 就业成本指数

## Definition 定义
The ECI measures the change in the hourly labor cost to employers over time. It covers both wages and salaries and the cost of benefits, and is reported for civilian, private industry and state and local government workers.
ECI 衡量雇主每小时劳动成本随时间的变化，同时包括工资薪金和福利成本，分民用、私营企业、州与地方政府三类公布。

## Why it matters 为什么重要
- The ECI uses fixed job weights, so a shift toward higher- or lower-paid jobs does not move it the way it moves average hourly earnings in the jobs report. ECI 固定职位权重；低薪岗位比例变化会扭曲就业报告里的平均时薪，但不会扭曲 ECI。
- It includes benefits such as health insurance and retirement plans, which average hourly earnings leave out. 它包含医疗保险、退休金等福利成本。
- Labor cost is the largest cost for many service businesses, so the Fed watches it when judging whether services inflation can come down. 劳动成本是很多服务业的最大成本，美联储用它判断服务通胀能否回落。

## Market impact 市场影响
Faster growth in compensation costs supports the view that inflation will stay sticky. That tends to lift short-term rate expectations and Treasury yields. Slower growth supports the opposite. Because it is quarterly, the ECI confirms a trend rather than driving day-to-day trading.
薪酬成本增速加快，支持“通胀黏性”的看法，往往推高短端利率预期和美债收益率；增速放缓则相反。它按季度发布，更多用来确认趋势，而不是驱动每日行情。

## How to read 怎么读
1. Start with civilian total compensation: the 3-month change (seasonally adjusted) and the 12-month change. 先看民用总薪酬的季环比（季调）和 12 个月变化。
2. Split wages and salaries from benefits; benefits can jump for one-off reasons. 拆开工资与福利，福利可能因一次性因素跳升。
3. Compare private industry with state and local government. 比较私营部门与州和地方政府。
4. Cross-check with average hourly earnings in [[Nonfarm Payrolls]], with [[JOLTS]] quits, and with services inflation in [[PCE Inflation]]. 与非农报告的平均时薪、JOLTS 离职率、PCE 服务通胀对照。

## Release 发布
Quarterly, about one month after the quarter ends, at 8:30 a.m. ET. Upcoming dates are in [[12_Data/US Release Calendar 2026-10-27]].
按季度发布，约在季度结束一个月后，美东时间 8:30。

## Related 相关
[[Labor Market]], [[Nonfarm Payrolls]], [[Unemployment Rate]], [[JOLTS]], [[Inflation]], [[PCE Inflation]], [[Jobs Report to Markets]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [BLS ECI](https://www.bls.gov/eci/) · [latest news release](https://www.bls.gov/news.release/eci.nr0.htm) · [release schedule](https://www.bls.gov/schedule/news_release/eci.htm)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Quarterly and revised; one quarter of benefit costs can mislead. Do not treat the ECI as a direct measure of inflation.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata. The 2026-10-27 reading is in [[12_Data/US Macro Snapshot 2026-10-27]].
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
