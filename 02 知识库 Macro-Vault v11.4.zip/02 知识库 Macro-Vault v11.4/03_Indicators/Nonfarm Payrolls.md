---
title: "Nonfarm Payrolls 非农就业"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [非农就业]
tags: [indicators]
---
# Nonfarm Payrolls 非农就业

## Definition 定义
Monthly change in US jobs excluding farm work, published by BLS.
美国每月非农业部门就业人数变化，由 BLS 发布。

## Market impact 市场影响
Strong jobs can raise rate expectations and the USD; very weak jobs raise recession worries. Direction versus expectations matters.
就业强劲会推高加息预期和美元；就业非常疲弱会引发衰退担忧。关键看相对预期的方向。

## Related 相关
[[Unemployment Rate]], [[Federal Funds Rate]]
最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]；相关指标 [[Employment Cost Index]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [BLS Employment Situation](https://www.bls.gov/news.release/empsit.htm)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Monthly; distinguish establishment survey payrolls from household survey employment, revisions, seasonal adjustment and benchmark revisions.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

