---
title: "Federal Budget and Monthly Treasury Statement 联邦预算与月度财政报表"
aliases: [联邦财政赤字, 月度财政报表, MTS, Monthly Treasury Statement]
tags: [indicators, fiscal]
created: 2026-10-27
updated: 2026-10-27
source: "U.S. Treasury Bureau of the Fiscal Service, Monthly Treasury Statement https://fiscal.treasury.gov/accounting/monthly-treasury-statement/"
verified: 2026-10-27
---
# Federal Budget and Monthly Treasury Statement 联邦预算与月度财政报表

## Definition 定义
The Monthly Treasury Statement (MTS) reports federal receipts, outlays and the resulting deficit or surplus for each month and the fiscal year to date. The US federal fiscal year runs from October 1 to September 30, so the September statement gives the full-year result.
月度财政报表（MTS）公布联邦政府每月和本财年累计的收入、支出及赤字或盈余。美国联邦财年从 10 月 1 日到次年 9 月 30 日，所以 9 月的报表就是全年结果。

## Why it matters 为什么重要
- The deficit has to be financed by borrowing, so it feeds directly into Treasury bill and coupon issuance ([[21_US_Treasuries/Treasury Supply Refunding and Buybacks]], [[Treasury Auctions]]). 赤字要靠发债弥补，直接决定短债与中长债的发行量。
- Heavier supply can raise the yield investors demand for holding long bonds ([[Term Premium]], [[US 10-Year Treasury Yield]]). 供给增加可能抬高投资者持有长债要求的补偿。
- Cash moves through the Treasury General Account, which affects bank reserves and money-market liquidity ([[21_US_Treasuries/Treasury TGA Reserves and RRP]]). 财政现金进出财政部一般账户，会影响银行准备金和货币市场流动性。

## How to read 怎么读
1. Use fiscal-year-to-date totals or a 12-month rolling sum. Single months swing with tax deadlines and payment timing; April usually shows a surplus from individual tax payments. 看财年累计或 12 个月滚动合计；单月受缴税期和付款时点影响大，4 月常因个人所得税出现盈余。
2. Split the change into receipts and outlays, then into the big items such as individual and corporate taxes, customs duties, Social Security, Medicare, defense and net interest. 把变化拆成收入和支出，再拆到主要项目。
3. Compare the deficit with GDP to judge size over time ([[Sovereign Debt and Fiscal Sustainability]]). 用赤字占 GDP 的比例看长期规模。
4. Remember that borrowing need is not exactly equal to the deficit; changes in the Treasury cash balance also matter. 借款需求不完全等于赤字，财政部现金余额的变化也会影响发债。

## Market impact 市场影响
A wider-than-planned deficit raises the expected supply of Treasuries. If demand does not keep up, long-term yields and term premium can rise, which pressures equity valuations ([[Treasury Yield to Equity Valuation]]). The link is slow and conditional: the Fed's policy path, inflation and foreign demand often matter more in the short run.
赤字超出计划会提高市场对美债供给的预期；若需求跟不上，长端收益率和期限溢价可能上升，进而压制股票估值。这条传导慢且有条件，短期内美联储路径、通胀和海外需求往往更重要。

## Related 相关
[[Fiscal Policy]], [[Sovereign Debt and Fiscal Sustainability]], [[US Treasury Market]], [[21_US_Treasuries/Treasury Debt Ceiling and Payment Risk]], [[21_US_Treasuries/Treasury Holders and TIC]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [Monthly Treasury Statement](https://fiscal.treasury.gov/accounting/monthly-treasury-statement/) · [Fiscal Data API, MTS Table 1](https://api.fiscaldata.treasury.gov/services/api/fiscal_service/v1/accounting/mts/mts_table_1)
- **How to record / 记录方法:** Store the statement month, record date, fiscal year, the exact table and row, units (dollars, not seasonally adjusted) and the prior-year comparison.
- **Interpretation guardrail / 解读限制:** Figures are not adjusted for calendar timing shifts, so month-to-month comparisons can mislead. Congressional Budget Office estimates are projections, not Treasury results.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata. Fiscal 2026 totals are in [[12_Data/US Macro Snapshot 2026-10-27]].
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
