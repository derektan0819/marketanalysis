---
title: "Consumer Confidence 消费者信心"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [消费者信心]
tags: [indicators]
---
# Consumer Confidence 消费者信心

## Definition 定义
Surveys of household sentiment, such as the Conference Board and University of Michigan indices.
衡量家庭情绪的调查，例如 Conference Board 和密歇根大学指数。

## Market impact 市场影响
Leads spending: falling confidence often precedes weaker retail sales. The Michigan survey also tracks inflation expectations, which the Fed watches.
领先于消费：信心下滑通常先于零售销售走弱。密歇根调查还追踪通胀预期，美联储对此很关注。

## Related 相关
[[Retail Sales]], [[US Consumer and Housing]], [[Inflation]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)
## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [Conference Board Consumer Confidence](https://www.conference-board.org/topics/consumer-confidence)
- **How to record / 记录方法:** Store the exact release or series URL, observation date, publication/retrieval timestamps, units, frequency, adjustment basis, prior value and revisions where relevant.
- **Interpretation guardrail / 解读限制:** Record survey date/release and distinguish Conference Board confidence from University of Michigan sentiment.
- **Current value / 最新值:** Do not store an unsourced “latest” number in this evergreen note. Put dated observations in `12_Data` or a dated report with source metadata.
- **Expectation comparison / 预期比较:** Use consensus only with a named provider and timestamp captured before release; otherwise mark comparison unavailable.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].

