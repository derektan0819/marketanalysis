---
title: "Fed Funds Futures 联邦基金利率期货"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [联邦基金利率期货]
tags: [indicators]
as_of: 2026-10
---
# Fed Funds Futures 联邦基金利率期货

## Definition 定义
Futures contracts whose price reflects the expected average federal funds rate in a given month, traded on CME. They are a main source of market-implied rate expectations.
合约价格反映某月预期的联邦基金平均利率，在 CME 交易。它们是市场隐含利率预期的主要来源之一。

## Market impact 市场影响
Changes in these prices after data, speeches or Fed meetings show how the market revised its expected rate path. This feeds directly into Treasury yields, the dollar and equity valuations.
数据、讲话或议息会议之后这些价格的变化，显示市场如何修正预期利率路径，并直接影响国债收益率、美元和股票估值。

## Related 相关
[[Market-Implied Rate Expectations]], [[Federal Funds Rate]], [[Fed and FOMC]], [[Priced In]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Source, methodology and data-quality rules / 来源与数据质量
- **Preferred source / 首选来源:** [CME Group](https://www.cmegroup.com/) product and settlement pages (verify exact contract and page).
- **Interpretation guardrail / 解读限制:** Price = 100 minus expected average rate for the contract month. Record contract month, price, timestamp and session. Derived probabilities depend on the provider's method.
- **Current value / 最新值:** Do not store an unsourced 'latest' number here.
- **Expectation comparison / 预期比较:** Name the provider and the timestamp for any implied probability.
- **Related governance:** [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
