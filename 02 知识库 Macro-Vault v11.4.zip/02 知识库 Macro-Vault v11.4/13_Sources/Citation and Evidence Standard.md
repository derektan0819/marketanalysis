---
title: "Citation and Evidence Standard"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [sources, citation, governance]
---
# Citation and Evidence Standard

## What must be cited?
Cite every material financial number, every comparison against expectations, every claim about company guidance, and every non-obvious causal or industry claim. Cite any current company relationship, index weight, policy rule or regulatory requirement that may change over time.

## Evidence record
Use one record per source/document, not one vague link for an entire report.

```yaml
source_id: SRC-YYYYMMDD-001
source_type: filing | issuer_release | official_series | consensus_provider | transcript | secondary
publisher: ""
title: ""
url: ""
filing_accession_or_series_id: ""
publication_datetime: ""
timezone: ""
retrieved_datetime: ""
reporting_period: ""
source_location: "page / table / item / paragraph / series observation"
notes: ""
```

## Citation rules
1. Put a citation immediately after the claim it supports.
2. Link to the specific document or series rather than only the publisher's homepage.
3. For filings, record form type, filing date, accession/document and relevant item/page/table when available.
4. For official statistics, record release date, reference period, units, seasonal adjustment and revision/vintage if relevant.
5. For consensus, record provider, measure definition, observation timestamp, estimate statistic and contributor count if available.
6. For calculations, cite every material input and show the formula or reference the calculation record.
7. For a paraphrased conclusion, cite the underlying evidence and label the conclusion `[INFERENCE]` if it goes beyond the source's explicit statement.
8. If a source does not support the statement, remove or rewrite the statement; do not cite it merely because the subject is similar.
9. Do not fabricate page numbers, quotes, filing IDs or timestamps.
10. If source access fails, mark `unverified`; do not pretend the source was opened.

## Claim strength
- **Strong:** direct primary-source disclosure or reproducible calculation from verified inputs.
- **Moderate:** multiple credible sources or a reasonable inference with stated assumptions.
- **Weak:** indirect read-across, uncertain timing, incomplete evidence or unverified market expectations.

## Citation quality examples
- Good: `[FACT] FY2026 Q2 revenue was X (issuer release, dated ..., table ..., URL).`
- Good: `[CALC] YoY growth = (current quarter revenue / prior-year quarter revenue) - 1; both inputs linked.`
- Not sufficient: `Revenue grew strongly (source: company website).`
- Not sufficient: `Analysts expected X` with no named provider and timestamp.
