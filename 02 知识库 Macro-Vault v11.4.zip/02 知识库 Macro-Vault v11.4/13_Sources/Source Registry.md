---
title: "Source Registry — authoritative starting points"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [sources, governance]
version: 1.0
---
# Source Registry — authoritative starting points

This is a **source directory**, not proof that a particular data point has been checked. For every claim, cite the exact release, filing, table or data series and record its dates. Confirm URLs still work when used.

## US company filings and disclosures
- **SEC EDGAR Search** — https://www.sec.gov/edgar/search/ — filings including 10-K, 10-Q, 8-K, exhibits and amendments. Use the filing itself for reported financials; note filing date and accession/document.
- **SEC EDGAR APIs / documentation** — https://www.sec.gov/edgar/sec-api-documentation — company submissions and XBRL company facts. API data must be mapped carefully to the right taxonomy concept, unit, period and filing accession.
- **Company Investor Relations** — use the company's official investor-relations site for earnings releases, presentation slides, prepared remarks and webcast/transcript links. Prefer the original release over news summaries.
- **SEC Inline XBRL viewer** — accessible through relevant EDGAR filings; use to inspect tags and context. XBRL tags may require interpretation and do not eliminate period/basis checks.

## US macroeconomic data
- **Bureau of Labor Statistics (BLS)** — https://www.bls.gov/ — CPI: https://www.bls.gov/cpi/ ; Employment Situation: https://www.bls.gov/news.release/empsit.htm ; JOLTS: https://www.bls.gov/jlt/ ; PPI: https://www.bls.gov/ppi/ . Use the release tables and note revisions/seasonal adjustment.
- **Bureau of Economic Analysis (BEA)** — https://www.bea.gov/ — GDP: https://www.bea.gov/data/gdp/gross-domestic-product ; PCE price index: https://www.bea.gov/data/personal-consumption-expenditures-price-index ; international trade: https://www.bea.gov/data/intl-trade-investment/international-trade-goods-and-services . Use the release/table and vintage; advance estimates are revised.
- **US Census Bureau** — retail sales: https://www.census.gov/retail/index.html ; international trade: https://www.census.gov/foreign-trade/index.html ; housing and construction releases are also available on Census pages. Distinguish advance estimates from revisions.
- **Federal Reserve** — FOMC calendars/statements: https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm ; H.15 selected interest rates: https://www.federalreserve.gov/releases/h15/ ; industrial production/capacity utilization: https://www.federalreserve.gov/releases/g17/ . Use the dated release, not a generic page, for point-in-time claims.
- **US Treasury** — daily Treasury par yield curve rates: https://home.treasury.gov/resource-center/data-chart-center/interest-rates . Treasury par yields are not identical to every market yield or real yield series.
- **FRED (Federal Reserve Bank of St. Louis)** — https://fred.stlouisfed.org/ — useful series access and metadata. FRED may redistribute data from other agencies; record the original source, series ID, units, frequency and observation date. Some series are revised.
- **ISM Report on Business** — https://www.ismworld.org/supply-management-news-and-reports/reports/ism-report-on-business/ — PMI survey data. Distinguish ISM PMI from S&P Global PMI; methodology and sample differ.
- **Conference Board Consumer Confidence** — https://www.conference-board.org/topics/consumer-confidence — check the dated release and methodology. Do not treat consumer confidence as the same measure as University of Michigan sentiment.

## Market, volatility and index data
- **Cboe VIX** — https://www.cboe.com/tradable_products/vix/ — methodology and product information. VIX is a measure derived from SPX option prices, not a direct prediction of the exact future move or direction.
- **S&P Dow Jones Indices** — https://www.spglobal.com/spdji/ — official index methodology and factsheets; confirm access rights and the relevant dated document.
- **Nasdaq Indexes** — https://indexes.nasdaqomx.com/ — index methodology and index data information; verify current methodology and access terms.
- **Exchange / issuer data** — use the official exchange or issuer source where possible. Record market timestamp, timezone, session (regular/extended), adjusted/unadjusted status and currency.
- **Consensus and estimates** — consensus is usually licensed/proprietary (for example, a named institutional estimates provider). Record provider, metric definition, estimate statistic (mean/median), contributor count if available, timestamp and whether the estimate was captured before the release. Do not infer consensus from a search engine or a company guidance range.

## Semiconductor and technology industry
- **Semiconductor Industry Association (SIA)** — https://www.semiconductors.org/ — industry releases and references to WSTS market statistics. Record release date and whether figures are monthly, quarterly, year-to-date or forecasts.
- **World Semiconductor Trade Statistics (WSTS)** — https://www.wsts.org/ — market forecast and statistics information; verify exact report, vintage and access conditions.
- **TSMC Investor Relations** — https://investor.tsmc.com/english — monthly revenue, quarterly results, presentations and filings. Check whether monthly revenue is reported in NT dollars and whether comparisons are year-over-year or month-over-month.
- **Company investor relations** — for NVIDIA, AMD, Broadcom, Micron, ASML, Applied Materials, Lam Research, KLA, major hyperscalers and other companies, use each issuer's official IR pages and filings. Company names in the Vault are examples, not a live constituent list.

## Malaysia
- **Bank Negara Malaysia (BNM)** — https://www.bnm.gov.my/ — Monetary Policy Committee statements and OPR decisions. Use the dated statement; do not infer the next decision from the current rate alone.
- **Department of Statistics Malaysia (DOSM)** — https://www.dosm.gov.my/ — official CPI, GDP, labour, trade and industrial statistics. Record the release, period and revision status.
- **Bursa Malaysia** — https://www.bursamalaysia.com/ — issuer announcements and market disclosures. Verify the specific announcement and timestamp.

## Source selection hierarchy
1. Regulatory filing / official release / original statistical release.
2. Official issuer, central bank, agency, exchange or index provider data.
3. Licensed professional data provider with a clear timestamp and definition.
4. Reputable secondary reporting for context, clearly labelled as secondary.
5. Search snippets, social posts and unsourced aggregators: discovery only, not sufficient support for material numbers.

## Mandatory caveats
- A source homepage does not substantiate a specific figure.
- Search snippets can be stale or truncated.
- Data may be revised, restated, adjusted, delayed or licensed.
- Market price data require timestamp and session.
- Do not scrape or redistribute data contrary to provider terms.


## Global central banks and international data (added v4)
- **European Central Bank (ECB)** — https://www.ecb.europa.eu/ — euro-area monetary policy decisions, statements and data.
- **Bank of Japan (BOJ)** — https://www.boj.or.jp/en/ — monetary policy statements and Japan data.
- **Bank of England (BoE)** — https://www.bankofengland.co.uk/ — Bank Rate decisions and minutes.
- **People's Bank of China (PBoC)** — http://www.pbc.gov.cn/en/ — policy announcements; verify the exact page and language version.
- **National Bureau of Statistics of China** — https://www.stats.gov.cn/english/ — official Chinese statistics; record release and caveats.
- **Bank for International Settlements (BIS)** — https://www.bis.org/ — Basel framework texts and international banking and market statistics.
- **International Monetary Fund (IMF)** — https://www.imf.org/ — global economic outlook and country data; record the publication date and vintage.
- **CME Group** — https://www.cmegroup.com/ — federal funds futures and related market data; verify exact product pages.
Confirm URLs still work and that you are on the official site before relying on them.


## Korea and crypto sources (added v5)
- **Korea Exchange (KRX)** — https://global.krx.co.kr/ — KOSPI and KOSDAQ index information and market data; verify exact pages and terms.
- **DART (Korea Financial Supervisory Service disclosure system)** — https://dart.fss.or.kr/ — Korean company filings, including Samsung Electronics and SK Hynix.
- **Samsung Electronics Investor Relations** — https://www.samsung.com/global/ir/ — earnings releases and presentations; verify the page.
- **SK hynix Investor Relations** — https://www.skhynix.com/eng/ir/ — earnings releases and presentations; verify the page.
- **Bank of Korea** — https://www.bok.or.kr/eng/ — Korean monetary policy and statistics.
- **Korea Customs Service and Ministry of Trade, Industry and Energy** — official monthly and partial-month export data; verify current release pages.
- **SEC** — https://www.sec.gov/ and **CFTC** — https://www.cftc.gov/ — US crypto-related regulation, ETF filings and enforcement. Use the primary document, not a summary.
- **Crypto ETF issuers and data aggregators** — each ETF issuer's website is the primary source for holdings and flows; aggregators differ, so record which one was used.
Secondary news sites (for example Cointelegraph, Investing.com, Yonhap-style outlets) can explain context but must not override primary sources. Confirm URLs still work.


## FX, commodities and positioning (added v7)
- **Federal Reserve H.10 foreign exchange rates** — https://www.federalreserve.gov/releases/h10/current/ — official daily rates; these are noon buying rates in New York, not intraday quotes.
- **European Central Bank euro reference rates** — https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/index.en.html — daily reference rates; a reference rate is not a tradable quote.
- **Bank Negara Malaysia** — https://www.bnm.gov.my/ — ringgit and Malaysian policy information (already listed above).
- **US Energy Information Administration (EIA)** — https://www.eia.gov/ — US oil inventories and energy statistics.
- **International Energy Agency (IEA)** — https://www.iea.org/ — global oil market reports.
- **CFTC Commitments of Traders** — https://www.cftc.gov/MarketReports/CommitmentsofTraders/index.htm — futures positioning; published with a lag.
- **Crypto data providers** — ETF flows (for example Farside Investors, SoSoValue), liquidations (for example CoinGlass) and prices (for example CoinGecko) differ from each other; record which one was used. Treat them as secondary data, not primary sources.
Confirm URLs still work and that you are on the official site before relying on them.

## Added in v9: user-added videos
- **Videos and talks you add yourself** are secondary sources. Record the URL, speaker or channel, publication date and watch date in the note's properties; see [[Video Guide]]. Claims need a primary source before they are treated as facts.

## Added in v8: Asia FX, gold and global indices
- **Bank of Japan** — https://www.boj.or.jp/en/ — policy statements and data for the yen.
- **Japan Ministry of Finance** — https://www.mof.go.jp/english/ — official foreign-exchange intervention data, published after the fact.
- **China Foreign Exchange Trade System (CFETS)** — https://www.chinamoney.com.cn/english/ — onshore renminbi reference rate and market data; the People's Bank of China (https://www.pbc.gov.cn/en/) publishes policy.
- **LBMA** — https://www.lbma.org.uk/ — gold and silver benchmark prices. **World Gold Council** — https://www.gold.org/ — gold demand data.
- **Bursa Malaysia** — https://www.bursamalaysia.com/ — FBM KLCI and Malaysian market data. Other exchange sites (Japan Exchange Group, HKEX) are the primary source for their own index closes.
- **Stablecoin issuers' transparency pages** — primary for each issuer's reserves; aggregators such as DefiLlama are secondary.
Confirm URLs still work and that you are on the official site before relying on them.

## Added in v10: global and structural sources
- **Eurostat** — https://ec.europa.eu/eurostat — euro-area inflation (HICP), GDP and labour data.
- **Office for National Statistics (ONS)** — https://www.ons.gov.uk/ — UK CPI, GDP and labour data. **UK Debt Management Office** — https://www.dmo.gov.uk/ — gilt issuance.
- **Reserve Bank of India** — https://www.rbi.org.in/ and **MoSPI** — https://mospi.gov.in/ — Indian policy and statistics. **NSE** — https://www.nseindia.com/ and **BSE** — https://www.bseindia.com/ — index data.
- **Statistics Bureau of Japan** — https://www.stat.go.jp/english/ — Japanese CPI.
- **IMF COFER** — https://data.imf.org/ — currency composition of official reserves. **IMF Fiscal Monitor and Global Financial Stability Report** — https://www.imf.org/ — fiscal and financial-stability analysis.
- **International Forum of Sovereign Wealth Funds (IFSWF)** — https://www.ifswf.org/ — standards and member information; each fund's annual report is the primary source for its own figures.
- **OPEC** — https://www.opec.org/ — production decisions. **LME** — https://www.lme.com/ and **CME Group** — https://www.cmegroup.com/ — metals and energy contract data.
- **US Treasury** — https://home.treasury.gov/ and **TreasuryDirect** — https://www.treasurydirect.gov/ — auction results and refunding statements.
- **USTR** — https://ustr.gov/, **US Customs and Border Protection** — https://www.cbp.gov/ and **WTO** — https://www.wto.org/ — tariffs and trade rules.
- **FRED** — https://fred.stlouisfed.org/ — convenient access to many series; check the original source and any redistribution terms.
Confirm URLs still work and that you are on the official site before relying on them.

<!-- BEGIN GENERATED NAVIGATION -->
[[HOME|首页]] · [[13_Sources/Source Index|来源索引]] · [[14_Reports/Run History Index|运行历史]]
<!-- END GENERATED NAVIGATION -->

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Data Sources and Definitions|美债数据源、单位与时间口径]]：知识库告诉 AI 去哪里取数，不等于已经接入行情。

## 美债专项来源（v11.4）

[[21_US_Treasuries/Treasury Data Sources and Definitions|来源、指标口径与时间记录]] 汇集 TreasuryDirect、财政部、Fed／NY Fed 等定义与数据入口。产品和交易结构另在对应笔记列出 SEC Investor.gov、FINRA、CME 的一手说明。IRS 页面只支持其明确适用条件，不代表对用户个人税务作出结论。

资料入口不等于已安装采集器。当前没有新增行情、共识、TIC 或宏观自动连接；免费公开资料也要在每次研究中核实更新时间与可用权限。
