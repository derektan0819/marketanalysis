---
title: "Sources MOC — 原始来源"
tags: [index, moc]
created: 2026-10-27
updated: 2026-10-27
source: "自动整理：完整列出 13_Sources 的全部文件（2026-10-27）"
---

# Sources MOC — 原始来源

[[00_Index/Master Index|总索引]] · [[HOME|首页]]

本文件夹共 102 个文件，其中笔记 50 篇。以下按路径完整列出，笔记显示标题。

## 先读

- [[13_Sources/Source Index|原始来源索引]]
- [[13_Sources/Source Registry|Source Registry — authoritative starting points]]

## 笔记

- [[13_Sources/Citation and Evidence Standard|Citation and Evidence Standard]]
- [[13_Sources/Source Index|原始来源索引]]
- [[13_Sources/Source Registry|Source Registry — authoritative starting points]]

## Raw

- [[13_Sources/Raw/SRC-01f576137f26e339d42bae12|SRC-01f576137f26e339d42bae12 提取正文]]
- [[13_Sources/Raw/SRC-0d22ae2e56e5e9209f93b78c.earnings|SRC-0d22ae2e56e5e9209f93b78c 财报附件候选正文]]
- [[13_Sources/Raw/SRC-0d22ae2e56e5e9209f93b78c|SRC-0d22ae2e56e5e9209f93b78c 提取正文]]
- [[13_Sources/Raw/SRC-1cf41a59f7a0f9bd19d142ef.earnings|SRC-1cf41a59f7a0f9bd19d142ef 财报附件候选正文]]
- [[13_Sources/Raw/SRC-1cf41a59f7a0f9bd19d142ef|SRC-1cf41a59f7a0f9bd19d142ef 提取正文]]
- [[13_Sources/Raw/SRC-1db8a6c89a58e018e4171fc7|SRC-1db8a6c89a58e018e4171fc7 提取正文]]
- [[13_Sources/Raw/SRC-2b259bd14aae3c6cda610019|SRC-2b259bd14aae3c6cda610019 提取正文]]
- [[13_Sources/Raw/SRC-37b983f4389f983f2f7b570c|SRC-37b983f4389f983f2f7b570c 提取正文]]
- [[13_Sources/Raw/SRC-76097bd5d0676a2af912246a|SRC-76097bd5d0676a2af912246a 提取正文]]
- [[13_Sources/Raw/SRC-821ba21da94c21df60d729fd|SRC-821ba21da94c21df60d729fd 提取正文]]
- [[13_Sources/Raw/SRC-989578e077b325a53283a75a.earnings|SRC-989578e077b325a53283a75a 财报附件候选正文]]
- [[13_Sources/Raw/SRC-989578e077b325a53283a75a|SRC-989578e077b325a53283a75a 提取正文]]
- [[13_Sources/Raw/SRC-9c13f4e336126491246ce357|SRC-9c13f4e336126491246ce357 提取正文]]
- [[13_Sources/Raw/SRC-a7294589a5aaa86bbd9cc776|SRC-a7294589a5aaa86bbd9cc776 提取正文]]
- [[13_Sources/Raw/SRC-c1ec319cd0b030514ec1e7fd|SRC-c1ec319cd0b030514ec1e7fd 提取正文]]
- [[13_Sources/Raw/SRC-cdfdbabdeb7969a82d193e80.earnings|SRC-cdfdbabdeb7969a82d193e80 财报附件候选正文]]
- [[13_Sources/Raw/SRC-cdfdbabdeb7969a82d193e80|SRC-cdfdbabdeb7969a82d193e80 提取正文]]
- [[13_Sources/Raw/SRC-eb223ffcdc5663a094a6b31e|SRC-eb223ffcdc5663a094a6b31e 提取正文]]
- [[13_Sources/Raw/SRC-ee4a8840d145293adfaac731|SRC-ee4a8840d145293adfaac731 提取正文]]
- [[13_Sources/Raw/SRC-fd41fbb8d4e31433b10eee67.earnings|SRC-fd41fbb8d4e31433b10eee67 财报附件候选正文]]
- [[13_Sources/Raw/SRC-fd41fbb8d4e31433b10eee67|SRC-fd41fbb8d4e31433b10eee67 提取正文]]

## Records

- [[13_Sources/Records/SRC-01f576137f26e339d42bae12|SRC-01f576137f26e339d42bae12 · issuer_preliminary_release]]
- [[13_Sources/Records/SRC-08308d5b92d92472bdc27b22|SRC-08308d5b92d92472bdc27b22 · sec_submissions]]
- [[13_Sources/Records/SRC-0d22ae2e56e5e9209f93b78c|SRC-0d22ae2e56e5e9209f93b78c · sec_filing]]
- [[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7 · sec_companyfacts]]
- [[13_Sources/Records/SRC-1cf41a59f7a0f9bd19d142ef|SRC-1cf41a59f7a0f9bd19d142ef · sec_filing]]
- [[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466 · sec_companyfacts]]
- [[13_Sources/Records/SRC-1db8a6c89a58e018e4171fc7|SRC-1db8a6c89a58e018e4171fc7 · sec_filing]]
- [[13_Sources/Records/SRC-2b259bd14aae3c6cda610019|SRC-2b259bd14aae3c6cda610019 · sec_filing]]
- [[13_Sources/Records/SRC-37b983f4389f983f2f7b570c|SRC-37b983f4389f983f2f7b570c · sec_filing]]
- [[13_Sources/Records/SRC-76097bd5d0676a2af912246a|SRC-76097bd5d0676a2af912246a · sec_filing]]
- [[13_Sources/Records/SRC-7ab958b0ea29ba91248ed4e8|SRC-7ab958b0ea29ba91248ed4e8 · sec_submissions]]
- [[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff · sec_companyfacts]]
- [[13_Sources/Records/SRC-821ba21da94c21df60d729fd|SRC-821ba21da94c21df60d729fd · sec_filing]]
- [[13_Sources/Records/SRC-989578e077b325a53283a75a|SRC-989578e077b325a53283a75a · sec_filing]]
- [[13_Sources/Records/SRC-9c13f4e336126491246ce357|SRC-9c13f4e336126491246ce357 · sec_filing]]
- [[13_Sources/Records/SRC-a6776da28e9dbc899140e410|SRC-a6776da28e9dbc899140e410 · sec_submissions]]
- [[13_Sources/Records/SRC-a67d23125031be722818082a|SRC-a67d23125031be722818082a · sec_submissions]]
- [[13_Sources/Records/SRC-a7294589a5aaa86bbd9cc776|SRC-a7294589a5aaa86bbd9cc776 · sec_filing]]
- [[13_Sources/Records/SRC-c1ec319cd0b030514ec1e7fd|SRC-c1ec319cd0b030514ec1e7fd · sec_filing]]
- [[13_Sources/Records/SRC-cdfdbabdeb7969a82d193e80|SRC-cdfdbabdeb7969a82d193e80 · sec_filing]]
- [[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d · sec_companyfacts]]
- [[13_Sources/Records/SRC-e06ad19d0d6e580ca33905ef|SRC-e06ad19d0d6e580ca33905ef · sec_submissions]]
- [[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d · sec_companyfacts]]
- [[13_Sources/Records/SRC-eb223ffcdc5663a094a6b31e|SRC-eb223ffcdc5663a094a6b31e · sec_filing]]
- [[13_Sources/Records/SRC-ee4a8840d145293adfaac731|SRC-ee4a8840d145293adfaac731 · sec_filing]]
- [[13_Sources/Records/SRC-fd41fbb8d4e31433b10eee67|SRC-fd41fbb8d4e31433b10eee67 · sec_filing]]

## 机器可读文件

JSON、CSV、HTML、TXT、PY 等文件，可在 Obsidian 中打开或用外部编辑器查看。

- [[13_Sources/Raw/SRC-01f576137f26e339d42bae12.html|Raw/SRC-01f576137f26e339d42bae12.html]]
- [[13_Sources/Raw/SRC-01f576137f26e339d42bae12.meta.json|Raw/SRC-01f576137f26e339d42bae12.meta.json]]
- [[13_Sources/Raw/SRC-08308d5b92d92472bdc27b22.json|Raw/SRC-08308d5b92d92472bdc27b22.json]]
- [[13_Sources/Raw/SRC-08308d5b92d92472bdc27b22.meta.json|Raw/SRC-08308d5b92d92472bdc27b22.meta.json]]
- [[13_Sources/Raw/SRC-0d22ae2e56e5e9209f93b78c.html|Raw/SRC-0d22ae2e56e5e9209f93b78c.html]]
- [[13_Sources/Raw/SRC-0d22ae2e56e5e9209f93b78c.meta.json|Raw/SRC-0d22ae2e56e5e9209f93b78c.meta.json]]
- [[13_Sources/Raw/SRC-174f3bdf69743dba0ce516d7.json|Raw/SRC-174f3bdf69743dba0ce516d7.json]]
- [[13_Sources/Raw/SRC-174f3bdf69743dba0ce516d7.meta.json|Raw/SRC-174f3bdf69743dba0ce516d7.meta.json]]
- [[13_Sources/Raw/SRC-1cf41a59f7a0f9bd19d142ef.html|Raw/SRC-1cf41a59f7a0f9bd19d142ef.html]]
- [[13_Sources/Raw/SRC-1cf41a59f7a0f9bd19d142ef.meta.json|Raw/SRC-1cf41a59f7a0f9bd19d142ef.meta.json]]
- [[13_Sources/Raw/SRC-1d3f9e9e2a262c50d415f466.json|Raw/SRC-1d3f9e9e2a262c50d415f466.json]]
- [[13_Sources/Raw/SRC-1d3f9e9e2a262c50d415f466.meta.json|Raw/SRC-1d3f9e9e2a262c50d415f466.meta.json]]
- [[13_Sources/Raw/SRC-1db8a6c89a58e018e4171fc7.html|Raw/SRC-1db8a6c89a58e018e4171fc7.html]]
- [[13_Sources/Raw/SRC-1db8a6c89a58e018e4171fc7.meta.json|Raw/SRC-1db8a6c89a58e018e4171fc7.meta.json]]
- [[13_Sources/Raw/SRC-2b259bd14aae3c6cda610019.html|Raw/SRC-2b259bd14aae3c6cda610019.html]]
- [[13_Sources/Raw/SRC-2b259bd14aae3c6cda610019.meta.json|Raw/SRC-2b259bd14aae3c6cda610019.meta.json]]
- [[13_Sources/Raw/SRC-37b983f4389f983f2f7b570c.html|Raw/SRC-37b983f4389f983f2f7b570c.html]]
- [[13_Sources/Raw/SRC-37b983f4389f983f2f7b570c.meta.json|Raw/SRC-37b983f4389f983f2f7b570c.meta.json]]
- [[13_Sources/Raw/SRC-76097bd5d0676a2af912246a.html|Raw/SRC-76097bd5d0676a2af912246a.html]]
- [[13_Sources/Raw/SRC-76097bd5d0676a2af912246a.meta.json|Raw/SRC-76097bd5d0676a2af912246a.meta.json]]
- [[13_Sources/Raw/SRC-7ab958b0ea29ba91248ed4e8.json|Raw/SRC-7ab958b0ea29ba91248ed4e8.json]]
- [[13_Sources/Raw/SRC-7ab958b0ea29ba91248ed4e8.meta.json|Raw/SRC-7ab958b0ea29ba91248ed4e8.meta.json]]
- [[13_Sources/Raw/SRC-7f583d5afbbe74d9038418ff.json|Raw/SRC-7f583d5afbbe74d9038418ff.json]]
- [[13_Sources/Raw/SRC-7f583d5afbbe74d9038418ff.meta.json|Raw/SRC-7f583d5afbbe74d9038418ff.meta.json]]
- [[13_Sources/Raw/SRC-821ba21da94c21df60d729fd.html|Raw/SRC-821ba21da94c21df60d729fd.html]]
- [[13_Sources/Raw/SRC-821ba21da94c21df60d729fd.meta.json|Raw/SRC-821ba21da94c21df60d729fd.meta.json]]
- [[13_Sources/Raw/SRC-989578e077b325a53283a75a.html|Raw/SRC-989578e077b325a53283a75a.html]]
- [[13_Sources/Raw/SRC-989578e077b325a53283a75a.meta.json|Raw/SRC-989578e077b325a53283a75a.meta.json]]
- [[13_Sources/Raw/SRC-9c13f4e336126491246ce357.html|Raw/SRC-9c13f4e336126491246ce357.html]]
- [[13_Sources/Raw/SRC-9c13f4e336126491246ce357.meta.json|Raw/SRC-9c13f4e336126491246ce357.meta.json]]
- [[13_Sources/Raw/SRC-a6776da28e9dbc899140e410.json|Raw/SRC-a6776da28e9dbc899140e410.json]]
- [[13_Sources/Raw/SRC-a6776da28e9dbc899140e410.meta.json|Raw/SRC-a6776da28e9dbc899140e410.meta.json]]
- [[13_Sources/Raw/SRC-a67d23125031be722818082a.json|Raw/SRC-a67d23125031be722818082a.json]]
- [[13_Sources/Raw/SRC-a67d23125031be722818082a.meta.json|Raw/SRC-a67d23125031be722818082a.meta.json]]
- [[13_Sources/Raw/SRC-a7294589a5aaa86bbd9cc776.html|Raw/SRC-a7294589a5aaa86bbd9cc776.html]]
- [[13_Sources/Raw/SRC-a7294589a5aaa86bbd9cc776.meta.json|Raw/SRC-a7294589a5aaa86bbd9cc776.meta.json]]
- [[13_Sources/Raw/SRC-c1ec319cd0b030514ec1e7fd.html|Raw/SRC-c1ec319cd0b030514ec1e7fd.html]]
- [[13_Sources/Raw/SRC-c1ec319cd0b030514ec1e7fd.meta.json|Raw/SRC-c1ec319cd0b030514ec1e7fd.meta.json]]
- [[13_Sources/Raw/SRC-cdfdbabdeb7969a82d193e80.html|Raw/SRC-cdfdbabdeb7969a82d193e80.html]]
- [[13_Sources/Raw/SRC-cdfdbabdeb7969a82d193e80.meta.json|Raw/SRC-cdfdbabdeb7969a82d193e80.meta.json]]
- [[13_Sources/Raw/SRC-df4f13151968a6aacad9041d.json|Raw/SRC-df4f13151968a6aacad9041d.json]]
- [[13_Sources/Raw/SRC-df4f13151968a6aacad9041d.meta.json|Raw/SRC-df4f13151968a6aacad9041d.meta.json]]
- [[13_Sources/Raw/SRC-e06ad19d0d6e580ca33905ef.json|Raw/SRC-e06ad19d0d6e580ca33905ef.json]]
- [[13_Sources/Raw/SRC-e06ad19d0d6e580ca33905ef.meta.json|Raw/SRC-e06ad19d0d6e580ca33905ef.meta.json]]
- [[13_Sources/Raw/SRC-e518cf203523282fcc91b24d.json|Raw/SRC-e518cf203523282fcc91b24d.json]]
- [[13_Sources/Raw/SRC-e518cf203523282fcc91b24d.meta.json|Raw/SRC-e518cf203523282fcc91b24d.meta.json]]
- [[13_Sources/Raw/SRC-eb223ffcdc5663a094a6b31e.html|Raw/SRC-eb223ffcdc5663a094a6b31e.html]]
- [[13_Sources/Raw/SRC-eb223ffcdc5663a094a6b31e.meta.json|Raw/SRC-eb223ffcdc5663a094a6b31e.meta.json]]
- [[13_Sources/Raw/SRC-ee4a8840d145293adfaac731.html|Raw/SRC-ee4a8840d145293adfaac731.html]]
- [[13_Sources/Raw/SRC-ee4a8840d145293adfaac731.meta.json|Raw/SRC-ee4a8840d145293adfaac731.meta.json]]
- [[13_Sources/Raw/SRC-fd41fbb8d4e31433b10eee67.html|Raw/SRC-fd41fbb8d4e31433b10eee67.html]]
- [[13_Sources/Raw/SRC-fd41fbb8d4e31433b10eee67.meta.json|Raw/SRC-fd41fbb8d4e31433b10eee67.meta.json]]
