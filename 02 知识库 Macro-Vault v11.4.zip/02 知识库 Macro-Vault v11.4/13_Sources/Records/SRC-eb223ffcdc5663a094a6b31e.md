---
title: "SRC-eb223ffcdc5663a094a6b31e · sec_filing"
tags: [sources, source-record]
created: 2026-10-19
updated: 2026-10-19
source: "https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/amzn-20251231.htm"
---
# SRC-eb223ffcdc5663a094a6b31e · sec_filing

[[13_Sources/Source Index|所有来源]]

官方下载地址：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/amzn-20251231.htm

首次保存时间：2026-10-19T07:09:47+00:00；发布时间：2026-02-06T04:44:31.000Z。
SHA-256（下载原始文件）：`74ac75ce763c5db08b1a426196a94bfc952dc5a38e2911ea1a8815031557c6bb`。
内容核验状态：未由本索引认证。

## 保存的正文
- [[13_Sources/Raw/SRC-eb223ffcdc5663a094a6b31e|完整提取文本]]

原始下载文件：[[13_Sources/Raw/SRC-eb223ffcdc5663a094a6b31e.html|原始文件（可能使用外部编辑器）]]
元数据：[[13_Sources/Raw/SRC-eb223ffcdc5663a094a6b31e.meta.json|来源元数据（JSON）]]

## 相关公司
- [[04_Companies/AMZN/Evidence Index|AMZN 证据索引]]
