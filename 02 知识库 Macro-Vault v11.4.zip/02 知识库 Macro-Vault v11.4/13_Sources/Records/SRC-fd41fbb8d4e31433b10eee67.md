---
title: "SRC-fd41fbb8d4e31433b10eee67 · sec_filing"
tags: [sources, source-record]
created: 2026-10-19
updated: 2026-10-19
source: "https://www.sec.gov/Archives/edgar/data/789019/000119312526323632/0001193125-26-323632.txt"
---
# SRC-fd41fbb8d4e31433b10eee67 · sec_filing

[[13_Sources/Source Index|所有来源]]

官方下载地址：https://www.sec.gov/Archives/edgar/data/789019/000119312526323632/0001193125-26-323632.txt

首次保存时间：2026-10-19T07:09:12+00:00；发布时间：2026-07-30T00:04:53.000Z。
SHA-256（下载原始文件）：`d5bf29b45bc42bf81154ac3adb2f33c0f003d1633e7ce5fc36f306072c9806b6`。
内容核验状态：未由本索引认证。

## 保存的正文
- [[13_Sources/Raw/SRC-fd41fbb8d4e31433b10eee67.earnings|EX-99 正文]]
- [[13_Sources/Raw/SRC-fd41fbb8d4e31433b10eee67|完整提取文本]]

原始下载文件：[[13_Sources/Raw/SRC-fd41fbb8d4e31433b10eee67.html|原始文件（可能使用外部编辑器）]]
元数据：[[13_Sources/Raw/SRC-fd41fbb8d4e31433b10eee67.meta.json|来源元数据（JSON）]]

## 相关公司
- [[04_Companies/MSFT/Evidence Index|MSFT 证据索引]]
