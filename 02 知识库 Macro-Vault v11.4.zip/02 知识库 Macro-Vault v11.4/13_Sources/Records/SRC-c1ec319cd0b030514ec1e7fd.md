---
title: "SRC-c1ec319cd0b030514ec1e7fd · sec_filing"
tags: [sources, source-record]
created: 2026-10-19
updated: 2026-10-19
source: "https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/amzn-20260630.htm"
---
# SRC-c1ec319cd0b030514ec1e7fd · sec_filing

[[13_Sources/Source Index|所有来源]]

官方下载地址：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/amzn-20260630.htm

首次保存时间：2026-10-19T07:09:38+00:00；发布时间：2026-07-31T02:11:13.000Z。
SHA-256（下载原始文件）：`7cba7603afd95c52068ec39d138e2de21935c4b1acafd62d69835bd7c7a8c8ab`。
内容核验状态：未由本索引认证。

## 保存的正文
- [[13_Sources/Raw/SRC-c1ec319cd0b030514ec1e7fd|完整提取文本]]

原始下载文件：[[13_Sources/Raw/SRC-c1ec319cd0b030514ec1e7fd.html|原始文件（可能使用外部编辑器）]]
元数据：[[13_Sources/Raw/SRC-c1ec319cd0b030514ec1e7fd.meta.json|来源元数据（JSON）]]

## 相关公司
- [[04_Companies/AMZN/Evidence Index|AMZN 证据索引]]
