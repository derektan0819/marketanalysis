---
title: "SRC-cdfdbabdeb7969a82d193e80 · sec_filing"
tags: [sources, source-record]
created: 2026-10-19
updated: 2026-10-19
source: "https://www.sec.gov/Archives/edgar/data/1018724/000101872426000024/0001018724-26-000024.txt"
---
# SRC-cdfdbabdeb7969a82d193e80 · sec_filing

[[13_Sources/Source Index|所有来源]]

官方下载地址：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000024/0001018724-26-000024.txt

首次保存时间：2026-10-19T07:09:55+00:00；发布时间：2026-07-31T00:06:23.000Z。
SHA-256（下载原始文件）：`4638f860867282b1b95b9fb4e58bc9fc20498780b315d1c392c45baf48d2da7f`。
内容核验状态：未由本索引认证。

## 保存的正文
- [[13_Sources/Raw/SRC-cdfdbabdeb7969a82d193e80.earnings|EX-99 正文]]
- [[13_Sources/Raw/SRC-cdfdbabdeb7969a82d193e80|完整提取文本]]

原始下载文件：[[13_Sources/Raw/SRC-cdfdbabdeb7969a82d193e80.html|原始文件（可能使用外部编辑器）]]
元数据：[[13_Sources/Raw/SRC-cdfdbabdeb7969a82d193e80.meta.json|来源元数据（JSON）]]

## 相关公司
- [[04_Companies/AMZN/Evidence Index|AMZN 证据索引]]
