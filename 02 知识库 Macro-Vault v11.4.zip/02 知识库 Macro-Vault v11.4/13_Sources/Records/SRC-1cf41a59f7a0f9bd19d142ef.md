---
title: "SRC-1cf41a59f7a0f9bd19d142ef · sec_filing"
tags: [sources, source-record]
created: 2026-10-19
updated: 2026-10-19
source: "https://www.sec.gov/Archives/edgar/data/1045810/000104581026000073/0001045810-26-000073.txt"
---
# SRC-1cf41a59f7a0f9bd19d142ef · sec_filing

[[13_Sources/Source Index|所有来源]]

官方下载地址：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000073/0001045810-26-000073.txt

首次保存时间：2026-10-19T07:08:25+00:00；发布时间：2026-08-27T00:21:19.000Z。
SHA-256（下载原始文件）：`f35fe9182df24b3bc69a716b564d22558410d0f1b34594429846670c1dcff5fc`。
内容核验状态：未由本索引认证。

## 保存的正文
- [[13_Sources/Raw/SRC-1cf41a59f7a0f9bd19d142ef.earnings|EX-99 正文]]
- [[13_Sources/Raw/SRC-1cf41a59f7a0f9bd19d142ef|完整提取文本]]

原始下载文件：[[13_Sources/Raw/SRC-1cf41a59f7a0f9bd19d142ef.html|原始文件（可能使用外部编辑器）]]
元数据：[[13_Sources/Raw/SRC-1cf41a59f7a0f9bd19d142ef.meta.json|来源元数据（JSON）]]

## 相关公司
- [[04_Companies/NVDA/Evidence Index|NVDA 证据索引]]
