---
title: "SRC-1cf41a59f7a0f9bd19d142ef 提取正文"
tags: [sources, raw-text]
created: 2026-10-19
updated: 2026-10-19
source: "https://www.sec.gov/Archives/edgar/data/1045810/000104581026000073/0001045810-26-000073.txt"
---
# Source text — untrusted evidence

```text
0001045810-26-000073.txt : 20260826
0001045810-26-000073.hdr.sgml : 20260826
20260826162119
ACCESSION NUMBER:		0001045810-26-000073
CONFORMED SUBMISSION TYPE:	8-K
PUBLIC DOCUMENT COUNT:		14
CONFORMED PERIOD OF REPORT:	20260826
ITEM INFORMATION:		Results of Operations and Financial Condition
ITEM INFORMATION:		Financial Statements and Exhibits
FILED AS OF DATE:		20260826
DATE AS OF CHANGE:		20260826
FILER:
COMPANY DATA:
COMPANY CONFORMED NAME:			NVIDIA CORP
CENTRAL INDEX KEY:			0001045810
STANDARD INDUSTRIAL CLASSIFICATION:	SEMICONDUCTORS & RELATED DEVICES [3674]
ORGANIZATION NAME:           	04 Manufacturing
EIN:				943177549
STATE OF INCORPORATION:			DE
FISCAL YEAR END:			0131
FILING VALUES:
FORM TYPE:		8-K
SEC ACT:		1934 Act
SEC FILE NUMBER:	000-23985
FILM NUMBER:		261323290
BUSINESS ADDRESS:
STREET 1:		2788 SAN TOMAS EXPRESSWAY
CITY:			SANTA CLARA
STATE:			CA
ZIP:			95051
BUSINESS PHONE:		408-486-2000
MAIL ADDRESS:
STREET 1:		2788 SAN TOMAS EXPRESSWAY
CITY:			SANTA CLARA
STATE:			CA
ZIP:			95051
FORMER COMPANY:
FORMER CONFORMED NAME:	NVIDIA CORP/DE
DATE OF NAME CHANGE:	20020612
FORMER COMPANY:
FORMER CONFORMED NAME:	NVIDIA CORP/CA
DATE OF NAME CHANGE:	19980303
8-K
1
nvda-20260826.htm
8-K
nvda-20260826
00010458102026-08-262026-08-26
UNITED STATES
SECURITIES AND EXCHANGE COMMISSION
WASHINGTON, DC 20549
______________
FORM 8-K
CURRENT REPORT
PURSUANT TO SECTION 13 OR 15(d) OF
THE SECURITIES EXCHANGE ACT OF 1934
Date of Report (Date of earliest event reported): August 26, 2026
NVIDIA CORPORATION
(Exact name of registrant as specified in its charter)
Delaware	0-23985	94-3177549
(State or other jurisdiction	(Commission	(IRS Employer
of incorporation)	File Number)	Identification No.)
2788 San Tomas Expressway, Santa Clara, CA 95051
(Address of principal executive offices)   (Zip Code)
Registrant’s telephone number, including area code: (408) 486-2000
Not Applicable
(Former name or former address, if changed since last report)
Check the appropriate box below if the Form 8-K filing is intended to simultaneously satisfy the filing obligation of the registrant under any of the following provisions:
☐  Written communications pursuant to Rule 425 under the Securities Act (17 CFR 230.425)
☐ Soliciting material pursuant to Rule 14a-12 under the Exchange Act (17 CFR 240.14a-12)
☐ Pre-commencement communications pursuant to Rule 14d-2(b) under the Exchange Act (17 CFR 240.14d-2(b))
☐ Pre-commencement communications pursuant to Rule 13e-4(c) under the Exchange Act (17 CFR 240.13e-4(c))
Securities registered pursuant to Section 12(b) of the Act:
Title of each class	Trading Symbol(s)	Name of each exchange on which registered
Common Stock, $0.001 par value per share	NVDA	The Nasdaq Global Select Market
Indicate by check mark whether the registrant is an emerging growth company as defined in Rule 405 of the Securities Act of 1933 (§230.405 of this chapter) or Rule 12b-2 of the Securities Exchange Act of 1934 (§240.12b-2 of this chapter).
Emerging Growth Company ☐
If an emerging growth company, indicate by check mark if the registrant has elected not to use the extended transition period for complying with any new or revised financial accounting standards provided pursuant to Section 13(a) of the Exchange Act. ☐
Item 2.02 Results of Operations and Financial Condition.
On August 26, 2026, NVIDIA Corporation, or the Company, issued a press release announcing its results for the quarter ended July 26, 2026. The press release is attached as Exhibit 99.1 and is incorporated herein by reference.
Attached hereto as Exhibit 99.2 and incorporated by reference herein is financial information and commentary by Colette M. Kress, Executive Vice President and Chief Financial Officer of the Company, regarding results for the quarter ended July 26, 2026, or the CFO Commentary. The CFO Commentary will be posted to https://investor.nvidia.com immediately after the filing of this Current Report.
The press release and CFO Commentary are furnished and shall not be deemed "filed" for purposes of Section 18 of the Securities Exchange Act of 1934, as amended, or subject to the liabilities of that Section or Sections 11 and 12(a)(2) of the Securities Act of 1933, as amended. The information in this Current Report shall not be incorporated by reference in any filing with the U.S. Securities and Exchange Commission made by the Company, whether made before or after the date hereof, regardless of any general incorporation language in such filing.
Item 9.01 Financial Statements and Exhibits.
(d) Exhibits
Exhibit		Description
99.1
Press Release, dated August 26, 2026, entitled "NVIDIA Announces Financial Results for Second Quarter Fiscal 2027"
99.2
CFO Commentary on Second Quarter Fiscal 2027 Results
104		The cover page of this Current Report on Form 8-K, formatted in inline XBRL (included as Exhibit 101)
SIGNATURE
Pursuant to the requirements of the Securities Exchange Act of 1934, the registrant has duly caused this report to be signed on its behalf by the undersigned hereunto duly authorized.
NVIDIA Corporation
Date: August 26, 2026		By: /s/ Colette M. Kress
Colette M. Kress
Executive Vice President and Chief Financial Officer
EX-99.1
2
q2fy27pr.htm
EX-99.1
Document
NVIDIA Announces Financial Results for Second Quarter Fiscal 2027
•Revenue of $96.2 billion, up 106% from a year ago
•Data Center revenue of $89.0 billion, up 117% from a year ago
SANTA CLARA, Calif.—Aug. 26, 2026―NVIDIA (NASDAQ: NVDA) today reported revenue for the second quarter ended July 26, 2026, of $96.2 billion, up 18% from the previous quarter and up 106% from a year ago. For the quarter, GAAP and non-GAAP gross margins were both 75.0%. GAAP and non-GAAP earnings per diluted share were $2.46 and $2.22, respectively.
“AI has reached its inflection point. It’s doing useful work. Its tokens are productive and profitable. Now, compute is revenue,” said Jensen Huang, founder and CEO of NVIDIA. “And demand is accelerating. This time last year, one lab alone was driving the buildout; today, we have a golden age of new AI labs and startups, multiple frontier labs scaling in parallel, a thriving open-model ecosystem and physical AI coming online — with strong momentum across the U.S. and around the world. The AI infrastructure buildout is at full steam. Vera Rubin, now in full production, was built to power exactly this moment.”
During the second quarter of fiscal 2027, NVIDIA returned approximately $26.0 billion to shareholders in the form of shares repurchased and cash dividends. As of the end of the second quarter, the company had approximately $99.0 billion remaining under its share repurchase authorization.
NVIDIA will pay its next quarterly cash dividend of $0.25 per share on October 1, 2026, to all shareholders of record on September 10, 2026.
Q2 Fiscal 2027 Summary
GAAP
($ in millions, except earnings per share)	Q2 FY27	Q1 FY27	Q2 FY26	Q/Q	Y/Y
Revenue	$96,221	$81,615	$46,743	18 	%	106 	%
Gross margin	75.0 	%	74.9 	%	72.4 	%	0.1 pts	2.6 pts
Operating expenses	$8,408	$7,621	$5,413	10 	%	55 	%
Operating income	$63,734	$53,536	$28,440	19 	%	124 	%
Net income	$59,688	$58,321	$26,422	2 	%	126 	%
Diluted earnings per share	$2.46	$2.39	$1.08	3 	%	128 	%
Non-GAAP
($ in millions, except earnings per share)	Q2 FY27	Q1 FY27	Q2 FY26	Q/Q	Y/Y
Revenue	$96,221	$81,615	$46,743	18 	%	106 	%
Gross margin	75.0 	%	75.0 	%	72.5 	%	—	2.5 pts
Operating expenses	$8,232	$7,449	$5,361	11 	%	54 	%
Operating income	$63,956	$53,783	$28,541	19 	%	124 	%
Net income	$53,954	$45,548	$24,763	18 	%	118 	%
Diluted earnings per share	$2.22	$1.87	$1.01	19 	%	120 	%
Outlook
NVIDIA’s outlook for the third quarter of fiscal 2027 is as follows:
•Revenue is expected to be $108.0 billion, plus or minus 2%. NVIDIA is not assuming any Data Center compute revenue from China in its outlook.
•GAAP and non-GAAP gross margins are expected to be 74.0%, plus or minus 50 basis points.
•GAAP and non-GAAP operating expenses are expected to be approximately $9.2 billion and $9.0 billion, respectively.
For the full year fiscal 2027, NVIDIA expects GAAP and non-GAAP tax rates to be between 16.0% and 18.0%, excluding any discrete items and material changes to NVIDIA’s tax environment.
Highlights
Data Center
•Second-quarter revenue was $89.0 billion, up 18% from the previous quarter and up 117% from a year ago.
•Announced the NVIDIA Vera Rubin platform is ramping into full production with racks running at partners including CoreWeave, Google Cloud, Microsoft Azure, Oracle Cloud Infrastructure and Nebius.
•Revealed that NVIDIA Spectrum™-6 switch systems — supporting both pluggable and co-packaged optics as part of the NVIDIA Vera Rubin platform — are arriving across the world’s gigascale AI factories.
•Unveiled NVIDIA Vera, the first CPU built for AI agents, with broad adoption planned across the world’s leading technology providers.
•Announced that NVIDIA Groq 3 LPX, the interactive AI inference accelerator, is now in full production.
•Introduced new security innovations for NVIDIA Vera BlueField™-4 STX, delivering agentic AI storage processing with in-silicon security for AI factories.
•Launched the NVIDIA DSX™ platform, providing infrastructure builders a complete playbook to design, build and operate AI factories at scale.
•Announced strategic partnerships to establish independent compute financing platforms with Apollo, BlackRock, Blackstone, Brookfield, Goldman Sachs and KKR to mobilize over $500 billion of third-party capital for the buildout of AI infrastructure over time, subject to definitive agreements.
•Announced that SpaceXAI will deploy NVIDIA Vera CPUs to accelerate its next generation of agentic AI applications.
•Secured land, power and shell capacity through a partnership with SB Energy at the PORTS-Pike Technology Campus in Ohio to host NVIDIA compute.
•Revealed that NVIDIA Blackwell led across every category in the MLPerf Training 6.0 benchmarks and in AgentPerf, the industry’s first agentic AI infrastructure benchmark.
•Announced new software, open source models and partnerships with the world’s leading software platform providers to build autonomous AI agents for industries and enterprises;
expanded NVIDIA Agent Toolkit with NVIDIA PhysicsNeMo and new and updated NVIDIA CUDA-X™ libraries.
•Launched NVIDIA BioNeMo™ Agent Toolkit, which provides domain-specific tools and skills for the agentic life sciences era.
•Formed the Open Secure AI Alliance with industry leaders to advance AI safety and security.
•Revealed that NVIDIA GPUs with Confidential Computing are now used for confidential inference in Apple’s Private Cloud Compute.
•Expanded Korea’s AI factory ecosystem through strategic partnerships with SK Telecom, NAVER and Brookfield to build sovereign AI infrastructure at gigawatt scale on the NVIDIA DSX platform, as part of a broader NVIDIA-powered national AI push across Korea’s industries and research institutions.
•Announced a multiyear technology partnership with SK hynix to advance next-generation memory for the global AI factory buildout.
•Partnered with the Japan government and industrial leaders to launch the world’s first national AI infrastructure; revealed that Japan’s leading enterprises, startups and research institutions are building industry-specialized AI models with NVIDIA Nemotron™ open models.
•Announced that the NVIDIA Vera Rubin platform delivers world-class supercomputers for science; announced a record 35 new NVIDIA AI HPC supercomputers in development across Europe.
Edge Computing
•Second-quarter Edge Computing revenue was $7.2 billion, up 13% from the previous quarter and up 27% from a year ago.
•Partnered with Microsoft to reinvent the Windows PC with NVIDIA RTX Spark™ — a 1-petaflop superchip with the full CUDA™ and NVIDIA RTX™ ecosystem.
•Announced NVIDIA DGX Station™ for Windows, the world’s most powerful deskside AI supercomputer for developing and running agents on Windows.
•Launched a local AI initiative with optimizations for top open models — DeepSeek v4 Flash, Diffusion Gemma, Nemotron 3.5 Lightning and Qwen 3.8 — and agent harnesses Hermes Agent and OpenClaw across RTX and DGX platforms.
•Expanded the NVIDIA DRIVE Hyperion™ robotaxi-ready platform ecosystem, including strategic collaborations with Foxconn, VinFast, Uber and HUMAIN.
•Introduced NVIDIA Alpamayo 2 Super, the frontier open reasoning model for safe robotaxi and autonomous vehicle development, for commercial use.
•Launched NVIDIA Cosmos™ 3, the world’s first fully open frontier omnimodel for physical AI.
•Announced the NVIDIA Isaac™ GR00T Reference Humanoid Robot, the first open humanoid robot reference design built on NVIDIA Jetson Thor™ and the NVIDIA Isaac GR00T open development platform.
•Announced NVIDIA Halos for Robotics, the industry’s first full-stack safety system for physical AI, unifying AI compute and safety in a single comprehensive platform.
•Released a major collection of open source agent tools and skills for physical AI, enabling developers to turn complex robotics, autonomous vehicle and vision AI workflows into agent-executable tasks.
CFO Commentary
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com.
Conference Call and Webcast Information
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter fiscal 2027 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its third quarter of fiscal 2027.
Non-GAAP Measures
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude acquisition-related and other costs, other, gains/losses from equity securities, net, certain other income and expense, and the associated tax impact of these items where applicable. Beginning in the first quarter of fiscal 2027, NVIDIA’s non-GAAP financial measures no longer exclude stock-based compensation expense. The historical non-GAAP financial information presented has been updated to include stock-based compensation expense. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the users’ overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.
About NVIDIA
NVIDIA (NASDAQ: NVDA) is the world leader in AI and accelerated computing.
###
For further information, contact:
Toshiya Hari		Mylene Mangalindan
Investor Relations		Corporate Communications
NVIDIA Corporation		NVIDIA Corporation
IR@nvidia.com		press@nvidia.com
Certain statements in this press release including, but not limited to, statements as to: the buildout of AI factories; expectations with respect to growth, performance and benefits of NVIDIA’s products, services and technologies, including Blackwell and Vera Rubin, and related trends and drivers; expectations with respect to supply and demand for NVIDIA’s products, services and technologies, including Blackwell and Vera Rubin, and related matters including inventory, production and distribution; expectations with respect to NVIDIA’s third party arrangements, including with its collaborators and
partners; expectations with respect to our investments; expectations with respect to our financing arrangements; expectations with respect to technology developments, and related trends and drivers; future NVIDIA cash dividends or other returns to stockholders; NVIDIA’s financial and business outlook for the third quarter of fiscal 2027 and beyond; projected market growth and trends; expectations with respect to AI and related industries; and other statements that are not historical facts are forward-looking statements within the meaning of Section 27A of the Securities Act of 1933, as amended, and Section 21E of the Securities Exchange Act of 1934, as amended, which are subject to the “safe harbor” created by those sections based on management’s beliefs and assumptions and on information currently available to management and are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic and political conditions; NVIDIA’s reliance on third parties to manufacture, assemble, package and test NVIDIA’s products; the impact of technological development and competition; development of new products and technologies or enhancements to NVIDIA’s existing products and technologies; market acceptance of NVIDIA’s products or NVIDIA’s partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of NVIDIA’s products or technologies when integrated into systems; NVIDIA’s ability to realize the potential benefits of business investments or acquisitions; and changes in applicable laws and regulations, as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its Annual Report on Form 10-K and Quarterly Reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.
© 2026 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, BlueField, Cosmos, Nemotron, NVIDIA Isaac, BioNeMo, CUDA-X, NVIDIA DRIVE Hyperion, NVIDIA Spectrum, NVIDIA DSX, NVIDIA RTX, RTX Spark, DGX Station, and Jetson Thor are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability and specifications are subject to change without notice.
NVIDIA CORPORATION
CONDENSED CONSOLIDATED STATEMENTS OF INCOME
(In millions, except per share data)
(Unaudited)
Three Months Ended		Six Months Ended
July 26,		July 27,		July 26,		July 27,
2026		2025		2026		2025
Revenue	$	96,221 			$	46,743 			$	177,837 			$	90,805
Cost of revenue	24,079 			12,890 			44,538 			30,284
Gross profit	72,142 			33,853 			133,299 			60,521
Operating expenses
Research and development  	7,054 			4,291 			13,375 			8,280
Sales, general and administrative	1,354 			1,122 			2,654 			2,163
Total operating expenses	8,408 			5,413 			16,029 			10,443
Operating income	63,734 			28,440 			117,270 			50,078
Other income, net	7,773 			2,766 			24,140 			3,039
Income before income tax	71,507 			31,206 			141,410 			53,117
Income tax expense	11,819 			4,784 			23,400 			7,920
Net income	$	59,688 			$	26,422 			$	118,010 			$	45,197
Net income per share:
Basic	$	2.47 			$	1.08 			$	4.87 			$	1.85
Diluted	$	2.46 			$	1.08 			$	4.85 			$	1.84
Weighted average shares used in per share computation:
Basic	24,190 			24,366 			24,238 			24,404
Diluted	24,285 			24,532 			24,338 			24,571
NVIDIA CORPORATION
CONDENSED CONSOLIDATED BALANCE SHEETS
(In millions)
(Unaudited)
July 26,		January 25,
2026		2026
ASSETS
Current assets:
Cash and cash equivalents	$	22,443 			$	10,605
Marketable debt securities	34,143 			39,065
Marketable equity securities	42,783 			12,886
Accounts receivable, net	63,059 			38,466
Inventories	31,575 			21,403
Prepaid expenses and other current assets	3,409 			3,180
Total current assets	197,412 			125,605
Property and equipment, net	14,285 			10,383
Operating lease assets	5,390 			2,867
Goodwill	21,125 			20,832
Intangible assets, net	2,998 			3,306
Deferred income tax assets	12,159 			13,258
Non-marketable securities	51,157 			22,251
Other assets 	15,746 			8,301
Total assets	$	320,272 			$	206,803
LIABILITIES AND SHAREHOLDERS' EQUITY
Current liabilities:
Accounts payable	$	15,059 			$	9,812
Accrued and other current liabilities	26,960 			21,352
Short-term debt	1,000 			999
Total current liabilities	43,019 			32,163
Long-term debt	32,366 			7,469
Long-term operating lease liabilities	4,985 			2,572
Other long-term liabilities	10,918 			7,306
Total liabilities	91,288 			49,510
Shareholders' equity	228,984 			157,293
Total liabilities and shareholders' equity	$	320,272 			$	206,803
NVIDIA CORPORATION
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS
(In millions)
(Unaudited)
Three Months Ended		Six Months Ended
July 26,		July 27,		July 26,		July 27,
2026		2025		2026		2025
Cash flows from operating activities:
Net income	$	59,688 			$	26,422 			$	118,010 			$	45,197
Adjustments to reconcile net income to net cash
provided by operating activities:
Stock-based compensation expense	2,027 			1,624 			3,954 			3,099
Depreciation and amortization	1,127 			668 			2,124 			1,280
Deferred income taxes	(602)			18 			982 			(2,160)
Gains from equity securities, net	(7,771)			(2,247)			(23,707)			(2,073)
Other	315 			(100)			222 			(196)
Changes in operating assets and liabilities, net of acquisitions:
Accounts receivable	(22,346)			(5,675)			(24,590)			(4,743)
Inventories	(5,784)			(3,622)			(10,204)			(4,880)
Prepaid expenses and other assets	(5,497)			387 			(6,480)			946
Accounts payable	1,915 			1,314 			4,125 			2,255
Accrued and other current liabilities	252 			(4,053)			8,015 			3,075
Other long-term liabilities	753 			629 			1,970 			979
Net cash provided by operating activities	24,077 			15,365 			74,421 			42,779
Cash flows from investing activities:
Proceeds from sales and maturities of debt securities	24,592 			3,150 			26,563 			6,739
Proceeds from sales of equity securities	7,215 			70 			7,241 			70
Purchases of equity securities	(15,822)			(346)			(42,404)			(1,245)
Purchases of debt securities	(21,777)			(7,812)			(21,777)			(14,108)
Purchases related to property and equipment and intangible assets	(2,677)			(1,894)			(4,434)			(3,122)
Acquisitions, net of cash acquired	(211)			(294)			(298)			(677)
Other	(15)			— 			(15)			—
Net cash used in investing activities	(8,695)			(7,126)			(35,124)			(12,343)
Cash flows from financing activities:
Proceeds related to issuance of debt, net of costs	24,896 			— 			24,896 			—
Proceeds related to employee stock plans	— 			— 			515 			370
Payments related to repurchases of common stock	(19,732)			(9,721)			(39,044)			(23,815)
Dividends paid	(6,047)			(244)			(6,290)			(488)
Payments related to employee stock plan taxes	(2,402)			(1,848)			(4,531)			(3,380)
Groq, Inc.	(2,944)			— 			(2,944)			—
Principal payments on property and equipment and intangible assets	(59)			(21)			(92)			(73)
Other	112 			— 			31 			—
Net cash used in financing activities	(6,176)			(11,834)			(27,459)			(27,386)
Change in cash and cash equivalents	9,206 			(3,595)			11,838 			3,050
Cash and cash equivalents at beginning of period	13,237 			15,234 			10,605 			8,589
Cash and cash equivalents at end of period	$	22,443 			$	11,639 			$	22,443 			$	11,639
NVIDIA CORPORATION
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES
($ In millions, except per share data)
(Unaudited)
Three Months Ended		Six Months Ended
July 26,		April 26,		July 27,		July 26,		July 27,
2026		2026		2025		2026		2025
GAAP cost of revenue		$	24,079 			$	20,458 			$	12,890 			$	44,538 			$	30,284
GAAP gross profit		$	72,142 			$	61,157 			$	33,853 			$	133,299 			$	60,521
GAAP gross margin		75.0 	%		74.9 	%		72.4 	%		75.0 	%		66.6 	%
Acquisition-related and other costs (A)		46 			47 			49 			93 			170
Other		— 			28 			— 			28 			4
Non-GAAP cost of revenue		$	24,033 			$	20,383 			$	12,841 			$	44,417 			$	30,110
Non-GAAP gross profit		$	72,188 			$	61,232 			$	33,902 			$	133,420 			$	60,695
Non-GAAP gross margin*		75.0 	%		75.0 	%		72.5 	%		75.0 	%		66.8 	%
GAAP operating expenses		$	8,408 			$	7,621 			$	5,413 			$	16,029 			$	10,443
Acquisition-related and other costs (A)		(176)			(172)			(37)			(348)			(74)
Other		— 			— 			(15)			— 			(15)
Non-GAAP operating expenses		$	8,232 			$	7,449 			$	5,361 			$	15,681 			$	10,354
GAAP operating income		$	63,734 			$	53,536 			$	28,440 			$	117,270 			$	50,078
Total impact of non-GAAP adjustments to operating income		222 			247 			101 			469 			263
Non-GAAP operating income*		$	63,956 			$	53,783 			$	28,541 			$	117,739 			$	50,341
GAAP other income, net		$	7,773 			$	16,367 			$	2,766 			$	24,140 			$	3,039
Gains from equity securities, net		(7,771)			(15,936)			(2,247)			(23,707)			(2,073)
Other (B)		298 			26 			1 			323 			2
Non-GAAP other income, net		$	300 			$	457 			$	520 			$	756 			$	968
GAAP net income		$	59,688 			$	58,321 			$	26,422 			$	118,010 			$	45,197
Total pre-tax impact of non-GAAP adjustments		(7,251)			(15,663)			(2,145)			(22,915)			(1,808)
Income tax impact of non-GAAP adjustments		1,517 			2,890 			438 			4,407 			418
Tax expense from OBBBA**		— 			— 			48 			— 			48
Non-GAAP net income*		$	53,954 			$	45,548 			$	24,763 			$	99,502 			$	43,855
Diluted net income per share
GAAP		$	2.46 			$	2.39 			$	1.08 			$	4.85 			$	1.84
Non-GAAP*		$	2.22 			$	1.87 			$	1.01 			$	4.09 			$	1.78
Weighted average shares used in diluted net income per share computation		24,285 			24,391 			24,532 			24,338 			24,571
GAAP net cash provided by operating activities		$	24,077 			$	50,344 			$	15,365 			$	74,421 			$	42,779
Purchases related to property and equipment and intangible assets		(2,677)			(1,757)			(1,894)			(4,434)			(3,122)
Principal payments on property and equipment and intangible assets		(59)			(33)			(21)			(92)			(73)
Free cash flow		$	21,341 			$	48,554 			$	13,450 			$	69,895 			$	39,584
*Includes H20 charges/(releases), net, which were $4.5 billion and none for the first quarter, and ($180 million) and insignificant for the second quarter, of fiscal years 2026 and 2027, respectively.
**Tax expense included represents impact from OBBBA (One Big Beautiful Bill Act).
(A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items:
Three Months Ended		Six Months Ended
July 26,		April 26,		July 27,		July 26,		July 27,
2026		2026		2025		2026		2025
Cost of revenue		$	46 			$	47 			$	49 			$	93 			$	170
Research and development		$	170 			$	167 			$	29 			$	337 			$	57
Sales, general and administrative		$	6 			$	5 			$	8 			$	11 			$	17
(B) Comprised of net (gains)/losses on equity derivatives, interest expense related to acquisition consideration discount to be paid in the future, share of net (earnings)/losses related to equity method investments, and dividend income on equity securities.
NVIDIA CORPORATION
RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK
Q3 FY2027 Outlook
($ in billions)
GAAP gross margin		74.0 	%
Impact of acquisition-related costs and other costs		—
Non-GAAP gross margin		74.0 	%
GAAP operating expenses		$	9.2
Acquisition-related costs and other costs		(0.2)
Non-GAAP operating expenses		$	9.0
EX-99.2
3
q2fy27cfocommentary.htm
EX-99.2
Document
CFO Commentary on Second Quarter Fiscal 2027 Results
Q2 Fiscal 2027 Summary
GAAP
($ in millions, except earnings per share)	Q2 FY27	Q1 FY27	Q2 FY26	Q/Q	Y/Y
Revenue	$96,221	$81,615	$46,743	18 	%	106 	%
Gross margin	75.0 	%	74.9 	%	72.4 	%	0.1 pts	2.6 pts
Operating expenses	$8,408	$7,621	$5,413	10 	%	55 	%
Operating income	$63,734	$53,536	$28,440	19 	%	124 	%
Net income	$59,688	$58,321	$26,422	2 	%	126 	%
Diluted earnings per share	$2.46	$2.39	$1.08	3 	%	128 	%
Non-GAAP
($ in millions, except earnings per share)	Q2 FY27	Q1 FY27	Q2 FY26	Q/Q	Y/Y
Revenue	$96,221	$81,615	$46,743	18 	%	106 	%
Gross margin	75.0 	%	75.0 	%	72.5 	%	—	2.5 pts
Operating expenses	$8,232	$7,449	$5,361	11 	%	54 	%
Operating income	$63,956	$53,783	$28,541	19 	%	124 	%
Net income	$53,954	$45,548	$24,763	18 	%	118 	%
Diluted earnings per share	$2.22	$1.87	$1.01	19 	%	120 	%
Revenue by Reportable Segments
($ in millions)	Q2 FY27	Q1 FY27	Q2 FY26	Q/Q	Y/Y
Compute & Networking	$88,299	$74,550	$41,331	18 	%	114 	%
Graphics	7,922	7,065	5,412	12 	%	46 	%
Total	$96,221	$81,615	$46,743	18 	%	106 	%
Revenue by Market Platform
($ in millions)	Q2 FY27	Q1 FY27	Q2 FY26	Q/Q	Y/Y
Data Center	$89,023	$75,246	$41,096	18 	%	117 	%
Hyperscale	48,710	43,050	24,168	13 	%	102 	%
AI Clouds, Industrial, & Enterprise	40,313	32,196	16,928	25 	%	138 	%
Edge Computing	7,198	6,369	5,647	13 	%	27 	%
Total	$96,221	$81,615	$46,743	18 	%	106 	%
We specialize in markets where our computing platforms can provide tremendous acceleration for applications. These platforms incorporate processors, interconnects, software, algorithms, systems, and services to deliver unique value. Our platforms address large markets where our expertise is critical: Data Center and Edge Computing.
During the second quarter we reclassified a company from AI Clouds, Industrial, & Enterprise (ACIE) to Hyperscale due to a change in their business model and recast the prior period revenue associated with this company.
Revenue
Revenue for the second quarter was a record $96.2 billion, up 106% from a year ago and up 18% sequentially.
Data Center revenue for the second quarter was a record $89.0 billion, up 117% from a year ago and up 18% sequentially, driven by the ramp of our Blackwell Ultra infrastructure. Hyperscale revenue more than doubled from a year ago and increased 13% sequentially on the strength of Blackwell Ultra. ACIE revenue increased 138% from a year ago and 25% sequentially driven by end-demand from AI natives, enterprises, and sovereign customers, as well as hyperscalers utilizing AI clouds. Shipments of Data Center Hopper products to China during the quarter were less than 1% of Data Center revenue.
Edge Computing revenue for the second quarter was $7.2 billion, up 27% from a year ago and up 13% sequentially. The increases were driven by strong sales of Blackwell workstations, partially offset by slower consumer PC sales that were tempered by elevated memory and systems prices.
Gross Margin
GAAP and non-GAAP gross margins for the second quarter increased from a year ago on improved mix from Blackwell Ultra. GAAP and non-GAAP gross margins were approximately flat sequentially as our Blackwell architecture remains the vast majority of our revenue.
Expenses
GAAP operating expenses for the second quarter were up 55% from a year ago and up 10% sequentially, and non-GAAP operating expenses were up 54% from a year ago and up 11% sequentially. These increases were driven by higher compute infrastructure and compensation and benefits costs.
Other Income, Net and Income Tax
GAAP other income, net includes equity securities gains or losses, interest income, interest expense, and other income and expense. Non-GAAP other income, net excludes equity securities gains or losses and certain other income and expense.
Net gains from equity securities for the second quarter were $7.8 billion.
GAAP effective tax rate for the second quarter was 16.5%, an increase from a year ago, primarily due to higher revenue. Non-GAAP effective tax rate for the second quarter was 16.0%.
Commitments
We continue to make strategic commitments across our supply, infrastructure, and partner ecosystems to capitalize on the substantial growth opportunities ahead of us.
We’ve partnered with our extensive network of suppliers to secure the critical components needed to meet demand for the next several years. Our commitments increased from $119 billion last quarter to $279 billion, primarily related to the procurement of memory.
Our cloud service agreements and data center lease commitments together provide the physical and cloud infrastructure that powers our research and development — from the engineering, product design, and testing of our compute chips, networking products, and systems, to the development of our open models, such as NVIDIA Nemotron™, NVIDIA Cosmos™, and GR00T, and our autonomous vehicle software. Our upcoming data center leases have terms up to twenty years and are expected to commence between the third quarter of fiscal year 2027 and fiscal year 2033.
Our equity investments are focused on AI model makers, infrastructure financiers, and other private companies, subject to certain contingencies.
Future commitments by fiscal year as of July 26, 2026, were as follows:
Remainder of 2027		2028		2029		2030		2031		2032 and thereafter		Total
(In billions)
Supply and capacity	$	92 			$	87 			$	88 			$	6 			$	5 			$	1 			$	279
Cloud service agreements	3 			8 			7 			6 			4 			1 			29
Data center leases not commenced	— 			1 			1 			2 			1 			20 			25
Equity investments	18 			3 			2 			2 			— 			— 			25
Capital expenditures	7 			1 			— 			— 			— 			— 			8
Total	$	120 			$	100 			$	98 			$	16 			$	10 			$	22 			$	366
Additional Commitments
Securing land, power and shell for data centers has become the next critical phase in the AI infrastructure buildout. AI clouds and model makers are seeing extraordinary demand for AI infrastructure, yet many are growing faster than their balance sheets and long-term credit profiles can support. In response, we have entered into arrangements that help select customers secure the land, power and data center capacity needed to support their growth. We will focus on exceptional sites where visible, durable demand can support multiple generations of NVIDIA compute.
We have partnered with leading AI clouds to enable broader access to our AI infrastructure to serve AI startups, model builders, enterprises, research organizations and sovereign customers. Under these agreements, we will earn revenue on the upfront sale of our infrastructure and if certain criteria are met, we will participate in revenue share generated by the AI clouds from their third-party customers.
We signed data center lease agreements with terms of approximately fifteen years that are expected to commence between fiscal year 2028 and fiscal year 2029. We expect to reassign these data center leases to third parties.
Future commitments by fiscal year as of July 26, 2026, were as follows:
Remainder of 2027		2028		2029		2030		2031		2032 and thereafter		Total
(In billions)
AI cloud agreements	$	— 			$	6 			$	8 			$	7 			$	6 			$	9 			$	36
Data center leases not commenced for third party	— 			— 			1 			1 			1 			17 			20
Total	$	— 			$	6 			$	9 			$	8 			$	7 			$	26 			$	56
Guarantees
We have land, power, and shell guarantees for certain AI cloud partners’ data center lease obligations in the event of their default. The maximum gross exposure under all agreements is $3.5 billion.
In August 2026, we entered into guarantees to provide credit support on the land, power, and shell buildout to secure approximately 4.25 gigawatts (GW) at SB Energy's PORTS-Pike Technology Campus in Ohio, which will exclusively host NVIDIA infrastructure under 20-year leases to OpenAI, subject to limited exceptions. Our guarantee obligations are capped at a total of $105 billion and become effective in phases as certain conditions are met, including data centers becoming ready for service, with the first expected in fiscal 2029. Our guarantee exposure declines as OpenAI fulfills lease payments. We also have the option to provide credit support in phases for approximately 3.8 additional GW as the site scales. Each generation of NVIDIA infrastructure deployed at PORTS-Pike could represent approximately 1.5 million NVIDIA GPUs, or approximately $150 billion to $200 billion in NVIDIA revenue. Over 20 years, we expect the site can support multiple infrastructure upgrade cycles.
The following table summarizes the maximum gross exposure related to our guarantees, including the SB Energy Corp. guarantees signed in August 2026 (in billions):
Land, power, and shell guarantees for AI clouds	$	3.5
SB Energy Corp. guarantees	105.0
Total	$	108.5
Balance Sheet and Cash Flow
Cash, cash equivalents, and marketable debt securities were $56.6 billion, up from $53.6 billion a year ago and up from $50.3 billion a quarter ago. These changes were driven by higher free cash flow that was used to return a record of nearly $26.0 billion to shareholders in the second quarter through share repurchases and cash dividends.
Accounts receivable was $63.1 billion with 60 days sales outstanding (DSO), up from 45 days sequentially, due to extended payment terms on large, multi-quarter agreements with certain investment-grade customers.
Inventory was $31.6 billion, up from $25.8 billion sequentially, as we prepare for the introduction of Vera Rubin in the third quarter.
Cash flow from operating activities was $24.1 billion, up from $15.4 billion a year ago and down from $50.3 billion a quarter ago. The year-on-year increase reflects growth in revenue, while the sequential decrease was driven by higher working capital adjustments and cash taxes.
We issued $25.0 billion of senior unsecured notes in the second quarter to be used for general corporate purposes.
Outlook
Outlook for the third quarter of fiscal 2027 is as follows:
•Revenue is expected to be $108.0 billion, plus or minus 2%. We are not assuming any Data Center compute revenue from China in our outlook.
•GAAP and non-GAAP gross margins are expected to be 74.0%, plus or minus 50 basis points.
•GAAP and non-GAAP operating expenses are expected to be approximately $9.2 billion and $9.0 billion, respectively.
For the full year fiscal 2027, we expect GAAP and non-GAAP tax rates to be between 16.0% and 18.0%, excluding any discrete items and material changes to our tax environment.
______________
For further information, contact:
Toshiya Hari		Mylene Mangalindan
Investor Relations		Corporate Communications
NVIDIA Corporation		NVIDIA Corporation
IR@nvidia.com		press@nvidia.com
Non-GAAP Measures
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude acquisition-related and other costs, other, gains/losses from equity securities, net, certain other income and expense, and the associated tax impact of these items where applicable. Beginning in the first quarter of fiscal 2027, NVIDIA’s non-GAAP financial measures no longer exclude stock-based compensation expense. The historical non-GAAP financial information presented has been updated to include stock-based compensation expense. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the users' overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.
Certain statements in this CFO Commentary including, but not limited to, statements as to: the buildout of AI factories; our strategy and expectations regarding data center sites; expectations with respect to growth, performance and benefits of our products, services, and technologies, including Blackwell and Vera Rubin, and related trends and drivers; expectations with respect to supply and demand for our products, services, and technologies, including Blackwell and Vera Rubin, and related matters including inventory, production and distribution; expectations with respect to our strategic commitments and their anticipated benefits; expectations with respect to our third party arrangements, including with our collaborators and partners; expectations with respect to upcoming data center leases, including their commencement and reassignment; expectations regarding revenue under agreements with AI clouds; expectations with respect to the PORTS-Pike Technology
Campus, including its buildout, related guarantees, and anticipated NVIDIA deployments, revenue and upgrade cycles; expectations with respect to our investments; expectations with respect to our financing arrangements; expectations with respect to technology developments, and related trends and drivers; our future cash dividends or other returns to stockholders, our financial and business outlook for the third quarter of fiscal 2027 and beyond; projected market growth and trends; expectations with respect to AI and related industries; and other statements that are not historical facts are forward-looking statements within the meaning of Section 27A of the Securities Act of 1933, as amended, and Section 21E of the Securities Exchange Act of 1934, as amended, which are subject to the “safe harbor” created by those sections based on management’s beliefs and assumptions and on information currently available to management and are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic and political conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing products and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; our ability to realize the potential benefits of business investments or acquisitions; and changes in applicable laws and regulations, as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its Annual Report on Form 10-K and Quarterly Reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.
###
© 2026 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, NVIDIA Nemotron, and NVIDIA Cosmos are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.
NVIDIA CORPORATION
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES
($ In millions, except per share data)
(Unaudited)
Three Months Ended		Six Months Ended
July 26,		April 26,		July 27,		July 26,		July 27,
2026		2026		2025		2026		2025
GAAP cost of revenue		$	24,079 			$	20,458 			$	12,890 			$	44,538 			$	30,284
GAAP gross profit		$	72,142 			$	61,157 			$	33,853 			$	133,299 			$	60,521
GAAP gross margin		75.0 	%		74.9 	%		72.4 	%		75.0 	%		66.6 	%
Acquisition-related and other costs (A)		46 			47 			49 			93 			170
Other		— 			28 			— 			28 			4
Non-GAAP cost of revenue		$	24,033 			$	20,383 			$	12,841 			$	44,417 			$	30,110
Non-GAAP gross profit		$	72,188 			$	61,232 			$	33,902 			$	133,420 			$	60,695
Non-GAAP gross margin*		75.0 	%		75.0 	%		72.5 	%		75.0 	%		66.8 	%
GAAP operating expenses		$	8,408 			$	7,621 			$	5,413 			$	16,029 			$	10,443
Acquisition-related and other costs (A)		(176)			(172)			(37)			(348)			(74)
Other		— 			— 			(15)			— 			(15)
Non-GAAP operating expenses		$	8,232 			$	7,449 			$	5,361 			$	15,681 			$	10,354
GAAP operating income		$	63,734 			$	53,536 			$	28,440 			$	117,270 			$	50,078
Total impact of non-GAAP adjustments to operating income		222 			247 			101 			469 			263
Non-GAAP operating income*		$	63,956 			$	53,783 			$	28,541 			$	117,739 			$	50,341
GAAP other income, net		$	7,773 			$	16,367 			$	2,766 			$	24,140 			$	3,039
Gains from equity securities, net		(7,771)			(15,936)			(2,247)			(23,707)			(2,073)
Other (B)		298 			26 			1 			323 			2
Non-GAAP other income, net		$	300 			$	457 			$	520 			$	756 			$	968
GAAP net income		$	59,688 			$	58,321 			$	26,422 			$	118,010 			$	45,197
Total pre-tax impact of non-GAAP adjustments		(7,251)			(15,663)			(2,145)			(22,915)			(1,808)
Income tax impact of non-GAAP adjustments		1,517 			2,890 			438 			4,407 			418
Tax expense from OBBBA**		— 			— 			48 			— 			48
Non-GAAP net income*		$	53,954 			$	45,548 			$	24,763 			$	99,502 			$	43,855
Diluted net income per share
GAAP		$	2.46 			$	2.39 			$	1.08 			$	4.85 			$	1.84
Non-GAAP*		$	2.22 			$	1.87 			$	1.01 			$	4.09 			$	1.78
Weighted average shares used in diluted net income per share computation		24,285 			24,391 			24,532 			24,338 			24,571
GAAP net cash provided by operating activities		$	24,077 			$	50,344 			$	15,365 			$	74,421 			$	42,779
Purchases related to property and equipment and intangible assets		(2,677)			(1,757)			(1,894)			(4,434)			(3,122)
Principal payments on property and equipment and intangible assets		(59)			(33)			(21)			(92)			(73)
Free cash flow		$	21,341 			$	48,554 			$	13,450 			$	69,895 			$	39,584
*Includes H20 charges/(releases), net, which were $4.5 billion and none for the first quarter, and ($180 million) and insignificant for the second quarter, of fiscal years 2026 and 2027, respectively.
**Tax expense included represents impact from OBBBA (One Big Beautiful Bill Act).
(A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items:
Three Months Ended		Six Months Ended
July 26,		April 26,		July 27,		July 26,		July 27,
2026		2026		2025		2026		2025
Cost of revenue		$	46 			$	47 			$	49 			$	93 			$	170
Research and development		$	170 			$	167 			$	29 			$	337 			$	57
Sales, general and administrative		$	6 			$	5 			$	8 			$	11 			$	17
(B) Comprised of net (gains)/losses on equity derivatives, interest expense related to acquisition consideration discount to be paid in the future, share of net (earnings)/losses related to equity method investments, and dividend income on equity securities.
NVIDIA CORPORATION
RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK
Q3 FY2027 Outlook
($ in billions)
GAAP gross margin		74.0 	%
Impact of acquisition-related costs and other costs		—
Non-GAAP gross margin		74.0 	%
GAAP operating expenses		$	9.2
Acquisition-related costs and other costs		(0.2)
Non-GAAP operating expenses		$	9.0
EX-101.SCH
4
nvda-20260826.xsd
XBRL TAXONOMY EXTENSION SCHEMA DOCUMENT
0000001 - Document - Document and Entity Information
link:presentationLink
link:calculationLink
link:definitionLink
EX-101.LAB
5
nvda-20260826_lab.xml
XBRL TAXONOMY EXTENSION LABEL LINKBASE DOCUMENT
Entity Tax Identification Number
Entity Tax Identification Number
Entity File Number
Entity File Number
Title of 12(b) Security
Title of 12(b) Security
Local Phone Number
Local Phone Number
Document Period End Date
Document Period End Date
Soliciting Material
Soliciting Material
Entity Address, Address Line One
Entity Address, Address Line One
Document and Entity Information [Abstract]
Document and Entity Information [Abstract]
Document and Entity Information [Abstract]
Entity Address, Postal Zip Code
Entity Address, Postal Zip Code
Entity Registrant Name
Entity Registrant Name
Pre-commencement Issuer Tender Offer
Pre-commencement Issuer Tender Offer
Entity Address, State or Province
Entity Address, State or Province
Entity Address, City or Town
Entity Address, City or Town
Amendment Flag
Amendment Flag
Entity Incorporation, State or Country Code
Entity Incorporation, State or Country Code
Written Communications
Written Communications
Security Exchange Name
Security Exchange Name
Trading Symbol
Trading Symbol
Document Type
Document Type
City Area Code
City Area Code
Pre-commencement Tender Offer
Pre-commencement Tender Offer
Entity Central Index Key
Entity Central Index Key
Entity Emerging Growth Company
Entity Emerging Growth Company
EX-101.PRE
6
nvda-20260826_pre.xml
XBRL TAXONOMY EXTENSION PRESENTATION LINKBASE DOCUMENT
GRAPHIC
7
nvdalogoa19.jpg
NVDA LOGO
begin 644 nvdalogoa19.jpg
M_]C_X  02D9)1@ ! 0$ > !X  #_X0"R17AI9@  34T *@    @ !P$^  4
M   "    8@$_  4    &    <@,!  4    !    H@,#  $    !     %$0
M  $    ! 0   %$1  0    !   AU%$2  0    !   AU        'HF  &&
MH   @(0  8:@  #Z   !AJ   (#H  &&H   =3   8:@  #J8  !AJ   #J8
M  &&H   %W   8:@  &&H   L8__VP!#  (! 0(! 0(" @(" @(" P4# P,#
M P8$! ,%!P8'!P<&!P<("0L)" @*" <'"@T*"@L,# P,!PD.#PT,#@L,# S_
MVP!# 0(" @,# P8# P8," <(# P,# P,# P,# P,# P,# P,# P,# P,# P,
M# P,# P,# P,# P,# P,# P,# P,# S_P  1" !I =$# 2(  A$! Q$!_\0
M'P   04! 0$! 0$           $" P0%!@<("0H+_\0 M1   @$# P($ P4%
M! 0   %] 0(#  01!1(A,4$&$U%A!R)Q%#*!D:$((T*QP152T? D,V)R@@D*
M%A<8&1HE)B7J#A(6&AXB)BI*3E)66EYB9FJ*CI*6FIZBIJK*SM+6VM[BYNL+#Q,7&
MQ\C)RM+3U-76U]C9VN'BX^3EYN?HZ>KQ\O/T]?;W^/GZ_\0 'P$  P$! 0$!
M 0$! 0        $" P0%!@<("0H+_\0 M1$  @$"! 0#! <%! 0  0)W  $"
M Q$$!2$Q!A)!40=A<1,B,H$(%$*1H;'!"2,S4O 58G+1"A8D-.$E\1<8&1HF
M)R@I*C4V-S@Y.D-$149'2$E*4U155E=865IC9&5F9VAI:G-T=79W>'EZ@H.$
MA8:'B(F*DI.4E9:7F)F:HJ.DI::GJ*FJLK.TM;:WN+FZPL/$Q<;'R,G*TM/4
MU=;7V-G:XN/DY>;GZ.GJ\O/T]?;W^/GZ_]H # ,!  (1 Q$ /P#]_**** "B
MBB@ HHHH **BOG,=E,R\,J,0?3BORJ\1?ML_%6U\07\4?C;5ECCN9$51LX 8
M@#[M?G_'7B)@N%E1>,ISG[7FMRVTY;7O=KN<.-Q\,-;G3=^Q^K5%?DS_ ,-P
M?%C_ *'C6/\ R'_\31_PW!\6/^AXUC_R'_\ $U^>_P#$Q62?] U7_P D_P#D
MC@_MZC_*_P /\S]9J*_)G_AN#XL?]#QK'_D/_P")H_X;@^+'_0\:Q_Y#_P#B
M:/\ B8K)/^@:K_Y)_P#)!_;U'^5_A_F?K-17Y,_\-P?%C_H>-8_\A_\ Q-'_
M  W!\6/^AXUC_P A_P#Q-'_$Q62?] U7_P D_P#D@_MZC_*_P_S/UFHK\F?^
M&X/BQ_T/&L?^0_\ XFC_ (;@^+'_ $/&L?\ D/\ ^)H_XF*R3_H&J_\ DG_R
M0?V]1_E?X?YGZS45^>W[#'[4WQ!^)'[2NAZ1KGBG4M2TVY68RV\NS:^(V(SA
M0>"*_0FOU+@GC/"\38&6/PD)0C&3C:5KW23OHWIJ>E@\9'$0YX*VMM0HHHK[
M ZPHHHH **** "BBB@ HHHH **** "BBB@ HHHH **** "BBB@ HHHH ****
M "BBB@ HHHH **** "BBB@ HHHH **** "BBB@ HHHH **** "BBB@ HHK@_
MC?\ M*>$?V?=&^U>(M4AAG8$PV41$EU/_NIUQ[G ]ZY,=C\-@Z$L3BYJ$([N
M322^;)G4C"/-)V1WE8/C;XI>&_AM9FXU_7=)T>(#.;NY2(M] 3D_05\!?';_
M (*A^,OB'/-9^$X_^$5TUCM61")+R0?[^,+G_9&1ZUQ'P]_8]^*_[1MV-2DT
M_4%AN#N.H:S*T8<'N-_S,/H,5^*9EXV0Q&(>"X8PD\54[V:CZV2/
M4SA2ER8:+D_Z_KH?9WC/_@I7\*]$66VMM4OM6E8% ;2T8H2>/O-BOFN?_@EQ
MX_\ $_F:I;W_ (?$6H,;F)'G<,%<[AGY<9P:[+PQ_P $@[BVM/M&M^,X5DC7
M>8;*R+ $,Y*GB72="&OL52WOIS\W+*;T]VU[==#DK2Y[/,5RKI;\>_D<'XM_X)
ML?%CPO$TD>BVNK(O_/E=H['_ ("V#7COB[X?Z[X OC:ZYH^IZ1< X\N\MGA8
M_P#?0%?;WP[_ ."O&AZG<1P^)_#-[I8;@W-E.+A!]4(5A^!-?1/AGQK\/_VH
M?";_ &.?1/%%A(,2V\JK(\6>SQM\RGZ@5YM#POX0S^+7#68M5/Y)ZO\ \!:A
M*WGJ9QRW"U_]WJ:]G_29^0%%??'[1?\ P2KTO78+C4OA_ %_P"S+ABU
MO*?1'/*'ZY'TKX?\=_#_ %KX9>)+C2->TZZTS4+=B'BG0KGW4]&4]B.#7Y'Q
M9P'G'#M7DS"G[CVG'6#]'T?DTGY'EXK U<.[5%IWZ&/1117QIR!1110![I_P
M3A_Y.X\-_P"Y%?"
M>FV.G2VVG6MO:M'"TELCN07B9N6)/)K]X/;/Z2J*_C6_XB)OVU/^B_\ BS_P
M%LO_ (Q1_P 1$W[:G_1?_%G_ ("V7_QB@#^RFBOXUO\ B(F_;4_Z+_XL_P#
M6R_^,5UWP\_X.@?VU/ 5Y')-\6AXACC()AU70[&56'H2D2-^N: /Z^Z*_G__
M &#_ /@]%FO/$-CHG[0G@&U@L;AQ&_B3PPS#[+_M2VCYW+ZE'!']TU^ZWP2^
M.'A/]H[X7Z/XT\#Z]IOB7PSKUNMS97]C,)8I5(S@X^ZPZ%3@J000"* .JHK\
M/_\ @Z@_;T_:@_X)V_'?X>:Y\*?BEK'A3P'XVTJ:W:R@TVRGBAOK9P9#OFA=
MLO'+&<9Q\IP.M?E+_P 1)/[;G_1>M=_\$^E__(U ']C5%?CU_P &I_\ P5L^
M)G_!0'2OBIX1^,/C*?QCXK\-RVNJZ;=7%M;V\BV<@,3QA88T4A9%!R02/,Z]
M*_86@ HHK\ ?^#FS_@N1\;/V2/V[M-^&7P3^(EWX-M?#F@P3ZXMK9VESY]W<
M$R*&,T3E2L6PX&/OT ?O]17\,?$7C75KJ\TR2[M+>V:TTY-L,2!88T4[GCD
MDR03AQS0!]Y45_,3_P %I_\ @NC^U=^S'_P4^^+G@7P+\8M7\/\ A/P[JR6^
MG:?%IFGRI:QF")BH:2!G/S,3RQZU\M_\1)/[;G_1>M=_\$^E_P#R-0!_8U17
MC/\ P3I^)FN?&;]@WX/^+/$VH2:MXB\2>$=.U'4KUT5&NKB6W1WM=_\$^E_P#R-0!_8U17X<_\&J/_
M  5/^/W[?O[2?Q0T3XO_ !&U#QKI>@^&X+VPM[BQM+<6\S7(0N##$A.5XP21
M7[C4 %%%?/?_  52_;+@_8&_8$^)?Q.,T46J:'H\L>BK(1^^U&53':K@]?WK
M*2,'A30!]"45_'*W_!R5^VX3_P EZUP>W]CZ7_\ (U'_ !$D_MN?]%ZUW_P3
MZ7_\C4 ?V-45_.__ ,&Y'_!?WXU?M"?\%"K'X8_'7XBW7B_1?'>G3VFBM>6=
MI:_8]1B4S( 88DSYB)(F"3\Q4#K7]$% !1110 4444 %%%% !2.ZQH68A549
M))X%+7P[_P %-?VJ_$WA[Q1)\/\ 2UFT?3Y+9)KNZ5L2WZOT52/NH,$'N2".
MG7Y;C'BS"\.Y9+,L4G))V26[D]E?9+35O;S=D^;%XJ.'I^TD=1^U[_P4JL_
MOC3PCX0\9?M2_$_[-;&]U[7-
M0;?-<3N6$:]W=NBJ/_K"N:\'^%[KQQXLTW1K/R_MFK74=I#O;:N]V"C)/09-
M?K!^S%^S5HO[,WP]BTVQ5)M2F4/J-\1\]U)U/T4= /3WS7\R9)AR^2/G*,:V8U;U':*_K3S\SA_P!F/_@GQX3^!=K;
MZAJT,/B+Q,HRUU.F8+<^D49X_P"!'GZ5V_QK_:U\"? ")H]>%_A[<>1#"QAN]84?/(1P5A]!VW]3V]:\
M!_9P_99\5?M7^*YGM6>'3XY,W^K71+*C'G [NY]/?)Q7VF,\0\'E-6/#7 F$
MC5J7MS)7C=;OO-KK*327=H[)X^%)_5\%&[_K[_4^@?'?_!7>2^G>W\.>$UC@
MDR@FU"XRY!XSL3@?3<:['3?^"5_@?Q5HL.I3:QXBCN]2C%TY22/8C.-Q &WI
MD^M=-X,_X)F?#'P7H#"^L;[7KY(RS7%UOUQ77Q5X+996PO]J\,5/8S2YX^\W"2M=-2;O%VU
M3O;TW-,5D].4?:X9V>^^GW]#S/\ 8Q_X*%6/QJDM_#?BPPZ;XH8;8)QA+?4<
M#M_=D_V>A[>E>O?M"_LT^&?VD/"C:?KEJJW<2G['?QC$]HWJ#W'JIX-?D==#
M^R=7D%K=>;]FF(BN(LKOVGAUS@C.,CO7Z;_\$\?CMX@^-_P79_$%K.UQHLJV
M<>HN/EU%0O7W=> QZ'([YK+PO\0/]9*(8*K)Q=I-74XK=2MIS+=2Z_XK
M-SEN.^L+ZM75_P!?7_,_/W]HC]G37_V;O',FCZS%YD$A+6=[&I\F\C_O*>Q'
M=>H/YUP-?KY^TQ\)?#/Q?^$FJ6/BAH;:QM87N4OF(5K!U4GS0?;N.XXK\BM3
MMXK34;B*"=;J&.1ECF"E1*H. V#R,CG!K\<\5/#^/#.81^K3YJ-6[@F_>C;=
M/JTKZ2Z]=4>3F6!^K5/=>CV[D%%%%?EIYI[I_P $X?\ D[CPW_N7'_HEJ_4B
MORW_ ."O^2#VS\YJ^
MH?@M_P $7OVGOVA_A;HOC7P9\(?$VO>%_$,'VG3M0MQ'Y5U'N*[ERP.,J1T[
M5\O5_9E_P;V_\H8?V?O^Q<;_ -*IZ /YDYO^#?S]L2"%G;X$^,2%&2%6(D_0
M;Z^<_CU^S#\1/V6_%*Z+\1O!/B;P7JCC='!J]A):F9?[R%@ X]U)%?WA5X-_
MP4>_8#\%_P#!1W]EGQ%\._%^FVMQ)>VSR:1?M&//TF]"GRIXVZKAL9 X920:
M /X?*_7C_@TP_P""H>K?LX?M@VOP+\0:G--X#^*LWDZ=!,^8],U8*3$R9^Z)
M@/+('!8H>HK\G?'_ (+OOAMX[UKP[JD1AU+0;^?3KN,_\LY89&C\\-Z[9:G!(IP4>&=) 1]"M ']47_!UA^R;_PTK_P2
M@\0:W:VWG:O\+;^'Q/;E5RXA7,-P![>7(6/^X#VK^2VO[R/&G@_3?VC_ -GK
M5-!U2)9](\=>'I;*ZC(X>&ZMRC#_ +Y.,?\  C7]=-?P4?!KXG:A\%?BWX9\7Z5(8]2\,ZI;ZI;,
M#CYX9%$_&6DR";3/%6D6NK6KC^*.>%9%_1J .BU
M+48='TZXN[F18;>UC::5VZ(J@DD_0"OX??\ @IE^TI-^U]^WW\6?B--*TT?B
M7Q'(K
M^#3K.%>LDLKA$'YL*_NH_9E^!>F?LR?L\^"_A[HZJNF^#M&MM*A*C&_RHU4O
M]68%C[FOY6O^#6']DO\ X:>_X*S>%]2O+8S:+\,[*?Q5=L1E1+'MBMU/N9I5
M;Z(:_K>H _C5_P"#A_\ Y3,?'?\ [#B?^DT-?%M?:7_!P_\ \IF/CO\ ]AQ/
M_2:&OBV@#^WC_@DU_P HR/@'_P!B)I/_ *2QU_,S_P '5G_*<+XL?]>6A?\
MIGLZ_IF_X)-?\HR/@'_V(FD_^DL=?S,_\'5G_*<+XL?]>6A?^F>SH _.VOL[
MX)_\&_/[6'[0_P )/#WCCPC\+Y]5\,^*;&/4=,O!J5K&+F"095]K2 C([$ U
M\8U_:K_P1!_Y1%?L[_\ 8CZ?_P"BQ0!_*U\;O^"&W[6'[/GA^?5?$GP1\9KI
MMJADFN+"V&H+$HY+,("Y 'KC KY2N+>2TG>*:-XI(R5='7:RD=01VK^_D\U^
M'_\ P=@?\$:_"?B7X!:C^TE\/]%M=&\7^&9HCXK@LXQ'#J]DY"?:2BC'G1L4
M);^)"V9-$\3!0%-U($#17>T< 3("3@ ;T
M<#@5_'E7ZZ_\&;O[1EQ\-O\ @I%KG@&2X9=-^(WAR<>5GY7N;3]_&<>HC\[\
MZ /TO_X/$?\ E$I'_P!CCIO\I:_E;K^J3_@\1_Y1*1_]CCIO\I:_E;H _;3_
M (,C?^3O?C1_V*-K_P"E@K^DBOYM_P#@R-_Y.]^-'_8HVO\ Z6"OZ2* "OP"
M_P"#U/\ ;;POPU^ >D7G7?XJ\0QHW7_EE9QM_P"1G(_W#7[YZUK%MX>T>[U"
M\F6WL[&%[B>5CA8T12S,?8 $U_$K_P %7?VPKK]N[_@H+\3OB5),TFGZQK,L
M&D*3Q%I\!\JV4?\ ;-%8^[$T ?.X&37IW[4G[)7C#]D'Q)X:TKQE9?8[KQ5X
M;L/%%B #AK6[CWH#D?>4AE8=BIKMO^"5?[(-Q^W5^W_\,?AJD,DMAK6LQ2ZJ
M4_@L(3YMR<]OW2, ?4BOVO\ ^#SC]B.#5_V;OAK\9-#T](V\"W8\,:B(5QY5
MC."T!/\ LI*FP>GFB@#^?;X&?%[5O@!\9?"_CC09FM]8\)ZI;ZI:2*<$212!
MP/H<8/L:_N2_94_: TG]JK]FSP+\1]#E672_&FB6NK18/,1EB5FC/^TC%E([
M%37\(=?TR?\ !FO^V[_PMW]C[Q9\&=6N_,UCX8Z@+W3$8_,^FW9)P/\ XKY_BKA^CGF55
MLLK[5%H^TEK%_)I/\#GQ5!5J3IOJ?BCINH3:3J%O=6[M'/:R++&PZJRG(/YB
MOUZ_9K^,5M\>/@OHOB*%E::ZA\N\0=8IT^612/J,CV(K\V?VQ_V;;K]F[XM7
M5BL]=U_P $X_VHX_@K\17\/:Q<>7X=\1NJ
M;W;Y;2XZ*_LK?=/X'M7\G>%N?5N$^):N3YK[D*CY)7VC-/W)>CO:^UI)[(^8
MRVN\+B'2JZ)Z/UZ'&_MT?!*3X)?M!ZM;QPE-+U=SJ%@V/E*.-QW4C(/L:]/.L'6X XSCFU.#>%K-O3^67QP]8O6*ZI+S-:T98'%^
MU2]U_D]U\C]BM1_Y!\__ %S;^5?BQXJ_Y&C4O^ON7_T,U^K?[/?[4OAO]I/P
M$UYIMS';ZK'!_ING2./.MGV\X'\2^C#^=?E)XJ_Y&C4O^ON7_P!#->EX_P"9
M87,,'EN+PC-,\J1G&G.#NG?]#Z*_X)Y?M?V?P#UG4]
M$\37CP^&;^)KF.3:S_9KA1G@#)PX&, =<5RW[7W[:NM?M+ZTUG;^9IGA6UDS
M;62MAIR.DDO/+>@Z#Z\UX>JEF  R2< #O7T5^RS_ ,$\_$WQOO+?4M>BNO#O
MAG(8RRIMN+L>D:'D _WB,>F:_,5--[;\K>TY;*"=WK9:V
M=[)+S:-;$UJ:PM/;^MWV./\ V2OV4M7_ &F_',<$<
MKMV';.37ZB>&_#NA_!KX?V]A:+;Z7H>AVVW+$*D:*.68^IY))ZDUS\][X'_9
M'^%,:226/A_0=-3"+_'.WL/O22-^)-? /[87[=FL?M&7DFDZ7YVD>$X7.VW#
M8DOL'AIO4]L?-M
MEI]QJ4QCMX9KB0*7*QH68*!DG [ 5TGP@^#'B+XY>+H=&\.Z?+>7$A!D?&(K
M9.[NW10/U[9K]+OV4OV-O#_[-/AKA(M4\0WD>V]U"2,<@]8XP?NI^IQS7Y3D
M?"N?^(6:3S+&2Y:=]9M>ZK;0@KZV[7TW;N]?,HX:OCZCJ2V[_HC\IZ*_23]I
M/_@FKX6^+9N-4\->7X7UU\N5B3_0[AO]I!]TGU7\C7P5\9/@7XF^ WB=M+\2
M:;)9RMDPRCYH;E1_$CC@C]1W KYGC+PWSGAR;EBXO\ DG*O_7Z7_I,#W\A_W=^OZ(*_D<_X.KO^4TGQ#_[!VE?^D<=?
MUQU_(Y_P=7?\II/B'_V#M*_](XZ_>#VS\YJ_LR_X-[?^4,/[/W_8N-_Z53U_
M&;7]F7_!O;_RAA_9^_[%QO\ TJGH ^RJ*** /XF_^"RWA2+P7_P55^/UC#'Y
MX$VJ?#N[N/"UTNICD0GV0>E 'K'_
M  >R_M2_V#\)OA%\'K&X_?>(+^Z\2ZI&IY6&W58;<-[,\LI_[9?G_.S7Z"?\
M'.7[4W_#3?\ P5U^(4-O<_:-)^'YC\)VFULHK6P/GX_[;M(#_NU\!Z/I5QKV
MKVMC:QM-=7DR00HHR7=B%4#ZDB@#^E/_ (,O_P!DO_A7G[''CCXNWMOY=Y\1
M-9_LVP=@,O9V65)'?!G>0?6.OVAKQ'_@F]^S!#^QG^PM\+_AK#"L,WA?0;>&
M[55QFZ<>9<$^YE=R37MU '\:O_!P_P#\IF/CO_V'$_\ 2:&OBVOM+_@X?_Y3
M,?'?_L.)_P"DT-?%M ']O'_!)K_E&1\ _P#L1-)_])8Z_F9_X.K/^4X7Q8_Z
M\M"_],]G7],W_!)K_E&1\ _^Q$TG_P!)8Z_F9_X.K/\ E.%\6/\ KRT+_P!,
M]G0!^=M?VJ_\$0?^417[._\ V(^G_P#HL5_%57]JO_!$'_E$5^SO_P!B/I__
M *+% 'U/7B?_  4E\*6OCC_@GW\:M*OHUDMKSP5JRL",X(M)&!_ @'\*]LKX
M^_X+S_M/:;^RG_P2G^+VMWUU%;W>N:++X*8551U)"L[<= A/04
M ?QB5]Q_\&VOB&7PY_P6S^ \L;,/M&IWMHX'\2RZ;=H<_P#?0/X5\.5^@'_!
MK[X#F\*/B,!X5TG!Q(@G!^T2#_=@$G/8LM?R"U^O?_!X=^VY_P +V_;PT3X4
MZ7>>;H?PET[;=HCY5M2NMLDN>V4B$*CT);UK\A ,F@#][/\ @RI_8O\ MOBC
MXF?'C5+3,=C OA30W=>-[E9KJ1?<*L29]&8=Z_:;_@HQ^RG:_MM_L1?$KX87
M4:O)XJT2>"S+8_=W:CS+=N>F)50YK\__ /@C;_P4]_8S_P""?_\ P3D^&OPW
MN_CIX)M-?LM/^WZ\-L^YM1N6,TX8B/G8S>6#_=C%?3W_ !$)_L8_]%_\%_E<
M?_&J /XV_$6@7GA3Q!?:7J$$EK?:;<26MS"XPT4B,592/4,"/PK[5_X-X/VV
M_P#AA[_@J3\/]6OKK[+X9\87'_"+ZV6)V)!=$(DI_P"N+O _C*X77H+K3@PAM[B<%IX2&52")0QZ='%?*%E>R
MZ=>PW$$C136[K)&ZG#(P.01]#0!_?NK;ER.0>0?6BOEC_@BW^VC#^WG_ ,$V
MOACX\DN%FUS^RTTK75#99-0M0(9B?]\J)![2"OJ>@ HHHH **** "BBB@#@?
MVC_V?=(_:/\ AOTFQPP]NQ'<5^5/Q?\ A#KGP.\@Z
M]:26UW:M\CX/EW"=I$/=3[=.G6OV4KSW]HC]FGPW^TEX2.G:W;^7=0@FSOHA
MB>T;U![CU4\&OQ[Q2\+Z?$=+ZY@K1Q4%9-Z*:7V9=FOLOIL]-O)S++5B%SP^
M+\SYM_8&_;[M[FPL_!/CB]$-Q"!%IVJ7$F%E7HL4C'HPZ!CUZ'GK[%^U7^P[
MX;_:9M/[0A=-'\2H@$6H1)N6<=EE4?>'OU'N.*^"_P!HO]C[Q?\ LX:M)_:5
MHU]HY;$.J6J%H'';=W1O8_@377_LX?\ !1;QA\#[>'3-2_XJ;08OE2"Y?$]N
MOHDG)Q[-D>F*_+,DX^AA\.^%./L.W".BE)-RBEMS6U=OLSC=^NYYM''*,?JN
M.CIW_K\T8?C;]D/XK?L\>)%O(=+U9H[=_DU/1B\B[<]24^91_O 5]>67[!7P
M<\::19:A-#Y%U21
ME?(OX",,1T#KE3^8KX-UWX%_$.37;R2V\*^*V@N)WDB:*QF*.K,2""!C!!!H
MQ-#AKAU>URFBLSHUOL-J7L7'TC)KGO;5)^[N^A*.'H:TE[1/IV_#K^A]\Z+\
M)O@%^S.!?2?\(K9W4/*SZA>+\/\ AVWELO ^
MFR:U=XVK>7(,-K'[A?O-]/E%?*&A?LMK^8UBL7-/K7V7\#
M?V /A[\$Y(KQ=/;7=7CY%[J/[S8?58_N+]<$^]>N>(_%ND^"],:ZU74;#2[2
M$9,ES,L**/J2*]3AOP/G.L\TXNK\[W<5)N_^.;U]4O\ P(UP^3-OVF*E?R_S
M9A_!OX'>&_@/X4CTGP[I\5I"H'FS$9FN6_O.W5C^@[8KKB<"OFOXO_\ !4'P
M!\/UEM]$^U>*K]/1I/OM],@>U?=9WXM<+G+>U?GA\>/
MVA?$O[1/BS^U/$-X9!'E;:UC^6"T0G.U%_F3R:XAW:1BS$LS'))[TE?S#QOX
MG9OQ++V5=^SH7TIQV\G)[R?KHNB1\[C,QJXC26B[?UN>Z?\ !.'_ ).X\-_[
MEQ_Z):OU(K\M_P#@G#_R=QX;_P!RX_\ 1+5^I%?T-]'K_DG*O_7Z7_I,#WW_E##^S]_P!BXW_I5/7\9M?V9?\ !O;_ ,H8?V?O^Q<;
M_P!*IZ /LJBBB@#^+?\ X+L_\I=_CY_V-4_\EKY/M?\ CYC_ -X?SKZP_P""
M[/\ REW^/G_8U3_R6OD^U_X^8_\ >'\Z /[R?V??^2">!_\ L 6'_I/'6!^V
MC^SK8_M;?LG_ !"^&VH*AM_&6A76FJSKN$4KQGRWQ_LR!6_"M_\ 9]_Y()X'
M_P"P!8?^D\==?0!_ GXL\+WW@?Q3J6BZI;R6FI:1=2V5W!(,-#+&Y1U(]0P(
M_"OH#_@DO^V^_P#P3O\ V\_!/Q2999-/T8W-MJ$*?\M[>>WDA(([X9U;'J@K
MVS_@Y@_9,_X9/_X*V>/XK6U^SZ+X\6+Q;IQ"X5UNMWG8^EPDPKX#H W/B;X\
MOOBG\2/$'B;4YI+C4?$6HW&I74KG+22S2-(Q)]26-?7?_!O7^R5_PV#_ ,%7
M_A?HMS:_:]%\,WO_  D^J*4W((;/$JANV#+Y2\^N*^**_H4_X,GOV3/[,\)?
M%CXUWUK^]U.6'PKI,K+TCCQ/<[3[L8!_P"@#]Z**** /XU?^#A__ )3,?'?_
M +#B?^DT-?%M?:7_  G:G9G2+V3[-/&F&3Z* /ZQOC=_P '
M:7[(?PM\/S7&A>(/$OCR_1"8K/2='EB\UL< R3A%7TR:_!+_ (+*?\%N/B!_
MP5X^)%FVIV8\)_#WP]*TFB>&8+@S+$Y&TW$[X'F3$9&< *"0!R2?B:B@ K]T
M/^#*G]D2[U[XR_$SXV7UFRZ;X?L$\,Z9.Z?++*;ZW=--TV/JWSXQ))CI&N221
MG YK^O#]@[]B3P9_P3U_9B\.?"[P+:M%I.AQ9FN9/]=J-RW,MQ*>[NW/H!@#
M@"@#X)_X/$?^42D?_8XZ;_*6OY6Z_JD_X/$?^42D?_8XZ;_*6OY6Z /VT_X,
MC?\ D[WXT?\ 8HVO_I8*_H2_:1^.>D?LS? +QA\0->ECATGP?I-QJMP7;:&$
M498)GU8@*/;R1[A6'K0!_-S^T)\:=7_:-^.OB_P >Z],]
MQK'C#5[G5KIV.@#\"/[
M%O/^?2Z_[]-_A1_8MY_SZ77_ 'Z;_"O[PO\ AGGP#_T)'A'_ ,%%O_\ $4?\
M,\^ ?^A(\(_^"BW_ /B* /X.YM+NK>,O);W$:KU9HR *KU_;E^W=_P $_P#P
M+^U!^QQ\2/ -OX1\-6=YXFT&YMK.>WTV&*6&Y"[X65E4$$2*AR*_B9\1Z!=>
M%/$-_I=]$T%[IMQ):W$;##1R(Q5E/N""* /W+_X,M/VWO^$;^)WQ$^ NL7FV
MU\16Z^)= 21^ES#B.YB4>K1F-\#_ )Y-ZU_1+7\-?_!/#]JW4/V(OVU_AO\
M%#3Y)%7PKKEO<7L:''VFS+A;F+_@<+.OL2#7]:/_  4Q_;P\1_"'X!?#F3X1
MW.EMXC^,5^;?2-8O(Q/;:;9)I\]_-=!#\LD@BA"HAX+2 G(!% 'V'17X\_\
M!,__ (*X_%[Q[\:_ S^)O$6K>/\ X:^//$-IX.GN=5L;**?3-6N["2]A^SSV
MMK;*X01%)HGC;9YB%7((%?L-0 4444 %%%% !1110!#?Z?;ZK9R6]U##<6\R
M[9(I4#HX]"#P:^>?C!_P3)^'OQ(FENM*CNO"U_)R39-NMV/J8FX'_ 2*^C**
M\7.N&\LS>E[',J$:BZ76J]'NODT8UL/3JJU17/SU\7?\$E/&6ASM-H^O:#J=
MO&=^V8R6\N!STVLOZBO=M _X*5_"_P .Z+:Z?=7FL1W6GQ+;3*+!F = %."#
MR,BOH[4!FPF_ZYM_*OQV\3_"SQ/)XEU%E\-Z\RM=2D$:?+@C>?\ 9K\%XPHO
MP\G3K<*TO]XNIJ7--+DMRVU37Q.]V[GAXN/U!IX9?%O?78^\]:_X*P_#/3D;
M[+9^)]0;L([.- ?Q>05Y_P"+O^"P:[670?!K9_A>^N__ &5!_6OC[_A5/BC_
M *%O7_\ P7R__$T?\*I\4?\ 0MZ__P""^7_XFOSC&^,/&V(7+!^S_P --?G)
M29P3S;&2VT]$>P>/_P#@I9\4O&RR1VVJ6F@VTG&RPME5L?[[;F_(BO%/%7CC
M6?'-\UUK&J:AJEPQSON9VD(^F3Q^%6_^%4^*/^A;U_\ \%\O_P 31_PJGQ1_
MT+>O_P#@OE_^)K\\S;-<_P S=\PJ5:GE+F:^2V7R1P5:E>I_$;?WF!16_P#\
M*I\4?]"WK_\ X+Y?_B:/^%4^*/\ H6]?_P#!?+_\37B_V?BO^?T3]JOP]
MT?G+_Q"C_L1?\ 1,=;_P#"NU7_ ./U]Q?LV?LZ^$_V
M2O@9X;^'/@73YM+\)>$[7['IEK+6)/-=Q10 4444 ?
M"_[0?_!N%^R3^U#\:/$7Q \9_#_5M2\4>*KQK[4KF/Q-J-NLTK8R1'',$7IT
M4 5QR?\ !J5^Q&C!A\,M;RIR/^*NU7_X_7Z,T4 4O#?A^U\)>'=/TJQC:*QT
MRVCM+="Q8I'&H51D\G  Y/-7:** /F']O3_@CQ\ ?^"EOBO0=<^+_@^Z\0:I
MX;M7LK&XMM7N]/:.%WWE&\B1-PW"V>ZENI#)*Y=V:65F=B2>Y.  .@%>GT4 %%%% 'P_P#M+?\
M!NM^R?\ M<_''Q#\1O'?@'5M4\6>*+@76HW47B74+9)I JH"(XYE1?E4< "N
M%_XA1_V(O^B8ZW_X5VJ__'Z_1JB@#F_@Y\)=#^ OPI\.^"O#-K)8^'?"NGPZ
M7IMN\SS-#;Q($12[DLQ"@#+$DU\J_M>_\$ OV7?VZ?CYK'Q-^)7@?5-:\8Z]
M';QWMW#XBO[-)%@@2"/$<4JHN(XT' &<9/)K[.HH _.7_B%'_8B_Z)CK?_A7
M:K_\?H_XA1_V(O\ HF.M_P#A7:K_ /'Z_1JB@#\YX/\ @U+_ &(8IE9OA=K$
MJJE_"7_ (-[OV.?@M?PW6C? WPQ/<0D%'U6>YU0@_\
M;S+(#^-?9M% &;X2\'Z3X"T"WTG0]+T_1]+M%V06EE;I;P0CT5%  _ 5I444
M >0?ML_L*_#7_@H9\&QX!^*NBW.O>%UO8M1%M!J$]DWG1[MC>9"ZMQN/&<&O
MD3_B%'_8B_Z)CK?_ (5VJ_\ Q^OT:HH ^7?V"_\ @CC\ ?\ @FEXTUSQ!\'_
M  GJ'AW5/$=DFGW\MQK5Y?B6%7\P*%GD<+\W.0 :I?MT?\$4?V>?^"D'Q2T_
MQE\7?"NL>(]+Q!?644%NKO(%$<,JIDM(Q+8R>,G@5]7T4 ?G+_Q
M"C_L1?\ 1,=;_P#"NU7_ ./U]G_LC_LB> ?V&O@7I7PW^&>BG0?">CO+);6K
M7,ES)OE,#H!7I=% !1110 5\"_%G_ (-EOV.?C9\4/$7C
M'7_AKJ4VN>*M2N-6U&2W\3:C;QRW$\C22,L:3!$!=B=J@ 9X%??5% 'YR_\
M$*/^Q%_T3'6__"NU7_X_7T%\=_\ @EIX!^+O['_A#X0Z5>Z[X5L?AN\-QX/U
M6"[:\OM#FABDA0[IRQF0Q2R1LDA(9'(/8CZ8HH ^'?V4/^"--O\ !OX_:'\0
MO&WC"Q\47GA%8VT+1]%T-=%TFWNH[46:7\T2R.9KI;<>6&)"@@_*EHH 38/0?E1L'H/
MRI:* $V#T'Y4;!Z#\J6B@!-@]!^5&P>@_*EHH  H':BBB@ HHHH **** "BB
MB@ HHHH **** "BBB@ HHHH **** "BBB@ HHHH **** "BBB@ HHHH ****
? "BBB@ HHHH **** "BBB@ HHHH **** "BBB@#_V0$!
end
XML
9
R1.htm
IDEA: XBRL DOCUMENT
v3.26.1
Document and Entity Information
Aug. 26, 2026
Document and Entity Information [Abstract]
Document Type
8-K
Document Period End Date
Aug. 26,  2026
Entity Registrant Name
NVIDIA CORP
Entity Central Index Key
0001045810
Amendment Flag
false
Entity Incorporation, State or Country Code
DE
Entity File Number
0-23985
Entity Tax Identification Number
94-3177549
Entity Address, Address Line One
2788 San Tomas Expressway
Entity Address, City or Town
Santa Clara
Entity Address, State or Province
CA
Entity Address, Postal Zip Code
95051
City Area Code
408
Local Phone Number
486-2000
Written Communications
false
Soliciting Material
false
Pre-commencement Tender Offer
false
Pre-commencement Issuer Tender Offer
false
Title of 12(b) Security
Common Stock, $0.001 par value per share
Trading Symbol
NVDA
Security Exchange Name
NASDAQ
Entity Emerging Growth Company
false
X
- Definition
Boolean flag that is true when the XBRL content amends previously-filed or accepted submission.
+ References
No definition available.
+ Details
Name:
dei_AmendmentFlag
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Area code of city
+ References
No definition available.
+ Details
Name:
dei_CityAreaCode
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
For the EDGAR submission types of Form 8-K: the date of the report, the date of the earliest event reported; for the EDGAR submission types of Form N-1A: the filing date; for all other submission types: the end of the reporting or transition period. The format of the date is YYYY-MM-DD.
+ References
No definition available.
+ Details
Name:
dei_DocumentPeriodEndDate
Namespace Prefix:
dei_
Data Type:
xbrli:dateItemType
Balance Type:
na
Period Type:
duration
X
- Definition
The type of document being provided (such as 10-K, 10-Q, 485BPOS, etc). The document type is limited to the same value as the supporting SEC submission type, or the word 'Other'.
+ References
No definition available.
+ Details
Name:
dei_DocumentType
Namespace Prefix:
dei_
Data Type:
dei:submissionTypeItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Address Line 1 such as Attn, Building Name, Street Name
+ References
No definition available.
+ Details
Name:
dei_EntityAddressAddressLine1
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Name of the City or Town
+ References
No definition available.
+ Details
Name:
dei_EntityAddressCityOrTown
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Code for the postal or zip code
+ References
No definition available.
+ Details
Name:
dei_EntityAddressPostalZipCode
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Name of the state or province.
+ References
No definition available.
+ Details
Name:
dei_EntityAddressStateOrProvince
Namespace Prefix:
dei_
Data Type:
dei:stateOrProvinceItemType
Balance Type:
na
Period Type:
duration
X
- Definition
A unique 10-digit SEC-issued value to identify entities that have filed disclosures with the SEC. It is commonly abbreviated as CIK.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b-2
+ Details
Name:
dei_EntityCentralIndexKey
Namespace Prefix:
dei_
Data Type:
dei:centralIndexKeyItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Indicate if registrant meets the emerging growth company criteria.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b-2
+ Details
Name:
dei_EntityEmergingGrowthCompany
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Commission file number. The field allows up to 17 characters. The prefix may contain 1-3 digits, the sequence number may contain 1-8 digits, the optional suffix may contain 1-4 characters, and the fields are separated with a hyphen.
+ References
No definition available.
+ Details
Name:
dei_EntityFileNumber
Namespace Prefix:
dei_
Data Type:
dei:fileNumberItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Two-character EDGAR code representing the state or country of incorporation.
+ References
No definition available.
+ Details
Name:
dei_EntityIncorporationStateCountryCode
Namespace Prefix:
dei_
Data Type:
dei:edgarStateCountryItemType
Balance Type:
na
Period Type:
duration
X
- Definition
The exact name of the entity filing the report as specified in its charter, which is required by forms filed with the SEC.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b-2
+ Details
Name:
dei_EntityRegistrantName
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
The Tax Identification Number (TIN), also known as an Employer Identification Number (EIN), is a unique 9-digit value assigned by the IRS.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b-2
+ Details
Name:
dei_EntityTaxIdentificationNumber
Namespace Prefix:
dei_
Data Type:
dei:employerIdItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Local phone number for entity.
+ References
No definition available.
+ Details
Name:
dei_LocalPhoneNumber
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as pre-commencement communications pursuant to Rule 13e-4(c) under the Exchange Act.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 13e
-Subsection 4c
+ Details
Name:
dei_PreCommencementIssuerTenderOffer
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as pre-commencement communications pursuant to Rule 14d-2(b) under the Exchange Act.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 14d
-Subsection 2b
+ Details
Name:
dei_PreCommencementTenderOffer
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Title of a 12(b) registered security.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b
+ Details
Name:
dei_Security12bTitle
Namespace Prefix:
dei_
Data Type:
dei:securityTitleItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Name of the Exchange on which a security is registered.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection d1-1
+ Details
Name:
dei_SecurityExchangeName
Namespace Prefix:
dei_
Data Type:
dei:edgarExchangeCodeItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as soliciting material pursuant to Rule 14a-12 under the Exchange Act.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 14a
-Subsection 12
+ Details
Name:
dei_SolicitingMaterial
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Trading symbol of an instrument as listed on an exchange.
+ References
No definition available.
+ Details
Name:
dei_TradingSymbol
Namespace Prefix:
dei_
Data Type:
dei:tradingSymbolItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as written communications pursuant to Rule 425 under the Securities Act.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Securities Act
-Number 230
-Section 425
+ Details
Name:
dei_WrittenCommunications
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Document and Entity Information [Abstract]
+ References
No definition available.
+ Details
Name:
nvda_DocumentAndEntityInformationAbstract
Namespace Prefix:
nvda_
Data Type:
xbrli:stringItemType
Balance Type:
na
Period Type:
duration
XML
10
report.css
IDEA: XBRL DOCUMENT
/* Updated 2009-11-04 */
/* v2.2.0.24 */
/* DefRef Styles */
.report table.authRefData{
background-color: #def;
border: 2px solid #2F4497;
font-size: 1em;
position: absolute;
}
.report table.authRefData a {
display: block;
font-weight: bold;
}
.report table.authRefData p {
margin-top: 0px;
}
.report table.authRefData .hide {
background-color: #2F4497;
padding: 1px 3px 0px 0px;
text-align: right;
}
.report table.authRefData .hide a:hover {
background-color: #2F4497;
}
.report table.authRefData .body {
height: 150px;
overflow: auto;
width: 400px;
}
.report table.authRefData table{
font-size: 1em;
}
/* Report Styles */
.pl a, .pl a:visited {
color: black;
text-decoration: none;
}
/* table */
.report {
background-color: white;
border: 2px solid #acf;
clear: both;
color: black;
font: normal 8pt Helvetica, Arial, san-serif;
margin-bottom: 2em;
}
.report hr {
border: 1px solid #acf;
}
/* Top labels */
.report th {
background-color: #acf;
color: black;
font-weight: bold;
text-align: center;
}
.report th.void	{
background-color: transparent;
color: #000000;
font: bold 10pt Helvetica, Arial, san-serif;
text-align: left;
}
.report .pl {
text-align: left;
vertical-align: top;
white-space: normal;
width: 200px;
white-space: normal; /* word-wrap: break-word; */
}
.report td.pl a.a {
cursor: pointer;
display: block;
width: 200px;
overflow: hidden;
}
.report td.pl div.a {
width: 200px;
}
.report td.pl a:hover {
background-color: #ffc;
}
/* Header rows... */
.report tr.rh {
background-color: #acf;
color: black;
font-weight: bold;
}
/* Calendars... */
.report .rc {
background-color: #f0f0f0;
}
/* Even rows... */
.report .re, .report .reu {
background-color: #def;
}
.report .reu td {
border-bottom: 1px solid black;
}
/* Odd rows... */
.report .ro, .report .rou {
background-color: white;
}
.report .rou td {
border-bottom: 1px solid black;
}
.report .rou table td, .report .reu table td {
border-bottom: 0px solid black;
}
/* styles for footnote marker */
.report .fn {
white-space: nowrap;
}
/* styles for numeric types */
.report .num, .report .nump {
text-align: right;
white-space: nowrap;
}
.report .nump {
padding-left: 2em;
}
.report .nump {
padding: 0px 0.4em 0px 2em;
}
/* styles for text types */
.report .text {
text-align: left;
white-space: normal;
}
.report .text .big {
margin-bottom: 1em;
width: 17em;
}
.report .text .more {
display: none;
}
.report .text .note {
font-style: italic;
font-weight: bold;
}
.report .text .small {
width: 10em;
}
.report sup {
font-style: italic;
}
.report .outerFootnotes {
font-size: 1em;
}
XML
11
Show.js
IDEA: XBRL DOCUMENT
// Edgar(tm) Renderer was created by staff of the U.S. Securities and Exchange Commission.  Data and content created by government employees within the scope of their employment are not subject to domestic copyright protection. 17 U.S.C. 105.
var Show={};Show.LastAR=null,Show.showAR=function(a,r,w){if(Show.LastAR)Show.hideAR();var e=a;while(e&&e.nodeName!='TABLE')e=e.nextSibling;if(!e||e.nodeName!='TABLE'){var ref=((window)?w.document:document).getElementById(r);if(ref){e=ref.cloneNode(!0);
e.removeAttribute('id');a.parentNode.appendChild(e)}}
if(e)e.style.display='block';Show.LastAR=e};Show.hideAR=function(){Show.LastAR.style.display='none'};Show.toggleNext=function(a){var e=a;while(e.nodeName!='DIV')e=e.nextSibling;if(!e.style){}else if(!e.style.display){}else{var d,p_;if(e.style.display=='none'){d='block';p='-'}else{d='none';p='+'}
e.style.display=d;if(a.textContent){a.textContent=p+a.textContent.substring(1)}else{a.innerText=p+a.innerText.substring(1)}}}
XML
13
FilingSummary.xml
IDEA: XBRL DOCUMENT
3.26.1
html
1
22
1
false
0
0
false
0
false
false
R1.htm
0000001 - Document - Document and Entity Information
Sheet
http://www.nvidia.com/role/DocumentandEntityInformation
Document and Entity Information
Cover
1
false
false
All Reports
Book
All Reports
nvda-20260826.htm
nvda-20260826.xsd
nvda-20260826_lab.xml
nvda-20260826_pre.xml
http://xbrl.sec.gov/dei/2026
true
false
JSON
15
MetaLinks.json
IDEA: XBRL DOCUMENT
{
"version": "2.2",
"instance": {
"nvda-20260826.htm": {
"nsprefix": "nvda",
"nsuri": "http://www.nvidia.com/20260826",
"dts": {
"inline": {
"local": [
"nvda-20260826.htm"
]
},
"schema": {
"local": [
"nvda-20260826.xsd"
],
"remote": [
"http://www.xbrl.org/2003/xbrl-instance-2003-12-31.xsd",
"http://www.xbrl.org/2003/xbrl-linkbase-2003-12-31.xsd",
"http://www.xbrl.org/2003/xl-2003-12-31.xsd",
"http://www.xbrl.org/2003/xlink-2003-12-31.xsd",
"http://www.xbrl.org/2005/xbrldt-2005.xsd",
"http://www.xbrl.org/lrr/role/negated-2009-12-16.xsd",
"http://www.xbrl.org/lrr/role/net-2009-12-16.xsd",
"https://www.xbrl.org/dtr/type/2024-01-31/types.xsd",
"https://xbrl.sec.gov/dei/2026/dei-2026.xsd"
]
},
"labelLink": {
"local": [
"nvda-20260826_lab.xml"
]
},
"presentationLink": {
"local": [
"nvda-20260826_pre.xml"
]
}
},
"keyStandard": 22,
"keyCustom": 0,
"axisStandard": 0,
"axisCustom": 0,
"memberStandard": 0,
"memberCustom": 0,
"hidden": {
"total": 2,
"http://xbrl.sec.gov/dei/2026": 2
},
"contextCount": 1,
"entityCount": 1,
"segmentCount": 0,
"elementCount": 23,
"unitCount": 0,
"baseTaxonomies": {
"http://xbrl.sec.gov/dei/2026": 22
},
"report": {
"R1": {
"role": "http://www.nvidia.com/role/DocumentandEntityInformation",
"longName": "0000001 - Document - Document and Entity Information",
"shortName": "Document and Entity Information",
"isDefault": "true",
"groupType": "document",
"subGroupType": "",
"menuCat": "Cover",
"order": "1",
"firstAnchor": {
"contextRef": "c-1",
"name": "dei:DocumentType",
"unitRef": null,
"xsiNil": "false",
"lang": "en-US",
"decimals": null,
"ancestors": [
"span",
"div",
"body",
"html"
],
"reportCount": 1,
"baseRef": "nvda-20260826.htm",
"first": true,
"unique": true
},
"uniqueAnchor": {
"contextRef": "c-1",
"name": "dei:DocumentType",
"unitRef": null,
"xsiNil": "false",
"lang": "en-US",
"decimals": null,
"ancestors": [
"span",
"div",
"body",
"html"
],
"reportCount": 1,
"baseRef": "nvda-20260826.htm",
"first": true,
"unique": true
}
}
},
"tag": {
"dei_AmendmentFlag": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "AmendmentFlag",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Amendment Flag",
"label": "Amendment Flag",
"documentation": "Boolean flag that is true when the XBRL content amends previously-filed or accepted submission."
}
}
},
"auth_ref": []
},
"dei_CityAreaCode": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "CityAreaCode",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "City Area Code",
"label": "City Area Code",
"documentation": "Area code of city"
}
}
},
"auth_ref": []
},
"nvda_DocumentAndEntityInformationAbstract": {
"xbrltype": "stringItemType",
"nsuri": "http://www.nvidia.com/20260826",
"localname": "DocumentAndEntityInformationAbstract",
"lang": {
"en-us": {
"role": {
"terseLabel": "Document and Entity Information [Abstract]",
"label": "Document and Entity Information [Abstract]",
"documentation": "Document and Entity Information [Abstract]"
}
}
},
"auth_ref": []
},
"dei_DocumentPeriodEndDate": {
"xbrltype": "dateItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "DocumentPeriodEndDate",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Document Period End Date",
"label": "Document Period End Date",
"documentation": "For the EDGAR submission types of Form 8-K: the date of the report, the date of the earliest event reported; for the EDGAR submission types of Form N-1A: the filing date; for all other submission types: the end of the reporting or transition period. The format of the date is YYYY-MM-DD."
}
}
},
"auth_ref": []
},
"dei_DocumentType": {
"xbrltype": "submissionTypeItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "DocumentType",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Document Type",
"label": "Document Type",
"documentation": "The type of document being provided (such as 10-K, 10-Q, 485BPOS, etc). The document type is limited to the same value as the supporting SEC submission type, or the word 'Other'."
}
}
},
"auth_ref": []
},
"dei_EntityAddressAddressLine1": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "EntityAddressAddressLine1",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Address, Address Line One",
"label": "Entity Address, Address Line One",
"documentation": "Address Line 1 such as Attn, Building Name, Street Name"
}
}
},
"auth_ref": []
},
"dei_EntityAddressCityOrTown": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "EntityAddressCityOrTown",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Address, City or Town",
"label": "Entity Address, City or Town",
"documentation": "Name of the City or Town"
}
}
},
"auth_ref": []
},
"dei_EntityAddressPostalZipCode": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "EntityAddressPostalZipCode",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Address, Postal Zip Code",
"label": "Entity Address, Postal Zip Code",
"documentation": "Code for the postal or zip code"
}
}
},
"auth_ref": []
},
"dei_EntityAddressStateOrProvince": {
"xbrltype": "stateOrProvinceItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "EntityAddressStateOrProvince",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Address, State or Province",
"label": "Entity Address, State or Province",
"documentation": "Name of the state or province."
}
}
},
"auth_ref": []
},
"dei_EntityCentralIndexKey": {
"xbrltype": "centralIndexKeyItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "EntityCentralIndexKey",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Central Index Key",
"label": "Entity Central Index Key",
"documentation": "A unique 10-digit SEC-issued value to identify entities that have filed disclosures with the SEC. It is commonly abbreviated as CIK."
}
}
},
"auth_ref": [
"r1"
]
},
"dei_EntityEmergingGrowthCompany": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "EntityEmergingGrowthCompany",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Emerging Growth Company",
"label": "Entity Emerging Growth Company",
"documentation": "Indicate if registrant meets the emerging growth company criteria."
}
}
},
"auth_ref": [
"r1"
]
},
"dei_EntityFileNumber": {
"xbrltype": "fileNumberItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "EntityFileNumber",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity File Number",
"label": "Entity File Number",
"documentation": "Commission file number. The field allows up to 17 characters. The prefix may contain 1-3 digits, the sequence number may contain 1-8 digits, the optional suffix may contain 1-4 characters, and the fields are separated with a hyphen."
}
}
},
"auth_ref": []
},
"dei_EntityIncorporationStateCountryCode": {
"xbrltype": "edgarStateCountryItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "EntityIncorporationStateCountryCode",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Incorporation, State or Country Code",
"label": "Entity Incorporation, State or Country Code",
"documentation": "Two-character EDGAR code representing the state or country of incorporation."
}
}
},
"auth_ref": []
},
"dei_EntityRegistrantName": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "EntityRegistrantName",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Registrant Name",
"label": "Entity Registrant Name",
"documentation": "The exact name of the entity filing the report as specified in its charter, which is required by forms filed with the SEC."
}
}
},
"auth_ref": [
"r1"
]
},
"dei_EntityTaxIdentificationNumber": {
"xbrltype": "employerIdItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "EntityTaxIdentificationNumber",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Tax Identification Number",
"label": "Entity Tax Identification Number",
"documentation": "The Tax Identification Number (TIN), also known as an Employer Identification Number (EIN), is a unique 9-digit value assigned by the IRS."
}
}
},
"auth_ref": [
"r1"
]
},
"dei_LocalPhoneNumber": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "LocalPhoneNumber",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Local Phone Number",
"label": "Local Phone Number",
"documentation": "Local phone number for entity."
}
}
},
"auth_ref": []
},
"dei_PreCommencementIssuerTenderOffer": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "PreCommencementIssuerTenderOffer",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Pre-commencement Issuer Tender Offer",
"label": "Pre-commencement Issuer Tender Offer",
"documentation": "Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as pre-commencement communications pursuant to Rule 13e-4(c) under the Exchange Act."
}
}
},
"auth_ref": [
"r3"
]
},
"dei_PreCommencementTenderOffer": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "PreCommencementTenderOffer",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Pre-commencement Tender Offer",
"label": "Pre-commencement Tender Offer",
"documentation": "Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as pre-commencement communications pursuant to Rule 14d-2(b) under the Exchange Act."
}
}
},
"auth_ref": [
"r5"
]
},
"dei_Security12bTitle": {
"xbrltype": "securityTitleItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "Security12bTitle",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Title of 12(b) Security",
"label": "Title of 12(b) Security",
"documentation": "Title of a 12(b) registered security."
}
}
},
"auth_ref": [
"r0"
]
},
"dei_SecurityExchangeName": {
"xbrltype": "edgarExchangeCodeItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "SecurityExchangeName",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Security Exchange Name",
"label": "Security Exchange Name",
"documentation": "Name of the Exchange on which a security is registered."
}
}
},
"auth_ref": [
"r2"
]
},
"dei_SolicitingMaterial": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "SolicitingMaterial",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Soliciting Material",
"label": "Soliciting Material",
"documentation": "Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as soliciting material pursuant to Rule 14a-12 under the Exchange Act."
}
}
},
"auth_ref": [
"r4"
]
},
"dei_TradingSymbol": {
"xbrltype": "tradingSymbolItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "TradingSymbol",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Trading Symbol",
"label": "Trading Symbol",
"documentation": "Trading symbol of an instrument as listed on an exchange."
}
}
},
"auth_ref": []
},
"dei_WrittenCommunications": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2026",
"localname": "WrittenCommunications",
"presentation": [
"http://www.nvidia.com/role/DocumentandEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Written Communications",
"label": "Written Communications",
"documentation": "Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as written communications pursuant to Rule 425 under the Securities Act."
}
}
},
"auth_ref": [
"r6"
]
}
}
}
},
"std_ref": {
"r0": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "12",
"Subsection": "b"
},
"r1": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "12",
"Subsection": "b-2"
},
"r2": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "12",
"Subsection": "d1-1"
},
"r3": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "13e",
"Subsection": "4c"
},
"r4": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "14a",
"Subsection": "12"
},
"r5": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "14d",
"Subsection": "2b"
},
"r6": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Securities Act",
"Number": "230",
"Section": "425"
}
}
}
ZIP
16
0001045810-26-000073-xbrl.zip
IDEA: XBRL DOCUMENT
begin 644 0001045810-26-000073-xbrl.zip
M4$L#!!0    ( *FB&EV(:?:E6P\  %AG   1    ;G9D82TR,#(V,#@R-BYH
M=&WM/6MSXCBVW^=7Z#)[IY.JV-CF32=LL732P_9TD@OTSM1^V1*V'#1M;%H2
M">ROO^=(-N  :9+*BTQWU?1@6SHZ;YV'[#[^^VPN[;PC+/:3
M@,=7)^_:_4ZW^^[OK9^._\>R_OA'[S?R(?&G8Q8KTA&,*A:0&ZY&1(T8^3T1
M7_DU)9<156$BQI9EIG62R5SPJY$BGN-5LV'94]%TW :K.(Q:#<]E5FW(2E:C
M&E2LL%[W2K5*.!P&P=%5LUIQ&I4@K%IAK>%99:\66,-:G5H5C_EA$-:K7KUZ
M%#2I2VN!6PHK+*R6JS ;'@>>4RM7JG18\LIZW9$"FH'N6)X41DI-FL7BSHY;L9RZ57*7<'(@9D,1Z15A9&D%T,JRF\??M:;G6(YGN5X&9";Y)B(]QW&+
M?WS^K>^/V)A:/):*QC[+9@5L.4LOFY$+#W"1Z@(\/.3;J'*0JCS@^#J@N>'Q
M-0\XM?UDK.$Z]25L(/+K':#Q\9#*!>C9VOB<0/&I'MJ,*.AV@<76EWZA=3QB
M-&@=CYFB!*=:[-N47Y\4.DFL0,^MP7P"*_CFZJ2@V$P5M6X46S_]]-.QXBIB
M+:3*RM _+IJ;QT4#>I@$\]9QP*^)5/.(G10"+B<1G3?C)&:  )\U<2 3YB8=P$[0J!L';/:)S0N$
M!R>%T/+<0LL!43OE2MUUCHLYJ/=8I TV'Z#=GT7T:@'<*[1"&DFV!K>8)T2P
MD GP*DQNX#_*I2FU&L+*1,NIJ8#K)P7)QY,(Y:OOC00BEF.U/9,!"$*OMUPD
M75,F4Z&OM(XV4^HT[DA==I]I_F57/,#KD#-!-$YLH]%WNI_R?+T]N97=RD.?
M 'N2(+L"RQ#J WC1%M*#K@*5Y_:S!9K!EJ'9D^PZ6Z28HSMCTH(KQ16]*X)V
M&A5%[O#O.='_(/>6T3]KG'\CI'YU?V^C_WN[_VCW_
M.+@X/R(?.A!J5,J-K0CGU:^:5[\G(,'9B83_Y/[LB'SCR9&O[H3\V47O,]E]
M/\G"2+.[FNT$G$K=^G1[+R&/P(A-/N39]'GG1&[QJ5"^_
M]/I?VH#KX(* UQB :R!NB5STB%LY" [)Q=FK1G_PZRE9<78+1]?N# !UXC9*
MY:=7N>7D%<
M\LO/;M5Y[U6/=#*['O>^$G'7'YF))L?HL2LN,>%4Y_ DXTVIT$HQZEST+F^S
MY*+7'JS$#HH.(Y;1.$P$1)\6D!K1B63-[,?[+$$R>:ZE)[W/\Q"CRVLF%/=I
ME/)1L]0\3@//1L.N5TI(J8(@5P79PFE8:@,3BNOW&W6[X6Q^Y-BNOE_4\ Q,
MP!II.RF4"MG@"0VP?M+T[*HW4<3%_^R*^;4N^34ZDLGSVKX.SP].9Q \:YFC
MR8N%K F51$Z8CWE-0'A,N)+$'T%ZPL3A0N-5D'*EJ*5U7QM8QOS[H"&0>):]
MRIT:LBNHD/%AN+'BDG\=?E\QB,&@X>PLZ4\JQ1:
MCN65&O7*#Y9M9-F SKII!137NO/EM([B3C,9?R#5/8[4$"-IY$R9R)MZ[!$%3QU;WG
M\(T*%1T_,9[KK9*8]]+D/+$?+1!^L;+(?3>K=A ()F7ZO]\ GIMM5+5"RZO5
MZX@4&21CR!].9Q,<=4/GM_>MHWL4#7,+=^#GA1@D-XN8K%YHP8J*DDY$!7VT
MA?3&K'R86M<)A!G1O_F$Q.$IO50!S;\BE-QGZ(D
M^IQEI8.42LPK)P*8R"4@(.0 >$&3"X3V*]^D=\ 4Z
MZ7L-)"]+);_\7/?$+^[*;P&GWJ>
M*-*>3"+8*& K>"6H;K'1,TA\(:XV]1^A\V"XI,9R05=#K/G$5RP@$MT@B:C,
M*L';;?51JN.EN]K#S\FCSHCY7_59)SJ9B 1<&:8DPV1&ABQ*;I!'^! Y2>K6
M)Q+R"(V;2[!TQ>( >*<28-]X&BD:LV0JHSF1$$/(<*YGIA.2(1!J0HO$@%RI
MQDT!#L@EGF?/PB2"Q7$>EBDXI@NR^;#6Y\NQ=GU"6 (EXQ3JN@#<,H4]844&IS/CFO(2*#NV&?F&A7 I&!H"GGK2
MW71T,N(B#''SW$T8E>W" ."6OP+]NY;AE@/+.Q@>[B8:,_:O(YRNE%,F'B"B
MZF.*J,2L\H&_FXC2L0\4T8M%72LNV>R;3,#.N\H*&*%W5U=K:[J/ OG-?6I3
MEAIVK=QXE,Z16[.KY;L[1_? JN1NGO(L32C#V!YYC^C0^."YZPVU82PVLQJD4;!' ?_Z*O&_'I&_.;;CN&1"!;FFT921"1Z]
M'KU$8W4/^)H:GK&[!5/K> 3GPUHU\@?#EHJ813GFY-+MP OM.M_@=QO@Y2 J
M.*5M@)6+7 W0\@(H!K#+
M>2M@[9UJAM]_">&UB=,<35S_FYQF,OMH9-9)97;?7D4&QX!)H>R8Q'C.]B3F
M'FPU+HG'V'_3IQSW2#[=\ X#PF; 1FOD:P7 $=B:=D-@:W&B\YFI9'H4D)F6
M&?&M0*YS'/,V$$I)KQ7-<7']TB;J0,QNT,P$N^82YH$%T]C'J@OU?3P6A8/Q
M!;Z BD": F.P+9DJ'=!%,K5JFC992'Z+?&Z]-31)#.Y-P2**':*M[Q&E69:S
MG$*',HFF:ON41WGUR/P]$LMM](I90\'H5XN&X&2:-+JAJAGFT-
MCQ?(Y[N*C8EG.Q[I,3F-E.XC7H!>IT4.T$YRME#<3@*&A _L?:LL7<3&86\Z
M:7Y$LC/6RP,D1VBY:&R=A0_!$E- *-'==K#JB%%P#32.P99]W8M0>-MP,4RG
M?YOJL[S$N(Y_3J-Y?FV;8""4!XG1@%*0$N%RN!./^) KTFC8KI:'[GEDAUU@
M# 04# (#\&V+US3W3C[MC& D!AQ?GF[/T+U*]"JU&0> ,4LGR^/%F]MZMBGE
M*2KF.+>31$S!AO#9)I],$^YTT3+_%P>0EW!7OW*J)W=&G(4KAG"AN^HB\\@+
M)8&M!)PY*L-]%6&I<&<7I+/ U>A'_A[L,%%$AJ VB52F[X6OT_"83MD[]5DW(BVU/-L@[27A5,1<
M:LN" 9 * R=QHP=N!@SBAX 4@#,LT*$7;L7 8Z:=XF(KKN\8+1^A$M.Q%KB6
MKIP._\0,!^2%TR-.AR $/5]#I&JQ"(Q.?TKB&JMW/0@!#KS#N^/^U46-[JS:
M =C(!FGGV;#=RGBLPYI4'M'TG869>47KD3.)(P?/)$[V5:%1"IVHZ)
M5N_3JZC;]?+=38'=[Y?JY4?I5-3K=JEV]YLWCU3%C5BXQMH7JV>G6G^/VJ"#
M]*1L>BM<^,"D+_AD[>V!)Y3XF >P+;Q L12#\MB2./
M=  2D.,BW3]*,-G=2\2EVD^&>WN)=74OL<[29OT1J @3MQ21MJG(0":RC*/3
MXI:)[C"SVTN2($#\VIA^ZD;W*SV2WOUXWAY\Z9T^_=N=N]2,]Z5E=KERS,2<@ODVY2)M-NS:
MX=IP?":81G/BTRD>>=%.RKS'B,L,&9% -#Q(S)>NAFQ$HS!K"NE],1V '9]I
M#',T.#I5HT0 <<%3=";?;$/A@1_@JMC51NEQ7EAP[&KM?CV(K=_RYAM+Z\=BGJN>;^B]*T-]LE +/V'9))N_2+D6;;]9A;AO
M]OZ/>9,497'M7,US*LQ;-M#-NOJ#VX_,;0VMR14LX^_ _VUGQHS?H'%@?FPY
M/?8B^=:>9DE%\P]]Z'\=I/7_4$L#!!0    ( *FB&ET=S=,IU (  $T(   1
M    ;G9D82TR,#(V,#@R-BYX^O8'X>\27+Q5&=JFNWJ5)V
M4==J?:NP^9R@.N !3M)_/\!&2=HF4_:T/&$XY_!=#I#SB\VR0BN0B@F>!7$O
M"A#P0E#&YUEP?_<9CX.+Z=G9^3N,'S[>SM"U*)HE<(VN)! -%*V97B"] /1+
MR">V(NA'170IY!+CJ:-=B?I9LOE"HR1*AA[F5^4DBE,81$!PFL2 1SGT<3JD
M UR.QTE_-"CSG-+W\\EP$*4#6@YQ.4H3_"$949R/Q@0/$BA*6HZ'R7CH1#=J
MHHH%+ DRJ7$UV:@L6&A=3\)PO5[WUOV>D/,PB:(X?/@Z^^F@08>M&'_:0V]R
M67E\/[3+.5'@X7Q%R1Z(96B3C<;)T&.M$CNBS;C2A!=&FV@M6=YH
M^&RJ> TE:2J=!0W_W9"*E0RH:5$%M@E[@)UE3>0<]#>R!%63 OX:XO0,(5LW
MMJR%U(B_23P4;EOLF2B(=AXZ2+%?V/.PG<)Q@OMQ;Z-H$/Y##-MVG!:#YYT>
M@Q-34/3F8A528*Z$;V^O#L'M -O!_IZ$"G:"3-E Y_XZ&^A
M]-9Z9=O.Y'&:IJ%;-2YT9"(+*2HX#@YK*6J0FH':M;P36$@HL\ :'WO[/-82
M>B82#WFUP7X+[++9 90QL,MWMDW(2^CGVD@HTX<*VA+]S_E7)#\U?T.!ZL3$
M+?'.K"-&L\#?PX333UPS_7S#[:7K"AH@"[V_O3ET\%T(1Q7\SGYO"B7CS+DS
MU;L#,T:JB50SMZY^%+E1?ZC0+ZG4_=^*4W.G('.4(L2%4TU>F\;5@'
M:=VD;T%W1,/],]I^[YUC>XJ[R]JUS1KGT1?K\HW*7^9*2U)H\PQTHRS0LC'^
ML[?1MN_'N9Q5QF'6ABW7/3X3XVDFZ)VS&&UDYQ75&!K3C?WZ(D539T$+9QJ6
MYBUQ\';&R)O_!3=FWHI8?[J4V^MO>O8'4$L#!!0    ( *FB&EWTO!60=PD
M (-7   5    ;G9D82TR,#(V,#@R-E]L86(N>&ULS9Q=;]LX%H;O^RNXGIM=
M8!A+U'?09I#-M(M@,VW0I)C!#A8%29&),+(4T,K7OU]2MA/)DFR2BM6]:12'
M/N]YC_6(1S35][\\+7+PP,0R*XL/,_?(F0%6T#+-BIL/LV_7GV \^^7DW;OW
M?X/PCW]^O0"_EO1^P8H*G F&*Y:"QZRZ!=4M [^7XJ_L 8/+'%>\% L(3^JW
MG95WSR*[N:T 3,(T@#R.D1<%G) T_?GF
M. R<)$AY"'F4(.BC*(4DBC$,$*,\Y7&(XK .FF?%7\?J'X*7#$A[Q;+^]C9>OA39_RC5X]VDR29UW]]&;K,^@;*
ML.[\C]\NKN@M6V"8%0? JARBS-E7QH'Z^>WK^:!D,EIT:D?/N.W.BW*
M"N<3G!:O,HV4<_7"A3Q:RZA .RZFM<[ZTMU(E3U5K$C9ZFK9"@VR],-,'GU/
M6?;]8U%EU?,U?CI/Y>R7\6QU\?Y\OR!,?-^:PP*$(781@5A.4T%,G- )T/?J
MY>3^S@KX[6J31RVFJ30S\%H-,"O8LKP7=#7;274UTZ\2.EEI RD.VNI@)?]^
M_IKQF'KETU4AGZ8 )6U)Y&IR+\6VN9+JFWNE9BG=U4I+SM#CP70(W$L)Q_9&[J!+CS;
MP0\,3RT':CWC^:93A_W9;N<<)JF\J-;KG]<9 5SMUDB*($)ET=Q$(>A&WDT" W7
M%7I4IEE@6"O^O#D 2AM\*0SFKN$ZZ:X[C'1OM0!A;MQB.6*'L1'K$GU1)UZ@
MV&&LNU*Q:[ 9EL5#BE\FR],B7<4_+]17T/4:XBE95@+3JH.H&T#L!!$,&.>(
M^LCSG5@'46W%J5I,7*BVJSZ%&UF /S=Y_%W5%5&^K+WI.O+[PZ0>:Y")H[&MS031_X\B>Y;)<5CC_
M3W9W5J:=FVP4>C!V0Q4@;^F"5 %AE .H4] '<6[G],+YE/D>WLE;S985_$I2@?,JFUC33F 8Q#E\(D""E-F(LX2:T:
MVBVAB5O:6EU6"&ST+9O:[7(9MK4CBC"NL=7W;]_:#I@;W]QN!_XQ[>V O<$&
M=VC\2&#/Y.$7<5T^%ITNUT,08S>"B"#B$#]$&!ONF>UH3(RI$E9GJ9*V)+11
M'T,X[5R/XU++L#V274OC:6S$_#$@=DT-,M@SU!R_4SD!IVH2_I3CF\Y7OCR!
M,0LH)%& F8NQ3V)MZ%J1#XS:BQ908OIPM=WO1\K:DQE(FG:,T.E-W0J8=J3)
M,.DUT(2C?X#MC'1>T%+9ZVGN[/ROJC$<]_2:.@[D(3$A0A'"&'N\#31
MWANAH3?-3-5*H=%6K1.Q6B_=74;=2>S-BF,UH8VJB\7\IN5VQ%RW._[$\YZ6
MV>XTQ2-PH\Y"-'%_=>A0,#
MOM8$;5%]EONKLI_>T5[->#6T:83F3BM6,/9'G R_G8::P.T>:/\$R<BL_
M/=;WI4;,"<1QG,+(BQ"/74I=1YNP/H$# [:1!!M-PR\U>FNRGZ^Q3LWP,C1I
M]3Q)GY-1SY2T D[^7$F?G;YG2WK'F:-U+;#ZKSFNGA>D[&S@#5$ DS1UH1?C
M..0!(@G3WG38BGQ@F-9:8"6F#U';_7YZK#V98:-IQPB7WM2M.&E'F@R07@--
M,OH'V#\_M7[AN!(D7
M$>B[3I3R*$H9=75!: 8^, CUBK+2,ER+:'G?3X*M(S,2-,T8H="7N14*K4"3
MH="7?A.%WK^/WONQ8]<'CQV(.?-@$'G48SR-8Z;]0.ZPS($QZ6QR>).-'J.V
M>/R8S1T'W]5QH/T<_P\[.^[4IAF>7TM"FI5(&5-U]*WZZ*[>C["K=5ZN;Y1B\7Q 3,CEL.W
M(TZ\ #Y@J+OD/330%K./"R9NY"W6OT3Y6-U*F.]PT8$M];A:Y?8A8D$8)'[H
M!#@R@ZU79QKD-M)@I0W6XJ;@]5=*%[_1_JT@-+5N@>).8R. [(\[,98[S77A
MW#U\"-'FIW$ACT[>;5[)5O]GZ\F[_P%02P,$%     @ J:(:76F@H_H#!@
M#C0  !4   !N=F1A+3(P,C8P.#(V7W!R92YX;6S5FUM3VS@4Q]_Y%-[LZXK(
M\D424^BPM-UAEK8,T&EG7SJZ'"6>.G9&-B1\^Y4-Z39QH%[L3N*7Q+%/=,[Y
MZX[ %DF>'8_\0SSR(%.Y3K+)\>C3S3O$1J]/#@Y>_8;0ES^O
M+KPWN;J=059Z9Q9$"=I;).74*Z?@?<[MM^1.>)>I*$UN9PB=U%\[R^?W-IE,
M2X]@$J_,5D_M$?8Y1!@$XL0'1"4$B,I&B ,^EEQ7UQ^/1M"SG1^/Q8K$X7$J;
M'N9V,B88!^.5]>C1?-FP7P2UM<\Y']=/OYL6R39#UZP__O+^XEI-8290DA6E
MR%3EH$B.BOKF1:Y$6:O^T[B\)RVJ3VAEAJI;R"@QPV3^$*
MC%>]?[HZ7W.9W24Z$8PNK>U((Y'F5W6J"JHS$C<17%[\^V-_XOQKF%HC*K[E^X&X_-5C'U%"\L
M2\@T/ BS7M=(NW4UF45JCRZP;2+/01
MYUBB0 0\\@73--(_DZVUMP<-_W\Z&I+O[=\XV\VH Q$BB4V$*&9" U9Q$&]T
M=M4KA>N6FLD"U.$DOQN[=L=5)M5%G5*=SJ:W]:A_[/M3J[S<:K!N.%JY$U8U
M.%C_0WBT&,^%=0TA-4W2[Q(;F\]^91>6>0^*/G272V/D.34,6 OZXJ&WGDRZ
MSKAT@S?4EGV0< DVR9TN^HT;W3<34$(B[O, $>H>,(PA,$$O2*RY;<4&&2X;
M+]=XQY \2'(%DZ12(BL_B%DC_HAS)&+I)G%#PQ" .DG"3HQL\]H*D6!XB'16
M>"\(.7/R6)&>N\EV^3?<;R80"H484P&*E$\@)$I30WI 9,-M*T;"H3+21>,=
M0W+JI-&5/.]2,6G0+2GB@>&(TY R*5@@3-0)CC5WK:"(A@?%RS7=BQ'CW.TY
M[3RWM1C7KD/@++]U@-^?Y;HQ (+; $HN#/(I#UD0&C\VLH?QX]D@6H$3#P^<
MOO7?"YS>)2E\N)U)L)NQNX$1"1DIY#-EW#HK5E1U&UXV/;8"A0X5E!"A@\5FJY:[Q,P9^[RH[W)
M%UFC'(2U6Y5)A4)-G$*,$A;U,14U'+>KM>&!T_)"H?>)E7KA]=%>VOPNR51C
MW<4Q1LRX9$+N5E\$AQ&1?G_ ;'AO1\T 2[2]2;Y/Z%SF12G2?Y+YM@4[#4+$
MA68H9E0%QB=2X!XGIC7?[; 98/6V)[EW#$TU2IY:$-OB-C)"0DB.I%"$1MVFFTV/
M[9 88(FVD[0[QN*S3U.Z*\1@1$5))@7+)=2[> LHE(&T5G+)"4!",_5B$-(AF9N-NO/$V?
M[?@88%6VH[P[AN/20D4VN 5U?1:B.G5C/QJSI>[CYD?)8XV4QCZXM1)C'4\4
M/.V['2P#K,SV)/=^07->%+=@G\F%1NX*PABQ.&8QQX Q[[8\^5D$[0 :8*FV
M5^EW/3&!NG63Z[W;==TD9=I8D>.((4$Q0Y@$$$MA(JI$MVEIPV,[3 98G.TD
M[8ZQN+&B.M-\?3^3>6,N-6ZOSK!;;0GCAUK%4KF=>RLXB!"+,!N_P[:<#\4 GBW\Z_;O+9C8X!5ULX2[T5U]>T,
M[,0A_I?-%^7439)SD37.6F$WY E.-2*^$+Z,A:)1-U*><=X.F,'65[L+/H2#
MU$13!SX/D4\)#<-($9_^LH/4K\8-5"[H# !<   !Q,F9Y,C=C9F]C;VUM96YT87)Y+FAT
M;>U]:7?;1K+V]_=7].LE8\^!$*QKIZNKJ6KZ;)%/_^^\FC'K?_[_O_O_9
M&?DQ'*93%B1D&#&:,(^D,0_&Y'>/Q5_(V5GVU%4XFT=\/$F(95@=\GL8?>&W
M5/Z>\,1GW^?M?/>M_/S=MZ*3[P:A-__^.X_?$N[]XP5G/M>=)1=WW$LF
MYZ9AO'ZQ^BB-QO#T($R2<'K>AR<3]C4YHSX?!^=_I''"1W-X8Q0&"0PN@L[D
M/V6?]WO>U9R@R/;&'M-,_L(P],/H_*4A_KO 7\Y&=,K]^?G?/OSO]8_7E^03
M#>*_:3'\>1:SB(_D0S'_BYV;#G0@/MY)HG6A#9\'+">B:2'9OGEI=HR+ZO])
MUO_+RG\#RW>*:Y-&?_N/!X///I_)P'8L3BI<<@%*2B;DC)F(!02KR\Y^QG
M7?ST;>+=_\WJZ+9C;?W9T,VMO^UJUK1UQ]S^JFKVJSYY5Q#VXF@7*?[J\
M_&6Q0K?.TWZQM@!1_N TX]#G'L$A7I0E@,]&]];A\T^_G\]>-';.$^AHN$(/
M9R,]WKPB/"#0BP_"+=8(^SID, =&HP F%Y,92/UX0B/V=H5JAR+6T=!BE$(+
M2OC_6-U63MUL[]0%USNMG/HW+YWNQ:]MG/I_Q-3_L\_F4*TMX-X\-TO\C^R6
M!2DKP>*RTQ.'TLK,[U6_HUF6V=SY]4RM8[K-G9_3T;J.O75^UK;Y&768G=F3
MAHKUZ3W$,J.Z4WK=5%89G8;SJHG;VT]1&,=$6D(:"LRNJQL-1V:#F.7H?<6L
MNC#+TIT6,:ONJJ*AFV16N()HVOQ@M/?FU\0]^V;&\'8E&!/V=<:"F#67I:]Z
MFF/TFCN]KM9I\MG;U1RSL4=3I536A56NVW!6-7N7X\$PG#;8 MNQM:[M-'=^
MKJVY=IG[H9K.SP(EQ3$:*CM-=1RO#:NLII_&F[C/?6!)XW@T^QKD]
MS6[R.<[J:(YE-51L6@T7FLWAE&FI*\:G;W#"T?K8T_R1^RG&P-SWE%P+$VF>
M[-2=)I]]=+O?W-F9^@[C<[UEJ=UP2=H<3IE6TYV@Q*[WK0C*>73PUW'C@/I]
MO>=V7C\N#,BR>P<)5;$/$UVDFL5F6QT&]"$,SE0HD H%4J% 9::N0H':.'45
M"M1T2[T*!:KY_%0H4)V/P4T_!3>(52H4J(;;FPH%:@(R%;,4LTX3"M1T)]LF
MJ8K?O.Q9IG6/5XV9'Z!1A0(UBZ6O>IIE;_=!JOWTNIKC-/@JW=7LSG;30KTW
M/]-LT=97;U:YRD6ZSKMWW4)9^_E9/>K5;*M#B#+G:3*8DX]L%D9RM7UB8RR?MM=%_3$"BX2T\9C==:G5&1G>P#%L
MMV=8KF-W+.;:\(TW^J]Y9IR9\#_;<;MN!QDH9_%LM'V>V"05@-2RJ:L I#9.
M704@-?U^X"JVKT+\H$E=U@M.!@W]]#=ZVE6O\%>45U'<]WMJ2-K
M/S_'U&R[L6:3IEN@&\0J4]V'UV^_^RFBLPD?-M>GN:OU&WPAT-6,3G.C;;&V
M05-38IHJ)V9=6.6H4-OZ;6R?PX3ZC96,*H]$S>>G\DC466 VB%7MR".Q-?-E
M]J)CZ5V\4YZ%,4]X"#-B/DWX+5M>);]^L?)B=A%M+%^A@SA$KZNMKY2\))=C
M'T2+NZ[,5:OPYR1:\F?,S@81HU_.Z"AAT3GU[^@\7NL8>EV;Z"''N+4YT]UD
MXSZZ7X#*+-JV9I5;@'0+^)E&7UA"?@'9-@JC:=5< M1]?@5N=MMYJ:WN\]LX
M=76?WW0ST(\TH>1*T+ZYQH1>7S.L!H=\=UW-:G*%%\?4C/[V^=7O<79)SW+[)SA/^;H=/3NF8-7;A*SL[6C#HZJ)6;
MG>5H9J=V%;[*S"E
M<1)QZFN99_8[/-'-(AXW=],S--NLX:&NW.QL2S-W''EJ/CNSH_6MAFYZ5HV2
M4+=[T[-K=/(^ZJ9787OE.V_,B Q":G+441>D?W,S>'4TN]/&"L* O=@I9NK\I"*"(H(B0EDBU%+E59$:M9Z?
MBM2HL1*E+N?KPZJ61VKL$9EP&._J>U.P< J_,Q+/V)##./YBPH58^%C'Y&["
M(D;"- ( 9N8<,LL$M]QA)(C9E@1>F,:'#(?-%)98P(/ DH;.9
M#YS"S[%./D]8S JM8";[:!;"\PQ;&[(X#J-8@^\3%@W#(&##!#[&X2BYHQ'3
M"/7'8<23R12_G<<)PW_0 $#$HEL.[Y,D)![S.2"$I '_,V7DEOHIT\D-S&39
M,X M@MZ(#UQA&^:,M=( 8S!:#I.%+A%NW[QT>Q>DX)(GNEXU>>ED-:2D^@CX
M,8V0M\D$D," Z![Y,Z41SNZ.D8@-?1K'?,291ZB  @WF9!2%4U+R@HN\N;RZ
M?O<6.;-T]2 >< :^@28G-!@+Y,$(>$0&:0Q#Q#*S(3!24!@&0>-$C!!:!%1!
M*SS$[V5D  PP! 1CPN@[  <\B$R30]5+LJ,#M,J^02]9T]J#/=W.H'^(\ =@
MCQR#!WR1B^H\#3P6X5/WB\W7!&]Y/ >*ATV@H[ ZD>5AY!'0/G6+#&14@T;2
M&8%MY+6$'R5S1F$)CD,!$ORM]QI:@S4?)(!$OS3O*T.:HFB)]B%3KZ\;JV0R
MNZ7)I!$O H$98(0-]A31Z8R$(R$'?_#I\,L=\WWRFY]$%);I*(*U&*7#)(U
MJA96=#[@:0@R-(%536!+@+W0VS@.$/T1HS'\:MJKPR%A("<,^THPAN4,0UD;
MADY0I"QZ++;5VSQMRUWK9#EEV+I@@4WQJ5RL!2)V$N0:6TBQ?)\)86'_#&>8
MY1[V00^H*W:RJPD/*(C*A8!>2F:@L8]24A#:?+W>6$::VJV U,"';8>U-*3:%
MH[]%_6M*_T#E>Y[O#7O*F!H"\]UZQ>0Z@3*\5_AYJQA%L(!X=-WMDM-8UQE6
MP+>AKT6CSO9&S0WB.-XAD"S&H+U)D':7(OB%$6 Y
MQ?,Y?#,6\@HP[H,H9+D=@<7)HH'%%QE,)8R+G8@OLE]U\F$!\'OC8%_+CD,"
MDT4)?+V]KZWL42D^CICBHS+HQ_4K<22$YWV0[9+EH!/WI>4\@?T,5T\@L\_C- 51
M.=I$@%Y"B#%!J-RR+O2V,!"\"!CSH$%D& ,AF)MFLA480/O0PBWHF[Y8W;$T
M[1>YN7:X>F6:_5P:$A]/,OGZA3Y>6=W^TGRP%!)B=Y7#D';G$ >-[>-\Y"F]
M=JP3A$([5'Y? J(Q8BQ; T!E#TU(,M4#\84<+=(U"<=,J"^+FQ^DS&0>"Q8*
M+4-&6/P$H_%!8Q(G!E74BN8=LL "HRAN8O+3>,
MP1LQ4%$NR 1T.3QU9"?2_&  I]A9K.4 %#=7F55-*UI6M)R[Q4%D3<&))I!7
M$'C5E.)H8Y(QX@-P'TU#,%ZG9UUH^?=783P-X\6WV--/'PWC7\'A"8=^![_/Y2H074 S
M0I\<9LA%YK$ V#P 2C FA5,RX=%R"X/ICC@:+.56:1E65S2U^J5MUQ+KF=;$
M@UO 28;R"'?S88K2 <3!Y75VSX2;@[QZ7,'NB 4&GNV[G0.D$S/T%V[^ZAF=_]F=\NED=MGL#V]
M9]IJK&JL-1EK7^]TW9J,%>AJ/2'QXWW'10.=JG;[[ [H\ L<6.#X=Y;M,2/Q
MWQ/3A$F1>U 'K6VY(_$.PY-Z#NHV97*E/42#%M(12%DVT@Z2QH7T!M47%DH2CZ*DOUJRY8'OR:X\.!22>;8G]WOKC]4;S'7/=3<%;[79><"GUU1%]O=VH+A3Z%OD.B;W=,
ML$*?0M\!I[@[R%F!3X'O@%/EL4JNI%FRR#,6G6O#I
MU%>YK;K.>'**2@S! 5X9.Z<*H%F_966A6;%)L4FY[7^J68I9BE
MF/7,QPQUJ_$$KRF9*%*F_/4XYM=ZY$&CO@?;AH0&-9U-RIQ7"S:I>T'%+,4L
MQ2S%+,6LNC#KU.&YSW^S8>F66^%CQ\8"Y0_--DM0D^72O9>CIIB_9N47HY#
MIIDA4@>C3X7#J\S][XV?G4PG-P:I):.6S#[USM6244M&+9E]LE8]T@E!K1BU
M8MJY8LQ'QN*I%:-63$M7C-+*U(I1*V8?'X%'>DFI%:-63#M7C-VILUHF[./?
MBHIJWS>PGNTED F_HS[94-KV^:"R/L[-5?;*UJ.O3%G 3Z("=3 F/@T\39;U
ME#4U)\SW19G60NE*+%H9DP$3U*+@Y3[7I@F
M.OXF2HO*,I?%BHVBH&/,& X)VHXHK!$>T&A>+!Q[KVF-S%D"+01S\3XLQCML
M8 1/8%G8"15#XA$94)CGD.'L6%8CU0^#\1F6X81Y,, 2UA8=<9_%9 BO8:7;
M,((A7P=8Z'06BBKS=TQ6[Q1$85@A-0FAYX@&XZSZJBB2"B2@,@L$<0912+'2&!T.62Q^P(JO]U$M*B!'MP+P<0+M
MIUBK5F):(%X4&Q4\G44\QN*BBXJY832F ?\K([-8=B$( \-!;DA<_SFM7I;!0)(E.82U8$=VWDV!\?+>N;PC(&ZE*QA*8L
M6;:/5.-#/L,:J7S94SP1BTT"!4@ZF.<+/R-F7OB71[)*[1DV-"_,K(8PPF+%
M;%-EY4+I98$M6=D7*$]G(%&^\BG0R,>*JZ,$2_?**K]"3#Q8YG>MHF]O0T5?
MJR\$@6P&&\&*V3C6##8;Z@^+8LE8.UBP=U=)VXP&CJ5W\6)\%L9BRST71;7Y
M+5L67\4:AH47,_X9RU?H -0UR9ZR#$^4#;WV,@^27G@S613%8-5Q6 U5C5653%8
M50S>PW:C*@8?DHZJ8K"J&*PJ!M>+=*IBL*H8?%I*JHK!JD?5HZH8K"H&5_3F
M/[?5[ZCYLN>\&^;O4-<"2HT*H500K",$5>E,!;[61B4K\+48? U)BJ3 5T?P
MJ6U7@>]T(9\*? I\I_/3;UPJF@H#ZJ&:7L)3>^E@.&];"GZ5.%893&.,:]:&&."+$%K0F%$A7QO/":O;-TE64"A7KLLH-=
MR70,W2_2>JVFMBQ0'S[-HO"6>RS/EYFGCLP2#VYA8)[\4^9+%!DP5Q/C.;KE
MDC&PZ(XF0-,W/_W^EM"$?/J!O /&CN=_B\DO-Q\_?SK[A7]AY#,;3@*@S'A.
MKNATE@J>WDQX"(.?\.$D2XSX=>BG,;_%]BE48TROMDC1& 8RVVV\3-+( YBCR&*YDJA5
M-(C?1HQZ<[%H,$TE'V+Z4I&?$'@UXA$099%[D"]2#.8U[%B*WW"%TF_/WI
M=QP"MHII3@F.G$&?[RCP?YF_M)"^=(WO'IOYX5PRIX"M89CZ'M!MAGDZ82&N
MC@'V'3+-.)X,5/K.IAGXX@B6>=#?U=2QXJ*(I2],IL@@C?+!9A.8;30B&3V%M$L
MLE'*#)IA$;AQ<8W@^PN10J[":*87I5N6W9.OR$/R!CXO@L5KF..PW],MF?5L
MWQ2'W;[NN(_+E[8SQ6%/MYURS;8J'/_?I92?18)=%:K?B+ %W6USW(*0H,>F
M^?8M8"U7;TN\UD =U97CFG)^SNH;NIW+<. :'$!A^.S/E-_"45O4H! %7&CTA25929%!(NT['&L*
MR 3QK]R.WLE/4!J<4&5EB%>NO?R:T"S-_#@4;2X?,G2[\-"?L%.C40^>$X:Z
M&$ZZ$ZR[DO7E11R.TYB\?@*CAP='$6-RW",@NZRX<$=CDL;RK!@Q.#9CRQ&R
MT$-K00 #P?.[U=%7#O"BX,4D%"4];#2B:PUL:3K#9&Q&9I-,S,
M.*+2"@P#>,T]%GCU.YM?#H<@2)(82<4  LAP).6KCJV;"T()ZU+'(!Z=QZ+\
M2 SG\21.@ !X G_SXZ>;MTL0.&[V(* *$,6I[\^Q0HTHK *3!D(Q+SKQ'MG82#MS#P8
M1L):&K$1EHB*LXI.A1([PICMLTS0Y&Q$ ZQ\$X=\3^#=A=$7G-J0SC G(J$>
MTETNBX402NC7&AH'?P>DQG$* @$AOI3-@-B8!1S G ;RSC
M.EM>$'7QWO/QM7^R,\09'C?/["250]ME"%,>?P/&?+B]_
M$=MW /J#^""OOR29XWM%Y  *74EN<$2TOG&C" ?ZU>-3LB;4@'$*\7.)YT#X<_T&,)FR:U:*EH@:FOS J
M9+?)V ,+;GD4!JA);R N]_[Q@K.>872I83I#RW &K-_O,=?L4VKTO&%WT&7_
M-3LO]N6(].C8KCL]JIUC,O:_*_^5'+S0\8HZGULEG([2"(N#H.]%&$V%\J>A
M=TX"Y\DZ.@A8>J=K/<9!P#;T3L]Z=@HJ+-(PI?U(H#?8I!%'+*5\+2R@(
ML(_"3!$&]WQ(6HB#JX79YRJ<3M, QG2?-/5&P^;R3%E#^?QASJU"PZ.(4F\<
M;)$*'[]YV7$N0+WU.-7A[-\J&&RF"3K_QKO(LN7JNN0QH/_P,:"&1L\/^8'L
M9T;1)[=V42B?0^%?[8M;Q,Q!.PLIB87W/9[3$>2!<(@0_L8C'M!@B&?&.($O
MY$5+YCLN?8GI$&^6A2> N)=$$FGBK(MV-CR)IC)];D:]:48]M++7X*ZPF@40!?0+_0&YW:\+O'D);MT05B]Y=<)
M'M+6V,=%TEK^&!).\&88Q.G&(#QH9 ]! YCG="Q]P@-[&:/9%
M=X]D7G#JR!B8(W.%R]ATQF@MKZ&)9N80!BB,6O0KX4"H81YW%>?6ESLLMHGF
M+A_$/_!$)S\P@&$@D54(5]E\&:&MLWL'A>$WXH?!&!K)R03 &'XY&U"YNJ]5SA@D_K#
M-.-C3!:+13R3A=1X>!N\\8[;ATV-@-"=D*5C2B%N MZ'MX#9@HW ]YF0@_B)
M!PFAX&,V ^9[=9B$=&OL6RP46Y
MBZ$LF* $E"^#,(WBOY'P%B]U?1G=M7 _D:C+5^L"+07.;I>M]X:UJ:5=P^0R
M1SI\#I),"N%6 BR3H7;P0.AGK4?(7HJQ9[ 9)G@9D]_)K?>X["B75YE[QX[-
M)U^:6T>_&/.4SG&<'A^-F!"*0BCI(.)
M5@1V%GT8L!&7J@7V/Y/.0"#ILYC!S-$OR:,N^6I4U0\^'7ZYPU 5?&KI/"3?
M6@B8"+W>I,\,.JU$988LU#%)"(]-Q58?1@<<),CO1+KWY>_QW.5*R[O,+U\\
M$!H1!^;#%R6F4N L'XI"";S@EB-CD$$P%2(ARA<1U _VELZRV-)[4=;KL78\6A2$6&P!Z+J$<7;X
MQ8;.E@C/+Y^SF.LUY[Y%%%2) >.JVQP\K/Q[JN#?4QGA+T+)BQA&H9C+:VTA
M)(JQI0CIXJK-QB)CB[,%F"-9.C87XW-+KNVE!VO9-S*E -6_@BPHLU:6B\.#
M8?OA;+KT]'Y(E(N>4Q&'O.KKC/J,U RDO[4XHPCU-_.GUHJCIE)&#](8X\SC
MW-FDG%>2W-#F<%B78P*A_8>\49=^ZKF;I1"Z8AXEJ +2ICA_'G@IROZ<@@; [P\DAJPHOXP"R8P^JBYGJ^HG)WEL_VE/%69?=L6CKYT*KRG)>L6KYKO-KSZ[JN\\"ZTX:RV(=,JX*@+Z1"P
M%>%M85S$=(0I/"+85,0WY@5&]LN-;)X=GF,YAIC((P^,!G9T*K&Y4$'%06 D
MP24> ?Z\H O#.\$*<'1R/<7P?%3PI6*WH6'X/BUHZ]"^;+'8
M1W9$E%KCV \'\ (:!&#C'.YTXA,U0'09=@A$V 9
MRDE))?;^\YE$F1-Q4@6A$.?G9=#5Z3"?5QHL_(/01B/,405E?L,D5ZAZ-V&!
M:',<97(,Q? \1@O,$CQTP'TT^8CH&-B2_Y(>Z+,PR1S0B^>%A9 N[%'B]+HT
M/!6$9&'&2U,/\>E=G,G7<9I=3&:A"JBNQYELS1>4QV#1^FAZQ:-HPJ=BU8N_
M&17W7H=<:EW3
M5LA'@'NOW._7SY2P==(O,$ 4SG&^XZ %C*"A+QR)74G+$NG@(Q%:BB*Y70 @
MM(4F!7N[3[EPT)H7TNO(DXAH,7EHY +)(LHB'Z[(_22 .N31,)W&0DH\UEQQ
M,M^JER]?ULS @M&J( Q$8I7[=ZTZN805+R)'$1%XLF=>;B.4AO;L)9!HX0(C
M']@T3*(P.\LOFHU!#@C4)JARXYX@5KDP<8>X28YA-Q&VM\(#RW1!A7'E@N4W
M_9->;"*W=J6!T 9U<$S
M<[F8%]9TG;P'!0NM;VB:X$,AF;*U+B2XEJ_$(1_E7@WKZE F[W)A .N;#]FS
M6.UV^RJJ _;I#M@+<75<-T.8M&[(B6_R,]SEU5?><6\O?\"NWN]M_WGW@(X]
M6!.:[3^N6358-=A3#=8QRBVPDHY5V_V-]GUC!=G,G2UD7DL\)[GK:+=1MK]%M#4
M0QO 9@*MJ;L8QO+B&7TJG^-1TSWU")[OT2?#\E@4KBS8-\O"#R'CW#_F]1*;ZJS9!_I?Z<6!VM!#I+
M3;^E9+R<1=Q7='PF.';+D%%12BW< P&NZAM136F-5QBGB912A*@L(5Q%"(6(
M'8BHCUG@^3=OU2
MH5N.9G1W%U@_<-U-A8X*H\/0''=W-7&%CM:BP[2T7G]W_1.%CM:BPW$TUU:R
M0Z%CXTQL0[-ZSG'0T5A5O)B/1.GAM5X/74LS'4M)2X6.33/IF)KI=A4Z%#HV
M[J6VUG-MA0Z%CHVG-("'U5?
MYNOGN IN'.\=_?!;V>FGJ7B_\8RL']YB=/II*MXKF:]X7U11.WJG=;S?Q_L4
M&6OIUA;UKXPWF'R[LM;NRX?3,9,WEV];L7AV7[H=?J&TF+B5M, VA;B5M% U
MA+C]2EJ'&T)DY7T?FH(<15\%7QK3-QJN+X]6MPK]K4&_
MH=D]A7Z%_E:B'X.6'%.A7Z&_C>AW',TQNPK]"OUM1+]M:*9IM!7]>]D"5K-<
M7#QB>+6P$NP90:=$15M$!<;C]7IM%14*_>U&?\?4+-M2Z%?H;R/Z;5OK&PK]
M"OVM1#_&BSI6:T])"O[MAG_'T#I]MZWH+V]E3Y)C9-"%0K3SX5I2S^D6J0PK3"MY+3"M,+T$PG9Z>B'O+=2F'XLINM8
MPT0]>L1'&YNG.)RQB"8P=L*^SE@0LUAE*ZYUTL">YAB5C Y3X#C]3+I:YU@)
M)14XZ@8.5W/,2B:C4. X_4S,CF98EJ"?K^61Y]_A&1545P4QOJ6VJJUU[2,5(U'HJ!LZ7%MS[4J6%%7H./U,K)[F.$>J?:C043=T
MF&97LXY5&E/!HV[P< W-Z!XIAE 53GT6EGT.$^H3/IW1H2BM%N3WP]3[(XV3
M*0N2F"3A5@4ZBK"K,?U$O]73
M7%5,5:&_G>A'"W?75LZ_"OZMA+]K:'9[A;_R %./MM0#3&1^DJ8@C02L3.%<
M=1-;!3F^+5]GMZM2,BIP;-9Q.YK=J>3UFD+'Z6=B:=V.<@]4X-AR+:^9RCU0
MH6/S3&S-L(]T]7W<=&X5=^+ZB?(@)J,HG!+V9\J3.8G9,(UXPEG\5&V^(5X#
M;U C-E4BK(/0UG2UOJT2Y1Z&N)9F.2JCZX%H:VM=0Q'W4, UNO:I\[=5Q@^\
MROG@1ZM?R1I(3:%N)0T+#2&N%K"OKMA'Z_TVLK])_JP+VOI\#C7U*/5N;1>IN%=CAU!RQ1"3V;X%?E]K5.
MKY+W4@H=IY^)V]-LJY*7/PH=IY^)U=&<:F8J4^@X_4Q,LZ<9IG+H5O#88CO7
MS/Z1(H641W>!\#(MYRQB9PG]^D!Z3N6T]::K6:YR[CX,;;$D4N?P?ISM)*ZE
MF8XJSWT@VEI:7]4^/Y14T'I&[]3.W<^L$U391?M:V/&(T@9*G&DTUZQD='M#
MZ&MIO7XE3XP-H:]C5]+4VQ3J:HZAI,,!Z6NJ B"/O27T^.T:F<[P^7/3S(=W
M=#L$Z!OLZXP%,9/QY3<__/##Y=^7V<)AR&U&^SY9I72AYHBA<6PH[2MU0
M\*TOA8\%WWJ["3T0/;9T%5*%0)0O:<&W! N!M+8BO$)_N]'ON)KKM-:96J&_
MW>BW'*W;465P%/I;B?Y^7W,-2Z%?H;^-Z'=LK>>Z;46_J@.B'MWYZ#%L0>)F
MY=@K[T?NIPGS"O8@,F.P$"8T8L]WYZ,>K0YJV^IAC69/%199Z^@$2W/T,['T8U4B4-BH&S9,W:CDE;?"QNEGXN@]5V%#86.SW.@YE?!M;)>FGCLI
ME/%,4,NGNLL'8*;R$"AL;!.ME73*5]@X_4Q 75?9;10VMJCKACKF*VQLD1O=
MX[H&J_M"]6C+[@M_%Q^81R@,BXZ9O"F,21K#=SP@WH[[1*#$=)8F-.%AH.+)
M%CYW5C4-4,TAL-VOI#K9' *[=B7/^#6K]!!'.)6O/65
M*8W&/,BCV_NK#,+L,GPTSYCQ_7<#'/7*CEWXKW4,O:Y-])!C+-O'Q>.;3^3D/
M!*#$2Q>K'>#,UL @^I,_+R>M&W+BF;Z8]2Q_-G3S]?UC9OZ;W75V_+K]35,W
MMOYF=_5^;_O/NP=T[,&:T&S_<A!P9C0(:A#H.BPIZ2_4S;;T\\$=&^CJVX"%3HV
M9R,P--LYD@N.0D?=T&&ZFMVII.U4H>/T,^DZFJ.JY"AT;/$CL+1N]TB>!,JY
MLT#X7])H.*$QBXDP:H)BGX2HY(-JG\P)#3S"_DSY#%-;BT\\2&@PYFB2HW',
M5+YK442@T^VJ//<'H:VI=5U%VT/1MM=W%&T/0EO0=FQ%V\/0UM9,RSIU[8OR
M^:UW,^N16:VKKE9$/!CR&=;0HG-1%X.$@=(K]L.YVU<"Y# "1)73.I FK(K
M'8:P_EX*;\Y.]CQB3%X(C/[Q3*:M5ZKKE%:*IV8[9UM1U
M"OWM1K_3TUR5L%VAOYWH-VW-<0V%?H7^-J*_T]=Z_=8F[57H;S?Z[;[F]EJK
M^2C7.MV+
M-Q'S&;J;O-70IUPC=Q,^G) [%C'RRM%=,N"^S\- +F>\& K"@)%1&)%D G_S
M*$[(GRF-$A9IXN+HS2NS9Y"I?.UM=I<4 U7X""@$E,C?C=DPA!\7+X,71K9_Y?Q1^5H"5?R^6H.62KQY09P8$
M$O=Z?#JCPZ10G9:\N0&6_<#'Y =&TX2/4A\^^3ZY'"9O]141O3O\LG'Q@3W#
M/41\H.OTZQ-K5:O ,#58-=@]X@,WJP.YZ,&=K*PVD,DQ67U\567-?HJDD-[X
M&RJZ9DE%MQK'IBVW7);"*.:6]@
M8Z?3$&;PETAM@Y_O>9=H)(E@8!BW!D^(5J0Z,82I4QZ(YF#+DRUD&HQX /M:
M;(/PH%!+8)<)[S 0#N= >,*FH.ZXO7OGD2>AHPPX3J3[FN[>>H_:/\-SDYB\"X"YS^& U%_GV<95^S22G>S _XE_W9=@C0#[1N/6ZM!JS-5_
MI?Z<6!UMOSO][=-O*1DO83/R%1V?"8[=,F1\#DK5FTQ/0]LCH'8@);22Q"V%
MP89M<#5E&)KRGE=@*$+4GA"N(L1!$-' DTU)M!Q0V..%;__Q$.R?]HYAIU'G
M*HP3M,E$[)8%*7L"&!^A]N[A+' R I5P%B@]SX>OL4\VS0=J1S[N,+/'?!7@
MV@:XW7FM%. 4X)X9<+L3FM01<*U 6PVAUK'-3\4Z1I.F>&U2OXM!N"@L8IH=$Y6.9?
M!8UZ0\,Z6&Y&A8QZ(\.VE=!0T-@X$[>4P6V_BR-U(C@=/S]1G\4:&;. 1=27
MWK#>E <\3B)1#TL=#6J]7G=?R"A!WEI@'"RIOP)&O8%QL#*8"ACU!H9YL$H/
M"ADU1T8=#P7Y(V72.M3!GU<]>I! H)VH+=',$2-%GRO=1#Z,K86 CRE;WOSP
MEEP5XT"Q;.&;,>5!_%:DG_##&$N=A('(/I[,"="'WXJS*QQL.3JALCA9I#LH
ME$2ARS!48$,0C0N4AS,0RGK#"9F W32%1AW)2PXJE"
MK_^PS,L2*6R&X1,%XLXN5#NJG2:U<^C]1%6\7YMHBRO>]_NZ:7=QWIL2VNS*
MC&'I=K?W[/DVNH9N/S*ASYK+FKFX^_G+S\?+S];#F?CWS6^?_WUS\S\;B?+PX;+_;,>7?6H?GO+,54L<_&J3]__![''D
M)DW\,/SR\!*H$.D/%;9],DO3FU=X#LL2"L9O'V;&\R3O.UFV)"%HQA&<)XE4
M RI30NMD$.@Z^N&]'8\]J=?[B)43EZFK\'*YEGDK,5O8AA1C66*QU41C:D%]
M\[)GF=;%<2YWZBVD-VL*'P!CCQ'4^^=1WX"XI^94/Q46-Y,2A7M[THV?C,P;
MMYM]+L1.KMF6/PG51KCLT "QQ"I-8.SY-<93MBUU8W[ZF?1UZX3[K5(E'^;0
MIARU2H'MWVS82[_?[5^"V:3?9 ZM\BI3=S3FNX[1N$SNU
MW>WNIWM@";+04*3*AQWM7W\' *F'+2F2;4HD-7O.IK;Y F9^F!D,YO'C(!T&
M;W\<<-9[^W]^_+\'!^1=U,V&/$Q)-^8LY3V2)2*\)7_V>/*9'!SD=YU$HW$L
M;@;J#=^^V-/W!'1^]XH/;H7O71P:!K&=]_,W\KB6[C[)DK3:'C8@3M3_B4]8(&X#0__
MRI)4],?P1#\*4QA<#!_3/^IO/O[RW.M,:Y0N?WCY8W+ (];K 64/ MY/U;B*
M/RBZ/AQI%TC)X_Q;Q5N[41#%A]\:ZG]'\LI!GPU%,#[\Q_F_S]Z='9,K%B;_
MH G\>Y#P6/3U38GX'S\T'?B"^O5>4]*#=P0BY 5E34O2,G_1<1A&6=CE"7DO
M0A9V!0O()4^R($U(/XK)%>]&88_\GK$8Q@DW)5VX \#AK4F3SD.2V.V%O-)_
M$F$/"')X8/H3!KP,4)AQ
M$O7)JTZ[99$;$00B"BG)1L0TVM^1?AP-"2-CSF+";B-DS'88\XZEC)RH]4OB
M&2;YG98QSR33>PZ3ELJU7QY2;^SL40^#=RY9I2WR
M/O]V?C,E/Q\??U*/A%%XH'ZYC:,D(1H2";GG,2< C 'QW);Q76O! _#R$)":
MD!%\O2>"3$XV&3!X4#W]RFHY;?4(_&19% B1C'@W%7<\&+=(=5&Y0BP81\=G
M9, 2F OK#F"^ G27"/N!G%<4DE$DPK1%SE(%3N\H(;U(FCY9POM90.[!QI%7
M$\#(9PYDEL0:Q5$O4V11Q()?^R)E-P%OD?/HGI)N-!P!;8E("BA1-1;SB"1,
M '3@13PDOV0LO*6 L@P I>%P4'AK.LA'$(UX>#",>CP@L*R2<9+RH2;C8)P(:3_ YX""
MZMY08'P,9(J!>UD\I80B:TJ X0&\G[-AB_P;*$PNLQL!*SF,[N5TU.6"]W*%
M2\+*5Z1 1 #2O90-7U@W!<&02K;H,;9RWM=M^;S+X@(Q#P0@P*(_-?5H#E?
M.A UA"7&1D"E+V((.PD@Q2NK/55YDE)*X@PDRF*Y%-470-0.Y7O5-;EL1EG<
MA64KWP9?[K)D !+K3@ R>TF+'"?R9OD@_%[\.#]*JOXFER(+QX#M1\/JS&AB
M^."0B5 M?+48I930DG$Z%,*R=!#%XG],LK]^\C!_T;V0, 9])^<8PL *B@%1
MYNBL=)H!&RVE+S0U@%07W32Z@3^8A>H#EC*Y<&;9"H_&P(ZX)Y^XXB-8Y.H9
M0S_4>DR[]3:&SL*-X1R]I:&:_R6-1FJWMC;]O?9-IS0KZ7=K=H=$KK(A#'/\
M7!0IQ5,\J >.IK_@MR>WO$XE3(X
M_XKZH+X\W6JW#+W=3F'GF_:*+^>76^K2#VGO\37+;WF^N_2RT3*77EOU6M-J
M^78;7UO*:^V6Y2U_=/:U/R@X:$@ ZA*0NO_ZQO2_*9[(=TF'5JL-"Y*8\O\M
M5__TV.7Q$(A#T>L%?+L[&X5R:3=/5NC2>=K?/%B 4O#(:291 /:>'.+1N@20
MV\CRI]\I9J]>=@CF:R"ZJW6(HL?K5U)C#[76!".0?^F"<)_?62A%\&:.:F41
M:VMH,=9"BY3P_YUQ?NW3U,W]G;KB>GLOI_[]MXYW]/L^3OV_:NK_W40Y5$L%
M/)KG8HF?>YC78/&ZTU-''969WZM.F\+VO+GS\TW:-MWFSL]I4\^QE\[/6C8_
MHPZS,_WOOS7;QM'#Z7V-949UI_1=4UEEM!O.JR:JMY]G#E$:"DQY'M1P9#:(
M64ZK@\RJ"[.LEK-'S*J[J6BT3#)*D\;.#T;[:'Y-U-D7H_SXF_ O(WF6WER6
MOO*I8_C-G9Y'VTW>>[O4,1N[-46CLBZL[31W
M?JY-77N=\Z&:SL\"(\4Q&BH[3=R.UX955M-WXTW4<^<\;;R&R&BHVK88+S>9PRK3PB/'Y"DX%6F][FN_R=*O'D9(/1(])@--:8+)0)@,A,E F R$R4"8#-20#2\F ]5[?I@,5.=]<(-8A112[:?G
M4<=I\&&Z2^WVZ1ZJLWJUP,DJZSEFMZJ'3;IAVWP0%CKDT]?[F'
MLO;SLWSJ.HU58TP?83=))!51J7UT-VWQ9!K?% \-XBE3
M;_G!305
MB(W9]KFC( .NQ@06/OQ@?=9?O5
MDX$(FTC.\>@L %>+ $^*\:NR8;
M=6E$!KXH Z-'D3F+N/BP*^>TA;+N1#S7+[O>#8F+GLZJD:QJ];RHC:JF3[*@
M?W/*OA"@*$]RTMWP])[SD)AM6 CJ5M-72X)_Z099KQ!\/?A(S&4_XI0/=1=?
M2>U8P)>[ Q;>ZA<^4);R8SR\$W$4JBZVU27V8I/E%_@YD+\G=1OYK*)"Z;4=
MZ76E>@WQ,VS,%5$!W:&_)XDO)O%(AT#2\+HCDE6)&KIS@KL
MGX*,OQ=<+4RE)AQR=0U\[_$ V!TK>2V7N>A*UB? :?A5,K?+DT1>58L?F)B(
M0( !.OUJ+B10CF\;!A\8+.G!O-WX[NH_.8,GRIGF\E;;C7,FG)3R4@Z#W2_=
MC('<>"2/$2C("S &+Z/N
MY_Q'D @A; A^B@$:?2E'Y-XAZ U9")/L#K2OYK??+N6GAQ%L06&.) +)0EZY
MQF1/JDU)$?<.Y'#'I,M&LH37Y)A# 2W*E,FI-= L7-7K4C&$<239S5]@]FJ0
MPF2$4EKL-N9^ X\&841.,Y1036I<+GQ*;@ZA C
M!/(24$#*#ZN!,J./V&@$6D>K-I0RVW,TP:KK$;#P8;6/HOO<8Y0,.+ 6EB[K
M2OV?#N(HNQV #ID105J87/U$3N$/8/(#,N3Z_G1Q>7UU\$E\YN1ZNA\X82"4
MI(."7 Q$),$QB)*)E9J++%S1._4R*"5P+QD?3'=[<&,LA3AHH"B6]J=B\LJ6-Q9[CQZP)1Y/]HUZ+SHC Q[:
M+L4;$1C;%_5JVQ'UTWLFO81@%,)^(,IBV"H.(]A1:";/621*'BSW#A0OF[J4
M)DX"=8*D#= ,C)!H*#W8$Z^$,AUR\"A;%#ZLSB-&L4BXC(;H'"T'2#T#E&H<
M:[3.^MO!:N-?1@"@FY_QCI$\\827H8Y0>
M2ZE%0R8]
M'2/>%7U0/BGT N
MI!;2-JM4#\>PX632>9D[KK1YH11.KE18[T[=(/U=K,_!E%4LSOU:R,)=FIL_
MRUVBXMQ)%/:%))J, 3E1>P'EK 0N2S=TEL"3&5)R?OSOTTNUAJ=>JJGQF$CO$8PO7+"7 -S),\E[EN:>3!*%#[RJ,^[4
MF6-1IH_#>.%K/U"[9&D@*U\%(!$^!GO;0;%CFI_V [LUY@EG<5=**T!1FJ&[
M8S>[&T:&69 *%0HS>VSYR+WQ&QF,0_%E5IE(/];!C!]KR(<2U87%4M\_J39"'R>[$E_92"5R*V4$"J",/=1Z,7)@EFC(5"&Y8*=K/97
MS*[[>2&C=Z+QG+)3WWVT%Y[9OE*@%@PW&ZT0$$H5*A3I$QYMZ&CKE4DW?$\.
M)M^7SVYES@&::1R%A5&LMO'Z/@3C;KSG7PFSR0]K$PV]@V[ 0*4DV8C'N9,T
MUGN3?"NB(<=FY%H,FC+N$=M5^]9BLWM&?OET\O ]\-T>@#6(1GI%:/UUFL4
MD]I%V)[V;OG4>$1P[R12=9X)\X&KWC267L>MVFO$K5H+PE:1MSO1HM/(4="1
M8&:'=U)H2.;]"<2+[F'?=3*G?"ZO_R//"N//A?:9A! 2\V#$4]8'R9/+I(G!
M-,?YZ(KSS^3.(>_!T!E0\D[T^UDB
M=U4_\^&0T8D%2^R62S[(\84%'GZ_Y_+/_E2NP!\5.,B Q2%/9([7+SP>PG^T
M-UC>('V()P&[+\P=*:7DWR64)X$R*%&V[2R:=<5Y%CN58,2&;!P1BUQ)A9!'K8,$2(5,BY=B!!"01$H,
M*(&B]T.LSR<8T9)@>I1\QP=")KG,['9H[E$>#D'I2 = EF#\R<[.[DZB! R#
M8JG;BPP'[7R1IN%8HV"*B6$HID 8J=-;I9IP&>\RO^TL8:Q;L/3G2\.X)I>\
M.+/Y)1NR,!(]>@D0@UX,H
MGMTS/!Q-/@SUB5G/1Z%,$#"[VDC\PH)(&XL*$**;K(P9DV+@($E9]W-QKIL?
M*#V0 )1D(?!!J@JP5(O(:'4&K!\3(9BR,OD!M(.\'/,!#Q-IRR(FMGY('(!>
MUVQRO& D6E6J7FW3
M+WWR_D)Z1*6>8?&XNE[UQ8)B.O+BO+QPT-Z,85H!3T&>_A;#7IL^+-FA%X84
MI7>BJSR\B0K>T*G( \'[18H*K-:HWX>;=.HANV,BT$G+L)-/TY$N>*6:&JM_
MI.M1IJ^U0IGSQ%JPE&MW7"%C7G*;YH0%@2+*G_RF"]M1F84/BD?M6*L[K54U
MSG1FB#P9R+JIRCR;3+8K)ZMVX2QD 2CM(EIIF
M:Z)-T0/0RH+\3=TLCB7*IE='<93H(C9IU&,J4<$BH]:P13ZQ//I/##EY[>H_
MG@(+."@(^<Z?B*K^IC0*Y3^J8KJJ\^)1, P3)*1?!P
M/ \G\8 ;CTFN8K,E:5=4KZO=XCPO:AQ]!(LDBWF%B_8L7H;7D2H%$:A,N04\
M[LD"6+(@1*BZW:NPYBEOP;!.=8Z=DMHR6$'EO!R!>B$+WB/=O#QAU798('W
M98SOPF)M=%4)L(47=<>'V4LPQ3C_,WF=/_L&;N"S'PTGS2*6_!%62E%AFZH2
MV[V\[K8JM4W52NW'7*Z\9$"DH=DB[R-.-$EF]0OU"
MR2T +5'B$C:5$I'J!)G#"^1&40?_"L5\R< "F7-<5CDFFM%TXDI@21+! %6U
M./:%""!4MRB=DA0%S>[A+;S(9@2>M,A/'& 8:F3-.#H6R\I'9M0*"L,U$D3A
M+;RD(!, H_OYX(;IU3V4$] \RR>CE<5 2 "I;=*"UXNI^3&S_B4>;F1]MR(-
M IA3K,>O?_7]'*ZEE0-#*GZU*5K5"<(P%HU+S"
M#6P(86CPMP(5,*Z1C&")\VAOR??13,A7RL);K8T!&[G1,(IA*F(DY1 ;#XOC
MQ4U>,RGV><,# ;O-I AKD.2;+!N5!KN"H3P<,)5@(!\&81HG.0Y48K14R%DH
MP]3@X^J<8V)ZJ#4[P#6_2F58/-RYK"[VHS+F615"@RHTOK"P'*
M)7][+)G,9$ZWCFKCDW#)AU]\;&+ .*5$6Z&"B@6Z=/23,0_!\(%Q]D1?F3FI
M%@V/[U,QYQ)]N7B1[]TPN:<2ELSQC4RUUZ^K[MA7[B5>GQ]?O3O^71G",)-W
MQV\D\B8'!'GDILH".-/6[B3MO)>[_&"IO CGGE$MNZM"/G= Q6^__7;'4]]M
MB=-^%N>*?:+5J)13*:B330MI+YR4]OU-7'6PZ8H/U*GS*.&'Q0]'L(N2NZY#
M$:IAJH>.YK\@?64/6@"H#^K+N1O-]UMVVY*>M+P33?[AW,G64DZV!ST(]#7;
M;3F^N_2RT3*77EOU6JO3LHWVB[_6-EL=H[/6:^O5>>ZKR#7T!BX9B#$CO[!8
M;-#"Q9"3^F:M6VM%CH_PI9"3CV!SP4A", !JW'MPO2F?%9ZAR\(SA#AX>Q+%
MHT@5E)&.Z2PL"L8T" V/[#ACQA8JYC_K&=X'-#R)*/7&P1*IF4(EWW?S9J,N]V('?ZMW%TGP[HK$M!
M[;QN0$GWA7;M/G!CY35$9;H;C^6!H':\3'(OE3]N&L YK44D[YHF2M$\22YW
M]< 6OJ=?U(M5VM0:@U>.<>W3Z?&A@3F-T 3X6Q[*KPE 7^)U^6Q=-D%[B28BL="K+CV,(
MPWZ$,*PGBHJDZ#5@&&5Q?CZAX+;F$]-*E;-87>/AF+#JIJY+)0RS1,@DA,T:
M?6DQ.H["GOX$B(6_=(,:60B-I[GLU=)(S6P-.N6.L8(BTYH$1?IH<8XRHRU4
MLJHNP9'..929/$F7%V ^]RSN'0TAASKLQ2S8]NJ  ,;RH*F/0T+T08?,_&\^U8[YHL1.,9WS?\$PX!YP6.1O*_@'2H:_M@04OAK]G
M,]YY%2$@WSC[C?Q@2!L;>4$$>0P8#457'[A$@5#&HSJ-5AIA\9H"S.H:/RK\
MJ-!J0A\. JDR.4[5R$*>PPR!AJ!*=9.#7&,GCP[ "^6N/ZC"3*='>1,-+PZ6W^!1::*MF[["7ZL[DL
MD)[N4:K)L]3B(@NLFXE$UX=+\P0I2D)/J:O6;SRMX-?C?3ZYO6C:I [W0T \
M0&$TB=A6G]=VUN/[)R6;U($6R)(B& B !%\N9IN%DRY=\D!7G5W/6)ZKIS['
M@?L!#]7K;^-<$DJYKIMH+(0?DV6.9054F?*J2BWH<[THS7UXO+.1%3./@-YV]I_4?"(O+?%0SM_S>@J^.A X=*4;=
M5Q.=#O?T1 E'L"A3+8X7'0'FT50343H3"B4I-HE7 Q$/\X 9Q[>3 )05"JY0
MC+;HM #[//1$6,L:107_(0G ,2D&9L,Q0J84&W3QB2Z ;M0JQ+@N3Z6ST,15HQ<(;DO ZN+X*P[MZ6RF
M"(@*51P];Z9 \^2D:2HJG]J^LRE;-@P
M29RGLPG6VA":R711($QC)J5K7G57!;VH$+];&:88*_-W,
M]=JTR'LPON1)O-P8BZX2-/G2U0(Y7U6GB\OCZ[.+\W7S1BLP ^U,<\NSG)+&21;]KQCQ
M=H,D0#"U#"V<%D5)K(I)L%J68STIFF'U-=]X^= +N]UJ^]Z+O]:T6K[]M(B.
M[=, !UOF8!W[)2-P-CB +/FL4DN+1>_O;/Q^K1B6?N'EU(6QUJ'X]4"&6G^$
M^P8).97>SY$K&
M^A,"LNY@-J\VFX<)I'*TWHRG8UIW3$Q81@F*7TW#:
MU'-L! 6"8F8:IN=1W_80%8B*6?UA4-]PMP"*KUA$N8F5G^59!38OZ'0,)
M7)ZQY%#7]I' I1'8-JCE.]LA\'I:1F[DZZ5B%GNM?IXI&?EE[]A6#U>+)
M>Q8U'>OE"U6O!^J5<'X"S%Y&DGS]PVO(F&;!Q+:I[]H($X3)2IB8@!.KTT&<
M($Y6XJ1M4-4F#77D>=1PM[1)WTLOB /F96GGM$A?,."I[95VD($$?NM3R]^2'WK/=<\5
M"V1Z\RT/965W7:"@-Q2A4,UKQ5U3SY),:J,**I6^IF4A?
M;2%*OG*VU::&A4=;").OP,2@CK.WT@2/MAIS:[./MG0?RH:Z@-HV]6S<0Y>X
MAX:-A8/AQ"4ZV4R/6AY2N#P*NP8UO"T%;'_%#U24I0NCD*_F"=[YU#N1!3N_
M$UFP\SL;:=/.]%57+=<;:M1ZU/.V=&ZQEP:!1;UV&^E;9HZGB7N&$@EL4\/>
M4@XMNKD:01VJ+>M(A=[
M25_+IG !"5RBEZIC[3*_H[%56LYYNN30_H7"B"HUVV5U\3:>Y :@VO8$E1/]>HM\T?6J8!L(?X;^/\'=<:G:\?44_GIXU
MYM8FGIY-=YK3SL;??^OZCU9,;;BT\UOWO!3%3RP1W1?O^+*SZ;QXT?[=N4-;
M3B7/C1$;NY^)V3(J6<\[#W?/BQTRC8D"E'F
M&F*[PW();&.V;+D$MK"?9+D$=HQ=]I/<'TVSQ%'5'"!9U=RU-8? KHT5Y\M5
MYJAK2D:PMZ6V/4K7_)"RFX##?WOB[NV/\$_QF2&+;T58Y%YVYHGV5Y:DHC_.
M"?3VQQOYIGRT&[VHR\.4Q\]_SRX&E#/.]EL6D/]H%"5";A\/8QZHKBE']Z*7
M#G+&SCZ8?]F8/L)NDDAJOJ6//&_RL_\.XBF0;OG!3C9,'
M'X:O/IAHF6/.V
M'/=I UKU6LMN>6Z[!!ITG$XY@UW[M0LTU=I5U4Q_8Z-=PW\+6LM<+^-0O^CD
MXO+3Q>7Q]=G%^1H!H'M$GY.+\W>GYU>G[X!$YU<7'\[>'5_#+S\=?S@^/SDE
M5[^#$YCJ^NUC/G9A((YRG3U+
M$IXFM4D2+$.=UOR,[H0E ]4CNBM_X']GXHX%P-I'/3,W/F+W3'HIZ/"[U$?6Y1W]]IK"TN],?NH&XW
MRF![1&+>Y;!7@A7?Y.93;9L:+A;^+E&;^]39;4 ]+O(%=?WO>)A&<7.5MVU2
MU\/@Y1)=-29UC)U:1[BN'S'E4\Q'3/2*9AV)7>7VJU
M-!8GEBL/+Q G&):!81G/L&^C$0QEK.Q:Z8<>#4'W--D_96(2;NF'RO9NO?S[
MLG@O8.FR%(9- LX2WNR=J$MMK--2ION)^NV=5NK=EU7[#"I5LUU'0PCL@Y%:[#^V<;L+?,MK4-VR$/P:M[#)HY0DU
M\"HE*CZ<'?]T]N'L^NSTBAR?OR-7OQQ?GOYR\>'=Z>75/\CI[W^<7?\72^-5
M$'@UW^,616P"P6Y$H!Q36,FFONR<9&:.V%CZ&[& 3?4\ J9;U7121,?N9]*A
MOEF/4(B]DJIQ)EON/I#R
M>*@J5C5T;9L4WHU+NSQ=WMFIF8)/0@/>,@E,5\$ 4 U^0?>5N/AIJQEN7#
M'M1!.[;$R#>/6IUZ%%)#2W;[EJP*L$K6D#@O9*]4BAK[D"R$N7(O(AH0_O6$
M/^;*;:*1?U 54^"_/7'W]D?XIWABR.);$1[HEQ]VYD&M&\GGS'W[XXU\43[A
MLMZ3$]GV6Q:0Y6@4):#-(B )#U@J[OC1O>BE@YP)LP_F7S:FC[ ;('R6+G]D
MY9C_RI)4],?+!SW[[R">FERW_. FYNSS >O#I ]9<,_&R8,/PU_<
M;LP_G).DI4CR8(7I:TZ[Y7OMI9>-EKGTVJK7FF;+\:PGO7;U-=OS<;#U&JRS
MUFL7[GHL9V-WA5Z!6]"QYEHZ-G_1R<7EIXO+X^NSB_,YA=?069]SFVI/E2GQ93I3G@F;A]M:J&.E^S8(QL=IT#1RM-?V])J.W#AF1
M4@BXD@"WIJA[EFM]#637C)268;7+*1)2/T*X2 A$Q I$;$/";-N9?,*2 >D'
MT7U"^G$T&['.NJFXVZB2T$NIK&UKM^>*_)<:YPY(,_>>)N+[G*=YNP6LH52]
M2!*W0]M^)4/.$1V[GPELE!QKI\DNB([JHL,T?6J8E:Q[@O#8_4P 9Q=&=
MZ/$>N1D_:T=938[M_-:G0D:%^U05,U=IU/U\<,,2+B=3&
MN[$U@5ZW#>L-KL(R5B&JD/*(V_$K>6S4$.J^EC5]C=+%0B.5Q\],A'FHC9Z(J*6D]6HZ'M"V'MC;U#"1N6< U/!L5R9/KDS946=@F
MEA N<=7!?U">E>*YJF:T6D.H^]KLM"NK*ZH[2
MMNXLO.-A&L7-;:4!8LWS'5QYI=#6IFT+
M#R7+<@U0RT#@EJ4R?!^/S9Y$NT\Q'S'1*V+!];XU4BV:]$:VN8K$Z>#I0SE>
M9A]C),N,'*+.%J3=7M*VXVRIC5@C=S,[D6X6QQP&T?Q6L9:+!]VE.@H,MWS?\E[2
M5M:,0:U2XJ::&AYJ%6P[OD%7;'>GG00;OA[;UI:2Q_>2NK#']BI9@:PA].UX
MU2A]T+".G>=YT2[RM3I->]>3W@+3V_.PLQ_VI%\)$].E=MM%F"!,5L+$(*%1ZL
MFTJ[W#[%49?S7HZ:A 5Y>-F0I7EA!ID0U>,WZ4RMAH8ZXU3* )[ME.D?-UWT
M&)4(X#9UV^A0+M&A3#V[&DZYYF@;4"^/B@$U5,%XU,+SUS+IB\JE5/ Z)M*W
M]N!MIF+)XNZ )?NE3EZ;+O4Q&[ DXF+9@](B_"SJ8)YE63(!U'3Y-26:KT3V
MP^7UVC*IYV&.93G$]:AOHGI&X-:.N*9#3<-'+?(\+1+S@*6\)SM%CF(980:;
M$GFV(O.7]G(S5SD[M3O#:Q8'$IA/W^6]\RK2,\8$?HUHVP
M6X7NGB:K9HGJN;HPKG_O$E5?^[3=6;J8,;NK0ISRJ&DMC:- 3E6(4[8K6X\C
MJVK *E,V95E:(PO3%IMYJR+Z#ZFLV@K_[8F[MS_"/P]X8/LMM3<>1=HU?*@.
M(<4=/[H7O720(VCV0&++X5X4'^9&=^K?R5@7W2'^?K
MXNV/-W+4.5#5H&?_'<33*=_R@YN8L\\'K)_R^) %]VRP,V2OAA\<-1X0@1H5K;ZJ&C^0_(F3U8@>I[^G(^Z4ZG
MY5BNG'=N#^-:37KOZFNWY
M.-AZ#=99Z[7[D(K=%R$+NYB*C:G8:R;'S<0-B23) #R\B$B='O1&26,CA2R'
M^ITM%?E'AQU2&"%?<''7#AZ,@&G.YA8FZGPGL4L*F*AF4@4CANE/8
MQ6H")5+7QHSLYZ@7-I8I#G/J)>:CV12[;C0<1J'6-0W5,J_-#O5LS $KA[A
M6PM#@-C0O:+[406.+I(RKXTN,X'=0SEA8H@Z<,DWJ+R^@BZRJ$*LLCSK+_2O(JFJQRO9W*0"Q!L@.;FUD
MOOR A;=<6C:Z>G78TS](__8="Z3ONZ%;Z@ZU#$P2+37"P5U>)PYI^SQW$%AU
M/H*W/'\%-;;5++V16F69+B$L)3?\5H2AW$)'?3*"#T1-320P;6K9'B[3\@CL
M H$=)'!Y!#9HV\ \Y_(([%/7[U1"T33,<[M2!7'X^U+E\T(NBTI1X]5+37(#
MT&U[CI9%'<H-N"YW(F&1L/6Z$]M?8/N+N?87,.F6H2>^J/_%U_H>K->@X.&U
M57T/;*_5\9=??DZ3AIP%]T1V:NM2/3>Z+\=2<7EY\N+H^OSR[.R=PV">FDZ71Y>G)Q?G+V
MX4S3Z.(]^?GX^!.YOB#G%^<'ZN?W9^?'<,OQ!_+Q]/CJC\O3J_TAY2;;\->O
MR%E(X-4!6%,))?Q+E\/01QR,G0&+.>FQE+U!VBVDW1\ARWHBY;W%!'I@[E8Q
MVM9T=SV"K8?;;O#ZIQQ@3S#YPFRI[ I9+*BO!S'GY"/<-TC(:=CCRV.V-J!+
MYX7(LC//ZY7XLIPH#0+PPE,%<\ZANTFD2,6X^&L6C(G5IFM >JWI[RD9CT>Q
M")".+P1';QTR(J5PX98$N$9JKYHRR#*L=CD-2Y$0M26$BX1 1*Q 1'V\%B^O
MI?&3=?SD0I.C_;)VQ+9=B\I[+1M&RX2#F-_Q,.//D%>+25&M0+S%A%@6B%?E
M<+NE_84-;TM).XB.VJ'#H(Y;R=QL1,?N9V):U.]L*;,
MCNIMAR*%H737CM#5_\[8\3ISZ2N-'I93[R?M9$;;?*+VZ^^VG.
M\WZ3D%7)6$NE\3\U&DP_75EO]W'W[TSHJ@H'JA #[ZEZF)%LDZO:"VN]L7;&Q.K>NGL#6VP46WKT9"6CGQI"7(0OPK?&Q*U&Z-L3%7PEE/N2
M)L=1>/#$-!6L,;TO-:9ETHN-%=81_?N)?H/:/J(?T;^7Z)=)2XZ)Z$?T[R/Z
M'8B(9!6Q\&$8A7\T+O+.>=ZX?'M^H+/DGG=]BRLR^
MI,SXF"R,X-]7\'O4<3H(?@3_/H+?I78;:^DA^/<2_*9+VSZB']&_G^@WJ.TZ
M^XI^C.7'6U?>N@>Q_"+L1L-U&BM@4%T5Q/B2WJHV]>PM-2-!=-0-':Y-7;N2
M+441';N?B>53Q]E2[T-$1]W089H>M;;5&A/A43=XN 8UO"WE$&+CU!=AV764
MLH"(X8AU56NUL#@?9KV_LB0=\C!-2!J]Y!:A(<$IEF5540XVA;K8F+U,/6Y4
M,IFW(=1UVI7,=VP(=:WV+O,%:^/N6SO\2^OS#6N@XD%0HP^"VC;MN.U]/0A"
M].\W^EV;>MA,%=&_G^BW?.IB,U5$_WZB7WJX/1N#?Q'^>PE_UZ#V_@I_C ##
M6_[OEW"H>Q/4S$V%"^G$T)/SO3*1C
MDO!N%HM4\.2YUGQ#H@9>2XO8Q$)8I=#6=&G'QD*YY1#7HI:#%5U+HJU-/0.)
M6Q9P#<_>=?VVRL2!5[D>O*KY2E[_A!7?WUJ=2O9 :@IU*^E8: AQ,:2[Q)VM
M54EO>D.HNZ5$FGJ?WGTMH/L))W@8U[$O<1VV469/[$H'=2#T]QOZCNLA]!'Z
M^PA]UT*IC]#?2^A[F+Z&T-]/Z'?:_KY"_[D!W)M&"CS](;RU,K?6VRVT(J@[
MY"D6]&Q"7)7;H6V_DN=2B([=S\3UJ6U5\O 'T;'[F5AMZE2S4AFB8_T/H:U&_4\D=8T/HZ]B5=/4VA;K4,5 ZE$A?$QN //64L"?N'I#I
M0-Y_:)K%\+;NAP![@W\9\3#A.K_\XJ>??CK^Y[1:. QYG]'^_;>^95I'*$^0
MPK6EL(/F!L*WOA3>%GSK'2;TE>RQ::@0-@+!6-*9V!+9"&1O.\(C^O<;_8Y+
M76=O@ZD1_?N-?LNA7AO;X"#Z]Q+]G0YU#0O1C^C?1_0[-O5==U_1CWU \-:5
MMV[#%Z1.5K:]\MZ)($MY;\8?1$8<%L* Q?SESGSPUNJ@=E\CK*7;$],B:YV=
M8+6<2M:31&SL?B96:UN="! ;=<.&V3(J>>2-V-C]3)R6[R(V$!N+Y8;O5"*V
M<;\L]2)(89W(!%P^U5T^ #.L0X#86"9:*QF4C]C8_4S 7,?J-HB-)>:Z@=M\
MQ,82N>%M-S08SPOQUCT[+_Q3_<)[A,&PV"W7)X4)R1+XFPA);\5Y(E!B.,I2
MEHHHQ'RR2;%][\$=1(J0U=1CS ,RJ.WYT+WKI(,?U[(-Y$0-C
M^@B[22)IJRU]9,CB6Q$6Y0\Z\RM8EA\2_7&^6M_^>"-'/6?2S?P[B*=3ON4'
M-S%GGP]8/^7Q(0ONV3AY\&'XZH.)ECG&=5_7Y2&,6"Y3R9PI855T*K W8*.$
M'Q8_'/5$,@K8^%"$2N*HAX[F/R!G]D!:J._IR]-)MPP]\7Q#D7]97S9:YG>/
M_1#%-=MS5EQ=_J39,I9>L[U6QU]^>?6 MCU8$U[;>=IK<; XV%T-UC'66V#U
MSE'_2BN++DL&9!1'=Z+'>^1F3*(1CT'-A;>$=4';@1[CSRE_AS[;W<\$;&_#
MPY- 1,?B:@0&M9TMA> @.NJ&#M.E=KN2OE-$Q^YGXCG4P2XYB(XE<006];PM
M11)@<.<,X3]E<7? $IX0Y;,"PSZ-I)$/IGTZ)BSL$?YW)D:RM+7Z380I"V^%
M]+BP).%8[UHU$6A['M:Y+X6V)O52U5BZ;GJ$:%+;,?>U
M=!VB?[_1[_C4Q8+MB/[]1+]I4\%NU%].\W^NT.=?V]
MM7PPD0AO77GKXN.DFN2@J[<=BA0^UUUC,?[S+.P&68\GY!?+(-T!BV]Y\OVW
MCG?T.N8!E^$F;ZB,*:?D?B"Z W+/8TY>.2V7W(@@$%&HE[,\& JCD)-^%)-T
M /\5<9*2OS,6ISRFZN#H]2O3-\A0/_8F/TM*@"JB#Q0"2A3/)KP;P<7)PU$?
M7I< $/P@T=)S),1EV'M/!BW%J3';X6?%6#E/V=;T K-UQY0
M9P0$4N=Z8CABW72F.RUY?0$L^TGJLG7-@5R.Z?;C\S9K
M?BG64GKA-6GIFFM:NM78-RTYGCM^ UKC[TSH).F#(D95JND(E'H,M$M !Q75
M;&(AZ]Z 9F?#"&;P/U7;1O[^*+R$DC2&@AWH//V&
MW(11-\AO3?0@W*CL$M RT;W,A)-S("+E0[!W7/_1AN19Z%@''#LR?DUW8\-'
MYV]7YD3S>B"/-#_"?8.$G(; W)>(0.H\Y-G"5?L\DNULQW\EOFQ*L)V#_5GF
M^,LLIJ4RNL90^#4+QL1JT\TB 99/?T_)> P:+$ ZOA 9GH>V
M)T"M),NUDL1="X.H%9]K-NXNVLFPVB\K99 0M2>$BX0H!1$-W$.MB982-80\
M6^X\'8*=W1YGK'0?G41)*KT_,;_C8<:? <8GV,H;Q"7LC$!KQ"6L/<^OGYCO
M;)I?:5/YM!W0!O-%P.T;X%:7T$+ (>!>&'"K:Z?4$7![@;8:0JUC/PUJB#/$
MV4;EY#QC':"]E#/Q94"(^[2GL/J2)YS%W8$Z7^_!9BV(5&6(71:3K=S:;MX*
MWJU"0&CL$AKMTHH,(S3J#0VKM#*0B(QZ(\.V46@@-!;.Q%W+X;;9P1'N"';'
MSRL6\(226Q[RF 4Z[K8W%*%(TEAU5L*M0:W7Z^H#&13D>PN,TOH'(##J#8S2
M.FXB,.H-#+.TIA*(C)HCHXZ;@N*6=2I(5"\/#&\M^]9U4+O&:[:8D_I2E2V*
M82QM*;M-V?+ZIS?D9#;C5'9(?'W+1)B\494N@BB1756B4!4Z3\<$Z"/NU-X5
M-K9"!J'R))U45ICIOL*F":_ AC 1/=5F$7X#IG6C#"8*=]UP,F)BFH&:I5G,
M*4D&,C^U& ]G<0BDGQ_2S*?RH0UY.HCDJV!LJ:K6KG-A@>CP<551HQL-^LF$Q#)\I$%=^ M^#[VG2>\K6)T^K[C)I[JUE
MRZ-6X2_6<[R,%^52#+O"O^ 8*]X5OM-IN6U?SGM14:!5U46LEMVV7[QFB6>T
M#/MI18%6UAIJN:;W\@56.JVVOU[%EX4FJKFT!\&&64 E[%3-M;* ]#XU?]W)
MQ>6GB\OCZ[.+<_*X6E93)W]Y>G)Q?G+VX4Q/_.(]48W'KR_(^<7Y@?KYXH_K
M#Q<7ORTDRM>WS9T7VYAMTD!RE[O)6N+@=YN\_Z\LP4P[\Z&]?B5WF'E5QN3-UYGQ,A40=U9Q2@F:VQAVRD2; 97I0[8S"'A.J_PX
MSFU/ZKM-Q,J.>_U5>+F*?LN+:@C)M>7&V^6)MN*"^_]:W3.MH.\=6]1;2
MBRV%<\#84P3UYL7H%R#NN87I=X7%Q:24PGU_:K;OC,P+U&O]P$_7&\)]!.@S>
M_G]02P$"% ,4    " "IHAI=B&GVI5L/  !89P  $0              @ $
M    ;G9D82TR,#(V,#@R-BYH=&U02P$"% ,4    " "IHAI='&UL4$L! A0#%     @ J:(:76F@H_H#!@  #C0  !4
M             ( !-QP  &YV9&$M,C R-C X,C9?<')E+GAM;%!+ 0(4 Q0
M   ( *FB&EUO[K%E
XML
17
nvda-20260826_htm.xml
IDEA: XBRL DOCUMENT
0001045810
2026-08-26
2026-08-26
0001045810
false
8-K
2026-08-26
NVIDIA CORP
DE
0-23985
94-3177549
2788 San Tomas Expressway
Santa Clara
CA
95051
408
486-2000
false
false
false
false
Common Stock, $0.001 par value per share
NVDA
NASDAQ
false
```
