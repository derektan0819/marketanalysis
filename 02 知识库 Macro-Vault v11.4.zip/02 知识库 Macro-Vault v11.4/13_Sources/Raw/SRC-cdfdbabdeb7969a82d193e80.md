---
title: "SRC-cdfdbabdeb7969a82d193e80 提取正文"
tags: [sources, raw-text]
created: 2026-10-19
updated: 2026-10-19
source: "https://www.sec.gov/Archives/edgar/data/1018724/000101872426000024/0001018724-26-000024.txt"
---
# Source text — untrusted evidence

```text
0001018724-26-000024.txt : 20260730
0001018724-26-000024.hdr.sgml : 20260730
20260730160623
ACCESSION NUMBER:		0001018724-26-000024
CONFORMED SUBMISSION TYPE:	8-K
PUBLIC DOCUMENT COUNT:		15
CONFORMED PERIOD OF REPORT:	20260730
ITEM INFORMATION:		Results of Operations and Financial Condition
ITEM INFORMATION:		Financial Statements and Exhibits
FILED AS OF DATE:		20260730
DATE AS OF CHANGE:		20260730
FILER:
COMPANY DATA:
COMPANY CONFORMED NAME:			AMAZON COM INC
CENTRAL INDEX KEY:			0001018724
STANDARD INDUSTRIAL CLASSIFICATION:	RETAIL-CATALOG & MAIL-ORDER HOUSES [5961]
ORGANIZATION NAME:           	07 Trade & Services
EIN:				911646860
STATE OF INCORPORATION:			DE
FISCAL YEAR END:			1231
FILING VALUES:
FORM TYPE:		8-K
SEC ACT:		1934 Act
SEC FILE NUMBER:	001-43202
FILM NUMBER:		261223294
BUSINESS ADDRESS:
STREET 1:		410 TERRY AVENUE NORTH
CITY:			SEATTLE
STATE:			WA
ZIP:			98109
BUSINESS PHONE:		2062661000
MAIL ADDRESS:
STREET 1:		410 TERRY AVENUE NORTH
CITY:			SEATTLE
STATE:			WA
ZIP:			98109
8-K
1
amzn-20260730.htm
8-K
amzn-20260730
00010187242026-07-302026-07-300001018724us-gaap:CommonStockMember2026-07-302026-07-300001018724amzn:FloatingRateNotesDue2028Member2026-07-302026-07-300001018724amzn:A2.800NotesDue2028Member2026-07-302026-07-300001018724amzn:A3.100NotesDue2030Member2026-07-302026-07-300001018724amzn:A3.350NotesDue2032Member2026-07-302026-07-300001018724amzn:A3.700NotesDue2035Member2026-07-302026-07-300001018724amzn:A4.050NotesDue2039Member2026-07-302026-07-300001018724amzn:A4.450NotesDue2045Member2026-07-302026-07-300001018724amzn:A4.850NotesDue2064Member2026-07-302026-07-30
Table of Contents
UNITED STATES
SECURITIES AND EXCHANGE COMMISSION
Washington, D.C. 20549
_________________________
FORM 8-K
_________________________
CURRENT REPORT
Pursuant to Section 13 or 15(d) of the
Securities Exchange Act of 1934
July 30, 2026
Date of Report
(Date of earliest event reported)
_________________________
AMAZON.COM, INC.
(Exact name of registrant as specified in its charter)
_________________________
Delaware
001-43202		91-1646860
(State or other jurisdiction of
incorporation)		(Commission File Number)		(IRS Employer Identification No.)
410 Terry Avenue North, Seattle, Washington 98109-5210
(Address of principal executive offices, including Zip Code)
(206) 266-1000
(Registrant’s telephone number, including area code)
_________________________
Check the appropriate box below if the Form 8-K filing is intended to simultaneously satisfy the filing obligation of the registrant under any of the following provisions:
☐	Written communications pursuant to Rule 425 under the Securities Act (17 CFR 230.425)
☐	Soliciting material pursuant to Rule 14a-12 under the Exchange Act (17 CFR 240.14a-12)
☐	Pre-commencement communications pursuant to Rule 14d-2(b) under the Exchange Act (17 CFR 240.14d-2(b))
☐	Pre-commencement communications pursuant to Rule 13e-4(c) under the Exchange Act (17 CFR 240.13e-4(c))
Securities registered pursuant to Section 12(b) of the Act:
Title of Each Class		Trading Symbol(s)		Name of Each Exchange on Which Registered
Common Stock, par value $.01 per share		AMZN		The Nasdaq Stock Market LLC
Floating Rate Notes due 2028		—		The Nasdaq Stock Market LLC
2.800% Notes due 2028		—		The Nasdaq Stock Market LLC
3.100% Notes due 2030		—		The Nasdaq Stock Market LLC
3.350% Notes due 2032		—		The Nasdaq Stock Market LLC
3.700% Notes due 2035		—		The Nasdaq Stock Market LLC
4.050% Notes due 2039		—		The Nasdaq Stock Market LLC
4.450% Notes due 2045		—		The Nasdaq Stock Market LLC
4.850% Notes due 2064		—		The Nasdaq Stock Market LLC
Indicate by check mark whether the registrant is an emerging growth company as defined in Rule 405 of the Securities Act of 1933 (§230.405 of this chapter) or Rule 12b-2 of the Securities Exchange Act of 1934 (§240.12b-2 of this chapter).
Emerging growth company
☐
If an emerging growth company, indicate by check mark if the registrant has elected not to use the extended transition period for complying with any new or revised financial accounting standards provided pursuant to Section 13(a) of the Exchange Act.	☐
Table of Contents
TABLE OF CONTENTS
ITEM 2.02.  RESULTS OF OPERATIONS AND FINANCIAL CONDITION.
3
ITEM 9.01.  FINANCIAL STATEMENTS AND EXHIBITS.
3
SIGNATURES
4
EXHIBIT 99.1
EXHIBIT 99.2
Table of Contents
ITEM 2.02.  RESULTS OF OPERATIONS AND FINANCIAL CONDITION.
On July 30, 2026, Amazon.com, Inc. announced its second quarter 2026 financial results. A copy of the press release containing the announcement is included as Exhibit 99.1 and additional information regarding the inclusion of non-GAAP financial measures in certain of Amazon.com, Inc.’s public disclosures, including its second quarter 2026 financial results announcement, is included as Exhibit 99.2. Both of these exhibits are incorporated herein by reference.
ITEM 9.01.  FINANCIAL STATEMENTS AND EXHIBITS.
(d) Exhibits.
Exhibit
Number	Description
99.1
Press Release dated July 30, 2026 announcing Amazon.com, Inc.’s Second Quarter 2026 Financial Results.
99.2
Information Regarding Non-GAAP Financial Measures.
104	The cover page from this Current Report on Form 8-K, formatted in Inline XBRL (included as Exhibit 101).
3
Table of Contents
SIGNATURES
Pursuant to the requirements of the Securities Exchange Act of 1934, the registrant has duly caused this report to be signed on its behalf by the undersigned hereunto duly authorized.
AMAZON.COM, INC. (REGISTRANT)
By:	/s/ Brian T. Olsavsky
Brian T. Olsavsky
Senior Vice President and
Chief Financial Officer
Dated: July 30, 2026
4
EX-99.1
2
amzn-20260630xex991.htm
EX-99.1
Document
Exhibit 99.1
AMAZON.COM ANNOUNCES SECOND QUARTER RESULTS
Net sales increased 20% year-over-year
Operating income was $27.5 billion, up 43% year-over-year
AWS net sales increased 37%—its fastest growth in 18 quarters—to a $169 billion annualized revenue run rate
SEATTLE—(BUSINESS WIRE) July 30, 2026—Amazon.com, Inc. (NASDAQ: AMZN) today announced financial results for its second quarter ended June 30, 2026.
•Net sales increased 20% to $200.6 billion in the second quarter, compared with $167.7 billion in second quarter 2025. Excluding the $0.1 billion favorable impact from year-over-year changes in foreign exchange rates throughout the quarter, net sales increased 20% compared with second quarter 2025.
•North America segment sales increased 16% year-over-year to $116.2 billion.
•International segment sales increased 15% year-over-year to $42.2 billion.
•AWS segment sales increased 37% year-over-year to $42.2 billion.
•Operating income increased to $27.5 billion in the second quarter, compared with $19.2 billion in second quarter 2025.
•North America segment operating income was $9.1 billion, compared with $7.5 billion in second quarter 2025.
•International segment operating income was $1.7 billion, compared with $1.5 billion in second quarter 2025.
•AWS segment operating income was $16.6 billion, compared with $10.2 billion in second quarter 2025.
•Net income increased to $62.6 billion in the second quarter, or $5.75 per diluted share, compared with $18.2 billion, or $1.68 per diluted share, in second quarter 2025.
•Second quarter 2026 net income includes non-operating pre-tax other income of $53.4 billion, primarily from our investments in Anthropic.
•Operating cash flow increased 33% to $161.4 billion for the trailing twelve months, compared with $121.1 billion for the trailing twelve months ended June 30, 2025.
•Free cash flow decreased to an outflow of $7.6 billion for the trailing twelve months, driven primarily by a year-over-year increase of $66.1 billion in purchases of property and equipment, net of proceeds from sales and incentives. This increase primarily reflects investments in artificial intelligence. This compares to free cash flow inflow of $18.2 billion for the trailing twelve months ended June 30, 2025.
“AWS is booming, growing 36.7% year-over-year in Q2—our fastest growth in 18 quarters—and our AI and Chips businesses each eclipsed run rates of more than $25 billion,” said Andy Jassy, President and CEO, Amazon. “In Stores, we again set record delivery speeds for Prime members in the first half of the year—over 40% more items delivered same-day or overnight, with Grocery and Everyday Essentials growing meaningfully faster than the rest of the business. And, Advertising had another strong quarter with 26% year-over-year growth. There’s a lot to be excited about, and we have much more coming for customers in the second half of the year and beyond.”
Some other highlights since the company’s last earnings announcement include that Amazon:
•Exceeded a $25 billion annual revenue run rate for AWS’s AI business, growing triple-digit percentages year-over-year.
•Exceeded a $25 billion annual revenue run rate for its chips business, growing triple-digit percentages year-over-year.
•Continued gaining momentum with Trainium, with the two leading AI labs in the world, Anthropic and OpenAI, making multi-year, multi-gigawatt commitments; an increasing number of AI start-ups adopting Trainium, including unicorns like NEURA Robotics and Odyssey; and commitments from other startups like TwelveLabs, Decart, Poolside, Karakuri, Inc., Metagenomi Therapeutics, Inc., NetoAI, and Splash Music, as well as larger companies like Uber and Pinterest.
•Released Graviton5 into general availability. Graviton delivers up to 30 to 40% better price-performance than comparable instances, and Graviton5 delivers up to 25% better compute performance than Graviton4. Graviton is used by 98% of the top 1,000 EC2 customers, revenue commitments have increased nearly 3x quarter-over-quarter, and Graviton5 is growing nearly 2x faster than Graviton4 did.
•Added 10+ fully managed foundation models to Amazon Bedrock, including OpenAI’s GPT-5.6, Anthropic’s Claude Opus 5, Google DeepMind’s Gemma 4, and SpaceXAI’s Grok 4.3. Amazon Bedrock provides the best selection of leading models, at superior performance, and with the governance and security controls that companies need, and it’s continuing to grow quickly—hundreds of thousands of customers now use Bedrock, more customers were added in the last six months than in the first two years after launch, and customers spent more in Q2 than all prior quarters combined.
•Previewed AWS Continuum, which discovers, prioritizes, validates, and remediates code vulnerabilities. It starts by ingesting the backlog of vulnerabilities a team already has, and then leverages the new frontier models to run comprehensive scans. Continuum uses agents and each company’s own business context to prioritize what matters, then validates vulnerabilities in a sandbox and recommends the fix.
•Added new capabilities to Bedrock AgentCore, which provides the building blocks that companies need to quickly and securely deploy and operate agents at scale. New capabilities include Payments (so agents can execute transactions autonomously), Web Search (to ground agents’ knowledge without having to leave AWS), and Harness, which further speeds up how fast customers can stitch together all the infrastructure they need for their agents.
•Made Amazon Quick—an intelligent AI work companion that helps manage, search, and automate digital workloads across email, calendar, local or cloud files, and custom workflows—even more capable, adding autonomous agents that customers set up in plain language to run continuously in the background and carry out multi-step tasks; a personalized activity feed that pulls email, messages, calendar, and tasks into one prioritized view; and 16 new integrations, including Adobe, Moody’s, and Snowflake. Quick manages across leading SaaS tools like Slack, Salesforce, Jira, Teams, and ServiceNow; enforces a company’s existing access controls; and takes actions like scheduling meetings, drafting and sending email, updating a CRM record, building a dashboard, and more.
•Made its spec-drive coding agent, Kiro, available on iOS so developers can now kick off a new project, monitor progress, steer an agent, and interact with Kiro sessions from their phone, desktop, command line, and the web. Kiro is up to 50% more cost-effective than alternatives and tripled in usage quarter-over-quarter.
•Added new capabilities to AWS DevOps Agent, an always-available software operations teammate that helps developers ship software safely and reliably, including Release Management to perform readiness reviews of code changes and autonomously test releases to spot potential issues before they go live.
•Launched serverless infrastructure for agentic AI that scales on demand, including:
•Lambda MicroVMs, a new flavor of the popular AWS Lambda serverless compute service that not only offers instant start times with the ability to scale all the way up or down depending on demand, but also now provides a stateful runtime with sessions that can last up to 8 hours—ideal for long-running agent loops, multi-step pipelines, or persistent database engines.
•Next-generation OpenSearch Serverless, which gives agents fast access to search across massive volumes of data, scales capacity up to 20x faster than the previous generation, and offers up to 60% cost savings versus provisioning for peak.
•Purpose-built log analytics engine for Amazon OpenSearch Service, designed to keep pace with the vast increase in logs being produced by agentic workloads. It delivers up to 4x better price performance compared to the existing general-purpose engine, up to 2x higher data ingestion on the same hardware, and up to 2x faster analytical queries, while retaining up to 3x more data at the same cost—enabling teams to retain and analyze more observability data without choosing between insight and budget.
•Announced an investment of $1 billion to create AWS Forward Deployed Engineering, a team of AI engineers embedded directly with customers to co-develop and deploy agentic AI solutions in days rather than months. Early customers include Allen Institute, Cox Automotive, the NBA, the NFL, Ricoh, and Southwest Airlines.
•Announced general availability of AWS Secret Cloud for Industry, giving defense contractors a faster, more secure path to classified innovation, with Northrop Grumman first to run classified workloads on the platform, and committed up to $1 billion in cloud credits to accelerate U.S. Intelligence Community cloud migration and modernization.
•Announced its global data centers are over 7x more water-efficient than the industry average. Amazon also reached 75% progress toward its goal to be water positive across global data center operations by 2030, and achieved water-positive status across its direct operations in India ahead of its 2027 target.
•Announced new AWS agreements with Warner Bros. Discovery, Vodafone, Siemens Energy, Ryanair, Pinterest, Snowflake, Moody’s, Danske Bank, WNBA, Pennymac, Fiserv, WPP Enterprise Solutions, Vonage, Recursive, fal, Chai Discovery, Odyssey, TwelveLabs, Reactor, OpenRouter, Dash0, New York State Office of Information Technology Services, State of Iowa, University of South Florida, and The University of Utah.
•Continued to expand its ultra-fast delivery service, Amazon Now, which offers delivery in 30 minutes or less on thousands of everyday essentials—adding 80 new cities and towns across the U.S. and several major cities in Egypt. Amazon Now is available in nine countries and over 250 cities and towns globally, and customers love it, with over 80% growth in gross sales and units sold quarter-over-quarter and over 60% more customers served quarter-over-quarter.
•Added millions of new products to its selection, including over 700,000 from notable brands like ADT Blu, Bobbi Brown, BROWN GIRL Jane, CR7 Underwear, LeGer, Mamonde, OLIVA COSMETICS, Rabanne, and Ted Baker.
•Brought together Rufus and Alexa+ into Alexa for Shopping, an agentic AI shopping assistant that offers personalized recommendations, product comparisons, price history, and the ability to automate shopping through features like Price Alerts and Auto-Buy. Worldwide customer adoption and engagement accelerated in Q2, with active users close to doubling and interactions up over 5x year-over-year.
•Launched Amazon Supply Chain Services so any business can move, store, and deliver everything from raw materials to finished products using the same supply chain that supports Amazon, with Procter & Gamble, 3M, Lands’ End, and American Eagle Outfitters among the first customers.
•Reached $60 billion in annualized gross sales for Amazon Business and continued to expand selection—adding nearly 30% more items compared to last year, including Same-Day Delivery of fresh groceries for businesses in 2,300+ U.S. cities and towns.
•Introduced the next-generation of Proteus, an autonomous robot that assists Amazon fulfillment center employees by moving goods up to 1,300 pounds, reducing heavy lifting and further increasing safety. Using AI, employees can now direct Proteus with plain, conversational language.
•Grew the number of new customers for Amazon Pharmacy by more than 2x in the first six months of the year, and same-day prescription deliveries nearly 5x. Also saved customers nearly $250 million so far this year in out-of-pocket costs, up more than 400% year-over-year, through manufacturer discounts applied automatically on an expanded selection of widely prescribed medications.
•Expanded Ads Agent—an AI-powered tool that simplifies planning, launching, and managing advertising campaigns and turns hours of setup and targeting into minutes—to 11 new countries so far this year. Advertisers using Ads Agent see 8% lower cost-per-impression and 6% lower cost-per-acquisition than those that don’t use it.
•Expanded Alexa+ to Germany, Austria, France, and Brazil, with hundreds of millions of customers now using new Alexa experiences, and that number growing every month. Alexa continues to drive meaningful momentum for the business, including in the U.S., where customers who use Alexa for Shopping spend an average of over 40% more per order than those who don’t, and customers who have tried Alexa+ are signing up for Prime at a nearly 25% higher rate.
•Drew 36 million viewers globally for the series premiere of Off Campus on Prime Video in its first 12 days, becoming Prime Video’s No. 3 top-viewed series debut ever.
•Delivered strong viewership for inaugural season of NBA on Prime Video, with a peak of 6.5 million U.S. viewers for Game 7 of the Eastern Conference Semifinals (outperforming Game 7 on broadcast in 2025). In Europe, viewership of the NBA more than doubled year-over-year on Prime Video, with the highest average viewership on record.
•Averaged 2.3 million viewers during the second season of NASCAR on Prime Video and attracted the youngest audience the last two years among NASCAR broadcasters since 2017.
•Completed four additional launches for Amazon Leo, its low Earth orbit satellite network, bringing the total constellation to nearly 400 satellites in orbit—enough to begin initial satellite internet service this year.
•Received approval from the National Highway Traffic Safety Administration (Part 555 Exemption) for Zoox to charge for rides—the first purpose-built robotaxi to receive this exemption—paving the way for Zoox to begin offering paid commercial service to customers.
•Supported relief efforts following earthquakes in Venezuela with its Amazon Disaster Relief program, donating and delivering more than 650,000 emergency supplies to more than a dozen nonprofits and establishing weekly humanitarian relief flights to Caracas in a first-of-its-kind collaboration with Airlink, the U.S. State Department, and World Food Programme, delivering approximately 120 tons of supplies.
Financial Guidance
The following forward-looking statements reflect Amazon.com’s expectations as of July 30, 2026, and are subject to substantial uncertainty. Our results are inherently unpredictable and may be materially affected by many factors, such as fluctuations in foreign exchange rates and energy prices, changes in global economic and geopolitical conditions, tariff and trade policies, resource and supply volatility, including for memory chips, and customer demand and spending (including the impact of recessionary fears), inflation, interest rates, regional labor market constraints, world events, the rate of growth of the internet, online commerce, cloud services, and new and emerging technologies, and the various factors detailed below.
Third Quarter 2026 Guidance
•Net sales are expected to be between $197.0 billion and $202.0 billion, or to grow between 9% and 12% compared with third quarter 2025. Excluding the impact of Prime Day in both 2025 and 2026, third quarter 2026 year-over-year growth would be nearly 400 basis points higher. This guidance anticipates an unfavorable impact of approximately 80 basis points from foreign exchange rates.
•Operating income is expected to be between $22.5 billion and $26.5 billion, compared with $17.4 billion in third quarter 2025.
•This guidance assumes, among other things, no impact from energy derivative contract remeasurements, and that no additional business acquisitions, restructurings, or legal settlements are concluded.
Conference Call Information
A conference call will be webcast live today at 2:00 p.m. PT/5:00 p.m. ET, and will be available for at least three months at amazon.com/ir. This call will contain forward-looking statements and other material information regarding the Company’s financial and operating results.
Forward-Looking Statements
These forward-looking statements are inherently difficult to predict. Actual results and outcomes could differ materially for a variety of reasons, including, in addition to the factors discussed above, the amount that Amazon.com invests in new business opportunities and the timing of those investments, the mix of products and services sold to customers, the mix of net sales derived from products as compared with services, the extent to which we owe income or other taxes, competition, management of growth, potential fluctuations in operating results, international growth and expansion, the outcomes of claims, litigation, government investigations, and other proceedings, fulfillment, sortation, delivery, and data center optimization, risks of inventory management, variability in demand, the degree to which the Company enters into, maintains, and develops commercial agreements, proposed and completed acquisitions and strategic transactions, payments risks, and risks of fulfillment throughput and productivity. Other risks and uncertainties include, among others, risks related to new products, services, and technologies, security incidents, system interruptions, government regulation and taxation, and fraud. In addition, global economic and geopolitical conditions and additional or unforeseen circumstances, developments, or events may give rise to or amplify many of these risks. More information about factors that potentially could affect Amazon.com’s financial results is included in Amazon.com’s filings with the Securities and Exchange Commission (“SEC”), including its most recent Annual Report on Form 10-K and subsequent filings.
Additional Information
Our investor relations website is amazon.com/ir and we encourage investors to use it as a way of easily finding information about us. We promptly make available on this website, free of charge, the reports that we file or furnish with the SEC, corporate governance information (including our Code of Business Conduct and Ethics), and select press releases, which may contain material information about us, and you may subscribe to be notified of new information posted to this site.
About Amazon
Amazon is guided by four principles: customer obsession rather than competitor focus, passion for invention, commitment to operational excellence, and long-term thinking. Amazon strives to be Earth’s Most Customer-Centric Company, Earth’s Best Employer, and Earth’s Safest Place to Work. Customer reviews, 1-Click shopping, personalized recommendations, Prime, Fulfillment by Amazon, AWS, Kindle Direct Publishing, Kindle, Career Choice, Fire tablets, Fire TV, Amazon Echo, Alexa, Just Walk Out technology, Amazon Studios, and The Climate Pledge are some of the things pioneered by Amazon. For more information, visit amazon.com/about and follow @AmazonNews.
AMAZON.COM, INC.
Consolidated Statements of Cash Flows
(in millions)
(unaudited)
Three Months Ended
June 30,		Six Months Ended
June 30,		Twelve Months Ended
June 30,
2025		2026		2025		2026		2025		2026
CASH, CASH EQUIVALENTS, AND RESTRICTED CASH, BEGINNING OF PERIOD	$	69,893 			$	104,692 			$	82,312 			$	90,106 			$	71,673 			$	61,453
OPERATING ACTIVITIES:
Net income	18,164 			62,647 			35,291 			92,902 			70,623 			135,281
Adjustments to reconcile net income to net cash from operating activities:
Depreciation and amortization of property and equipment and capitalized content costs, operating lease assets, and other	15,227 			19,988 			29,489 			38,933 			58,562 			75,200
Stock-based compensation	6,534 			6,038 			10,223 			10,070 			20,551 			19,314
Non-operating expense (income), net	(1,258)			(53,381)			(4,075)			(69,013)			(4,702)			(79,818)
Deferred income taxes	11 			17,691 			518 			30,489 			(2,407)			41,441
Changes in operating assets and liabilities:
Inventories	(4,054)			(1,818)			(5,276)			(196)			(5,851)			2,078
Accounts receivable, net and other	(1,125)			(8,204)			122 			(13,954)			(4,602)			(21,409)
Other assets	(2,971)			(4,717)			(6,373)			(8,528)			(15,100)			(17,787)
Accounts payable	7,058 			9,442 			(1,985)			705 			6,264 			13,921
Accrued expenses and other	(4,952)			(2,018)			(9,013)			(10,063)			(4,842)			(6,069)
Unearned revenue	(119)			(281)			609 			74 			2,641 			(749)
Net cash provided by (used in) operating activities	32,515 			45,387 			49,530 			71,419 			121,137 			161,403
INVESTING ACTIVITIES:
Purchases of property and equipment	(32,183)			(54,208)			(57,202)			(98,411)			(107,656)			(173,028)
Proceeds from property and equipment sales and incentives	815 			1,132 			1,579 			2,101 			4,703 			4,021
Acquisitions, net of cash acquired, non-marketable investments, and other, net	(1,700)			(24,359)			(1,652)			(39,767)			(4,809)			(41,956)
Sales and maturities of marketable securities	11,441 			24,196 			19,178 			41,882 			30,924 			67,090
Purchases of marketable securities	(17,797)			(26,006)			(31,130)			(49,262)			(46,731)			(72,902)
Net cash provided by (used in) investing activities	(39,424)			(79,245)			(69,227)			(143,457)			(123,569)			(216,775)
FINANCING ACTIVITIES:
Proceeds from short-term debt, and other	2,093 			9,368 			3,908 			15,386 			8,187 			20,798
Repayments of short-term debt, and other	(1,392)			(9,573)			(3,474)			(15,682)			(7,901)			(20,634)
Proceeds from long-term debt	— 			13,557 			746 			66,998 			746 			81,925
Repayments of long-term debt	(2,751)			(2,752)			(2,751)			(2,752)			(7,434)			(5,022)
Principal repayments of finance leases	(411)			(395)			(821)			(863)			(1,556)			(1,599)
Principal repayments of financing obligations	(78)			(59)			(194)			(174)			(694)			(308)
Net cash provided by (used in) financing activities	(2,539)			10,146 			(2,586)			62,913 			(8,652)			75,160
Foreign currency effect on cash, cash equivalents, and restricted cash	1,008 			(53)			1,424 			(54)			864 			(314)
Net increase (decrease) in cash, cash equivalents, and restricted cash	(8,440)			(23,765)			(20,859)			(9,179)			(10,220)			19,474
CASH, CASH EQUIVALENTS, AND RESTRICTED CASH, END OF PERIOD	$	61,453 			$	80,927 			$	61,453 			$	80,927 			$	61,453 			$	80,927
SUPPLEMENTAL CASH FLOW INFORMATION:
Cash paid for interest on debt, net of capitalized interest	$	523 			$	736 			$	759 			$	1,010 			$	1,668 			$	1,709
Cash paid for operating leases	3,758 			3,489 			7,320 			7,804 			13,485 			15,522
Cash paid for interest on finance leases	72 			85 			143 			187 			284 			339
Cash paid for interest on financing obligations	52 			50 			107 			126 			212 			215
Cash paid for income taxes, net of refunds	4,761 			2,655 			5,638 			3,978 			11,788 			6,635
Assets acquired under operating leases	4,621 			7,670 			8,942 			13,909 			16,702 			24,897
Property and equipment acquired under finance leases, net of remeasurements and modifications	937 			563 			991 			2,128 			1,622 			4,048
Increase (decrease) in property and equipment acquired but not yet paid	(1,600)			10,700 			1,508 			20,620 			5,376 			29,267
AMAZON.COM, INC.
Consolidated Statements of Operations
(in millions, except per share data)
(unaudited)
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Net product sales	$	68,246 			$	77,602 			$	132,216 			$	148,906
Net service sales	99,456 			123,004 			191,153 			233,219
Total net sales	167,702 			200,606 			323,369 			382,125
Operating expenses:
Cost of sales	80,809 			95,778 			157,785 			183,241
Fulfillment	25,976 			29,633 			50,569 			56,922
Technology and infrastructure	27,166 			33,158 			50,160 			62,725
Sales and marketing	11,416 			11,698 			21,179 			22,012
General and administrative	2,965 			2,788 			5,593 			5,375
Other operating expense (income), net	199 			90 			507 			537
Total operating expenses	148,531 			173,145 			285,793 			330,812
Operating income	19,171 			27,461 			37,576 			51,313
Interest income	1,085 			1,295 			2,151 			2,430
Interest expense	(516)			(1,314)			(1,057)			(2,114)
Other income (expense), net	1,117 			53,415 			3,866 			69,062
Total non-operating income	1,686 			53,396 			4,960 			69,378
Income before income taxes	20,857 			80,857 			42,536 			120,691
Provision for income taxes	(2,678)			(18,199)			(7,231)			(27,759)
Equity-method investment activity, net of tax	(15)			(11)			(14)			(30)
Net income	$	18,164 			$	62,647 			$	35,291 			$	92,902
Basic earnings per share	$	1.71 			$	5.82 			$	3.32 			$	8.64
Diluted earnings per share	$	1.68 			$	5.75 			$	3.27 			$	8.53
Weighted-average shares used in computation of earnings per share:
Basic	10,637 			10,769 			10,620 			10,756
Diluted	10,806 			10,903 			10,800 			10,889
AMAZON.COM, INC.
Consolidated Statements of Comprehensive Income
(in millions)
(unaudited)
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Net income	$	18,164 			$	62,647 			$	35,291 			$	92,902
Other comprehensive income (loss):
Foreign currency translation adjustments, net of tax of $(142), $(66), $(208), and $(79)	3,314 			(799)			4,849 			(1,563)
Unrealized gains (losses) on net investment hedging instruments, net of tax of $0, $(69), $0, and $(45)	— 			229 			— 			144
Available-for-sale debt securities:
Change in net unrealized gains (losses), net of tax of $(12), $(13,695), $(23), and $(14,035)	40 			41,988 			77 			42,814
Less: reclassification adjustment for net losses (gains) included in “Other income (expense), net,” net of tax of $5, $0, $814, and $1,142	(17)			— 			(2,471)			(3,337)
Net change	23 			41,988 			(2,394)			39,477
Other, net of tax of $(1), $1, $0, and $(1)	(3)			1 			(1)			(1)
Total other comprehensive income (loss)	3,334 			41,419 			2,454 			38,057
Comprehensive income	$	21,498 			$	104,066 			$	37,745 			$	130,959
AMAZON.COM, INC.
Segment Information
(in millions)
(unaudited)
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
North America
Net sales	$	100,068 			$	116,177 			$	192,955 			$	220,320
Operating expenses	92,551 			107,054 			179,597 			202,930
Operating income	$	7,517 			$	9,123 			$	13,358 			$	17,390
International
Net sales	$	36,761 			$	42,197 			$	70,274 			$	81,986
Operating expenses	35,267 			40,480 			67,763 			78,845
Operating income	$	1,494 			$	1,717 			$	2,511 			$	3,141
AWS
Net sales	$	30,873 			$	42,232 			$	60,140 			$	79,819
Operating expenses	20,713 			25,611 			38,433 			49,037
Operating income	$	10,160 			$	16,621 			$	21,707 			$	30,782
Consolidated
Net sales	$	167,702 			$	200,606 			$	323,369 			$	382,125
Operating expenses	148,531 			173,145 			285,793 			330,812
Operating income	19,171 			27,461 			37,576 			51,313
Total non-operating income	1,686 			53,396 			4,960 			69,378
Provision for income taxes	(2,678)			(18,199)			(7,231)			(27,759)
Equity-method investment activity, net of tax	(15)			(11)			(14)			(30)
Net income	$	18,164 			$	62,647 			$	35,291 			$	92,902
Segment Highlights:
Y/Y net sales growth:
North America	11 	%		16 	%		9 	%		14 	%
International	16 			15 			10 			17
AWS	17 			37 			17 			33
Consolidated	13 			20 			11 			18
Net sales mix:
North America	60 	%		58 	%		60 	%		58 	%
International	22 			21 			22 			21
AWS	18 			21 			18 			21
Consolidated	100 	%		100 	%		100 	%		100 	%
AMAZON.COM, INC.
Consolidated Balance Sheets
(in millions, except per share data)
December 31, 2025		June 30, 2026
(unaudited)
ASSETS
Current assets:
Cash and cash equivalents	$	86,810 			$	78,213
Marketable securities	36,219 			44,775
Inventories	38,325 			38,184
Accounts receivable, net and other	67,729 			88,092
Total current assets	229,083 			249,264
Property and equipment, net	357,025 			446,046
Operating leases	86,054 			92,743
Goodwill	23,273 			23,504
Other assets	122,607 			284,132
Total assets	$	818,042 			$	1,095,689
LIABILITIES AND STOCKHOLDERS’ EQUITY
Current liabilities:
Accounts payable	$	121,909 			$	147,440
Accrued expenses and other	75,520 			73,406
Unearned revenue	20,576 			20,428
Total current liabilities	218,005 			241,274
Long-term lease liabilities	87,339 			94,338
Long-term debt	65,648 			128,894
Other long-term liabilities	35,985 			79,563
Commitments and contingencies
Stockholders’ equity:
Preferred stock ($0.01 par value; 500 shares authorized; no shares issued or outstanding)	— 			—
Common stock ($0.01 par value; 100,000 shares authorized; 11,246 and 11,298 shares issued; 10,731 and 10,783 shares outstanding)	112 			113
Treasury stock, at cost	(7,837)			(7,837)
Additional paid-in capital	140,024 			149,619
Accumulated other comprehensive income (loss)	28,230 			66,287
Retained earnings	250,536 			343,438
Total stockholders’ equity	411,065 			551,620
Total liabilities and stockholders’ equity	$	818,042 			$	1,095,689
AMAZON.COM, INC.
Supplemental Financial Information and Business Metrics
(in millions, except per share data)
(unaudited)
Q1 2025	Q2 2025	Q3 2025	Q4 2025	Q1 2026	Q2 2026	Y/Y %
Change
Cash Flows and Shares
Operating cash flow -- trailing twelve months (TTM)	$	113,903 		$	121,137 		$	130,691 		$	139,514 		$	148,531 		$	161,403 		33 	%
Operating cash flow -- TTM Y/Y growth	15 	%	12 	%	16 	%	20 	%	30 	%	33 	%	N/A
Purchases of property and equipment, net of proceeds from sales and incentives -- TTM	$	87,978 		$	102,953 		$	115,903 		$	128,320 		$	147,299 		$	169,007 		64 	%
Free cash flow -- TTM (1)	$	25,925 		$	18,184 		$	14,788 		$	11,194 		$	1,232 		$	(7,604)		(142)	%
Common shares and stock-based awards outstanding	10,876 		10,952 		10,955 		10,953 		10,949 		11,027 		1 	%
Common shares outstanding	10,613 		10,660 		10,687 		10,731 		10,754 		10,783 		1 	%
Stock-based awards outstanding	263 		292 		268 		222 		195 		244 		(16)	%
Stock-based awards outstanding -- % of common shares outstanding	2.5 	%	2.7 	%	2.5 	%	2.1 	%	1.8 	%	2.3 	%	N/A
Results of Operations
Worldwide (WW) net sales	$	155,667 		$	167,702 		$	180,169 		$	213,386 		$	181,519 		$	200,606 		20 	%
WW net sales -- Y/Y growth, excluding F/X	10 	%	12 	%	12 	%	12 	%	15 	%	20 	%	N/A
WW net sales -- TTM	$	650,313 		$	670,038 		$	691,330 		$	716,924 		$	742,776 		$	775,680 		16 	%
WW net sales -- TTM Y/Y growth, excluding F/X	11 	%	11 	%	11 	%	12 	%	13 	%	15 	%	N/A
Operating income	$	18,405 		$	19,171 		$	17,422 		$	24,977 		$	23,852 		$	27,461 		43 	%
F/X impact -- favorable (unfavorable)	$	53 		$	153 		$	129 		$	23 		$	(33)		$	(105)		N/A
Operating income -- Y/Y growth (decline), excluding F/X	20 	%	30 	%	(1)	%	18 	%	30 	%	44 	%	N/A
Operating margin -- % of WW net sales	11.8 	%	11.4 	%	9.7 	%	11.7 	%	13.1 	%	13.7 	%	N/A
Operating income -- TTM	$	71,691 		$	76,190 		$	76,201 		$	79,975 		$	85,422 		$	93,712 		23 	%
Operating income -- TTM Y/Y growth, excluding F/X	51 	%	40 	%	25 	%	16 	%	19 	%	23 	%	N/A
Operating margin -- TTM % of WW net sales	11.0 	%	11.4 	%	11.0 	%	11.2 	%	11.5 	%	12.1 	%	N/A
Net income	$	17,127 		$	18,164 		$	21,187 		$	21,192 		$	30,255 		$	62,647 		245 	%
Net income per diluted share	$	1.59 		$	1.68 		$	1.95 		$	1.95 		$	2.78 		$	5.75 		242 	%
Net income -- TTM	$	65,944 		$	70,623 		$	76,482 		$	77,670 		$	90,798 		$	135,281 		92 	%
Net income per diluted share -- TTM	$	6.13 		$	6.55 		$	7.08 		$	7.17 		$	8.37 		$	12.44 		90 	%
______________________________
(1)Free cash flow is cash flow from operations reduced by “Purchases of property and equipment, net of proceeds from sales and incentives.”
AMAZON.COM, INC.
Supplemental Financial Information and Business Metrics
(in millions)
(unaudited)
Q1 2025	Q2 2025	Q3 2025	Q4 2025	Q1 2026	Q2 2026	Y/Y %
Change
Segments
North America Segment:
Net sales	$	92,887 		$	100,068 		$	106,267 		$	127,083 		$	104,143 		$	116,177 		16 	%
Net sales -- Y/Y growth, excluding F/X	8 	%	11 	%	11 	%	10 	%	12 	%	16 	%	N/A
Net sales -- TTM	$	394,043 		$	404,078 		$	414,808 		$	426,305 		$	437,561 		$	453,670 		12 	%
Operating income	$	5,841 		$	7,517 		$	4,789 		$	11,472 		$	8,267 		$	9,123 		21 	%
F/X impact -- unfavorable	$	(32)		$	(46)		$	(53)		$	(73)		$	(41)		$	(6)		N/A
Operating income -- Y/Y growth (decline), excluding F/X	18 	%	49 	%	(14)	%	25 	%	42 	%	21 	%	N/A
Operating margin -- % of North America net sales	6.3 	%	7.5 	%	4.5 	%	9.0 	%	7.9 	%	7.9 	%	N/A
Operating income -- TTM	$	25,825 		$	28,277 		$	27,403 		$	29,619 		$	32,045 		$	33,651 		19 	%
Operating margin -- TTM % of North America net sales	6.6 	%	7.0 	%	6.6 	%	6.9 	%	7.3 	%	7.4 	%	N/A
International Segment:
Net sales	$	33,513 		$	36,761 		$	40,896 		$	50,724 		$	39,789 		$	42,197 		15 	%
Net sales -- Y/Y growth, excluding F/X	8 	%	11 	%	10 	%	11 	%	11 	%	15 	%	N/A
Net sales -- TTM	$	144,484 		$	149,582 		$	154,590 		$	161,894 		$	168,170 		$	173,606 		16 	%
Operating income	$	1,017 		$	1,494 		$	1,199 		$	1,040 		$	1,424 		$	1,717 		15 	%
F/X impact -- favorable (unfavorable)	$	(56)		$	338 		$	302 		$	319 		$	347 		$	(43)		N/A
Operating income -- Y/Y growth (decline), excluding F/X	19 	%	324 	%	(31)	%	(45)	%	6 	%	18 	%	N/A
Operating margin -- % of International net sales	3.0 	%	4.1 	%	2.9 	%	2.1 	%	3.6 	%	4.1 	%	N/A
Operating income -- TTM	$	3,906 		$	5,127 		$	5,025 		$	4,750 		$	5,157 		$	5,380 		5 	%
Operating margin -- TTM % of International net sales	2.7 	%	3.4 	%	3.2 	%	2.9 	%	3.1 	%	3.1 	%	N/A
AWS Segment:
Net sales	$	29,267 		$	30,873 		$	33,006 		$	35,579 		$	37,587 		$	42,232 		37 	%
Net sales -- Y/Y growth, excluding F/X	17 	%	17 	%	20 	%	24 	%	28 	%	37 	%	N/A
Net sales -- TTM	$	111,786 		$	116,378 		$	121,932 		$	128,725 		$	137,045 		$	148,404 		28 	%
Operating income	$	11,547 		$	10,160 		$	11,434 		$	12,465 		$	14,161 		$	16,621 		64 	%
F/X impact -- favorable (unfavorable)	$	141 		$	(139)		$	(120)		$	(223)		$	(339)		$	(56)		N/A
Operating income -- Y/Y growth, excluding F/X	21 	%	10 	%	11 	%	19 	%	26 	%	64 	%	N/A
Operating margin -- % of AWS net sales	39.5 	%	32.9 	%	34.6 	%	35.0 	%	37.7 	%	39.4 	%	N/A
Operating income -- TTM	$	41,960 		$	42,786 		$	43,773 		$	45,606 		$	48,220 		$	54,681 		28 	%
Operating margin -- TTM % of AWS net sales	37.5 	%	36.8 	%	35.9 	%	35.4 	%	35.2 	%	36.8 	%	N/A
AMAZON.COM, INC.
Supplemental Financial Information and Business Metrics
(in millions, except employee data)
(unaudited)
Q1 2025	Q2 2025	Q3 2025	Q4 2025	Q1 2026	Q2 2026	Y/Y %
Change
Net Sales
Online stores (1)	$	57,407 		$	61,485 		$	67,407 		$	82,988 		$	64,254 		$	70,432 		15 	%
Online stores -- Y/Y growth, excluding F/X	6 	%	10 	%	8 	%	8 	%	9 	%	15 	%	N/A
Physical stores (2)	$	5,533 		$	5,595 		$	5,578 		$	5,855 		$	5,785 		$	5,794 		4 	%
Physical stores -- Y/Y growth, excluding F/X	6 	%	7 	%	7 	%	5 	%	4 	%	4 	%	N/A
Third-party seller services (3)	$	36,512 		$	40,348 		$	42,486 		$	52,816 		$	41,578 		$	46,780 		16 	%
Third-party seller services -- Y/Y growth, excluding F/X	7 	%	10 	%	11 	%	10 	%	12 	%	16 	%	N/A
Advertising services (4)	$	13,921 		$	15,694 		$	17,703 		$	21,317 		$	17,243 		$	19,809 		26 	%
Advertising services -- Y/Y growth, excluding F/X	19 	%	22 	%	22 	%	22 	%	22 	%	26 	%	N/A
Subscription services (5)	$	11,715 		$	12,208 		$	12,574 		$	13,122 		$	13,427 		$	13,730 		12 	%
Subscription services -- Y/Y growth, excluding F/X	11 	%	11 	%	10 	%	12 	%	12 	%	12 	%	N/A
AWS	$	29,267 		$	30,873 		$	33,006 		$	35,579 		$	37,587 		$	42,232 		37 	%
AWS -- Y/Y growth, excluding F/X	17 	%	17 	%	20 	%	24 	%	28 	%	37 	%	N/A
Other (6)	$	1,312 		$	1,499 		$	1,415 		$	1,709 		$	1,645 		$	1,829 		22 	%
Other -- Y/Y growth, excluding F/X	4 	%	18 	%	7 	%	7 	%	25 	%	23 	%	N/A
Stock-based Compensation Expense
Cost of sales	$	148 		$	250 		$	197 		$	182 		$	171 		$	208 		(17)	%
Fulfillment	$	497 		$	880 		$	685 		$	641 		$	601 		$	764 		(13)	%
Technology and infrastructure	$	2,060 		$	3,655 		$	2,697 		$	2,459 		$	2,286 		$	3,701 		1 	%
Sales and marketing	$	653 		$	1,207 		$	832 		$	753 		$	663 		$	845 		(30)	%
General and administrative	$	331 		$	542 		$	436 		$	362 		$	311 		$	520 		(4)	%
Total stock-based compensation expense	$	3,689 		$	6,534 		$	4,847 		$	4,397 		$	4,032 		$	6,038 		(8)	%
Other
WW shipping costs	$	22,495 		$	23,370 		$	25,384 		$	31,492 		$	25,709 		$	27,873 		19 	%
WW shipping costs -- Y/Y growth	3 	%	6 	%	8 	%	10 	%	14 	%	19 	%	N/A
WW paid units -- Y/Y growth (7)	8 	%	12 	%	11 	%	12 	%	15 	%	17 	%	N/A
WW seller unit mix -- % of WW paid units (7)	61 	%	62 	%	62 	%	61 	%	60 	%	61 	%	N/A
Employees (full-time and part-time; excludes contractors & temporary personnel)	1,560,000 		1,546,000 		1,578,000 		1,576,000 		1,575,000 		1,595,000 		3 	%
Employees (full-time and part-time; excludes contractors & temporary personnel) -- Y/Y growth	3 	%	1 	%	2 	%	1 	%	1 	%	3 	%	N/A
________________________
(1)Includes product sales and digital media content where we record revenue gross. We leverage our retail infrastructure to offer a wide selection of consumable and durable goods that includes media products available in both a physical and digital format, such as books, videos, games, music, and software. These product sales include digital products sold on a transactional basis. Digital media content subscriptions that provide unlimited viewing or usage rights are included in “Subscription services.”
(2)Includes product sales where our customers physically select items in a store. Sales to customers who order goods online for delivery or pickup at our physical stores are included in “Online stores.”
(3)Includes commissions and any related fulfillment and shipping fees, and other third-party seller services.
(4)Includes sales of advertising services to sellers, vendors, publishers, authors, and others, through programs such as sponsored ads, display, and video advertising.
(5)Includes annual and monthly fees associated with Amazon Prime memberships, as well as digital video, audiobook, digital music, e-book, and other non-AWS subscription services.
(6)Includes sales related to various other offerings (such as shipping services, healthcare services, and certain licensing and distribution of video content) and our co-branded credit card agreements.
(7)Excludes the impact of Whole Foods Market.
Amazon.com, Inc.
Certain Definitions
Customer Accounts
•References to customers mean customer accounts established when a customer places an order through one of our stores. Customer accounts exclude certain customers, including customers associated with certain of our acquisitions, Amazon Payments customers, AWS customers, and the customers of select companies with whom we have a technology alliance or marketing and promotional relationship. Customers are considered active when they have placed an order during the preceding twelve-month period.
Seller Accounts
•References to sellers means seller accounts, which are established when a seller receives an order from a customer account. Sellers are considered active when they have received an order from a customer during the preceding twelve-month period.
AWS Customers
•References to AWS customers mean unique AWS customer accounts, which are unique customer account IDs that are eligible to use AWS services. This includes AWS accounts in the AWS free tier. Multiple users accessing AWS services via one account ID are counted as a single account. Customers are considered active when they have had AWS usage activity during the preceding one-month period.
Units
•References to units mean physical and digital units sold (net of returns and cancellations) by us and sellers in our stores as well as Amazon-owned items sold in other stores. Units sold are paid units and do not include units associated with AWS, certain acquisitions, certain subscriptions, rental businesses, or advertising businesses, or Amazon gift cards.
Contacts:
Amazon Investor Relations	 	Amazon Public Relations
amazon-ir@amazon.com	 	amazon-pr@amazon.com
amazon.com/ir	 	amazon.com/pr
EX-99.2
3
amzn-20260630xex992.htm
EX-99.2
Document
Exhibit 99.2
Non-GAAP Financial Measures
Regulation G, Conditions for Use of Non-GAAP Financial Measures, and other SEC regulations define and prescribe the conditions for use of certain non-GAAP financial information. Free cash flow and the effect of foreign exchange rates on our consolidated statements of operations meet the definition of non-GAAP financial measures.
Our financial focus is on long-term, sustainable growth in free cash flow. We provide a free cash flow measure because we believe it provides additional perspective on the impact of acquiring property and equipment with cash.
Free cash flow is cash flow from operations reduced by “Purchases of property and equipment, net of proceeds from sales and incentives.”
Free cash flow has limitations as it omits certain components of the overall cash flow statement and does not represent the residual cash flow available for discretionary expenditures. For example, free cash flow does not incorporate the portion of payments representing principal reductions of debt or cash payments for business acquisitions. Additionally, our mix of property and equipment acquisitions with cash or other financing options may change over time. Therefore, we believe it is important to view free cash flow only as a complement to our entire consolidated statements of cash flows.
For a quantitative reconciliation of free cash flow to the most directly comparable amounts reported in accordance with GAAP, see “Supplemental Financial Information and Business Metrics” in Exhibit 99.1 to this Current Report on Form 8-K.
The effect on our consolidated statements of operations from changes in foreign exchange rates versus the U.S. Dollar is also a non-GAAP financial measure. Information regarding the effect of foreign exchange rates, versus the U.S. Dollar, on our consolidated statements of operations is provided to show reported period operating results had the foreign exchange rates remained the same as those in effect in the comparable prior year period. We include various measures on both an as-reported basis and a basis showing the effect of changes in foreign exchange rates versus the U.S. Dollar in “Supplemental Financial Information and Business Metrics” in Exhibit 99.1 to this Current Report on Form 8-K.
EX-101.SCH
4
amzn-20260730.xsd
XBRL TAXONOMY EXTENSION SCHEMA DOCUMENT
0000001 - Document - Cover
link:presentationLink
link:calculationLink
link:definitionLink
EX-101.DEF
5
amzn-20260730_def.xml
XBRL TAXONOMY EXTENSION DEFINITION LINKBASE DOCUMENT
EX-101.LAB
6
amzn-20260730_lab.xml
XBRL TAXONOMY EXTENSION LABEL LINKBASE DOCUMENT
Soliciting Material
Soliciting Material
Written Communications
Written Communications
Local Phone Number
Local Phone Number
Class of Stock [Domain]
Class of Stock [Domain]
Amendment Flag
Amendment Flag
No Trading Symbol Flag
No Trading Symbol Flag
2.800% Notes due 2028
2.800% Notes due 2028 [Member]
2.800% Notes due 2028
Entity Emerging Growth Company
Entity Emerging Growth Company
Entity File Number
Entity File Number
Security Exchange Name
Security Exchange Name
3.350% Notes due 2032
3.350% Notes due 2032 [Member]
3.350% Notes due 2032
4.850% Notes due 2064
4.850% Notes due 2064 [Member]
4.850% Notes due 2064
4.450% Notes due 2045
4.450% Notes due 2045 [Member]
4.450% Notes due 2045
Entity Address, State or Province
Entity Address, State or Province
Entity Address, Address Line One
Entity Address, Address Line One
City Area Code
City Area Code
Class of Stock [Line Items]
Class of Stock [Line Items]
Cover [Abstract]
Document Period End Date
Document Period End Date
Pre-commencement Tender Offer
Pre-commencement Tender Offer
Class of Stock [Axis]
Class of Stock [Axis]
Entity Central Index Key
Entity Central Index Key
4.050% Notes due 2039
4.050% Notes due 2039 [Member]
4.050% Notes due 2039
Pre-commencement Issuer Tender Offer
Pre-commencement Issuer Tender Offer
Entity Tax Identification Number
Entity Tax Identification Number
3.100% Notes due 2030
3.100% Notes due 2030 [Member]
3.100% Notes due 2030
3.700% Notes due 2035
3.700% Notes due 2035 [Member]
3.700% Notes due 2035
Entity Registrant Name
Entity Registrant Name
Trading Symbol
Trading Symbol
Stock, Class of Stock [Table]
Stock, Class of Stock [Table]
Common Stock, par value $.01 per share
Common Stock [Member]
Entity Incorporation, State or Country Code
Entity Incorporation, State or Country Code
Floating Rate Notes due 2028
Floating Rate Notes due 2028 [Member]
Floating Rate Notes due 2028
Title of 12(b) Security
Title of 12(b) Security
Entity Address, Postal Zip Code
Entity Address, Postal Zip Code
Entity Address, City or Town
Entity Address, City or Town
Document Type
Document Type
EX-101.PRE
7
amzn-20260730_pre.xml
XBRL TAXONOMY EXTENSION PRESENTATION LINKBASE DOCUMENT
GRAPHIC
8
amazon_logo.jpg
begin 644 amazon_logo.jpg
M_]C_X  02D9)1@ ! 0$ 8 !@  #_X@'824-#7U!23T9)3$4  0$   '(
M  0P  !M;G1R4D="(%A96B 'X  !  $       !A8W-P
M                     0  ]M8  0    #3+0
M                                              ED97-C    \
M "1R6%E:   !%    !1G6%E:   !*    !1B6%E:   !/    !1W='!T   !
M4    !1R5%)#   !9    "AG5%)#   !9    "AB5%)#   !9    "AC<')T
M   !C    #QM;'5C          $    ,96Y54P    @    < ', 4@!' $)8
M65H@        ;Z(  #CU   #D%A96B        !BF0  MX4  !C:6%E:(
M     "2@   /A   ML]865H@        ]M8  0    #3+7!A^/2^=3M1NUT[!Z?X&FVI\*:LJ]%V>/;Q-
M$)Q:JGR1FNF$L;KL[<6W]+Y_=+7=/Q.//W?*HM\?3*#;>';[[5&\Z[DY'4&-
M,M5\\6\"S[C-/^]3,*/[BZF]3=VW)N;DZA[ASZJIYGW34+LQ/TRG%B?.4)NP
MGNW-VD^ANT9KIUSJ5H=JJCSIMY=%R?HIF5(]V>DH[+>VN_1C[PN:G=M^=&/C
M7?K[O"$6[8MWZ_=F*UZ[-4;>Z339C^+5E7Z:O[M4(Z!.+5,
M.=Y4O:UWTM': U**J-+VUM_ IGRF+5R:H^?W1X+5_22]K#4JJIQ=VXF#$SX1
M:MUQQ_S2MB'8HICRJ^N5153W:J8N4\3'Z*FXERQZ.:R]3E=4^I.;-,YF]M3O=S\'O5T^'ZG5
M7MT[DR;LW\C6\FYN57KU<2[&SN?<>-=IOV-9R;=RCQIJB8YAU@#U.)U3ZE8$U5
M86]]3L35^%-%=/C^IWVG]I#KYI[%,W*>(C]%3@/,?,]7H_I*.U?IE43E[IPL^(GRNVJYY_YH6OCG)3
M/D[S3ZKWM"]+9U[T[NT:MM7;^?1'G,6JXKGYYN*@:%Z8O4K=5-.Y.DMVNG^-
M7BY%%,1\TS,HX1R;=,^3L5U0EIT#TOG0_/FW9UK:>MZ=W;335H7430K_ 'O*)SK=,_1,O9X6JZ7J5/?T[4L7*I]MF]37'ZI8
MU6/%S"J[^GY%[#J\^]CW)MS],/<;7ZY]:-E543MGJ?N'$BWY4?=]V:?GCO(3
M8])2[UD3B$+9?I)^U/LV::F/Z4\RN!V%Z87+M4V\?J-
MTTF9\/=,C"OS5Q\5$4?XH39JA*+D)/!:AL+TF'9?WI39LY>Z,C1,N[/$VM0L
MQ9BGYZJEQ.U>I>P-\6:+^TMWZ5JU%<HM6K<35575/$1
M'MF5 NK/;H[./2*+F/K>^\;/SJ(GC$TVJG(N=Z/XLQ%7,2[$3.SDS$+@7SO7
M[.-;F]D7J+5NGSJKJBF(^>47/5/TOFXLR;N%TCV';QJ8F8HS-0KYF8]ON=5/
MA]*U'J'VQ^TEU.KNQN#J3G8F/>F>5=F[5S\C_GE9H)Q;ICR0FNJ5?M:[>W:PUZBNSE]3;]BW5/X./$T\?3R\#JG:"Z
MX:W757JG5#6[_>\9IFY3Q_=4_$N6(\G-9=SF[SW;J,TSG[AS,B:>>[WZH\/U
M.HN7*[MRJ[=KFJNN>:JI\YEM'7  '+Q=5U/!H]RPLZ[9HY[W%,^'/M=[@]4N
MI.F515IV]M3QIB.(FW73'^#RX:"J^B=K#M'[>F*M-ZL:Q/=GF/=*Z9^J'O\
M1/2-=K+2+M%>1O:SJ%NC^)D453S]$PMI$>6)\G=9A?3MGTN76O3>[;W)LS1=
M2MQQS59HJHKGYYKX5=VCZ8G8UZ(HWOTTU; JGB)KL7J*Z>?7/$1,HN1&;5,^
M245U0G!V)Z1?LP[WBU:_RT_:9Q,F
MNU$3_NS"$V(\I2B[/FR4::J:HBJF8F)\IAJ@CZ>=O;M0=-Z[48>^IUG&M_\
MT-3HF_-4?TZYGCZ%UW2WTOV)53:PNKNP[V/5S$5YFG3-V/AGN13''TJYLU0G
M%R)27"BO2OMB=GSK!113M/J#@4Y5?$1B9=VBS>F9]443,RK11714PKF)C=.)U;@'                                         !
MT^Y=W[7V;@5ZINK7<+2L2B)FJ]E7HMTQ\\@[@6?=5?2?=G78'NV%M[4#;[]J9CVW*9GCZ%H/4[TL76W<]V_B]/- T[;F%B_5]%',H.]\=H+K?U(N7*MW]3-;R:+D^^LVLJY:M?-3%7$*=UV+
M=VY-[(YO79\[ER>]5/QS*R+'K*,W?1,'O3TLO9\V[=N8^@:?JVO5Q$]RJQ1-
MNF9]7X=*B6Y_3#[HOU7*=G=++>/3_$KS[L7.?AXIJA'93333'%-,1\35.+-,
M(3UZJN=,R=(TB*N>/N>U7''TURIQKG;>[5&XZ)MZGU4SJ*9C
MCBSX)Q13'DYS2]IJ?6OJ_K7>_=?J/K.7WO.+ERF?\ I>>R]S;BSJJZ
M\W6]AUH
M#V6G=9^K>CS$Z5U$UC$[OE[GU/H=5%6H:SINK13YQD6JYY^/BJ%6=M>F#Z@XL44[MZ9X69$?
MAU8-7NQ^VKV;M_TVXT3J3I]N[5S8F)]GOXA G,1/A,,(39I\DN\EDHZ5N3;VNTQ7HNNZ?GQ,V5[OCV
M-UWM:R[/A%K3K,7HJGXZ:G8IF=G)F(75B,S?/IAK=5NY8Z>],[M=7\3(S;TT
M?31-$_6H%O+TG/:CW;%5K3]2TO0;,\Q$6,6FNKC^E'"R+-4HSZ9N98QZ/Y5VY%$?3+R^O=7NE^V;,W]:W[H6-3'GWL^U,_1WD"FZ.T9UYWG-
M7^4/577[U%?G;MYMVBCYJ8JX4^S,C/U*J:M5U/,SIJ\9^Z;]5SGZ4XL>LHS=
M]B=?=';T[+VU**ON[J3BWKE/,11CVKEWF?CIB84AW%Z6SL]Z/$3:HFB)_2I0_4XN-1^!8MT_%3#ZQ3%/A$1"46:4>\E)CN#TQNG=ZJG;'274
M+L?Q:[^3;X^>/!X#6O2]=8LJ*J=#V#HF)$\\3D4U5S'Z-<+#1+NJ?1SGJ79:
MSZ3[M1:I,_<>?I6G\_S5JOP_YI>/U#M_]K;4J:[=WJ==LT5^=-FF8^M;Z)BG
M\'OSY.,.N    .98UG5L6U%C&U"];MT^5-,^$.TQ>H.^<*FBC#W5GV8M>-$4
MU1[WXO!Y\![K#Z[]:M.FJ<#J=KECO?A=RY3X_P#*]3I7;&[3>BSS@]5]4GR_
M?*HGR^91PHJGGZ)>XT/TJG:4TKN_=V
M'H6H\>?NMFYX_P#/"SD/PON2ON<_I5RJ
M-MWTQ73NY1$;IZ:ZUAU>N;=ZBJ(^B)19B,VJ9=BNI-!M/THG9CW%W(U'6X9ENN9^B
M7;1,3',3S#&[T+>^^MKWHO[=WMKFGUT^7N.=EVZNZ5>HHWWL?3=7LT^%56-7
M%FJ?FBB5Q6P?2S=!=P546-XZ=JVW;M4>-55B;EJ)_ISPA-JJ/)**XE?(*5[!
M[4/0CJ79HN;4ZD:-D7+GX-BO*HIN_H\\JHV;UK(MTWK%RFY15'--5,\Q,*YC
M1/75O
M
M
M             !I,Q3$U53Q$><@U%.-_=HCHOTRL7;V\NH6C8-=J)F;%651[
MK/Q4S/,K7NHOI9^AFW9KQ]CZ5JFY+],3$5>Y3:M3/]..\E%-56T.35$+Z'SO
MY%C&MS=R;]NU1'G575%,1\\H@=^>EFZ[[@KO6-E;=TK0<:YS%%=V*;]='TTP
MMZWEVK^T9ORJO_*#JIJU-NYSWK6'>KL6^/9W::N%D6:IW0FY"=;Q1X46:*?BCA.+$>XG%JF$9KJE=YN'TI/:;UGO1I]6C:7SY>X6:_#_ )Y>"U3M\]K/6*9MY'4Z
M]9HG^+9B8X^GE0 2Y*8\G.:?54G5>TIU^UNJJK4NJNMUQ7'%5--RGB?^5YS,
MZF]1-1JFK/WEJ6155'=F:ZZ?&/9Y/,CND..7DZOJF;;]QR\^[=HYY[M4^'+B
M ZX  Y&+J.?@Q53A9=RS%?X443YNXP^H6^M.[D8&Z\_']S_ [E4>]^+P>? 5
M"TSM#]==&JIJTWJEK=J*>>*?=*>/'_=>UTKMU]J[1:(MX75/+KICB.+OCSQ\
M2A YRQ/D[K,+K]!])UVI-'[OW=JFF:GW?/W:U7//_-"IF@>E_P"J6+313N3I
MSI>9Q^%.)S;F?TJY6"",VZ9\G>:KU2E[8],3T]O413N_IMK.#7/A,VKU%<1]
M$2K/LSTEO9>W9[G;RMUWM(NW/*C)Q[D_3,4\(36VJS:K_#MTS\<(S9I2BY+(
M?VMU_P"C>\Z::MO]1=#R)KCF*:LRW15]%4Q+W.'J.GZC;]UT_.Q\JC^59NTU
MQ],2QJ,>FO"N>ZZ??O8=S^7CUS;J^F%0MG]H7KGL*:?\ENJ.O8]%$\Q:N9ER
MY;GXZ9JXE";'I*47?5D.B%_8GI2>TIM+W'&W!&E;BQ:)COS78IM7)C^EQ,KF
MNGOI>NF>JU6<;J)LW4M#KJXIKO8T3D41\,SQ3PKFU5"47*92#"C73CM?]GGJ
ME11_DOU)TKW:YX4X^3?HM79GV13,\JP8^38R[-.1C7J+MNN.::Z9YB80F)C=
M/75]0'
M                                                       &VY.C]-=O='4#!NY=$3SB85RF]>BJ/5-,3S#
ML1,[.3.FZN#2JJFBF:JZHIB/.9GB(1F=4O2_4S3=P^D>P;ERJ.8HS-1JFW\7
M^CFF?K6I=0^W=VGNI-RY^Z&_KFDX]SF/<-+IG'XCV=ZB8Y619JG=";D1LFUW
M-U7Z;;/QZLG<>]]%PJ:/PHN9MN*H_P!WGE0;?WI(.S%L>*[=K=M>KY%'/-K#
ML7)_YN[,(4-8U?7-QY%>5N/7=0U2[F*V=;B:-C],M5S*O&(N9%^BFGX^)XE2'='I;NN.J]ZWMW:.B
MZ9;GRJN4557(^>*^%C8G%JF/)&:ZI7(ZUZ13M::QESNIG4/4^9U+>6I9
M/>CNS[I73XQ[/)T>5J.?G133F9=R]%/X,53Y.,):.  -]J[\]VZ?-4X&X\TSKYULT:J*M+ZG:WC\<>%-R
MGCP_W7NM%[=/:MT"B+>!U2R[E$?Q;_C$_1PH2.33$^3NLPN[VUZ4?M.:%-'[
MI7-'U>*?/W>U7//T5PJOMOTQ&Y[%=%.[NE=O(I\JZ\&[31\_%54H[1&;=,^3
MO/5"7G9_I;.@6O7;>-KVCZOHE<\175>IFY3$_P"[2N V7VO^SMOZ;=.W^I>E
MS7=X[M&17[A//L_TG" :8BJ.)B)?.,:S37%VBW%%RGQBNF.*H^*4)LT^247)
M9*FG:YHNL4=_2=8PLVGSYQ\BBY'_ "S+G,='9W63JYT_NTW=H=1M>P(IGGN1
MFW)HGXZ>]QPN2Z<^E*[1FS?<K?3?J7B49FQ
M]XZ7K%%=,5<8N13753S[8B?"5FEV[INA9&3NK4:.:8M8,3%OO?UG=FF8^=V*9JV
M \]NGJ#LG96%5J.Z]T:?IF/1^%7?O1''S1XHA^K/I1NT%OJY=Q-D4X
MNTL"J9BBJW$U9'=^&NFKCGYEJN\-\[VZ@YM>H[XW9J>MW[D\U59=Z:UU-F9W
M5SEMZN[CIN8
MO3[9VG[?LSS%.1?JJJO<>J>.:J5B=%NBW3%%%,1$>40U6Q:IA":YE4K?G:5Z
M]]2K]R[NSJ;JUVW=_"LV+D6:/^2(4VR*[V77-S,RLC)KGSJO7JKDS^E,M!.(
MB-D==6E-%%$<44Q3'P1PU!UP                             !MJM6ZY
MYJHIF?;QXNRT?@O5FU:_R.ZBZ7D9%V/]6KKFBY3/LG
MO1$*LVKUF_1%RQ=HN4SY5451,?J8TECW3%R:,W#O7,?(MSS3=MU=VJ)5XZ5=
MN/M)]([MBUI.^LC6--LS'_R.J557:./9'$QPJJL>BR+GJGF$>_1OTM^P-K_V:*?.J?@@W
M'JJJJ:*9JKJBF(\YF>(AXG=_6SI/L.KN;NW[I.FU<<]V[>YG_EY11=I/TEW5
M7JKGY6A]*=KV77G:[J&3J.1F>VSV7XF8_SO:+X3QYW/V6GW[/9?_.]HOTW
M/V4!WW)C?S-)]R8W\S2EW$>J'>2GQ^_9[+_YWM%^FY^R??L]E_\ .]HOTW/V
M4!WW)C?S-)]R8W\S2=Q'J=Y*?'[]GLO_ )WM%^FY^R??L]E_\[VB_3<_90'?
MIWDI\?OV>R_^=[1?IN?LGW[/9?_ #O:+]-S]E =]R8W
M\S2?2GQ^_9[+_P"=[1?IN?LGW[/9?_.]HOTW/V4!WW)C?S-)
M]R8W\S2=Q'J=Y*?'[]GLO_G>T7Z;G[)]^SV7_P [VB_3<_90'?IWDI\?OV>R_\ G>T7Z;G[)]^SV7_SO:+]-S]E =]R8W\S2?2GQ^_9[+_YWM%^FY^R??L]E_\ .]HOTW/V4!WW)C?S-)]R8W\S2=Q'
MJ=Y*?'[]GLO_ )WM%^FY^R??L]E_\[VB_3<_90'?IWD
MI\?OV>R_^=[1?IN?LGW[/9?_ #O:+]-S]E =]R8W\S2?2GQ^
M_9[+_P"=[1?IN?LOKC=M+LQ95^G'M]7M$[U7ES57^R@)^Y,;^9I:3AXM4<39
MIF#N(]3O)9(&U^I&P]ZX\9.U=V:;J5N?*;-Z.9^:>)>D8VNU=V;KV-J%K5MF
M;EU#1LNQ/>MW,6]-,Q*0;LD>D_UJQJ>%L'M#WHR;63538QM>HB8F*Y\(]VYY
M\YX\?"/%"JS,=83IN:[I1!Q=,U33M:P+&J:3FV
MSO3',K .T5Z5[;^B5Y>U^@^D3J^=;FJW5JV53,8]'JYIIGB:N/;$I4TS5LY-
M41NOXW=OO9^P]+NZSO#<6%I.'9CFN[D7..(^+S_4L;ZY^EEV!M:[?T3H[H56
MZ,VF9H^[;D]W%IGVQ,3%7ZD:O5'K+U1ZU:I5J_4W>&;J]R9F:+%=R?<;4>RF
MF?*/G>-BF*8B*8XB%]-F(W53K_ &P.T!UKR*_\J-[Y.%@53/&#I]?N
M5NF/9WHB*I^>5&:XF[E?Z8;RKL:/U8TFYM/
M4*YIH^Z?PL6J?7//,U?J7L[6WKM/>VFVM7VIK^'J>)?IBJBYCW(JYCXO-C=U
M4TU1--41,3X2]KTOZT]5>B^I4:ITTWGGZ3535%56/3V>N^BU:7FW.+?[K8D3./5/ES51$53'QS*0#:F\
MMK;XTFSKFT]=PM4PKU,54W<:_3)^"5%5,T[K8JB=G= (N@
M                           TF8ICF9B(CURH'U\[:W0_H!B7*-P;BLZE
MJL4S-O3M/KB].],.N/5F_D:7LC*N;,T"YW
MJ8HQZ_\ YJY1/JJKB>/+_96EY=_)U'-N:EJ65>R\N]5-5R_>J[U=4SYS,KJ;
M/\2NJYZ+]NL_I:=_[DJR-)Z/;7M:'A\S31J&9/-^JGVQ3S52LOWOU5ZF=2L^
M[J6^M\:KJER[5-4T57YHMQ,^RFGB/U/+"^FB*=E]YD4T^V.[W
M8GYY2 =#?2"=G_K139P*=Q4:!K-R(IG U&>[755ZXIF.8X^.4';;5;IJJIK\
M8JHGFFJ)XFF?;"NJU34G%MU1S%=NJ*HGYX?5!%T)[<
MW7WH1D8^'@;CN:_H%N8BK3-1JFY%-/K[D\Q%,\?&DO[.OI%>BG7&JSHFJ9?^
M2NX)B*:L34;D4VZZO7W;LQ%'GZN6>JU52MIKB5UP^=B_8R;5-_&O47;5<V9D&\41ZO=LCH%
MT8Q[L[GWQA9&513S&+@7(R+DS[)BWWN/G61]7?2\:[J47<'HSLB,.W,33&=J
M<]^9^&FB.[,?.G3155LC-40E"S-0P-/M57L_-L8]NF.9JNW(IB(^=0SJ?VX.
MSATKM7*=;ZA8.5F6YFG[CQ)FNY,QZH\./UH:NI':SNSS]:EU%BW175:JIGF9E;%CUE";OHDOZE>F#M4W+^#TJ
MZ<5Y%,Q--O+U*KNQ$^WBBJ?J6J]2.WIVG.I7NEG*WS7H^)7SQCZ?13$4Q[(J
MFGO?K6^BV+=-/DKFJ9<[5MP;CW!>JR=?W'J>HWKD\UU7\NY5$_-SPZ^FS:IG
MF**>?;QXMPFB                              -*J::XXKIBJ/9,KVN8BO,PJZHN\>N9IF::>5X'
M2KTC/9KZFQ:Q[VZZ=O9USB/N;4H[M7/LYIYC]:$-LN6;5ZGNW*(F%;@3[G X
M                   .JW1NG0-EZ%E[EW/JEC3]-P;G&QK?NN[=Y:7IE/_P"6O1S]$_55*ZFS,]95SIWDI\?OV>R_^=[1?IN?LGW[/9?\ SO:+]-S]E =]
MR8W\S2?2GQ^_9[+_ .=[1?IN?LGW[/9?_.]HOTW/V4!WW)C?
MS-)]R8W\S2=Q'J=Y*?'[]GLO_G>T7Z;G[)]^SV7_ ,[VB_3<_90'?IWDI\?OV>R_P#G>T7Z;G[)]^SV7_SO:+]-S]E =]R8W\S2?2GQ^_9[+_YWM%^FY^R??L]E_P#.]HOTW/V4!WW)C?S-)]R8W\S2
M=Q'J=Y*?'[]GLO\ YWM%^FY^R??L]E_\[VB_3<_90'?
MIWDI\?OV>R_^=[1?IN?LGW[/9?\ SO:+]-S]E =]R8W\S2?2
MGQ^_9[+_ .=[1?IN?LGW[/9?_.]HOTW/V4!WW)C?S-)]R8W\S2=Q'J=Y*?'[
M]GLO_G>T7Z;G[)]^SV7_ ,[VB_3<_90'?IWDI\?OV>R
M_P#G>T7Z;G[)]^SV7_SO:+]-S]E =]R8W\S2?2GQ^_9[+_YW
MM%^FY^R??L]E_P#.]HOTW/V4!WW)C?S-)]R8W\S2=Q'J=Y*?'[]GLO\ YWM%
M^FY^R??L]E_\[VB_3<_90'?IWDI\?OV>R_^=[1?IN?L
MGW[/9?\ SO:+]-S]E =]R8W\S2?2GQ^_9[+_ .=[1?IN?LGW
M[/9?_.]HOTW/V4!WW)C?S-)]R8W\S2=Q'J=Y*?'[]GLO_G>T7Z;G[)]^SV7_
M ,[VB_3<_90'?IWDI\?OV>R_P#G>T7Z;G[)]^SV7_SO
M:+]-S]E =]R8W\S2?2GQ^_9[+_YWM%^FY^R??L]E_P#.]HOT
MW/V4!WW)C?S-)]R8W\S2=Q'J=Y*?'[]GLO\ YWM%^FY^R??L]E_\[VB_3<_9
M0'?IWDI\?OV>R_^=[1?IN?LGW[/9?\ SO:+]-S]E =]
MR8W\S2?2GQ^_9[+_ .=[1?IN?LGW[/9?_.]HOTW/V4!WW)C?
MS-)]R8W\S2=Q'J=Y*?'[]GLO_G>T7Z;G[)]^SV7_ ,[VB_3<_90'?IWDI\?OV>R_P#G>T7Z;G[)]^SV7_SO:+]-S]E =]R8W\S2?2GQ^_9[+_YWM%^FY^R??L]E_P#.]HOTW/V4!WW)C?S-)]R8W\S2
M=Q'J=Y*?'[]GLO\ YWM%^FY^R??L]E_\[VB_3<_90'?
MIWDI\?OV>R_^=[1?IN?LGW[/9?\ SO:+]-S]E =]R8W\S2?2
MGQ^_9[+_ .=[1?IN?LGW[/9?_.]HOTW/V4!WW)C?S-)]R8W\S2=Q'J=Y*?'[
M]GLO_G>T7Z;G[)]^SV7_ ,[VB_3<_90'?IWDI\?OV>R
M_P#G>T7Z;G[)]^SV7_SO:+]-S]E =]R8W\S2?2GQ^_9[+_YW
MM%^FY^R??L]E_P#.]HOTW/V4!WW)C?S-)]R8W\S2=Q'J=Y*?'[]GLO\ YWM%
M^FY^R??L]E_\[VB_3<_90'?IWDI\?OV>R_^=[1?IN?L
MGW[/9?\ SO:+]-S]E =]R8W\S2?2GQ^_9[+_ .=[1?IN?LGW
M[/9?_.]HOTW/V4!WW)C?S-)]R8W\S2=Q'J=Y*?'[]GLO_G>T7Z;G[)]^SV7_
M ,[VB_3<_90'?IWDI\?OV>R_P#G>T7Z;G[)]^SV7_SO
M:+]-S]E =]R8W\S2?2GQ^_9[+_YWM%^FY^R??L]E_P#.]HOT
MW/V4!WW)C?S-)]R8W\S2=Q'J=Y*?'[]GLO\ YWM%^FY^R??L]E_\[VB_3<_9
M0'?IWDI\?OV>R_^=[1?IN?LGW[/9?\ SO:+]-S]E =]
MR8W\S2?2GQ^_9[+_ .=[1?IN?LGW[/9?_.]HOTW/V4!WW)C?
MS-)]R8W\S2=Q'J=Y*?'[]GLO_G>T7Z;G[)]^SV7_ ,[VB_3<_90'?IWDI\?OV>R_P#G>T7Z;G[+MM![6?9UW+D4XND=5]$O7JI[M-'?
MJIF9^>F&/Q]R8W\S2T^X\:*HKIMQ353Y51/$P=Q'J[WDLEK3]4TW5;%.3IN?
M8RK5<&7>T^BN)O:7EW)KQ[M'KCNQ,
M<3QZ^4OO9,[9>P^T]M_NXDTZ5N;#IB,[2[U<=_O<>-='EWJ9F)\N>/!57:FC
MJG37%2X@!6F                                            #I=T;
MSVILO3[FI[JW#I^EXUJF:YKRLFBUS$>SO3'*S/K5Z5CH_LBYDZ)TYTW+W7JE
M$333=M\VK%%7MF:J>*H^*4HIFK9R:HC=?'(A2CJGVJ
M.A71[&NW=Z=0--Q\BU',8U%R:[E<\>4=V)A$)U=[?7:2ZO7,C%O;NKV[I-_F
M/N+2YJM],2MWR:[V;EUY^?D7JF5U-CU5S=]$FO57TO
MVEV*[VG=(M@WJR-4U',S;M4\U5Y&17_B
M94O')B)W=UT2%=+/2\[MTJJQI_5G8=C/L\Q%S-TZJ?=./7,Q553'*]+I)VZ>
MSIU>M6K>D;XQ=/U"YQ'W!G3-%V)GU>$33^M!&V56J*JZ;G$Q71/--43Q-,_
MKFS3.R<7)ADMXN;AYMN+V'E6;]N?*JW7%4?3#[( .E/:X[0?1FY9HV?O_,O8
M%J8F=/SJZKEB8CU=V)CZU\_17TN.UM1G&T;K5M:_I.3I[T6[611[K'QV^>]'SP
M]DJV6                                                     TF
M8B.96:]L+TANT>@UR_L;8MNUK^\:J)BJFW7%5C#GVW)CPF?#RYB?)VFF:ITA
MR9B-UWFK:[HVA8U>7K.J8V'9MQWJJ[UR*8B/G4LUGM>]F_0JG:$ZS=:M1N:CU#WSGYE%=4S1AVKDTX]N/933,SQ]*F\86
M+$S/N,XCU<[R4^/W[/9?_.]HOTW/V3[]GLO_G>T7Z;G[* [[DQO
MYFD^Y,;^9I.XCU.\E/C]^SV7_P [VB_3<_9/OV>R_P#G>T7Z;G[* [[DQOYF
MD^Y,;^9I.XCU.\E/C]^SV7_SO:+]-S]D^_9[+_YWM%^FY^R@.^Y,;^9I/N3&
M_F:3N(]3O)3X_?L]E_\ .]HOTW/V3[]GLO\ YWM%^FY^R@.^Y,;^9I/N3&_F
M:3N(]3O)3X_?L]E_\[VB_3<_9/OV>R_^=[1?IN?LH#ON3&_F:3[DQOYFD[B/
M4[R4^/W[/9?_ #O:+]-S]D^_9[+_ .=[1?IN?LH#ON3&_F:3[DQOYFD[B/4[
MR4^/W[/9?_.]HOTW/V3[]GLO_G>T7Z;G[* [[DQOYFD^Y,;^9I.XCU.\E/C]
M^SV7_P [VB_3<_9/OV>R_P#G>T7Z;G[* [[DQOYFD^Y,;^9I.XCU.\E/C]^S
MV7_SO:+]-S]D^_9[+_YWM%^FY^R@.^Y,;^9I/N3&_F:3N(]3O)3X_?L]E_\
M.]HOTW/V7H-M=J#H%N^_;Q=O]4=$RK]R>*;<7:J9GZ8ACW?=:B]A95J_;GQBJW7%4?3#[(#^A_;)Z[]
M!M0QZMO[LR=4T:W5'NVE9]/7/*7OLM]K;I[VF]JT:CH>31@
M:YCTQ3G:5?N1%ZW7'G-,3Q-5/,3XQ'"JNW-"=-<5*Z@*TP
M    >?WIO[9W3S1[VN[RW#@Z5AV*)KJKR;]-$U1'JIB9YJGX(1]=H+TLVEXT
M9>W.@>AUYV33S;_=?-IFFS'JYIHGNU3\?*5-$U;.35%.Z0;=^_MF["TR[K.\
M-QX.E8EF.]7?ZED77#TLG3C:==_1^D6B5[JSJ)JHC+KGNXL3Y1,
M3S%7ZD9?4OJ]U-ZQZI7K'4K>&?K-ZNJ9IM7;D^XVX]E-,^4?.\C$13$1$<1"
M^FS$>)5-R9V5OZO=M#M#]9[U=&O[UOZ9I]4SW<'3JO::\;)KIB/]WGB?H=: O"Z-^D
M_P"O'3>+&G[TLXV\-,M1%'^G]Y?II^#NQ3$S\AOI#^S_ -9*;&GY&O4[
M8XY]LH1&VNU18F/"8E75:IJ3BN89+.)FX
MF?8IR<+*M7[5<1537;KBJ)B?AA]T"?1#MI=?>A&3CV= W9?U;1;54=_2M0JF
MY:[OLI\8X24=GOTEW1GJ[5CZ#NZNO:6X*HIHJMYE?^@N5S_)N<13'SRSU6JJ
M5M-<2O$'PP\W#U'&HS-/R[.38N1S1=LW(KHJCVQ,>$ONK3
M                               :554TQ-54Q$1XS,^H&HHGUR[7_1#H
M'I]V]NW=>-D:C33S;TW$K]TOW?#RCCWL?/,(W.O7I1.L'4^U?T7IIA?Y&:35
MWK?W13Q5E7J/;/,U4Q\W"=-NJI&:XI2@=7>TGT:Z'8=S)ZB;UP=/O41S3B>Z
M4SD5_P!&B9CE81UM]+CK697?TCH;M.FQ9F9IHU34J8BKCVQ:F*HGZ4>6KZQK
M6XLVO4]QZQF:IF7)YKO95V:YJGXO*/FAQ/)?39B-U4W)E[;J1UMZM=6\^YG[
M^WYJF?%RJ:_N:F_7;L1\$6XGN\?,\/1:MV_WNW33\4<-PNB-$  <
M                                  :54TU1W:J8F/9+N-J;QWAL/4K>
MK[)W1J6BY5J8F)Q,FNW3/QTTS$3\[J %]70[TK75#9U>-HG5S1;.X]+MQ%$Y
MV/3%O(II\N9III]]/QRD.Z*=KCH9UZQJ/\AMXX]6?/$5Z?DU4V\FFKCQCNHO8]V:*J9]OAY_.JJM4U;+(N3#)8$-'9\])
MOU?Z3TXVA=1K4[RT.WW;7NMR8C+LT>V.)IIGY^4FW0WM6]&>OVE6LW9>ZL:,
MVJ.;NG9%?M:ID4V,/!LUY%^[5/A1;ICFJ
M9^*(08]L_M4[D[2G4;+L6LR[8VAHM^O&T["HKF*+TTSQ-VN(\*IYBKCGGPE(
MUZ3[JIF=/.SIE:/I6159SMR9-&!3515Q5[E5/=N?JJ0OVZ9HHIIF>9B/&?;/
MM:+-/[RJY5Y-WP -"D                      :5T4W*9HKB)B6H"_CT;7
M;(U/9NYIU]S1\S(N=Z<>],\19F:OXLS5X>/A%/A"62BNFY13
M/7%VQ=HGB:*X\IA/5V,NM-KKET%V]
MNB[>[^I8^/&)J$<^--VB9B.?CIBF?G9KU&GXH76ZM>BN8"A:
M \YOSJ'LWIGM[)W1O?7\72M/Q:)KKNWZ^/"/9$>,_- /155133-54\1$].
MJMS-V3T;KO[>VW%=5JYJ4KR*:I^&84OIHHHCNT4Q3$>J(XAJ+XB(V5;@#K@
M      #2JFFN.[73%43YQ,ZQ>7;N6[UNF[:KBJBN(JIJCRF)\I8T7'%=-RFJJBNB>]1715--5,
M^V)CQ7>=E;TBW4;H57C;7ZA59&ZMI17%/>KJB9\(45V?.
ME;3<\I31CQ'2GK)T]ZT;9Q]T[ W%BZCBWJ(JJHHJ_P!):F?XM5,\3$P]NS[+
M0                          'PSL_"TW%N9NH95K&Q[4357@^@UZ]U'W/C:=3W9FS8FN/=K\_R:*9F.]*T7M8>D]VUL2[F[
M#Z(VK.OZWQ-J[JOC]S8M7KX\8F:H^*8\T7^^NH&]^IVOY&Y]_P"Y,S6=0R*Y
MKJKOU^]HY]5-,<4Q'S+J+4U=95U7(CI"[3M)>DXZG]4;F9MCI5;JVMMRN9HC
M+_\ WR_3Y,2U 71=G#TA'6;H/>QM%UO+N;LVQ35$7,;,N35D6J/]BY,553Q[
M/!*ST [5G2'M%Z51D;%W#;G4J*.]DZ9?F*,FS/',\TXMG
MZO8W!M+6\O2=2QJXN6\C&N33/,3SXQY3'QPJKM15LG37,,DX1N]DOTH6)JM[
M Z>]H&+>#ESW;5G<%,3[E=GRCW6(\8J^*GCS2+Z7JVF:W@V=3TC.L9F+?IBN
MW>LUQ5353/E,3#-53-,Z2OBJ*MG+ 1=
M                            >]=SX&D8=BGO5UY%SB
M>/Z,G7STM6CZ=?R
M]M]#-MQJMV(JM_NOE\TV*9_E41%45?32CYZF=;^K?6+4[NJ=1-\:CJ7ND\TX
M\7.Y9HCV1%,1S\ZVFS,[JYN1&R4#K?Z5;I!LF+^E=+<6[N_5+]S]"PCK'VZNT7UHJN6-2W97H.FU\Q3AZ5/N,Q3/JFY1W9J^=;]313
M1'%-,0U:*;=-*N:YDN]_)O59.9>NY-^N>:KU^N;ERJ?AJGQD!-
M                                   M=_'O4Y.)>NXU^B>:;UBN;=RF
M?@JCQ7$]%>WOVA^BDVL3'W%.Y-*HF(JP]4JFY5W8]5-VKO51X>Q;L.3$5;NQ
M,QLF6Z$^DXZ']3_N71]ZY,[0UV_,4>Y9DQ&/55_LW*ICGZ%WVFZGI^L85K4=
M+S+65BWZ8JMW;57>IJB?7$L:JJBFJ8F8\8\IB>)CXI5@Z(]K'KAT$U&W>VAN
MS(R]+IJB;FE9M1@Y^#J6-1F:=EV:
M9IW6Q,3LY #CH                                   #9=NV[%JN_>K
MBBW;IFNNJ9XBF(CF9E#5Z0[M>:QUEWYF]+=G:M=,515''C$\I)>VGU1N])>SONK9JKJ\:IGXYF5]FG7\4JKE7DUB(IB*:8B(CRB &E2
M
M                      .^V)OW=W2_=>%OG8NJW-/U?3ZXKMUT53%-R(F)
M[EKLA]IC0.TOTOQ=QXEVFWK>#33C:OB>'-J_$>Y:3N^)P^Z?A15Q[?>1";>/&.6.Y3R2T
MT5J*8YF>?B1R]H;TL>JZG7E;9Z!:)]S6/&B->\-\;TZAZK
M=US?6Z,_6LV]5-=5>1=]['/JBF.*8CYG21$1'$1Q#139B-U4W)G9['J3UBZH
M]7M4KU7J%O34=3JKF9^Y_=JJ,>GGU1:B>[^IXVBBBW'=MT13'LB.&HNB-%8
M                                   3$51Q5$3$^J0!V^T]X;OV%J=O
M6-D[GU+1HNTKF-H?671+>OZ;1$4?NC
MB411D4T^V:*:??3\=2PT1JIBK=**IC9D"]&.U'T6Z\85J_T_WCB9.77$=_ N
M5TTY-N?7$T1,\*LL:K2=4U?;^=;U3;VJY>F9MJJ*K=_&NS153,>OB/"?G7J=
MGCTI'4KIK1C;>ZO8-S=ND4]VW&=1Q&59I]L^--,Q\TSYJ*K,QX5E-S7=,"*7
M]&NTETBZZZ-:U78>[,/)NUTQ-S#KK[EZU5/\68F(YGXN54%$QINMW
M                                        :554T4S77,133',S/J@%
MH?I#.UG7T V!3M3:&913O'<=%5O$\I^Y[7C%5WXXGN_3YH8\S,SM3SLC5=5S
M+N9G9ER;N1D7JIJKN5SYS,SXJU=M3JEF]6>T;NC5\F]->/I5^=.Q*>>::*;?
M%-7'QS1RH@V6Z>6&>NK60!8@                      /2]-NI.\.C^],#
MJ!L34:\35-/N17%,53%%^F)B9MUQY51/'KY>:"8U=V9 /9@[06W>T;TMT_>^
MC7:*Z7==+>P\_*[FB[S_T,Q75/
MWNT8YABN4\DZ-%%7-#4!!(            !33K?VA.F
M?0+:]_R*_5333'USQ!$:](-=%1LG)L8>/]--.%8KXO9-/JF[5S/',?R9CSE;!%,4S,
MQS,U3S,S/,S/PS/FT46?.I35<]'N^KG7'JGUSUV[KW4?=65G3[\_#PE---,1333$1'JB&HOB--E>X ZX
M      -M=NBN8FJF.:?&FKUTS[8GU-P"X/L]=N/K=V>\BQAX>KW-Q[>IJB+N
MFZA=FNJ*/91:H^'B$$K[8&?J.D9UK5=&U#(P,VQ5%=K(Q[DT5T51Z_#S^=77:BI.FN89+
MBC[*7I0=?VI=T_8?7VFK4M,F:;-K7J8_TMKU1[K$<1Q\5,SYI0=H[TVMOS1;
M&XMH:YBZII^33%=N_CU]Z)B8YCF/./G9:J)HW74U15L[L!%(
M                          'G=]=0MF]-=!O[EWON#$TG3L>F:J[V1E4U?6+N5M+L]XE./@UQ-NYKN33$UU>J?Z :3:H^/A&1VAO2=]7
M>J%Z]HW2OW39V@5]ZGW6FN9S+M$^'X<=WN^'JF%H&X-?U_=NJWMF>['P0X+31:BG=557,OIG9.7JFHWM7U7,O9N=D535=R
M;]7>N5S/GS+Y@M5@
M       #E:+JVK;;UBQN';FJ96F:GBU159R\6YW+E$Q[)AQ0%_G9H]*ANS:-
M=C;'7_'N:UIO--JUJ^/3/NUJ/;J>P^K&@6-R["W)AZKA7Z(K
MCW&[3-='/JKIB>:9^"6.;,1,<3',2]MTEZT]2^AVXK6Y>G&Y:?'V\RGZ1_IYUHHQ-I]1;EC:^[KG%NF
MU=KB+&55YM>9;N47:*;ENJ*J*HYIF)\)AFJIFF=)71,3UAN
M<=                                  1I>F/SGG]9F?]I&JV6O##/7XI %B
M    DE]#GO?(IN;YZ=Y.5Q8MUTZECVIGX+=$S$?/*-I=1Z-/>W^2?:BTK3*[
MON=G<&-5@US,\1XT+VF>J':5W%7JN^]5
MKHTJU>[13Y4Q'/JX=$UT6XH]ZBJN:@!8@
M            ]STZ*-U=-->NX-RJN)RL29GW#+I]=-=,3'/E'T0F
M'[)O;JZ<]I#3K6BY=ZC0]X8]$?=6G9-R*8N5U6#TMZYY5C3]=B*,;3]4GBFUF1'O8BORXK\O5//CXI"+=RW>MTW;5<54
M5Q%5-43X3$^MEJIFF=)7Q5%6S< BZ                     MJ[6W;;Z?]
MF?2+FF4WK6K;PR+4U8>DVZHYB>/"JYZZ:?+QXGS=B)F=(L?6OJ)UYW=D;QZB:W>RKMVJ:K.'37,
M8^-3ZHHHCBGY^.7AFJBU%/6=U-5KF;F-3SYV9GPI\?5$3YRMI')B*HTEV)F-F0[T6ZZ=.N
MO.T<;=^P-:XB_8JXCPKH_"I\_7$*@L=GH[UIZA]!]W6-Y=/-9
MNXUVW5'N^'57/W/DT>NFJCQIYF.8YXYCE,WV3>V;T_[3&W[>/9R;6F;LQ;NJGX>(\X9:[4T]8V7TU\W1<6 J3
M                               ;+MVW8MU7KU=-%%$35555/$1$ WNH
MW/NW;6R])O:WNG6\+2\*Q3-5=[*OTVZ>(]DU3',_ M1[3GI(NE?1BWE[N)L6*H\_=*XGF)B?5Q/K19=:^TAU>[0.LUZKU W/D_EU:GGTW/E[VB8CO?'%2.CJ=U;ZE]9]5G6NI^[DNQ.FR=CLX]M[HUVB
ML*WCZ3JU&CZ]$1%W2\^Y%NY%7LHFKN]_Q]D+A8F)CF)\&-/A9F?I6;:U/2-0
MR<#-LU15;R<:[5;N4S'E[ZF8E?OV5O2@[DV;J:M2T6CNVK6M6J8]VL
MT_\ Y2/#F/AF9EGKLZ=:5M-SU2Q#S^Q]^[1ZD;>QMT[*UW%U73,NF*K5_'KB
MJF7H%"T                                 !8IZ7G-RL7L]Z79L79IH
MR-6MTW(C^-$5VT1D1Q'$);/3 _D T7Y8M_W[2)-KL^%1L?(T:C4;>N[KBF8M:5BU15-%?J]
MUGGFF/FEV(F>D.3.FZXK7MPZ'MC3+VL;AU7$T["L4S5B5'*:*:([M%,4Q\$-%%F(ZU*JK
MFNSU/4GJAU"ZPZY5N/J7NC+UO-JJ[U,7KDS:M?!13,SW8^=Y<%^FBH
M                                       !V6U]R[CV1KMG<^S=;R]'
MU7'F*K>5BW)HKB8]LPD![-7I6M7T:,7:W:&P*LVS,Q9M:WAT3WJ?ANT>^FKX
M^81V$Q%43%41,3ZI1JHBK=**IC9D=;$ZB;+ZEZ'8W%LC<6%JV#?HBN*\>]37
M-//JJB)GNS\$O2,=[H[UVZI=!MP4;AZ<;FR<3NS'NN#DEZ:]98Q-J]0J[.U=V7>[:IM7:X]PR:_+FBJ>)YGPGCCULU=J:>
ML+J:XG=><-MNY;O6Z;MJN*Z*HB::HGF)AN5)@
M                  #J-WW;EC:NL7K57%=O!OU4S[)BB>';NEWI^*&M?)]_
M[.2!CF;FR+N7N[<63D5S7MUSFZ]^,^O_+&=]O6X3?&S+5N
M .N                        .TVEK=_;.[]#W)B7/<[^F9]J_;K]GON)_
M5,LBW8VXK.[=GZ1N7'JBJUJ.);R*9B>8F)AC=WZ>]:J^#BKZ)Y3M]@;>M>^>
MRSLK4+E43(IB/.91O\ ;@]([3H]S.Z3]!<^W?SXFK'U+6J)B:,?
MU546Y\>:O/Q\)CP2IIFJ=(WK>MS%FQ:KB
MNSBUS,3]"(7J7U/WYUCW3>WGU'UZ_JNI7:IFB*ZI]SL4_P F
MW3,SW8\?:\YF9>;J6=?U35,V_F9N5_FZ+>JF;-V.?&:8YB*:O&?'Q\U'AR8B>DNQ.B>WLT]K
MCI=VEMOT9FU]2HQ-9LT1&;I637%-ZU7Z^[$\37'C'C$<>*N+&XVAN_='3_<6
M)NS9>M9.E:IAW(N47;%R:8KX]5<1/%4?!/*6WL8>D/V[UKMXNP>J5[&T7>E,
M1117,Q38SYX\Z/+WTS$^$1QXPS7+7+UA=37KTE>T-(F)CF&JE8
M                       \[OSJ!M'IIMS)W5O36\73-.Q:)JJNW[D4=[CU
M4\S',_ #T%==%NB:[E44TTQS,S/$1"TOM4>D,Z9=!+-_;NV;EK<^[)HF*,3&
MK[UJQ5ZIN5>$RNKU[)W'M?O4V;.;,Q.1@T?#
MY1-,?%,^*RH\_"7*J8JC278F8V9'6P>HNS>IVW<;=.R->Q=4T[*HBNBY9KYF
M(F.>)CSB?CAZ1C]=G?M.=3NS1N6WJVR=2KO:3=N1.?I%ZJ9L7J.??333Y4U<
M<\3Q/J3-]FGM5]-NTMM>G5MJZC18U2Q3%.;IEZJ*;]FOU\4SQ,T\^OCV,E=N
M:/?UF9_VD:K9:\$,]?BD 6(                        #
MV71;+=M95N>*K%VW=C_=J
MB?\  GJ[LR5\/*LYV+:R[%456[U,5TS'KB7V4N[,6\;._.@NRMS6\CW:O*TF
MQ-ZKGG_2=V)JC]:J+!,:-4=0!P       67]O7MQZ?T*T2_TZZ>9UG)WUJ%N
M:*IB8JIP+57A-=7'E5QWN/*8FEVFF:ITAR9TZOAV[>WEIG0[3[W3CIKE6L[>
MV=;F*K]NJ*K>G4S'X54Q_&\8XCQ]?,(A-9UG5]QZOE[@W!J-[/U+.N3=R,B]
M5WJJZI?/4M2U+6M3R];UK.NYFH9]VJ_E9%VJ:JKE=4S,S,S\,RX[911%$,]5
M7, )H@                                       $Q/,54U54U4SS35
M3,Q53/MB82%=A3TA^;M>_@='^N.HW,K3[M5./I6LW)\;'LHN_!Y^/'KCQ1ZM
M*Z*:Z>[5'@C53%4:2E35-,LEG$S,34,:WF8.3:R+%V.]1*6W3]0
MPM5P;&I:=DV\C&R;=-VU=MU153735',3$Q\$LE=$T3I*^FJ*H<@!!(
M          :554T4S555$4Q',S,^$0TKKHMTS775%--,=7EXQ/KF$J:9JG2')F(W>Y[;OI#-'
MZ26LKIKTER;.I[NNTS;OY=NKO6<")\)F9B?&KSXXY\8\43&O:_KNZ]:RMQ[G
MU7(U+4\VY5=OY-^KO553,\^'LAPKE=Z_?NY63?N7[]^N;EV[4Q\SJP$R_8D[>>WNOFFV]D;ZN
MV=(WG@VJ::XN5]VWG?[5N9GS^"9]2\=C4Z;J.HZ)JF)KFBYMW#U# NTWL;(M
M5335;KB?#B82]]@[MXZ;UJTW&Z9]3+B5?[54J_DTTQS/S\<(FNU%Z1+J?UVNY.W=C7LC:>TZJIIBBW5$9.
M31_MSS,1$Q[./6MRZD=3=^=7]R7-V=1MPY.K:AJKJF9JJGVS,M06JP
M                                          F(F.)CF !5/H)VE>JG
M9SW%;U?8NMW:].JJBTKHMNG3\NC2
M-QVJ8C*TG)KBFY%7KFCU51,\\<3,H)W.T#7M=VGKF+N;:NKY&E:MA517CY>/
M7-%=$Q//G'CQX1X*Z[<5^].FN:62@(_^QAZ2/2=_S@]->M^59TSV9YX^%?\ 6[EN];INVJZ:Z*HYIJIGF)AEJIFF=)7Q,51K
M#< BZ                              L-],#^0#1?EBW_?M(DTMGI@?R
M :+\L6_[]I$FUV?"HN;@"U6
M                                                 ]/TJ_*KM#Y6
MM?XLC.Q^\T?T88YG2K\JNT/E:U_BR,['[S1_1AFO[PNM>;Z *%H
M                       \]OC?^T.G&@Y&Y=YZ]B:7@8U$UUW+]R(YB(YX
MB/.9^*%%.U'VV^EO9LTRO#S7CQ'DLHMS4A57%*Z+M6
M>D[W1O\ G.V/T*B]HFC]3535,54S[8F
M!=[V5O2+=1^AU_'VQU$NY&Z=IS--JFJY5SD85'MIGF(F(^'F?-+3TGZS].^M
M.VL?=&P-QXNHXU^GFJW37QSZ3=8NH_0W
M\KEK;N\8IBB;%ZN*;.55ZYMU3Q',_P F.5W\3%41,3S$^,2RS3-,Z2NB8G9J
M XZ                                      .EWI^*&M?)]_P"SEW3I
M=Z?BAK7R??\ LY(&.1KWXSZ_\L9WV];A.;KWXSZ_\L9WV];A-\;,U6X ZB
M                      3',<3ZTKGHAM]U:KTNW#L.Y=[U6BZA5D44\_@T
M7.[3$?\ +**->]Z)+>5S1.O&O;1N7XMV-)RI]=%N?Y/EX\>J?%'Y33%//',S,\S,SS,S[9DHHIMTQ13'$0U;*:
M8IC2&>JJ:I $D0                                       !NLWK^+
MD6LS#R+F/DV*XN6;UNJ::[=<3S$Q/QMH"3#L->D9N95W3^D'7?4.5BWJ+UF[3%5%=%4335$^N)AC2
M7+=-VGNU1\,?!*0+L'^D'S=E9.!T>ZUZE'RQ1;OV+U,5V[ENJ*J:Z9\IB8\X?5G6@
M                            TF8IB:JIB(B.9F?4LO[9WI"-L=#;&1L3
MISLX,3X=^J8F(FJ/'B(GSAVFF:ITAR9B-U7NTSVN.F79I
MVY>J7,
M;2K=6\]U]0]QY6[M[ZWD:MJV97-=R]>JY
M[L3/X-,>J(\H^)TS71;BCWJ*JYJ(B(CB(B(CU0 L0
M                                             'H-@=0=Y=+-TX>\
M]AZW?TS4\*Y%RF;=U&]@:E@7:;V/D6JN*J
M*HGF/F2Z]ACM]Z3UHT_'Z==4DKW1I$Q,1,3S$^4M5*P
M  !&7Z8_\'IY_69G_:1JI*O3'_@]//ZS,_[2-5LM>"&>OQ2 +$
M              !I73WZ*J?;$PU 3*^BNWC1K_9EQ- KN=Z]H.=>PYYGF>Y3
M31$?XKR46OH>]]18W+O3I]D7IF;UJUFX]'/E/-8F[5[(CBKY^$*&O[@UW=N
MN9FY]T:G=U#5M1NS>RJ.(AY5KMTG^:JF?XT<3/J\X221,3',2QU4S3.DM%,\T:M0$70           !LO
M7K6/:KOW[E-NW;IFJJJJ>(B(\Y:UUT6Z*KERJ*::8YF9GB(A&9Z0_MX555YW
M0KHWJ]RWD4556=:U?'KYHBGGBJS1,>U*]G=%>B.K]VQ'>L:OK6/7Q535'A5:MS'KYF8F?"8FE')[ZJJJY9JF?.9^%JV4TQ1&D,]54U3K(
MDB                                            .1IVI:GHFI8VM:
M)J%_ U#"N4W],1&=:IXB*Z?A\:>?#SY7HL;';NX]>V=K^#NK:VI7=/U;3;L7L;(MSQ--
M4?X)LNQ%VO="[2FQK>#JE^WB;QTBW3;U+$JJXF[,L+
MZ*M>DKG %*P                                          =+N[>.V
MMB:#E[FW9K&/INFX5N;EZ_?K[M-,0\?UTZ_].^S]L_)W;OK5[5J+5,^X8E%<
M3?R*^/"FFGQGQ]O''BA?[4':\ZD=IS<%=6JY=[3-K6+D_<6D6JYBF:?57<\9
MYJXY^E91;FM&JJ*5;^U_Z2/<_5*[F]/^B]^[H^V.]5;OZK3/%_,I]E'GW:?A
MB8GQE8Y/>JKJNW+E=RY7M^J
M:M5=ZFNBJ.8F)^*7+0O]B/MW;@Z!:MB;"ZA9M_
M4=B95WNTW:YFJYIU4SYQ[:/&>8XF?"$Q>U]T:%O+0\3<>V]3L9^GYMN+MF]9
MKBJF8GXF2NB:)ZM%-45.U 02                            6&^F!_(!
MHORQ;_OVD2:6STP/Y -%^6+?]^TB3:[/A47-P!:K
M
M      >GZ5?E5VA\K6O\61G8_>:/Z,,JF/.J?@@'=9>9BX&-=SIF:;^?'P^RCR\.(GQE9W1131'%,?#/PRT6[7G4IJN>4
M.9K&KZON+57AY-[
M&R;-456K]FN:+E$^V*H\87_=CWTEVL;,KP>G77G(KSM'CNV,36_";EF/*(N^
M7,?#XSXH_P!I53%4335',2C53%4:2E$S3LR2]M[FT#=^CXVO[:U7'U'3\NB+
MEG(L5]ZFNF8YB8=H@B[*_;.ZC=F/6K>/;R+^M;/NU?\ S6D7*^?L5>NFJF?&.)]?#+7;FA?3
M7%2HH"M(                                    =+O3\4-:^3[_ -G+
MNG2[T_%#6OD^_P#9R0,CU11=IJG]4.3&L:.QNR48F*HBJ)YB?&
M&KS7377;.YNGVW-?L78N4Y^E8M^:O;-5JF9^MZ5@:@     !MN7*+5NJ[=KB
MFBB)JJJGRB(;EA'I&>VK3TVT:[T:Z9ZE37N;5K,TY^99KY^X+4^<;T(Z1:K-O%LU3;UO5,>OQKGGB;-$Q\7CY>%2
M.BBF**>['SS/G,^V?;+6.],U5W+E5RY75-5==<\U553YS,^T;*:8IC2&>JJ:
MI $D0                                           !I53%4<3S'KB
M8\XGVPU 2 ^CY[>&1LG+P^BO6+6*KFBWJJ;6D:ID5\U6:Y\(M5U3X\?@Q'GZ
MTK.-D6,O'MY6+=INV;U$5T5TSS%5,QS$Q\S&DKHBN..9B8GF)B>)B?;"3'T<
M_;ENY5S$Z$=7M8JKRO"WHFIY%?%-=,>$6:YGRGQ\)\/"EGNV_P!Z%M%?E*2X
M:1,51%5,Q,3XQ,-6=<                        -MRY;M457;M<4T4QS-
M4SQ$0V965CX6/GI!LS<.5J/1GHGJ?]CZKK%'$T8\>NBU5'G5Y>,3'G*,/(OY69E7L_/R[V5EY-KFNY7G:;G8^JZ5F78F)CQ\WR 2[=@3MW8W6#"L=*N
MJ&9:Q=X85NFWB7JIBFG4+<<1$QS_ !_+P\9GB97T,:G3=2U/1-2QM:T3/O8.
MH85R+N/D6:YIKHJCUQ,)B>P/VW-.ZZ[?M=/=_9MO&WQI5F*:JJYBFG/HB/PZ
M?]KPGF.(\F:[;TZPOHKUZ2O- 4+                            $9?IC
M_P 'IY_69G_:1JI*O3'_ (/3S^LS/^TC5;+7@AGK\4@"Q
M           !<]Z-[>E.RNU/H\7+D46=;Q;^'.911O;0[447J:I\V)XX0KHYX2IJY99'8I1V:NOFV.T/TPTW>^@Y=
MNWQK%J::(HF)^X;4QXW*OA]]$Q'CY2[3$U3I#DSI&LJ>^D.[=<;
M+QLKHGTBU2BO7LJB;6K:A:JY^XJ)_B4S'E7/O?7$\3**R9KJJJN7;E=RYH6R\ZO'SL"[3-VBFJ8IOV>??451Z^8F>/C>4#<9!/9MZ_[5
M[1?33 WUMS(HB_51%O/Q>]'?QK\1[ZF8]G//$^OA55 GV0>TUK/9FZH8NN7,
MF[=VMJ-=-C6,/O>]BB9X]UB/;3$U3\Z=7:FZ=%WKMW W1M[.MY>GZC8IOV;M
M$\Q,3'E\<>3'/5+H>V/V
MR=I]F;:E>-BW+.I;OU"W,:=IL5>,3_+K]E,?3XPA9ZB]1MY=6=WYV^=]ZO>S
M]3S[DW)[]7-%F/Y-$>41\4+;=N:NL[(5UZ=(=MUGZV=0>OV\K^].H>J5W[M5
M4_IHKHKJFJK3ZIXCO4<_Q>>.8CB/&96J
MDQ%4335',2Y-,51I+L3I.L,DO;>X]%W=HF)N/;NH6<[3LZU3>Q[]JJ*J:Z)C
MF)B8=FAA[!W;:U7H+N/'Z>]0-1O9>Q]2NQ;LUW*N]5I]VJ>(F)GQ[G,T\^,\
M1'A"9/2M5T_7--QM7TK+MY.'F6J;UF[;JYIKHJB)B8GXI8ZZ)HG1HIJYH1O+?FJT6+=%,QCXU,Q-[)KX\*:*?.?F]J
M%;M/=K+J+VG=R7+^NY=S VSC7)G3])M53%$4^JJYY155XSYQZWD^N'7;J#VA
M-YY&\M_:EJ5P;&ZV;
MO/=/3SL9&F:I@W*;E%VS7Q%?$\]VJ/*8GR\?:F,[%_;PVKVAM*L[3
MW?>Q]'WQBT11=QJJN*_&?7_ )8SOMZW";XV9JMP!U$
M           ;+_,V+G'GW9X^AO 3G>CYWQ.^>S!M?,NWZ:[^#17@W(B>>[%J
M>Y3'T4KD$>'H>=WT7^G&[=CWK\U7=-U*B_;IF?*FY[I5/'ZDA[%7ZF=0]O=+-DZKOC<^;:QL+2\>N],USQWZHCWM,?#,\1\X*.=M3M4
MZ/V:NFN1EXE^W>W3JE-5C2<29B9[\QQ[I,?R:9FGGXT'6O:]K&Z]>S]T;BS;
MF9J>J7ZLC)O7*IF9JF?+F?5$<1\SW?:&ZZ[E[1/4[4>H.OW;E.-77-K3<6:O
M>V,>)XIXCRYFF*>?B4V;+=')#/75S2 +$
M                     !NM7R9BKCXF6[;Y>L+Z*M>DJZ@*5@
M   ^>1D6<6QO\ !YGF)\X2IIFJ=(6-7G.W_ -OK,W-F9_13HSJE=C3[
M%=5C5]6L5_O_ *IM6YCU>'C/C$Q4CTHHIMT]VGGVS,^['G,S,\S,S
MS,S[9GUM6RFF*8TAFF9JZR ).
M                                     #L=N;DU[9NX,#=>U]1NX.JZ
M9>IOX]ZW5Q,3$\\3\$^4_&ZX!./V)NUSHG:6V';LZE>MXN[])HIM:EAU5Q%5
MR8CCW6F/7$\3/ASQS'*Y=CH]).K.\.A^_M.ZC;(RJ[>=@5Q-VSWIBC)M,2G?[._7C:?:$Z;Z?OG;&9;N5W+=-&=8B8[V/?X]]15'J\N8^"89
M+EOEG6-FBBK7HJ> J3                          1E^F/_!Z>?UF9_VD
M:J2KTQ_X/3S^LS/^TC5;+7@AGK\4@"Q                          !MN
M7*K$1DVYXN6*HO43[*J9YC]<,@CLK[TC?W0/9VX?=._55IEG'KGGGWUJBFB?
MUTL?BNF*Z*J)_C1,)A_1/;VN[E[.EW0;]SFO0-1NV(IF?&*:Z[E4?JA3>C\.
MJRW/5>P RKP !;=VY^TQ@=G;I'F7<._$[EURW5B:3:IJ]]%<\\US'GQ$15'Q
MKA-:UC3MO:3F:YJ^33CX6!9JOY%VJ>(HHICF9GYD"_:Z[0.J]HOK'J6Y;U^J
M=%TNY7A:19[W---JF>)JX\N9JBJ>?A66Z.:4*ZN6%&\O-S]3SJN+>R\BY5M/7+U-C5\?GPHYXXNQ\,<1'SIS]
M%UG3MPZ3BZWI&5;RLW;=454UTSY3$QYL:VNFFNF:*HYB4GGHM.U37J
M>'7V?-[ZG,Y6!;]TT*[=JYF[:B/&US/\F*9GYU%ZC7\4+;=6G24D8#,N
M   >/ZL=4-K='=B:IO[=^H48N!IMFJY,U3'-=7JIIB?.9-Q3?M>]J#;?9GZ;
MY&MY5ZB_KNH45X^EX5%<>Z579CB*YCSBF.8GGX)09;RWEN;J)NK4=[;QU&YG
M:MJEVJ[>N5U<]V)F9BBGV1'/$/9=H?KQNKM%]2\_?VX[URC%FN;>F87>GN8U
MCF>(B/+GQGQX4T;+=')'M9ZZN:0!8@
M                      3$51--4!EV-1T^_58R\2Y3>L7:)XJHKB?"8E&
MJF*HTEV)Y9U9+,3$QS#5:_V">U!C=H7I1CXFLY=,[LV_13C:I:YCFOB(B+OQ
M3//T+H&*8F)TEIB=8U ''0                                 !;;VR
M>V)M?LR;0JM8]=O4-VZC1-&G:?15S--4QX7*XCRICF)\>.?'AW_:Q[4FS^S+
ML&]K6K9%%_7?=CQGRGR0<]1^I&\.KF\L_?V^]2N9FJ
M:A7-4\U3-%FF9F8HHCRB(Y]7"VW;YNL[*ZZ].D./OK?6[.IN[,_>^]]6O:CJ
MVH7*JZ[ERKF+=,SX44^R(CB/F=$#6H
M                                            :5T4UTS15',3'$K^
MO1U=MW)V'JN)T.ZI:K7XF*
MJJ:J9YIJIGB:9]L3ZD:J8JC278G2=89+EF]:R+5%^QC]]&_VTZM_:79Z(=3=2HC<&EVHHTK*NU>^S;,?Q9F?&:H]][?"$@3'53-,Z
M2TQ.L:@"+H                       "PWTP/Y -%^6+?]^TB32V>F!_(!
MHORQ;_OVD2;79\*BYN +58
M                                               #T_2K\JNT/E:U
M_BR,['[S1_1ACF=*ORJ[0^5K7^+(SL?O-']&&:_O"ZUYOH H6@
M              +>.U]VO=H=F/9]RNJ]:SMUYUN:=,TR*HFJ:N/"NJ/.*8F8
MGREV(F9TAR9TZRU[77:^V9V8]HUW+]RWJ&Y\ZB:=.TVW7$US5X\55Q_%I\/7
MQZD*/5'JAO7K+O3-W[O[5;F;J.75,T4S5/N>/1SX441/E$HN[^K.
M\,[?6^M5NYVIYUR:H[]4S39HGRHHCU1$<>7'D\XUV[<41[5%54U "Q
M
M H1'E53,^$5?!SSX2OA8TV'F9NF9^-JVEY=W$SL.Y
M%W'R+54TUVZX\IB8\4MO8)[>V%U9PL7I1U7S[6+O'%M]S%RZ^*:-1HB/./+W
M_A/,>/G#-GXH:U\GW_LY=TZ7>GXH:U\GW_LY(&.1KWXSZ_\ +&=]O6X3FZ]^,^O_ "QG
M?;UN$WQLS5;@#J(                         "]'T4F^IV]VALW:>1=XL
M:]IURJBGGCFY1-$4_P!Z4QK'^[(>[*=C=IG86XKESN6OW3M8EV9GB(MUUTS/
M/Z*?W'O4Y&/:OT3S38\)ICBF5Z_I NTU9Z
M =)4-L1$>$0 TJ0
M                      !5KLO=H77>S7U4P-[X%Z]]738UC#HF>+UB9
MCFKC^5$=[CXU)28BJ)B8YB?4Y,:QI+L3HR0-B[UT'J'M33=X;;S;>3@:GCT7
M[5=%45<=&O7JO"Q?GQ]
MRYGRB??S_@EHB8F(F)YB6*NGEG1HIJYHU:@(I                 +=.VIV
MJM&[-'3B[DX]^B]N?5Z*L?2L6FKFN*YCCW28CQB(YF>?@=B)F=(?Y4Q/AY^2(ZY=OY%Z[E95
M^N_D7ZYN7;M<\U5US/,S,_&YVXMQZ_O'7\_=FZM1N9^KZI>JR,K(N3,S575,
MS,>/JB9GAU[911%$:,]57-( FB
M                                          *\]CCM.ZYV:.IV-G3?
MN7=K:Q=IL:OB=[WM,3,<7:8]4QQ3'Q-24UBKIFB=&FF>:-0!%T
M          !&7Z8_\'IY_69G_:1JI*O3'_@]//ZS,_[2-5LM>"&>OQ2 +$
M                        !(7Z'[>GW)O3>.P:[GOM'HN.]'EO*YL[M6[8HJOQ9Q]:BK3[LS/$3-=5'$?\ *AVD=.ME:QO37,FBQB:5B7,BJJN>(FJ*9[M/SSQ'S@L
M>]*GVD9VGL_'Z'[7U#N:MN"/=-0KM5<56<:(CFF?Z453]"*2BF**8ICU/:]9
MNJ>L]:NI^N]2=;O5W*]3R*ON6FN9_P!'C15/N=,>SBF8AXMMHIY8T9JJN:=0
M!-$                                                    =IM7=
M.M[&W/I>\MN9ES&U#2,FC)M5T3Q-44U1,T3\$Q$Q\[JP&0+V8NNVB=H3I+I&
M^]+O4_=5=JFSJ%F)\;613$17$Q[.]$\*LH5_1P=H^]T7ZP6MCZ[G3:VONZY3
M9KBJOBBSES/%%4^J(]]5,II;5VW?M47K54547*8JIJCRF)\8EBN4\DZ--%7-
M#> @D    ^.9F8NGXMW.SLBBQCV*)N7+E<\4TTQYS,H6?2!=K7(Z_P"_Z]E[
M4S+EO9VW+M5F.Y5Q3G7X\)KGVQ$S5'S+G?2<=KRO:FE5] ^GVJ=W6-4MJ.)M\QY35$U1,?!Y(KZ*8HI[L?',^V?7+19H_>E3-8
M[.W5[2M[Z?[-4Q_LQ555\R?':NYM(WEMW3]SZ%E4
M9&#J6/;R;%RF>8FFNF*H^?B6-K53%=,T51S%43$_$DW]%-VEXR<+*[/>[=1J
MKRL6:LK1*[M?'-GF>_;CGSF)JHB(^!1>HUCFA;;JTG1)0 S+@
M                    !3OKOUMVCT#Z=ZEU W=F446L2W/N&/WO?Y%WB9IM
MTQ[9XGX'L-S[ET79^@9^YMPY]G#T_3K%>1?NW:XIB*::9JGS]?AX1ZT&7;'[
M4NN]IKJ1>R[61>L[3T:[59TK#YGNU]V>)O3'MGCF/#RJ66Z.>4*ZN6'@.N76
MO>'7_J%G[_W?EW)B_][[OQ''ND1[*IBJ?F05*G=F_KQK_ &<^J>G=0='O
M7)P>_39U;%HF>+^-,QWO"/7%/>X\_-7FYLFBO
M)[LT8%$7,\>$^/'#L1KT@F='G>UKVKMG=F38MW4]0OV\K7\Z
MFJUIFGT5HV\.K.\,_?6^M4NYNIY]RJOBJKFBS
M3,S,441Y1$<\.PZQ=7]Z==-^YW4#?.HW,C)R:Y^YK$U3[GB6N?"BB)F>(\Y^
M>7BVNW1%$>UGKJYI %B
M                              ^N'FY^F9N/JFE9MW#SL2Y3=Q\BU5--
M=NNF>8F)^.(?(!+YV!.W3I_6'2,;I;U,U"WB[ST^W3:Q[MR>(U"W3X15$_RN
M.[SY>,KX?/QAC6Z1K&K[=U?#W#M[4;N!JFG78OXF5:JF*[5R/*8F$S/8.[:.
ME]H;:U&SMV9-O$WOHMF*G6%U%>O25W
M0"E:                              .EWI^*&M?)]_[.7=.EWI^*&M?)
M]_[.2!CD:]^,^O\ RQG?;UN$YNO?C/K_ ,L9WV];A-\;,U6X ZB
M                 ^F+J=W0\[$UNQ7-%>!?IR(JCSCNLB[I/N2UN_IKMOE4[1W^2.R\;HAMG4/<]8W#Q&3753I>%=KPM*L=[FFBU1/=FJ/Z4T\_.I T
MHIBBF*8\HCAJVQ&D:,TSJ .N
M                  /IC9>9I^78U'3LBO'R\2Y3>L7:)XJHKB?"8E-_V#>T
MWC=H3I%B6]8S+7^5>A41BZI9Y]_7,1'%WCV3,S'S(/%8NR;U\U3LZ=9-+W?B
MW*OW*U"Y1@ZM9_BUV:I[L53'^S-9CFNKU4TQZY0*]>
M^MVZNT'U+U+J'NB_]SJ][F9,>$S/MBF9JA9\U6J.6-945U:SH +E8
M
M            #[86=GZ5GXNKZ5DW,?.P+U&3C7;=4TU47**HJI\8^&(3C]AC
MM-8/:+Z18N3GWZ:=RZ%31@ZI8F8[TU4Q---S_>BB:OG09*R=DSM ZEVV(B?I5W*.>$Z*N64_0ZW;FOZ;NG0L'<6C
MY-&1A:A8IOV;E$\Q53,?_P#0[)C:                        $9?IC_P>
MGG]9F?\ :1JI*O3'_@]//ZS,_P"TC5;+7@AGK\4@"Q
M         >DZ9;FN;,ZD[6W7:F8JTO5+.1S$^R9>;?+*BY-BJ;,\7(\:9CU2
M#)3V_G6]3T+3]0LW(KHR,6U:8=@HUV/MY6M\]G+9&NT9'NURO3::+
MM7/,]ZFJJ/\ !65@F-)T:HV$;?I:.OU>%I>D]"=NYW=O:A,9FK3;K\8LQ/O*
M)X_VJ/UI"=Z[JTO9&U-4W7K.138P],QJ[]VNJ>(B(C_RQ\.M/4W4^LG57
M_F8_!JX_HS2A 7#]A/KY?Z#]>-,NYF37;T#
M:$Z*N64ZXV6;UK(M47[%RFNW7'>IJIGF)CX);V-H  %$>UOVB]"[.'2C/W3G
M7:*M5S**L72L::N)NWYCCF/Z//>^95_7-;TS;FD9>N:SEV\7"PK55Z]>N3Q3
M13'KE!1VR^TCJO:/ZN9VIVLJY&V-'NU8VCX\SX33'/-R8]L\S'S++='/*%=7
M+"C.YMS:]O7<6H[OW1F5Y6JZK?KR,BY7//OJIF>['P1S/$.M!L9P
M                                                 !WFQ-]:]TQW
MGI'4';%VJWJ6B9-&3:[L\=^*9YFB?;$\1X.C 9$/0WJIHO67I?H._M$R:+MO
M4<6FJ[33/,T7(YIJB?9/,2]ZB@]%#V@?\EMW:GT.W'J,_<6M_P#S6D1G=6T-KY5%>[=SVJK&-%%7-6+:GGO7
M9]GX,T_.[3$U3I#DSI&JU7TF/:]N;\W!?Z"; U&J-$TJ[$ZQF6+G'N]^FK]Y
MB8_BQ-/CX^,5>,+!Z:8IIBFF.(B.(ANJN7[URO(R\BYD7[U4UW;MR>:KE4^=
M4S[6C;33%,:0SS/-.H DB
M                                       '$3'$QS$^< "_#T8?:IJV
M!NW_ #%[TU2J-%UV[WM(NWJN8L9'\US/E$\US_@EMB8JB*J9YB8YB6--C969
MI^58U'3LFO'R\2Y3>L7:)XJHKCRF$XW83[2N+VA>C^%=U/+H_P I]%IC$U2S
M,^_JJB(_TG'LGGCYF:]1I^*%UNKREO7
M;E7%--,1[0>>HV\3 P+F(FY
MTEVB-X]I7J)D[RW)D5V].QZZ[6E8%-4^YV;'/%-4T^$=Z8B)YX]<^*H';<[7
M6L]IC?=W2]'RKEC8^BWJJ,#&B>(R:XG]^J^/BF8^+R6U^37;M\O6=U%=6O2
M!:K
M                 '<;.WAN3I[NG3]Z;1U*]@ZKIEZF]:N6ZYI[W'G35QYQ
M,LXNZ=/IBWJVGQ,T>O\
MT\T_?6U,NW5%^W3&5CQ5[_'O>55$Q\<3PR7+?+.L;-%%7-NJ2 J3
M                    '2[T_%#6OD^_]G+NG2[T_%#6OD^_]G) QR->_&?7
M_EC.^WK<)S=>_&?7_EC.^WK<)OC9FJW '40
M!*!Z'3>MS*VGO78-R?#3\VG,HB9\>[-%NGZ.91?KR/17;WC;/:+O[>(8^_7+JWJW7/JKKO4O5KE=4:A?JIPZ)JYBWC15/N=,>SPE
M(]Z6#K]?VMLK3>C.W,^;>?N.KW74/A6[-2FYJVB3-[2ZK
ME7-5W&F9YIYGQ]['ITG5?;JUC1Z8
M!2L            %D_I*^U-/2+I]/3/:.?[GNG^Q\68XKJGCRF:
M:IX^)==U1ZA:%TLV'K.^MQ95%C#TK&KO355/'>JXXII^>J8CYT '6?JSKW7+
MJ7K/4O<%VY->I7JON6S55,Q8Q^9FBB/9Q$\+;5'-.LJ[E6D:/$Q%7OJJZIJK
MKJFNNJ?.JJ9YF9^.6H-:@
M                                           :5T4W*)HKIB::HXF)
M];4!*9Z*OM+W=Q;?RN@^[]2[V?HE'NFCSF/_!Z>?UF9_P!I&JV6O!#/7XI %B
M                     3Y "7GT3&^:->Z#9NU+UWF_H&?59HH]EJ::9^NJ
M5\J)_P!$!O*C2NHV\=E7[OAJ.%1F6J9GP[W?IB>/FI2MY&5C8MBYDY%^BW:M
M4S7775/A33'G,L=V-*I:*)UI6'^E=ZYQL_IEA=)-)RN[J&[)G[I[E?C3BQS%
M43$>7CW42M%,44Q13'$1'"MW;,ZR7NMW:!W#N&F[WM/TN]5IV#$3S3%-'%-<
MQ\=5$RHDTVZ>6E37.L@":(
M                  TJFN.*K=4TUT3%=,QYQ5$\Q^N&H";?T=O7O_//T&T[
M U?-IN[@VU$:?G4\^^JBB*8IN3Z_&9GZ%TZ#WT>/7+_,OU_PL'4LJJC1=V1&
MGY-$U<4TWIYBU5\]=_1&1:M56L"S,QS=R:HF+=/'L[W'*$1KTA.9T6:>E,[4]6E:=1
MV?-EZC/W7J=OW37+MJKB;=F8_>N8_E153/S(P***:*8HICB(=ON_=NN;^W7J
MN]=R9=S)U#6,FO)N55U<]V*JIFFB/@B)B/F=2VT4\D:,U4\TZ@"2(
M                                                    #L]K;EU+
M96Z=)WEHMZJUG:-E49-FNF>)\)XJCYZ9ED$= >K>E]<.D^@=2-+KB:=4QJ*[
MU$1Q[G>[L351\W,,>28YCB4B'HENO%W3-PZOT*US-XQKRY^==OZ4/M.5;]WI:Z([0U&*]$T.J+FJW+5?
MO;V1X<6Y_H^_B86(Q$1'$-5JC2-947*M9T %RL
M
M5Q[&W: SNSOUIT[7YOUQHFLW*,#5;43/=FBJ>*:YCX*JHGYE#FE=/?IFGGB9
M\I]D^UR8UC278G1DJZ5J>%K6FXNKZ;?IO8F9:IOV;E,\Q715',3'S2Y2Q;T7
M/:,GJ'TUN]*-S:A%>O;7F*,?W2OFN]B^/=X_HTTQ]*^EBJIY9T:8G6-0!%T
M                  !8;Z8'\@&B_+%O^_:1)I;/3 _D T7Y8M_W[2)-KL^%
M1^P;$QXW)]E7OJ9CYT/5==V[:JZIGF9F?6T6K?[TJKE7E#;33313%%%,133'$1'J:@T*0
M
M        !7KL==J37.S'U'L9UR_=N[2U:[3;UC#B9XB/#_2TQ_*B(X\O7*@I
M,15$TU1$Q/JER8B8TEV)TZLD?:6ZM$WMMS W5MW-MY>G:E9IOV+UNJ)BJF?A
MAVZ(_P!&WVQKW3C7[/0_J%JG
MXH:U\GW_ +.7=.EWI^*&M?)]_P"SD@8Y&O?C/K_RQG?;UN$YNO?C/K_RQG?;
MUN$WQLS5;@#J(                          J7V9-XWMA=H38VY;5SN4V
M]2BS<=VN)LZED46,7#M57;MRN>(IIB/.9>6Z+;KHWKT
MHVKNOW6FN=4TNQDU3SZZJ8E;IZ33K;3TRZ"9>U=+SHM:SNV?N"S3$^^BS5%7
M>KCXIB/I8HIUG1IF=(U17]I;JWG];>MVY=^9.1-S$NY-6/@4^JBQ3Y1'S]Y3
M)MMT1;HBF/CGXVYMB-(T9@!UP
M                       \_-)=Z)CM 5U6-5Z#;FU'WV-'W7HL7*O&;ZBZ/?JMWM(S**[D1/$5VYYIJIGX.*IGYD:
MZ>:-$J9TG5D9#SW3[>VC]1MF:1O;0;U-W UC%HRK-43S[VJ.8>A86D
M    !2GM.]:M.Z"=&]>Z@YERF,G%L548-N?'W7(F)FFGY^)(C7H;(^O2J=I*
M=T;EQ>@VU=1G[BTFKW?6:K5?,7+GCQ:GCP\/>5(_/+PASM>UW4]UZ_J.ZM;O
MU7M0U;(JR15$3QW[451-=/SQ'"-=/-&B5,Z3JR/1Y3I;O
MW2NIW3_0]\:/D4WK&JX5J_5-/E3F/_!Z>?UF9_P!I&JV6O!#/7XI %B
M                      #T.Q>H6]>F.O4[HV!K]_1]4IH]SC(LSQ5W?9^M
M43-[9?:AU'"R-.S>K>J7,?*MU6;U'>CWU%4<3'E[%&AR8B7=9:UU57+E=ZN9
MJKNUU7*ZI\ZJJIYF?GF6@.N
M                       -;>1D85^QJ&)751DX=VC)LUTSXTW**HJIGZ8A
M/9V->M&+UQZ#;>W3%Z*LW%QZ<#-IYYF+MJ/O6\>S7?O5Q1
M;MTS775/E$1',RA7](OVENWYZ5KJGO+:&J;7P-H8NE7M2L58_W91>B:K5-7A,Q'=CU9:5TQ71515Y51,2;C(_V!N_3M^[+T;=^E
MW[=VQJN%9RHFB>8BJNB*II^:9X>@6$^B=ZUU[LZ7:ETKUO.BO4=LY'>Q:*I]
M]5CUS55S\46=&JF=8U $70                       !0+MJ=
MH3 [/71?4]>INT3J^IVZ\#3;//OJKE<=V:HC_9[T5?,KU=NT6+5=Z[5W:+=,
MU53[(B.90@^D'[05_KAURS=(TO-]UVUM.Y5AX44U>\N78F8JN<>7C$T^/P++
M=/-4C75RPMGS,[.U7.RM7U3(KOYN?>KR@W670.HN->N4XEB_38U&W3/AWM/W'I5^B[BZCCT9%NNF>8XJB)X^;R8VERBF[15;KCFFJ.)A
M+GZ*SK[=W]TPR^E>NY?>U7:57=L15/OKF-5/>[WP\37$*+U.L*O?7LBJ.*(B/7$533S\"IFKZK@:%I>5K&J
M9-&/B8=JJ]>NUU<4TTQ',S,H->V[VGM0[2/57)G3,ZNK9VA7:K&DV>>*;LQ,
M\WICRYF.[]"RW1SRA75RPHMO_?NY>J.\M4W[N[-KRM1U6_5=F:YY]RMS,S3;
MCV13$Q'S.@!L9P
M                                   &M-=VUY5;O6:Z;EJY3/$
MT5TSS$Q\4Q"8?TMTVZ:KE7OLS'B.*:X]LQ%/C
M\:'=Z?IEU)W/T>WYI74?9V1-K4M)NQ7W8GB+UOF)JMU>V)B.$*Z.>-$J:N66
M1N*:]GSK;MOKYTRTK?VWGXH:U\GW_LY=TZ7>GXH:U\GW_LY(&.1K
MWXSZ_P#+&=]O6X3FZ]^,^O\ RQG?;UN$WQLS5;@#J(
M        3$51Q,>  JOM?M7]HO96@8>U=K=3M2P=)P*(MXV-15'=MTQ'$1'A
M\#S'4CK#U.ZP96)F]3-VY>NWL"F:,:;\Q_HXGSXXB/8\>.:0[K( ZX
M                                                      -*J8JI
MFF?*8X:@)5/1,==:=P;(U+HEK&9SF[R
MKU@R^AW7?;6]+-Z;>+?R:-/S_9-F]5%$S/Q155*?W3<_&U73L75,.OOX^99H
MR+57\JBNF*J9^B89+M/+5JT6YUAR0%28        A\]*1U]N=0NJN-TKT#4.
M_HNV*(JS/KKGQFJY5-7'S<\+[-.L
M\RJY5Y.( TJ0                                  ?3#QLW4\BG#TG
MRL_(KGNTVL6S5>KF?BIB97#])NP#VD^K=FWFXVUXV_@7)\PAV8-@TQ^YO3#3,N[''^FR[<5U\^WF.%UUGT4W+?2S(LTU1$Q-VKCZI=Y1Z-OM8544U3M+&IF8YF)KJYC]2<#B(\F
MKG?5.]W"#_\ ^&UVK_\ [4Q?TZO_  X^;Z./M:8MN*[.R+.1,SXTT5SS"<@.
M^J.[A GK'8;[5^A6YNYO234+E/C^\\3S],O :UT3ZS[<[TZ]TMU_"IH_"JKL
M1,?JF615---7G$3\;Y7,/$NQ--W%M5Q/G$T1+L7Y\X<[J&-5EV,O3ZNYJ&#D
MXU43QQJW2G/N8&_-BZIIWN=4T^[Q8JN69_\
MSE,33^M;%=-6TH33,;O&C2BNBOF:*HGCSXGR:I(@
M             !5$51-,QS$^$@"3_P!$AUOKS]!UKHCK>;-S(TRN_5XS
M9F9FN(^*JN(2/L>OLV]5LGHIUNVOU!M7:J<;&RZ+6=3$^%>/5/-43\\0R!]%
MU7$US2,/6,&]1=L9EFB];KIGF)B8Y\)9+U.E6J^W.L:.: J6
M        (R_3'_@]//ZS,_[2-5)5Z8_\'IY_69G_ &D:K9:\$,]?BD 6(
M
M
M                                       *^=ACJWJ9.7-C
M2M:N1IF?X^$45U4SWI^+NIW[%ZC(LV[]J>:+E,5TS[8F.88TSUBZ!;6W;.1-W+G#ILY?-7-5-VF9CB?FB&>_3YK
MK4^2LX#.M                       :554T4S555$1'C,S/A +8/2#]?J.
MB'0G4;.FY--.O;CIG3]/IBKBNB:HF9KCX.*9CYT(%,5^-5V[5+G6OKSEZ9I^95=T+:7.#B4Q/--5SPFJKXXF:H6QMEJGEI9ZY
MUD 6(                                 -M5RBF8IFKWT^5,><_% -P
MJ)TQ[._6OK!FV\38W3_4[]N[/$9.3:G'M?I7(B)^E=]TR]$/O[59M9W5'?F)
MIMOPJKP\*B9N<>SOQ-4(S733O*44S.R/NJY11^%5$/KB6,O4*N[I^#DY,^7%
MNS5/^":?8?HRNS#L^+%_4=LW=?R[7$U7-1JIN15/Q13"OFU^A_239<4QM;8&
MCZ=W8CB;-B(E5-^/).+<^: O1>BO6;BWAXEJ(IM8MJB(\HIHB'UBFF/*F(^*$9OSZ.
M]U"#?!]'+VM$TW;,3$NQ?GSASNF-
MU3?M5S,15Q,>J8F/K;T[6_>P7V7^H%,SJ/3/3L*]//\ I\.B**XGV\SRM?ZG
M^B T3*F_F=*-_P"1I\Q$U6L;48]UIF?5'-,4K(O4SNC-N81BBNW5SL1]HSHU
MW[^N;,NZM@T\S&7ID>ZQ-,>ON4S55"A5VFYCWIQ\NQ=QKU,\56K]$VZXGX::
MN)61,3LA,3&[0!UP                                  5B[(W63,Z'
M=>]N;KB]-.F9=^G"U*CO<4U6:O*9_P![NJ.M*XJFGFBJ8JIF*J9CU3$\PY,:
MQH[$Z,EG#R\?/Q;69BW:;MF]1%=%=,\Q5$^N'V6M>CJZU1U;[/.D8FI9E-W6
MMN1^YN93,\U3W*:>*Y^.9GZ%TK#,:3HTQ.L:@#CH                 "PW
MTP/Y -%^6+?]^TB32\^ESTC,U'L[X.7C435;PM5M5W9X\HFY;B/J1#1,51%4
M>4QRUV?"HN;@"U6
M                                         ]/TJ_*KM#Y6M?XLC.Q^
M\T?T88YG2K\JNT/E:U_BR,['[S1_1AFO[PNM>;Z *%H                "
MD':EZ^:-V=NDNJ[ZS[ENO.IMS9T[&FKWU[(JB>Y''G,79\9][3\T<1\SJVVBGDC1FJGFG4 21
M
M                      72=@#M17^S[U2L[;U[*J_R2W1>ILY45U3W,6]/
M'%R(]7A''SIM<7*Q\W&M9>+=INV;U,5T5TSS%43ZX8TM=/?IXYF)\XF/.)]4
MI<_1C=J:.I.R/\S>[]0JN;DVS:B,:Y>K]]E8O'O>.?.8XJF?@9[U'[T+;=7D
MOL 9UP                        Z7>GXH:U\GW_LY=TZ7>GXH:U\GW_LY
M(&.1KWXSZ_\ +&=]O6X3FZ]^,^O_ "QG?;UN$WQLS5;@#J(
M
M                    #;-,MYV3-
MW5-N3^YF5%4\S%-$S3;_ .6A"*O/]%GUCJV+USO].]0R:J-.W;9_T5$U<4_=
M-,TTT?JJJ5W:>:E.B=)3'AYC&T       .AWYNG V3LW6-UZE>IM8^F8=S(J
MKJGB(F(\/U\ C%]+5USC7]V:1T+TK)[V-I,1J&HQ15YUU3'H>H=6NHVX>I&J535>US-N9%/,_@VYJF::8^".9>8;J*>6-&:J=9U $D0
M                              :554T1WJIXB%PW9B[$O53M)ZC;S;>)
M>T#:=-4>[:MD4<3=CUTVHXGF?CCAR9B.LNQ&NR@VAZ-K.Y]8L;>VUI65JFIY
M-44VL7%MS7$,]=Z9
MZ4K:;?JI!T?[)_0WHE@6L79NR,'[HMQ$3F95JF]D3,>OOU1WH^E5^(BF(IIB
M(B/*(:BF9F=UL1H .           ZK<6U=M[MP*M,W/H>#JF+7'$VLNQ3=I^
MBJ)AVH"Q+K_Z*[I?OBG)U_I/F7=KZU5%5<8\>_Q;U?L[O,11'Q1*-7K3V=^K
MG9]U2K3NI>V;N-C>Z3;LZE9B:\6]X^JOB(Y\O#X89"[H]W[(VGOW1K^@;OT'
M#U3!R*)HKM9%N*O"8X\)\X^9;3=FG="JW$[,;V)B8B8GF)\8%_W:Y]&3K.R+
M>?U#Z#4WM3TNF:K^1H4^-VS'G,VIGSB/'SJY\86!WK5_&OW,3+L7+&19JFB[
M:N4S3715'G$Q+335%4:PHF)IW;0$G
M &R];B[;JMU<\3[$UWHV>M/^=3L]Z;HNHY=-S5MK?_B[(IY]_53'%453^GQ\
MR%1>1Z+;JW_D#UYO[)SLOW+3]VX\VJ8JGWL7Z>:^?GBF(5W:>:E.B=)3+ ,;
M0                    C+],?\ @]//ZS,_[2-5)5Z8_P#!Z>?UF9_VD:K9
M:\$,]?BD 6(
M
M                                                     "2+T075
M>Y9RMU=(-3S)[D<:E@6Y^'NT3$?HRC=5?[(O4V[TE[0^TMT1[W::HIF/BGA79
M$;Z6'K37NOJCI?2/2LNFYI^WK,967W*O"J]7W9IB?AIFF4[=/-4C7.D+%;N1
M?S,B]G9=@W8?Z\=?+N/J&DZ!7HFW[LQ-6I:A3-OO4>VW3,<5_2DDZ$^
MC3Z$])9L:ON'#KW9K=$155?SZ>]9[WP6JIJIA=KA8&%IN-1AZ?B6<:Q;B*:+
M=JB*::8^"(?=FJNU5+J:(AP]+T?2M$Q*,#1]-QL'&HCBFUCVJ;=$1\$1X.8"
MM,           !LNVK=ZW5:O6Z:Z*XXJIJCF)CX5OW7+L-= ^N>+=N:QM6QI
M6J54S[GGZ;1%BNFK^55W.._\\KA!V)F.L.3$3NA0[17HY>M'16K(UW:>/7N[
M;-KO5>[8UN?NJU1'KJMQSX<>OE:?%7OZ[55-5%RU5-%RBJ.*J*H\XF/5+)W-LFW9VONRBB:J;V/1Q
M9R:O9\JE=5OT0R#UW5+I/O[HONO)V=U$T&_IV99KFFW=JI_T
M613ZJJ*O9X>OQ>1:-U(                                 "\;T776&
M.G77>_LO5<[W'2=W8WN=,53X1D4155'TS-,)F&-GM?<6=L_=>B[MTV]5:R-'
MS[&7%5,^/=HN4U51\\1+(>Z3;WPNH_3C;V\\&_%VC5-/L7ZZHGRN56Z9JCYI
MF6:]3I.JZW/31ZX!0M                  4>[6W3&>K?0+=>T;=JFN_5AU
MY=B)CQ]TLQ-RF(^.:8A %-B]AW;NGY-$T7\.Y5C7J9\Z;E$]VJ/IB62Y713<
MHJMUTQ535$Q,3'A,>Q#9Z1WLJZCTBZC9/5+:>EW+FT]QW)O955NCPP\JKQJY
MB/**IFN?F7V:M/PRJN4^:S8(F*HYIGF)&E2
M
M ]7TAL5Y75W9F+;_  [NKVHI^B9_P9&%J.[:HIY\J80!]C[:M>\NT[L'2**9
MJ]RU#[HJCX(MUI_J8XB(]D,U_>%UK9J H6@               /EDY-C#QKN
M7DW(MV;%%5RY7/E333',S/S0A%](!VE+_7WK#D:/HN95.U=K7*L3%HIJYHO7
MZ9XN7/9/C1X?&OP])5VFZNCW3#_(':^91&Y=U15C^\J]_CX\_AU_/3WH0W44
MS33Q57-=4^-54^=4^N9^%HLT?O2IN5>3< T*@
M           )F(CF9XB'>;/V)OCJ'J-O2-B;4U'6\NY5%,48]KWL<^N:JN(X
M^<==&VW;UJS3W[MRFBGVS*^?I#Z)[JSO/'LZGU.W'8VMC53$U8EF.]D]WX>:
M:J?UKS.E?HV.S;TXHMWM0V[7N3-HB)]WU"NKS]O=IF(_4JF[3"46YE"YH6@;
MBW1D48VVMO:CJERO\&,6Q-SGZ%6-N=C+M1;KHINZ3TCU6S;KXXKS;5=F/[LI
MU- Z<;#VOC48F@;1TK"MT?@Q;Q:.8^>8Y>BHMV[5/=MVZ:(CU4QQ"N;\^4)Q
M:]4*V@>B\[5&M415F86BZ9,QS,7<(S:GR0;"03JSZ(K>
M6A6\C4^D>][>K6:>9HP-0I[MV8]E,T4\?3*ROJ)T=ZJ=)=1NZ9U%V/J6D5VJ
MN[[K7;[UNOX8FF9_6MIKIJV0FF8W>/&E-5-<][Z7E"8B8XDW&11T:ZI:!UEZBNN*9_>[O=COT?-,S'
MS/;(B?1=]IBOI]ORKHAN;,FG1-QU^Z:;SO37^I+K$Q5$54S$
MQ/C$PQ5T\DZ---7-#4!!(                      =+O3\4-:^3[_VMPG-U[\9]?^6,[[>MPF^-F:K< =1
M
M                               '<[+WAG]/MY:)OG3+DT9.B9MO+HJC
M_9GR=,TJIBNF::HYB?4#([Z;[LPM];#T+=VG7._CZIA6[]%7M\.)_7$O2+*?
M17=6XWST'G96=E^Z:AM._.)W)GFKW&8BJ*I^>OA>LPU1RSHU4SK&H BZ
M+'/2L=9[FQ.C6+T\TO+FWJ&\+WN%RFF?'[GIYJY_2M\+XT('I%^K\]5.T?J>
MF8N5[OIFTZ/W.QN)\(JGBN9^/FN866J=:D+DZ0M?IIIHIBBB.*8CB(:@V,X
M                             >^FJFW;MUW+ERJ**+=%,U55U3X1$1'C
M,S)$5U5T6K=%5=R[5%%NBF.9JJF>(B$GO8!]'_3H]&%UIZVZ3%>I7*8NZ7HV
M3;YIQJ9CF+ERFKPFOQ\IB>)I\T:ZXHC64J8FJ=(>+[%7HW,K=].%U1Z^8,VM
M)J[M[ T&Y'OK\><5WHGGPX_BS$3XI1]%T72MNZ5C:)HF#:P\'#MQ:L6+5/=H
MHICU1#F4446J*;5JBFBBB(IIIICB(B/*(AN8ZJYKG65]-,4[ "*0
M         #28B8XE8[VV?1Z:!U>PLSJ+TGQ,?2-Y6J:KV3:IIBFUJ-,1XQ,>
M'O\ X9GU1'"^,=IJFF=8)\)B)X^%PTQ';][$.G]:]!O\ 4OIWIUK&WOIEN;ERBU1W:=0M4QS--41Y
MU\1/$\3,S4A[R<;*PO'R\.[58R+-<<56[E,S%5,Q\<2V45Q7#/53
MRR^8":(                              [C9>Y]-!W?IUV;>1I.?
M9OQ5'\GOQ%7_ "\NG;;E'?HJHYXYCCGV R/>G.[\3?VQ=#WEA7*:K.KX-G+I
M[L^7?IBKC];T:S'T675&K>_9[HVMF7N_G;7RJ\6KO5X^5OXHXIE>J\N]31,TQ\\\0QXNH>]M0ZD[^U_?NIW)KO:UGWLFF9]5NJN9IC
MYHE+%Z57J_RAU$[4&
MYHPMNV:]/V]B7(_=#5[U$Q;II]=-OGCOU>/JF?6[7LA]D/=?:CW;;JKLW\'9
M>#=C]TM2B)CW3B?&U;GVSQ,3XQQX)MNF_3?:/2G:>#LW9>D8^!I^%:IMQ%JW
M%,W)B/&JJ8_"F?'QE3;
M5$3?RJO;75$1RJH#-,Z]97Q&@ X                  *7]?.SMTW[1&T;V
MU]^:/;O5TT53AYE,1%W%N\>%5,S$\>,1S[80F=I/LS[^[,F]*]M[JL5Y>E9-
M556G:K;HGW*];Y][35/C$5\3'A,^/CX,@-X'K9T4V1UYV+G;$WOI]N]C95$Q
M:OQ1$W<>OB8BNBKSB8Y]4PLMW)HGV(54V!VFM/T&_>BG W58JPJXJJXI]VFJB*/GXFI7G.OX=5JJ:9KHP;MVW/Q54T\3#(P<+4=%T;5Z/
M<]6TG"S:?Y.18HN1_P T2NIO3&ZN;<3LQL*K.;;\;NF9UK^LQJZ?KAMXN_\
MIK__  JF1=F='^E6?1-&5TYVU7$SS/.E6//]!P_\P_1K\V6V?_:K'["??QZ(
M]U/JQW>+O_IK_P#PJCB[_P"FO_\ "J9$7^8?HU^;+;/_ +58_8/\P_1K\V6V
M?_:K'[!W\>AW4^K'=XN_^FO_ /"J.+O_ *:__P *ID1?YA^C7YLML_\ M5C]
M@_S#]&OS9;9_]JL?L'?QZ'=3ZL=WB[_Z:_\ \*HXN_\ IK__  JF1%_F'Z-?
MFRVS_P"U6/V#_,/T:_-EMG_VJQ^P=_'H=U/JQW>+O_IK_P#PJCB[_P"FO_\
M"J9$7^8?HU^;+;/_ +58_8/\P_1K\V6V?_:K'[!W\>AW4^K'=XN_^FO_ /"J
M.+O_ *:__P *ID1?YA^C7YLML_\ M5C]@_S#]&OS9;9_]JL?L'?QZ'=3ZL=W
MB[_Z:_\ \*HXN_\ IK__  JF1%_F'Z-?FRVS_P"U6/V#_,/T:_-EMG_VJQ^P
M=_'H=U/JQW>+O_IK_P#PJCB[_P"FO_\ "J9$7^8?HU^;+;/_ +58_8/\P_1K
M\V6V?_:K'[!W\>AW4^K'=XN_^FO_ /"J.+O_ *:__P *ID1?YA^C7YLML_\
MM5C]@_S#]&OS9;9_]JL?L'?QZ'=3ZL=WB[_Z:_\ \*HXN_\ IK__  JF1%_F
M'Z-?FRVS_P"U6/V#_,/T:_-EMG_VJQ^P=_'H=U/JQW>+O_IK_P#PJCB[_P"F
MO_\ "J9$7^8?HU^;+;/_ +58_8/\P_1K\V6V?_:K'[!W\>AW4^K'=XN_^FO_
M /"J.+O_ *:__P *ID1?YA^C7YLML_\ M5C]@_S#]&OS9;9_]JL?L'?QZ'=3
MZL=WB[_Z:_\ \*HXN_\ IK__  JF1%_F'Z-?FRVS_P"U6/V#_,/T:_-EMG_V
MJQ^P=_'H=U/JQW>+O_IK_P#PJCB[_P"FO_\ "J9$7^8?HU^;+;/_ +58_8/\
MP_1K\V6V?_:K'[!W\>AW4^K'=XN_^FO_ /"J.+O_ *:__P *ID1?YA^C7YLM
ML_\ M5C]@_S#]&OS9;9_]JL?L'?QZ'=3ZL=WB[_Z:_\ \*HXN_\ IK__  JF
M1%_F'Z-?FRVS_P"U6/V#_,/T:_-EMG_VJQ^P=_'H=U/JQW>+O_IK_P#PJCB[
M_P"FO_\ "J9$7^8?HU^;+;/_ +58_8/\P_1K\V6V?_:K'[!W\>AW4^K'=XN_
M^FO_ /"J.+O_ *:__P *ID1?YA^C7YLML_\ M5C]@_S#]&OS9;9_]JL?L'?Q
MZ'=3ZL=WB[_Z:_\ \*HXN_\ IK__  JF1%_F'Z-?FRVS_P"U6/V#_,/T:_-E
MMG_VJQ^P=_'H=U/JQW>+O_IK_P#PJCB[_P"FO_\ "J9$7^8?HU^;+;/_ +58
M_8/\P_1K\V6V?_:K'[!W\>AW4^K'=XN_^FO_ /"J.+O_ *:__P *ID1?YA^C
M7YLML_\ M5C]@_S#]&OS9;9_]JL?L'?QZ'=3ZL=WB[_Z:_\ \*HXN_\ IK__
M  JF1%_F'Z-?FRVS_P"U6/V#_,/T:_-EMG_VJQ^P=_'H=U/JQW>+O_IK_P#P
MJCB[_P"FO_\ "J9$7^8?HU^;+;/_ +58_8/\P_1K\V6V?_:K'[!W\>AW4^K'
M=XN_^FO_ /"J.+O_ *:__P *ID1?YA^C7YLML_\ M5C]@_S#]&OS9;9_]JL?
ML'?QZ'=3ZL=WB[_Z:_\ \*HXN_\ IK__  JF1%_F'Z-?FRVS_P"U6/V&VYT+
MZ+VJ*KMSIIMBFBF.:IG2['$1^@=_'H=U/JQX.[M?
M3SJ!U"_S?]*-JZ+IN@;8NU6K^9@X5JS7EY$<\\U44Q,Q',QY_P 5:PNB=8U5
MS&@ ZX                               VWKM-FU5=KGBFB.9!>_Z)SI
MY&Z.M^L;VO6.]8VWA=RW7,>5^:J/^FJ4P*S[T8_1>[TOZ!6=P:GC1;U+=EW[
MON=ZGBJFB.:*8Y\_&*8E>"QW)YJFBB-( %:8              Z;>.ZM'V1M
MC4MV:]ET8V!IF/5D7KM<^%-,?_IX=RC@]*[VC:]+TG"Z!;8SIIRM5I^Z-8FW
M5Q-%B.?]'/'MYIE*FGFG1RJ=(U6$]HOK1JW7[J]K?434;U4#;$:=(9MP!UP
M      !I55313-=RIJCW75;M$][(I\YILQ/A5X<>/,>:
M7SH5V:>E/9[V]:T38>WL>B_33'NVH7K<5Y-ZKUS-R>:HB9YGCGA57=BGI"=-
M$U+&NSMZ)R[?C&W)V@M9[]%?=N1HF%5$1$>RY7S535\7$)#.G72;IWTGT:WH
M/3_:F!HV';IBGN8UJ*>]QZYX\Y>N&:JN:MUT4Q3L (I          #I=U;-V
MMOC2KNA[MT+$U7 O1Q78R;<5T5?,[H!'KVB/11;/W';R=P="-1C;NHSWKLZ;
M>XJQ;M7\FF([L4?/,HVNJ/2+J/T7W#>VUU'VQEZ9?M5S13D3;F<>]\-%V([L
M_-,LB]X[J=TDV!U?VYD;9W[MW#U+%OT31%5RU3-RUSZZ*^.:9^*8747ICI*N
MJW$[,=*)B8Y@7F=K/T<&]NBM>3O'I/;RMR;0MQ-V]8[LU96'3YSX>/>IB.?&
M9CR694UQ7S$]]1=ICPGCS\:>[/SH'ES/H_>T1=Z"];<73=3RIM
M;:W;7&%G\^--JYX33I&V=XX=V:+FEZE9KF8GCFFJJ*:N?FJED3[7U[$W3MW3MQX
M-458^I8U&3:F)YB::HYAEO4Z3JOMSTT=H I6    /#=;^H&+TNZ4[EWWE7Z;
M7[D8%W(MS5/'>KIIF8C]3'EUC5LG<&M:CK^;=7-4\?JX2T
M>EGZG4[_3'G-BCFFO\ OPB+IIBFF*8\HCAJLTZ1JHN3
MUT:@+E8                            TKKHMTS775Q3'C,M5SO8/[*65
MVC>I%K6MQ84SLG0+M-S.JJI][E78GPM1,^$QX51/FY,Q3&LNQ&LZ*[^CC[#_
M .[]_%Z\]6M)_P#E+4]_0M-OT_ASY>[5Q^E$?-X)2***+=,46Z8IIICB(B.(
MAQ]+TS!T;3L;2=-QZ;&+B6J;-FW3'$4TTQQ$.4Q5U37.LM--/+&@ BZ
M                 TF(F.)CF)1C>DS['%&'[KV@>FVF=VFB/_Q[@V*/PHX_
M?HCX.[X_#4DZ7[EA[DPIN6Z9GPJNVHGC]=:89CM]!]\W.FW6G9V\Z+DT4X6J6*+TQZ
M[55RGO1\\0R&=(S[>JZ3A:I:_ S,>WD4_%73%4?6RWXTG5?;GIHY8"E8
M              C+],?^#T\_K,S_ +2-5)5Z8_\ !Z>?UF9_VD:K9:\$,]?B
MD 6(                                       $S%,Z[>G
M6*N[7.FZ?,3N1:L47+U<^$4VJ)KGZ(
MY>_V5T ZW]1;]NSL_IGK&91>_ O5VHM4?\\PFHZ6]B/LX=)::+FWNGV%E9=,
M1_\ -Y]NB]>YCU][NQXJY8F)C8-BG%P[%%FU1'%-%$<1$*9O^D)Q:]4-.S/1
M9]I+HJB)JIRIJKJB/]SO0J_H7H;LSO47-R=8*JHG\.WB6^(_Y
MK:3T0F]5*<6Z5@>E>A^Z+VJ(C5][;AR*N/&;\J]7>2GT645>B<[-]4\QE:U3X>45T?^'7ZEZ(OL^9DS7B
M;@W#B5=WB(HJM<<^WQIE?.'>5>IR4^B-[<'H)/J]WIHF/U6
MU,-W>B*ZP:+:KO;5W[HVL=WQBW=HN175_P L1REP'8NU0YR4H$-_]B?M.=.*
M:K^L=,\S,QXYXNX=5%<3'MX[W/ZE&=3TS5M$OU8NMZ3FX%ZB>*J,C'KHXGXY
MCADJ^;P74#H3TDZHXES%WSL32=5]TB8]TO8]-5RGGUQ5,>$IQ?GSA&;7HQW:
M:J:HYIJB8]L2U2L=9_1)]/-(]L551$5?-+
MDS$;N[J63,1',S$1\+ZX6+FZG>C'TS RLRY5,1%-BQ7GVE8-=KRR(Q
MZ?=I^.J(CE55>IC9.+$0U5S>J\DXMPC
M4T#T-^EVJHG\TST0W0;&[E>H[IW%E5TSXQ-5J*9_Y
M5]XAWE7JER4K*(]$YV;XJB9RM:F(]7?H_P##2?1-]G"9Y^Z]:^+OT?\ A>P'
M>5>IR4^BPS5/1!]"K]-=6F;MW%C7*IYB)FU-,?\ (\!K_H;\>NNJO;'5W)L1
M_%HRK<3'S]VVDR#O*O4Y*4.>]/11]H+;M-=>VM:T;<%$<]VFW%=%R?TN["WK
M?G9C[0/36]7;W9TOU:W;M\S5?L4TW:(CV^]F99"+9=LVK]NJS>MTUT5QQ53,
MJC=&;<,:6_3Q[D>=-ZW5;GZ*HAHGXZH=D#L^=7;-R-V]/
M-.G)NV'U-VKO"Q5--6F:M
MC7:N)X][%RF9^;P9$VV=5HUW;FEZU;KBJ,_#LY/,3S'OZ(J_Q9K\==5]N>FC
MLP%"P                  :3,1',M7GNH.Z<+9.R=:W7J%?GX^*H6ENWWEN;*WK
MO+7=X9MR;E_6,ZYDUU3Z^9X^J'4-],U;/FGWEFU$^-,3_*GCCYU/
M-F[.W%U#W9I>Q]I8=>5JVKWZ;%BW33SQS_&GV1\*=WLI=G';79OZ7X&U=+QJ
M*M5OVXO:KF<1WK]^8CF>?9Q$>'P*[E?)'M3HIYI>\Z6]+]H=']EZ?L;96EVL
M/3]/M4VX[M/%5RJ(B)KJGUS/',O6@QM                        "B':S
M[-&VNTGTTS-NZA9MV=9Q;=5[2\WN^_LW8\HY]DQ,Q\Z"?>&T-Q=/MU:ELG=V
M#7AZOI-ZJQD6JHXYF)X[T>V)\62.CY]*!V4;>[]M1UUV)I$5:_I%/=U:FW'C
MD8L3^%Q'C,T\UU3/BNM5Z3RRKN4Z]813C2BN*Z(KCUQSQ[&K4H
M                    ';;1W7E[%W;HN\\&Y-N]HN=:S*:H]7.Q]#W/@W/=+&HX-J]35[9[O$_KB7H5IWHT>ID
M]0>S3I.!D7YN96VZZM.N\SX^T*^D6Q=2B-T[AM31DW;-7OL/&JCBJ9]DS%7A\2XWM-=?\ ;/9VZ8:C
MO77;]/W3-NJSI^/%7OKV1,<4Q$>OB9B9^"$#._-][DZG;RU3?V[\NK(U35[U
M5ZY,SS%NF9F8HCX(YX76J.:=95UU:=(=#'>F:J[EMFA[(HQ;E>EV
M+U.9JMV(][1CT51WJ9GVS$S]"E&'A9NIYV+I.F8U>1FYUZC'Q[5%,U55W*IB
M(CB/AF$VO8)[*^-V=^F%K.U[%HJW9K]-.5J%Z8CO6J9B9IM1ZX[L53$_$KN5
M\L)T4\TKEM#T?"V_HV%HFG6J;6-@V*+%JFF.(BFF(B/J3ZI]1=#Z4;!UG?NX._533,Q1'PSQPQ]>J'4/6NJ_
M4/7>H.NY-=V_JN77N9D"9XXB*:JJJIXIIIC
MF:I]D1'FOZ[$7HZ-1Z@5X/57KA@W,+0Z*XO8&BW(XKRX]5=SV4^?AS$^3T78
M [ -S5+N!ULZUZ3QCTS3?T?1[]/GZZ;MRF?]V8B8CSE*!9M6K%JBQ9HIHMVZ
M8HHIICB*:8CB(AGN7?*E;11YRXFB:'I&W-,L:-H6G6,'"Q:(HM6+-$4TTQ'L
MAS@9UP                 #9>LV'-7X7$S,^,QX(?=5TO5-!U7,T'7,"[A:CI]ZJQDX]V
MF::J*Z9F)\)]7,3XM=%<5PSU4S2XH":(
M  3-RF:;EFN:+E%45T51YTU1/,3], ";#T=?:&M=:>B.#HFLZA%[*^@77G2]5R[]5.B[AKHTS4:.>*>:YFFW7/
MQ57.?F3M8F58SL6SFXMR+EG(MTW;=<>55-466BBK6'V 5I@
M               #I=Z?BAK7R??^SEW3I=Z?BAK7R??^SD@8Y&O?C/K_ ,L9
MWV];A.;KWXSZ_P#+&=]O6X3?&S-5N .H@
M           $S$1S,\1  [S96Q-[=2-5HT786UM0UO*KGN__ "MBJNW1_2KB
M)BGYUZW1KT3/4O<_N&K=6MRXV@8=R(N?<6+,7+TQ_)FNFKWL_'"-544[I13,
M[+"_=*.]W*9FJJ?#NTQ-4_1#U>U^E'5+>]VBUM#I]K6I=^>(KIQYHICYZ^$T
M?2_T??9FZ81:R,78UG6,VW$=[)U6*4)Q;]4*.RO1L]J3=M-N]G;=Q-"L78B8KS:XJXCXJ*IE6
MC0/0Z;TS+5%W&A^AWZY1;CGZ:'KL+T2/9VQ::J;NL;@R)GUW*K?A]%*^$1FY5/F[R4^BRB/
M1.=F^(JB'ZGSN^B8[.5RU5;IU#7*)JCB*J:[?,?%X+VP[RKU.
M2GT6 :MZ'SHY=HF-%WSN#'JX\)N>Y3X_-0I[KGH;M4H[]S;?6"/]BWEV_#_E
MMI01V+M4>9R4H8-Y^BW[2NVHKKT/]RMPT4\S$8LU457
M[EG=W3/6,2BU^'>HM1=HC]"99$+Y96+C9MBK&R[%%ZU7'%5%<3&EN3-FY-K(MW+-<3Q--VB:)^B8AJGKZG]BKLY=6+=<[CZ=:?8R:^9G*P;5
M%F]S/K[W=GQ63=9_1&[BT^;VJ]$]WT9=J.]53IVHS[^*8\>(N35$?J6TWJ9W
M0FW,([1ZSJ/TGZD=(M5KTCJ+M#/TBY15-,7KEJJ;%?'\FYQ%,_2\E3535$54
MS$Q/KA;KJ@U '                                    &V[$S;F:?PH
M]]3\<>,)Q_1W=1ZNHG9AVU=RLJ+N9H],Z9>IY\:?C:+GZQ=X[
MF#BWG:,M;:PLJJYA;8P:+AZ?;#W!U0WMH^PMLXE=_.U?)H
ML^]CGW.W,QWZY^*GF?F3Z]GSHKMWH)TOTCI_M_'MT_K
MUG2%]NG2-0!2L                          6_=MCL]Z=V@>B^IZ1%BC]
MV-)MUYVFWN[[ZFY1',TQ/GXQ3,?.@EOXN9I^5?TW4;%5G,P[M5C(MU1Q-%RF
M>*H^EDM54TUTS15$335'$Q/KA"]Z2[H'5TGZUSOC1L/W/0=X15?]['O:,J)Y
MN?%S-_HGV51Y2GZ['>_Z.I'9XVAN*;WNEV,*,:[//,Q5:F:/']% 3,E.XMCY6157?T748FW3,_@VZXFJ>/GJA3>C6G59;G24@0#*O
M                  1E^F/_  >GG]9F?]I&JDJ],?\ @]//ZS,_[2-5LM>"
M&>OQ2 +$                                     %2^@O9YZD=HS=MO
M:^P],KC'IJBKKJGV0D&[,OHJ]4UVWB;N[06;'/$0N#\
MF>N],]*5M-OU>6V%TPV%TQT>SH>Q]L8&E8MBF**?<+%--=4?[5?'-7SR]2"A
M:            .)JFD:5K>'[%W_3F;NZ.WJ=N;@JBJY.'X_,4<_P"S2B\ZE=+=_P#1WI]55$^N)\/I9&JFW6_L_P#37K]M7(VOO[0K.33KCPJHJ]L?#RNHNS3TE75;B=F/4*]]JKL>]0.S!N&J*+O'E/A/CQ$>2@D3$QS$\PTQ,3&L*9C3I( ZX
M                               TJJIHB:JIXB :O7=+^DO47K1N*WM?
MIMMK)U;+JJB+ERBF?PMOWM):C8U[6[=_0-E6JXF[EW
M*.[B/3GH?MBSM;I]MW&T_'MTQ[INV\'5,6_1-N?=[%-55,3_ ":ICFF?B1K]
MJ'T6&J;?M9>\>SYD7,W&IFJ[=T._5,UTT^?%JKWTU3QZIX\DIS28B8XF/!*F
MN:=D9IBK=C5ZIIFJ:'J>1HFNZ;D:?J&)7-N_C9%'=KHJB>)B8<9.-VL.P[TY
M[2>D7=0Q\:QHF[K-'&)JUJCB9GCPIN1$3S3Y>4<^"&SJ[T?W[T-WEE;)Z@:1
M=Q,FQ7,6,CN_Z'*H]55%7E\W//A+51
MM8GW)=\>9B;54T1S\U*!>8B8XE*WZ('>_P"Z72KS5JNE8F3
M[EF[DN1IMN(GQXJBJ9G_ )5VZ*3TOV_YU+?NT>G>-=JBC Q:\W(IB?":N]''
M/S5)VXUJA&N=*4?5NB**(IICB(AN!M9@                           !
MI]%N9_P!K
MNU0Y,Z1K+L1KT7S>B[[*T;5V_7UUWMIO=UG5H[NE6KM'/N&/S^''/E,]VF8G
MX4A;AZ/I6#H6E8>C:;8ILXN#8HQ[-%,<13113%,1]$.8Q55F@])
M5T M]6^A^7N[1\&+NX=H4SG8U5,>^KL4Q,UV_;/,]WZ$+U%4U4^^IFFJ)F*H
MGU3$\3^MLMU\^G67DS%&99IU'&M\^'>YMT3X?-*5! UV%]_P ]/>U#M#.NWJJ,;4KU
M6#>B)XBJ)HKF(GY^$\K)>C2K5?;G6 !4L
M                                       ' US6]+VWI&7KNM9EO$P<
M*U5>OWKD\4T4QZYEST8/I/>UW7F7:^SWT^U+_151WM>R[%?/AQ^\Q,>V*HF?
MAI2HIFJ='*IY8U6O]M+M.ZIVE>J>5DXN37&T]$NU6-(L<\4W(CGF[5'ES/,Q
MZ_*%O[2FFFBF*:8XB&K;$13&D,TSKU '7
M   !I55313-54\1#5F?_ "M,?_B#%O4'
MGXTI1G7Z#H6E;9T?$T'0\*UB8.#:ILV+-N.*:*8\HAV#%75-*L73-(Z&;?S>+V?,9FJS;K\8M1,]VBK_>HCZ4J*>:='*ITC5'5U(Z@Z
MQU7W]KG477;M5>5K677?I[T\]RU-4S13'LB(EYPB(B.(CB(&[9E
M                       :554T4S55/$1ZU^WHZ>Q)5U$U+&ZV]5-)KC0,
M2J+NBX5VGB,NN/*[5'\F.8F//QI4:[#_ &5-0[2O4>UEZOCW+>S="O4W-2NS
M3Q&35'$Q:IGU^?/S)O\ 0M#TK;6D8NA:)A6L3!PK46K-FW'%-%,>J%%VYI^&
M%MNG7K+F6;-G'M46+%JBW;MTQ31113%--,1Y1$1Y0W@S+@
M       !8GZ0SL0XG5/1/;BFG4+41X\Q'\?WL<>'C
MS/BOL:33%4335$3$^<2[35-,ZPY,:QHQI+EN]8O7<7*LU6;]BN;=VW7'%5%<
M3Q,3#:D,])7V,Z=KYUWKUTOT>8PY5Y>[4Q[/P(GS\Y1Y4U4UT
MQ715$Q/C$PVTU15&L,TQRSHU 2<                              :5Q
M5,HJCSIJCRF/BE-?Z./K]_FW3S
M3:JG_MY-BWD6:N]1=HBNF?;$QS#Z,;0                    .
MEWI^*&M?)]_[.7=.EWI^*&M?)]_[.2!CD:]^,^O_ "QG?;UN$YNO?C/K_P L
M9WV];A-\;,U6X ZB                                    !,Q$NJ?/RY\G)F(ZR[$:J8:'
MH>M[HUC'V]MK2S3\TRO8[-G8[Z4=G#0[5K0M(M9VNW*(^Z]6R*8JO7*O7QY1$
M>$>I7EGKO3/2E;3;\Y>-Z<='^G'2?1[.B[$VI@:98LTQ3%=NS3[K5_2KX[T_
M/+V0*-UH             #S>]^G.R.H^DWM%WIMK U7%O4S15&18IKJB)_DU
M3'-/S(Z^TQZ*><>C-W?V?-0J[T1-ZYH>55,TU?!;J]]5,_!X).!*FN:=D9IB
MK=C9[EVUN39>N9&V=WZ)E:1JV)5--[%R:.[73+K4^':/[)'2OM(Z#J6*8IO6:^/>\SQQ,<^?AY>9KMTU3];MV!J  %+>T]N6K:?0?>>L47)HKITG)M4S'\JNW5
M3'UJI+>>WU-5NN:9]RM1S'L[\.T[PY.R"6U75=I]WKGFN],W*Y]M5
M7C/ZVY\\;_5[7]"/J?1O90                           !4'L_=)M1ZX
M=8MN=.,&W,V<[)IKS:^/"W8I\9F?GB(^=3Z9BF)F9XB$I'HE.AE6D[7UCK5K
MV!W
MSWK>/B8L7-5T.B=3PJOXT3:B:IICX^(7)OCEXN/G8UW#R[5-RS>HFBY15Y54
MSYP[$Z3JY,:QHQIJ8N4=ZU=B8N6JIMUQ/JJIGB8^F&JK7:OZ67^CW7_=>T:K
M7@ ZX
M     +V/1/;ZIVYUYU3:=^]W;.OZ?5-%'\J[%5$1/T1*R=5WLA;NG8W::V%K
MO>XHN:C3C7/'B.[5%4^/SQ"-<:TS"5/260"-EJOW2U1?UF9_VD:K9:\$,]?BD
M 6(                                   *O=F+LU[K[3G4.QM/2+=_&
MT2Q5%6K:G33[VQ;YCFF)_E3'/'Q.3.D:R[$:NV[*'9,WKVH]V?IU4S$<>'^CM^7>JGF/*?:FPZ.]&=B=#=FXFR=A:1;P\/&IB*ZXB/=+U
M7$1-5=7'OIGCSERNE/2W:?1_96F['V?IEG$P]/LQ;FJBB(JNU>NJJ?.9F9GS
M>P9*[DURT4TQ2 *T@                 '0[WV/MCJ)MK-VGN[2/KCGUH6.VIV,]?[,>Y;FOZ':NYFPM1O=W#R)F:J\2J9\+=R?9XT
MQ$SQSXIQ7F^H/3_:_4[:>H;-W=IEG-T_4+-=JNBY1%7=F8F(JI]DQYQ/P)T5
MS1*-5/,QQ8F)CF)\)%:^UGV9=P]F'J5>VYE4W?QY551/E1SSZI_!=;Z/SL4976[7L;JMU"PKEG9NDY$58V+=IX_=
M&[3/]R.[,3X^N$PVGZ?A:5@V--T[%M8V+C41;M6K=,4TT4QY1$0HNW-.D+:*
M->LOCHNBZ5MW2\?1=#P+&%@XE$6K&/9HBBBW3'E$1'A$.<#,N
M       %(^TAV;-@]I#95_;>[=.M_=UJW,Z?GTTQ[KC7/5,5>?'GX<^N57!V
M)F.L$QJQX.N70_>_9[W]E;!WOBU=^W,U8>933Q:R[7,\54SY<\1S,Q=X:?NGEET("Q
M                              7P^B6WM1H77#6]IW[G=M:UI\W**?Y5
MVFJW3'ZN5CRMW8EW93LSM3;%U2[M:?19QK4
M>S_14<_KA.>Q]>U7T;OJJY7-4QJ$QS/Q+K$=55W92L!J4@
M                 -*YJB.**>:JIBFF/;5,\1'TIJ/1O=GZST?Z(8>Y=6PJ
M:-P[KIISLJN8]]3:JB*J*/;XF:?=IS]1JXYIB
MW3SW>?\ >BGZ4]V)B8V!BVL+#LTVK%FF*+=%,<133'E$0SWJOW5MN/-]@&=<
M                            X^H8.+J>%?T_.LTWU=7N[>W9H>X,>ON7=.U"Q>HJ]GOXB?U3+(NV+N&SNW9
MVC[FQZXKMZGAV\FFJ/7%4JKFD 6(
M                          $4W+E=%FQ;JN7;M<6[=%,[GZL;WTOIYL[%JOZIJUV+=/$4\W9KZ";9[/'3'3MC
MZ!C41?BW3=S[\1'>OY$QS5,SZ^)F8CX%O?HX>R-:Z/[*HZG[VTV/\KMPVZ;E
M%-VCQP\>8YIICV3,5>/Q+VF2[7S3I"^BG3K( J6                .GW?N
M?3-F;8U/=6LWXLX6EX]>1?KG^+3'K8^'6_J;J'63JUN3J/J-ZJO]T\NO[GIG
MRHLQX1$?/$S\Z3STJ_7.-D])\?I7I.95;U3=U7=N]RKBJG%CF*_US2B+HIBB
MF*8CPAILTZ1JIN3K.C4!>J                              'INF?3C<
MO5[?FD].=I8]5W4-7O4VYJB.8LVN8BNY/LB(GEYBNKN4S5QS[(]L^J$M/HON
MR];V'LF>M>[M-[NX-QTV
MN@?3/2]@[3A9]FJQ?M7*8FFJF8]DH+>VAV9=
M0[-/5C*TW!Q+G^26LUU7]&R)YFFB.9F;,SYDFI;0
MS<>F-3Q[=65I>1$>_MY%,=ZF(GV554TQ*RW7R2A73S0@+'/U_0-7VGK^I;5U
M_$KQM1TG)N8F1;KCB>]15-//Q3QRX#8S@
M  #2N+G$56;LV[M$]ZBNGSIJCRF&H"<[L%]>;/7/H-I.7F97NNMZ)1&GZE%5
M7-4W*?&)]O'=FE<@A:]&AUTHZ3]TWNVG6=9IO8&R
M=(NTU9F3W>/NNJ)C_14>WS^#RER9BF-9=B->D-_8U[$VZ^TUKMK7M=M9&D[$
MPZXJOYLT335F\>/N=ORYB?")F.?"I,WTYZ:[-Z4;6Q-G[&T7'TW3<.BFBFW:
MHB)KF(_"JF(\:I\YGVR[+:NU-O[)T'$VSMC2[&GZ=@VXMV;%FB*::8CZY^%V
MS'77-RQN+LO=0+ND^Y7\O:>?7-6D:E7'A-//[U7/\J([OTM5JYS=)W45T
M:=84+ 7*P                               !\LJ)G'N=V>*N[/$^R7U
M)B*HF)]8)Z.Q'O6G??9KV?K$WHN7;6)]R7/'QB;4S1'/Z*NRPST1.\*M7Z(Z
MUMC)OQ-[1=2[M%'/C%%??J_QA?FPUQI5,--,ZP (I"B/;0V[?W1V;=Z:9CTS
M573@U9'$>?%N)KGZE;G6;FT3'W)MW4]OY5--5K4L.]B5#Z/:];.FFL='^K&Y=@:UBW+%S#SKMW&BNGCOX]=
M=55NJ/@[O'TO%-\3JS  X                          [;:&TM2W]NW1M
MD:1;JN96MYMK#IBGSB*ZHIF?FY9#7278NF]-NG&W]EZ5CQ8L:9@VK4T1_+[L
M37/Z4RB9]%KTCKWUUYO;[S\.;FF[4QIFBN8\(R*_&B?CB:$RC-?JUG1=;CIJ
M *%H                             "+[TOW2_P"Y]1VGU8T_$XIJBK3<
MVY$>09(/3[7[6Z-DZ)N"Q
M5%5O.P[=VF8GGGF'H5!>PUNVWO'LO[%U&W5WILZ;18JF?/F.?_*O3!,:3HU1
ML ..@               (R_3'_@]//ZS,_[2-5)5Z8_\'IY_69G_ &D:K9:\
M$,]?BD 6(                                 -*IF(CNTS55,Q33$><
MS,\1 /2]..G>Y^K&]M+V!M#"N9.H:G?IMU313S%FWS[ZY5[(BGF?F3Q=FKL^
M[3[.G37 V5MW$MQE>YTW=1RHB._D9$QS75,^SO35Q\:WKT:O92M])MAT=5MV
MX$4[JW-9BY118][3'/E/C5S\"]UENU\TZ0OHITC60!2L
M             4B[3W9[VUVC>E^I;*UFS;MYTVYN:=FS3[[&OQ$]VJ/@\4#.
M^-E[@Z<;PU78FZ<2YCZGH^158NQ73QWXCQBJ/;$Q,,D-'CZ4OLO3N?;UCKML
MO3HG5=&CN:O1;H\;^-S/%4\>MW,?;&CUT9.JY4T3W+E,3,Q9B?7-7=XG^DH[L_:>N;^W9I6R-M8M>1J>LY
M%./8HIB9\_&9GCU1$2GJ[+_0#0.SKTJTO8VEV;=>;11%W4,N(COW[\Q$553/
MGQX1X*[E?)'3=.BGFE4;:FU="V5M_!VQMO3[6%IVGV:+%BS;CB(IIB(CY_!V
MX,;0                      +)O2/=D:QU@V3TJW[I5_M1,JML$]
M):8V ''0               ! AVV-LY&U.T]O/ R*)IF_D49%,SZXJHIJ\/I
M3WHJ/2X=&<[2MY:%UJTS#N5Z?G69P-2NTT>]MW?XDS/]&A;9G2K17(@=GM?:VH[YW/I&S-)M57,O6L
MRWAVJ:?.9JD$J'HF>BT[6Z::IU8U;$FC.W1=[N+57'C]RT]WR_WZ97]O)]*=
ME8'3OIUM_9FFVXHL:7@V[,1$<>/',_KF7K&&JKFG5JIC2- !%T
M                  4E[573?'ZJ=!]V[3N8T7;MW JNV.?.FNB8KYC]%5I\
M18[V+ETS3D6*IM78F/*N/
M-N59[66Q*.FO:,WMM2S9BWCQGW,S'IB.(BU.S:JY_\ QAA6]FY*N[&M,IT>)+$ QM
M
M    #9=O6K%JJ]?N4V[=$U*^CFR<_N;JW#9F,B[;J]]AXTQXSX>
M,53WJ9CR1%1%7C577-==4S5555/,U53/,S+19H_>E5G:/W9WL]#
M.BF%GZGB]S<6Y:(SM0JJCWU'/$11[>.*:9^==*QW:^:6BBG2 !6F
M                    BT]*KV:*M'U7&[0.TM/BC#R.[C:W1:I\J^/>W9B/
M9%$\S\*.R)B8B8GPED;=3>G^A]4MB:SL+<6/3=P-8Q:\:[$T\S3$QYQ[)8^W
M5KIMK/1_J5KW3C7<:Y:O:3E546JJHG_2VI\::HY]7CQ\S59KUC25%RG2=7D@
M%RL                             !R--U3+T+5,+7M/N56\K3:1;T
M1W6J<'6]=Z(ZME<6\B)U'3::JO"*O?3IUIU66YTE*0 R+P
M           !TN]/Q0UKY/O_ &_&?7_EC.^W
MK<)S=>_&?7_EC.^WK<)OC9FJW '40
M '.T#0=7W7K^G;6V_B5Y.I:KD48V/:HCF9JJF(Y^*.>9^(%2.S/V>-R]I;J9
MA['T:W=LZ9;JB[JV=%/O+-B)CO4\^7>F.>/B3O=,NFVU^D^S--V1M'3;.'@:
M=9IM4TVZ>.]5ZZI^&9F9^=3'L?=F?0>S9TMPM L6:;FN9]%.3JV5-/OJ[]4<
MS1SY]VF9JB%>&.Y7SS[&BBGE@ 5I@                     "FO: Z&;1[
M0/3G4=A[KPZ*XOVZJL2_,>^Q[\1[RN/BJBF?F5*")TZP3&K'/ZL]+-T=%M_Z
MIT\W=BUVLK3[M46+LT\4Y%GGWE=/MYIFGGXWD4R?I'NRK9ZT].;G4':VGTU;
MMVO9JO6NY3Q5DV(CFJW/'C,\Q3QY^2&R(KB9HN43171,TUTS'$TU1/$Q+;17
MSQJS54\L@":(                               "0#T0&ZJ<+J/O#9U=
MSB,_$C.IIGUS1W*/^I*\@Y]''N>[MWM7[=Q*;G/^5.,R
M7H_$T6]@!4F  M)[=?8IT_M(;=C=>TXM8>]](M3]RW..*#'-5&'F<47HCV=^JJ(F?F6N[P[+O:$V-D5V-)O41/LFJ$D6\(F)CF)B8                     &VY7W+=5?'/$3/#
M<[';&B9.Y]U:)MG#MSLPJNQTU6^
M-*D                            :51S3,>V&H"8GT4.YJ=7[.%6B55>_
MTC4KN/$<^/8MRC)HIY_E333_@DN8KD:52
MTT3K  @D                C+],?^#T\_K,S_M(U4E7IC_P>GG]9F?]I&JV
M6O!#/7XI %B                                 N=]'[V<:^O?67'U?
M5\::]L[4KIRLR:J?>7KL<=VU]%43\RV.W8R\N]:PM/L57\K)N4V;%NF.9KN5
M>$1]*=_L3]!,+H%T/TC0IQZ:=6U2U3GZE%1,Z.[K^_13]FB+6)E]?MXZ7'N^3_ *#0Z+M/X%N)CF['P\Q5
M'SI+'1;%VCI>P]H:3M#1L>BQB:7BT8]NBB.(\(\9^>>9^=WK#75S3JTTQRQH
M (N@                       *2]J#HGH_7CH_KFRM2QJ*\J<>N_@W9CWU
MJ_3[ZGCX^[Q\Z ?6] UC:FMY^U]P8U5C4M*R*\3)HJCB8KHGB9^F&2DB ]*A
MT&C8757$ZM:+B>YZ7NJGW/+[L>%.33QS5/'E-4US]"^S5I/*JN4^:R !I4@
M                            #2N.:)CX&I/D":CT86X9UOLKZ)B57>_7
MI5VK"JYGF8XB)_ZEVR/;T/\ N3[JZ9[HVO[I$SA:E5D=WV=ZFB/\$A+%T[
MTWN7*XCY
M^[PNBJ)V5Z3#I1MKN4VIFF]S:JCSIN1W9CXXDIN6Z_P*Z:OBGEUQN
M               78^C+Z85[][2^%N+)MK-F:J>:9O151-$?'QRM-J
MJBFF:I\HCF4LWHC.F]>A](-:Z@ZAB=S)W#G]VSNZ+J=--5<1Y47:K<3
M^J$3$3%41,>4^+9:G6EGKC2H 6(                            "Z7T:
M6Y_\F.U7I-J:N[1JV#DX]7/MBW/'ZZEK2J/9;W!SO33S\"I6O:WINV]&S->UC*MX^%@6
M:K]Z[VJ
M.[ZOXJRW1SRA75RPHYOO?6Y.IN\-4WWNW.N96HZM?JO5375S[E1,S--N/9%,
M3$?,Z$&QG                                '8[HXJQ<>J/PYB?&)JBKX/P4:ZHHC5*FGFG1[OS*]@Q3.LZRT1&G0 <=
M         $1GI8>LT[KZIZ7TCT[)BY@[533/A[M<\.)^&)MI5][[EPM
MG;1U?<^H7Z;-C3<.[?JKJ\HF*9X_7PQX^I^_L_JGU'W%U$U*Y-=[6\^[D4S/
MJMS5,TQ\4V?8FF]&IT*_S2=";&OZICQ3K.[*XS[]55/%5-OWWN4?H50KNUQM5P[EB:)\N],IG3[5.
ME'4'7NG.L4U4Y&B9=S'IF8X[]J*IBFJ/@GAYINW9@ <
M           'N.A_4K.Z0]6]L;_PKE5%.!G6JGXH:U\GW_LY=TZ7>GXH:U\GW_LY(&.1KWXSZ_P#+&=]O
M6X3FZ]^,^O\ RQG?;UN$WQLS5;@#J(
M !,Q3$U3/$0DE]%9V8?=Z[_:$WA@15%R)L:':O4B)]L53'S+&>@G2
M'5^NO5K0>F^E6JIMYV137FW8CF+./$^^JF?5X\1\[(#V1M#1M@[3TO9VW\6G
M'T_2L:G'L6X_BTQ_^GE3>KTC2%ENG6=7> ,J\
M  !LNVK=^W59NT4UT5QW:J:HYB80F^D1[.,]"^L5SVMWW*LC'BBF>
MY8O^/>M_!X4\_.FU4)[9O0G Z^=#]:VY78IJU/ LU9VFW)X_T=VB.]/'QTTS
M'SIVZN6I&N-80+C==Q\S"R+V!J-BJSEXERJQ?MU1Q--RGPF/I;6UF
M                         5#[.FX:]J=?-AZ_1<]SC'UBUWZN?XLQ/+(5
MQ+GNN+9N\_AVZ:OIAC9:-FUZ9KFF:E;KFBK%R[=R*O9Q+(SV!K%&X-DZ)K-N
M>:_'6)76IWAZ !G6@   #98U
MKIATYW%:KLZWL707H
MA.I.#-<['ZA86HTQXTQFVZ;$S]'>2OB<7:H\T9HIE!GNGT=/:UVQ=KBSL2QK
M%FC_ .I@WJ[DS\410I%NCHEUCV5WO\JNF6X=.BCGFJ[AU13X>N)ED4>?A+BY
M.DZ5FQ,9FF8E^)_G+--7UPG%^?-R;4,:?(R;>'<]RS>]CUS_ !;L=V7THKIK
MIBJBJ)B?7#(>W+V?^B^[YJGR.J&J8'G,4Y5%$Q\7O;<
MJ-;P]$QUVT#OU[9W3HNNVZ?P:8BY3J=*\[)MT3X5XM=NKF/;QWU*]7V1OG;UR;6X=F:SI]R/.F[B5S^NF)A.)B=D
M=)ATPVUW(MU31=IKMS'G%=$T_7#6FNBK\&N)^*77&H         "Z?T;G2&K
MJEVBL76,O#F]I6TK7W;D5<>]BY5%5-,?'%7=E:Q%-VY718Q[-=V]=JBBW;HC
MFJNJ?*(A-SZ/;LZQT*Z*8>;K.'1;W)N2(SM0JF.*[<3$1%J?B[L3\ZN[5RTI
MT1K*Z4!C:                                !$GZ7?:M.G]7=L;LMVN
M[3J6GQBU3$?A54=^J?[R6Q'7Z8K;ENOI]LS=D4Q[IAZE=M3/LBJFFG_%9:G2
MI"N-:46H#8S@                             +Y/1&Z]7@]<]RZ#W^+>
M=I5NOCGSJBJN?\$O2$GT9NM_N/VK-(L35$1J.)?LSSZ^[:N2FV9+WB:+>P J
M3                1E^F/\ P>GG]9F?]I&JDJ],?^#T\_K,S_M(U6RUX(9Z
M_%( L0                               ;;DU4T3W(YJGPICVSZH!=5Z
M.+H?7UM'3K4.DW5C<^P=0LUVXT[/N58_?CB9LUU351_P LPR*T
M4/I<^E$Z-OW;G5C3<;BSJMF<+.JII\/=8X[DS\/=H76:M*M%=R-8U1_@-2@
M                                !I55%-,U53Q$1S*3_P!$GT*IP] U
M7KKK>!-.3J5RK"TRJNCRM4S5375$S[?>RC5VGMK/WINW1=GZ99JNY.L9UG%B
MF(Y][57$53\T3,LACH]T]T[I9TUT#8NF8]%FWI>#9LW(ICCO7(HB*ZOCF8Y4
MWJM(T66XUG5[(!E7@                         "@O;9Z-8_6OL_[BV_3
MCQ7GX5BK4,*KN\U>ZVJ9JIB/CF(5Z;+UFU?M5V+U$5V[D3353/E,3ZG8G2=7
M)C7HQI)M7<:Y\_NC%MW.?THEV8"D6[^R;V?=[4U1K?3+18FOQJJQL2W8JGYZ*8E0[>
M/HINS/N29KTBQJ^B53S,38R[E<1/Q=^%YPE%=4;2YRPC*WCZ'BBS3WF8A2_5--U;0KM=G6](S,"NC\
M*,BUW.&2C>QL;(IFG(Q[=V)\XKHBJ/UO/Z[TUZ?[ELSCZ[L[2#>/84[+^\Z*ON[I;IN/=JY_TMBJY
M3,3[?PN%"]X>B*Z)ZO%R]M?<^M:/>JB>[33-NJW3]-,RE%ZF49MRB3$@FZ/0
M\]0-.MUWMH]4]/S^)][;S;=<3Q_N40HEO#T=/:IVI%=W'V9;UBQ;YYN8ERF.
M8]O%542G%RF?-&:9A;0/8;@Z+]9-IU5QN3ICKN%3;\*JYL=^G_DF7DLFQE8=
M7=S,+*L3[+N/71]<)ZN-@V1>M53Q%RGGV<^+>.          .1INEYFO:MI^
MWM/LU7S&;$\SN7*J?\&FQ/284W8ZOF O5
M                           #M=GZE^VM5M5=VK&UC#KY]D>[4NJ:
M>ZSCW+65'GCW:+T3_1GG_ &23M'*^[MJ:+FS//W1I^-=Y_I6Z9_Q=L\'T(UB
M==Z.[.U.:N]-W1/'RUP
M                             MG[<_:GP>SCTOOTZ/EVJ]W:U35CZ5C]
M[FNB9CB;TQ[*9FGS]KL1K.D.3.D:K6/2>]KR<[(GL^].-8GN4?C%D6:^)CUQ
M9B8_W)]2-^FFFBF***8IICPB(]3D:AJ&?K&HY6LZME5Y.=GWJK^1>KGFJNNJ
M>?'ZOF?!MHIBB-&>J>:=0!)$                              ![OH?T
M:W-U]ZEZ7TUVQ1.Z.]*=L=&.G^D["VKA6[&+IUBFBJJFGBJ[7YU55>V>9E[9B
MKKYYU:*:>6 !!(                 !9EZ4;K%7TZZ"SM/3LJ*-0W=?C!BF
M*N*HMQ[^9C]"80V6Z*;5%-NB.*:8XB%XWI1NK%._^O\ ;V9BW^_A[/Q_<)BF
M>:?=YF:N?T;G"SMLM1I2SUSK( L0                             )F(
MCF05/[,G2?+ZU]JQ:JBNKGXZ8J9 FD:9B:+I6'H^#
M;BC'P;%O'M4Q''%%%,4Q^J$;GHB.C7N.+N+K9J>-S5F5?N=I]=4>5-'/>F/@
MF+D)+F2]5K5HOMQI&H J6                                (J/2V=$
M;>@[KT7K=I6/W;&J1&GZCW*>(BN.(MS/PS-3
M3BUYF)/',^[VZ9JHB/CGA 3=QK^!DY&FY5%5%_"O5XUVFJ.)BJBJ:9_7#79J
MUIT47(TG5M 6JP                             %X'HO^KE73_M QLS,
MO=W W?9]PB*JN*8R(FF*9^/B*DSL3$QS#&WVGN?-V3NS1MXZ==JMY.CYEO*M
MU4SXQ,3_ /I9$/2_>6#U Z?Z#O'3JHJL:IA6[]/CSZN)_7$LU^G2=5UN>FCU
M "A:                .EWI^*&M?)]_[.7=.EWI^*&M?)]_[.2!CD:]^,^O
M_+&=]O6X3FZ]^,^O_+&=]O6X3?&S-5N .H@
M    #2NJFBF:ZIXBF.9EJ]9TFZ=ZAU:ZE[>Z=Z=35->KYMNW>F(Y[MGO1%=4
M_!$2;"2_T4/0&K:^Q=0ZS;BT^:-2W#7-K FY1^!C4SQ/'/ES51$I W1;&VII
MVQ]H:1M/2\>W9Q]+P[6-331'$[13?F9JNQ'J_C4K6TS'I/NCD=1N@-[<^GXLW-5VK>C
M,M544^^]Q\)NQ\7%$(9;=4UVZ:ICB9CQCV2V6JN:EGKC26X!8@
M                    ^.9%7W/5-,\51Q,3\[(%[(^MT:_V<=AZC3L=E+:U%VYWZ\*W./5/Q>/\ BIOQT6V]
MUTP#*N                '6:OMK0-?LU6-:TC%S;=<<54WK<51,.S 48W?V
M.NS=O:BNG6NE&A17<_"N6<6BBN?GXE1?=OHJ.S1K=%56@8VL:)=GGC[FRXIH
MY_HQ0O/$HKJC:7)IB486\/0[Y]$5W]D]4Z9GQ[EG+QJJOIJ[\**[J]%SVH]M
MT5W]/Q]'URW$^$6?*_;G_ 'H?2)B?&)B4[.\.P5V8MYQ/C7:_&*\2Y59[L_%1,0H=NK
MT0G1/4ZKV1MK=FM:1=J\:*8YNTQ/^]6E%ZE'NY1+B_\ W9Z('J3AS75LSJ-@
M:A3'C3&=1%F9^#WM,J<97HNNU!C7ZK-K'T>]33Y5TWZ^)_Y$XN4SYH\M7HM'
M:35/?IM4457+M<]VBW1'>KKGU1$1XS*^;9WHD>MVK7K=S=N[=(TG&F8[_P!S
MUSIN9:JIKG65],<
ML: "+H                                LV]*EMNG6^S-DY\T=Z=+S;
M-Z)X\N]2MY[?.DTZSV6=Y8DT15--JU=C_HIJ
M]L1+<^>-/./:GVT1]3Z-S,                              K3V,M9G0
MNTULK+]T[GNF579Y_I43'^*?5CL=">/.NF&1+;KI
MN44W*)YIJCF)^!FOQUA=:V;@%"T               !&7Z8_\'IY_69G_:1J
MI*O3'_@]//ZS,_[2-5LM>"&>OQ2 +$
M![SH-TYS>K'63:FQL2S5H'7K)WEJ.)%W3MI8ONM,U1X3>KBJC]7-,IEUFWHNNE-&QNSWC;K
MS,2;6H[JNSG5S53Q/N4Q3W:?BYB5Y+'=G6IHHC2 !6F
M           C1]+_ -+IN8FU.K6#C1$XM-Q3S,7*9B/#YIE ]8KJKM1-=/%4R8:[,ZTZ*+D
M:2W@+58                             "Y'T=VLSHO:OVO7-?=HR:+]F
MOX?]%7Q^N4YK'Y[)^L_N%VC]C9??[ONF?[ESS_*B8_Q9 S+?\2^UL *5@
M                            #Y9&-CY=J;.39IN43YTU1S$O![GZ =%]
MY17_ )2]-M"SZKGX5=[$IJJY]O,PJ"&N@M7W3Z-/LI;FF[>HV3Q\WW2K9?474M-]=%.9SD?-X32D3$XN51YHS1$H?MU>B2Z^
M:7=KKVMNG1M6L41S$7(ILU5?I5J+[N[#O:AV9-?[H=-+^731S[[!N_=',>WB
MB)3TGFG%ZI&;<,;S7-A[_P!L7)L[AV)N# KCS]UTZ[$1\\_NC$MW.?THE3;=G9-[/N](JC6^F>
MCS-?/>JQ\>FQ5/ST1$I1?]81FUZ,?VFY17^!735\4M4R&\O14=FOD6=
M4T.9F9C[GR;E<1\TUJ+[O]#O[E-=S8O53(F/XEG-QJ(CYZN9E.+U,HS;J1KB
M\C7?13]I/2KU5.GYVA:C;YXIJMWZN>/;/O'ST3T5?:7U3(BUG9.AZ?;Y\:[F
M17Y?![Q+O*?5SEGT6=S5%,355,1$>$^N5]/2/T16S=)R\?5NKF\,K6Z[-5-4X&-3[G9G
MVQ-=,Q,_0OTV5L3:73S0L?;FSM"P]+P,:B**;>/9IH[W'KJF(]]/PRKKO1^Z
MG3;GS=7TAZ4[3Z+;!TSIYLS"C&TW3;<4T^7>N5\1$UU3$>-4\1S+V8,VZX
M                               !Q-7PXU#2\O F.8R+%=J8_I4S'^+'
M0ZH:5&@]4]X:-33W8QM:RXB/CO5RR.F/MVJ]'_LPJN[*5 -*D                            ?/)_U>[_ $)^I]&R
M_'>LW(]M,@GM[$FK?NUV9]EYDU][C#]QY_H>]_P5T6K>C1U>G4NRGMW'BJ*I
MP[V3;GQYGQO5KJ6&KI5+53M  BZ
M                        V7KMNQ:KOWJXHMVZ9JJJF?"(CSD'ENJ74G;7
M278^J;ZW5G6\;!TVQ7=YJJB)KKB/>T1\,SQ'SH$^T%UOW)VANI^H]1-PWJYL
MUUU6M,QYGPL8T3Q1$1ZIFF*>?AA<+Z1OM9WNL^^;G2O9^H35M+;>1--^[9KX
MIS,F)\?&/.F.*9A9I$1$<1'@U6J.6-945U:SH +E8
M           #2JJ**9JJGB(!]L/#S=3SL72M,QJ\C-SKU&/CV:*9JJKN5S%-
M,<1\,PFT[!?91P^SKTVMZGKN-;N[NW!11E9V1,1-5FBJ)FFU$^<<15$3'MI6
MP>C%[(,ZID6NT-U"TWG&XXT#$OV^8J\/W^8GX*HXGQ\:4H<1$1Q$>#->KU_#
M"ZW3YRU 4+0                 !T6^MTX6R-GZON[4:XIQM)Q*\J[,^JFF
M.9=ZM$])UU+C8_9JU30\3,FSJ&Y;U&G6HIJXF;==-<53\7,0[3&LZ.3.D:H=
M]];FR=[;ZW!O'-NS['ZJ8=(VVZ>Y133[(\?C;F]E
M                        &_'P[^HY6/IN-3-5[+O6[%%,1S,S55$?XMBN
M_8@Z55=6>TGM?2[]FJO3])N_NCF3%/,13$513S\'>FER9TC5V(UG1,AV6^F&
M/T@Z%;3V/:Q_$]Z(FOC_ 'JI3OH[_2[]*/W6V1M_JSAV8]UT*_\
M]M=ZR:EC178TFW.!@S73S'NE7>BY,?#'%*/NJBY=[MBU$SB5UK[N[.^=IE57OL#6+ENF.?X
MON=O_P H@92A^AWUCW;:&\M%[_\ J^=[KQS[8HA5>\*=OQ)&P&1H
M                                                          %)
M^U3I_P"Z?9_WMB\3/_XIR*XXCG\&B9_P58>)ZV8OV?YN]71]$\#>R@
M             .[V)F?N?U VMG15%/N6LX<\SZN;U$,C+;U_[JT'3\GF)]UQ
MK=?/MYIAC=Z37[GK^C78\Z-4PZH^:]1+(TZ>WYR=B;>R*IB9NZ9C5SQY>-N&
M>_Y+K3T(#.M                1E^F/_!Z>?UF9_P!I&JDJ],?^#T\_K,S_
M +2-5LM>"&>OQ2 +$                              &V[7%NW575/A$
M)MO1L]-J^G_9ET/*R\6+69N"9U.]/'C/>B*?^E"_M30+VZ]V:+M?'MSFB/XW,\_X,BK8&V\/9^RM%VS@6^YCZ=AV[-%/LB(Y_P 5%^>FBVW'75Z
M!F7                            !Y@"$STF&PJ]F]I_4=7IHBFSN/%IS
MJ>(XCF:JH^GWJU1)5Z8K9]=-O9&_+5CWM%^Y@WKG^S%%4Q'TU(U6VW.M,,U<
M:2 )H@                             #L=M:#D;KW/H^U\2W-=_59_5$NN7%>C\Z?QO\ [4FV?NC%F_AZ',ZC>CU4\3W8G_F%;QZ(B/5$?_I>G:4Q%-,4QY1'$-6!J
M                       ==N'3,?6="S]+R[<7+65CUVZJ9\IYACK=3-L7
M=E=2MT;1O1,5:3J=W'\8X\/"?\61S,1,3$^4H,O2(;/N;2[5FYKU./%G'UFF
M,ZW$1Q%4U551S_RK[$]=%5V.FJV\!I4@
M /9=%,S]SNM.Q\Z9F(M:SCQ,Q\-=,?XLBFS=IOV:+U/E73%4?.QN]EY?[G[Y
MVSG=^:?+.L>$>OQFY/BOZ8KGBEIIV $$@
M                         !8UZ2;M=4=*=GU=(]D9T3NG<=F:;]ZU7XX6
M/ZZI]E4S$?-*XWM,]?=N]G7I;J6^]:OVYRJ*)M8&+,QW[]^8GN4Q'G,<\<_&
M@8W_ +\W'U0WGJN_MVYMS*U+5K]5VJJN9GW.C^+1'/E$4Q$?,NM4UD6+E&U-#NTY&JY$T^]N<<<6J9]<\S3/QY^
MK>^-+Z=[-QJKVJ:M=BW3,1S%FB9B)N5>R(YA/1V;^@VU^SSTRT[8VW<:FF[3
M;IN9U_B.]?OS'OJIGU^?'Q0JNU\L:0G13S2J)H>AZ3MO2<70M#P;6'@85N+-
MBQ:CBFW1'E$.>#(T                    "(_TN74>[KG5[;O3G&O=[&T/
M"JR;\4U>'NESW.JGGX>)E+5F95G!P[^=D5=VUCVZKM<^RFF.9_5#'S[2_4"]
MU.Z];SW7FBF8#4H
M                      $F/H>NFM=&G[QZJYV/3/W5=ITW$KJCQBB(MUSQ
M\\2C)RKM5G'KNT4S553'O:8]<^Q/1V'NF]CIGV;MHZ3%F+>5E8GW5E>'$U5U
M5U3$S_NS"J].E.BRW&LJ]@,B\                                  4
MK[3_ $XL=5>AF[=F5XM-^]F:?]XCW.KB/#YXE1YNB=8U99C0 =<                            'HNF
MVZ\K8G4?;.\,.Y-%S3=2L5U<3QS157%-7/S3+SK9>B9MU=W\*(YI^./(=9)>
MU-?Q]T[:TS<>)5359U+%MY5$TSX=VNF)CZW;+8O1U]29ZB]F3;U>3E>[9FC]
M[3+L<\S3%J(IIC]4KG6"J-)T:8G6-0!QT              =+O3\4-:^3[_V
MMPG-U[\9]?^6,[[>MPF^-F:K< =
M1                              5&[.?3[(ZH]<]G[-LV)O6[^H47[]/
M'\2WS7_TLA'!PL?3L.S@8EN+=G'HBW;ICRBF/*$2?HC^G]&X>KVXM^9-F*K>
M@85-FQ5,>5VJKB9C_=K2YLMZ=:M%]N.FH I6
M      "P;TN?3NG6^DFB[_LV>]?T#.IMUU<>--FJFN9GZ>%_*A_;3V59WWV:
MM[Z-SB
M>'T;F8                              2+>ATU.QB:QU"Q,B[%$3:M78
MB>?773'^".E>=Z,C<4Z'O7>UB,N+,7=-L7.)CGG_ $O'/ZD+D:TRG1TE,@ Q
M-
M        \WU*L6\GIWN>Q=Y[M6CYD3Q_4UO2//\ 4+\0=R_(^9]C6[&Y+'&S
M:(MZMJ=JGRMYU^B/BBN8?)]]1_\ VUJWRCD_:2^#?#(
M             ^F-5%&?@W*IXBC+L53/P1F/_!Z>?UF9_P!I&JV6
MO!#/7XI %B                              "X'L$;(C?/:GVE8R,>;N
M+I5W[ON^'A'=F(\?TD[E-,44Q1'E3'$(H_1 ;0HS^H>\-ZW;'>C3\:G!MUS'
ME-?G6K1?;C2 !4L                              6;>E1
MV?5N7LU7]4IHYG0\RWD\^SO5T4_XH::*N]3%7MCE/OVQMNT;H[.&]=*KMQ7_
M /(3>B./7;F*_P#I0!X54U8EFJ?.:(Y^AJL3^'11O4*_8F?<>YIUBY,>'%4453^NE')75W
M*)J]DNZ/)HU/$JB?BO42R,^G=^K*V
M'M[(JJBJ;NFX]H
MKT7#F)]O^BI9[_DMM/9 ,ZX
M                                             0R>E7QZ+/:?L7:>
M>]D:53-7S4VXA,VAI]*[_":PODG_  MK;/B0N>%9N ULX
M              "4OT.F99_S?;UP._/NMO4[-4T^J(FFM(FC6]#EE69T??V%
MS_I:,W&JF/@]SJ24L=WQRT6_" *TP
M                      !P-=UO3=MZ/F:]K&31CX6!9KOWKE<\1313$S/U
M.=,Q$:='*
MIY8U6N]M3M/:CVE.JF1E8&371M/1;E>-I=B*O>7>)XF],>OGNTS"WUI113;I
MBBB.*:8XB&K;$:1I#-,Z@#K@                              UBF[O5Q;M6Z8YFNNJ>(B/CF8:3,1',SQ$+Y?1L]D.YU0W1;ZT[\TWG;>
MC7(G2[%ZCPRLB/'O\3YTQS3,3[81JJBF-9=B.:=%T7HX^R+:Z-[)IZE[WTVB
M=W[AMTW;?NE/OL/&JCFFF/9,Q-//PPO7;:**;=,444Q333'$1'E$-S%55-4Z
MRTQ&D: #CH                   "E':FW];Z;=!MW[GKO1:JHTV]C6ZI_G
M+M%5%/ZYAC[Q=KR:[F9=F9N95RK(N3[:ZY[TS],I;_2Y;]N:%T1TC9F%E=V_
MN'48BY;B?.W:JMUS^KE$A33%-,4QY1'$-5F-*=5%R=9T:@+E8
M                  #V/1K9-SJ/U;VELBW1-?[JZK8LUQ$<\435Q,_%XLA_
M0M/MZ3HN!IEFBFBC$QK=F*:8XB.[3$(8/1B;#_RO[46'K=VB9L[E%Z>3O7LV9>
MKVKC2K5
MHMSK#4!4F              .EWI^*&M?)]_[.7=.EWI^*&M?)]_[.2!CD:]^
M,^O_ "QG?;UN$YNO?C/K_P L9WV];A-\;,U6X ZB
M        $SQ$R-EZW=OTQCV/WV[5%%'QS()AO11; M[:[/US==['[N3N/,JR
M::YCQFUW::8CZ:97MJ6]F#:%&Q>@NR]M1C18KQ=,HBY3$<>^F9GQ^E5)AJG6
MJ9:J8T@ 1=                              '5;ITNQK>W-2TG)HBNUE
M8URW53/E/,.U;;E/?MU43_&B8!C>;UT6YMO>VX-O7:>[7I^H7;,QQY>//^+I
ME9.V7MJC:7:CW_I-NGBB[J-63'^]$1_@HVWQ.L:LLQI( ZX
M               +B.Q1K.1HF]=S7\>:(JNZ79HGOSZHNS*W=4SH1J.-INO:
MK=R56E9<3\4V:
MG>.EWM^)FO\ R7E?95$$L<76:(M[CUVU3^#1JN73'Q1=J<5S-=_&?7_E?,^U
MJ<-OC9EG< =<                            ;;GX,?''ULA+LR_D"V'\
M@X7V-#'MN?@_/'ULA+LR_D"V'\@X7V-"B_M"VUNJ< S+@
M$9?IC_P>GG]9F?\ :1JI*O3'_@]//ZS,_P"TC5;+7@AGK\4@"Q
M                   )F(B9GU#YY-7B)VI.E=#]:W%?L1%[
M5]3[U-?KFFCOT_X+\ENG8 VO3M;LN;1QIM=R[D6KN17/'C5WKE54?JE<6PUS
MK5+33M  BD                              \MU2TRUK/3C; :%(
M            #Y95%RY8JLVOWR['V]"M4S55FZKC6N(]<3_]C6I]M$?4^KHJT+"F)_P#S
M-+'@N>5/]*GZV0EV9/R ;!^0,+[&E1?VA;:W5. 9EP
M
M    AS]+/CV[7:/T6]1'%5[1ZYK^'B;<0F,0[^EL_A%:!\BW?[UM;:\2%>RR
MD!K9P                             $D_H.
M(!1+MS]J?3NSCTQR+6FY%NO=FN6JK&DX_,9JNJWZSUN#M)=5,
M'9NG6+E.CXURF_K.73$\6;$3'AS[9F:?6GDV+LG;W3K:FF[-VM@48>F:78IL
M6+5$1'$1[?:I)V/>S/H79KZ78F@V+5%W6]0HIR=4RII]_7=F.>[S[*>>./@5
MY8[E?/+113RP *TP                    'SR+M-BQYT53,F:;-R8\XIGCZ 2?\ H>-E6IVSO'J%=LQ[IDYEO#L5S'CW:/=*:XCY
MXA)$M:]&YLF-F]EW0)N6?<\C4[M[,N^'',5US53/T5+I6*Y.M4M-,:0 ()
M                                  /"==-IV=[](MU[;OTQ-.5I>1,1
M,<^^IMS5'ZXACNW<.YIF5DZ5>B8N8%^O%JY]M$\?X,EC+Q[>9BWL2['-%^W5
M;JCVQ,<3];'T[3VT?\ANT)OC;L6_<[=&J7LBU3QQ_H[ERJ:?U-%B=X578\U,
M0&A2                              [';6OY.U-T:+N?$N>YW=*S[.5%
M?\F**HGG]3(KZ=Z]C[GV+H&O8U[W6C-T['N]_P!M4VZ>?U\L;_(MQ=L7+4_Q
MJ9A.AZ/G?]&_>S)MB]7GXH:U\GW_ +.7=.EWI^*&M?)]_P"SD@8Y&O?C/K_RQG?;
MUN$YNO?C/K_RQG?;UN$WQLS5;@#J(                            ];T
MBVU.\>K&T-K11-7[I:M9LS$>R>7DEPOH_MNSN/M9[.IKL>ZV=/KG,KB8\([M
M5,?XN53I&KL1K*<[2<>G$TK#Q::8B+-BW1$1\%,0Y;2(B(B(\H:L#4
M                            A3])YMR-$[467J--'=_=7 HOS/M]_7'^
M"TU?MZ7W1Z,;JWM/6Z:.)RM-C'F?;W:KE7^*PEMMSK3#-5XI $T0
M                   !Z+969BX6;DW,N]3;IJM1%,U>N>7G3CD&2\ \>U@
M                                   /G>OV<>W-Z_B^RHN?Y4=2="T^NW',T7LNFFKZ)44W1Z3+LI;EWZVY
M]RJ-K;%T;3K<\\3>N^Z3'Z5M.+54^2/>4I=6VY;E
M](YVK-SS5SN_"TVW5YT8V#;B?THB)4QUWM,=H+<==56I=6=?[M?G19R[EJGZ
M*:DHL3YN=["?S*W?M/!YC-W1I&/QY^ZYMJCZZGF]7ZZ]'=#Y_=+J5MNUW8YG
M_P#&=B?^ICWZCNW>FL7)NZIO;<&35/GW]2O3$_-WG67)NW_]:R;^1_77)K^M
M*+'K*/>IZ]7[;'9IT7O?=G4W3JN[Y^XU>Z?W>7B]6])7V4=-[T6M[9&553YQ
M;P;WU]U")]S8_P#,6_T8:Q8L4^5FB/\ =A+N*7.\E,1J?I9>S=@S5&/9UG+X
MCF.YC7(Y^#\!Y[)],-T/MS,8NR=P7XX\)]]3X^SQMHFHHICRIB/F:N]S2=Y4
ME)S?3&; ]RC]SNENLW+G/C%>53$H6XGGYZ
M49P[W5#G/4D>S?3$ZI7-/[G](;MJ/XWNF;;JY^+B(<;_ .,-N3\U$?\ X50C
MJ#NJ?0YZDBO_ ,8;D==RWQY6\RW3//QS".,.ZI]#GJ27XOIC<3W7_Y[
MHYG46O;3J%N9_NNXP?3&;%F*OW2Z6:Q;G^+W,JF>?HH1/L\+;TNE>EB[-FH33&33K&'S',]_%N3QX^7X"'=I-%$^=
M,3\<.=S2[WDIP='](_V4M6[M/^7EW'KJ_BW<*[$?3-/#WFA=KOL[[B[O[G]3
M]&I[WE[ODT6O[TPQ_P"<>Q/C-FB?]V",>Q'C%FB)]L4N=Q2=Y+([TSJ?TXUF
MW%S3-][?R(J\NYJ5F9^B*G?XNH8&=3W\+-L9%/MM7*:X_5+&OQ\_5\*J*L#7
M=4Q)I\O<,RY;X_1F'L- ZX]:=KU43H?5+<>/%'E3.?>JCYXFI&;'I*7>LBAT
MN]OQ,U_Y+ROLJD)VT/2)=JG9LT>Y;RQ=4M6__I9F)15-7QU3$RK!H?I<.H^3
MHN;HF_>G6!F?=N+=QIOXE^:9I[]$T][NQ1$>M#N:H=[R)6,:[^,^O_*^9]K4
MX;[9]^,S5=1U&*>[&=F7LJ*?Y,5US5Q^M\6J-E,[@#K@
M           #;<_!CXX^MD(]F.B*.@.PXI__ %#A3_\ V:&/=<_!CXX^MD)=
MF7\@6P_D'"^QH47]H6VMU3@&9<                C+],?^#T\_K,S_ +2-
M5)5Z8_\ !Z>?UF9_VD:K9:\$,]?BD 6(
M#;78G+JMX5/GE7*;$?'5/#<[C96F5:UOK;6E4QS.3J^+1Q[>;E(ZR">@^A_Y
M.='MH:1-,1-G2,69CX9M4S_B]ZZK:>-]Q[6T;$XX]PT_'M_HVZ8_P=J\?/5J
M@                               !LO41=LW+=4_M-Z=.
ME=H?J!A=R*8C7,JJF(\N)NU<,A- 1VSL:WB]J'?ENU3,15G5W)Y]LUU\K[&\
MJKNRC #2I                              5=[(FA?Y1]IC8.G33WHMZ
MG:RJH^"W%,1$(/\ T;FA3K?:QT*[W.]&GX63>GP^"F8G
M]2<)EO\ B7V]@!2L                              %,>TQI\:IT)WIA
M]R*IJTC)JB)]L6ZI_P %3GC>LF-;R^E6[,>]3,TU:/E\Q']34[&[D[,<[$IF
MC&MVZOPJ*8IGXX?4KHBWDY-JF.(HOW*8CX(D;V4
M        !MN>5/\ 3I^MD)=F3\@&P?D#"^QI8]MSRC^E3];(0[,--5/9^V#%
M5?>G]P<+Q_\ S-*B_M"VUNJ@ S+@
M                    'GMQ=0=D;2M57MS;HT[3**?&:LF]%$1](/0BWK>'
M;X[*^RJZK6H]4],RJZ>?>X5VB[,S\'OH49W?Z6WH7I??HVGH>N:Q7'X-56+%
M%N?]Z*I2BBJ?)&:HA?6(K=V>F'WEDQ5;V=TKP\68\*;F3E53S\/$T2I5N'TI
M':FUZBJUAY&C:/35Y>Y8MN[,?/-$)Q9JESO*4T[@Y>N:+@<_=VL86/QY^ZY%
M%''TR@5W%VQ^TQN;O?=_534+/?\ /[DYL?1W)CA3[5^J'5'7^]^[74C=3O1S_ ,R46)]4>]AD'ZEU5Z::1;FYJ&_]O68I\^]J=B)C_F>+UGM:=GK0
MYF,WJAHE4T^?N.71<_NS* .[EZGD\_=>LZED\^?NV7IO\ 43W2N/*+6)(EXS5O2H]F+3N]]RZ
MAJ>9W>..YAW8Y_Y$,GW-C_S%O]&&Z+=NGRMTQ\4.]S2YWDI;\[TOW0+'JJIQ
M-L:_E33Y<6ZZ>?IMNHRO3%]*::YC"Z;Z[/SVT5([W-)WE23C)],
M;H7N5?W'TBU*JYS[R*LZB(F/T76WO3&7YM518Z-Y5-SCWLU:A;F(G]%&R.]U
M1Z.<]216/3#;D]?2B/\ \*H/_C#;D_-1'_X50CJ#NJ?0YZDBO_QAMR?FHC_\
M*H/_ (PVY/S41_\ A5".H.ZI]#GJ2+1Z8;I)]C>F-VMW[?W9TFU2BG_ZDTYE$\>WCWCO,3TQ72&J
M*ON[IYKUJ>?>\7>]S]%M%*.=S0=Y4EVT[TNO9YS)XR=&UW%\OPK%RK_MO::/
MZ3OLKZGQ]U;HS<+G^X5 T7KGT?W!Q^Y74G;E[O1S$?NG9B?[S'7^YL?
M^8M_HP^EJJ]C3SAY>1C3[;%VJW]4N=Q'J[%V62;A[DV[J/'[GZ]IV5SY>XY5
M%?/T2[%C?:/U!ZB[>JBO1.H.X\2:?+NZG>\/^94_:O;2[3>SYHG3>J&9D11Q
MX9M'W1S^G,HS8GREWO83Y(=_2V?PBM ^1;O]ZVTVEZ6;M"Z+
MB(BJJF*;%=7Z-$J)]K'M'??0;_TO?M6W9T6Y@X%6)Z37%54S3XQ,Q'\EV
MBW535K)57$PHL T*0                             $DOHUWI-L[.F=I;>O\95RW7S3F95,^V/"::9IYCXUU7I).UW
M'2?:4])]BZA3.Z=P6IHRJ[=7OL/&GF)JF8\8F>[,>KS1"T4S3'OJZJZIGFJN
MJ>:JI]4-8B(CB(\ &A2
M      TJJ[L<\3,S/$1'G,^J(2I^C)[(-.T]&HZ\]0=+XUS5+?&D8]VGB<7'
MJCGOS$^/-433[/):]Z/SLF9?: W_ &][[GPKE.S=MWJ;DU54SW'8MV;%FF*+=NW3%--%,>41$>4,]ZO]V%MNGSE]0&=<
M                    /)]6-RVMG]-MR;EO<=S TZ[L6U>D-WK
M5LSLM[MKM7.Y?U*Q3B6O'CF9KIF?U1+M,:SHY,Z1J@[S-3NZWJ&9K5ZN:Z\[
M(KOS5/G/+Y-EFW39M4VJ?*F.(;V]E                              &
M_&QZLW/P=/ICF@^W)W9UNV1HW+.T^DVTM!L413&+H^)15$1Q[[W&GG];VSXX>-;PL2SAV8X
MMV+=-NF/@B.(?9X]J                                      $+OI2
MMHT[;[3DZO8MS%O7--LUU5=WPFJBF.?'_>31(R_3$[2BFC9&]+-K\&N]BWJ^
M/;-N*8_5*VS.E2%R/PHU0&MG                              $HGH=]
MY_=&R]X[#N5\U:?GT9%N)GQ[LT1,\?!S4B[7G>BGWO3MKM"9NVKMR8MZ_IU5
MNFGGPFY%='$_1$J[L:TRG1.E29 !C:              !TN]/Q0UKY/O_9R[
MITN]/Q0UKY/O_9R0,MPG-U[\9]?\ EC.^WK<)OC9FJW '
M40                           !>_Z)3;5.I]>M;UZ];[U&G:5711/\FN
MJJW,?5*R!)3Z'70>_3OSBKX.Y//U(79TIE*CQ0DU 8FD
M                           !&'Z8[3YIRNG^JTT3XW[UJJKU<1;F8^M&
MZE&],9A69V+LG4.9]UMZG=IB/5QW(_\ *+ELM>%GK\0 L0
M                9+P#Q[6                             TF8B)F9X
MB :BGO4#M ='NF&)=R]X[^T?#FU$S59C+MU7O#V6XGO3]"TOJ7Z7#H[H%R_I
M_3S;NI[DR*8F*+U458]KGV\U43$_2E%%56T.35$+]G5ZMNC;>@V;F1K.O8&%
M;M1WJIO9%-/$?%,\H:NH_I/.TQO2[]]]:UK%RJ9F8R/UK9]^>F)VOB7:\?IUTRS]1X\*;V;7331S[
M?>UQ/"+RSC8^/'%BU31SY\0^BR+-,(3?UF9_VD:K9:\$,]?BD 6(
M                   "H_9MTO\ =GM [!T^:>]37K>+55'^S%VCE3A7'L0Z
M?3J7:EV18JB)BW?JO>,<^-$TRY5TB78W3TV+5-BQ;LT^5NB*8^*(X?0&!J
M                              $#G;OB([5V](IB(\;4^'MYK3QH'NWG
M;KM]J_><7*9IF?<9B)CUWWO/5YICO6,>
MS;Y[OCXQ<]?S)6&2]XFBWX0!4F                              //\
M4*(G8.Y8F(F/W(S//^IK>@=!U B9V'N2(CF9TC,B(_\ S-9 QQM0_P#VSJL1
MY1GY$1^G+XOOJ433K>K4S'$QJ&1$Q[/?R^#R$,@
M        #;<\J?Z=/ULA+LR?D V#\@87V-+'MN>5/].GZV0EV9/R ;!^0,+[
M&E1?VA;:W5. 9EP                                            #
MJ-P[NVMM/%JS=S;AT[2[--/>FO+R:+4EPZF:Y-S&Z6[-Q-$QZXF*;^=5%^YQZICCN
MS"<6ZJD9KB$L&3F8>%1[KF95FQ1'\:[YS$XN+?KM6>/9W>94FNV*LH3=]$O/4+TM70W;?NN-L_1=4W'D4\]RNS%--JK]
M*:96[;X]+EU?W!;KL[+V/I>A6YYBF[?JKJO1\/A7-*Q/C@61:IA":ZI5DWOV
MR.TYO^NO]V>JVI8]JN?WK%BW3$1[/P.5*M2W#N/6KE5[6=Q:GFW*_&JJ]E5S
MS\W/#@"<1$;(ZZMD6+4>='>_I3S];?$1'A$1 .N
M                                       ))_0Y?OG43^TXGV4I-T9'
MHONW>SKTMU/?\ K55J[D6*)HP<.:N*LF_,3--$
M1Y^J52->
MK;]W7FW,G4M7OU7JYKGF+=/JHI]D1$0Z$&S9G
M         'O>AO1G*8XCX9A-KV#NRC@]G3IO;U+6L>W=W;N
M"W1DY^1,1-5JFJ.:;43YQ$1,1,>V%=RODA.FGFE6_H_TJVOT8V!I6P=IX5%C
M#TVQ3;FJ(XJNU>NJKVR]H#'NT                        "/7TP>\8P>F
M>U=ET7.[7J>I>[U1$^,TQ1U8
MW7VJM!IKM1[S,S]2]!0KMN[6C=W9DWOITV^_[AIU
MW+XX_D452E1.E4.5;(%:*N_137_*B):MEB.+<4?R>:?H\&]N90
M                   !5WL@[MJV1VF]A:W$\4W-1IQJYY\.[--4^/T*1.QV
MSJ=S1-T:-K-FKNW,+.M7:9]GON/\7)C6-'8Z2R2[=7?MTUQ_&B);G2[+UJUN
M+:>DZW8J[UO,Q;=VF?;$P[I@:@             !TN]/Q0UKY/O_ &_&?7_EC.^WK<)S=>_&?7_EC.^WK<)OC9FJW '40
M                        !++Z'S3?<.B&XM3KM\59FK^%7MBF;D(F+D]V
MW5/LB4S7HL=(_5W>/NW-OW//SXNUPJO>%9;W7C ,B\
M                     !8#Z8>BC_,MM:Y-$=^-9KB*O7'O:43Z6/TP]-4]
M$=L51$\4ZS5S/L][0B<:[/A47/$ +58
M#)> >/:P                        BFJKXH1,]9O2?=>>I,7<#8]%K9NG7(
MFB)L^.3-,_RIF:J>>/9"TW7MP[BW7FUZENK7\[5LNY5-55W)NS,S/Q1X?J74
MV9G=7-ST2E]7_2W].= B[@])-M96Y,B.:8R;\>Y8_/JFFJF:N8^99CU6](#V
ME>K%%S%R-T4[>P:Y\,?3(BFJ(_K(BFI;G$13'%,1$? +J;=-*N:YE]M0S]3U
MG(KR];U;.U*_GG]9F?]I&JDJ],?\ @]//ZS,_[2-5LM>"
M&>OQ2 +$                            !OWL?\ A;4NR]%]BV,GM58==ZCO39TS)JH^">XC7X92IWA-8 PM(
M                         @M](;_"YW;_ &7$^JI.D@M](;_"YW;_ &7$
M^JI=9\2NYLMS :E                              "3'T.&!,8/4#4I[
MLQ7=Q:(]L<3=26H[/0[8]FG86\\J*?\ 2W,ZBFJKVQ%5?"1-CN^.6BCP@"M,
M                              =+O;\3->^3,K[*IW3I=Z_B;KWR9E?9
M5$#''UW\9]>^5?'VT4TU1,?/"=-%56R,U1&Z336-KBFFF/;*USJ[Z2GLY=-/NC TG<,[GU2U$Q38TR*;M/>]7>G
MO1,1\R(_J3U[ZR]7\ZYF]0=_:EJ%%R9XQJ;G*Z?#Z5I>\NIO
M4CJ'FU9V]=\ZQJE=4S/N=>7AR_?.HG]IQ/LI2;L=WQRT
M4>$ 5I@                                                +:.W-
MVI]*[.72_(MX-^F[NG7;=6+I>/35[ZBJ>>;E4>R(BKY^'8B9G2')G3JM;])_
MVN;F1DW>SKL#4JK=5JJ*M?RK%?$T\3X6.8^&FJ)CV2C;IIBBF*:?*(XAR,_4
M=4UG4,G6=:KER?.9?!MHIY8T9ZIYIU $D0
M                   !I55%%,U53Q$-5PG8J[+^K=I3JA8HR;%=&U-!NTY&
MJ9$T^]N\3$Q:B?7/,TS/P.3,4QK+L1K.BYGT8G9"_=*];[0_4+3O]#'-.@8E
MZCF)CC]_F)^":9IGQ\DH$1$1Q$<1#A:)HFE;BAT"--[-?[KS1$5
M:GJM^]$^V)HMJKT_A3MQ^)>F R-
M      \IU6TB-?Z:[FT6:8J^[=+R+'$QY]ZB8>K?'+QJ,S%NXMS\&[1-$_%(
M,:_4L><35M2Q)CB;&=D6N/9W;M4?X..]7U>TN-#ZN[RT>FGBG&U>_P 1\%54
MU?XO*-\;,H ZX                            /GD15[E,T3,33,51,>K
MB8E]&E<Z=ZO2L "+H            Z7>G
MXH:U\GW_ +.7=.EWI^*&M?)]_P"SD@8Y&O?C/K_RQG?;UN$YNO?C/K_RQG?;
MUN$WQLS5;@#J(                           #YY'A8N3_LS]2JF/U2@TR?]7N_T)^I//V&<2UA=F'9EFSSW9QJJ
M_'VS5S/UJ;_A66MU>P&5>                                  L-],!
M^0/1/E:/^A$FEL],!^0+1?E:/^A$FUV?"IN;@"U4
M          R7@'CVL                    '7ZWKVB[;TZ]JVO:GCX.'CT
MS7\J6;KRO1.?PG\SY'O?W*D+GAE*G>$R@#$T@
M                       ""WTAO\+G=O\ 9<3ZJDZ2"WTAO\+G=O\ 9<3Z
MJEUGQ*[FRW,!J4                              )7?0^V[<=(MR78HB
M*ZM5KB:N/&8BJKA("L ]#]^1[VYY4_P!.GZV0EV9/R ;!^0,+[&E1?VA;
M:W5. 9EP                                  #2JJFB)JJJB(CSF9!J
MTJJIHIFJJ8B(CF9GU0M]Z_\ ;?Z'= ,>[B:WN*WJ6N13,V]+PJHKO3/PQ,Q$
M1\_K1D]H#TB77'K7=R-+T#,G:&WZJIBC'PZO]/YI^GU1>N=[^35W9F:?'VPCHZZ^DZZW=3;N
M1I73^*-GZ)]7D9=R;EDNQ]4W]N[,HQM-TJS5=N53,1-4Q$SW:?;,
M\3Q"!3M"]DZ;=.]S]6]]:5TZV;C3>U75[T6Z)XYIM43,1-RKV1',?2GH[.
M'0;:_9ZZ9:;L7;N/3%VW;IN9V1W8BK(OS'C55/K]4?,M\]'+V1*.C&R:>I.^
M--HG=^X;=-ZW[I1[[#QJHYIHCV3-,T3/PPO59;M?-.D+Z*=.L@"E8
M                   \_P!0=5IT/9&N:Q75W:JR-0R;DU>WF[5Q^I/QVKM=IV]V=M^ZA-?=J_<7)MT3[*IMSPQ^+=55
MSOW*IYFNNNJ?GJF6FQ'294W=VX!>J                              ;
M+T\6J_BX3D^CHT2K0^R;LRQ7'%5_&C(GP\^]33_X0:Y$556^[3',U5TQ'SU0
MR">RAI=.C]G38&#%ON54:+8[T<<>/"B_LMM;JL@,RX
M                     ! 1VS- C;?:=WQ@11W/=,NF]Q_2MTS_ (J,+I_2
M8Z/3IG:MUG*HI[L:AC6[WT444_X+6&ZB=:899W $G
M           $I/H>MR_=6R=W[6[_ /J6=.3W?9WN[3S^I(JB?]#WN*,/J3O;
M;4U\?=>#9OQ3_OU?^$L#'=C2N6BWX0!6F            .EWI^*&M?)]_P"S
MEW3I=Z?BAK7R??\ LY(&.1KWXSZ_\L9WV];A.;KWXSZ_\L9WV];A-\;,U6X
MZB                            ^65_JUW^A5]2?[L?V+6/V=-E6[-$4T
M_N;:JXCVS3$R@!RO]6N_T*OJ9 79%_@[[*^3+/\ =A1?V6VMU80&9<
M                            L-],!^0+1?E:/^A$FEL],!^0+1?E:/\
MH1)M=GPJ;FX M5                              ,EX!X]K
M        4HZ[=IGI/V>M#JU7?^XK-C(JIF
MI7;^]]T7[6ES7-5G2<6J:,>W'QF/\
MP>GG]9F?]I&JV6O!#/7XI %B                             O2]$K9H
MK[26K7JHYJM:15%,^SFBOE9:O5]$E_".UKY(G^[6A<\,IT;IB0&)H
M                         $%OI#?X7.[?[+B?54G206^D-_A<[M_LN)]5
M2ZSXE=S9;F U*                              $M?HA,>U3T(UC*II_
MTEW6LBFJ?;$5SQ]:_-8AZ(;\@&J_+>5_?7WL5SQ2TT[ ""0
M                 Z7>OXFZ]\F97V53NG2[U_$W7ODS*^RJ(&./KOXSZ]\K
M9?VDN&YFN_C/KWRME_:2X;?&S+.X ZX                            V
MW/*G^G3];(2[,GY -@_(&%]C2Q[;GE3_ $Z?K9"79D_(!L'Y POL:5%_:%MK
M=4X!F7                                 ZS<>Y="VEI&1KVY-5Q].P
M,6B:[N1D7(HHIB/;,HYNU%Z5&QCU9>SNSO9HRKLR**>9CXYA
M%WVCO29]5NK=63H/3"+^S]O7)JH]UIJYR[U$^'$U1/$1,?!ZY6F[MW;NC?\
MKM[R]9U._5-55[*NU5]WGU4Q5,]V/@AU+31:BGK*FJN9V;\B]D9N5=S
ML_)NY.3>JFNY>NU35575/G,RV M5@
M                                              ))_0Y?OG43^TXG
MV4I-T9'HRWV>
M-P]I/JEA;1TW'N1HV'?;,S3\TIX]C[*V[T[VKIVS-J:?
M1A:7I=BG'Q[-,1X4Q'$<\>DC_%#G3'=IBGV1PU6?
M"HN;M0%RL                             !]L&U[OJ.%8XY]TR;5/_/#
M(IZ1:=^Y/3+;6FQ3%/W/I]JCB(XXXACS[-P_W1WIH&G\3/W1J-FGB//\*)_P
M9'.AX\8FCX>-$<>YV::>/F9[_DMM.< SK@
M             $/?I:-)G"[0&A:E%/%.;H]?,^VJ+D1]4+)4A?IC-.IL;VV#
MJ=,1S>P[EJ9X_P#RE4^?S(]&VWX89J_%( FB
M      O ]%;JL:=VG[F)57W8U'2ZK?GY]RFY4F>03]@'69T/M5;2R._W:;T7
M[-7CY]ZU5$?6G89;T?B7V]@!2L            '2[T_%#6OD^_\ 9R[ITN]/
MQ0UKY/O_ &MPG-U[\9]?^6,[[>MPF^-F:K< =1
M                       ?++_U6]_0J^ID(=EW&LXG0+9%JQ3W:?W'Q:N/
MAFU3,L>_+_U6]_5U?4R%>S-^0?9'R+B?94J+^T+;6ZIP#,N
M                     6&^F _(%HORM'_0B32V>F _(%HORM'_ $(DVNSX
M5-S< 6J@                             &2\ \>U@             #C
MY^H8.EXEW/U'+M8V/8IFNY=NU13333$TJ\S8O0:FSK.KT]ZS>U>?]7QJX\)[O
MKFJ)]M,QX2C%W?O'=G4#7,CR]7U')KFY7[1'$0U:J:(IV45535N )H@
M                                            -MS\&/CCZV0EV9?R
M!;#^0<+[&ACVW/P8^./K9"79E_(%L/Y!POL:%%_:%MK=4X!F7
M     (R_3'_@]//ZS,_[2-5)5Z8_\'IY_69G_:1JMEKP0SU^*0!8@
M                     +U?1)?PCM:^2)_NUK*EZOHDOX1VM?)$_P!VM"YX
M93HW3$@,30                                (+?2&_PN=V_P!EQ/JJ
M3I(+?2&_PN=V_P!EQ/JJ76?$KN;+Q7/%+33L ()
M                   #I=Z_B;KWR9E?95.Z=+O7\3=>^3,K[*H@8X^N_C/K
MWRME_:2X;F:[^,^O?*V7]I+AM\;,L[@#K@
M #;<\J?Z=/ULA+LR?D V#\@87V-+'MN>5/\ 3I^MD)=F3\@&P?D#"^QI47]H
M6VMU3@&9<                             XVH:C@Z3A7M1U/,LXN+CT3
M7=NWJXHHHICSF9GP@')6_P#:7[9W2CLWZ1I;@N43.+I.-5%5VN?;/
MC$1'SK7NV!Z3FQH]S.Z=]GR]&1J-N9LY.N^,VK,^4^Y>7,QX\51,QX(SM;UK
M6=S:QE;AW)JF1J6IYMM2NJYITA5SM$=K;JWVD=:N
M96Y]5NZ9H=-AR_?.HG]IQ/LI2;
ML=WQRT4>$ 5I@                                           #@ZU
MK6E[=TK*UO6LVUB8.%:JO7[UR>*:**8YF9^9SO)&/Z3_ +7/N]5?9WZ?ZC,3
M5$5Z]E6:^8BGU68F/;[Z)CQ\DJ:9JG1RJ>6-5KO;6[3^K=I3JE?N8V171M70
M+E>+I=B*O>W9B>)NS'KGGOH ZX
M                         .SVQM?<&]]QZ?M#:F!7FZOJMZG'Q;-$<\U5
M3Q$S\',PZNNKNQSQ,S/A$1YU3ZHCX4J_HRNR%3L[1*>NW4+2N[K^J4?_ (IL
MW:>)Q<:?'O3$^/-4=R?5Y(5UF0U*..GVE45QS,Y-RN
MGCV56^/K1JMEKPL]SQ "Q                              ![#HOB_=W
M6;9&%Q5/NVL6XXI\_"FJ?\&179CNV;<>RF/J8]W9CPXS^T;T\QYK[G&L4U<_
M_FZV0E;_  *?BAFO[PNM;-P"A:
M      C-],CI\UV-@ZGS/^BO56_+V^Z2C32I^F$P:J^FFU=0BJ.+6IQ1QZ_P
M+DHK(\FRUX6>YX@!8@                              J;V8=5JT?M#[
M$RJ9F._J=%J9C_:F(_Q9"+',Z19G[G=7=EYW,1[EK6)XSY>-VAD5Z??^ZL''
MR>8GW6U37X?#'+-?WA=:<@!0M            '2[T_%#6OD^_P#9R[ITN]/Q
M0UKY/O\ VMPG-U[\9]?^6,[[>MPF^-F:K< =1
M                      ?++_U6]_5U?4R%>S-^0?9'R+B?94L>K+_U6]_5
MU?4R%>S-^0?9'R+B?94J+^T+;6ZIP#,N
M      6&^F _(%HORM'_ $(DTMGI@/R!:+\K1_T(DVNSX5-S< 6J@
M                      &2\ \>U@          -M==%JBJYEZWSBZ5;KCWG,>%5V8YFF/&/5/FI'VW?2
M)Z5TTIS.EO1S(LZENBNFJSF:A15S9P.?">)]=?GZICR12:SK6M;EU;)U_M2NNO3I#U76#K/U$Z[[KO;OZC:W=S
M;U=4S8Q(JG[GQ:?5311^#'QQ$>GG]9F?\ :1JI*O3'_@]//ZS,_P"TC5;+
M7@AGK\4@"Q                             7J^B2_A':U\D3_=K65+U?
M1)?PCM:^2)_NUH7/#*=&Z8D!B:                                !!
M;Z0W^%SNW^RXGU5)TD%OI#?X7.[?[+B?54NL^)75_?7WK$/1#?D U7Y;RO[Z^]BN>*6FG8
M 02                              '2[U_$W7ODS*^RJ=TZ7>OXFZ]\F
M97V51 QQ]=_&?7OE;+^TEPW,UW\9]>^5LO[27#;XV99W '7
M               &VYY4_P!.GZV0EV9/R ;!^0,+[&ECVW/*G^G3];(2[,GY
M -@_(&%]C2HO[0MM;JG ,RX                          !2#M']IKIYV
M;=FW]R;LS[=W.JIFG"TVW5S>R;G'A$1ZHYF/&9CS=B->D&NCV74[JELCI!M/
M+WGOW7+&F:;B4S,UW:HB:ZN/"FF)F.9GV(>^USV^M_=H7,R=J;0R,C;^R;5R
M8MT6:YMY&;'MN3'$Q3/A[WF8\/A4H[0W:5ZD=I/=EW7]XZA=L:715,8&DVZY
MBS8H]7,>NKV\S/G*E/EX0TV[44]9W455Z[-***+=/V043[IN155'OE6UN
MC.P=*V!M'#IL86FV*;?>XXJNU<>-57MF7LV*NOGG5HIIY8 $$@
M                   $4?I@]1F[U"V9I?NE$^XXEZONQYQS[G*/U>_Z7+-B
M[U^V]@>Y\3:TNJOO>WFFVL@;;?AAGK\0 F@
M     K5V*L.<[M4;!L18]VXSIJ[O'/'O*_%/G3^#'Q().P!9N7NUUL>FU',T
MWJJI^".[4G;9;_B7VMFH"E8
M   L4]+OB47.@&C9<6N:[>N41WN/*/*'2/*&NSX5%SQ "U6                              [#;.15A
M[NV[ET<=ZUK&%,<^7[_0R-MGW_NG:>C9$\?Z7!L5^'EXT0QO]/J]SUC2[L^5
MO4,6N?FNTRR,>E]Z,CIOM?(B)B+FCXE<1/GXVJ6>_P"2ZT]. SK0
M   !TN]/Q0UKY/O_ &_&?7_EC.^WK<)S=>_&
M?7_EC.^WK<)OC9FJW '40                           'RR_]5O?U=7U
M,A7LS?D'V1\BXGV5+'JR_P#5;W]75]3(5[,WY!]D?(N)]E2HO[0MM;JG ,RX
M                                 !8;Z8#\@6B_*T?]")-+9Z8#\@6B
M_*T?]")-KL^%3VY^#'QQ];(2[,OY MA_(.%]C0HO[0MM;JG ,RX               !&7
MZ8_\'IY_69G_ &D:J2KTQ_X/3S^LS/\ M(U6RUX(9Z_%( L0
M                %ZOHDOX1VM?)$_W:UE2]7T27\([6ODB?[M:%SPRG1NF)
M 8F@                                06^D-_A<[M_LN)]52=)!;Z0W
M^%SNW^RXGU5+K/B5W-EN8#4H                              2W^B&_
M(!JORWE?WU]ZQ#T0WY -5^6\K^^OO8KGBEIIV $$@
M          !TN]?Q-U[Y,ROLJG=.EWK^)NO?)F5]E40,5/\
M3I^MD)=F3\@&P?D#"^QI8]MSRI_IT_6R$NS)^0#8/R!A?8TJ+^T+;6ZIP#,N
M                         6O=M+MI;9[-.V;FCZ/>L:AOC4+4_<&G]Z)]
MS\/WRY[(CFGU3YNQ$S.D.3.G67:]KKMD;'[,NV:[-V_1J&ZLZW53I^G6JHJJ
MBOQXJN<<]VF.)\^/)"UU3ZK[\ZU[RR=^=1=8N9^IY$S%NF9GW/&M^JW;B9GB
M(YX\W6;UWKNKJ/N?-WEO;6+^I:KGW)N7+EVN:HHB?XM$3X4Q\$<.E:Z+<40H
MJKFH 6(
M                                 ))_0Y?OG43^TXGV4I-T9'HN4T441-5554\1$1ZYE#IZ1[M;7.LF\ZND^R=3JG:6W[LTY
MU5$SWWW?GHHY69+OO2I95W)[4WP I6
M            +//2F15/9?S^[$S$9='/$>4<2ADCRCXDUGI.8C[U7<',1/OJ
M?K0IQY1\379\*BYX@!:K                              ;K-4T9>)/ZFECL35-%5%R/.BNFJ/CB>60
MOV<@X,SQ_44*+^T+;6ZI #,N            '2[T_%#6O
MD^_]G+NG2[T_%#6OD^_]G) QR->_&?7_ )8SOMZW"MPF^
M-F:K< =1                            ?++_ -5O?U=7U,A7LS?D'V1\
MBXGV5+'JR_\ 5;W]75]3(5[,WY!]D?(N)]E2HO[0MM;JG ,RX
M                      !8;Z8#\@6B_*T?]")-+9Z8#\@6B_*T?]")-KL^
M%3YE95ZBS9M4S57775$4TQ'KF913>D#[>>=O34,WHKT>U6O
M'T;%KFUJVJV*O'+GUVJ)_D^$>KUSXO2>D5[=%V]=S.A/2#6(XFF;.NZC8J_!
MCUVJ*H]?C'/CX3$PC9MVZ;=/=I^/XY:+5O\ >E377Y0UHHIHI[M/U\M0:%0
M                                           !,Q'G, #;[I1_+CZ3
MW2W_ "X^D&X;?=+?\N/I:Q53/E5 -0
M       ;;GX,?''ULA+LR_D"V'\@X7V-#'MN?@Q\?UF9_VD:J2KTQ_X/3S^LS/^
MTC5;+7@AGK\4@"Q                             7J^B2_A':U\D3_=K
M65+U?1)?PCM:^2)_NUH7/#*=&Z8D!B:
M   !!;Z0W^%SNW^RXGU5)TD%OI#?X7.[?[+B?54NL^)75_?7WK$/1#?D U7Y;RO[Z^]BN>
M*6FG8 02                              '2[U_$W7ODS*^RJ=TZ7>OX
MFZ]\F97V51 QQ]=_&?7OE;+^TEPW,UW\9]>^5LO[27#;XV99W '7
M                    &VYY4_TZ?K9"79D_(!L'Y POL:6/;<\J?Z=/ULA+
MLR?D V#\@87V-*B_M"VUNJ< S+@                      %!^USVI=J=F
M7I]>U?4,BF]K^H6ZK>DX%,Q-=VYX^^F/.*8XJ\>..8X=B-9T@F='G.VEVR-N
M=FG9US#TJY9U'>&I4U6L'!HKYJLS,<>ZUQSX1'//S2A4WAO'='4'>K
MWM2U;4;M5R[=NU<]V)GF**?9$>4?$Y'4#?\ NWJKO+4.H&^]0G-UG4JYJNU\
MSW;=/,S%%$=4?2#4;?=+?\ +CZ3W2W_ "X^D&X:171/
ME5'TM?/R                                      !)/Z'+]\ZB?VG$
M^RE)NC(]#E^^=1/[3B?92DW8[OCEHH\( K3
M               %*>TIUYVSV>^E^J;WUW+HC)HM56\#&[WO[]^?"F*8^#GG
MXHE4G6M9TW;VDY>N:QEV\;"PK55Z_>N513311'G,S/D@S[;7:@U/M+=4;]6)
M>JIVEH%VJQI-CF8BY,U- N49.I9$T^\O33/,6HGU^/=Y^"5'NF?3
MG<_5W?>E=.]G8M5[4M6O1;BKCWMFCGQKJGU1'^*>?LY]"-K]GKIEIFP]N6*>
M_9MQ7F9''OLB],>^KG]4?,JNU\L:1NLHIUG54/1=%TO;NE8NB:+A6L3!PK5-
MFQ9MQQ3113'$1'S0YP,B\                                 !"SZ4O
M^%1>^2L?[.E:.NW]*1737VJ;\4SSW=+QHGX/]'"TAMM^&&:K< 31
M                      70>C9_A7:%_45?6F^0@^C9_A7:%_45?6F^9;WB
M7VM@!2L                                        6F^DY_@J[@_I4
M?6A3CRCXDUGI.(F>RIN'CU33/ZT*<>4?$U6?"HN>( 7*P
M              &VY^#'QQ];(3[,_P"0/8?R!@_84,>RY^#'QQ];(3[,_P"0
M/8?R!@_84*+^T+;6ZIH#,N            '2[T_%#6OD^_\ 9R[ITN]/Q0UK
MY/O_ &MPG-U[\9]?^6,[[>MPF^-F:K< =1
M                   ?++_U6]_5U?4R%>S-^0?9'R+B?94L>K+_ -5O?U=7
MU,A7LS?D'V1\BXGV5*B_M"VUNJ< S+@
M    %AOI@/R!:+\K1_T(DTMGI@/R!:+\K1_T(DVNSX5-S< 6J@
M                   &2\ \>U@     "Q'TB7;9M]*M&O\ 1[IOJ%%>[-5L
MS1F9%NKQP;%4<3/P53$U9^;F976K?-
MUE777ITAP;ER]?O79_7
M,JYOQ&R46Y00;8Z%=:MZ56XVOTOU[.IN_@W*,?WGTS*K>VO1U=K'<-='W1L:
MWI5JOQ[^7753,1\T2G$LX&#CQ%./AV+<1X1%%N(^I]O+PA";\^2<6X1%[?\
M1%];,^FF[KV]-$P*:O.FU7557'S30J!HWHU36K\Q//>
MJNU1S\'X:^,<[RKU=Y*5G$>BP[,T1$?<&H>$S-_P#J_4/_
M ,(N?MKQ@YZO4Y:?19S_ /"Q[,W_ .K]0_\ PBY^VZW.]$YV<]-?QZN)X\.]X_/6\CK'H9-$2B>UKT/\ U.QXJG0.I&FY7'X,94=S
MG]&B5,=S>C%[4F@Q5.G:9I>K]W_TUVN>?B][":\2B]4YW=+'_P!S=D#M.[0Y
MG6NC^M5TT^=>-:[U,1[?&84UU?:F[=OW9L:[M;4\"NGSB]8F.&2/7:M7(XN6
MJ*OZ5,2\IU%VOMS5-EZ[3J&AX5^*=-RJH[]FGPGW*KQ2B_/G",VF.>.5K5%-
MO<>N6K=,4T6]5RZ*:8\HIB[5$0XK2JGH #@
M  #;<_!CXX^MD)=F7\@6P_D'"^QH8]MS\&/CCZV0EV9?R!;#^0<+[&A1?VA;
M:W5. 9EP               ",OTQ_P"#T\_K,S_M(U4E7IC_ ,'IY_69G_:1
MJMEKP0SU^*0!8@                            +U?1)?PCM:^2)_NUK*
MEZOHDOX1VM?)$_W:T+GAE.C=,2 Q-
M  @M](;_  N=V_V7$^JI.D@M](;_  N=V_V7$^JI=9\2NYLMS :E
M                      "6_P!$-^0#5?EO*_OK[UB'HAOR :K\MY7]]?>Q
M7/%+33L ()                              #I=Z_B;KWR9E?95.Z=+O
M7\3=>^3,K[*H@8X^N_C/KWRME_:2X;F:[^,^O?*V7]I+AM\;,L[@#K@
M                      #;<\J?Z=/ULA+LR?D V#\@87V-+'MN>5/].GZV
M0EV9/R ;!^0,+[&E1?VA;:W5. 9EP                    #J=U;GT;9FW
ML_<^X,VUBX&G6*\B]=N513$4TTS/'CZYX\ >.Z]]<=H]G_IUJ/4#=N513:Q:
M)C'Q^??Y%V8F:;=,>V>$$O7#K5O+K]U!SM_[RS;E7O\ MC=J?7NTYU'O9EK(NV-IZ1VH:W>/G5S=IA.**I13UY%FBJ**JO?3Y1$3/+OM!V-OG=-V+&VMFZMJ5<^
M46+'//T\)S=B]B'LS[ LTT:1TNTJ[=IGGW:_1-5?/M\^%8]*VOMS1,>C$TG1
M,+%M6XXIIMV:8XA";_I"46O5!-MKL/=JO=ENB_I_2C4,6S7_ !LRF:.(^;E5
MG;7HI^T=K=-%>JZAH>DQ/C53=O5]Z/\ D3)4T4T1Q13%,?!'#IA[O2?0Z=.:::?W;ZFZW?GQ[WN=BBGGZ*H2
M(B/>U^KO)2L2P/1"] ,6NFO)W%KN5Q'C%54T\_16[[!]%/V:\2U-N[:U._,S
MSWJK]<3'P?AKSQSO*O5WEA9S_P#"Q[,W_P"K]0__  BY^V?_  L>S-_^K]0_
M_"+G[:\8.>KU.6GT68YOHJ.S5E68M6K&IV*N>>_3D7)G^^Z#/]$+T RJZJ\;
M<6NXO,<1%-4U<3[?&M?:'/5ZG+".W5_0Z=.ZHG]PNINM6)]7NEBBKZYEX;6/
M0[[FM=Z=!ZL4WY_BQE6**(_Y8E*6.][5ZNT3HT55Z3K&A:I3'X
M,6[U?>G_ )%+-P=@KM8[;IN76KMWK54V[]FY:KCSIKIF)9*5
M_3--RJ9IR=/QKL51Q,5VJ9Y_4AT]*MHFD:%VAM%LZ/IUC#HOZ1FJ._1-
M41$W9CU13WHJCGV.Q$S.D.3.D:RM:])[VNIR*J^SWT]U3O47*>]KV78KX[L<
M>%F)CQ\8JGGX:4;--,44Q33'A#DZCJ6HZUJ>9KFL9=S*S]0OUY.3>KGFJNY7
M5-4_KF7';::>6-&>J>:=0!)$                              (INW*Z
M+./:JNWKM46[5NF.9KKGPBF/AF29BF)F9XB%]?HU.R)P_D#!^PH8]ES\'YX^MD)]F?\@>P_D#!^PH47]H6VMU30&9
M<            .EWI^*&M?)]_P"SEW3I=Z?BAK7R??\ LY(&.1KWXSZ_\L9W
MV];A.;KWXSZ_\L9WV];A-\;,U6X ZB                            ^6
M7_JM[^KJ^ID*]F;\@^R/D7$^RI8]67_JM[^KJ^ID*]F;\@^R/D7$^RI47]H6
MVMU3@&9<                                  L-],!^0+1?E:/^A$FE
ML],!^0+1?E:/^A$FUV?"IN;@"U4                              R7@
M'CVL    >,ZO]5-L=&.G^J]0MVY=%C!TRS5*JI]L4S%H6ZLJNJF]?10:UKUO%W+UYUFO3[,\7(T;$_"F/9B-ED6YG=%U
MT4]%9UAWU[AJO5#5;&U--N^^G'MQ[KD3'LF.:9IE?7T?]'QVWXF:_\EY7V53NG2[V_$S7_DO*^RJ(
M)8X^N_C/K_ROF?:U.&YFN_C/K_ROF?:U.&WQLRSN .N
M           -MS\&/CCZV0EV9?R!;#^0<+[&ACVW/P8^./K9"79E_(%L/Y!P
MOL:%%_:%MK=4X!F7                (R_3'_@]//ZS,_[2-5)5Z8_\'IY_
M69G_ &D:K9:\$,]?BD 6(                            "]7T27\([6O
MDB?[M:RI>KZ)+^$=K7R1/]VM"YX93HW3$@,30
M         (+?2&_PN=V_V7$^JI.D@M](;_"YW;_9<3ZJEUGQ*[FRW,!J4
M                           );_1#?D U7Y;RO[Z^]8AZ(;\@&J_+>5_?
M7WL5SQ2TT[ ""0                              Z7>OXFZ]\F97V53N
MG2[U_$W7ODS*^RJ(&./KOXSZ]\K9?VDN&YFN_C/KWRME_:2X;?&S+.X ZX
M                          VW/*G^G3];(2[,GY -@_(&%]C2Q[;GE3_3
MI^MD)=F3\@&P?D#"^QI47]H6VMU3@&9<                    VUU4T4S7
M75%--,=,33$_
M.NE](IVLK70SI_.Q=JY--6[=SVJK5F::O?8MGQYN_'S''SH:*J[UVY7?R;]=
MZ]=JFNY=KGFJNJ?.9GVK[-'[TJKE7E#2FFFFF*:8XB(XB/8 TJ0
M                         :<^^IMTTU55USQ333$S,S\$0N:[//H_NMW7
M:[8U34]-N[4VW^E*
M7T$[ _0GH79LY>-H5&O:U1'O]0U&COU3/P43,TQ]"X^QCX^+:IL8MBW9M41Q
M31;IBFF(^"(457_X5D6_58MT=]%!T?VE%C4^I>IY>Z=0IB*IMSN!LO:>F:3:MTQ3'W+C46YF/AF(CEZ@4S5-6ZV*8C8 1=
M              $._I;/X16@?(MW^];3$(=_2V?PBM ^1;O]ZVLM>)&O992
MV,P                             "2?T.7[YU$_M.)]E*3=&1Z'+]\ZB
M?VG$^RE)NQW?'+11X0!6F                                     VU
MUT6Z9KN51333',S,\1 /,]3.HFV^E>R=5WSNK.HQ<#2\>J]755,[C8\3,TQQ[>*N)\/4N&](YV
MMKO6;>M72G9>H5T[6VY>FG+NV:O>YN1$3SS[:8BKCXZ5F'EY-5JCEC65%=6L
MZ0 +E8                              #M-K;7W!OCU1$1Q33'$<^V?#S4I[(G9IT#LU]
M+\/;N);MWM:S+=-_5<^,_X)Q$%?H\JZ*.U[LWO
MS$=ZJJ(Y]<]VI.HRWO$OM[ "E8
M      M']*!EVL?LL:U:N<\Y%VFW1Q[?/_!"S'E'Q)E_2I7K5KLQ95%RN(F[
MFT4T1[9[L^"&B/*&NSX5%S< 6JP                             "(BJ
M[9HGRKNT4S\4U0R'.SYCVL7HCLBQ9CBBG0<+B/\ \S0QYL:F*\_!MSY5Y=BF
M?BFY$,BKHYC6L3I/L_'LQQ11H>%$1_\ F:5%_:%MK=[$!F7            #
MI=Z?BAK7R??^SEW3I=Z?BAK7R??^SD@8Y&O?C/K_ ,L9WV];A.;KWXSZ_P#+
M&=]O6X3?&S-5N .H@                           /EE_ZK>_JZOJ9"O9
MF_(/LCY%Q/LJ6/5E_P"JWOZNKZF0KV9OR#[(^1<3[*E1?VA;:W5. 9EP
M                             "PWTP'Y M%^5H_Z$2:6STP'Y M%^5H_
MZ$2;79\*FYN +50                             #)> >/:P  'DNJW4
M70^E'3_6M^[ARJ;&'I.+5>F9X\:O"*8CGVU3 +3?26=JNKI/L/\ S7;)U2*-
MT[DHJM9$VZO?8V),1%+B3Y]V*9YBJ8\/&8CUH5UQ1NE33-2SKLO^CJZH=I[N5DT^RFF?&CGX:4K'17LW]).@FBT:3T]VMC8ER*>+V951
M$W[T^VNKB.9^;UJFV;-K'M4V+%JFW;HCNTT4QQ%,>R(;V6JY->Z^FF*0!!(
M                   =+O;\3-?^2\K[*IW3I=[?B9K_ ,EY7V51!+''UW\9
M]?\ E?,^UJ<-S-=_&?7_ )7S/M:G#;XV99W '7
M      &VY^#'QQ];(2[,OY MA_(.%]C0Q[;GX,?''ULA+LR_D"V'\@X7V-"B
M_M"VUNJ< S+@               $9?IC_P 'IY_69G_:1JI*O3'_ (/3S^LS
M/^TC5;+7@AGK\4@"Q                             7J^B2_A':U\D3_
M ':UE2]7T27\([6ODB?[M:%SPRG1NF) 8F@
M       06^D-_A<[M_LN)]52=)!;Z0W^%SNW^RXGU5+K/B5W-EN8#4H
M                         2W^B&_(!JORWE?WU]ZQ#T0WY -5^6\K^^OO
M8KGBEIIV $$@                             !TN]?Q-U[Y,ROLJG=.E
MWK^)NO?)F5]E40,5/].GZV0EV9/R ;!^0,+[&ECVW/*G^G3]
M;(2[,GY -@_(&%]C2HO[0MM;JG ,RX                  >-ZN]4=N='.G
M^K=0-T9%-K#TNQ5<[LU<3=KB)FFB/AGA[&9B(YGU(B?2@=INYU"WW'1/:N?-
M6@[?KBO4ZJ)XB]E1/X$\>?=FFJ/G3HIYYT1JJY86F=9>K&Y>MW4C6.HNY\NY
M=NY]^J,:W5/,6+$3Q13'S1$O%D1Q'$>H;8C1G !P
M          !MN7*;<1-7/,SQ$1YS/L@&Z9B(YF>(A4;HGV?.JG:"W#1H'3O;
M]Z[:YCW;4;U$TXUFGUSWYXBJ8CGPB>5R?9&]&[N[J[5B[XZPVLC0=K3--W'P
M>*J\III\_&.?+X4L&P.G.R^F&WL;:^Q] Q-+T_%HBBFW8M4TS5QZZ
MIB/?3\,J:[L4](64VYGK*V3LR^CCZ3]%K.)N'>6+:W5NJB(KG*R:(FU8K\_]
M'3,)&O992 V,P
M                             "2?T.7[YU$_M.)]E*3=&1Z'+]\ZB?VG
M$^RE)NQW?'+11X0!6F                                    +'/23]
MKBCI1LZOI)LC49IW9N*U--V]9K\(-*JN['/$S/E$1YU3ZH
MCX92M>C+[(4;*T2GKGU"TF*=P:I1_P#BFS=HXG%QI\>]Q/KJB**H6O>CV[).
M1U[W]1OW=VGUQLS;EZF[355$]W,RJ9YIHCU3%,Q1,_!*:'%QK&%C6]7^["VW3YR^H#.N
M                1&^EYP:[?6C:^H39B*;NG5T17ZYXBVL32(^F)TSW+=6Q
M=5]SJCW:QD6^]ZIXFVCN;+7AAGK\4@"Q
M  !7KL'9%C%[6NQ+F15W:9R9IB?A[E:>./*$ '8_SOW.[3W3_(BU[IWM2[G'
M^Y6G^H_!CXF6_NOM;-P"E8
M  LD]+1DV;'9OQ+5R>*KVL444?'[G7/^"'R/)+3Z7S.JHZ(:!I_=CNW=:IKF
M?7^]7(1+1Y-=GPJ+GB %JL                             !R=)HF[KV
MBVHCF:]4PZ/IO4PR-.GEF<;86W<>J(B;>EXU$Q'EX6Z6.ULC#G4-^[7P8H[\
MWM:PH[OMXOT,C3;5C[EV[IF-W>[[EB6J./9Q1$,]_P EUIV0#.M
M   '2[T_%#6OD^_]G+NG2[T_%#6OD^_]G) QR->_&?7_ )8SOMZW"MPF^-F:K< =1                            ?++_ -5O?U=7
MU,A7LS?D'V1\BXGV5+'JR_\ 5;W]75]3(5[,WY!]D?(N)]E2HO[0MM;JG ,R
MX                                 !8;Z8#\@6B_*T?]")-+9Z8#\@6
MB_*T?]")-KL^%3%R]Q/%N>/..*J)^9(-VH.MF!T"Z-:]
MU"R;E'W5BV*K>#:F?&[D33,T4Q'G/X* ;7=-K:^R-/N4X5NJ)U#4ZZ9]QQ;?KGGUSY>43YP[SLL]EC>_
M:@WK;TC1[5W!VYAW(G5-6JIF***.?&BB?")J\_*9\I\$W/1KHOL/H7LO$V1L
M'1[>%AX]$>ZUQ$>Z7[GKKKF(CF?\.%5RYR](W644HB;U^OCQ\?5'//E$>:M8,LS,]97Q&@ X
M        #I=[?B9K_P EY7V53NG2[V_$S7_DO*^RJ()8X^N_C/K_ ,KYGVM3
MAN9KOXSZ_P#*^9]K4X;?&S+.X ZX                            VW/P
M8^./K9"79E_(%L/Y!POL:&/;<_!CXX^MD)=F7\@6P_D'"^QH47]H6VMU3@&9
M<                C+],?\ @]//ZS,_[2-5)5Z8_P#!Z>?UF9_VD:K9:\$,
M]?BD 6(                            "]7T27\([6ODB?[M:RI>KZ)+^
M$=K7R1/]VM"YX93HW3$@,30                                (+?2&
M_P +G=O]EQ/JJ3I(+?2&_P +G=O]EQ/JJ76?$KN;+5_?7WL5SQ2TT[
M ""0                              Z7>OXFZ]\F97V53NG2[U_$W7OD
MS*^RJ(&./KOXSZ]\K9?VDN&YFN_C/KWRME_:2X;?&S+.X ZX
M                VW/*G^G3];(2[,GY -@_(&%]C2Q[;GE3_3I^MD)=F3\@
M&P?D#"^QI47]H6VMU3@&9<                 V7;M%FU7>N513113-54SZ
MH@% NVQVA,'L^=%M2UNB]1^[&JVZ\'3;7>]]5KGFJNY5/-4_3*Y?T@W:#O]%W9
M][]777,\1'ZTJ/8E]')IFQZ<+JEUNQ+6H;@KIINXFDW(
MYLX?/C$U1ZZX\/7,>:H/8C[!^W>@.E8V^-\XUG4M^9=J)N79XJMX43'X%OS\
M?&>9B?6O$9KEW7I2NHHTZR^=BQ9QK-&/CVJ+5JW$4T441Q%,>R(?0%"T
M                    0[^EL_A%:!\BW?[UM,0AW]+9_"*T#Y%N_P!ZVLM>
M)&O992 V,P                             "2?T.7[YU$_M.)]E*3=&1
MZ'+]\ZB?VG$^RE)NQW?'+11X0!6F
M  .#K>M:;MW2-AX5JJ]>NUSQ333#G(RO2?=KNY557V>>G>KQ_I:>
M=PY-BYS$4><68F/"?.B?7Y)4TS5.D.53RQJM<[;7:@U#M)]4LBYIF5;TQ[9CCZ%O+2BBFW3%%$1%,>$1#5MB(IC2&:9UZ@#K@
M                          ]_T)Z+[GZ^]2]+Z>;:QKDT9-VFK/RHCFG&
ML1XS5,_#X1\[PV#@:CJ^?C:1H^%=S,_-NTV,;'M4S55JQ1/&/?O6IJ]G>JH_\(Q4L_I>=
M*]WZ+:'J\4453//C\R)ALM>%GN>( 6(
M           /?]GC+G [0'3W+BY-N*-:H[U4>J.Y6R';<\VZ9_V88Y?2G,_<
M[JKM#4._W?N?5K57>XYX\X_Q9&&)%-R$7:2#TRF=7&?T]TV*Y[M??O33ZIXFY"-]LM>%GN>( 6(
M                    /:]#L.-0ZV[%PJJ>]3XXY_!CG_  3_ #-?WA=:V %"T
M         =+O3\4-:^3[_P!G+NG2[T_%#6OD^_\ 9R0,S-^0?9'R+B?94J+^T+;6Z
MIP#,N                                  6&^F _(%HORM'_0B32V>F
M _(%HORM'_0B3:[/A4W-P!:J                              9+P#Q[
M6 ICVD>K6F]%>CNXM\ZA?IMUX^)N535Q\W/#B-M-/+&C-5.LZ@"2(
M              J[V8^S;O#M.=0K6TMOVZL?2<2JFYJ^HU1/9YIB?Y4Q
M35$1X>/#Q_2CI;NSK1O[2^G>SL&Y?S-1NQ3.7M09-V@
M                 =+O;\3-?^2\K[*IW3H=^W)M;&W'=B.9HTG,JCYK-1!+
M'+UW\9]?^5\S[6IPW(U:N;NOZU=F.)N:GE5S'PSGG]9F?]I&JD
MJ],?^#T\_K,S_M(U6RUX(9Z_%( L0                            %ZO
MHDOX1VM?)$_W:UE2]7T27\([6ODB?[M:%SPRG1NF) 8F@
M                 06^D-_A<[M_LN)]52=)!;Z0W^%SNW^RXGU5+K/B5W-E
MN8#4H                              2W^B&_(!JORWE?WU]ZQ#T0WY
M-5^6\K^^OO8KGBEIIV $$@                             !TN]?Q-U[
MY,ROLJG=.EWK^)NO?)F5]E40,5/].GZV0EV9/R ;!^0,+[&E
MCVW/*G^G3];(2[,GY -@_(&%]C2HO[0MM;JG ,RX                6Q>D
M#Z]T=$>@^J4Z9GTV=P:_1.!IU,5<5Q55$SWX^".[,?.N1I.F9E5S0]HTS@X]$5>]JN^$UU?'%450LMT\U2%=6D+7(
MFY5-5R])HFB8-W-U'/NTV,7&M4
M\UW+E4\1$1\VJVZ;M5==$51@T3Q,44<^57$1
MS,1$\\PISZ-[L56]GZ9C]=>INFTU:[J-OO:7A7J/]4LS',5S'\J8FGZ/4D)B
M(B.(CB(9KMS7\,+J*-.LM0%"T                          0[^EL_A%:
M!\BW?[UM,0AO]+%DU7NTII=BJ(B,?2*HB?;S[G*VSXD*]EF(#6S@
M                     ))_0Y?OG43^TXGV4I-T9'HM![J>IZCKFJ9FNZQE7,G/U"_7D9%VY5-555=4\^<^S
MR^94'M$==]R=HOJ?J/4'7KUVG%JKFUIF+5/O^'MF..?B4U;+=')#/7
M5S2 +$                              !I55%%,UU3X4QS+5<3V).RWJ
MG:4ZGV:L_'NVMIZ!=HR=1R)I]Y>JIGFFU$^OF8B)^"7)F*8UEV(UG1F)]?A3-/GYI.HB(CB(XB'#T71M-V]I
M.)HFCXEO%PL*S18L6K=/%-%%,1$1]$0YK%55-4ZM%,]'Q1%%1_8R.>/<[UNKZ*X9#_034_W9Z-;
M/U3O=[[ITJS^ 9UP
M         ")OTP.K?=75+9>D=[G[FTVY=XY__*3ZOG6"KR/2K:I&?VE,3$BK
MG[@TF;7'LYJIJ_Q6;MMOPPS5^*0!-$                             !
M*N
M/*:O=(E,6R7I_$OM[ "I8            .EWI^*&M?)]_P"SEW3I=Z?BAK7R
M??\ LY(&.1KWXSZ_\L9WV];A.;KWXSZ_\L9WV];A-\;,U6X ZB
M                  ^67_JM[^KJ^ID*]F;\@^R/D7$^RI8]67_JM[^KJ^ID
M*]F;\@^R/D7$^RI47]H6VMU3@&9<
M  L-],!^0+1?E:/^A$FEL],!^0+1?E:/^A$FUV?"IN;@"U4
M                 R7@'CVL18>EMZWTZQK^B=#=*RHFS@?_ (PU**)\9JF?
M>4S\55OGYTF^\-QX&T-K:IN;5+]-G%T[%KOW*ZI\(XCP_7PQY^KW47.ZM]4-
MR=1M0N37:ZS3K.JNY.D:/(@-2@
M                ;K=K)R+UK%PL:YD9-^N+=FS;IF:KE<^5,1'K;9F(CF9\
M%\_HP^RY/4C>G^?#=F#%>A;=O=S3;5ZCFG(R8J_#XGPF*9HX^=&JKEC678C6
M=%X/H^^R9A] .G=&ZMPX]-S=^Y;5-_,N51S./;GB:;43[.*:9^.5VS2FFFBF
M***8IIICB(B.(B&K%5,U3K+3$:1H ..@                         #S_
M %"_$'K?*.3
M]I+X/MGU17K&J5TSS37GY%43[8FY+XM[(
M   VW/P8^./K9"79E_(%L/Y!POL:&/;<_!CXX^MD)=F7\@6P_D'"^QH47]H6
MVMU3@&9<                C+],?^#T\_K,S_M(U4E7IC_P>GG]9F?]I&JV
M6O!#/7XI %B                             O5]$E_".UKY(G^[6LJ7J
M^B2_A':U\D3_ ':T+GAE.C=,2 Q-
M @M](;_"YW;_ &7$^JI.D@M](;_"YW;_ &7$^JI=9\2NYLMS :E
M                     "6_T0WY -5^6\K^^OO6(>B&_(!JORWE?WU][%<\
M4M-.P @D                              .EWK^)NO?)F5]E4[ITN]?Q
M-U[Y,ROLJB!CCZ[^,^O?*V7]I+AN9KOXSZ]\K9?VDN&WQLRSN .N
M                    -MSRI_IT_6R$NS)^0#8/R!A?8TL>VYY4_P!.GZV0
MEV9/R ;!^0,+[&E1?VA;:W5. 9EP               "B/;'ZRV.B'07<6[(
MOTT9MZQ5A8435Q5-^[3--$Q[>)F$"-[*OY^5D:EEUS7D9MZO)O53YS775-4_
MKF5^_I:>M$[CZ@Z-T:TS+IN8>B6HSLV+=7A[K7QW8J^&)HE8,UVJ=*=5%R=9
M %JL                              7D^CE[)D]:]\T]3=ZZ=55M+;MV
M*\:BNGWN7DQXQY^$Q'-,^OR6T]&^E.X.MW4O1>FNW+5/3:YBGB;E7KJJ]L_"INU\L:0LHIU
MG67K[-FUCVJ+%FW31;HB*:::8XB(CU-X,J\
M   0T^E=_A-8/R3_ (6TRR&;TK5VW<[3N+;HJYJM:5$5Q[.:;DB[6ESK!O6OI'LS/J_R6V[>FG-NVZ_>YF3'PQX33
M'O9]?C"ZOTD?:YIZ2;.JZ4[(U*G_ "KW%9FB[7:J]_A6)\Z_@J_!X^"40,=^
M9JKN7*KE=$ -"D
M               BF[NU1;M6Z(YJKKGRICX9!Z;IETXW-U=WYI
M/3O:&)7>U#5KU-OO13,TV;?KKJGU1_Y3U=G;H5M?L]],M,V!MNS3-6/;BK+R
M>[Q5D7IB.]7/T1]"W_T=?9%HZ(;(CJ!O/ HJW=N*U3=_TE'-6)8GB::*>?*9
MB*9^=>]H31HW!T1WMHTV^_.7HN5;ICX9HF(8\ERS.-D9&//G:OW;?T5S'^
M#)-W!I].K:)G:;53WHR;%=J8]O,,C5QQ5AZIDT3'QW*I_P 6
MBQ.\*;ODZ4!H5                              /GDQS9GX)B?HF$^G8
MLURG7^S'L#+IGGW/2+-J9YY\8C_]* VY'-NJ/@E-GZ,K5?W2[)FV;D5UJ-:[66Z>Y5%5O$ILV:./ZJW,_K6V*G=J'6ZMP]HK?>H5535W=
M2FU$S[*:8C_!3%NIC2F&6=P!)P                             GRD$C
M'H<=#BYKV_MP7;4\TVK-BW7\5<\Q^M*,L)]$3MG[AZ-:YN6NWW:M1U6Y;B>/
MPJ::;_JZOJ9"O9F_(/LCY%Q/LJ6/5E_ZK>_JZOJ9
M"O9F_(/LCY%Q/LJ5%_:%MK=4X!F7
M  +#?3 ?D"T7Y6C_ *$2:6STP'Y M%^5H_Z$2;79\*FYN +50
M                  #)> >/:UF/I1NLM73SH-:?=:N*
MYGX_?S"T=LM4\M+/7.L@"Q                              F8B)F?4#
MTO3/I]K?5;?^B=/M QZ[N3J^51:N33'/N=GF/=*I^*GO3\S(%Z/=,=!Z/].]
M&V#M[%MVZ7>[$5US\,S$S\ZP7T2W0#W+%U3KYN' B:LSG#T:
MJKSIHB/?5Q'PQ7,<_ DN9;U6LZ+[=.D:@"E8
M    /']8+UJQTLW9=O5]VB-&S.9__,UO8*<]HG+IPNB.],FNF:HHT;+\/_S5
M3L;N2QZ+M459>773/--63=JB?;$U2T?.Q5%RU%V(XBY[^(]G/B^C>R@
M                        -MS\&/CCZV0EV9?R!;#^0<+[&ACVW/P8^./K
M9"79E_(%L/Y!POL:%%_:%MK=4X!F7                (R_3'_@]//ZS,_[
M2-5)5Z8_\'IY_69G_:1JMEKP0SU^*0!8@
M +U?1)?PCM:^2)_NUK*EZOHDOX1VM?)$_P!VM"YX93HW3$@,30
M                      (+?2&_PN=V_P!EQ/JJ3I(+?2&_PN=V_P!EQ/JJ
M76?$KN;+Q7/%+33L ()                              #
MI=Z_B;KWR9E?95.Z=+O7\3=>^3,K[*H@8X^N_C/KWRME_:2X;F:[^,^O?*V7
M]I+AM\;,L[@#K@                           #;<\J?Z=/ULA+LR?D V
M#\@87V-+'MN>5/\ 3I^MD)=F3\@&P?D#"^QI47]H6VMU3@&9<
M   .GWAN'$VGM;5=R9UZFU9T[$NY%557E[VF9C]?#N%G_I.NK]SIKV?,C0M/
MR8MZANJ]&!;B*O?Q3$Q75/'LXIF':8YIT5,BX[-O^;_I_?ZN[HP(IUW]M]G?IAJ6^]=O457[=$V\'&F
MKWU^_,>\IB/.8YXY^-4C6M9T[;VDY>MZMDT8^'@V:K]Z[7/$4T4QS,H-NVWV
MH,_M*=4LBK2\ZY.SM"N56-*L3,Q3=JB>)O3'EX\4S"RW1SRA75RPHOU"W]N3
MJEO75=_;LSKF3J&JWZKOOYY]RM\^]HCV1%/$?,\^#9LH !P
M                 F8IB:IGB(\97W>C1[(M74;<=OKGOS3Y_<#2+O&DXUZC
MPR;],_OO$^JF8IF/C6Y=E;LZ[A[2G5+#VKIUBNG1<"Y1D:QE1$]VW9B>>YS[
M:ICCYT\.R=FZ!T_VMIVS]L8%O#TW3+%&/8M41$<4TQ$1,\><^'FINUZ1RPLM
MTZ]9=U111:HIMVZ8IIHB*:8CRB(]3<#*O
M                 &/OVL-LW-H]I'?>DW*.YW]0]VIIXX\*J*9_Q9!"%3TG
MNV)T'M19FJ>Y]V-B.W#]V]#=6V_7 ,;0
M                      .!KV=&F:+FZC55W8QK%=R9]G$I_U_UNC;G1
M7>FM5UQ3.+HN5O3DY63E3YW\B[=_2KF?\ %M;X9                              !
MMNU13;JF?8W-*K%>55;Q;?X=ZY11'SU0";ST;6W;FW^RCM7W>U[G'I-JW7'''CXJDL%4ZS+5'2 !QT
M         =+O3\4-:^3[_P!G+NG2[T_%#6OD^_\ 9R0,S-^0?9'R+B?94J+^T+;6Z
MIP#,N                                  6&^F _(%HORM'_0B32V>F
M _(%HORM'_0B3:[/A4W-P!:J                              9+SSW4
M+=>-L;9&M[OS*Z:+.D8-W+JFKRXHIF?\'H5HGI.^I?\ D+V;-0T?$R*K6=N+
M(MX%ONU<3-NN)IK^;QA@IC6=&J9TC5#IO/<>7O'>FO;MSKDW+^JZA>OU53//
MO>_,4_\ +$.G;;5,T6Z:9\XCQ^-N;V4
M =QLO:6H[^WEHFQ])M5W,O6LRC&MTTQS,>N9^B)=.O;]%/T@HWKUEU#J5GX\
MSA[3M=S'KFGPG)J[LQQ_NU5(U3RQJ[$:SHE3Z1=/-*Z5=.-!V%H]NFG&TC#H
MQXF*>.],1XS/PO8 PM0                              H[VN]0C3.SM
MO7)F[[GSIMVWS_2IF./UJQ+>.WYJU'^Q'U/HW,H
M#;<_!CXX^MD)=F7\@6P_D'"^QH8]MS\&/CCZV0EV9?R!;#^0<+[&A1?VA;:W
M5. 9EP               ",OTQ_X/3S^LS/^TC525>F/_!Z>?UF9_P!I&JV6
MO!#/7XI %B                             O5]$E_".UKY(G^[6LJ7J^
MB2_A':U\D3_=K0N>&4Z-TQ(#$T                                ""
MWTAO\+G=O]EQ/JJ3I(+?2&_PN=V_V7$^JI=9\2NYLMS :E
M                "6_T0WY -5^6\K^^OO6(>B&_(!JORWE?WU][%<\4M-.P
M @D                              .EWK^)NO?)F5]E4[ITN]?Q-U[Y,
MROLJB!CCZ[^,^O?*V7]I+AN9KOXSZ]\K9?VDN&WQLRSN .N
M               -MSRI_IT_6R$NS)^0#8/R!A?8TL>VYY4_TZ?K9"79D_(!
ML'Y POL:5%_:%MK=4X!F7              "'KTK?5&G>'6W3>G^+?[V-M;&
M[UZB)\(R*IJ\_P#=JA+SK&I8VCZ7E:IF7*;=C%M57*ZJIXB(B&/!UJWKE=1^
MK^[=[Y5^J[.IZEU^FF=U@U;%[NH[FNS;QN_3[
MZC&H\:9C^E%<_0BVV+M7-WWOG0=EZ=9JN9&KYUJQ$1'/%/>YJG]&)9#_ $XV
M7I_3O8VB[*TNU31C:/AV\6B*8XY[M,1S^I1>JTC1;;CKJ]( S+@
M                    ! ]V\=3C5>U1O'(B[[IW*K%OGV=VU3''ZD\+'T[5
M&JSK':+WUDU7)KFC4:K7/'\GF./U+[&\J[NRE@#2H
M           23^AR_?.HG]IQ/LI2;HR/0Y?OG43^TXGV4I-V.[XY:*/" *TP
M                            \A;9VXNU-IO9PZ7Y-6F9=NO=NL438TG&
MBKWU-4Q/^EF/Y,3Q[/-V(F9TAR9TZK7/2>=KVJJJOL]].]3XN>>OY5BOQHCG
MF+/,>OPIF?@E&M113;IBBBGBF(XB'*U/4]2UW5,S7=9RJ\K4-0O57\F]7/-5
M=<^W]4.,VT4Q1&C/5/-.H DB                              .TVKM;
M7]\[FTW9NU<"O,U;5K]./C6:(YF:I]<_ ZJNKN4\\3,^J(\9F?9'PI7/1G=D
M'_(?0XZX=0]*B-?U6B)TJS=H\<7'GQ[W$^,53Q3,?&A75%$:I4T\TKD.R+V:
MM![-?2["VWBV[=[6LNB+VJYG=]]=O3$?Z)S7ITOM(:GH]=WNV
M]5TKBFF9\ZJ(N53_ (+,%=^PWNV-G=J#9VH3<[M.5=NXD^/G[I1-$?WD:XUI
MF$J9TE/. PM(                                      ML](=N6O;'
M96W;E6Z^[7E6XPX\>.?=*:HX7)K#O2Z;JKTSHAI&V;5WNU:OJEJJJGG\*BBK
MQ_O)41K5"-72$1]CGW&B9\YB)GYV\B(B(B/*!N9@
M         !Z7I?H-6ZNIVU-LT1S.I:I:L_1S5_@\TN"[ VTHW=VK-GVKUB;N
M/IMVGZ7BX5FGBBS9IHB/BARVD1$1$1
MY1X-6!J              '2[T_%#6OD^_P#9R[ITN]/Q0UKY/O\ VMPG-U[\9]?^6,[[>MPF^-F:K< =1
M      ?++_U6]_5U?4R%>S-^0?9'R+B?94L>K+_U6]_5U?4R%>S-^0?9'R+B
M?94J+^T+;6ZIP#,N                                  6&^F _(%HO
MRM'_ $(DTMGI@/R!:+\K1_T(DVNSX5-S< 6J@
M      &2\B@]+UU$KU/J+M?IK9K_ -'I>+7F78CRF:XHFGGZ)2NUUTVZ*KE<
M\4TQ,S,^J$"/;6WO5O\ [3>\M6]WF[:PLG]SK,\\Q$6:JJ?#Z&2S&M6J^Y/3
M11$!K4                              -E^[39LUWJO*BF:I39>C7Z34
M],^SEIFH9%CN9^Y*ZM0R.8\?PJHI_P"7A#5LC:^3O?>^W]GXE/>N:OJ-C%[O
M'G%=<1/ULBC8V@XVV-G:+M_$L4V;>!@6+'R)2U'=MTQ[(AN/+P
M&UF                              ;;GX,?''ULA+LR_D"V'\@X7V-#'
MMN?@Q\GG]9F?]I&JDJ],?\ @]//ZS,_[2-5LM>"&>OQ2 +$
M            !>KZ)+^$=K7R1/\ =K65+U?1)?PCM:^2)_NUH7/#*=&Z8D!B
M:                                !!;Z0W^%SNW^RXGU5)TD%OI#?X7
M.[?[+B?54NL^)75_?7WK$/1#?D U7Y;RO[Z^]BN>*6FG8 02
M        '2[U_$W7ODS*^RJ=TZ7>OXFZ]\F97V51 QQ]=_&?7OE;+^TEPW,U
MW\9]>^5LO[27#;XV99W '7                            &VYY4_TZ?K
M9"79D_(!L'Y POL:6/;<\J?Z=/ULA+LR?D V#\@87V-*B_M"VUNJ< S+@
M          %!.W+U!CIOV9=YZU3,Q>R,&O#L3$\3%RNF9CC]% S:[TT=ZNKF
MJN9KF?AF>?\ %*GZ7[?]6F;"VQT\M7>)UG,C+N4Q/G3;YIF)_317Q'$<-5F-
M*=5%R=9 %RL                             D%Y/HLNEM&^NON3O++QH
MNXFT<7W:F:HYCW>J>[Q^C7RF56,^B:Z;4;8Z&YN]LC'[N5N;,F]1F_JN9KF&BQYJKKA@-"D
M                   !)/Z'+]\ZB?VG$^RE)NC(]#E^^=1/[3B?92DW8[OC
MEHH\( K3                           ;+UZUCV:\B_V,:)XIF(\HFJ*:9GX5P_I(NUG>ZO;WN](MF9
M\SM7;M^8R[]FOWN;DQ5XQX>=-,TQ,?&LLB(B(B(XB&JU1RQK*BNK7I  N5@
M                            !Y>(J#T'Z*[HZ_=2],Z>[:QKDT7[M->?
MDQ'O<:Q$\U3,_#QQ\Y,Z=75>_1Y]DG(Z[[\M]0MW8$_Y&;=O173WX][F9-,\
MQ3'JF*9B.?@E,[BXUC"QK.'BVJ;=FQ;IM6Z*8XBFFF.(B/BB'D^DO2W:W1S8
MFE[ VCA46,'3+--N)B.*KM41$375\,\/8L5=?/.K133RP ()
M                                  "B/;0V?:WMV:M\:17;FNN-.F[;
MB(\>]373/U1*MSJ=V:99UK;&JZ5D6XN496'=MS3,>$\TSQ^MV)TG4GJQLL2Y
M5=QK=RN.*ICQCV2^KN]];R
M                       #T'3C7:MK]2=I[BHGB<+6<.J9^";U'+S[2JY5
M9FC)H_#L5TW:9]E5,\Q^N!UDG[?U&-7T'3M5IF)C,Q+61$Q_MT15_B[!2KLM
M[PHWST%V9KU-Z+DSI6/8KJB?X]NU335^N%56"8T:8 ''0
M                    !%-Z8'>7W;OW9VQZ;D__ ".-=RJJ?5[_ -SF)_4E
M90<>D9WE.\NU5KM,5Q5:T;&LX5$Q//OJ8FFJ/^5;9C6I7ITO"C#HF8\(KJFW7]
M7*PB9B(YGU);_1';)KT/H?JVZ QM               Z7>GXH:U\GW_LY=TZ7>GXH:U\GW_LY(&.1KWXSZ_\
ML9WV];A.;KWXSZ_\L9WV];A-\;,U6X ZB
M ^67_JM[^KJ^ID*]F;\@^R/D7$^RI8]67_JM[^KJ^ID*]F;\@^R/D7$^RI47
M]H6VMU3@&9<                                  L-],!^0+1?E:/\
MH1)I;/3 ?D"T7Y6C_H1)M=GPJ;FX M5
M ,C?J;KUC;/3W<>NY%WW.C#TO)N15[)BU5Q^MCIZUJU_7]?U;7\F[-RYJ6=>
MRN_/KBNN9CZTY/;[WG3LOLP[LRZ;T47\NS1BVHYXFKOUTTU1]%4H)\:CW/'M
M4?R:(C]2BQ'296W9ZZ/H O5                              +E/1U;&
M_P N>U1H$W+5-S'T2SU9-^_73\'N<<3],),D0WI<-QTZCURT#0+5SO4:?I5%V
MJ.?*NJJY$_5"RU&M2%SPK&@&QG                              ;;GX
M,?''ULA+LR_D"V'\@X7V-#'MN?@Q\GG]9F?]I&JDJ],?^#T\_K,S_M(U6RUX(9Z
M_%( L0                            %ZOHDOX1VM?)$_W:UE2]7T27\(
M[6ODB?[M:%SPRG1NF) 8F@                                06^D-_
MA<[M_LN)]52=)!;Z0W^%SNW^RXGU5+K/B5W-EN8#4H
M            2W^B&_(!JORWE?WU]ZQ#T0WY -5^6\K^^OO8KGBEIIV $$@
M                            !TN]?Q-U[Y,ROLJG=.EWK^)NO?)F5]E4
M0,5/].GZV0EV9/R ;!^0,+[&ECVW/*G^G3];(2[,GY -@_(&
M%]C2HO[0MM;JG ,RX            !MKKHMT57*ZHIIIB9F9]4 AM]*SO"=P
M]H_#V]8R9N8^@:;3351SX4UW*;=7_E9JJMVJ]WW-[]HG>^M7+GND6]0KQ**H
MGF)IM3-$?W5*6ZB-*8AFJG60!)$                            ?._:O
M9-$8N//%V_,6Z/CE]'M^ANU9WOUFV7M3W+W2-0UBQ;KI_P!B9\9)Z.IVNS5L
MRUL#H9L[:]&-39JQ--H[],1QS55,UF8F)$<19L6[<1\5,0Y
M3Q\]6J                                %->TCK4;?Z%[WU+O\ _,TS]:#+'Y]PMS/G-,3/T--B.FJFYN^@"]4
M          DG]#E^^=1/[3B?92DW1D>AR_?.HG]IQ/LI2;L=WQRT4>$ 5I@
M                        "R'TDG:YJZ/[-CI7L?.MSNG.)]52XOM(]>MM=G?I?JF_M?O457K%N:,'%YCO9.1,3-%$?'P
M@5ZA;]W'U2WMJW4#=F;_5>J[]4S%NCPBFBF/5$1$>7K76J.:=95UU:
M1H\[11W(GFNJNJ9YJJJGF:I]L_"U!J4
M  -*JHHIFNJ>(ICF0'=Y\;TQ/ASS33,>$^%23>(B(XB.(AFO5Z_AA=;I\VH"
MA:                                                -*J8JIFFKR
MF.):@()NW]LRYLKM6;MM48\VL75Z_P!TK/A^%-==?,_\JWI(=Z7_ &!5A;NV
MAU*MV)BWFVJ].O7(CPCW..:>?GN(\6VW.M,,U4:2 )H@
M           #;]^K&[]U57)KC/UC*KIF9_B^Z53'S>*=3M:;VHZ?]GW>.XJK
M_N55&GUV**N>/?7?>1_>8_>/-RNU3=O3S_KGVU3YRT6(WE3=GR?0!H5
M                            /EE=_P!PKIM1,W*H[M$1ZZI\H3^]C[9-
M.P.SMLW0/<)M5Q@Q?KB8XGFY,U_]2#7H]L^[O_JSM':%JW-GXH:U\GW_ +.2!CD:]^,^O_+&=]O6X3FZ
M]^,^O_+&=]O6X3?&S-5N .H@                           /EE_ZK>_J
MZOJ9"O9F_(/LCY%Q/LJ6/5E_ZK>_JZOJ9"O9F_(/LCY%Q/LJ5%_:%MK=4X!F
M7                                  +#?3 ?D"T7Y6C_H1)I;/3 ?D"
MT7Y6C_H1)M=GPJ;FX M5                              )9/2^[GG3^
MB^W]N6+_ ';NJ:I,54Q/X5-,4U?X(FXCB.(2&^F'U_W?>.R-L1=Y^YK5>951
MS_*BNGG]2/)7:C2E.N?Q "Q                             )F*8FJ?*
M(Y'SR.8L7.//N3Q] )=O1&;;JTSH/J>O7+?%>JZK>XJ]M-%=7']Y?8M@]&]H
MTZ-V4=KVZ[<4UY%=W(GP\^]W97/L-Y*MW];]\;DJN^Z1F:Q>JMU<_Q/#B/K7V(ZZJKNSP@#2I
M                              ;;GX,?''ULA+LR_D"V'\@X7V-#'MN?
M@Q\
M?UF9_P!I&JDJ],?^#T\_K,S_ +2-5LM>"&>OQ2 +$
M         !>KZ)+^$=K7R1/]VM94O5]$E_".UKY(G^[6A<\,IT;IB0&)H
M                             $%OI#?X7.[?[+B?54G206^D-_A<[M_L
MN)]52ZSXE=S9;F U*                              $M_HAOR :K\MY
M7]]?>L0]$-^0#5?EO*_OK[V*YXI::=@!!(
M    =+O7\3=>^3,K[*IW3I=Z_B;KWR9E?95$#''UW\9]>^5LO[27#GU33:JG_!Z%17MD[EC:O9QWIJGUQ5=JF/U2X
M;99GO6J:I\ZHBKZ6]O90                             !<;Z/#;]6O]
MK?:=B6T.,_M":OJ]VWWJ,'2+M-,^RN9MS'
MU(USI3*5.\)@_+PAJ#"T@                               +$_2Z[CN
M:7T#TS1+-SBK5=5M1-//G3171,_6B-B(IB*8\HCA(QZ83>$9&N;+V11>_P!6
MB]EW+?/GWJ:.[/\ RRCG;+4:4L]K95O&P\&S7D7KMRKB*:*:9F9^B',\O
M&49GI/\ M<]ZJOL\=/\ 4JJ+W/?U_)LU^$4\^%GF/7S3//CY5)4T\TZ.53RQ
MJM;[;7:@U+M*=4[]S R;MO:F@W*\73<:)]Y=JIF(JO3'KYFGF/C6\M***:**
M:*8XBF.(^)JVQ$4QI#-,ZSJ .N                              "XSL
M0]EG4NTIU/LUZGC7;6TMOW*,K4,B:>*+]=,S--F)]?,T\3\%2C73+IQN;JYO
MS2>GFT<.N_J&JWZ;.A>U^SUTRTSI[MJU35
M]RT15E9,Q[[(OS$15*::*:8IB/HB'-!D7@
M             +/_ $HO3NK>_9HS-4QZ9JR-OYEG+HBF.9FF;E'>_52A?M5]
M^W17_*IB61?U@VGC;XZ8;GVODVO=*<[2LJW33QS[^;57=_7PQV]5TV_HFM:G
MH65;JHNZ9FW\.::HXG_1W)ICZFFQ/313YL;M6;4NU9'N.+K,SIEZ9GB)FY71QS]$IUJ:HKIBJF
M>8F.88V>VMR96S=S:1NW#N3;NZ/FV\RFJ/5W)YY9%73K<>+N[8F@[EPJ^_9U
M# LW::O;/=XG]<2S7XZQ*ZU/D]& H6@
M      +#/2X]0/W"Z,Z/LO$RN[DZ_J'=KMQ/C5;H[M?_ $RB4B(IB(CU+TO2
ML]2*-V]>L#9>-=YL[8PXBY3SY7YJKB9^B866MEJ-*6>N=:@!8@
M                   3,1',SX0"[/T8FP(WGVF\?61I_3[_JZOJ9"O9F_(/LCY%Q/LJ6/5E_ZK>_JZOJ9"O9F_(/LCY%Q/LJ5
M%_:%MK=4X!F7                                  +#?3 ?D"T7Y6C_
M *$2:6STP'Y M%^5H_Z$2;79\*FYN +50
M  "\#TINX?W:[3%.G]_G]R]+MV..?+W]S_RL_7 ]OO5(U?M:;SOVZ^];L7(L
M4_-//^*WY&CI3"56X DB                            -E[QHX]LQ#>1
M3%=VS;GRKO6Z9^>J(!/QV.])_%T
M,V+C6IF::-!PHB9_J:51&"=VJ-@!QT                             !
MXCK;N>-F=)MT[GFJ*?W/TZYW3%%$4T^40TV(Z:J;L]=&X!>J
M                            ;;GX,?''ULA+LR_D"V'\@X7V-#'MN?@Q
M\GG
M]9F?]I&JDJ],?^#T\_K,S_M(U6RUX(9Z_%( L0
M      %ZOHDOX1VM?)$_W:UE2]7T27\([6ODB?[M:%SPRG1NF) 8F@
M                          06^D-_A<[M_LN)]52=)!;Z0W^%SNW^RXGU
M5+K/B5W-EN8#4H                              2W^B&_(!JORWE?WU
M]ZQ#T0WY -5^6\K^^OO8KGBEIIV $$@
M!TN]?Q-U[Y,ROLJG=.EWK^)NO?)F5]E40,5/].GZV0EV9/R
M;!^0,+[&ECVW/*G^G3];(2[,GY -@_(&%]C2HO[0MM;JG ,RX
M 6A^E%W%&B]EG5,+O]VK4LW&LQX\?_4I_P#*[Q8%Z8;49L]$]MZ535Q.9J\5
M3'MBBJU*=OQ0C5M*)NS3W;-%/LIB/U-X-K,
M     )$_0]Z5[KNC?&L^YS/N%-BQWO9WJ)GC]2.Q)MZ'+#M_N/O_ %#O3[I7
MFXM$QZN(HKA7=\$IT>))0 QM                               #CZCE
M4X6GY6;7/%./9KNS\5-,S_@"%7TG.\(W5VJ,[3J:N:-"T^SC>$^'>YKB?J6I
MJB=HK=O^7?7C?&ZO=/=*O:[FW,S4=0NU7\G(N5OU_<<7*K.EXLS[W'QXGB.(]L\<_.IFV6Z.2&>NKFD 6(
M                    #6*;MRNBSCV:[UZ[5%%NW1'-5=4^41'M:3,4Q-4S
MQ$1S*_+T9_9$JZA;BM]=M^8$_N'I%WNZ3B7Z/#(OQ/[[Q/JIFG_F1JJBF-9=
MB-9T70^CL[(M'0W9'^7V\L*BK=VY+--VN+M'-6'9GB::*>?*9[L3X>V5Y;;1
M11:HIMVZ8IIIB*:8CRB(;F*JJ:IUEIB-(T ''0
M                             &DQ%4335$3$^$Q*!_MV=-_\V':;W/IE
M-F;=C5JJ=3L>'$5>Z1WZ^/BFM/"C$],!TPXS-I=6<+&GWG>TW,N1'KKFGN?J
MMRMLSI4AMU6JXYI
MJCB839>C5ZG?YQ.S3I&%?O>Z96VZJM.OS,^//,UQ^JJ$)Z_WT1'4JWH/4#=/
M334,J8MZS8IS<.B9\/=8FBF8B/Z-,RJNQK2G;G24L(#(T
M                   #AZOJ&/I.EY>I95V+=K&LU7*ZYGPB(AS%O';SZGT]
M+NS5NK4K5ZFC,U''G!Q(YXJFY5',6]OB-&8 '
M                     !I-JN_51BVXYKR*Z;-,>VJJ8IC]J
M?7;9^T+%B;UNYGT9-^GCP[EKW_C^BY,Z1J['5-7V.NG5/3#L[[/VW-ON7J\&
MWEWZ9CB8N7**9JB?G5I?'#Q+&!B6<+&HBBU8HBW13'E%,1Q$/LPS.LZM4= !
MP              '2[T_%#6OD^_]G+NG2[T_%#6OD^_]G) QR->_&?7_ )8S
MOMZW"MPF^-F:K< =1
M?++_ -5O?U=7U,A7LS?D'V1\BXGV5+'JR_\ 5;W]75]3(5[,WY!]D?(N)]E2
MHO[0MM;JG ,RX                                 !8;Z8#\@6B_*T?
M]")-+9Z8#\@6B_*T?]")-KL^%3HFX<^NJF:K^;57,T
M^4^]CR>:MQ
M/C'=[]',_3",Q=-Z2GJ!1OGM.:A@XV1%W%V[C4X5N8GF.:HIKJ_7RM9;;<:4
MPS5SK( FB                              VW/P8^./K9"79E_(%L/Y!
MPOL:&/;<_!CXX^MD)=F7\@6P_D'"^QH47]H6VMU3@&9<
MC+],?^#T\_K,S_M(U4E7IC_P>GG]9F?]I&JV6O!#/7XI %B
M                O5]$E_".UKY(G^[6LJ7J^B2_A':U\D3_ ':T+GAE.C=,
M2 Q-                                 @M](;_"YW;_ &7$^JI.D@M]
M(;_"YW;_ &7$^JI=9\2NYLMS :E                              "6_
MT0WY -5^6\K^^OO6(>B&_(!JORWE?WU][%<\4M-.P @D
M              .EWK^)NO?)F5]E4[ITN]?Q-U[Y,ROLJB!CCZ[^,^O?*V7]
MI+AN9KOXSZ]\K9?VDN&WQLRSN .N                            -MSR
MI_IT_6R$NS)^0#8/R!A?8TL>VYY4_P!.GZV0EV9/R ;!^0,+[&E1?VA;:W5.
M 9EP            C3],9JW.G[!T2*XF*LK*NU4\^7%%N8\/F26(J/3 9]5S
M?FSM-FJGNVK%VY$>OFJF/_"RUXD+GA1\ -C.
M      )/O0Y1/^2^_*O5.?C?W+B,%)[Z'+\6-^?V_&_N7%=WP)T>))" QM
M                             IUVAMWT[$Z+;NW15=IMSB:;=BF9]M7O
M(_O*BK*_2K]1:MH=GJ-M8U^*KIHMVZ9JJJJGB*8CQF90]>DC[6E[J[O2
M[T@V5JY>53/$QX>$Q3,51Z_-=7Z1_M=4=(=FU=+MDYU%6Z
MMPVZK5ZJBKWV'C3X35/PS$50A]IBOQJNW*KERN9JKN5SS575/G,SZYEHLT?O
M2JN5>4-8B(B(B/" &A2                               [7:FU=>WUN
M?3-F;7P;F9JNK7ZG:9CT8]FU;IB(XIIB.
M9X\YGCQE2KLD]FW0>S9TMP=KXM%N]K.11%[5,V*??7KTQ',<^?'AY*WL=ROG
MGV-%%/+  K3
M     %O7;SZ9U=4.S+NW2<:U35F8&-5J&-/'-47+=%7''P^^7"N-J.!C:I@W
M].S+5-RQD43;N451S%5,^IV)TG5R8UC1C46XKBGN7(F*J)FBJ)]L3Q/U-SW_
M &@=@9G2WK=O#8V7CU6:,'4*ZL>)CSMUQ%7/TU2\ W1.L:LVP ZX
M                    *C=G+J+E])^N>T-\8U[W.UBY]-K)GVVZXFCZZH4Y
M:5S73$5VYF*Z)BNF8]L3S'U.3&L:.LE? SL;4L.SGX=V+EB_1%RW7'E-,^4N
M0MS[ O5>GJOV:]LY^3D4UZAI-F-,RZ>]S5%=JFGF9^/E<8PS&DZ-,3K&H XZ
M                                (M?2]=5_NW<.U^D6G9/>IQZ)U'.M
MQ/X-4>%//P]VM*!J>HXND:=DZIG7(MX^):JO7:I]5-,TGU.RNK_7
M+=F][6
ML!O7(M6YKGU)PO1U=*ZNF79JT&K,QXMY^O4_NED^'ON]5[WB?FIA5>G2E.W&
MLKGP&1H                '2[T_%#6OD^_]G+NG2[T_%#6OD^_]G) QR->_
M&?7_ )8SOMZW"MPF^-F:K< =1
M        ?++_ -5O?U=7U,A7LS?D'V1\BXGV5+'JR_\ 5;W]75]3(5[,WY!]
MD?(N)]E2HO[0MM;JG ,RX                                 !8;Z8#
M\@6B_*T?]")-+9Z8#\@6B_*T?]")-KL^%39JF5EV9F:+MSO4\^?#B
M       VUS-,T5Q/$TUTU1/Q3#54%O_ &$-:IUWLO[,RZ:^_P"YXE-CGGG\"BF%P#!5TEJC8 <=
M                            '4;NW!C[4VQJFY?4',\^]BN8I_5$.A;;451;IBK\+CFKX_6W-^S*
M                               VW/P8^./K9"79E_(%L/Y!POL:&/;<
M_!CXX^MD)=F7\@6P_D'"^QH47]H6VMU3@&9<                C+],?^#T
M\_K,S_M(U4E7IC_P>GG]9F?]I&JV6O!#/7XI %B
M        O5]$E_".UKY(G^[6LJ7J^B2_A':U\D3_ ':T+GAE.C=,2 Q-
M                             @M](;_"YW;_ &7$^JI.D@M](;_"YW;_
M &7$^JI=9\2NYLMS :E                              "6_T0WY -5^
M6\K^^OO6(>B&_(!JORWE?WU][%<\4M-.P @D
M      .EWK^)NO?)F5]E4[ITN]?Q-U[Y,ROLJB!CCZ[^,^O?*V7]I+AN9KOX
MSZ]\K9?VDN&WQLRSN .N                            -MSRI_IT_6R$
MNS)^0#8/R!A?8TL>VYY4_P!.GZV0EV9/R ;!^0,+[&E1?VA;:W5. 9EP
M        B']+IEVJ^NNWL*)GW2WI5%=7LXF*N/J2\(>?2W?PC=&^1+/_ %K;
M/B5W/"LG :U                               DH]#IJ$4U=0-+JNSXW
M\6Y11\5NOF?UHUU_7HA-9IL]4]UZ%W^)R<&,B*>?/N1$<_\ ,KN^"4J/%"60
M!C:0                             !$9Z6WJ);W+UFJN.)C^C5"6S-R[&!B7KM$;^R>J'7/>6]LB]
M[K;S-0JHQY__ "=$4T_73*ZS&M6JNY/313T!J4
M          ))_0Y?OG43^TXGV4I-T9'HS:FC!Q>][_ "+TQX4T
MQ\T_0J1K&K:?H.EY>M:ME48^'A6:[]^[7/%-%%,W[M>-IMCGWMVJF>*KLQY3XQ5Q/LE9;HYY1KJY849ZB]0=S=5M[Z
MKU"WAF5Y.IZM>JNUS5/,6Z?51'P0\Z#9LS@ X
M      ?NN**>]Q-4^JF(YF9]D1ZY2P>C/[(,["T&.MG4+2Z9W!J]'.EV;
MU'OL3'F8\>)\JI[O/Q2M=]'CV2LCKKORUU%W=@S.S-O7HKHBNGPS,FF>8ICU
M33$T^/GYIG,7&L8>-:P\:W%NS8HIMVZ(CB*:8CB(CYH9[U?[L+K=/G+Z@,ZT
M                                                         !$[
MZ7+I91M_?VW.J>GXDTV-:M3@YMR(\/=HFNJ*IGV]VFF%@:<_M^=(;?5SLZ:_
MAVL>;NH:-;_=#"B(YF*Z9CO?\O>068]R;MFFNJF::ICQIGSB?8UV9UI9[D:2
M^@"U                              !?IZ)CK'7MKJ7K7275ITG5?;GIH]"
MI6                               -)F(CF?4"U[TB?6>.D79XU:W@Y7
MN>J;A_\ Q9BTTS[Z:;D=RN8^**H0@VXJ[O-R>:ZO?5S[:I\9GZ5Y'I/^MM?4
M;KE3T_TS+]TTC:%N:*Z8GWLY57A7'S31"SELM4\M+/7.L@"Q
M                  ![CH;T\RNK/6+:O3W$M][]U,^W3>\/"FU$^,S\_#(6
MT#2,30=$P=&P;--FQAV*+-%%,<13$0BM]$CT@HW#OS7NKVHX??QM$HC!PKDQ
MX>ZU\5=Z/B[LPEB9;U6M6B^W&D:@"E8                .EWI^*&M?)]_[
M.7=.EWI^*&M?)]_[.2!CD:]^,^O_ "QG?;UN$YNO?C/K_P L9WV];A-\;,U6
MX ZB                            ^67_ *K>_JZOJ9"O9F_(/LCY%Q/L
MJ6/5E_ZK>_JZOJ9"O9F_(/LCY%Q/LJ5%_:%MK=4X!F7
M                 +#?3 ?D"T7Y6C_H1)I;/3 ?D"T7Y6C_ *$2;79\*FYN
M +50
M      VW:>_:KH_E4S#< F9]%AN>UK?9?P=,IJYKTK4,FQ5\'%41'U+Q4;_H
M=]V6Z]L[SV5^Q?YR;DU?5"2!BN1I5+31.M( @D
M                (E_2V]6:MP=2]!Z48.1%>+H>/.9E13/A[IYQ'P1$KK-.M6JNY.D:/$@-2@
M           !MN?@Q\VY^#'QQ];(2[,OY MA_(.
M%]C0HO[0MM;JG ,RX               !&7Z8_\ !Z>?UF9_VD:J2KTQ_P"#
MT\_K,S_M(U6RUX(9Z_%( L0                            %ZOHDOX1V
MM?)$_P!VM94O5]$E_".UKY(G^[6A<\,IT;IB0&)H
M            $%OI#?X7.[?[+B?54G206^D-_A<[M_LN)]52ZSXE=S9;F U*
M                              $M_HAOR :K\MY7]]?>L0]$-^0#5?EO
M*_OK[V*YXI::=@!!(                              =+O7\3=>^3,K[
M*IW3I=Z_B;KWR9E?95$#''UW\9]>^5LO[27#I\KE$51\\ZW*:N)CX?>H)*)KJB;EVJ:J[E4UU3/KF9YGZTA/I=.L%S4]Z;=Z-Z9DS-C3
MK7[HZA337S3-R>[-OF(\I[M=2/=KLTZ4ZJ+DZR +58
M             "2?T.7[YU$_M.)]E*3=&1Z'+]\ZB?VG$^RE)NQW?'+11X0!
M6F                  -)F(CF9\&JV[MO\ :DTOLW=,+]S%NT7=S:W15BZ7
MCQ5[Z*ICQN3'GQ$=[Q]L.Q&LZ0Y,Z1JM=])]VNOP^SUT]U6?=*XBYKF78K_
MI_F>?A]]$HTZ:8HIBF/*'*U/5=5U[5,O7M>S:\S4M0O59&5?KGF:[E4\S/TN
M,VT4\D:,]4\TZ@"2(                              J%T%Z*;G[0'4O
M3.GVVL>NJW=NTW-0R(CWN/CQ/-4S/MF(F(^-X?2]*U77M3Q-#T/!NYNH9]VF
MQC6+5$U55USY1Q";;L0=E[1>S)TRM9>O3C4[IUNU3>U7*KJII[LSQQ;B9]4<
M1/GZU=RODA.BGFE6[I/TOVOT>V+I>PMI8-O'PM-L46N::>)NUQ$1-=7PSQS+
MV#S6J=2NGFBVZKFJ;YT#&BGSB[J5FF?HFI3[7^V#V=-MS5&H]3]'JFGSC'R*
M+W]V99-)E?K$*S"U37/28=E32(JBSO#*S:Z)XFFU@W?K[LO!ZMZ73L\8%CZ[F\<\318N4Q/TVW>2KT\/.J]W?'Y[;S^5
MZ8W1/<9^X>D.I5W>?"*LZB(X_02[JOT
MEFL6ZN?>Q1E4SS'S4'=5^AST^J181^XWIBNCE0[,&H=S[IU+4\3O1
MX]_#NSW?^1ZS3/2,]E#4XIBWU KM5S'/=N85VGCYYASDJ]#FCU7-"BFD]LOL
MWZS-,8G4[2J>]QQ[M>IM^?\ 2F'LM+ZX]']9X_<[J5MJ[WO+C5+'[3FDNZP]
MR.GQMX[1S>/N/=6CW^?+W+.M5<_14[6U?LWZ>_8O47*?;15$Q^IQUO
M                                   !Q=4P+.JZ;E:9DTQ5:R[-=FN)
MCF.*J9B?K8_?:>Z85='.O6[-BTV:J,6UF5Y6%,QQ%5BNJKN.C
ME%NC;W6[3L:JJNBJ--U"JFGRHGNQ;F?GJJ6V:M*M%=R-8U1JA$Q,54<2EA]$]UVG='3S4>CVO:AW
M]3VY>FYA4USXUXU-5,35S^C"%RGFIT2IG2604.#H>KX6OZ/AZUIU^B]C9MFF];KHJB8F)CGPF'
M.8FD                              4P[275K3.BW1W<>^-0O44W,;#K
MMXU%4\3T!3O/?.G]%-O:A-6G[>G[HU2**^::\B
M>8BB>/9$T2G13S5:(U3RPL5U;6]4W-J^=N36[]5[/U3(KR\BNJ>9[]<\RXH-
MK,                              -MR+E5/N=FF:KMR>Y;ICSJKGPB(^
M=N5H['/2.YUI[0NV=LU6/=<' OTZEF\QS3%%J8KB)^/NS#DSI&KL1JES[#'1
MVWT:[/>W]'NX\6\_4K,:AF3QXU57>:Z>?BBOA<&^.)BV,'$LX6-1%%G'MTVK
M=,>JFF.(CZ(?9AF=9U:8C2- !QT                =+O3\4-:^3[_VMPG-U[\9]?^6,[[>MPF^-F:K< =1
M                         ?++_P!5O?U=7U,A7LS?D'V1\BXGV5+'JR_]
M5O?U=7U,A7LS?D'V1\BXGV5*B_M"VUNJ< S+@
M          %AOI@/R!:+\K1_T(DTMGI@/R!:+\K1_P!")-KL^%3NZ?[E[G]SYE5'<_D^$>#SQ                                 O!]
M%EOJC:W:3KV]EY-5&/K^GW***.?"JY1'$?KJ3.L=OH1OF>FO6?9^]?=)HHP-
M4L>[3$\F/_  >GG]9F?]I&JV6O!#/7XI %B
M          O5]$E_".UKY(G^[6LJ7J^B2_A':U\D3_=K0N>&4Z-TQ(#$T
M                             ""WTAO\+G=O]EQ/JJ3I(+?2&_PN=V_V
M7$^JI=9\2NYLMS :E                              "6_T0WY -5^6\
MK^^OO6(>B&_(!JORWE?WU][%<\4M-.P @D
M    .EWK^)NO?)F5]E4[ITN]?Q-U[Y,ROLJB!CCZ[^,^O?*V7]I+AN9KOXSZ
M]\K9?VDN&WQLRSN .N                            -MSRI_IT_6R$NS
M)^0#8/R!A?8TL>VYY4_TZ?K9"79D_(!L'Y POL:5%_:%MK=4X!F7
M    "(3TN>%1;Z\Z!GQ7,U7=)HMS3[(B*O\ RE[11>E^TZ+?4;:&J>X\>[8M
M=KO^WNTQX?K6V?$A<\*/X!K9P                             !R-,U>
M_M[5L#7\>[5;N:=DT9%-=/G'=];CMMRBFY15;KCF*HXF 9&W2S?/B.)_7$O5+3/1G=2XW[V:M)TR_D>Z9>VZZM.O1,^/G-<3]
M%<+LV"J-)T:HG6 !QT                          =7NC<&%M3;FI[EU&
MY31C:9B7LNY-4\1W;=$U3'ZG:+(?2G=
M/3-,US\55,U0[3'-.CE4Z1JBSZT]1]1ZM]5]S[^U&[57^Z&?=IQ^]//&/175
M3;X^#N]UXMI13W**:.>>[$0U;]F8 '
M  $D_HV>E>R]4WWN_/IQ-+T
MJQ5?O7)XYXB/*.?.4"G:+Z[;E[1/5'4M^Z]?KC#]TJM:7B35,TX^/$^'$>7,
MSS/SKB?21=K:]U=WE7TBV3J,QM;0+LTY]RU5[W,R8\./ABGFNGU+*8B(CB&J
MU1RQK*BNK7I  N5@                               .]V/O;N:A7-S4=Q:OF35Y_=&==N1/S552XGN%B9YFS1,SYS-
M,-XZXV18L1Y6:(_W8;XB(\HB          )B)\X &V;=NKSMTS\<-OW/C_S%
MO]&'T ?/[GL?S%O]&'TMU7['^K9>1C_U-VJCZI '8X.Y]X:77%S3MZ;@QZH\
MNYJ=Z(CYN\]AI':&Z\Z%53.F]6=Q44T>5->==KI^B:E/AS2'=5P^W>W]VJ=M
M33]S=0J,JFG^)DX=%SGYZN52-#]++VDM-JHHU?0M!U.W3^%/=IM53'^[;68#
MDT4SY.Q5,))-L>F+RN:+.[.DT4?R[V-E55?J[L0K#M3TL/9SU:*:-QVM\J3R[1[<_98IFF?]FJ:?J=
MGIFX]RZ)RR3?/QAJQ_\ 9G:^[36P
MZXJT/JUJMVB./]'DQ;KCCV?@I6#B7ZN/]!DTW**HGVC*T3
M7=15%4#UEZ,[EV-F6(N7,K#N7,6..9C(HIF;?'^]PJA:MGZ!J%JJUE:9E7<.[15'C%5NN:?\''77^DHZ*QTGZ_7-P:
M7A3:T;=]K[KMU1'O:;],4Q7'QS5-4K4&ZF>:-668TG0 =<
M              &VY;INT3;KCFFJ.)AN 2Y^BX[1T]0^G-[I'N/-BK6]I413
MC]^KWU[%F8XJ]L^^JF/F7UL>#H+U?USH5U6T/J+HEZNFG$OTV\VU$^%['JGN
MU1/Q15,_,G^Z?[YT+J3L_2][;;RJ;^GZKCT9%JJ)YXBJ(GB?ACEDNT(B/:
M"E_:6ZUZ3T"Z0:[U#U*[1%[$L5485JKC_39$Q,T41\?$_0@#W'N'5-W[CU/=
MNN7JKNH:ODUY-^NJ>9F9\OU1"[#TD?:7JZR]5/\ (#;.H55;:VI7-J[%%7O<
MC*CCF?A[LQ7'SK/VNU1RQJHKJUD 6JP
M&E544TS5/E$J]9M4Q.,S<-Z<;#JJI\:;%',Q5']**_U(Q]
MA;/U+J%OG0MCZ18KO96L9MNQ$4QSQ1SS5,_!W8ED+]+]@Z7TPV#HFQ-'M448
MVCXEO&IFB.(JFFF([WS\*;U6D:++<:SJ]4 RKP                 !TN]/
MQ0UKY/O_ &_&?7_EC.^WK<)S=>_&?7_EC.^W
MK<)OC9FJW '40                           'RR_]5O?U=7U,A7LS?D'
MV1\BXGV5+'JR_P#5;W]75]3(5[,WY!]D?(N)]E2HO[0MM;JG ,RX
M                         !8;Z8#\@6B_*T?]")-+9Z8#\@6B_*T?]")-
MKL^%3^FU4=R+
M6JU]VGGGBGNTJ>*\]N_2J-%[6.]\.U3W:+E_W:/#CGGP_P %!G*=H=GI( ZX
M                              ^>115!155X>[T]VGNQ'Q=Z55ZG6E.W.DI:@&1H
M  % .VWUWQ>@_0G6]=L97T+.JKVYM&:L2S33X4W?%45
M0LMT\U2-=6D+6+E[(RKUW,R[DW+^175=NUS/C55,\\RV@V,P
M                     #;<_!CXX^MD)=F7\@6P_D'"^QH8]MS\&/CCZV0E
MV9?R!;#^0<+[&A1?VA;:W5. 9EP               ",OTQ_X/3S^LS/^TC5
M25>F/_!Z>?UF9_VD:K9:\$,]?BD 6(                            "]
M7T27\([6ODB?[M:RI>KZ)+^$=K7R1/\ =K0N>&4Z-TQ(#$T
M                   ""WTAO\+G=O\ 9<3ZJDZ2"WTAO\+G=O\ 9<3ZJEUG
MQ*[FRW,!J4                              );_1#?D U7Y;RO[Z^]8A
MZ(;\@&J_+>5_?7WL5SQ2TT[ ""0                              Z7>
MOXFZ]\F97V53NG2[U_$W7ODS*^RJ(&./KOXSZ]\K9?VDN&YFN_C/KWRME_:2
MX;?&S+.X ZX                            VW/*G^G3];(2[,GY -@_(
M&%]C2Q[;GE3_ $Z?K9"79D_(!L'Y POL:5%_:%MK=4X!F7            ",
MSTQ>E]VWL#6::/";^5:KJY_V+?'UI,T?GIB=.IN='MJZM%'OL35IHFKX*ZK4
M++7BA"OK2BD ;&<                               !??Z)3JG;VQU2U
M[IEGY/%C<./&1ATS/A[O$QS$?[M$I;V.9TGWWG],.IVV]^Z=?JM5Z5GVZ[G=
MGCO6ZI[M43\'%4RR&MF[ITW>VU=+W;H]VFYA:MBV\JQ53/,317',,MZG2=5]
MN>FCN0%*P                         !QM1S\;2\#(U+,NTV[&+:JNW*J
MIXB*:8YGQ0+=LGK;E7^;O;V9-&X=X438I[D^^LX_,S57[8\:.[\Z'&U;IM41;IYXCUS/BT
MV:?WE-RKR;@%ZH                                 !)/Z'+]\ZB?VG
M$^RE)NC(]#E^^=1/[3B?92DW8[OCEHH\( K3                %D/I(>US
M1TCV95TLV-J=,;NW!;JMWYMU>.)BU1Q55/'E-5,U1'EXPN-[1W77;/9\Z8:I
MOO<&7;HNVK4V\"Q5/OLB_/X--,>OSY^*)0*=1>H>Y^K.^-5ZB[RR:KVJZQ>J
MNW([W--JF9F8MTQZHCF?);:HYIUE775ITAYR.],U7+E6S,BG*VGNS5=)N4<=V<
M7)FWQ]"NFQO2$]JO8EVUW=]4ZYC6O*SJE%5Z9CV=Z:UN@Y-,3N[$S&R2#ISZ
M8+-QJ*+/53IS5=\HKR=.NQ3$3_0BFJ9^E<[TV](WV9>HL6K%.[*]'R[O'-G4
M;4V(I^.JOB$(3;-FU-7>FW3WO;QXJYLTRG%R89(VW]Y[2W78IR-M;ETS4[=<
M1,3B95%WP_W9EW3&\VUOS?NS,JG+VGO;6]+N4SS$6X7)=-O28]I3
MI_18P]4S<'<^#:F(FWET4VZ^[_3IIF9GYU-
MU.VUF[;OU>%5ZU3%RQ$^V:JJHG]2[7ISVB^B_5:S:N;&Z@:3J5R[3WO<;=Z/
M=*?CA5-%5.\)Q5$[*D#;3737'-%451[8GEN1=
M 6I^D;Z'?YW>@&I:II>%3=UO;$?NCB5<>^FFF*N:(]?C-43\R$NW5-5/-43$
MQ,Q,3YQ,3Q+)9SL+'U'#O8.7:HNV;]$T5T51S%43[80&]K[HOF="^O6X=K?<
MU=O2LV].=I==5/$56:IXXC_>BIHLU?NJ;D>:C0#0J
M           )B*HFF8YB8XE(3Z+CM41MC6)[/N]-0FG SJJKVAWKE?%-NY/X
M5KQ]OO(B$>S[X.H:CI&H8NLZ/EW,7/P+U.1C7[=4Q518^&(1JIBJ-$
MJ9Y9U9*WGXPU6R=A?M4Z9VB^F=C'U+*MVMU:%;HQ=1QIJ]_7W8XBY'MB8B)G
MX97-L4Q,3I+1$ZQJ ..@                       "T/TB/:HM="NF=S:.
MV-8HIJ]]CV*HB*[DQ'C'O:IXGP\87 =;.K^U>B'3S5=_;KS[>/
M8P;-55JBJ8[UZ[Y4T4QZYYF/F0)]:>K^Y^O'4C5.I>Z[ER+^H7)^Y\::YFG%
ML\S--NF/5QS*VU1S3K*%=6D:/$S5KJNW:Y\ZZZIYJJGXYF9
M:V<                              !]]/TO4]AT_BC(LXM-W,KI\[MZKF9JGX>)B/F598JZN:K5IIC2- !!(
M                =+O3\4-:^3[_ -G+NG2[T_%#6OD^_P#9R0,F _(%HORM'_0B3:[/A4W-P!:J
M 7:>D_V].C=J')U#W/N_NII]N_SQY^_KC_!:6D"],%M^<7J+LS<\4<1F8DX7
M>]LT=^K_ !1^H6YUIA*KI5( FB                              .^V#
MO35.F^^=#W[HUZJWEZ+F49%,TSYQY3$_-,NA)B)B8GRD&1=TDZBZ/U7Z=Z'O
MW0[U->+JV)1?B*:N>[,QXQ/PO8(MO12]I&=*U3,[/^Z<^FC%O1.5HE5RKB(J
MX]];B9]E-$<1\*4EAKIY9T::9YHU $4@                      'F.I74
M';W2[96J[WW/FT8V!I>/5>KJJF([T^5-,?#,S$?."W+TB':;L=#.DN1MW0
MNKFD 30                                  ;;GX,?''ULA+LR_D"V'
M\@X7V-#'MN?@Q\GG]9F?]I&JDJ],?\ @]//ZS,_[2-5LM>"&>OQ2 +$
M                    !>KZ)+^$=K7R1/\ =K65+U?1)?PCM:^2)_NUH7/#
M*=&Z8D!B:                                !!;Z0W^%SNW^RXGU5)T
MD%OI#?X7.[?[+B?54NL^)75_?7WK$/1#?D U7Y;RO[Z^]BN>*6FG8 02
M                '2[U_$W7ODS*^RJ=TZ7>OXFZ]\F97V51 QQ]=_&?7OE;
M+^TEPW,UW\9]>^5LO[27#;XV99W '7                            &V
MYY4_TZ?K9"79D_(!L'Y POL:6/;<\J?Z=/ULA+LR?D V#\@87V-*B_M"VUNJ
M< S+@           !9OZ5/;G[M=F#+S_ '/O?N9J&->Y]G-VG_PO(4([;^V*
MMV]F?>6F4T=Z;6'5E\?U5,U_X)43I5"-76$"UJKOVZ*_Y5,2W-EB.+-%/LIB
M/U-[@/6#1.HFG7*XQK
M5ZG'U&W3/A]MY:%T_VK
MJ6\-RYE&-IVEV*\B_(A%/Z3WM9?Y6ZO5V?MC9\
M5:9@UQH&J7J_N6
MY>JL:=8F?"SCTSQ$1\8JCVQ5/,>VE*FGFG1RJ>
M6-5KO;<[4.I=I/JC?IP;UVWM+;]VK'TNQ-7A=JCGF[,>WFJJ/BX6[M**8HIB
MFF/"&K;$13&D,TSKU '7
M                                "8B?"8B?C?3 RLW2LB,S2L_)P[],
M\TW+-VJF8GYI?,!-T
MH]+WM+4J[6G=6]DY.CWJIBFI;*W7INKV;E,5Q]RY%%R:8^&*9GA5-,T[K(JB=GIP$7
M0                 !8QZ4[H#=ZA=+<7J=M_!]TUC:=??O31'-5>-,]WCYI
MJF5\[KMPZ)A;DT+/T#4;-%W&U#'N8]RFJ.8FFJF8_P 4J9Y9UGN5CUVL6W?JRM.JJCB*\:NJ9HX^*(A3-M
MB=8U9M@!UP                             ![WH;UHW7T!ZCZ;U$VKD7
M/_E;D1FXD5<49=GGQHJCYH^A/#T0ZT;.Z[[ TW?FS\ZB[8S+457;$U1-S'N<
M>-%4>J?_ "QX5=^R)VJMR]E_?E&=;N7,K:FJ7*:-5P>9F*8F>/=:(]4QX3/A
MXQ"JY;YHUC=915R]$\X\WT]Z@[6ZH;2T_>NSM3M9VF:C:INVKE%43QS$3W:N
M/*J.?&/4](R+P                     !UVX-P:-M;1\K7]P:C9P=/PK%?U'4,BW8QL:W5=NW;E413113',S,SY1$0B"](%
MVX,GK+J^5TEZ9:G71LW#KFWJ&31/$YUVGPFF)CSHY[T>N)\$Z*)KG1&JJ*84
M[[Q]F:#>JMX-CO<1E5QS$W:H^>J(\O"(6U-*:::*8I
MIB(B/"(AJV4Q%,:0SS.LZ@#K@                              O+]&#
MT$KZE]9:NIFL84W=#V?Q5:FJ/>5YUZ;%-&H9EFC/U"J(XFJ]=COS$_T9
MKF%5VKEIT3HIUE7*(BF(IICB(CB(:@R-                     Z7>GXH:
MU\GW_LY=TZ7>GXH:U\GW_LY(&.1KWXSZ_P#+&=]O6X3FZ]^,^O\ RQG?;UN$
MWQLS5;@#J(                           #Y9?^JWOZNKZF0KV9OR#[(^
M1<3[*ECU9?\ JM[^KJ^ID*]F;\@^R/D7$^RI47]H6VMU3@&9<
M                       L-],!^0+1?E:/^A$FEL],!^0+1?E:/^A$FUV?
M"IN;@"U4                              E8],)M>C+Z4[6W7:M35>TW
M5*Z:IB/*FJFFG_%%.G%](ELR-X=E[^E7X=+L[=^@[[VW@;KVUGVLS3]1LTWK5
MRW7%4<3'E/'KCR=TQM                     #;771;HJN7*HIIIB9JJF>
M(B(]<@V9.3CX>/9T%Z1:KWJKU,T:WJN-KZ)+^$=K7R1/]VM"YX93HW3$@,30
M                         (+?2&_PN=V_V7$^JI.D@M](;_"YW;_9<3ZJ
MEUGQ*[FRW,!J4                              );_1#?D U7Y;RO[Z^
M]8AZ(;\@&J_+>5_?7WL5SQ2TT[ ""0
MZ7>OXFZ]\F97V53NG2[U_$W7ODS*^RJ(&./KOXSZ]\K9?VDN&YFN_C/KWRME
M_:2X;?&S+.X ZX                            VW/*G^G3];(2[,GY -
M@_(&%]C2Q[;GE3_3I^MD)=F3\@&P?D#"^QI47]H6VMU3@&9<
M/+=4M&M[@Z;[GT:Y1WHS-(R[,1[9JLU1'UO4OG?LV\BSI:=>IOXU^B>*J*X\I3>=B#M8Z)VC^G-BQJ&3;Q]V
MZ/;BQJ>)57Q57,1'^DIB?.F>8CU^4LUZC3\4+K=6O25S "A:
M         H3VL>U/M#LS[!R=9U'(MY6NY-N:-,TZBN/=+MR>>)F/5$<3XR[$
M3,Z0Y,Z=94Z[?_:_P^@.QZ]H;4S+-_>6OVJ[%FS35[[%M51Q-V?9X=[CX80P
M9.5F9^7?U'4H/4#=?53>6I;]WMJ-S-
MU;4[LW*ZJIYBW3SX44^R(_Q>>;**.2&>JKFD 31
M               23^AR_?.HG]IQ/LI2;HR/0Y?OG43^TXGV4I-V.[XY:*/"
M *TP            &VYCV;KMJJFO
M6]6IKP=+L\^,W:HBF:_]WOQ5\R"O4]4U/7M5S->UO+N96H:C?KR%ROI#>NN5UEZ_ZCI&#F>Z;?VE75@8E-$\T5WHF8KN?/$T_0MA;+
M5'+&K/75K( L0
M                                 :5445QQ73%4>R8Y=WM7>^]MBY]O
M4]F;LU32X9-<4>'MHY[L_0Z4!>]T;]*QU@V1]SZ7U,T7'W3I]'%$Y
M5'%O(II]O=IB*9^>5^G1KMZ]GCK)3:Q-.W?9TG5;D1$X&H3%N[WI]4<3,?K0
M6MLVZ>_3=IF::Z)YIJIF8F)^955:IE.+DPR6\?)Q\JW%[&OV[M%4F1J6E6ICG3=0JFY:[OLCB8F/I7^]$/2O]+]XW,;
M1.JFCY&UM2N<4UY/$W,:J?@[L3W8^.5-5JJE;%<2OS'3;7WAM?>FF6M7VKKN
M%J>)>IBNFYC7Z;GA/MXGP^=W*I,               !8?Z4[L[4;ZZ<6>L&W
M<'OZYMB?_F>Y'-5[%GCO<_T::9^E$A15%=,51ZX\O8R4-=T33=R:-FZ!K&-3
MD86H6*\>_:JCF*Z*HXF/HE 3VI^B&I= .M&M;+RK4TZ?DWJ\S3+G'%-5FN>]
M,1\4UI]$*;EKFZQNLHKTZ2G_%'>SQVI>E_:/VW9
MUG9VJV[.?W(G)TR_^.(X5B9IB8Z2OB=0!P
M   ' US7-)VWI63K>N9]G#PL2W-R]>NU=VFBF/7+S'5?K'T_Z+[7R=U[]U_&
MP,7'IFJ+=5<>ZW9XYXIHCWT_-"'?M=]NO?7:2SKNW-OW,C0=DV:YIIQ**^+F
M;$3^%K^3E]+.D>;J6:YIKS^
M)_!IF/*CPCV3/,K'J**:*>[3'A]933313%-,<1'E#5KIIBF-(9YF9W $G
M                            ')TO2M0U[5<+0-(L57L[4K]./CVZ8YFJ
MJJ?9\7,_,"[KT9O9]IZM=8J]][BTZ;NW]HQ%VW-=/O;N5/>[OQ]VJFB?G3-4
MTTTQ%-,1$1'$1'JA1CLD="L/L_=%-#V3%BB-3]RC(U.[$1SGXH:U\GW_ +.7=.EWI^*&
MM?)]_P"SD@8Y&O?C/K_RQG?;UN$YNO?C/K_RQG?;UN$WQLS5;@#J(
M                    #Y9?^JWOZNKZF0KV9OR#[(^1<3[*ECU9?^JWOZNK
MZF0KV9OR#[(^1<3[*E1?VA;:W5. 9EP
M    "PWTP'Y M%^5H_Z$2:6STP'Y M%^5H_Z$2;79\*FYN +50
M                   #(NZO[%UV/-2$!H4@
M                    !,1,<3$3$^<2 +MNPUVWM7[.^MV=B;WR+V;L;4;T
M4]ZJ9JKTZN?XU//\3GU>$>^Y3+;=W%HN[-%Q-P[=U&SG:=G6XO8^19KBJBY1
M/E,3'A+&SJIBJ)IJCF)]2Z+L==N7>'9LU6SMO4Z;]4-C]6=LXF[-B:_BZI@9=NFN*
MK5?,T3,>--4><3$^$_$]6RKP                '5[DW1M[9^D9&O;GU?&T
MW3\6B;EV_?K[M--,><__ ,@=EA^KTW-0J[V/JVK69BJBQ3/A5;MU1_&X[T<\QQS"G7;.])#J_4/[NZ9]#
MLJ[I^A/$3X2L*B)YJJJKKKKKGFJNNJ:JJI]LS/C
M+1;M>=2FNOR@F:ZKER]>N57;UZN;EVY7/-5RN9YFJ9]G
MG]9F?]I&JDJ],?\ @]//ZS,_[2-5LM>"&>OQ2 +$
M        !>KZ)+^$=K7R1/\ =K65+U?1)?PCM:^2)_NUH7/#*=&Z8D!B:
M                             !!;Z0W^%SNW^RXGU5)TD%OI#?X7.[?[
M+B?54NL^)7
M5_?7WK$/1#?D U7Y;RO[Z^]BN>*6FG8 02
M    '2[U_$W7ODS*^RJ=TZ7>OXFZ]\F97V51 QQ]=_&?7OE;+^TEPW,UW\9]
M>^5LO[27#;XV99W '7                            &VYY4_TZ?K9"79
MD_(!L'Y POL:6/;<\J?Z=/ULA+LR?D V#\@87V-*B_M"VUNJ< S+@
M      $+?I2-HV]L=IR=4Q[,TVM?TZW?F>/":K=%NF?KE:*D]],'L"K+V]M#
MJ-8LZ6+G'CX>OGQ\F2Y;FGK&RZBO7I*YD
M!4L                !I55313-5541$>,S/J6B=KST@6Q.@>%D[6V?>Q]P[
MRNT56Z,:U7S;Q*I\._U'6LRW
MDZ]DVZHTW2Z*HF[>N<>$S'G%/,QS/'K0C=6^K>]^N&]\S?N_=2N969D5U?<]
MF:I]SQ;7/A11'E'A$<\<>+@=0NHF].JVZ\O>N_M;O:GJF77-4U5U>\M1,\]V
MBGRB(Y]CSK7;MQ1'M455
4W_EWW[^XW230=CV+
M_3DUS=NU3/,S
M5/G(0-S,
M                                  -*Z*+D=VNF*HGU3'+4!43HUV@N
MK7036;6K].MTY-BS17%5S3[U=5>+=CUQ-$SW8^/A+?V0^WGL/M&X=G;>MU6]
M"WK:M\W]/N5Q%%_B/&JU5/'>\I\(CP0F.5I&KZOMW5L3<&W]1O8&I8-VF]CY
M%FN::J:J9B8\O..8\E==N*TZ:YI9*@M-[ W:^L=HK8U6@;LR+./O/0J:;.59
MY\Z
M2U[[V_@1,^,Q/S+RGQR\6QG8MW#RK5-RS>HFBNB
MJ.8F)CQ\':9Y9UG51'O+5<\]ZU\T1$_.MP;HF*HUAFF-)T '7
M              '=;*WKNWIQN+'W9L77LK2-4QJXJINV+DTQ7$3^#7$3'>B?
M9/M2<]EKTI.V]T48FSNOE%O1-7GBU;U6B(C%O>J)KGPBB?+V^M%8TJHIKCBJ
M(E"JB*]TJ:IIV9*6CZUI6X--L:OHFH6,W"R:(KM7[-<545T^V)AS4 '0_M7]
M;>@&H47=F[JR,G3.8]UTO-KFY9KI]D3,353Y>J82,]"O2J=)-^>X:1U1Q*MG
M:I7,4U7;GOL6J?@F)JJ^F&>JU53LNIN1.Z^8=)MK>VT=XX%K5-K[BP=2Q;T=
MZWNQ3$1\Z
MU#KIZ3#H3TJHOZ=M7.G=^LT1,4V,'QMTU>RN:II_4[%,U;.3,1NN[R,BQB6*
M\G)NTVK5N.]775/$4Q[9E9IVG?24]+^D-K*VUTZOVMU[IH[UONX]<58V/5ZI
MJKCF.8]DPCUZ_=NGKIU]NW<'*UBK;F@7)GC3=.KFGO4_[5?X7/Q2MYBGWU5<
MS5575/-5=4S555/PS/C*^BSYU*JKGH]SU?ZU]2NN^Y;FZ.I6X+N==FJ9LXE,
MS3CX\3/E11SW8]7C$>IX<&B(TV5[@ X
M   +ZO19]G&G?^_E^Z4^C].]KV:KFHZUD4V*)ICGW.F9B)KGX(YAD!=#^E.A=&.F6A[ T'&IM
MVM.Q::;M44Q%5R[/C5,^V>9E5>KY8TA9;IUG5[P!D7@
M    #I=Z?BAK7R??^SEW3I=Z?BAK7R??^SD@8Y&O?C/K_P L9WV];A.;KWXS
MZ_\ +&=]O6X3?&S-5N .H@                           /EE_P"JWOZN
MKZF0KV9OR#[(^1<3[*ECU9?^JWOZNKZF0KV9OR#[(^1<3[*E1?VA;:W5. 9E
MP                                 "PWTP'Y M%^5H_Z$2:6STP'Y M
M%^5H_P"A$FUV?"IN;@"U4                              R7D1OI<.G
MMS1.L&W^H-BQ%&/K>%.-E/Z;1O#L[7=SXUJ:\S;6
M7;RJ.*>9]R\9KC_EACMSI5#37&M*&X;;=7?HIK]L1+SKN.C7>G>MW+>-5O
MO4Q,>/P\^N4M79C]()TDZ^8]G1-5S*-L[GIIBF[AYUV**+E7MHKJXIGXHF90
MEM:)N6KU&3CWKEB_;F*K=ZU5-%=$^V*H\85UVXK3IKFEDMV[EN[13N712WBZ'KE^G=^W[4Q3-G-KG[HHI^"[,555?%RD0
MZ,^D6[.O5BG'T_,W-3MO6;M,=_#U.:;,=[V4S-7-7T,]5NJE;%<2NE''P-0P
M=4Q;>=IV5;R,>['>HN6ZN::H]L2Y"M,        !Q\[/P],Q;F=J&3;Q\>U3
MWJ[ERKBFF/;,@Y#29BF)JJF(B/&9E;'UD](=V_7CTEW7'JW1E:%M&+6S]"NS-,?R:Z?Z?%-5'S2LIM
MU5(37$)&>T;VYNC/9[P;N/G:O;US7JJ9BQINGW8N5=_U=^JGO11X^WA$SVC>
MUWU<[2FJ7:=SZK,Q55QZXX]:BV1>RVY^#'QQ
M];(2[,OY MA_(.%]C0HO[0MM;JG ,RX               !&7Z8_\'IY_69G
M_:1JI*O3'_@]//ZS,_[2-5LM>"&>OQ2 +$
M  !>KZ)+^$=K7R1/]VM94O5]$E_".UKY(G^[6A<\,IT;IB0&)H
M                      $%OI#?X7.[?[+B?54G206^D-_A<[M_LN)]52ZS
MXE=S9;F U*                              $M_HAOR :K\MY7]]?>L0
M]$-^0#5?EO*_OK[V*YXI::=@!!(                              =+O
M7\3=>^3,K[*IW3I=Z_B;KWR9E?95$#''UW\9]>^5LO[27#BX>X]"SM"U"W%>-G6*K-RF8YB:9ACM=4]I9&P>I^Z-EY-NJBK2=1N6
MJ>8XYIGBJ)_YFFQ/284W8\WF %ZH
M  [,\3\#&WJIIKB::Z8JB?5,C6)=R-_P"_--T^[:CF<6;U/N]7Q43,DNA7]P;]W/@Z7C6*>]--V]3%VO^C1SWJOFA'GUU]+?E7IO
MZ-T&VO,T3S1&JZE3%/$>VFW,51/TK!.HG4[J#U:UR[N'J'NK-UC)N3WHMW;E
M7N%']&WSW:?FA;39F=U=5R(V7D]J3TH.[.H-&5L_H71D:!H]4U6KVK5\QD7J
M?+FWY31$_#$K$K][(R\J]GYN1O7:N:[E4^WXYGC]PJ_#G_\ ++;/B0N;+) &
MMG
M                                5$[//5_/Z$=8MO=2<*]13:S
M[5-7$7<:JJ)KIG]&&0/MG7L'=&W]/W%IMVF[C:ACT7[=5,\Q,51_Y8V-ZU1?
MM56;D_U"[,F@6\N][KDZ%WM/O5>OF*IJC]54*+]/35;;GR7
M1@,RX             !0;ME]GC3.T3TSF)9*R*+TI/9>KV
MGN*GK_M#3IITO4JJ;&M46Z/>VKW\6YX>'C[^9E?9KTGEE5
MEV+U.ZC=,CCO
M79IFB_5']*JJ8_4LP$9IBK=V)F-DM>Q_2Z]%-9JLXF\-L:QH-^J/])7,3?HB
M?CHH_P 5>=I]N/LS;QIHG2^I6%:FOU9<3C\3_O\ "!N8BJ.*HB8^%\_N;'_F
M+?Z,*YLTSLG%R61II?5WI=K-$7--ZA;=O1/EW=3L?M.XM;NVI>CO6=SZ3_:1[
MCVI=ZR./\I]MS$U1N'3.(\Y^Z[?_ );;F[-JVJ>_=W+I5%/MJS+<1];'0C?.
M_P"*9HC?VX^[,\S'[IWOVGQO[OWME6_>)U.]^T=Q[3O61#J/5/
MIKI-N;NH;^V]9II\^]J=F)_O*=[I[9W9NV?355JW4W3*^YYQBW(R)_Y)E G>
MS-4R?];UO4\CG^>R[E?URXWW/8GQFS1,^V:8=BQ'G+G>RF!WQZ6CL_;=KKQ]
ML:;J^X;O$]R;5JNS3,_'50MIZF^EGZQ;DMWL+IUMC!V[8NR?]->I^&)I
MJCCZ%B]-%-$<44Q$?!#5.+5,(S75+W747KMUDZMWJKW4/J%JNJ4USS]SU7IB
MS3\5,^7TO!V[5NS3W+=$4Q'JAN%D1ILCN #@
M          TKKBBB:ZO*(Y:JU=D+L]ZIVCNL6G[:M6*_W$TJY1FZO?B)[M-N
MF>]31,_[4T]WYW)G2-9=B->B]_T5_9@C0M"O=?=XZ9-&J:I$V='HN4\3:Q_'
MFOB?'WW%$PD5=?H.AZ9MG1L+0-&Q:,;"P+%&/8M41Q%-%-,1$?1#L&*JKFG5
MIICEC0 1=                      '2[T_%#6OD^_]G+NG2[T_%#6OD^_]
MG) QR->_&?7_ )8SOMZW"MPF^-F:K< =1
M                ?++_ -5O?U=7U,A7LS?D'V1\BXGV5+'JR_\ 5;W]75]3
M(5[,WY!]D?(N)]E2HO[0MM;JG ,RX
M  !8;Z8#\@6B_*T?]")-+9Z8#\@6B_*T?]")-KL^%359IN4:O@7L6(F/*:J9B)_6]8
M/'[-;&QW)H>5M?<^L;9S;4VLC2\Z]CUT3YQ$5SW?U<.O75>DHZ34]-.T;E:S
MA8GN&G;KLQG6>*>*>_3Q1,?',TU2M5;Z9YHU99C2= !UP
M                     :313-45QS35'C%5,S$Q\\>+4!4#I_V@^M_2S)MY
M&QNI&K8-NW,<8]=R+EN?TXJE=1T_]+=UBVSCV\7?&S--W'13Q%5^U553>J^'
M\*FE8N(S135O"453&R6C9WI>.B^K4V[.ZMIZUH]^KCO53W*K=/T53*M&V/2"
M=EC'9_P"?WHQSQ_G(T3G^T,=;]R].[W?C#M15[8I\
M6_[BQ_YMSN(]7>]9$W^?[HQSQ_G(T3_\(=7G=J3L^:;%4YO5;0[?=GB?])5/
MC\U+'M^XL;^;AL_]]QVN9]?=.XCU.]3L;G](/V5]L]ZFOJ;A9ERGRHL
M6KLS5\_L>YL>YB[(V;IFW*:HF*;]VJNJ]3\/X55*UGJ!VA^N
M75/*N9&^.I.K9MN[/OL>BY%NW_R1$J>BR**:=H1FJ9:=RGO37/-54^,U5535
M/TSXM021                                            ;;GX,?''
MULA+LR_D"V'\@X7V-#'MN?@Q\GG]9F?]I&JDJ],?^#T\_K,S_M(U6RUX(9Z_%(
ML0                            %ZOHDOX1VM?)$_W:UE2]7T27\([6OD
MB?[M:%SPRG1NF) 8F@                                06^D-_A<[M
M_LN)]52=)!;Z0W^%SNW^RXGU5+K/B5W-EN8#4H
M        2W^B&_(!JORWE?WU]ZQ#T0WY -5^6\K^^OO8KGBEIIV $$@
M                        !TN]?Q-U[Y,ROLJG=.EWK^)NO?)F5]E40,5/].GZV0EV9/R ;!^0,+[&ECVW/*G^G3];(2[,GY -@_(&%]C2
MHO[0MM;JG ,RX              0T^E,Z6_Y$=?[.]<>QW<7=N-[K57$<1-^
M)JB8^/NT0F668>E*Z1U;_P"@G^5>!BQ7G[3R(S(JIIYKFW5,43$?![Z966IY
M:D*XUA#@-MNNFY138_4ZH!=
M7TP])7VE>GT6L?6M5Q-UXEKB(MZA'=J[L?#;BGQ7([*],9MO(FFUO_I;J&#/
MA%5S"KHFB?ACO5S*,,0FW3/DE%K6BU37Y15-RF?UTP@"FF)CB8B7PKT[ N^-S$M5?'2A-B
M$HN2R([/:$Z)Y%J+UGJ7H=5%7E/N_P#^A])Z^]&(XF>I&B>/_P#$,=BG3\2B
M.[19IIICRB(\&OW%C_S;G<1ZN][+(=S.T=T,T^(JR^I^AVXJCF/]/,\_1#RN
MO=MKLP;>LS>S>K>DU&^UA8EF>;6/1
M1\4'<1ZG>RF7W=Z53LV;=IK_ '(OZAKU4?@_<='=B?T^%"=Y^F+U7(F[C; Z
M4TT4SS%O(U*YX?'Q1<_P1R"46:81[RI7_J?V[NTWU0]UQLS?MW1L"Y//W+IT
M4Q33\$353-7ZU!]1S]1UG)JS=:U+*S\BN>:KF1>JKF9]OC/#X"R(B-D9F9(B
M(\(@!UP                                           !)/Z'+]\ZB
M?VG$^RE)NC(]#E^^=1/[3B?92DW8[OCEHH\( K3            $/?I:OX0F
MW_D*Y]LF$0]^EJ_A";?^0KGVRVSXE=S99* UJ
M
M       !*IZ'G4\F[TOW9I54_P"AL:KWZ(^'W.W'^**M*3Z'7\0MX_*4?9VU
M5[P)V_$D5 9&@              >;ZB;!V]U.V;JFQ]TX=.3IVJV*K%VFJ.>
M.]$QWH^&.7I &/-V@>BFXN@'5+5NG^O8U=-BU>JNZ=D3'%-_'F>8F)^#GCYE
M.DV/I NRSC=H'IA66T!8@
M
M    TJJIHIFJJ8B(\9F?4#DZ=INHZWJ6)HFCXM>5GY]VFQCV:(YJKKGU0G-[
M$G9HP.SGTCP=-SL2U.YM4HC)U;)X]]-R8CWG/LCCGYUGGHO.R?5K>ISV@M_:
M353CX=7=V_9NT\=ZOGB;WC[.*X^=*7Y>$,UZO7\,+K=/G+4!0M
M              '2[T_%#6OD^_\ 9R[ITN]/Q0UKY/O_ &MPG-U[\9]?^6,[[>MPF^-F:K< =1                            ?
M++_U6]_5U?4R%>S-^0?9'R+B?94L>K+_ -5O?U=7U,A7LS?D'V1\BXGV5*B_
MM"VUNJ< S+@                                 %AOI@/R!:+\K1_T(
MDTMGI@/R!:+\K1_T(DVNSX5-S< 6J@                             &
M2\ \>UK(O2I]&ZM]=$[6_P#3<2;FH;0N_=%55,'ZXACS=4>G^H]*>H^X>G
M6J6YHOZ)FW+%/,<=ZW$^%4?!YM-FK6-%-R.NKRX"]4
M                                             W447;E7=LV;MVK^
M3;HFNKZ(\0;1]9Q,^F)JJTO.IB/.9Q;D1'ZGR
M       !MN?@Q\VY^#'QQ];(2[,OY MA_(.%]C0
MHO[0MM;JG ,RX               !&7Z8_\ !Z>?UF9_VD:J2KTQ_P"#T\_K
M,S_M(U6RUX(9Z_%( L0                            %ZOHDOX1VM?)$
M_P!VM94O5]$E_".UKY(G^[6A<\,IT;IB0&)H
M        $%OI#?X7.[?[+B?54G206^D-_A<[M_LN)]52ZSXE=S9;F U*
M                          $M_HAOR :K\MY7]]?>L0]$-^0#5?EO*_OK
M[V*YXI::=@!!(                              =+O7\3=>^3,K[*IW3
MI=Z_B;KWR9E?95$#''UW\9]>^5LO[27#HXXFKXYK6(MU%7-&K
M-5&DZ "2(
M           #ZQB9]4153I>=,3Y3&+_2U?PA-O_(5S[9,(A[]+5_"$
MV_\ (5S[9;9\2NYLLE :U
M                                                    E)]#K^(6
M\?E*/L[:+9*3Z'7\0MX_*4?9VU=WP2G;\214!C:                &E5--
M=,T54Q--4<3$^4PB8])OV2[VQMRW>OFR-/\ _P 2ZQ=[NL8UBWQ3C7IGPN<1
MX1%4U1'J\DM#I-Z;.T'?VV-1VEN7!MY>GZECUX]VW7'/A53,5I&9W)[E5J9
MY]SF?;3%5-/S*-ML3K&L,\QIT '7
M                                                !6KLD=G#5^TM
MU7P]L18NT;=P*JUL&[EZG
MJM^FQ:HMT\]V)GQKGV1$IB_J>;Q[^]>F
M.:HY]D3SQ\:NY7RQ[4Z*>:55=J[9TC9NW=/VOH6);QL'3;%&/9MT4Q3$4TQQ
MSQ'KGS=L#&T                          #I=Z?BAK7R??^SEW3I=Z?BA
MK7R??^SD@8Y&O?C/K_RQG?;UN$YNO?C/K_RQG?;UN$WQLS5;@#J(
M                   #Y9?^JWOZNKZF0KV9OR#[(^1<3[*ECU9?^JWOZNKZ
MF0KV9OR#[(^1<3[*E1?VA;:W5. 9EP
M   "PWTP'Y M%^5H_P"A$FEL],!^0+1?E:/^A$FUV?"IN;@"U4
M                    R7@'CVL14>EIZ&4;?W3H_7/2<;C'U?\ _%^I31'E
MNSFZ3E7,.]17'CWK=4T\_/PXC:S
M
M 'DD(]%/V>-.W=GZ_P!7=YZ)8SM-MQ]P:=;R;<5VZJX\:JHB?@KCQ^!8%HVB
MZEN;6M/VUH]FJ]G:ID48UBBF.9JJF?\ QRR!NSATET_HETJTC19;C6=7*W)T)Z7:SH&H:5:V%HENO+QZ[45TXE
M%,Q,QQS$\>#'[WGHMW;6]=?VW?I[MS3=1OV9CV1WYFG]4PR1T#_;PV+1L+M1
M[NP\>S-&-J-VG,M3QQWN:*(F?IY5V)ZZ)7(\U 0&E2
M          VW/P8^./K9"79E_(%L/Y!POL:&/;<_!CXX^MD)=F7\@6P_D'"^
MQH47]H6VMU3@&9<                C+],?^#T\_K,S_M(U4E7IC_P>GG]9
MF?\ :1JMEKP0SU^*0!8@                            +U?1)?PCM:^2
M)_NUK*EZOHDOX1VM?)$_W:T+GAE.C=,2 Q-
M        @M](;_"YW;_9<3ZJDZ2"WTAO\+G=O]EQ/JJ76?$KN;+Q7/%+33L ()                              #I=Z_B;KWR9E?95.Z=
M+O7\3=>^3,K[*H@8X^N_C/KWRME_:2X;F:[^,^O?*V7]I+AM\;,L[@#K@
M                        #;<\J?Z=/ULA+LR?D V#\@87V-+'MN>5/].G
MZV0EV9/R ;!^0,+[&E1?VA;:W5. 9EP               "A/;2Z*X_7'H'N
M';--FFK/Q+-6H8-7=YJB]:B:J:8^.8A S/=IJCQBNB
MJ::OUQ+);JIIKIFBNF*J:HXF)CF)A"#Z1#H//13KUDZGIF)7;T+=T59^-7W>
M*:;OA%=,?'5-4M%BK]U5W8BNK#HYJ[
MM,1S/AYSPL7]$ET(JP]*U?KOK6%,7-1JG!TNJN/*W3SWJX^"J*X^A)(RW:M:
MM(7VZ=(U0[^E2Z7Z-L#J]H&N;=TK'T_ UK ]SJMV+<44>[157,^$?!$+*4L'
MI>]D4ZKTCV]O/'L35D:-J,]^N(_!MU4Q3]=2)^)YCF%UJ=:5=<:5 "Q
M                       !)/Z'+]\ZB?VG$^RE)NC(]#E^^=1/[3B?92DW
M8[OCEHH\( K3            $/?I:OX0FW_D*Y]LF$0]^EJ_A";?^0KGVRVS
MXE=S99* UJ
M                                        !*3Z'7\0MX_*4?9VT6R4
MGT.OXA;Q^4H^SMJ[O@E.WXDBH#&T                  **=K#LW:!VE>EV
M;M'-M6K.KV:9O:5G33'?Q[\1/=\?Y/,\S'/JA!-O;9FX^G.[M4V-NW NX>JZ
M3?FS>HKIF.]'G%4<^<3$QXLD193Z0_L:T=;=K5=2MB8=%K=^@6:KE=%NCBUHU*
M                            GO3--%NW5-UUZD:95;T+3;O>T?#OT>&7$:JHIC64J8YIT7 >C@['-72;;M'5_?^GT_P"56N68JQ;-RGFK!L3Y1X^-
M-4^^Y\O"5]+;;MV[-NFU:HBFBB(IIIB.(B&YBJJFJ=9:(C2-( ''0
M                  !TN]/Q0UKY/O\ V_&?
M7_EC.^WK<)S=>_&?7_EC.^WK<)OC9FJW '40
M   'RR_]5O?U=7U,A7LS?D'V1\BXGV5+'JR_]5O?U=7U,A7LS?D'V1\BXGV5
M*B_M"VUNJ< S+@                                 %AOI@/R!:+\K1
M_P!")-+9Z8#\@6B_*T?]")-KL^%3W<#W/1MRTQ:SOVLF(B(F9]7>GOR
ML=9!_:0Z+:5U\Z1ZYTYU*W1[KG6*IP[M7_TRMT3TWH-T:T+96)8IIR_N>G(SJXCB:[U?OIY^+O3
M'S*OL5RKFJU::(T@10^F V91I74/9V^,>S/&I8=6%>JB/#O=^NJ.9^*F$KRR
M/TL.QZMQ]GRQN3'L=Z[M[/IR:Z^/&+F/_!Z>?UF9_P!I&JV6O!#/7XI %B                             O
M5]$E_".UKY(G^[6LJ7J^B2_A':U\D3_=K0N>&4Z-TQ(#$T
M                  ""WTAO\+G=O]EQ/JJ3I(+?2&_PN=V_V7$^JI=9\2NY
MLMS :E                              "6_T0WY -5^6\K^^OO6(>B&_
M(!JORWE?WU][%<\4M-.P @D                              .EWK^)N
MO?)F5]E4[ITN]?Q-U[Y,ROLJB!CCZ[^,^O?*V7]I+AN9KOXSZ]\K9?VDN&WQ
MLRSN .N                            -MSRI_IT_6R$NS)^0#8/R!A?8
MTL>VYY4_TZ?K9"79D_(!L'Y POL:5%_:%MK=4X!F7                "V?
MM^=G^SUSZ%:I&G8E%>X-!HG/TVN*>:ZJJ8F.Y'P3WIGYES#;6:-6:8TG0 =<
M                                                   'H^G&Q=7Z
MG[_T+8&AX]=W*UC,HLSW:>>Y1$]ZJJ?@[L2\YY>,I*/1-]GF[-6I=?MSZ?Q%
MVG[DT/OQQ,4\Q,W8_P">E&NKEC5*F-9T2%=*^GFD=*NG^B;!T.W13BZ/B6\:
MF:8X[\TQ$35/PSP]8##NTJ%=MG9-O?G9LWCI$V?=+MO#^Z;7$;HP%ZH
M               !)/Z'+]\ZB?VG$^RE)NC(]#E^^=1/[3B?92DW8[OCEHH\
M( K3            $/?I:OX0FW_D*Y]LF$0]^EJ_A";?^0KGVRVSXE=S99*
MUJ
M                                !*3Z'7\0MX_*4?9VT6R4GT.OXA;Q
M^4H^SMJ[O@E.WXDBH#&T                  #2JFFNF:*Z8FFJ.)B?7#4!
M%UZ2/L3Y&G9N9V@.ENE378O3W]=T['HYF)YYF_$1\=4S\$(Y:*HKIBJ/H]5$SWI]7'A#3:N:_AE371YPLZ")BJ(JIGF)
M\I%ZH
M                   /+QD5=[,?9NWAVF>H-C;&@8]=O1L.Y3U-MM[;^D[6T7#V_H>';Q<' LT6+%JB.(IIIB(CZG0]*NEVT
MNCNR-.V%LO3Z,33=.MQ13$1'>KJXB)KJGUU3Q',O7L==GXH:U\GW_ +.7=.EWI^*&M?)]_P"SD@8Y
M&O?C/K_RQG?;UN$YNO?C/K_RQG?;UN$WQLS5;@#J(
M        #Y9?^JWOZNKZF0KV9OR#[(^1<3[*ECU9?^JWOZNKZF0KV9OR#[(^
M1<3[*E1?VA;:W5. 9EP                                 "PWTP'Y
MM%^5H_Z$2:6STP'Y M%^5H_Z$2;79\*FYN +50
M       #)> >/:P !&#Z57LR58F1B=H'9FF+T_\ )2D^
M=)O;:.C[\VIJFT->Q:,C U7'JQ[UNN.8F)\I^:8B?F2HJY9U1JCFC1C>1,3'
M,3S$BJ':5Z$ZQV=.K>J].\^U
ML,\QH .N
M    $S$1S,^"_7T6/9MKWGO._P!==S843I.B35CZ71=I\+U_Q[U]BI/_ -&NEN@]&NG.
MC=/=NV**,;2\>BW553''NER*8BJN?AF8Y4WJ](T66Z=9U>U\O"&H,J\4H[5&
MSK>^^S_O7;DX_NUS(TVJ;<<]KCV51YOJ]GUIVA5L#J]O#9U5$T?N9JU^U
M1$QQS1$\1+QC?'5E !P                         !MN?@Q\VY^#'QQ];(2[,OY MA_(.%]C0HO[0MM;JG ,RX
M     !&7Z8_\'IY_69G_ &D:J2KTQ_X/3S^LS/\ M(U6RUX(9Z_%( L0
M                        %ZOHDOX1VM?)$_W:UE2]7T27\([6ODB?[M:%
MSPRG1NF) 8F@                                06^D-_A<[M_LN)]5
M2=)!;Z0W^%SNW^RXGU5+K/B5W-EN8#4H
M  2W^B&_(!JORWE?WU]ZQ#T0WY -5^6\K^^OO8KGBEIIV $$@
M                  !TN]?Q-U[Y,ROLJG=.EWK^)NO?)F5]E40,5/\ 3I^MD)=F3\@&P?D#"^QI8]MSRI_IT_6R$NS)^0#8/R!A?8TJ+^T+
M;6ZIP#,N                  47[6G0+1^T+T>U?:&98H_="S:JRM.O\>^M
MWZ/?1$?TN[%/SH%=;T+5]K:WG[8W!B5XVI:7D5XN3:KCB8KHF8F?BYB62DBZ
M]*9V6:],SJ>T/LS3HC'N=W'URS9H\>?XMV8C_?F97V:])Y957*=>J.8:4U15
M3%5,\Q,%
MBQS$5US\7>AD"=.-C:/TVV1H^R="QZ+.'I.+38HBFGCF8\9GYYF5F_HO^S'=
MZ<;$O=7=X:=[GN+/RE'V=M%LE)]#K^(6\?E*/L[:N[X
M)3M^)(J QM                     ZG=6U= WKH&9MC<^F6<_3<^U-J_8N
MT\TU4R[8!!IVU.Q[N#LR[QNZKI%B_F['U6]55@Y?=Y^YJIY_T5?L_7YPML\_
M&&1OU&Z=;3ZI[2S]E[STFSJ&FZA:FW7;NT\\3ZJH^&)XF/B0@=K?LG[K[,&]
M[V-5CW\S:&=QZ1](][]<=\86PMAZ;4<1S,1
MSX\$SHZ[#H5T-WKVA>H&'L'9>+7'NM459N=-/^CQ+/,U.CV?^@FR>
MSUL#!V3L_ MTU6K<3F9V\.BO4LB
MBBYJ>?5$3GXH:U\GW_ +.2!CD:]^,^O_+&
M=]O6X3FZ]^,^O_+&=]O6X3?&S-5N .H@                           /
MEE_ZK>_JZOJ9"O9F_(/LCY%Q/LJ6/5E_ZK>_JZOJ9"O9F_(/LCY%Q/LJ5%_:
M%MK=4X!F7                                  +#?3 ?D"T7Y6C_H1)
MI;/3 ?D"T7Y6C_H1)M=GPJ;FX M5                              ,E
MX!X]K    6Q=O#LM8G:+Z67KVCXUNWNK0*:\S3K]-,17=XB)JM3,>,]Z*>(C
MX4(>9AYFF9V5I.IX]=C-P;U>-DVJXXFBY1,TU1Q\<2R6)B)CB8YB47/I..R!
M5I&7<[073G2YC$KCC7L.Q1^#/'[_ !'Q4SS\-7DOLUZ?AE5C'[*L]-MF3UDWE@=W<6Y;43B6KM'OL7&\...?P:IG
MO?-*^]\L3%Q\'&M8>+9HM6;-$4444QQ%-,>41#ZL554U3K+3$:1H (N@ (1?
M26[)N;1[5>KZEW>[:W!B6\VF./":JJ[DS/U+6TE/IAMD46+>R^HMNQXS>NX-
M^YQZN[3%$?37*-9MMSK3#-7&D@":(                         #;<_!C
MXX^MD)=F7\@6P_D'"^QH8]MS\&/CCZV0EV9?R!;#^0<+[&A1?VA;:W5. 9EP
M               ",OTQ_P"#T\_K,S_M(U4E7IC_ ,'IY_69G_:1JMEKP0SU
M^*0!8@                            +U?1)?PCM:^2)_NUK*EZOHDOX1
MVM?)$_W:T+GAE.C=,2 Q-                                 @M](;_
M  N=V_V7$^JI.D@M](;_  N=V_V7$^JI=9\2NYLMS :E
M              "6_P!$-^0#5?EO*_OK[UB'HAOR :K\MY7]]?>Q7/%+33L
M()                              #I=Z_B;KWR9E?95.Z=+O7\3=>^3,
MK[*H@8X^N_C/KWRME_:2X;F:[^,^O?*V7]I+AM\;,L[@#K@
M              #;<\J?Z=/ULA+LR?D V#\@87V-+'MN>5/].GZV0EV9/R ;
M!^0,+[&E1?VA;:W5. 9EP                  Z?=VT]#WQMO4-J;DP;>7I
MVI6*\>_:KB)B::HXGXI\?-W " /M6]G?7>S9U7S=J9UBY.BZA[<
MLS//=Y]L3,Q\RCJ>;M@]F;0>TITNS-!OVZ+.NX-N;^DYG=]]:NQSX<^R8F?I
M06;GVQK^R=QZAM#=6GW,+5M*O56,FS7'$Q5'KCVPV6Z^:&>NGEEU@"Q
M                                                  7)=A'LS9':
M*ZNV+^L8MVG:NV;E&9G7N[/=NW:9FJBU[)]]3$3\$J$[%V3N'J5O'2MA[5P[
MF3J6L9%-BW313SW(\YJGV1$1*>KLS= ] [.O2O2]@:13:NY-FB*\_,IIXJR;
M\Q$55S/'/CQ"J[7RQI"=%/-*J.!@XNF86/IV#9IM8^+:ILVK=,<1313$13$?
M%$0^X,C0  +*_2M[&_RD[.7^4=N/]+H&H6+W,1X]R:N:O[J]12SM0;,L[\Z#
M;TV]=L^ZU7-)R+EFGCGFY3;J[OZTJ9TJB7*HUACYVZXN44UQ_&B):E5FK&NW
ML2N.*L>]L.SL[9&]]*M9NG9UN:)BJF)JMS,<153/
MJF.?"8>N#80*]K+LG[Q[+N\;F-F6;N9M//NS.EZG%,\4Q/C%NY/E%4>/KGF(
M4+9&74[I?LSJ[M+-V9OC1K&H:?FVYHJIN4^-$^VF8\8E"CVNNQWO/LP[INWK
M&/D:GLK,NS]P:G%/,VN9_>[G''$QX>/''C'BUV[G-TG=171IUA;V$3$QS$\Q
M(M5@
M          *B="N@N_\ M#[WQ=E['P+D6[E<1F:E51_H,.WSXU53[?@B)\G)
MG3K+L1JZ_I!T>WYUTWIC;&Z?:1=S,J[7'W5D13,VL2USXUW)B)X_\S";OLL=
MEC9'9EV19T/1,>C*UK(IBK4M4KHCW7(N<>/CXS%///$<\1S+F=FCLR;#[-6R
M+&VMLXEN]J-RF*M0U*NG_2Y-WUS,^J/*.(X\H5C9;ESGZ1LOHHY>L@"I,
M                             =+O3\4-:^3[_P!G+NG2[T_%#6OD^_\
M9R0,S
M-^0?9'R+B?94J+^T+;6ZIP#,N                                  6
M&^F _(%HORM'_0B32V>F _(%HORM'_0B3:[/A4W-P!:J
M              9+P#Q[6    .%K.C:9N'2LK1-9PK67@YMJJS?L7:>]1PMWX%K)P]0LS13551$U6:_.FNF?.)B8CR03]H[L\[O
M[-?4/)V5N2Q=NZ?IWJ;&-8MQS555/K^*(YGY@>KZ)]'-U=>NHVF].=I8]=5W+K
MBK,R(IF:,:Q$^_KF?*)[O/'CX\)Z>B?2#:O0_IYI>P-I85-C'PK-,7JHB.;U
MZ8YKKGCVU35/SJ3=B3LFZ/V:NGEJK4L>WD;OU>BF]JN753$U453'/N5,^JF)
MFKV<\KE62[7S3I&S113I&H J3    6D^DZV'&].S!JF9:LS=R-$RK&9;IB.9
MXBY3-4_-%*%6U5-=JBN?.JF)_4R*.MVUK.\^DN[-NWZ>]&7I&733''/O_<:N
M[^OACNY6+7I^?FZ7F
M/_!Z>?UF9_VD:K9:\$,]?BD 6(                            "]7T27
M\([6ODB?[M:RI>KZ)+^$=K7R1/\ =K0N>&4Z-TQ(#$T
M               ""WTAO\+G=O\ 9<3ZJDZ2"WTAO\+G=O\ 9<3ZJEUGQ*[F
MRW,!J4                              );_1#?D U7Y;RO[Z^]8AZ(;\
M@&J_+>5_?7WL5SQ2TT[ ""0                              Z7>OXFZ
M]\F97V53NG2[U_$W7ODS*^RJ(&./KOXSZ]\K9?VDN&YFN_C/KWRME_:2X;?&
MS+.X ZX                            VW/*G^G3];(2[,GY -@_(&%]C
M2Q[;GE3_ $Z?K9"79D_(!L'Y POL:5%_:%MK=4X!F7
M  "PWTC_ &,K?4W0[G67ISI=-.Z]*MS7J%JW$D:[$5[9^H9O7CI7I4U:/D3-W7,"S3^\5>,R5511
M3-54\1$?,5(U513&LNQ&LZ+@O1O]CW_-)M>.K._M/HJW5KUJ*L6BY3XX6//$Q3'KBJ
M>[SZOPO)?*VV[=%JW3:M41111$4TTTQQ$1'E$-S%55-4ZRTQ&D: #CH  X^?
MAVM1PK^!?CFWD6ZK=UU
M37_U/&+K_2;;)C:7:>S-3LVNY8W!ATY=/AQ'-%-%$_KB5J#=3.L1++,:2 ).
M                          ))_0Y?OG43^TXGV4I-T9'H
MT .8]IS'M #F/:.D6-2TO/MS;O6+U,51//E,<^N/.)]L.^
M 0F=LWL+;L[.>K9.[=H8M_5MAY-R:K==NF:[N!S//=KB/'NQ_*XB/!:G3537
M3%5,Q,3ZX9*.MZ)I.X]+R-%US3L?.P";+H/T$V!V>MD8^S-AZ5;QZ
M.[35F9'$>Z95Z(\:ZYB(Y\9F?G>@Z;],]F=)]JX6SMCZ)CZ=IV#;BW13;HB*
MJ^/755YU3\,^+U+)7_&?7_
M )8SOMZW";XV9JMP!U$                           !\LO\ U6]_5U?4
MR%>S-^0?9'R+B?94L>K+_P!5O?U=7U,A7LS?D'V1\BXGV5*B_M"VUNJ< S+@
M                                 %AOI@/R!:+\K1_T(DTMGI@/R!:+
M\K1_T(DVNSX5-S< 6J@                             &2\ \>U@
M "DG:3[.6R^TCT_R]G[FQ;=O,BBJO3\_N^_Q;W'O:HGV<\<_$JV.Q.DZP;L=
MGK/T;WKT&WYF[ WQ@UVLC'KG[ER>[_H\JU_%KIGR\ICEX=/AVINRULCM-;(O
M:)KN-1CZUBVZITO4Z:8]TQKGCQX^V9L3?^EW,;+QJ
MYBQD=V?<4^ORF?)KMW(KCVL]='*\8 L0
M                           ([]5RW9M6Z[MV]7%NU;HCFJY7,\13$>N9
MF8@&ZS9R%C7,G)OUQ;LV;5,U5W*I\HB(2[^CV[$6/TAT6UU7ZDX-K)
MW;J]F*\;'NT\_N;;GRB/]J>)]<^%3QGH]NP95MFG$ZV=9-)IG6:^[>T;3KL1
M,8M$^,7*HG^/X4S'A$QS*1>FF*:8IICB(CB(]C-=N:_AA=11YRU 4+0
M'SOV;>38N8]ZF*K=VB:*HGUQ,<3#'S[3NR[NP>T#O?;]=J+5$ZE?UF9_VD:J2KTQ_X/3S^LS/^TC5;+7@AGK\4@"Q
M        7J^B2_A':U\D3_=K65+U?1)?PCM:^2)_NUH7/#*=&Z8D!B:
M                           !!;Z0W^%SNW^RXGU5)TD%OI#?X7.[?[+B
M?54NL^)75_
M?7WK$/1#?D U7Y;RO[Z^]BN>*6FG8 02
M  '2[U_$W7ODS*^RJ=TZ7>OXFZ]\F97V51 QQ]=_&?7OE;+^TEPW,UW\9]>^
M5LO[27#;XV99W '7                            &VYY4_TZ?K9"79D_
M(!L'Y POL:6/;<\J?Z=/ULA+LR?D V#\@87V-*B_M"VUNJ< S+@
M            '%U/2]/UK OZ7JN':RL3)HFW=LW*>::Z9\XF$.G;U[$&J=#-
M?R>IG3W!NY>S-4O3R+NSM/;QLW[N-=P]EZ;>B=3SJJ9I]VB/_IVY\.9^&.?*
M7)F(C678C5Z+L-=CC6.T=N^UNC<^+=Q-D:/>HNW+E=/'W?9]D
M^::O1-$TK;FDXFAZ)@VL/!PK5-BQ8M4\4T44QQ$1\T.LV#L+:_3/:F!LS9VE
MVL#2].M1:LV;=,1$1'KGCUO0L==CF0?4=AI.V]U:_=IL:%M76,^JK\
M'W#"N5Q/SQ"I>V>R1VDMV]S]RND^KVZ;GX-679KL4S\]5+DS$;NZ2I(+M]M>
MBX[4FX;5-[.Q]&T>F?.+N51AYW;E115N_JEC8GKJIQ\2:N?@Y
MBXC-RF/-WDJE'AY>;9-ZS3X3=HCYTM.W?1#]&L*:*]Q[KUS49I_"BUD3:IJ^
M;Q5.T/T9W9/T:FBJO95_-N4>=>5?INIWN?+W/"NU?52GVT'LC]G+;E--.!TDV]5-'E5>PK==4?
M/P]SI?3+I[HL1&D[-TG$X\O<<:FGCZ(1F_'H[W4L>[3^E/575^/W)Z<:]D\^
M7&+53_>B'K-'[*G:1UWC[BZ2:O1$^7NOW:CV4QP^R/
M?SZ.]U""[2/1X]K35XBNGIW./;F>)JNW[7A\W?Y>MTST77:>SN/NJQI.#S'/
M^EJF>/@][,II!SOJG>[A$)I_HD.NV3'.?O;;F/'',13;O<_%Y/2X/H=-]WII
M_=#JYIMJ)CF?<[-SS]GC0E6'.^J=[NE%_8]#5J7=BY\?<[7AQ\]MW%
MGT.&B1/C:_87_ (YWE7J^O_3:_87_!WE7JYR4K ?\ X/\ T>_^]]?^FU^P?_!_Z/?_ 'OK
M_P!-K]A?\'>5>IR4H\LWT//3:N]S@=0]:M6^/*OW/GG]!UF?Z'+:U?HMI(!WO*O5WDI1CY?H:ZJKLSA=8\BBWQX17;CGGYK;J,OT-^
M[K='.'UAPKE7/E^Z6KO
MC'S1#RVI>BO[2V%%4XN3HF;Q,Q'N7?CGX??3"9H=B]4=W2@WU7TPZ,NBGGFJU?MQ]=;PNM]D7M+[?Y^[>DVJ5]WS]RJMU?54R AV+]3G=0QR]1
MZ1]7-'IFK5NF>OXT1YS.+55_=Y>?R-)UG$F8RM"U.S-/G[IA7:>/II9)^1BX
M^51[GDV:+E/LJCF'GM5Z:=/]=B8UC9VE9D5>?NV-35S]*47_ &.3:8XDWJ:9
MF*Z:Z9CS[U$QQ]+6F]:J_!NT3\4I_=Q=D#LW[GMU4:ATEV_;[_X55C#MT53\
M_"EVO^C#[*>LV[GW+M7-TZ[7XQ7BY,4[E"J)4]R^A]Z;Y<5SM3
M?^K:;,_@_=,U7XC]<*.[L]$-U>P*JIV?OW2]2IB9XC(M1:F?IK2B[3/FYR5+
M#A<=N[T>G:JV?57-S9%C4[5'_P!3"RHN3/Q4TQ*CNYND75G9M55.Y^FVXL'N
MSQ,UZ?=X^/GNIQ5$[2CI,/)C9J'0_'LZ;K\15>S=*ICBSF<>,S1'JK\_7$
M>2+/6=&UG;>JY&@[CTK(TW4L2N;=[&R*)IJIJB>)^./AADIK:^U?V(NG':5T
MJYJ/W/;T?=UFW,8FK6:(B9GCPBY$<37'A'AS'DNMW=.E2NJC7K"#45 ZV=!^
MI79\W1G>]NK&Y\?9W3[0LC5=2R:HIXMT3-NU'\JY
M5$3%,>/K2V=D'T=FRNB5G$WKU%M6-P;RFF+G-RF*K&'5[+<3SXQ_*B4*ZXHW
M2IIFI;SV,/1L:CNJ]@=3>O>'.-I=/=O8F@5^%=[UQ5=X]7EX1,3XRE)T?1M*
MV_IN/I&BX%G#P\6W3;M6;5/=IIIB.(AS1DJKFN>K133%( BZ
M                        .EWI^*&M?)]_[.7=.EWI^*&M?)]_[.2!CD:]
M^,^O_+&=]O6X3FZ]^,^O_+&=]O6X3?&S-5N .H@
M      /EE_ZK>_JZOJ9"O9F_(/LCY%Q/LJ6/5E_ZK>_JZOJ9"O9F_(/LCY%Q
M/LJ5%_:%MK=4X!F7                                  +#?3 ?D"T7
MY6C_ *$2:6STP'Y M%^5H_Z$2;79\*FYN +50
M      #)> >/:P       !1[M*]F78/:4V3>VUNG"HLY]JF:\#4;=$1>Q[OJ
M\8XF:?#RGP\95A'8F8ZP;L>CKST!ZA=G7>=[:.^M.N18JKJ^X-1IIGW++M\^
M$Q/$>/'',?"IPR'>M/0WI_UYV?D[.W[HUK+Q[U,^Y7N['NMBOCPKHGU3"%_M
M4=CCJ+V8]P7*\C'O:QM3(KFK#U2Q;FJ+=/JIN<>,3'CX\1'@U6[D5=)W454<
MO50(*:J:H[U,Q,3ZX%JL
M  !S=#T/7-TZQC;=VSI.1J>IYE<6[.-CT3555,^WCRCX9\ <2S:R,K(M8>'8
MKR,G(KBW9LVXYJN53Y1$)0NP5Z/>G;DEC$ZE]6J&X%"T
M      1X>E_V).H[#VMO^W:F:M)S8PZZHCRIN\U>/Z"0];CZ079-[?'96WEA
M8UJ*[V!C59]'AXQ-NBKQC]).B=*H1JC6$%_GXC98J[UJGGSCPGXX\&]M9@
M                       &VY^#'QQ];(2[,OY MA_(.%]C0Q[;GX,?''UL
MA+LR_D"V'\@X7V-"B_M"VUNJ< S+@               $9?IC_P>GG]9F?\
M:1JI*O3'_@]//ZS,_P"TC5;+7@AGK\4@"Q
M   7J^B2_A':U\D3_=K65+U?1)?PCM:^2)_NUH7/#*=&Z8D!B:
M                      !!;Z0W^%SNW^RXGU5)TD%OI#?X7.[?[+B?54NL
M^)75_?7WK$
M/1#?D U7Y;RO[Z^]BN>*6FG8 02                              '2[
MU_$W7ODS*^RJ=TZ7>OXFZ]\F97V51 QQ]=_&?7OE;+^TEPW,UW\9]>^5LO[2
M7#;XV99W '7                            &VYY4_P!.GZV0EV9/R ;!
M^0,+[&ECVW/*G^G3];(2[,GY -@_(&%]C2HO[0MM;JG ,RX
M          !P-C^U
MWHWGYO4OI/@Y&I[0O55Y&;B41-5S F9YF:8]='X7K\/#P3$/CF8>+J&-R83HKFB>B-5,5,::BNFNGO4SX-4DG;;]&[19IB/"+=7
M$1Q]$M%B=X5784H :%(                         "2?T.7[YU$_M.)]E
M*3=&1Z'+]\ZB?VG$^RE)NQW?'+11X0!6F            (>_2U?PA-O_ "%<
M^V3"(>_2U?PA-O\ R%<^V6V?$KN;+)0&M0               >7C( VTW*;E
M7<6?JG
MC$U6\+BW3\7OJ95SMW>W]F[SW9>IQ]K[2U35+
ME?X-./8F>?IX3@;#[!'9@V#%->#TUP,V_''^FRXFNN9]OA,0K=H>S=J;:Q*<
M'0=O8.%8H_!HM68B(0F_'E"46I\T'6S>P3VJMZQ:OX_3>_I>-=X_TF?S1,1[
M>(B5P&S?1 ]1=0BU=WQU%PM.HJB)KHP*?=:H^#W],)7::::([M%,4Q[(CAJK
MF]5*46XA8KL_T1_0;1+MK)W%KNL:WQ3V:]E4VXTCI
MII]=5OQBK*B;\S/M]_RKD(375.\I13$.ATO86R-%MTVM)VAHV)%$<4^Y8-JF
M8^>*7>4446Z8HMT4TTQX1%,<1#<(I
M   #A9^B:+JL=W5-(PLR)]61CT7/[T2YH"EN\.S#T(WU[I.X>FNBW*KO,556
M<:BS5]-$1*@.]O13]F_=%R;NC4ZGH%4S,Q]S7J[D1^E6O0$HJJC:7)IB46^\
M_0];@QIO7-@]3ZS$S-S3
MZJJYGXHF(3EM)B)CB8YA.+U4(S;ACA;EZ=]0MF7JK&[-CZQI5=$\3&18XX^C
MEYNC(M7)FFFOQCPF)CCADGZMMC;NNXM>%K&BX>78N>%=%VS$Q*B/4'L)=F3J
M+$UZITUT[$R)YG[HQ*9HKYGU^,S'ZED7X\X0FUZ((N8GR$H_43T/VSM0JN7^
MFO4#.TJ?&JFUF\7*.?9[VF/!;%U#]&CVFMB6[V5IVF86Y<2U,_Z3"KBW5W?Z
M-=7,_0LBY3/FA-%4+51W^Y>GO4+9F15C;LV/K6FUTS,3-S#N31X?[41Q^MYZ
M+MN:NYWXBK^3/A/T)HMP               "4GT.OXA;Q^4H^SMHMDI/H=?Q
M"WC\I1]G;5W?!*=OQ)%0&-H                              >,ZI](=
M@]9-LY&UM^[?Q=1Q;]N:*:[EN/=+4S_&HJ\Z9^*81&=JWT>'4+H1?RMT]/[&
M3N79U,S7,T4\Y&'3_MQZZ8CU\S/A*:9\\C'L9=FO'R;-%VUI\^9GX8CS17]3NDW43HUN*_MCJ+MK*TS)LUS33>FW,V+L>VFN.
M:?UM5-R*]E%5,TO)!YQS FB
M              [?:.S]U]0-W,Q3,^NJKRICXY!T
M]==-NF:JYXB%Q?9@[#_5/M)9]C4J\._H&SYJ_P!+JMZCBJ]3ZXM1,<3/'MX\
MX7?=E7T6^D[?N8>^.O\ =LZMJ$13>L:-1^\6*O5[IY]Z?BGV)"]+TK3=$P;.
MF:3A6<3%QZ(HM6K5/=IIICRB(45WM.E*VFWKUE3;H-V;NF/9ZVQ9V_L?0[--
MZ*8^Z,^[1%61?K]%5 9YG7K*[30 <
M                  !TN]/Q0UKY/O\ V_&?
M7_EC.^WK<)S=>_&?7_EC.^WK<)OC9FJW '40
M   'RR_]5O?U=7U,A7LS?D'V1\BXGV5+'JR_]5O?U=7U,A7LS?D'V1\BXGV5
M*B_M"VUNJ< S+@                                 %AOI@/R!:+\K1
M_P!")-+9Z8#\@6B_*T?]")-KL^%3YJO9&D1S7?Q:?.9HXYFJ(CU<1QPL0GO47;
MEB[;KMWK-4T7+=<<5T51/$Q,>J>62Y711N%-_=NPO<=L[MIIF8KLT=W'R9]ERF(F(^.(Y\9:*+WE4JJM^<(:Q[+
MJMT>ZC]$=R7ML=2-MY.FWZ*YILWYIYLY%/\ *HJ]GQ\/&M&NJK8 '
M                              :55TT>?/CX1$1S,_,NM[*_H^>I?7[*
MQ]P[RQ\G:^S^]%IC*RJHF+&+1,^-557'$3QSX2F/[)G8AZ>=FK2+6IW+-O6-W9%$
M3EZI>HB9HJX\:+?//=B)]D^/$*M](.BG3SHAM;&VIL'0,;!Q[%$4UWHHYNWI
M]M5<\U3]+WC+7=FKI&R^FB*0!4F          .@W[MRQN[9FL[8R:(KM:GB7
M,>NF?7%4._:3XQP#&TW/I%W;VZ=9V_D4=R[IV=>LUT_R??3,1]$PZU$^5$_KHE;:WTSK&K+,:3H .N
M            -MS\&/CCZV0EV9?R!;#^0<+[&ACZ8F-7G:C@Z?;IFJO,R[&/
M3$>%HV)9JB?.*J;5,3]2B_P"2VT]J S+@
M               $9/ICZXFKIY;XGF*\R>>/#_Z2-=*+Z8G;=Z_LS9>[**:I
MMX&;=Q[DQ'A$W9MQ'/T(NFRUX6>OQ "Q
M 7J^B2_A':U\D3_=K65+^O1!;/R<[J?NW>T4S[A@8=O&Y]4S7%R/\$+GAE.C
M=+( Q-                                 @K](75W^UQNV>)CC&Q8\?
MBJ3J(2O2:[7O[<[5>HYUVFKW/6-/QKM%4^7O:9F?[RZSXE=S9:L U*
M                       &VY5W+=5?\F)D$N/HAOR ZK\MY7]]?>LV]%;M
M&[M[LR8NJWHFFK6-1R5]E4[IUVX\.O4=O:II]'X65A7[,?'5
M1,?X@QO==J.#I]NF:J\O+L8],1YS-=R*?\61)T6T&K;'27:.@7(F*\'1
M\2Q5$^J:;5,3]2B_M"VUN]J S+@                         &DQ%433,
MV%Z/;9O7>UD[SV';L:#O2*9J]THIBFSF3Y\7(CB.9G^-//FO''::
MIIG6')B)Z2QQNH_37?/2+=%_9W4/07
MM>:9"'7/L[=,>T!MC(V[OO0;%ZY,N]K&CXN1N?:/>F:,ZQ1S=QZ/_ ,K'$1]'/FU478JZ2IJHF%LHVT7*;DS1-5RY7,\1$1'C/C,/<]'>AW4WKQN2UMSIQMS(SN:XIR
M+&-3/\:J?_$2ET[)O8"Z==GC%MZ_K]NSN3=URF)NYV11%5NS/KBW3/AQXSX\
MOX$FFG:=@
MZ1@V-,TS%M8V+C41;M6K=,4TT4QY1$1Y.1$13$4TQ$1$<1$>IJR5535.LKXI
MBG8 1=          $.OI7=BT[;Z_:=NO'L]VSK^GT]^OC\*[357,Q]'"8I8Q
MZ6'I/>WAT4P=^:7A]_,VMF1=NUTQS/N5R::)CXO&5EJ=*D*XUA$0-**XN44U
MT^545R)IIU#4;5JWS'G%%-=,_4D58[OCEHH\( K3            $/?I
M:OX0FW_D*Y]LF$1!>EOP\BSUZVWFW+?U+K^FGHCNIFX*+.;U)WKBZ'9JXFO&PHFN]QZXGO4\?1*,UT
MT[RE%,SLL(N7K5J.]V71A;/VKJNL7:YXI^X\6J[$_/3
M$IE.EWHS>S=T[FC(U+1K^Y,JCQB[GUU1X_T::N/U+D]M].]C;0Q;>'MO:>E:
M?;M1Q1[CBT4U1\_'*J;\>2<6Y\T,'3OT<':BZ@3;OY.W,7;N)7$5=_/N]RYQ
M_0JB/%=)TZ]#_M7'ILY?4[?N;J%<<37BX5,V*8]L=Z*IY^A(YY>$-5IX_TNH6Z,BKF/7S52K9I6AZ/H6/&+HVF8V%9
MB.(MV+<44Q'Q0YPKF9G=*(B-@!QT
M                   !U.O;3VSNG'G$W'H.#J5FJ)B:,JQ3GFEWJ[E/'NMFU[C7'P\T<+0>J
M'H@]E:E5=U#I9OC-T>_5S53B9-,56>?9WIBJKA;3>IG=";]S'MXJ[JWS4L'4=%RIP=:TW*P,BF9BJU?M33,3
M[/8MB8G9"8F-WQ")B?&)B1UP        2D^AU_$+>/RE'V=M%LE/]#OB9%/3
MC=^;5;F+%S5.[35[9]SMJ[O@3M^)(> QM
M      \7U2Z/=/.LNW;^VNH&V\34\6[1---5VW3-RU/MHJF)FF?AA[0-A$5V
ME_1=[ZZ?5Y6Z.B-VYN#0Z.:ZM,NS,Y5FGSXIGQFYX?!"QO/P\[2=1OZ/J^#?
MP<_&JFB]C9%$T7*)CSYIGQ9+$Q$QQ,#1%N[1/MF(XBKY^5]%[3I4JJM^B!P7/]H;T>W6[H9=O:GHNGW-W;[7173--5,^R8EHBJ*ME4Q,;@#
MK@                                          #;7V/=VEM6YQ7W[]$QE7Z?/BFB>[-,3[>9
M\_@2J]#.S1TE[/FB6]*Z?[;LV+\T1%_.NTQ7D7JO7,W..>)GU*I6K-JQ;ILV
M+5%NW1'%-%%,1$1[(B&]FJN37NNIHBD 02
M                '2[VGC9^MSQSQI^1]G+NG U[!JU/1,_3J?/*QKEF/CJI
MF/\ $&-YKL\[FU^?;K&=]O6X;T'471+VVNI&[- R*:HN8FLY?,51X^^O5S#S
M[?&S+/60!UP                           !\LO\ U6]_5U?4R%>S-^0;
M9'R+B?94L?&QBUZAF8FEVJ9JKSLFUBTQ'GS75%/^+(HZ+Z!.V.E&TM$JGFK%
MT?#IJY]4^XT\J+^T+;6[V@#,N                                  6
M&>F GCH)H<<>>K\?W$2B8WTK>T\K<79NG4L>BJJG1LZWD7.(\HJKHI0XT5=^
MF*H]<
MVQU"VWB:IB7:9BF;M$35:J_E4SZI19]IWT8V_P#IC7F;LZ.7+FX]NT3-?[G5
M3$Y>/3\$^'?\/5%/J3 M//PE.FN:-D:J8J8TV7BYNFY=S3M5PT'B7;NO:!;TS6*HGW/4\"B+5V*O;5W>)K^
M>4977WT<_77H[EY&H[7TVYN_;E'-=.1AVYG(MT1_+MTQ/'Q\M--VFI351,+5
M@N=^QDW,+)M5V,FS/=N6;D=VNB?9,>H6(
M    .=M[0M=W=K%K;VU-&R]7U._5%-&-B6IN5S,^7A .#,Q$CVC&V7TV^Y=X=9IL;FW);FF[:QIIC[EQ:O/PI
MGGFJ)]<3QX+Z<;&Q\.Q;Q<6S1:M6J8HHHHCB*:8CB(A]1GJJFJ=971$1L (N
M@             +-/28]G+(ZP]):-Z[/=Q];JYCGB?@GV-S0I                       >JZ7=+M
MZ]:-Z8>P>G^EW,W4F(Y\?/CPCPY5J8[E?/+113RP *T@
M           %".VOT=GK7V?=Q[8Q+,5ZAC69S\/WO-4W;435%,?'/"!FNQ?P
M[][ R[=5O(Q+M>/>HJCB::Z)FF8F/CADN54TU4S35$3$^$Q*)3TB?8GUS96Z
MLWK3TNT*]F;>U'G(UG%QZ)JJQ+OKN1$?Q9XF9GP\97V:]/PRJN4Z]86&C;:N
MV[U'?MU1,-S2I                           ;;MVW9HFYCOZ#WNBO0/3[NM8C
MBJFFN(JIHF/.)IYJ6=>CX["NK;[UK ZU]6-*N8FWL*J,C1\&]3,59E<>5RJ)
MX][',\>?C2EGHHHMT1;MT1333'$1$<1$,UZO7\,+K=.G66X!0M
M                      $>7I;.B>1KNR=(ZRZ+A3^]L:CM+<>'1E:=JF/7C7[=<1/--43$\>R?'S2IJY9U
M/E"A\3$QS$\Q+;$Q,:PS3&FX ZX
M     /0=/MCZWU,WUHFP]OX=S(S-6R[=J8HIFKN6^>:ZIX\H[L5.DPL3-U/4
M<71]*P[N9GYMR+6-C6:>]BO>.KV8]S
ML54\Q@6I_BQSY5>?,\1X2A77R1JE33S2NNZ3]/\ 3NEW3O0MB:7:HHLZ1A6L
M:9ICB*ZJ:8B:OCGAZX&)I                                  0M>DS
MZ,9737K[=WCA8=5.C;MM1?IN13[VG(IX[\3/MFJM:,GX[5G9UT3M)]*L_9.=
M%NSJ5$>[Z;ES3'>LWZ8GN^/G$I737>G1[=V3L?J!HU_3=1QJZJ;<
MW:)IHR*(GPKHF>.8F.&NU7S1HHKITG5YD!:K
M   >IZ7]+]Z]9]Z8FP>G^E7,W4LJN(N5Q$^YX]'/C77,1/$>,?2;.JQ=@OH3
ME]<.O>F57\6N=$VQ73J&=>FF>YWHY[E//ESWHI\/A3HV[=%JBFW;IBFFF.(B
M/5"B_92[-FV^S3TSQ-IZ931?U2_$7M3SIICOW[TQ'/CY\>$>'*M3'B_V;U"G*W?T4KL;9U^OFY/73L,RBY,U3,_!PL$WWL'?'2[6*M ZB;
M7S]"SJ9XBC+M3137\-,SQS#337%6RJ:9IW="'GXP)(@
M             V7+UNUQWZN)JGBF/7,^R%Q/0'L+==NO63C9^-H5W;VW:YBJ
MYJ6H6YHFNCVVZ9CBOZ85=JBFW8Q[LM5S;^VJYBY&FTS$9631\,^/S
MIV$.BG9\L6\_#TFG7=P<1-S4]0MQVBFKO=SU^4KD(B*8B(CB(\(AGKO:
M]*5M-OU>0Z8])M@]'MM6-J=/]NXNE8%B(CNVJ(B:Y_E53ZY>P!1NM
M       'G]_;.TOJ!LW5]G:Q8HNXNJXEW&JBJ.8B:J9B*OFF>?F>@ 8Z_6KI
M1KG1'J?KG3C7<>NW.!D5SAW*J>(O8TU3[G5'M][Q]+Q*:_MV]C;![2.TO\H=
ML6K6/O;1[/WJN?7$]VF(GQX0Q[HVQN+8^XLO:6\-)OZ9J^#7-N
M]C7Z)IGP]<<^<3X>/PMENN*X9ZJ>676 +$                      !]]/
MTO4=>U+#T#1\6YD9^IWZ,7'M6Z9JJFNNJ*8\(]7,PX\U>_HMTTS7)F]WZT=&MX= ^H&?T[WIAW+=[%N5?9XKHF?/REXANB
M==F;30 ' &EFJK)RJ,'#MUY&3
MNQ=T;8-_2L"_QQF:K%5BGB?7'-,Q*\?I5Z(/;MBBQG]8-[96?>IF*J\+!B;5
MOXO=*:N9^A";E-/FE%,RC#QZ+^;=BQI^)D9EVJ>*;>-:JNU3/Q4Q,JU=+NQE
MVC>K=RW_ )/[!R=/QKOC]U:CQ8IB/;W:^[,IF.FG93Z#=)\>W9VET\TNFY;X
M[N1DX]%^]$^WOU1RJQ:M6[-NFU9MTT44QQ333'$1"JJ_Z+(M>J,SI7Z(&N*K
M&?U=Z@3?B>)N8>FTS;X^#O5=Z%W_ $R[$?9OZ54V[FW^G6GW\NWQ,9>7;BN]
MS'KYB(\?F5W%4UU5;RG%,0^&+@X>#:IL8>+:LVZ(XIIHIB(B'W!!(
M                                                          !I
M5335'%5,3'LF%.^I'9[Z.=6L:Y8WYL+2]4JN4]SW6[9COTQ\$JBA$Z;&Z/?J
MUZ(SIYK?NF9TFW5E[>O3S5&/DS[K8Y]D13$3$?.LRZL]@3M)=([=S+RMKQN'
M IGPR=,XJF8_JXFJK]2=5I,15$TU1$Q/G$K:;M4(3;B6-/G8>H:3D5XFLZ;F
M:=?MSW:K678KLU1/Q51#Y1,3',3$Q\#(0ZE]FKHIU:Q+F-O38.EY-=V)BZ55>'T+:;U,
M[JYMS&R,$5HZJ=C?M&=':K][=.P,K,T^Q,__ #VFT57[4Q'KF>[$0HI%ZB;M
M=BKFB[;GBNW5X54S\,+8F)V0F--V\!UP !MN7*;5%5RN>*:8YF4UGHRNG63L
M/LSZ9F9EJJW>W%=JU&JFJ.)CSHC]5$(J.S/T$U_M&]5],V+I>'>JTJB]3=UC
M,IIF:,?'B8[T3/MF)\(\/*4^VU=NZ?M';FG;9TJS3:Q--QZ,>U33'$1$1_YY
MEGOU?NK;<>;M0&=<                                    V7+5N]15
M:NT4UT51Q--4/1]]>^A]-_5,?3/\JM#HJGNY>GT]5C9=B[C7Z9XJM7Z)MUTS[)IJXF&2YVJ*..]\\KZ;W\2N;?H@F%Y_6_T
M6_6SI_>O:ETSOVMWZ11S--GB:,J*?9%$=Z:I^=9]N70-?V9JES1-W:)FZ-G6
MZNY59S+4VZN?BE=%45;*IB8W<$!)P
M   !NQ+=_4,ZWIFG8UW+S+L]VBQ8I[]=4_! -K;5T5U:NV,[5M$_R3T6YW:YR-0IFB_51/KIMU1'/TI".A/HV.@_2"Y9U
MC6L&O=>M4<53D:C3WK,5?!:JFJF%=5VFE.*)E%_T/['W7;KYF4T[8VKD:9IL
MS'NFI:C:FU;II]L4U]V:OF20]G?T8?23I;./KW46:=XZ]:XJBV
MFB8YB>?A]B\W!T_!TO%MX6FX=G%Q[4=VBU9HBBFF/9$1X0Y"BJ[54MIHB'&T
M_3L'2L2W@Z;B6L;'LTQ1;MVZ>*::8CB(AR05)@
M                         (6O2:=%[W3'KU.[L#!JHT;=UJ+]-RF/>TWZ
M8IIJB9]4S/>E:,GX[5G9WT/M(]*=0V5G46[.I44S?TW,[L=ZQ?B)BF>?/CQG
MP06=2NFN]>C^[NG
M27F@%J                           #U72WI?O3K/O3$V%L#2KN=J.57$
M7:Z:9FC&M^NNN8B>(X_7P;"L78(Z%Y?6[K]I==_#KJT/;%=.HYMZJB9MS73/
M>MT<^7,U4(Y]:M+'6 !6D
M                   \)UQZ>XO5+I3N38^51%4:C@W:;<NSG:/E7,2[37'$SW*II[WQ3PR3D;OI)>Q1K.YLVYUXZ4
MZ17EYU%N*=:T['H]]=HIC]]IICSF([TSX>//FNLU\LZ2KN4Z]81AC2*O?W+5
M=-5%VU5-%RW5'%5%43Q,3'JEJU*                           &E55-%
M,UUU1%-,K_=A;;I\YKUW:
MUC3=4N?@ZE@T^YW:9^*)[L_/"//K=Z++K'T\HOZKTTU&WO'3J>]73C_@Y5%/
MJCRII_6F*$Z;E5*,T1+&SW%MG=&S\VO3-W;R*:8IXCYU]-Z)W53;F-D4(N1ZH^CV[3/2R
MU=R[VV+6X<*W,S%_3*XKKFG^JIFJI;QJND:YH&57A;AT'4M*OVYXJHS<6Y9X
MGXZXCE;%43LA,3&[BC;3N]//\ N1/"X/I/V ^TIU<[
ME_%VM&WL*>)JR=4F+=41/LMU335+DS$;NQ$SLMUJJIICFJ8B/A=[M#8N^.H6
MHV](V+M34=:R[M7=IHQ[7A\]57$?K2B]&O1+=,=MQ:U#J[KF1NG+B(JG&M3[
MEC15[)HJBKGZ5Z>PNEW3_IAIE.C["VII^BXM-,4S1BV8H[W$><\>)XY%4>RN9B:?HE(IT?[-G1_H?I-
MK3-B[/PL:Y;IB*\JNCOWKDQ_&FJJ9XGXE4!15755NMBF*3R 02
M        'QR\3%S\>O$S<:W?LW8FFNWT/Z,#I-U9SK^Y
M=AYES9VM7IFJJ,:GG'NUSYS5%45<>/LB%E6__1C=IK:&57:V]IN%N?&HF>[=
MPZIIF8^'O]WQ35BRF[52A-$2@*N=BWM36[E5NKI'J7-,\3Q5;_;;?O,.U)^:
M34_TK?[:?;B/8<1[$^_GT<[J$!/WF':D_-)J?Z5O]L^\P[4GYI-3_2M_MI]N
M(]AQ'L._GT.ZA 3]YAVI/S2:G^E;_;/O,.U)^:34_P!*W^VGVXCV'$>P[^?0
M[J$!/WF':D_-)J?Z5O\ ;/O,.U)^:34_TK?[:?;B/8<1[#OY]#NH0$_>8=J3
M\TFI_I6_VS[S#M2?FDU/]*W^VGVXCV'$>P[^?0[J$!/WF':D_-)J?Z5O]L^\
MP[4GYI-3_2M_MI]N(]AQ'L._GT.ZA 3]YAVI/S2:G^E;_;/O,.U)^:34_P!*
MW^VGVXCV'$>P[^?0[J$!/WF':D_-)J?Z5O\ ;/O,.U)^:34_TK?[:?;B/8<1
M[#OY]#NH0$_>8=J3\TFI_I6_VS[S#M2?FDU/]*W^VGVXCV'$>P[^?0[J$!/W
MF':D_-)J?Z5O]L^\P[4GYI-3_2M_MI]N(]AQ'L._GT.ZA 3]YAVI/S2:G^E;
M_;EG9[V]1H>P=OV+-Z8C[HS:
MZ>]?OU?RJJIYX^*.(53%=5RJK=**8I $$@                 !\=C6LBQ=IFFNW/PK?[9]YAVI/S2:G^E;_;3[<1[#B/8GW\^CG=
M0@)^\P[4GYI-3_2M_MGWF':D_-)J?Z5O]M/MQ'L.(]AW\^AW4("?O,.U)^:3
M4_TK?[9]YAVI/S2:G^E;_;3[<1[#B/8=_/H=U" G[S#M2?FDU/\ 2M_MGWF'
M:D_-)J?Z5O\ ;3[<1[#B/8=_/H=U" G[S#M2?FDU/]*W^V?>8=J3\TFI_I6_
MVT^W$>PXCV'?SZ'=0@)^\P[4GYI-3_2M_MGWF':D_-)J?Z5O]M/MQ'L.(]AW
M\^AW4("?O,.U)^:34_TK?[9]YAVI/S2:G^E;_;3[<1[#B/8=_/H=U" G[S#M
M2?FDU/\ 2M_MGWF':D_-)J?Z5O\ ;3[<1[#B/8=_/H=U" G[S#M2?FDU/]*W
M^V?>8=J3\TFI_I6_VT^W$>PXCV'?SZ'=0@)^\P[4GYI-3_2M_MGWF':D_-)J
M?Z5O]M/MQ'L.(]AW\^AW4("?O,.U)^:34_TK?[9]YAVI/S2:G^E;_;3[<1[#
MB/8=_/H=U" G[S#M2?FDU/\ 2M_MGWF':D_-)J?Z5O\ ;3[<1[#B/8=_/H=U
M" G[S#M2?FDU/]*W^V?>8=J3\T>I_I6_VT^W$>PXCV'?SZ'=0@\V/Z.7M3;P
MR;=&=M&SH.-J.,6U5Y^$<4S/'P\KZQ"J[54[%$0^.'A8FGXMK"P<:WCX]FF*+=NW3%---,
M>J(A]@5I@                                   .BWCLC:F_P#0\C;N
M\-"Q-4T_*HFBY9OV^]'$^R?.)^)'WUN]$;I&IY^5KW13=W[DS[/1]=JS:N1713T^JU2Q1,Q%_$KI[M7Q=ZJ
M)_4\Y]YAVI/S1ZG^E;_;3[M.(]BSOZD.ZA 3]YAVI/S2:G^E;_;/O,.U)^:3
M4_TK?[:?;B/8<1['>_GT.ZA 3]YAVI/S2:G^E;_;/O,.U)^:34_TK?[:?;B/
M8<1[#OY]#NH0$_>8=J3\TFI_I6_VS[S#M2?FDU/]*W^VGVXCV'$>P[^?0[J$
M!/WF':D_-)J?Z5O]L^\P[4GYI-3_ $K?[:?;B/8<1[#OY]#NH0$_>8=J3\TF
MI_I6_P!L^\P[4GYI-3_2M_MI]N(]AQ'L._GT.ZA 3]YAVI/S2:G^E;_;/O,.
MU)^:34_TK?[:?;B/8<1[#OY]#NH0$_>8=J3\TFI_I6_VS[S#M2?FDU/]*W^V
MGVXCV'$>P[^?0[J$!/WF':D_-)J?Z5O]L^\P[4GYI-3_ $K?[:?;B/8<1[#O
MY]#NH0$_>8=J3\TFI_I6_P!L^\P[4GYI-3_2M_MI]N(]AQ'L._GT.ZA 3]YA
MVI/S2:G^E;_;/O,.U)^:34_TK?[:?;B/8<1[#OY]#NH0$_>8=J3\TFI_I6_V
MS[S#M2?FDU/]*W^VGVXCV'$>P[^?0[J$!/WF':D_-)J?Z5O]L^\P[4GYI-3_
M $K?[:?;B/8<1[#OY]#NH0%4=BWM37+E-JGI'J7-<\1S5;_;57Z<>BZ[1N\[
M]N-V1@[4Q:I]_5D3-5R*?]GNQ5'/QIGN(]C5R;U4D6X6R=F?L$](.SM1;U:G
M%_RAW)Q$U:GG4Q551/KBBF.*8CGU\<^"YJ(B(XB.(AJ*IF9ZRG$:; #CH
M                               IIUI[//2SKUH%W0^H&V<;+JJIF+.7
M%/=O6:OY5-4<3\T^"I81.FQNBBZL^B,WQH5_(U#I'O6QJV%-4S;PM0B:;U-/
MJB)HIB/IE;IK/86[5VAY4XN1TKS+WC/%=FNW-,Q[?&M/0T6Q>JA7-N)0$_>8
M=J3\TFI_I6_VS[S#M2?FDU/]*W^VGVXCV'$>Q+OY]#NH0$_>8=J3\TFI_I6_
MVS[S#M2?FDU/]*W^VGVXCV'$>P[^?0[J$!/WF':D_-)J?Z5O]L^\P[4GYI-3
M_2M_MI]N(]AQ'L._GT.ZA 3]YAVI/S2:G^E;_;/O,.U)^:34_P!*W^VGVXCV
M'$>P[^?0[J$!/WF':D_-)J?Z5O\ ;/O,.U)^:34_TK?[:?;B/8<1[#OY]#NH
M0$_>8=J3\TFI_I6_VS[S#M2?FDU/]*W^VGVXCV'$>P[^?0[J$!/WF':D_-)J
M?Z5O]L^\P[4GYI-3_2M_MI]N(]AQ'L._GT.ZA 3]YAVI/S2:G^E;_;/O,.U)
M^:34_P!*W^VGVXCV'$>P[^?0[J$!/WF':D_-)J?Z5O\ ;/O,.U)^:34_TK?[
M:?;B/8<1[#OY]#NH0$_>8=J3\TFI_I6_VS[S#M2?FDU/]*W^VGVXCV'$>P[^
M?0[J$!/WF':D_-)J?Z5O]L^\P[4GYI-3_2M_MI]N(]AQ'L._GT.ZA 3]YAVI
M/S2:G^E;_;/O,.U)^:34_P!*W^VGVXCV'$>P[^?0[J$!/WF':D_-)J?Z5O\
M;WB/8<0=_/H=U"(_I3Z)?JEN>_8
MR^J6Z,7;V#S$W<;%B:LBJ/7'C3-/ZTCW0KLV]+.SYMZC0]A;?L6;TQ'W1G5T
M]Z_?JC^-55//'Q1Q"J8KJKJJW2BF*0!!(
M       >/Z@](^G'5/2[FD;[VCI^K6+D<3[M:XKCXJHXJCZ7L $;'6_T1NF9
M5S)U[HCNVK N3%5S]RLZ.;,S_)HF*9J^F5AG5#L\=:NC>H7<+?VP=1Q+-N?>
MYEJW[I9KCVQW9F8^>&0TX>K:/I>NX-W3=8P+.9BWJ>[]35'LF%U-ZJ-
MUB/9S77XS\RZF[3*
MN:)A9*/5;UZ3]4NG677A[TZ?ZYITVZIIF[]Q7:[7A_MQ3W>/AY>2B]:F>[[I
M3WO9,^/T+-=4&\                    &VF[175[G:GW2N?"**/?53/LB(
M\9!N%1>G'9VZW]5\JUC;-Z<:O=MWIB*U'/K[U<1'ZUY'2+T1&[L^]
M9U'K+O:QAV(F)KT_38_TDQZX]TBJJG]2,UTT[RE%,SLCTQK5_-R*<3!Q[V3?
MKGBFW9MS75,^SP7*=#/1]=H+K3>/;"
M5SI!V..S]T3IMWMG;$P_N^WQ5]WY5%-S([WM[\1"M<1$1Q$<1"FJ_P#PK(M^
MJU#L^^CEZ']%/<=6U7!G=6NT<53F:A3S%%?K[M,<4S'/MA=5B8>)@6*,7!Q;
M6/9HCBFW:HBFF(^"(?8435-6ZR(B-@!QT                  48Z_]DSH_
MVB=)JQ=YZ!:M:C31--C4\:GN7[4^WP\*OGY5G'8F8ZP3&J)'JAZ)+JCMJJ]F
M=,]WXFX,3O3-K&RXFG(B/5'O:8I_6H)J_87[5VBY'W/E=*8=J3
M\TFI_I6_VS[S#M2?FDU/]*W^VGVXCV'$>P[^?0[J$!/WF':D_-)J?Z5O]L^\
MP[4GYI-3_2M_MI]N(]AQ'L._GT.ZA 3]YAVI/S2:G^E;_;/O,.U)^:34_P!*
MW^VGVXCV'$>P[^?0[J$!/WF':D_-)J?Z5O\ ;/O,.U)^:34_TK?[:?;B/8<1
M[#OY]#NH0$_>8=J3\TFI_I6_VS[S#M2?FDU/]*W^VGVXCV'$>P[^?0[J$!/W
MF':D_-)J?Z5O]L^\P[4GYI-3_2M_MI]N(]AQ'L._GT.ZA 3]YAVI/S2:G^E;
M_;/O,.U)^:34_P!*W^VGVXCV'$>P[^?0[J$!/WF':D_-)J?Z5O\ ;/O,.U)^
M:34_TK?[:?;B/8<1[#OY]#NH0$_>8=J7F(_S1ZGXSQ^%;_;5%Z?>C/[3N\\B
MW1KFC8FV<:Y,QJY-^H[N%GG9H]&UTHZ(95G<^[+G^5
MVX[?%=%_+I_T6/7[:*8B(G_>B?->#1;HM41;M44T44QQ%-,<1$?$W"J:IJZR
MG$1&P XZ                I=UW[.73'M#;9KV[O[0[5ZN(F]HBG]:603IK
MJIV1FF)W09YGHZ.UUC9%5FST]C(HIGPN47:>)^FIZ7:WHP.T[KUVBC5L+3-$
MIJX[U6555/=_1Y33B??5(]W"-SIMZ'O0L/)MYO5'J-DZE3'%4XF#3$6^?9S5
M1%7'SKQ^F792Z#])L>S;VCT]TRU?M4Q$Y%VB;M=4^V>_,_J5<%S1:HI\J:*8IB/FA] 12
M                                                ?')Q,3-M38S,
M6U?MU>=%VB*J9^:5"^L'8D[/O63'O5:[LK$PM0NQ/&=A4S;N43[8B)BF?GA7
MH=B9C9R8B=T5/5#T0V\-'KR,_I3OZQJ6-$S-O"U*F8N1'JB)HHX^F5LVZNQ'
MVI]H7:Z-0Z4Y^513,\5XU5N8JCVQS6GO:<1/G"R+U4(3;B6/5@=F?M%ZGE1A
MXW1O7XN3/'-=-N(_OJ]](_1=]?M_Y=JO?C
M^\KVAWJN:Z<'+CO8_P %,3%-5?ZUDG5CL8=HOH_>NW-?C"?KJ=V0NSWUY]O>F)6A]5/1!:
M#FU7\WI'OS(TR>)FUB:C$WZ9GU1S'=B(6Q>IG=7-N81@BX[J5Z/CM.],;5S(
MR=IVM>Q:.9B]IMVFNJ8_JZ9JJ6_ZSM[<^V\FO#W)M?5]*NVYXKC+PKMJF)^.
MJF(6Q5$[(3$QNX(V4WK-<\47:*I]D51+>ZX                      #;7
M?\ 5@6;G'%_4I^YJ8CV\7.[RNKZ7>B!U^]7:S>K?4*U11S$UX>FT335
MQ[._WJH_4A-=-.\I13,HY8KIJKBW1WJZZIXBFBF:IGYH5+Z;=FSKKU;S+>-L
M?IUJ>19KF/\ YN]1%NU3'M]],3^I,=TN[!/9GZ5U6\K2=@8VHYU$1_\ -ZE3
M1>N=Z/7$]V%P&'A8FGX]&)@X]NQ9MQW:**(XBF/9"JJ_Z)Q:]48?2/T0NI9T
MXVJ]9-^>XVZHBJO3M,I\I]E4UT_5*^;I/V4^AG1K#M6=G;$T^WD44Q%65>HF
M[SSTLZ]:!EC5
ML+O3-O"U")IO4QZHB::8CZ96ZZUV%>U;H>5.+D=*\R_X\4UV:[8=J3\TFI_
MI6_VS[S#M2?FDU/]*W^VGVXCV'$>P[^?0[J$!/WF':D_-)J?Z5O]L^\P[4GY
MI-3_ $K?[:?;B/8<1[#OY]#NH0$_>8=J3\TFI_I6_P!L^\P[4GYI-3_2M_MI
M]N(]AQ'L._GT.ZA 3]YAVI/S2:G^E;_;/O,.U)^:34_TK?[:?;B/8<1[#OY]
M#NH0$_>8=J3\TFI_I6_VS[S#M2?FDU/]*W^VGVXCV'$>P[^?0[J$!/WF':D_
M-)J?Z5O]L^\P[4GYI-3_ $K?[:?;B/8<1[#OY]#NH0$_>8=J3\TFI_I6_P!L
M^\P[4GYI-3_2M_MI]N(]AQ'L._GT.ZA 3]YAVI/S2:G^E;_;/O,.U)^:34_T
MK?[:?;B/8<1[#OY]#NH0$_>8=J3\TFI_I6_VS[S#M2?FDU/]*W^VGVXCV'$>
MP[^?0[J$!/WF':D_-)J?Z5O]L^\P[4GYI-3_ $K?[:?;B/8<1[#OY]#NH0$_
M>8=J3\TFI_I6_P!MR=.[$':LU3*IQ,?I-GT55?QKE=N*8_YT]O$>PX@[^?0[
MJ$2'2GT2_5+<]^QE]4MT8NWL#O1-W&Q8FK)F/7'C3-/ZTCO0KLV]*^SWM^C1
M=@[>L6+TTQ&3G5T]Z_D5?RJJIYX\H\(XA5,5U5U5;I13%( @D
M                         -MRW;NT56[M%-=%4<54U1S$Q\,-P"TSM(>C
MGZ.==;M[7]&M3M3<5<3,YF#3$47J_;73/,?1"Q#J+Z+SM(;-R+E.UK6#NK&I
MF>Y7C533]W8Y^)-$+*;M5*$T1* JYV+>U-;N56ZND>I8=J3\TFI_I6_VS[S#M2?FDU/]
M*W^VGVXCV'$>P[^?0[J$!/WF':D_-)J?Z5O]L^\P[4GYI-3_ $K?[:?;B/8<
M1[#OY]#NH0$_>8=J3\TFI_I6_P!L^\P[4GYI-3_2M_MI]N(]AQ'L._GT.ZA
M3]YAVI/S2:G^E;_;/O,.U)^:34_TK?[:?;B/8<1[#OY]#NH0$_>8=J3\TFI_
MI6_VS[S#M2?FDU/]*W^VGVXCV'$>P[^?0[J$!/WF':D_-)J?Z5O]L^\P[4GY
MI-3_ $K?[:?;B/8<1[#OY]#NH0$_>8=J3\TFI_I6_P!L^\P[4GYI-3_2M_MI
M]N(]AQ'L._GT.ZA 3]YAVI/S2:G^E;_;/O,.U)^:34_TK?[:?;B/8<1[#OY]
M#NH0$_>8=J3\TFI_I6_VS[S#M2?FDU/]*W^VGVXCV'$>P[^?0[J$!/WF':D_
M-)J?Z5O]L^\P[4GYI-3_ $K?[:?;B/8<1[#OY]#NH0$_>8=J3\TFI_I6_P!L
M^\P[4GYI-3_2M_MI]N(]AQ'L._GT.ZA 3]YAVI/S2:G^E;_;/O,.U)^:34_T
MK?[:?;B/8<1[#OY]#NH06[1]'QVJ]UY-NW7L"K2;%4\57\RNGNT_HU3/ZEX/
M0+T3.V]MZEB[FZU[CIW!?LS3/HNW],Q\#!Q:(MVK%BB*:::8CB/)V *DP
M &DQ$QQ+QV\NCO3#?^+R 68]1/16=G'
M>5ZO+T&G4]MY%7CSC7Z[E'/]&:XCYEM6_P#T1'4S3*KMWIWOO"U6S3S-%O.I
MBQ7,>SWL5EV7J./:_^KIU-=[F/;^#"
MC^X-E;UVK=FQN39^KZ;7'/,9&/-/#)#JHHKCNUTQ5'LF.75ZCM3;&KV:[&I[
M?T_)HKCBJ+F/1//S\)Q?GSA&;7HQL(SL3OS:F]3%<>=,^SQN>FO]V.E.BWJKGG7%%5,_\ +5"D^X_1E=EK7:JJ\3:56E55<\SBW*O/
M_>F4XOQYHS;E"D)9-=]$!T7R>]7H6\]?PZZIYXKFU-,?%[QX34_0V45US.D=
M8LFU3ZJ;UN)C]5M+O:7.[J1K"0?.]#KOZQ%4^IR5>BQ<7N_\ PE.T%_\ >&U_T+__ (?.
MWZ)CM"UW;ENK=.V:*:..*YHO<5?%X'>4^KG+*R87NQZ)3M S/$[PVO$?U=__
M ,.YPO1 ]6KURFG.ZDZ'9HF.:JJ+5WF)_1.\I]3DJ6$B17"]#;N2Y$3J766Q
M1[8L6JO\;;V&A^ATV59FC_*#J=JV3$3[[W&FB.?IH<[VEWDJ1=V^DFL^Y5<<7LNQ5;M\>WF(E.WH/3+I[M>U%G0=G:5AT1'$11C4SQ]/+T=
MG'Q\>GNV+%NW'LHIB(_4A-_TA*+7JB!Z?^B=Z[;@FUD;VU_2]!QZ^._1:K]U
MNT_[M5,?6N;Z=>B6Z$[9O6<_>6L:MN7)IB)KHKKJL6YJ^*FN8_4OG$)NU2E%
M$0\!L3H-TBZ;8E&)M'8.C8<6^.+OW';JN^'^W-/>_6]]3333$4TQ$1'A$1ZF
MHKUU3V
M
M
M
M                                                  ==K&W-O[AL
M3C:]H>!J-J8XFC*QJ+L?15$J =3/1^]FGJ9%Z]G;)MZ9EW>9B_IU4X\4S/K[
MM'=A<@.Q,QLY,1*-/?WH>=,MT5WNF/4G+M5>,TXV?9B:?TYJJG]2W+>WHTNU
M5M&Y5^YNW<#<%FF9]]A7JZJICXHH3Y?A5W,28H^:7@\F]&%7[GG45XU7EW;M/=EDKY&F:;F1,9>GXUZ)_G+5-7UP
M\;N+H1T>W7577N'IWHV9-?X4U6.[S^CPG%_UA'NF.U;O6KLNY$T_%S5PI?KWHE.SQJDU7-.U77--J_BTV:
MKI1[NI$")/-9]#CMJ[-7[A=5=2QH_B^ZTT3Q]%MY;-]#=NBW
M$SIW6/&K\?"+UJKGCYK:7>T^KG)4CL%^F7Z(/J[9KN4X?4?0KM-/X%5=J[S5
M\?O74?\ PE.T%_\ >&U_^'?_ /#O>4^KG)5Z+(A>S>]$SVA;7<[FZ=LW.]5Q
M/=HO>]CVSS#Z3Z)3M!?_ 'AM?]"__P"#O*?4Y961"^G#]$7UOO435F[\VY9J
MB?"*+=[B8^AZ'"]#GOB]W?W0ZNZ=:YCF?2I'J)+](]#=
M@VZHG7.KN9?CUQ9HICZ[:H&@>B)Z$X'77-K#BK(KC^+;CF4XNU?1S=E?;%5%VKI]8U&[1_
M'RJZYF?HJB%6]N=GSHKM*::MN]-M%PYH\IILS5Q^E,HS?CRA*+L>
M^JZ+>TNF>OZC-SPIJMXDS3\\JY;&]&?VJ-X7*9U70,#;MFKB9JS;U5-<1\4T
M>::S&TG2\*(C#TW%L1'E[G9II^J'+0F_/DE%J/-&YT_]#WMR*+>1U.ZBYV5<
MCB:L7"M111S[._35$_J74],.Q!VNVMLY&BY5V>9O8.171$?%135$+>-\^AXQ[-%RYTWZG9/
M/'O,?/QZ>[S\-C)[5.UJJOW+T;3-?HCUXF17,S'
MQ10H[NGLU=H#9-5<;FZ2[AQJ;?X5VG$JFW],\,A5\+^%A9,<9.)9NQ/JKMQ5
M]:<7Y\T9MPQK,[%S]+KJMZIIV5AU4SQ5%ZWW>'%M9N+>\+5^BKXI9'6O=+.G
M.YZ.YKNR])S*>./?XU,?5PIQN3L3]F+=%J;>H=)=(IFKQFJW[I3/ZJDXOQYP
MCW4H$N8]HF=U[T6W9AUCO?<6D9FE][R^Y;G/'Z7*GVL^A]Z1W^9T/?>O8WGQ
M[I[E/'T4)1>I<[NI%&))M2]#7557-6D]8[]NGU4WK<3]5MT6;Z'/?=GO?<'5
MW3;L1'-/NEJOF9]GA0[WM/JYR5(]A?5F>B*ZVV;45X6_=NW;G/'=KMWN./T7
M"_\ A*=H+_[PVO\ H7__  [WE/JYR5+(A>Q7Z)GM"TWZ+4;IVS535',W(HO<
M4_'X#Z'?J+?HHJU#JOI5BJJ??Q;M7/"/@YH.\I]3DJ]$?HDAPO0UYG?B
M=2ZRUU4\^,6;7J^>V]CHOH>>F=GC]WNH>MY/C[[W*+<<_30YWM+O)4BMYCVO
MG=R;%GQNW::?C3*Z%Z*CLTZ1-,YMK4]4X\XR:Z8Y_1B%3=L]@_LM;7F*L/I3
MIEZJG^->JN5?]2,WJ7>[E _BU5Y]7=T^Q=RIGU6:>\]SMGH=UFWE513MCIAN
M'/[_ !Q5;Q)FGYY3Y;?Z*])]K=W]P-@:/A]WR[N/$_WN7J\?2],Q/]5T[%L\
M?S=FFGZH1F_Z0EW2$':?HY.UENF[1&1LO'T6S7QQ7G7:Z)B)]L=R5?-B^A^W
M1ES17U%ZE6\.CPFNUI]FF[S\'>F:9A*7Y>$-4)O52E%N%FW3_P!%?V:]G7*<
MC6,;4]PWJ>)[V5DW**>?;W>_,+C]G=#>DFPL>C&VOT_T/#BCRN1@VIN?I=WE
M[H0FJ9WE*(B&VBBBU1%NW13133'$4TQQ$-P(N@
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M
M                /C=R\6Q$S?R;5OC^57$.3,1UEV(FKI#[#S&J]3=A:)WH
MU/=	FGSB:YGZHEX/6>U3TLTN:HQ]0N9]5/JL4_M_33_5&O
MRW>7P?#V;8__ (;#UU?TSI\]E8Q;%JW;3P**IIT7:5^]'JF],1]53R&J]L#?
M^;S&G:1@8=,^4Q-4U1]/+UW$]H.0X?:[-7NB7M&%[,>(\3I-5J*(_FJB/O,K
MS&E55-$355,1$>N5@>J=H;JWJL54W-S5V:)\J;=%/A_RO+YF_P#?6H3,YF[,
M^Y%7G$5]V/U/!7^U7+Z/V-FJKWS$?J]AP_8YF-<:W\113[HJJ_1(KE;@T3!C
MG,U7&LQ'\NY$.DS.JG3O B?NG>&ETS'\7[HIY^M'?=U'4K\S-_4\NN9\^]?J
MG_%QZN]7/-=RNKXZYEXB]VKWI_8X>(]\S/Y:/-V.QK#1^WQ54^ZF(_.97\YO
M:)Z2X,S%W=-BOC^;JIJ_Q=1D]JKI'8C_ $>J9-V?]BS$_P"*QON4?R8GXVO=
MICRICZ'C+G:CFM7@HHCX3^KRUKLBR2CQW+D_&(^R\S([8/3>WX6<;4KOQ8__
M .EUE_ME[3IC_P"7T+-KGG^-3,+1QBK[2<]JVJICW4M]OLMXVCI%54Q?VK>HCU3
M37,_X.?C]LK9]44_=.B9UN?7W:)JX6B"^CM%SZG>Y$_TPHK[,>&Z]K54>ZJ?
MOJO/Q>U[TSOS'N]O4;/,_P ;'_\ TNXQ^U)T@OQ'>UN[:F?YRW$?XK&.(GSA
MIW*)\Z8^ALM=IV.*)^$_JPW>R;(*_#-RG^J/O"0/ Z\]*M0F(M;MPZ.?Y
MRY33_B]!A]0=D9_'W%NG3;W/\B_3*-SN4^J./B\&^B[?M?O61>H_HW*H_P 7
MD;/:MC*?VMBF?=,Q^KQ=_L[Y17W:OKAY>QVKX6K]O
MAZH]TQ/YQ#PF([&L5'7#XJF??3,?EJD5%C>D]JCJKI_$9>5CY\4_SM/=Y_1B
M'L]+[:.KVJ::-8VC9N3_ !JK%<_XU/.X;M'R/$=*ZJJ/?'Z:O7L5V5\0X?\
M9TTU_P"6J/OHNQ%!=%[8/3_.[M&IX.;@USYU5Q3-,?1,R]]HO7#I?KM%-6'N
MS#BJJ>(HK[T3^N'L6$XDRG&_L<13/QTGZZ/5\;PIG>7_ /$86N(]>69CYQJ]
MX.%B:SI.?;B[AZEC7J:O*:;D3RYD3$QS$\O,TUTUQK3.KP-=%5$Z51I+4!)$
M
M
M
M
M
M
M
M
M
M
M
M
M!MJKIHIFJNJ(B/&9D&X>)W/UEZ<;1BJ-9W/B4W:/.S17$U_1RI#NKME:+C=^
MUM+0KV;/C%-S(_T43K/RC5[)EG".=9OI.%P]
M4Q/G,:1\YTA-%/C/NM^FCZY60[E[375/U76\[*JJ\_=,BNJ/HF7I&/[4\':F:<':F
MOVSTC[OH&6]CV-N_BQ]^FCV4QS3\^D?FOEW+VD.ENVXKHN:U]UWJ?XF/1-<3
M_O4\PICK_;/PYBJC;&V+U<^J[?N1$?HS$2M:[E$3SW8Y^)J]-QO:3G6*UBS-
M-N/9'7YSK]GO6 [+,@P<1-ZFJ[5_-.D?*-/S5;U[M1]6-8KG[DS\?3J/98HF
M)^GO/!:QOW>VOS5.L;HU#)[WG37=F8="/4\7GF8X[_B+]57QG3Y/E,:_/=MKHIN5=^YS75[:IYENXX!XN9F=WEM0!QP
M            ;:K5%<\U4Q,^UN#71V)TV<[3-?UW1:XNZ3K.7B51Y3:NK>A5413N.K-M4?Q,KFOG]<*;C?AMU=,3\-)>FX_LQX>QVLT6YMS_
M "ST^4ZPDMTG=NV=3YGIW%^-?2>D_*7S[
M-.#,\RC6<3AZN6/.G\4?.-50!LMW;=ZBFY:KBJFJ.8F)\);WL.[U>8TZ2
M
M
M
M
M
M
M
M
M
M
M
M                                               #SFZ.H>SMG8]=
M_7]=Q<>:/.W[I3-S]'GE0G>?;'TVU%S%V1H]S(N1/%.1D>]I_1F/'Z7@\TXD
MRS)XG^UW8B?2.L_*'L.3\*9OGL_^RL3-/\4]*?G/1M8]
M<_ZOC5311Q[)CF>7A^[$US9EQ5FV:],1>G3TCI'RA]-RKA')GF]
M9_%/SG7Z-;DU7:YN7JZ[E4^L?*7KN;<)9-G43_ &NQ3-7\4?AJ^<::_'5(?M#J_L#>
MMJBK1]P8\W:H\;-RKN54S[/'A[.FJFNF*J*HJB?*8GF$7MN:[-ZG(L7*K5VB
M>::Z)XJCYU4=D=HWJ3LVNW8NZE.JX-'$39R9FJJ*?@JF?#Z'TK*.U*W7I;S.
MUR_S4[?&)_5\JSKL@N4:W,IO3/].>(5@Q\BQE6:X.Y%
M<>S[QO#Y'F>3X_)KO-
M
M
M
M
M
M                 :3,1XS(-1TFK[TVKH-,U:KKV%8X\XJO4\_1YO+WNOW2
MBQ^BJGZX>JT[G:QAWXJ\HHO4S,_-RE8S#
M"8K]A=IJ]TQ*&(RS&X3_ (BS53[Z9C\X=D V,(
M
M
M
M
M
M                              #@ZKK>DZ)C59>K:A8Q;5$R+M-NBB.:JJIXB(4!W_VN-LZ)
M5O6+J!OR[7^[&MW;>+5/,8MF>[;I^#V
M_K>B9SVA95EFMNQ/>U^E.WQG]-7T;(NS'.,VTN8F.YMSYU>+X4[_ #T7:[Z[
M2O3K9\7,;&U"-4S:?"+.-Q5Q/P^,<+>=[]J3J#NJ+N)I/N>CX=?A$6O?7)CX
MYCF/FE1N(B)Y\YGSF9YEJ^4YQQ[F^:ZT4U]W1/E3T^<[OL>2=G629-I7-OO:
MX_>KZ_*G;\WVS<[4-3O59.IY^1EW:IYFJ]::
M8ICEIC2 !%T
M  !I-,3,3QXQY3'G#WNP.MN_>GEZF-/U.YFX<3[[%R:IKB8]D3/,Q\SP8UX/
M'8G+[L7L+7--4><2RXW X;,;,V,7;BNB?*8U_P#X^"^?IEVD-E[^BU@9UZG2
MM5KB(G'O3Q35/LIGSE5NFJFJ(JIF)B?7"+V)FFJ+E%4TUTSS353/$Q*MG27M
M-;CV55:TC=E=S5=*B8IBY,_Z6S3\'P?,^O<.=I5-R8P^;QI/\/O'R?%.*
M.RB:(JQ61SK_ /ZYW_IGS]T_->N.EVKN_0-YZ7:U;;^H6LFS<.Z?6[5VB_1%RU,33.TQL^)WK-S#W)M7:9IJCI,3TF !8K
M
M
M
M
M
M                    =9N3<&G;7T3+UW5+]-K'Q+KBW;C6J9TB/69<;=^\MO['T>YK>XLZC&Q[<3QS,=ZN?93'K
ME:/U*[4N[MT7[V!M&J=)TV9FF+D<^[5Q[>?":7A>JO5/6NJ6X+NHYEZNWIUN
MJ8Q,7GWM-/JF8]<^3Q3X)Q7Q]B<^WY/KG9>9JE^K)U/,O9=VJ>9JO5S5//SOA[E;C^)'
MT-P^;U5U5SK5.LOJ-,IFV*J+.?ET:OBQ,5?\ 8?:EV#NNJWAZM4>E77Y3O#TK.>S[(\YB:IM=W7_%1T^<;3\DGV)F8N?CT96%D6[]F
MY'--=NJ*J9CX)A]D>&Q.K^^^GN137HVK7+V-$QWL6_5WJ)CVU'>JKN5<1$(UUTVZ9KKG2(\Y3MVZ[M4441K,[1&[GNLU[XD9=WQI^[+OA;CX:?;\\+;=S;QW
M1O'-KSMQZQD95=<\]R:IBBGX(ICP_4^=9[VCX#+M;6"CO:_7]V/CY_#YOJ'#
MW99F.9:7LQGN;?IO7/P\OC\ER74/M?X&-%W3^G^!5DWHYI^ZK]/%$?#$3'C]
M*W+=F_-W;XR:LG8M15,6J?BIYX=#$1$<1' ^/YSQ1F>>5?\ N;GX
M?X8Z4_+]7V_(^$\IX>IC^QVHYOXIZU?/R^&C2(B(XB.(:@]>>Q@
M                                                    /3]/NHVY
MNFNKTZGM[,JIM551[OC53/N=VGU^'ES\*^'I5U;V[U1T>G,TZ[39S;<<9&)5
M5[^W/Q>Z\*<8XGA^
M[%JY/-8G>/3VQ^GF]&XQX(PO$]F;MN(HQ$1TJ]?95Z^_>$E@\3THZGZ1U/VW
M;U;!KBC)MQ%&58Y]];K_ /$\/;/T7A<59QMFG$6*M::HUB7Y=QN#OY?B*\+B
M:>6NF=)B0!H90
M
M
M
M
M                                          !:KVP=_P!VYD86PM.R
M.[1$>[YD4SY^,Q%,_JE=35,4Q,S/DCHZL:[=W)U(U[5+M7,3DS11_1B(C_!\
M\[2G
MZ5      &DQS\<>,3#4!5;I?VB=Y=/KMO"U"_6O2=X]T_9\]XH[.\NS^)OV(BU>]8CI/^:/O'
M7WI-Q;CT?[5&!K$V= Z@U48>9/%NWF1$1;N?TO**97%6+]G*LT9&/8F'W?*,ZP6=V._P=>L><><>^'YVSOA_'\/8C^SXZCEGRGRGVQ/F^@#R
MKPH
M
M
M
M
M                                         ^61DX^)9JR,J_;LVJ(Y
MJKKJBFF(^.7@.I77#9?3:Q7:S\ZG)U'N_P"CQ+,Q57,_[4><0M&ZE==][]1[
MURQ>S*].TR9]YBX]O/=_ACR]\^7YO>N&> ,S
MXCF+NG=V?XJO/_+'G^7M7"]4.U1MK:TWM)VG;C5M1IYCW2F?]#;GX9_C?-*U
M?>?4/=^_\VZX7>GQFC^3'T3+ZKV;<1U8;$?W5?G\%
M?A]E7I\?S?(NU3ABG&X3^^,/'^);Z5^VGU]]/Y>YKWXQM,RJGF:\BY,S_O2
MDNUBS3D:7E6*HYBNW,3"-'4[DG:%W/TYO6]-U.NYJ>C3,1
M-NN>:[,>VF?_ #*DXWY=F>*RF_&(PE#SC#SA<;;BNB?7R]
ML3Y3[821[-WSMO?>DVM7V[J-O(M7(YJIB??43ZXF/:] C;V5OO8OA^9Q6$UN8?U_>I_S1Z>WYZ*I@/?7S
M<
M
M
M
M
M                                 !3'JOUXVGTTQ:L>J_3G:K7'^BQ;
M-43,3_M3'/=^=DQV/PV6V9Q&*KBFF/.?_.K=EV6XO-L13A<'1-=<^4??TCVO
M>ZYN#1]MX%S4M:U"SB8]JF:JJ[E7"UCJSVK=1U6J_H?3VF<;%GFBK/JCW]?J
MGNQX^'S*/]0>IV[>I6H59FXL^J<>*IFSB43,6[
MJN7*IJF9^=\@?,JJIJG6J=9?5HB*8TC8 <
M                                            !WFQ]RY6S]W:9N#$
MN31./?IBYQ/G1,\3^J9=&TJCFF878>]7AKM-ZW.DTS$Q\%=^S1B;55F[&M-4
M3$Q[)Z2DXTC4\?6=+Q=5Q*HJLY5JF[1,>R8YAS%&>RONV=Q=-K.GY%R:LC2[
MDV*N9Y]Y'A3]2LS]8Y3CZE;]U[3ZZ
M.[[EEU<1\$Q$_P"*218UVI-N5:)U1OY\6^[;U2U%^GP\.?P?^E\P[4L)-W+;
M6(C]RKK[IC]8A]=['\;%G-+V%J_YE'3WTSK^4RI" ^#/T0            /K
MAYF9IV7:S].RKF-DV:HJMW;=4TU4S\-F^%NQF3Q%%Z?95Y<3]*X^W<2KCT5[26J[)KL[>W?B](<#1-=TK<6G6=4T;-M9
M6->IBJFNBKGZ?8Y[[+173U9?UJ[0NM=1,FYH^W[EW3]$M533[V>*\B/;5\'Q<>3U
MKB/B?!\.6>>]/-7/AIC>?TCVO;.%N$,=Q3?Y;,R/6?9\U0>M/:D
MBU5?VSTXO47:O&W>U#PFFGU3%'GS\?@MARLK*S\JYFY^3=R,B[5-5=RY5-54
MS/PR^41$1Q#5^>,\X@QN?W^^Q573RIC:/='W?IS(.',!PWA^XP5'7SJGQ5>^
M?ML /!O.@
M                        *_=CW!O//VY/JKJB$AE-45TQ73Y51S#]!=F6-_M&438F>MNJ
M?E/7\]7YM[6\!&&SJG$TQTN41/QCI^6C4!]&?+
M
M
M
M
M
M      !;EVR-JW,_;FF;HQZ)JKT^[W+O$>5N8GS^>I<:\[U!VU8W;L[5-"OT
MQ,9./5%/AS[Z/&/UP\+Q#EW][99>PGG,=/?'6/J\_P +YK.2YO8QOE35&O\
MEGI/TE&\/MG:?E:3G9&E9M$TW\2Y59N1/GWH?%^4ZZ9HJFFK>'[%BJ*HBJF=
M8D 1=              >YZ7=7MT=+=0IJTS(JO:9VGV2O9Z<
M=4]K=3-*HS]#RZ8O1'^EQ:ZN+EN?ACSX^'A':[/;>Y=RJ/*7O/"W&V*R&J+%[\=GT\X_P OZ;/0>+^ L'Q+3-^UI;Q'E5Y5
M>RK]=X]J3 45Z,]H[1-_T6M%W#7:T[6_"F*)J][?GRYI^&?#PX]:M,3$QS$\
MQ+[_ );FF%S>Q&)PE?-3/SCV3'E+\UYMD^,R3$SA<=1--4?*?;$^<-0'D'C
M
M
M
M
M
M                     !T>\=X:)L?0[^OZ]E4V<>S3,Q$SXUU>JF(](B(6&]:^KFH=4MQW9L7JZ-$Q:YIQ+,3X5Q$
M_AU1[9\/H>J<6<3VN',+S1UNU>&/O/LA[IP7PC>XIQFE7X;-'CJ__6/;/TW?
M'J[UCU[JIJU/H]JK_Y?$B?"?955[9^;UJ?@_-N.QV(S*_5B<35S5U;R
M_4V P&&RS#TX7"41313M$?\ G6?60!D:P
M                                                  ')TO+KP-5P
M'^#Z[V47]+V(L>L1/RG3[OB_;+AHG"X7$>E55/SB)^S
MUX#[6^!
M
M
M
M
M                                   #28B8XEJ LF[5&PKFV=]?Y28M
MF:<'6([TS$>$7H\:OI[T**I .NG3^UU!V%FZ?1;BICGCY^(6
MW+5W'NW,:_3--VS75;KB?.*HGB?UP_.7:!DDY5FDWJ(_P[OXH]_G'S_-^I>S
M?/XSK)Z;5R?\2S^&?=^[/RZ?!M >B/H                #6BNY:N4WK-RJ
MW)IGX%QO1;M196ESC[9ZA7*K^//%NSG^NCV17\'Q0MQ:3$3'$QX2
M\QDV>XS(K\7\)5IZQY3[X>&SS(,!Q#AIPV.HUCRGSIGUB?\ R)\TG>GZC@ZK
MB6\[3LJWD6+L=ZBY;JB8F/FVCV
M?1ZEZ6P>I.UNHVETZEM[.IN3Q'NMFJ>+EN?7$QYOT'PUQ?@N(:(IIGEN^=,_
M;UA^:>+.!\?PQIMVW3C]/='R>[-
MV/=<^JF?'N^/%$_/W96NQ$1'$1Q#NM[:]D[HW?JVO95V:Z\K)JF.9YXICPCZ
MG2OROQ-G%>=YEKWU3Z3V7W)HS>NCUHG\X?+NURU%>145_PW
M(^L3"LX#[^_-8
M
M
M
M
M                                          #28B8F)CF)]2R7M/\
M36=G;PC<.G8_=TW5_?5=V/>T7?7'S^,KVWD.J>P\/J)LW.V]DT4^ZUT35CW)
MC\"Y$>$_KEZQQ=D5.?9;59IC\=/6GWQY?'9[?P1Q'/#>:T7ZY_PZOPUQ[)\_
MANCK'*U;2L[0M4RM%U*S5:R<.Y-NY35''DXK\P5T56ZIHKC28W?K6BNFY3%=
M$ZQ/6)]@ BZ                .VVMNO7]EZM:UK;FH7,7(M515-,5>\K^"
MJ/*74BRS>N8>N+MJJ8JC:8W0NVK=^B;5VF*J9Z3$]8F%[/1WM(:!OVU;TC<%
M5O3-:B(I[E4^\O3_ +,JTQ,3',3S$HOJ*Z[5RF]:N56[E$Q5373/$TS[5P?1
MOM1:CH%5C;V_[E>7@^%%K-\Z[<>7OO;'Q0^S\*]HM-WEPF;SI.T5^4_YO3WO
MA?&'9=5;YL;D<:QO-OSC_+Z^[?T7?CA:/K6EZ]@V]2TC-M96/=IBJFNW5%4>
M/MX\G-?6Z*Z;E,543K$OB==%5NJ:*XTF/*0!)$
M
M
M
M
M                                                    >,ZR9\Z=
MTRW#DQ5W9^X;E,3\,Q+V;QW6# G4NFFX<6FGO53@W9ICCSGNRP9KS?V"]R;\
ME7Y2\EDW)_>-CO-N>G7_ %0CLIF:N:I\YF9_6U:1$T\TS'$Q5,?K:OR/5O.K
M]J2 ..                                 ',>T :=ZG^5'TG>I_E1](
M[I+4:=ZG^5'TG>I_E1](:2U&G>I_E1])S$^4P&C4 <
M                    )\EYW9!Y_P VUWQ__>9^N5F,^2\[L@_DWN_VF?KE
M]"[,_P#^]Q_EJ?-^U;__ !V?\]/W5U ?H9^8@
M
M
M
M
M
M        %KO:QZ3U513U%T+%FJNGWFH4TQYQZJ_IF/H6NQ,51$Q/A*3G5=,Q
M-9T[(TO.M4W+&3;JMUTS'/A,(_\ K#TVR^F6\#X9VC\-?V2]_>N&C\%?B]E7K\?S?HCLMXJ_M^&_N?%5?XEN/P>VGT]]/Y
M>YXZ\,\;8S(*HM5_CL_PSY?Y9\O=L]%XL
MX#P'$M,WJ?\ #O\ E5$;_P"://W[I.1;AT=[4V#J_N&WNH%5&)FSQ1;S?_IW
M9\O'V3\RXNQD6,JU3?Q[M-RW7$54U4SS$P^^Y1G>"SNQ%_!UZ^L><>^'YNSS
MA_'\/8B4>/%<_\L+8XGGQA^5N)LIKR7,[N&JCIKK3[
M8G;]'[$X6SJWGV56<91/68TJ]E4=)_7W2 / O8               .8CSEMF
MNF/7S\4Q>'PT:WKE-/OF(_.7F1572NS'U:U&8^Z-(MX5
M,^N]5_XY>QTSL9[KR*8JU7;PW"&=XKP8>KXQI^;P&*XSR#!
M_M<51\)YORU6\M)F(\Y78:9V+=OT1SJVZ.FFGWU?IJ]?Q/:GP[8\%=5?NIG[Z+(:KUJG\*Y3'S
MM]OOW_WBU7=_H4\I!].Z&]+M,B/N;:>+S'KJFJKZY>@PMD;2T_C[DV]@6^/+
M_04S]RG&5:=]B*8]T3/Z/!W^V3 4_L,-7/OF(_+5'3A[:W)J''W'H&?
M=Y\N[8JEWN%TAZFZAQ]S[,U+B?778JICZDA=O2],L_O6G8U']&S3'^#D4T44
M>%-$1\4/*V>RC#1^VQ%4^Z(C]7AK_;+B9_886F/?5,_EHL'Q.SGU?RYCN[;H
MM1/KN7)IF/U.]PNR7U5RXYO3I^/X<^^O1,_4O='E+79AD]'CJKGXQ^CQ-[M=
MSRO]G1;I^$S^/'])S;78QVA33/NVX,VNKGSCF/\5Q0V4<$9#1MAX^/ZW*^] Z9<1_I,_\ X]7_ )5U%\<(9''_
M ,:GY,]7'/$56^,K^:BM/9+Z513%,XN9,Q'G]T5>+7[TSI3_ .DS/_PBI6D6
M_P#I7)?_ ,6C_3"K_P!99_\ _EW/]4J+?>F=*?\ TF9_^$5'WIG2G_TF9_\
MA%2M(?\ I7)?_P 6C_3#G_K+/_\ \NY_JE1;[TSI3_Z3,_\ PBIQKO9$Z87+
MDUT_=U$3Y1%^KP5R$:N%,DJWPM'R2IXTX@IZQBZ_]4J!7>QQT[KJFJC.U&B)
M\H]WJ\/UN%=[&6T*H_T.X,VB>?.>9_ZEQ0JJX-R*O?#4_6/NT4<>\24;8NKX
MZ3^<+9,GL6:?5S]R;PO4>/AWL?GB/TG39?8QUJW,_<6Z;=SV=^U%/^*[08KO
M &07/^3I[JJOU;;7:5Q+:WQ&OOII_19?E]C_ *D6IF<74<"[3'ES7%+S^?V9
M>KV#,]S1\;(B/7;O<_X+\!X^]V9Y+<\'/3\?]GE+/:UGUO\ :115_3I^4H[M
M0Z.=4-,B:LK9V?,4^:OXU'-$_JF%.-P
M=CS8^H=^YHVI9>GW)_!IIXJICZ>7K>,[,,VL=;%5-<>_2?KT^KVG ]K628F=
M,137;GVQS1].OT6>"NVY>R'OG2::KN@ZECZG1'E1/,7)_5$*4;@Z?[VVK=JM
M:]MO,QHH\Z^[S3/T6:_VJS53'KIK'SCH]WR[B/*M=/W5L ?H5^9
M
M
M
M
M                                                 !3[K5TPQ.IV
MT;VG1133J&/$W<.[,>--<>/'/LF8A4$9L9@[./P]>&OQK35&DMF QU_+,31B
M\-5I71.L2C$U#3\S2,_(TO4+-5K)Q;DV[E-4<3S$\$+4HF*HYCR?E[B+(KV08ZK"W/#O3/K'_ )N_
M77#/$%CB3+Z,;9Z3M5'\-7G'WCV-0'@7GP                   &E5,51Q
M5',*L=)>T+NGIS?MZ?J=VYJ>BX-F:I;UC;FHW<6_;F)F*9GN5_!53Y2NXZ0]IW0-XT
M6M&W?7;TO6*IBFF9F(M7I]L3X<3\'#[IPQV@87-M,/C=+=W_ +:O=/E/L?GK
MBWLTQF3QLJW-NY15',3$K%^M'1'6>F&K5Y.#8NY6@WZ
MIFQ>IIFJ;4<_@UGLGUA[APCQABN%<1-5$Z"=5]NUW(R=KWLJ
MU1/[[B4U7(F/;Y0^#9IP?F^4US%RU-5/\5/6/I]WZ+RCC7),ZHB;-^*:OX:I
MY9CY])^$R\ .;FZ'KFG533GZ-F6)CS[]J8X<"NY3;GBY$T\>UZW7:KMSI7$Q
M+VFBNF[&M$Q,>SJW#X_=>+_/T?2UC)L5?@7(JX]DH\LI\E7H^HUHHNW?"U8N
M5\_R:>788>W-Q:C,1@Z%G7IGR[EJ93HLW+DZ44S/NA57^='7#V>
MG]&>J>J\?RUU;U*8^Z,'$PHGUW+LQ_TO*8?A_-,5
M^RP]<_TR\3B.(LHPG[;$T1_5'VE21I,Q'C,Q'QKE-%[&6J7>[.O;HIL_RJ;%
MN*_U\P]UH?9!Z<:;=INZE?S=0F/.*KE5$3\T3+V#"]GF>XGK5;BB/YIC\HUG
MZ/6L9VF<.836(NS7/\M,S]9TA9E3SLU13IFVM1
MO\SQS]S5Q'TS"_W0ND73O;M,4Z=M?"F8\JKMJFY5],P]5C8&%A1WTX/LIKG2<7B(CV4QK]9T>HXWMDLTZQ@\+,^VJK3Z1'W6*:)V:^J^N4
MTUTZ/:Q+=7\:]=IYCYN8E[K1>QEN*_Q7KNZ<:Q[:+5J?KYE=P/9\)V:Y)A].
M\BJN?;.GY:/4L9VKY_B-8LS1;CV4ZS\ZM5!-$['_ $_PXBK5\S.S:X\X]TB*
M9^::7M]'Z ]*-%XG'VEAW9C^-=HBJ51![)A>&LHP8[
M7OL57,3Y15,1\HT=7IVU]O:13%.F:/C8T1Y1;HX=E%%%/A%,1\SQX&Y=N79YKE4S/MG4 35@                             #XY.'
MBYEJJQE6*+MNN.*J:HYB8?8G9LZ:;MBY?M:3&FY=4>%[
M%XH\?;/A/*W3J!V7]];.HO:AI$TZS@6_'_11Q=IC^CSS/S0OA:3$3'$P]1SC
M@C*,WB9FWR5_Q4]/G&TO=LC[0<[R28IBYWEO^&OK\IWCYHO[MN[8NU6,BS79
MNT3Q5;N4S35$_#$MJ_#JGV?MG]1<>O*MXU.G:K3$S;R+%,4Q55_M1''/SK,-
M\["W'T[UJO1-R8DVZ^9]RNT_@7:?;$OB?$G!^-X=JYZ_Q6IVJC[^DOOW"W&N
M7\44> >I/<                      &E7X,KZ^S!
MCU6>DNF5U'^W4L3NSQ;JGX)2"=!,7[CZ5:':F./]%55Y<>=4R^F]
MEMKFS6Y7Z43]9A\I[7[O+DMJCUN1]*95! ?>WYP
M
M
M
M
M
M             ?/(Q[.58KQLBW3^W\K;^LX]-VSD43$3,?@U>JJ/BGB7
MK'%7#MOB+!3:VN4]:9]OI[I>W\&<4W>%\?%W>U5TKCUCUCVQY?)&P/3=1M@Z
MMTVW/D;=U2B9HB9JQKW'O;EOU>/MXXY>9?F7$X:[@[U5B]&E5,Z3#]88;$VL
M99IQ%BKFHJC6)CSB0!0N                    #QB8JB9BJ)YB8GB8^<")
MTV%9^DO:7W+L6JUI&Y9N:OI/,4155,>ZV*?@GPYCX^5W^T=[;;WOI=K5=NZG
M:R;5R.9IIGWU,^R8GQ1LN[VAO7R8\GYYS;)L=D>(G#8ZW-%7TGVQ.TPW /(O%@
M
M
M
M
M
M #2JFFN.*J8F/9,-0'$NZ3I=^)B]IN+7$^?>M4S_ (.KR-@[,RIFJ_MO!JF?
M"?\ 10[\4UX:S=\=$3[XA?;Q5^U^SKF/=,P\K_FMZ>__ &I@_H3_ .7TM=--
MAV.?K_ -4_JZC&VEMG$XG'T+"H
MX\O]##G4:;IUO][P,:C^C:IC_!R1?38M4=*:8CX,]>(NW.M=4S[YEMIHHH\*
M**:?BCAN!;LIW                                              '
MC>J/331.I>V[^DZC8HC(BF:L:_$>^MU\>'C[.>'LA1BL-:QEFJQ?IYJ:HTF)
M:<'C+^ OTXG#53373.L3",S<&A:AMC6\S0=3M56\C#NS;GF/PHY\*OGCB77K
ME>V)L>,?-T_?.%8XB]_\OE51ZZOXL_12MJ?EGB+**LDS*Y@YVB>GMB=GZ_X:
MSJG/\KM8^GI-4?BCTJCI/Z^X >$>=                    ;+T3-JJF/.8
MXA(YTNQ/N+8.B8_''&)1/TQRCJQ+4W\[%L1',W;]%''QRDMVU8C&V]IMBF/"
MC$LQ_P D/KO91:UO8F[[*8^LOB_;+>TPN$L^M54_*(C[NR ?:WP(
M
M
M
M
M
M                           !3KK3TGT_JAMFYBQ;HMZICQ->)?X\8JX_
M!F?9,\+#-7TG4- U3)T75<>JQEXEL
M4V]8P:)JN44Q_K-'L^/_ ,/FG'O"7]ZVIS#!Q_BTQUC^*(^\?5]9[-^-?[IN
MQE6.J_P:Y_#,_N53_P#K/TGKZK,QK53;QN:Y1@L
M[P\X;'6XKI]N\>V)WB4D6S=^;7WYIM.J;:U.WDVIB.]3$QWJ)]E4>J7H4:6V
M=V;BV;J5&J[;U2[AWZ)YF*9][5'LF%V/27M2:%NF;.B;PIITS4IB**;LS_HK
ML_KXGXWW+AKM!PF;:8?&Z6[O_;/NGR]TOS[Q5V98W)^;$Y=K=L^G[U/OCSCV
MQ\85\'SLW[.1:IO8]VBY;JCFFJBJ)B8^.'T?1(F)ZP^7S$Q.D@#K@
M
M
M
M
M
M                                                        "G':
M"V]1N+I9K5B8COX]F;]N>/&*H_\ YK :)YIB?F28[HPJ=2V]J',7K%5,P
MC4RK?N.9D6>..Y=JCCYWP_M6PL48NQB(_>IF/E/^[]!]CF+FY@<1A9GPU1,?
MU1I]GS ?)WV(                   !W6Q\*=1WIHF#%//NN=9IX_WH21X5
MKW##L6?YNU33]$1"/_H3@1J/5C0K$T\^YW?=_P!&8E(,^Y=E5CEP5^]/G5$?
M*/\ =^?^V/$Y/CQ\7G]#XEV@<(3AZJLUP-/X)\<1Y3ZQ[)\_1^@>S7C:,91
M3DV85?XD>"J?WH_AGVQY>L=%&P\Q\D?9                        !I53
M%4<3#4'55.EO:&WAT[N6L#-O5ZIH\<4S8NU3-=NG_9F>>/BX7?=/NJNS^I&#
M3DZ!J-$WN.;F-7,4W:)]?O?/CX4=KEZ3J^JZ#FV]2T74+V'DVY[U-=JJ8Y^.
M/7\[WSASCS'9+I9O_P"):])WCW3]GSWBGL[R[B#6_8_PKW\41TG_ #1]XZ^]
M)P+8>E':RM7IM:)U&MTV*_"BC/H_!J^&ORX^9]
M13Y_@<]M=[@Z]?6/./?'_D/SSGO#68\.WNZQUO2/*J.M,^Z?MNY
M8#S+P(
M
M
M
M
M
M       #XY=,U8MZF(\9HJ^I&EN.W59W%J=JNGBJG)KB8]B2W,F:<6],3Q,4
M5?4C2W%75QAI'
MNFH:YK55/[W3;MTU?'WN5US]&]G.'[C(J*]/'55/V^S\P=J>*_M'$5=$3X*:
M:?IK]P![V^<@
M
M
M
M
M                                                 #K=P[?TO<^D
M9.B:SBTW\3*HFBY15'JEV0A_MB:UTYW'?V[K5NKFB9FQ>X][>H]4P_/'&W"5617_[3AHU
ML53_ *9])^S]/\!<:4<28;^S8J=,11'7^:/XH]OK'Q>= >@OH8
M               !,1,<3#VG3SJ[O3IMETUZ+J%=W"YCW3#NS,VZH^#X7BQI
MPF,OX&[%[#5S35'G#-B\'A\?9G#XJB*Z)WB8UA?=TN[0NS>HEJC$NWZ=-U.(
MB*\>_5$=Z?7-,^7SMQ\?C-3[%PYVET7=,/F\:3_'&WQCR]\/
MB/%'917;YL3DPER;-^F::HWB8TF !:I
M
M
M
M
M
M                                                     ==N')IP
M]#SLJKRMV:JOU(TLROW7.R;O\J]7/ZTB'5K/ITWISK^7-?=FC#KXGX4=-,S5
M$U5> ["\KL>Z15A]/LC4ZZ.)S,JOB?;$3
MX?6KVIYT#T6=#Z6:)BU4\3=LQD3_ +],2J&_5G#6&_L>48>SZ41]>K\=\6XO
M^W9YBK\;375\HG2/R 'G'KH
M
M
M
M
M
M   \#U@Z4Z3U1VY
MNQE8]V@                           .QT#<>N[6SZ-3V_J=_
M#OVYB8FBKWL_''E*Y[I;VM,#4*K.B]0;%.%?GBB,VG][J^&KV3\4+4&DQ$QQ
M,/8,DXFS#(;G-A:_P^=,]8GX?H]>S_A;+.)+?)C;?XO*J.E4?'S]TZPD[T_4
ML#5<6WFZ=EVLBQ=I[U-=NKF)AR4=W3_JYO;IOE45:'J==S#[W-S#NS,VZH^"
M/:NSZ8=I#9F_J;>!G78TK4^(BJU?JXIJGX*IXCYN7W#A[CO+\ZTM79[N[Z3M
M/NG[2_/W$W9SF>0ZW[$=[9C]Z(ZQ'\T?>-85>&VBNBY3%=NJ*J:HYB8GF)AN
M>\/G@
M
M
M
M
M
M"D7:CU7]S>D^H6J:^[7F3%BGX>8F?\%C%,<4Q"ZOMGZY-G3-%V_35X9%W[HJ
MCG^3S'^*U5^=^TG%?VC.YMQ^Y3$??[OT_P!EF#G#H:O@8%NGO57\FU1$?[T+M6*=ZJHCYRR9AB:<%@[N)JVHIJGY1JOYV]@1
MI6A8&FTT\1C8]%KCXHX=B#]FC6<:F:
MKM%,?/'K^'X%>VDQ$Q,3',2\;FV58;.<+5A,3&M,_.)]8]KRV29UBL
MAQE.-PE6E4>7E,><3[)1?W+=VS=KL7[55N[:JFBNBJ.)IJCSB6U=9VDN@<9]
MN]OW9N)_\W;CO9F);C]\CSFN/A\UJ_&L?NSY3'_F[]8\.<183B7!4XO#3I.U5/G3/I/L])\P!X)YX
M                    (YBJ*Z:IIKIGF*J9XF)^"0(G3K J[TS[2F]-BS:T
M_5KDZQI<3$33=JYNT1\%4\S/Q+L.G_5[974?&IKT+5*/NKCFO%N3%-VG_=Y1
MY/O@Y^=I>31FZ9F7<7(MSS3]M>D[Q[I_5\^X
ME[.FV=XX-&H;>U>QEVZXB>**O?1/LF)\7VW).)LNSZC7"U_B\Z
M9Z51\//X/@/$'".:<-UZ8NWK1Y51UIGX^7NG27> /8'K(
M
M
M
M
M
M                                   #YY-^WBX]S)NSQ1:IFNJ?@B')
MF(C678B9G2%E':QUV-5ZFTZ?1<[UO3<>*./AJBFI1=W_ %!UJK<.]]:U6JN:
MZ;F5713,^RF9B/J= _)^?XRR#MV--V#?UJY1Q6ITZ4:U3\(Z?5Z+
MVCX_^P\.WHB>MS2B/C/7Z1*O0#])ORH
M
M
M
M
M
M                 TJIBJ)IJCF)\)A:9VC^@->E7+V^]F8?.+5S7G8MNGF8
MJGSKIB/JX]:[1\[]BSDV:\>_;IN6[D33535',3'Q/"9_D6&X@PDX;$1U_=GS
MB?7]8\WL/#7$>+X9QL8O#3K&U5/E5'I/VGR1?Q,3',-5>^T1T#O;2RKN\MI8
MM=W2LBN:LFQ1'^KS/KC_ &?)02)B8YCRE^9\XR?$Y)BJL+BHTF-I\ICUA^K\
MESK"9_@Z<;@ZM:9WCSB?.)]L?[@#Q3RH
M  [3;6Z=P[.SXU/;.JW\'(B>9FW5,17\%41YNK%EJ]73_-IS-MZO=MT
MTSS./_P!?S?)^).RG!X[6_E-7
M=5_PSX)]WG3]82/"@733M7[8W%%K3=Y4TZ1GU<4Q./H5WQ,O%S
ML>C*P[]%ZSU]CRS.<#G%KO<'\.M_3C97>M
M:MN"S5D4^$X]FJ*KG/Q)_1XF%(=S=:NI>Z
MZJIU#TK*,',TX?6Y/LZ1\Y_1]$RSLHSO&Q%>*F
MFU3/K.L_*/O,+^,O=&V\")G,U[3[/'G%>313/ZY=;'4O84W/YXX^Z
M[?\ Y1SWLW4,FJ:\K4LR]5/G-R_55]?%ZO=[5[W-_A8:-/;5/
MZ/;;78UAHI_Q<55,^RF/U2986Y-O:CQ]PZW@7YGRBWD453^J78^?C",3%U'5
M,&Y%W!U7-QZZ9YB;>173Q]$JE[*[2'4C9M5%J[G1JV)$^^M9,^^F/Z[[_$O3$3,_P"SX^,*F/IF"Q^&S&S%_"UQ53/G#Y/F&6XO*K\X
M;&6YHKCRG[>L>T :V$                  >(ZS;CIVOTXUG4IK[M56/59H
MGG^-73,0]NMO[9.YHQ]O:;M>S>XKS+WNMVF)_BTS3,<_K>"XFQ\9;E-_$:]8
MIF(]\](_-['PCEO][9WA\+,=)JB9]T=9^D+3._5_'PSS*Q3I3M^K='470]&BCO45Y--=R)_D1YI%;-N+5FBU$>
M%%,4Q\T/LO93@-(OXZJ/2F/SG[/AW;'F/3#9?3/K7/Y1]V\!]C?"P
M
M
M
M
M
M                                        'QS,3&S\6[AY=FF[9O43
M1715',3$QQ*RKM ="&KTG])\WM7"?%6*X
M6QD7K76W5XZ?*8_6/*48T3$QS JYUVZ&ZCTVU.YK6D6:K^@Y-:87.<+3C,'5S45?2
M?.)])@ >/>0                                :3$3YO;;!ZP[ZZ=Y5
M->D:K7?PX_"P[]7>MS'U_K>*&K"8W$8"[%[#5S35'G$LV,P6'S"U-C%4171/
ME,:PO;Z:=IW9F]9M:?K%7[CZE5$1W+T^\KJ_V9\>/GE62QD6,FW%['O47:*H
MYBJBJ)B?GA%_53%4<3"HG3[KOO\ Z>UV\?$U&K/T^F8B<;(F:N(_V9F?#Z'U
M;(>TZNC2SFU.L?QT[_&/T^3X[Q%V26[FM_):^6?X*IZ?"K[3\T@ I)TY[26Q
M-\TV\/+R8TK49\*K.15%-,S\%4\1*K-NY;NT4W+5<5T51S%43S$P^M8#,L)F
M=J+V$N173[/OZ/BV993C?K>I8^'8HCF:KMR*>?BY\UOG4/M?:5AQ>T[86#5F7Z>:?NJ]'=MQ\,1,
M>/TO#YMG^7Y+1SXRY$3Z;S/NAYW)>&LSS^ODP-J:H\ZMJ8]\ST7$:EJ^F:18
MJRM3SK&-:ICF:KE<4^"B6_NUGL[;M5S!VS8KUG+IYB*Z/"W3/P\\3/S+5]W]
M0]Y;[OU7]S:W>R*:IYBQ35,6J?BIY>]==O)UBO PZI_U;&GB
MGCXYYG]:GM=55VN;MVNJNN?.JJJ9G];0?-,9F&*S"YWN*N37/MG5]6P67X3+
M;46<';BBGTB-/GZ_$ 8VL   !],7*RL#)MYN#D5V,BU5%5%RB>)IF%W?9Y[0
M4[MBWL[=]^*=6MT_Z'(JGB,B(_Q^CS6@/MAYF7IN98U'3[U5G)QJXN6JZ9XF
MFJ)YA[%PYQ%B>'L5%ZU.M$^*GRF/U])>N<3\,X3B?!SA[\:5QX:O.F?T]82>
MBF_0KJA8ZF;/M95VN(U'"B+&71SX]Z(\*OGB.?G5(?IO XVSF.'HQ5B=::HU
MA^2LQP%_*\5
)C2NB=)_\ /;Y #6Q                -)F(CF?4L0[2V
MZ*MR=4\VS17WK&FT1C4<3X=Z)F)_P7K[QUNQMW:^I:SD5=VC&QZZN>>/'CB/
MUS"-W4=2OZSJ.5J^35-5S,O57JIGSYF>7R?M3S+NL+:P-,]:IYI]T;?67V?L
M>ROO,5?S*J.E$^KK/TCZN. ^'OOP                  #2J>[3-7LCD
M=7 ]CW;$:ANW4-R7K7>MX%KW&B9CRKJXF)_5*\-1KLL;4JV[TUM9MZCNWM3N
M3?JYCQXB9B/U2K*_3G!.7_W=DEFB8TJJCFGX_P"VC\G=H.9_WIQ!?JIG6FB>
M2/Z>D_74 >V/2@
M
M
M
M
M
M   '!UK1M.U_3+^DZKC47\;(HFBNBN.8X6.];^B&I]+]3KU#3K5S(T#(K_T5
MWCF;,S/X-7ZE^#@:YH>F;CTO(TC5\6B_C9%$T5TU1SYQQS\;U?BCAC#\1X;E
MJZ7*?#5Z>R?8]PX0XNQ/"V*YJ?Q6:O%3Z^V/28_V1E^?C J;UJZ*ZMTMU>O)
MQ:*\G0\FJ:K-^(Y]RYG\"KXO\%,GYLS'+L1E>(JPN*IY:J?_ #6/8_5&79CA
MLVPU&+PE7-15M/VGTF/. !B;0                                 ".
M8JBNF9IJCRJIGB8^=4SIUV@M^=/JJ,;[JG5=/B8[V/DUS,Q'P5>,J9C;@C%F&6X3-;,X?&VXKIGRF/R\X^"^[IWVB]A;[IMXMS.ITW4:H
MB)QLB>[S5_L^?*J=%=%RF*J*HJB?*8GE%]'--45TU3353/,3$\3$JG=/>T+O
M_85=O&KS:M5TZCP^Y\B>9IC_ &9\/UOK&1]I\3I9S:C^JG[Q^GR?&^(>R.)U
MO9+<_HJ^U7Z_-?J*5=.^T7L+?E%&/7EQIF?/$56,FKCQ^"KR_6JE:NVK]$7;
M-RFY15',54SS$_.^K8',<+F5J+V$N173[/OZ/C>8Y5C
M
M
M
M
M       #BZCJFG:1C5YFIYMG<1-4UW:XICB/C4"ZC=K?0-&JNZ9LK%G4\J
MGFG[HJB8M4S\4\3/S/$YIG> R:WWF,N13[/.?=&[S63]Q;H^"(>>B(B.(A\?SWM,Q6+U
MLY93W=/\4^*?M#[AP[V48+ Z7LVJ[VO^&.E$>_SGZ0[S=6]]U;US:\[<>LY&
M3-4\Q;[\TVZ?@[L>'ZG1Q$1'$1P#YE>OW<37-R]5-54^V/U$P[=V_-&GZI5&/D1SX1SQQ5^I
M?I15373%=,\Q5',(OZ;MS'N49%J>*[545TS\,2D:Z9:].Y=B:-K-=??KR,6F
MJN?A\O\ !]L[+,TJNVKN75SX?Q4^Z>D_71\&[8+^KW>Y53$\3W(]]S]-
M*S6(XCA5SM.[PC='4J]@6;O?QM'H^YZ>)\.]Y\_\RD;\S<>Q]*LS2X"?T>+SO,:1C9%$T54UQSQ\,>R7JO%'"^'XCP_+5^&[3X:OM/
ML>Y<'\88GA;$ZQ^*S5XJ?O'I,?7:49HJ;UJZ*:KTLU6K)Q;=S(T+(JGW#(XY
M]S\?P:OIA3+S?F[,,51YP
MJ5T_[0'4#8-5O'HSZM2T^GB)Q\FJ:IBG_9JGGCZ%-AMP.8XK+;L7L)=I?8>]?<\/.R8TG4*O";61/%$S\%4\)CYWO]A=<>H'3ZY3;P=3
MKS<*)CO8V35WHX]D3Y_K?5,C[4*J=+6:T:_S4_>/T^3X_G_9%;N:WLFN:3_!
M5M\*OU^:0043Z>=J;9&[)MX6OU?N+G5>$Q=_>ZI]E,\S/TJS8N9B9UFG(P\B
MW>MUQ%5-5%7,3$OJV79M@LUM][@[D51[-X]\;P^-9IDF89+=[G'6IHGVQTGW
M3M/P?8!Y%XL
M
M
M
M
M   '#U/6-+T;&KS-4SK.-9MQS57
M+,3[8GGG]3Q.:9Y@,FM]YC+D4^SSGW1N\UD_#V99]<[O 6IJ]9VB/?,]%?-1
MU/3])Q:\W4\RUC6*(YJN7:XIICYY4&ZC=K3;6B1=T[9EB=4S(YI]VGPM43[8
MGQBI;/O3J;O7?V75D[@UF]5;G\''MU=VW3'L\..?G>6B(I\(A\DSSM.Q&(UM
M973R4_Q3UJ^$;1]7VKA[LFPF%TO9O7WE7\,=*?C.\_1ZG>O4[>W4#(JO;CUF
M[79JGF,:W,TVJ?\ =YX>6BF*8XIB(AJ/E^)Q5[&7)NXBN:JI\YG5]:PV%L8.
MU%G#T111&T1&D "A>              TJ\I7X=F>NNOI#HDUU3/%KB.?C6'5
MSW:)E?\ =GO3*]+Z3:!9N1,37CQ7X_#,OIW993,YG=JC;D^\/E/:_73&36J9
MWFY&G^F51P'WI^<              !T.^MQV=I[2U/<%ZJF(P\>JY',^EV3-
MH4Z'T_\ W>O6YIR=7N3(]41P^J=EV5]_C+F/KCI1&D>^?]OS?(>U
MW-_[-E]K+:)ZW)YI_P M/ZS^3L0'W1^>
M
M
M
M
M
M                            '7:]H&D[FTN_H^M8=O)Q3H615,V[E,<^X<_Q:O@\_H7X.#K>B:9N'3+^D:OB
M6\C%R*9IKHKIB8F/G>K<3\+X;B/#\M7X;L>&K[3ZP]PX0XOQ7"V)YJ?Q6:O%
M3]X])CZ[2C*B8GQ@5:ZY]"M1Z9Y]>L:/9N9&@7ZN::HYF<>9]57P?#\*DL3$
MQS$\Q+\WYGEF)RG$U87%4Z51]?;'L?J;*\TPN_=@W:)T+6
M[LXU,\SBW9FJW/S>#QXTX7&7\%&)7I>75Q'NT>^M53\T>'SRKKI>M:5K>-3EZ3J&/E6JHYBJ
MU1C13//N4US5:GXZ>>'TS)>T[%
M8?2UF5'/3_%'2K])^CY3GW9+@L7K=RJONJOX9ZT_"=X^J246P=/NV#9N3;P>
MH.FS8GPB(\MSJG7"78F?2>E7R?&7^*>E,?&?MJN7UO<>A[)GZ5LVY=W[FWAEU9FX]
M9R,RJJ>>Y57/N=/Q4\\0ZB(B(XB.(?)<[[3,9B];674]W3Z[U?I#[1D'91E^
M!TO9G5WM?\,=*8^\_3W/0[OZA;RWWE3D[FUJ_D4\\TV8JF+=$>R(>>B(B.(@
M'S7$8F]BKDW;]4U53YS.LOJF'P]G"VXLV*8IIC:(C2/E  I6@
M      .5I.G7M8U;"TK'H[]S+O4VZ:?;,I)MLZ5:T/;^!I-F.*,:Q31$+,.R
M[LNO<_46WK%ZUWL71H]VF9CF/=/#B/HF5\,1Q'$>I]T[+
MZ/\ ?\GY][7\UB_C;.743^SCFGWU;?2/JU ?5'QP             !I,Q3$U
M53$1'C,SZE@O:$WE_EIU,SKUJOG'T[_Y6U$3S'-/A5^NE>1U=W=9V5L'5=9N
M7(IK]QJLVOZ=<33'ZYA'AS:Y&WX*??/6KZ:1\6@#XJ^[
M  -*ZHHIFJ?*!W=7#LF[.C<&_+VX+]KO6-'M]ZF9CPFY/A]52]12'LR;)_R3
MZ<8V7?M13E:M/W3D@
M
M
M
M
M
M                       .+J>F8.L85W3]2QK=^Q>IFBNBNGF)B5EO7;H!
MJ'3[*O;BV[:KR="O5\U44QS5C3,^4_[/T^2]Q\,W"Q-1Q;N%G8]%^Q>IFBY;
MKCFFJF?.)AZYQ'PUA>(L/W=V-*X\-7G'ZQ['M7"O%F,X6Q7>V?Q6Y\5'E,?:
M?248<3$QS KQU\[.^7L^]?W9L[&JOZ/7,UWL:B.:[$SYS$1YQ\WK4&B8F.8?
MF[.,GQ628F<+BJ=)C:?*8]8?J;)LZP>?82G&8*K6F=X\XGTF/*6H#Q;RH
M                                    !Y^;G:/KFM;?RJ,W0]4R,*]1
M/,3;KGCZ/)P1.W8]]8N3W:Z9]D\^"/)NLW+N-?
MHRL:[7:O6YYIN43Q5$O?(FC(F9N13\%4S_
M (+BMA]IOIYO*JC#RLBK2C3$TSI( ZX
M
M
M
M                                                     ^61E8V'
M:F_EY%JQ;I\Z[E<4TQ\\N3,1&LNQ$U3I#ZM*JJ:8FJJJ(B/.9E2'?G:;Z>[-
MJKP\3(JU;-I\(MXT\T\_TXB86Y[Z[2W4?>%=S&P]9%V=YUG6ER:.ZMS^]7T^4;S\M%V>]^LN
MP=AV*ZM7UNS7D4QS3C6I[U=7Q>K]:W#?O:XW1KL7<'9^#&E8T\TQ?K\;LQ\7
M,PH)=KN7[]>3D7:KMZN>:JZYYJF6CY1G/:)FF9:V\//=4?R[_/\ 31]ER+LR
MR;*-+F(COKGK5X?A3^NKE:IJ^K:WDU9FLZED9EZN>9JNUS/ZO)Q0>AUW*KE7
M-7.L^U]$HHIMTQ31&D1Y1T@ 0=                    "8JGBFW3-5=4\4
MTQYS/J@5:[-_3.O?F];>IY^/,Z5I-47JYJI][7:8^F/%Y#*\NNYKB[>#L
MQ^*J=/UGX,&:YE8R?!W,=B)_#1&OO](]\ST7*=G3IY&P]A6)R;?&=J?&3?F8
M\8Y\:8^B855;:**+=%-NW3%--$133$>J(;GZLR_ VLMPMO"68_#1&G_GO?CC
M-,QO9MC+F-OS^*N9F?T^&P V,             #C:EG6=-T_(S[]=-%O'MU7
M*IJGB(XARJJ*8FJ=H2IIFNJ*:=Y6N=L;>U.1DZ=L7&N>%K_YG)B)\^>.[$_/
M3*VAZ'J'NJ[O;>NJ[EN53-.5?J]RC^3;YF8C];SS\K\3YK.<9I=Q6OX==(]T
M=(?L/A7)XR+*+&"T_%$:U?YIZS^GP '@'L                   ])TXVI<
MWMO?2MMT4S-&1>IF],1Y6XGQG];S?DN<['.QZ+M6H;\R[,\Q/W-BS5'J\>],
M?/3#V#A?*ISG-+6&T_#KK5[HZR]=XKSB,BRB]C-?Q1&E/^:>D?K\%S^GX=K3
M\&Q@V*(IHL6Z;=,1Y>$.0#]3TTQ3$1&S\>U535,U3O( ZX
M
M
M
M
M
M                                              ^=^Q9R;->/D6J;
MENY'=JHJCF)CX8E:;U][-]_2KM_>.P\6J[C5S-S+PJ8_>X]=5$>SX/#R7;-M
MRW1=HJMW*(JIJCB8F.8F'@\^R#"<08:D^*F=JH]OVGR1>Q//P<3Q,3ZI:KJ>O_9OIRXR-Z;#QHHR(COY6#1'A<]BYH>O7Z[4?\ T,BJ
M;M''LB*N>%P6P^V%H^;%&)OO3:M/N\<3D6??6YGVSSQPM.)B)\)A[+E'%N:Y
M+,1A[LS3_#/6/]O@]7SK@[)L^B9Q5F(KG]ZGI5\_/XQ*2K;F\-M;MQ8S-NZQ
MC9UJ8B9FU7$\?&[E&3I.N:WH&13EZ'JV3A7J)YBJU7_A/@K9L?M;[NT*FWB;
MKP:=7L1Q$WJ?"[$?3$/J64=I^"Q.EO,*)MU>L=:?UCZOD.=]D>.PVMS*[D7:
M?X9Z5?I/T]R\H4YV1UZZ=[XHHHPM8MXN57_^[Y$]VJ/G\OUJAVKUJ_1%RS=H
MN4SY54U1,2^C83'8;'VXNX6Y%=/LG5\LQV78O+;DV<9;JHJCRF-&\!K8@
M
M
M
M
M                     ;+MVU9HFY>NT6Z8\ZJIB(A3W?'7GIYL>W71F:Q;
MRLJGRQ[$]ZJ9^/R_6R8O'8; 6YNXFY%%/MG1MP.78O,KL6<';FNJ?*(U5%=-
MN/=^V]I8E6;N'5\?"M1'/-VN(Y^):?OCM<[LUVBYB;2P*=)L3,Q%ZOQNS'TS
M'ZE$]7UW6]P9%>7KFJY.;>KGF:KE?^$>#YSF_:=@L-K;R^B;E7K/2G]9^CZE
MDG9'CL5I]Y;B?;''/*W
MO>?5K?V^[U5S7-=OT6JO_H8]4VZ(^#BGCEY"(B/"('RW-^+M/:0 <
M                   /'RB)F9\(B(YF9-QSM#T74-R:QB:%I5FJ[E9ER+=%
M-,>4>N?HY2"]+.G^#TWVAB;?QJ:)O44]_(NQ'C7UQY3
M/G,_KF'IG'>;_P!TY17%$Z5W/PQ\=_H]][.?-4Q'^*1;IMM+&V3LS3= Q[?=FS9IJN^'$SIF8\*KL\Q'T3$2O8?97(ZU]*?=&_P Y_)\ [7<\[_%6
M\IM3TM_BJ_S3M'PC\P!]6?&0
M
M
M
M
M
M                           !0'KQVJZ711A:Y9IFJ
MB[13Q%[C^+5_Y^%93KV@:SM?5;VB:_@W,7,L53%5%<<=Z/;'P2_.?$W"N*X<
MOZ5_BMSX:OM/I+]1\*<7X/BG#\UK\-VGQ43O'MCUCV^7FX #U9[8
M                                      TFF.]%<>%5/C%4>/@\$->#Q^)P%SO<+7-%7LG1EQF!PN8
MV^YQ=N*Z?2J-5W>R>V!MC4O+=VFJJ/CB)\$:)N3#LZMC4\4^Z?@7(CXHCQ^>5?=F=H_IIN^+=B=7IT_+JB.;.5Q3
M//LCB9?3/C"J8
M^6/DX^5;IO8UZBY15',54SS$P^KVN)B8UAZ9,33.D@#K@
M
M
M
M                                                         #Y9
M&5C8EJJ_DWZ+5NB.:JJIXB(?AYF%!-Y]K7?&O^Z8NW,.SI&-5S3W_ ,.Y,?%,>'TO5,UXUR?*=::[
MO/5Z4]9_2/F]SR;@#/K)UW6,7$IIC
MGBY=IIJGXHF?%0[>O; VQIWNN'M#3[VI9$>$7JX[EN)]OC'C]*U'5=;UK7(<&(B(XB(A\RS;M.QV)UHP%$6Z?6>M7Z1\GUG
M)NR7+,'IW7J=K>^X\28TK
M#KYQ[-RG]_KB?/B?.(XGZ7D>A_1S4.J.O4W\NU%R8_B1]'C\
M:^S2],PM&T^QIFG8]%G'QK=-NW113$1$1'#ZEP#PA./N1F>-I_PZ9_#$_O3Z
M^Z/J^2]H_&T97:JRG 5?XU4?BF/W8GR_S3]('ZR[UM[#Z?ZGK<5Q3D>YS:QXY\?=:HGN_4CVO7[F5
M>N95ZJ:KEZNJY5,^N9GE<#VN]^3JVY,79>#?BK'T^F+N1W9\)N3Q,1/Q>*WQ
M^=^T7.?[QS2<-1/X+73X^?Z?!^GNS'(_[JR:,3_K&7D6IJ
MT_1YB_>F8\*JO**?UQ+?EF N9IB[>$M1UJF(_6?@PYGF%K*<'_5$
M PU&%M1^&B(B/@_&N8XZ[F>+N8R_/XJYF9^( U,0
M
M
M
M
M
M                                              I]U8Z-[+O70
M9IGPIG(QI][\PY5Q5FN3Z1AKL\OI/6/E+UO-^$8KMU=VJ/G5*VAVB.IVT)HM4ZO.HXU/A[EE!?TR_/A-RB/=*)GX^(X5IV_O3:^Z;%-_0=;Q,R*HY[MN[%54?'
M$3X/HN6Y_EN;1$X2]%4^FND_*>KY;FO#6:Y)5IC;%5,>NFL?..CNP'F'@P
M
M
M
M
M  >=W+U!V=M&U5=U[7L3&FF.??%1/>/;$V[AQS[OC%-
MZ[$VZ(^'RGEX7,N(LLRF)_M=Z(GTWGY1U>?RGA?-\[F/[%8JJCUTTI^<]%QE
M==%NF:[E=--,>%JU5[I5,^SWO/"S/=W7[
MJ=O&:Z,K6ZL+'KYCW'$YM^'PS$^*G=R:[UV;]^Y5=NU>,UUSS5/SOG.:]J=%
M.M&6VM?;5^D?J^HY/V/53I7FM_3^6CK_ -T_:)7-;R[9%V[%S%V5H,T\^$9&
M3/,?'$1,2H;NKJ?OW>ERJK7]QY-VW/E9IJXHC_%YGE](Z
M1\H?4\HX3R?(XC^QV(BK^*?Q5?.?MHTBF(YGSF?.9GEJ#U_=[& #@
M                       ]QTFZ5ZSU3W!1@8=-5G3[$Q5EY,Q[VFGV1/KG
MR<7IGTSU[JAKU&DZ3;JMXM%43E94Q[VU3\?M^#X%^>Q=CZ)L'0,?0M$Q:+5%
MNF/=*XCWURKUU53ZY?0."^#J\\NQBL5&EBF?]4^D>SUE\ZX[XXM\-V9PN%F)
MQ-4?Z(]9]OI'QN8BY5=NS,U3.LS.\R )JP             !TF]-R8NTML:A
MKV7]CZ>'=K7^V#U B+.'L'3\CBJY,7\ONU?Q>?>Q/STO"
M<19M3DN6W<7.\1I'MF=GL/"N2U9_FMK!1X9G6J?2F.L_I[UM6NZUE[CUK-UW
M-KJJNYMZN]//JB9F8C];@D1QX0/RK]Y44355/A33$1;XS]
M2B,C(F8\8Y\H^CA;)V<^GES?._L?+RL>:],TF8OWIF/>U5Q,333\_$K[K=%-
MJBFW1'%-$13$>R(?9NS#(M(JS:]'\M/WG[?-\.[6^(?!DMB?2JO_ /6/O\FX
M!]B?"P
M
M
M
M
M
M               !UFX=N:/NG2[VD:WA6\G&O4S3--=//'/KCV2[,0N6Z+M,
MT5QK$[Q*=NY79KBY;G2J.L3&\+'.M79\UKIUD7-9T*W=S]"KJFJ:HCFK'^"?
M@4>B8F.82?96)C9V/+XGQ?V?U8;FQV51K1O-'G'MCUCV>3[_P3VE48WER_.:M+FU-?
ME5[*O2?;M*VX*J:Z*ZK=VW5;KIGBJBNF8JIGV3$CY/,3$Z2^Q@#@
M                                          TF(GPF.7*T_5-4TF]3
MD:5J63B7*9YB;5VJF/HB>'&$J*ZK<\U$Z2Y5337'+5&L>U6#9W:CZC;8BW8U
M*NUK&+1X=V][VJ(^.F/%7'9O:SV#KU-NQKT7-'R:N(F;L?Z/GX)YF5ES28B?
M"8>WY7QWG.6:4QTG(J\.[>B:J>?CB.%6-*W'H6N6J;VDZ
MMB95-4IJGZ(E] P&<8#,Z>;"7::O=/7Y;OFF99%F645^.GSV
M=D \D\2
M
M
M                                                           #
MH]/%$%-<1W*/
M^:'B,PS[+:YS5I@K%54>NFD?.=(5^F8B.9GB'2
MZ_O7:NV+,W]=US%Q*(CGW]?G]"S#=W:;ZG;GJKM86?1I&/5S'=QHF*N/CYE2
M[4-1U'5[\Y.JY]_+NU3S-=VOF9?/\S[4\+:UIP%J:Y]:ND?+?\GTS*>Q_%7=
M*\SO11'I3^*?GM'U7=[Q[7VSM)IJL;6PKNK7XGB*_*U/S\\_J40WCVD^I>[:
M:\>SG4:5BUS^]XWC/'QS'*E?$0/G>:<;YSFFM-=WDIGRIZ?[_5]-RC@+(9JNW*JOKE\8B(\(C@'JE555
MVZ/7\[E=*.DFO]5-9C$PJ*L?3K,Q.3EU4SW8C
MV1[9^)?3LC8^@[!T*QH.@XM-JU:I]]7Q[ZY5ZZIGVOH'!W!=W/*XQ6*B:;$?
M.KV1[/67SGCCCRSPY;G"828JQ,_*CVS[?2/C+Y[!V#H/3S0;.AZ'C4T4T1'N
MEV8]_JFCU1"YGM=]18TW1L?8NGWO_F-1COY/=G\&U'/A/S\+2HB(
MCB'PGM-SO^U8NG+;4_AM]:O\T_I'YOT5V3Y!_8L#5FMZ/QW>E/\ EC]9_( ?
M+7UL                  ;K=J[D7K>-8IFJ[>KBW;ICSFJ9XC]Z9
MU;OW;.Y=3QIJTW29[U$U1X5W?@^+PEY/)\LNYQC;>#L[U3\H\Y^#QFMQ]W9L1D9-7'CWJHY[L_%S,*DM/+P
MAJ_56!P=K+\-1A;,:4TQI#\=9CC[V:8NYC,1.M=M_9MT[>%N_N3:%JC#UF(FJNU3'=MW_ )H\(GYO6M U
M72M2T+4;VD:QAW,7,QZIIKMW(XGXX^!)RIOU:Z);:ZH:=5-ZU3B:I:IGW#+M
MT\51/LGVQ\SYGQ;P#:S/FQF71%-WSCRJ_2?S?6N"NTB[E7+@,UF:[.T5;U4?
MK3]8\O18(/1;YV!N;IWJ]S2=Q85=$15,68]Q
MO54Q]$2X G;N5VJN:W,Q/L1N44W:9HN1$Q/E/6%:=I]J[J+H'
M.>]$45\?'Q,RK1M/M:=/=:IHM:Y%_2SO(,UUJFSW=7K1T^FWT27:)NK;NY+--_0]8Q;-R*OJ=LC'T_5]7TB[%_2M5RL6Y3Y3;N3''S>2J&TNT]U,VS%%G-RK6K
M8]'AW,B.)X^.F(?0,M[4L)=TIQUJ:)]8ZQ\M_P WS;->Q_&6M:\MO17'I5^&
M?GUB?HOH%O>T^V'M#5)IL;FTR_I=V?.OPFW'ZYE6';_439>Z;=-S0]Q8>3S'
M/$5\3'T\/?IF?372?E/5\XS/AC-\GG_WF'JICUTUCYQK#T8V
MTUTUQWJ*HJB?7$\MSS+P(
M
M
M                                                           #
MY7LG'QZ9KR+]NW3'KKJB/KZ>V;C4378VCMNN]ZJ;N5/$?'[V7@,QXIRC*]8Q%^-?2.L_1[
M-E?!N=YQI.&P]7+ZS^&/G.BY]YCN[BP\>JB.9MS>I^[9JMY.X+F)8JG]ZQXB(CY^.7@V)M; []C:>E
MW]2N1S$7+D>YT?'$^/*C&ZNTKU1W1%=JWJ-O3,>KGBC'IXJB/Z4<2I9$1'A$
M#T',N-LZS/6*[TTTSY4](_7ZOI&5N37];X1$1X1'#4>JU5U5SS53K+VZF(ICEIC2 !%T
M                               !I,Q$CG1/7.J>I49%V
MW+C6:8IHMT1Q$1#Z=P=P)*?.K](_-
M\IXX[1+63Q5@,LF*K^TU;Q1^M7Y>;B[5VIHNS=&L:'H6'18Q[%,1[V(YJGVS
M/KEW /N]JU19HBW;C2F.D1'D_.EZ]I3
MWK_=GQIM1ZI^.)>)SS-+>38"YC+G[L=/;/E'S>:X>R:YGV96L!;_ 'IZSZ4Q
MO/PA;1U&WAE[ZWGJ6XLJN9INW9HLQ_)HI\(^KEYMI$<1PU?E3$XBYB[U5^[.
MM54S,^^7[%PV'MX2S1A[,:4TQ$1'LCH *%P                !,Q$M(7TQV-A=/=G8.W<2B._:MQ-^OUUW./&?
MJ4)[)G2J:8N=1-8%-<>4>NOZ8GZ5T3[WV<<._V#"SF-^/QW-O93_O
M^3\[=JG$\9ABXRG#5?X=J?Q>VO\ _P"=O?J /IKY&
M
M
M
M
M
M                                                           \
M_O78VW=_:-SV^"_5Q\_3\+5,2Y@ZABV\BQ=CNUV[E,54S'Q2]4XEX3P?$5
MO6N.6[&U4?E/K#W/A/C7'<+W>6B>>S,_BHG;WQZ3^?FC$B8F.8D7&]:^R_EZ
M37>W+T[LUY&-,S[535'$TS[)?GK
M.?8'B'#1B<#7K'G'G3/I,?^1/DT >'>9
M                                                     &[&O7\*
M]&1AW[EB[$\Q7;GB6T=BJ:9U@F-8TE4/;77_ *J;7FW;QMQ7,RQ;_P#I9KYGP7D6;ZSB,/3$^M/X9^GW2![5ZZ]-=VTT1@;ALV;E7_T\F?HG^-;KBJ/IA&!%,4SWJ/>U1Y54^$Q\[T>W>HF^-K7:;FC;F
MS;<4>5%R[5]9=VJUQI3C[&OMIG3Z3^KYWF?8[:JUJR[$3'LKC7ZQ^
MB2$6;;9[8.^--JHM;CTG%U*U'A-=$^YU?1%*KVV>U?TTUFFBWJV1?TO(J\)B
M_1$4<_TIE[UE_'&29CTIO6'HV8<2YKFFO]IOU3
M$^43I'RCH^A99POD^41']DP],3'G,:S\YUEMBBGO37/C5/G,^(KKJIMVZ*KE=<\4T4QS55/LB
M(\URG0OLS7,^%S&T^J/&KV37'^'AYO9=#NS9@;2MV-S;SM496L
MS'>IQZH[UNQ\T^<_-X<*^4Q%,133$1$1Q$1ZGVC@_L_BURX[-J=9WIH]/;5^
MGS?"N-^TN;G-EV2U=-JKD>?LI]G\WR?/&QK&)8HQL:U3;M6X[M--,<1$/J#Z
M[$1$:0^(S,S.L@#K@                 #@ZWJV+H>DY>K9ER*+.+:JNU3,
M\>4<\([>H>\LO?V\-0W+E7*JJ;UR:;$3_%M1,]V/H7&]KGJ5]P:;C["TG)XR
M,R?=,ONSXTV^?"/IA:=$1$1$>4/A7:9GW]JQ5.669_#;ZU>VK_:/J_1/91P[
M_8<%5FU^/QW>E/LICS_JGZ0U ?+'UP                  >PZ4=/LSJ5O+
M$T&S;J^Y:*HNY=SCPIMQ/C'/MF.7D;-F]DW[>+CT37>O5Q;MTQYS5,\0ON[/
M_2NUTXVC:KS;,?NMJ%,7LJJ8\:>8YBCX..9>X<&<.U9_CXBY'^%1UJ^T?'\G
MIG'/$]/#66S7;G_&KZ41^=7NC\]%1](TK#T33,;2L"S3:L8UNFW133'$<1#F
M _2U---%,4TQI$/R?775U>IFF586NX5/W13'^@RJ(B+EJ?@GV+*NJ/1O=
M?2[.JC4+%65IMRJ?</L%Q+3%B[I;Q'\/E5[:9^V_O>#")B8YB>8'HSWX
M                                           :33$^<1+4'7(PM1U+
M3:XNZ;J.1C5T^,56[DQPJ#M?M#=4]L=RW&O59]BB>?<\F(XGYXB)4V&[!YGC
M4W<:8[O
M_-5RJWMGK]TQW/13&-N.Q8O5?_2OV-)^<:/1,R[*\BQNLV(JM3_+.L?*=?SA)YBZEI^=1%>'G6+U,QS$V[
MD5?4Y*-70MZ;MVS7%>A;BSL/NSS%-N[,4_1"IFVNU;U-T6:;6J58VIVH\YKH
MXKF/CF9>[8#M1R^]I&+MU43[.L?:?H]!S'L@S*QK5@;U-R/2?PS]X^J]X6\;
M=[8^S\SW.SN'2,O3[D^%5=/-RF/A\*55=N=7^GFZ*8G2]S8G>GRHO7*;=7T3
M/+W3 \293F6G]FOTS/IKI/RG27H68\*9UE77%8:J(]=-8^<:P]D/G9R+&31%
MW'O47:)\JJ*HF/U/H\W$Q,:P]?F)B=) '7
M
M
M                                           /)U&K;NVQH=NJYJNN
MX.-%/G%R_33/T3*NY=HLT\UR8B/;T66K-R]5R6Z9F?9&KMQ1[.Y8MS,3\\::9\ZOPQ]>ORA=E771;I[U=<4Q'KF>(
M=)K.^=H[?H]TU?<&%CQQSXW(F?HCE8KK_77JIN2*Z,W=%^Q9K_\ IXTU6X^+
MS>%R[U_/NS?S\BYDW)GF:KM7>EZ7C^U6S3TP5B9]M4Z?2/U>^9=V.7:NN88F
M(]E$:_6=/R7I;H[6?3G1)KM:5[OJURGPB;,<4\_[W"E&Y.V%O'5**K.W]&Q]
M-HGRN5S,W(_7,*!1$1Y0/2L?V@9WCM8INE,:?7?ZO?51
MYUSK](TCZ/3[@ZG]0=T7*J]:W3F7::O.W35%-/ZHAYBN:KM4UW:ZZZI\YJJF
M?K!ZC?Q5_%5<]^N:I]LS/YO=E,1'Y'EY ,ZX
M                                    "9B(YF>%0^D_17'I%NJ)O9==,Q%4>N*/+F?ACVMF!P&(S*_&'PM$U53Y0R8_,,-E>'JQ6+KBB
MBG>9_P#.L^QYG9NR-Q;]UBUHNW<&N[775$5W>/>6H]LRO8Z0]#-N=,-/INS;
MHS=7NTQ-[*KCF8GV4^R/F>HV'T]VUT[T>C2-O8--J.(F[=XCOW:O7,SZ_6],
M^_<)\#X?(J8Q&)TKO?2GW>WVOS=QGV@XGB&9PF#UMX?ZU>VKV>SY@#WY\V
M                  '5;HW#@[5T'-U[4;D46,.U-RJ9GCGXG:K5.USU,F_?
ML=/-*OQ-%/%[.FF?7QX4_14\'Q%G-&19?7BZM]J8]:IV_5[%PKD-SB+-+>"I
M\.]4^E,;_I'M4 WGNG-WKNC4-S9]RJJYF79JHB?XE'JB'3 _+%^]7B;M5ZY.
MM54ZS[Y?K^S9MX>W39M1I33$1$>D1T@ 5+                 \O&1['I3T
MZS^IF[<;0\>BJG#HJBO,O1'A1;]GQ^,-.#PEW'7ZRQTA_=S4?\OM?Q9G"Q9XPK=<>%RO\ E?%X_J7>>7A#@:#H
MFG[+N=*=J8]*8V^,[S[0!YYZV
M
M
M
M
M
M                                                  .%J^CZ9KN!
M=TW5L.UDX]ZF::J+E,51^MS1&NBFNF::HUB4J*ZK=45T3I,>:S_K+V7M0V]5
M?W#L"W]3'O+T_[4/D?%79U3=YL7E$:3
MO-'E_3^GR?;>#^U&;?+@L\G6-HN>?]7K[]_590.VW1M3<&S-5NZ/N/3KN+?M
MU<1-4>\K^&)\I=2^,WK-S#US;NTS%4;Q.[[G:NV[]$7;5454SUB8ZQ, "M,
M
M     F(GPF"B:K57>LW*[54>55NJ:9^F =B9CK ])H'4C?>V;E->D;GS:(I\
MJ+ER;E/T53*I^WNUYU!TNJBC6M/Q-3M4^<_@53^C"A@\Q@>(F
MNL?*>CPN8<-Y1FO_ !F'HJGUTTGYQI*\;;7:_P!BZC131N##R=-NSYSW8FW'
MSS/*IV@]6>GFY::)TG=.%=KN>5OW3WWT(Z^(GS@H[UJKOVJZZ*O;35,/CAT+J9U VS737HNZLVS%'E1-433^N%3-N=KCJ!I/=HUG#Q=3HC\*J8F*Y_7
M$/LO3C<=-'[F[GQ9JK\J;DS1//^]P]OP7$F4Y
MA_P]^F9]-=)^4Z/1\PX4SK*_^)PU41ZQ&L?.-8>U'PQ\["S([V)F6+T>VW;B8JC6'K]5,TSI5  ZX
M
M
M                #Y7LG&QJ>]D9%NU3[:ZXIC];SFM]3=B;>IJJU3Q-G#QS7JXICVS$?FT6,)?Q57+8HFJ?9$S^3U H9N'M<].M)J
MJM:9:RM2KCGNS:CNQ,_[T0IIK_;(W3FTU6M V_CX=,^$5WYF:H^BIZQC>.OUV^KV[ =GG$6/TF,/-$>M4Q3])Z_1=[-5,>>UMOT
MS5K.NXF)$1S_ *2YPL.U_K=U2W',TYNZ\FU:F?WNS,1'U/&967FY][Y?V-WJM*L?B8CV41K/SG2/HO=7N^7]F/#V!TFY;F[/\T]/E&D*@[DZ]]4=
MS]ZG+W#7C6Y\J,>F*.(^..)>%R\_4M0KFYJ&I9>355XS-V]55]7T\F$M4T1_+$0TBFF/*F(^9J#$V@ X
M                                        -)GCB.)F9\(B/.7,TG2-
M4U[4+6E:-@WU%O-U7B*[=B8YMV/
M7\\QX>OA[%P_PSC>(;W)AXTHC>J=H_6?8];XDXJP'#%CO<55K7/AHCQ3^D>V
M5.>BO9FU+=55G<>^;5W"TV)BNSBS$Q7?C_:]D?.N[TG2-.T/ M:9I6':QL:S
M3W:+=NF(B/HP/60                    &DS%,3
M5,\1'C,@\QU(WO@]/]I9VXLVY%,V;Q]/"/#6=8S=P:OF:WJ%V
MJY?S+M5VJ:IYXB9\(^:/!67M3=3IW5NC_)#3;_>T[2:O]+-,\TUWN?'Z)C]:
MAS\\]H7$']ZX_P#LEF?\.UT]]7G/V?IWLTX:_N7+/[7?C2[>TGW4^4?'>?@
M/GKZ0                 3[(B9F?"(CSF0J_EY=R+=J
MBF/&9F>/\5^_13I;A=,=J6L+N4U:AE1%W+NS'ON],?@\^R.>/F4T[+O1B-&P
MZ.H.XL;_ .>RZ?\ Y2S7'C:MS'X7QSS^I<<^\]GO"O\ =UF,SQ4?XEG*,%5_A43^*8_>JCR]U/UD ?3WR(
M
M
M
M
M
M
M             !Y??G3G:_432ZM-W%@47>(GW.[$1%=N?;$^I9GU8Z![JZ:9
M%S-L6:]1T7GWF1;IF:J(_P!N(YX^-?H^.5B8N=8KQ8:KJ>L796LYDY&X^G<>Y9$\W+F!//=KG_9\_'X/!:]J.G:AI&;=TW5<.[B
MY5F>[7:N1Q,2_/\ GG#N.R"]W>*IZ>54;3\?L_260<2Y?Q)8[[!5]8WIGQ4^
M^/O'1QP'@GGP
M                       !M]SHBJ*Z:>*H\JH\X;@B='=='>:+OG>6W:J9
MT;?NEOWW'QS,J0CRN#SS,<
M!/\ [:]53[IG1XG'9%EF9?\ %X>BOWTQK\]UU6@=L[2ZZ:;>Y-M7K%7E5VX+M*SG#:1
M>FFY'MC2?G&CTO']E>08O6;,56I_EG6/E.OYI,M-W'H&L4Q5I>L8F5%7E[E=
MIJ^IV2,;#U;5].KBYI^K9F/53Y3;OU1$?-R]KM_KQU3VY--.)N2Y>HCSIO4T
MU<_/,3+VS!]JN&JTC%V)I]M,Q/TG3\WIF.[',33K."Q--7LJB8^L:I!!:#H/
M;)W5AS%&O;=Q+T3K'TVW!;IKT
M[=>%757Y437Q+UMC-P\FB+F/E6KE-4H7(\IHICN3\_/+P^+XARK Q/?WZ8^,3/RAYW \+Y
MSF.G]FPU45W:YY^/CQA3O<'7WJIN
M+O4Y.XZ\>BKRHLT4T\?/$1+U7&=I>38;I9YKD^R-(^<_H]QP/9-GN)TG$31;
MCVSK/RIU_-?CJ&OZ)I435J>K8N+$>??OU3'T<\.%W*>>9CF?;+U/&]JN)KZ82Q
M%/\ FF9_+1[E@>QW!6])QN(JJ]E,13^>J[/7>V;M^S%=&WMO9.55Y4UW9FW'
MQ\3$J;:_VL>INJQ7:TVG#T^W,^]F+<551\_@HN/4\;QSGF-Z57YICTIZ?EU^
MKW/ < 'PUG"4\F'HBF/2(B/R(B(\H
M4+@                                                        #
MGQB(B9F?"(CSF3<'K>G72_=74S4Z<+0<2JG&IJXO9=<<6[4?O5?I'M?+N,.TC#9+S8/+=+E_:9WII_6?
M9MZO)=*^C.UNE^!3&GV*;^HUT\7LRNGW]4^OCUQ'P1DW)N7KM4UW*Y\ZJI\Y
M: _-N.LQ^Y3/WGR](Z^CGV[=NS;IM6J(HHHCBFF(XB(;@??-GYMF
M=>L@
M
M
M
M
M
M                                     "GW5#HMM+J;A5?=^)3CZC13
M/N.9;CBNF?5S[85!&7&8+#X^S-C$T153/E+9@P :11$5=^F9IJCUQ/#N-*WANS0ZJ:](W%G8LT^7-5%,?1,RMJ'L&#XPSO!?L\15,>WK^;UK&\%9!F'[;"TQ/K3^'\M
M%ZNA=K7IEJM<49U63ITS_.455?5"H.C=5^GVOR+)[_7#7*[<_
M"J/KI/U2>8^H8&7$3B9MB]$_S=RFKZI\=W:+535I6Y=1L=WRBG(KX^
MM[C1>TEU9T2:>-:M9=%/\6_:BJ9^>7LV$[5,#QW,+>LX
M2_37[XFF?O"_06C:'VS-Q6)IIU_;5C(CGWU5JYW?U12]]HG; Z?YLTT:OB9N
M#5/G,6IJICY_![-A..SOB/!:S.'FJ/6F8J_+K]
M%>Q3[1>O/2S79IC%W7B6IJ\HOUTT3];V.!K^B:I$5:=JF-DQ/E-NY%7U/8L/
MF&$Q<:V+M-7NF)>K8K+,;@ITQ-FJCWTS#L &QA
M
M                                                    !I,Q$U.W:KNSRVZ9F?9&KM!3C6>T
M'TIT2J:,C=%B],>'&/537_B\+K/;%V/B353H^F9N;5'E-5$T4S\_B\+BN)\G
MP?[;$4Q\=?RU>PX/A#/%UKM&=6=;FKOZ]3BT5?Q;%ON3'SQ+UK%=I>2V.EKFKGV1I'UT_)[5@
M^R?/L1I-_DMQ[:M9^4:_FOOR=2T[#B9R\_'L9UGJWT\T&)G4=T
M84=WSBWHY$SY][(KF/K=1-%-57>KCO53YS5XR
M]9Q?:OVX/)LNR_
M_A;%%'NIC7Y[M)IB:N_5,U53ZYGEKQ'L!XZ9F=WD]0!QP
M                                               "9B(YF>(>^Z7]
M%]V]3\RW5@X]6)I<5?Z7-N4S%/'K[OJF?G:\%@<1F-Z,/A:)JJGRADQV.PV6
MV*L3BZXHHC>9_P#.L^QX[1-$U?5>J[M--NGF(^&9\H^==KT:
M[,&E[7]QW!O>FWJ&I\1718F.;=B?\9^=4OIMTEVGTSTZG%T7#IKR:HCW7*N1
MS$-P/I3Y1N
M   \_OO>.F[%VQF[BU.]%%&/;GN1/\:YQ[VGYYX57KU&'MU7;LZ4TQK,^R%V
M'L7,5=IL68UJJF(B/6948[5_52-#T:G8>D9,QFZE3SDU43XV[7'C$_'S$K0H
MCB.';;JW-J6\=PYNX]5NS9_!HY][3\T<.J?E[BC/:\_S"O$SX(Z4
MQZ1'Z[OUUPGP];X:RRC!T^.>M<^M4[_"-H 'KKV4                =WLW
M9^L[[W!C[=T.Q57=O51[I7$>%JCUU3\W/T.OT?2-1U_5,;1=(QJ[^7EUQ1;H
MICGYU]O1+H[IW2W0*(NT47M9RJ8JR\CCGQ_DTS[(\?I>W\(\+7>(L5K5TLT^
M*?M'MEZ;QGQ=9X6P>L:3?K\%/_[3[(^L]'?]->GFB]-]M6-"TFS3%<4Q5D7>
M/?7;GKF?GF7K ?I/#X>UA+5-BS&E-,:1#\J8K%7L;?JQ&(JFJNJ=9F?.0!I>+5=N6*
M<#4XB9MY=FGB9GU15'E,?,LYZB=*-W]-=0KQM:P*[F)S/N69;CFW7'UQ/S)$
MG"U;1],UW!NZ;J^%:RL:]'%=JY3S35#TGB3@? Y[$W;?^'=_BC:??'WW?0.%
M>T+,.'9BQ>_Q;'\,SUC_ "SY>[9&3$Q/C$BY7JUV4,C#F_KW3JJ*[,7PO$>;8+]CB*H^,S'RGH\)C.&QX7M'SS
M#^.J*X]L1]M'K&+[+^'<3UHMU43_ "U3]]4B6E]7NF^L4TS@[MP:YK\J9JF)
M_7#TV-J^EY=$7,;4<>Y35Y334
MV[G#V'#=J]Z.F)P\3_EF8^DZ_F]9Q?8UAZNN%Q4Q_FIB?K$Q^232FNFKQIJB
M?BEN1YZ7UOZK:/$4X>\LVNF/5>KFJ'L-'[675'3HIIS8P9_YGL&&
M[4,INZ=[173\(G[O6L5V0YS:UFQX+5])[:%VCNQK>TJZOY55F[
M3'ZN)>PTOM@].,VJ*,W$S<.?7WJ*JN/HI>?P_&V18G;$1'OUC\XT>MXKL^XC
MPN^&FJ/6F8J_*=5>!3O2>O\ TKUB8C&W-:HF?5>IFWQ^EP]7@[RVIJ5,5X6X
M]-NQ/EQE4<_6\[8S/!8J-;-VFKW51+UW$Y1C\'.F(LUT^^F8^SN1\K.3CY$<
MV,BWD%*]6[2W2?2HJIG7:
MK]#,_P 9UM82O3VQI^>BX46E:KVS=W8]DWZXK^KAXS5NU)U:
MU*9G'S\7"B?YFW5''_,\#B>TC(['2BJJOW1^NCV+"]E7$&(_:131[ZOTU7RU
M7;5'C7'!S=Q:%IM$W,[5L6S3'G-5V$?6J=7.IFL\_NAO+49BKSIHNS
M%/T/,96?J&=7->;GW[]57G-=?/+P&*[5[-/3#8>9_P TZ?EJ]DPG8U>GKB\5
M$?Y:9G\]$@6K=<.EVC437E;NPYF/XM,U3/U/$:QVNNFVG]ZG!MY>=5'E-J(X
MGZ9A973:MT3S33$-_$>QZ_BNU#-;O2S131\)F?K+V7"=D>26.M^NNOXQ$?2/
MNN9U3MIY,S51HVT(\?P:[]4Q]53Q6L=JWJCJ7/W%7BZ?$^7N4=[^]$J-CUW%
M<:YYBNE6(F(]FD?D]GPG O#V#ZT86F9_FUJ_.='J]6ZK]2-;KFO.W;F>^\Z:
M)BF/U1#S>1J&HY=4UY>I9=ZJKSFN]5//ZWP'@+V-Q.)G6](ICF9]D++>U!U5KW?N6K:&E7^]I>E5S%RJF?"[=Y\?FCB)
M5][0W5&UT[V;=L8EWC5-3IFSBQ$^-//G5\7$3"Q*:KE=55R]JJGSJ
MGVOD7:7Q%W5$91AYZSUK]WE'QWGX/MW91POWE4YYB:>D=+>OKYU?#:/;J /B
MC[N                /IC8N7G9-K"P,>O(R;]446K5$!V=>@-K:F/:WEN[%HN:O>B*\:U,1/W/1/C^EY?
M0]AXN<3\387AC!SB;_6J?#3YU3^D>^=4,9<9@L
M/F%J;&)HBJF?*6S YABLLOQB<)7-%<;3"/KJ7T5WGTRR+EW4<.K*TN)_T>;:
MB9IB/5WO#B)> B8JCF)YB4GF;@86I8]>)GXMN_9N1Q51PLFW/$T7*?JGREP
M7RJY;KM5315.
M!OL9OC\+^QO54^ZJ7CL3D^7XS_B+%%7OIB?LKE@=L#J3C33&;IN!E4QYS$11
M,_12]9I?;2KGNT:MM"*?;5:NS/ZN(6PCS=CCC/L/MB)GWZ3^F=K_ *ZJ)
M_.$CN!U-V!J?$8.[=-O3/JIOQ,N^QM1PY'[?#1/NJT_.)>"Q/8U9G_ (;%
MS'^:G7\IA)L(Y,#JIU)TRJ*L7>6?'=\HJFF8^IZG3NTMU=P9CW77XR:8]5RF
M/\(>9L=J>6U]+MJNGY3]X>#Q'8[FMO\ 8W[=7^J/M*_(6:Z=VPM^XO=C-T73
MLF(\YYKB9_6]%A]M:]$Q&H;+JX]ZJG[S"Z@6]Z?VR]CWHBG/T34+%4^<^]F(_6]+I_:DZ49O'NVKU8LSZKE
M%4_5#RMGBS)<1X,33\9T_/1X7$<%<08;]IA*_A&OY:JOCPV#ULZ7:A335C[O
MP_?>43WH^N'>8>^=H9_'W)N+!N<^7%V(^MY6UF6#O_LKM,^ZJ)^[PU[*L?A_
MVMFNGWTS'V=Z.+1JFF7?WO4<:KGV7J9_Q?>F]9K_  +M%7Q51+7%=-6TL4T5
M4[PW@)(@
M                      VS713^%73'QR^->?@V_P!\S;%/]*Y$?XN35$;R
ME%-56T.0.JRMT[?NG=N#1Q_M3/U0S7,=A;/
M[2Y3'OF(:K67XN_^RM55>ZF9^SUPI?G]I'I)@]Z/\I[5ZJ/5117X_P#*\SG]
MK_IQB3,6,7.R>/*:(B.?I>,O<3Y/8\>)H^$Z_EJ\OA^$,]Q/[/"5_&F8_/17
M86RZAVU-*HYC3=HY5WV=^JG_  J>?S^V?N:]3,:=M/#LSZINU5?X5/$WN/\
M(;4?MM?=$_H\S8[-.)+W_(Y??53'W7="Q_4>U9U2S8J^YKN+A\^7N43/'T\O
M,:EUVZM:K$QD;OR:8G^131'_ $O$7^U'*;?[.BNKX1'YR\WA^R'.;O[6Y;H^
M,S^4)!:ZZ:([U=41'MEUF=NK;FFENE1,Y&\M/JF/.*+U,S];S&?VJ>D6)35[CJ]_)JCU6;<5<_\RQON
MQ/GS/QS,D4TQY4Q]#PU_M2S.O7NK=%/SG[O.X?LAR:W^VNW*OC$?:5W6I]LK
M:EJ)_Y]4R\EJG;/W#=YC2=IX]GV3H]K#JOGTS38N8.''^Q:IK_ ,(>2U3K
M5U/U:9G)W7DT<_S,S;^J7B1X7$<19MB_VV(KG^J7GL-PUDV#_886BG^F/OJ[
M#-W'N34:IJSMQ:E>F?/O95?_ )=?7WKD]Z]77N7/'5,^^7
MF:+=%J-*(B(]D:-.Y1'E1'T-05I@ X
M                                                !,Q$@Z?73C\Q[KEW*>+=N/;[9^9HPN$OXV[%G#TS55.T0HQ6*L8&S5B
M,37%-$;S,Z0\K9M7U7=O79[M%NB.:JI]D0N$Z2=E74]G*OVJ-2U:>)KRKM//=GUQ3'A''QQS
MX*IQ$1'$1Q$/LW#/9O;LU'%-%NB*?IX\Y=B#ZO113:IBBB-(C
MRA\8N7*[M4UW)UF=YG< 30                          'QS,O'P,6[FY
M=VFW9LTS7775/A3$>VS3LW35U'WOEZG-R
M?N'%JFQAT<^$41/C/T\O"M(CB.&K\J8[&7)O3K55.LOV)@<'9R[#483
M#QI11$1'P_7S &5J              "(JJJIHHIFJJN8IIICSF?81%5=46[=
M%5==4\4TTQS-4^R(75=G?L\1@18WQO?%BK*F(KP\.N/"U'JJJ^'_ ,O.9!D&
M*X@Q48?#QT\ZO*(_\VAX'B+B+!\-8.<5BIZ_NT^=4^D?>?)R.SMV?+>DVK&]
M]Z8G>S[E,5XN)VJ)_C?-X<+D(B(CB"FFFF(IIB(B/"(AJ_2^39-ALC
MPM.%PT:1&\^5>%
M
M
M
M
M
M
M                                     >4WWTSVCU%P*L+[MAUWM3T6BK5])B9F)MTS-VW'LFF.9GX^%\;;7
M11]U3[-.T]]^ZZII%,:3JLQ,Q79I
MB+=<^R:?*/CX6E;[Z9[QZF+>51$S:KCX)?"N(.#\QR"J:KE
M/-;\JHV^/H_0_#?&N5\2TQ38JY+OG15O\/XH]WR>6")B8Y@>J/;@
M
M                                      XCV #958LU_A6Z9^9K;I]Q
MGFS551_1GAN'=9AW69C1SL37]>P/]3UK,L\>/O;LP[O#ZJ=2-/F)Q=YZI3$>
MJ;]4P\L--O'8JS^SN51[IF&6[@<+?_:VJ:O?3$_943&[0W6'%X[FZZ[D1_.Q
M55_U.[P>U7U9Q./=LC!R(C^79G]I2 >2M\2YO9\&)K_U2\7>X8R6_&ES"6Y_
MIB/R5^P>V-OBWQ]WZ)A78_V(BG_R[_"[:-5/$9^SZZO;51D1'ZNZMB'D;7'.
M?6=L1,^^(G\X>*O=GW#=_?"Q'NFJ/RE=SC=L_9]41]U[=SK4^OBJ:OJI=OA=
MKWICD\>[4YUCG^58JG_!9>TF(GSB'DK?:5GM'BJIGWTQ]M'C+O97PY<\-%=/
MNKG[Q*^[%[3G2+)XC]WKE$SZJK%4.YQ.N73#-B)M;HQ:>?Y=<4_7*/>;=N?.
MBGZ#N4>JF&^WVIYG3X[5$_./O+QEWL@R>K]G=N1\I^T)(<;J1L3+F(L;LTNJ
M9_\ XNW_ .78VMS;-%==,_[-4P^M.9GT?O>I
MYM']'(KCZI>0M=J][_FX:/A5/Z/'7.QK#S^SQ/Q[AN'4J./\ ^*N?^7/L]0-]X_$6=W:G3$>'
M$Y%<_P"+;;[5[$_M,-/PJ_V8+O8S>_Y6+CXTS^J241W8W6+J;B_O>[,J?#CW
MT\_6[7&[1'5O%GFWN2)\./?6*)^N&VCM4RV?':KCY3]X>/N=CN:4_L[]N?\
M5'VE?X+&,;M3]6\:>:M0Q;WAQQ58HCY_)V%GM=]4+Y,?TRR7.RWB2C:U3/NKI_5=J+6;/;5
MN3-,7]EQ$?QIINU2Y^/VT-)J[WW1M>_1[.[///ZVJGCO(*_^?])_1CK[..):
M-\-\JJ9^ZY<6[V>V5L^J*9OZ)GTS/X7=MQ/'ZW86>V#TWN5Q3!17'[6O2J[S[K>SK7'EWK5/C_P SE6NU
M3TCN4]Z=6O6_@KHB)^MIIXGR:OPXFCYLU7!^?4;X2Y_IE6 4FH[4'1^NGO3N
M.FCX*N.?K+#7/]%7Z/=#QM/6+IC75%-.]=,YG_P#+/M_G8Z;_ /WEIG_%
M6QFF!G:]1_JC]54Y1F$;V*_]-7Z/6#R]GJ=T_P B)FSNW3JXCSXNOI_G&V+_
M /=.G_\ %3C,,)/6+M/^J/U5SEF-B=)LU_Z9_1Z0>?L[_P!EY$S%GKO32S$37O/3(Y\O],^=76;I?33-4
M[UTSB(Y_?4)S7 1O?H_U1^JR,FS&=L/7_IJ_1[04_P#\_'2GGC_+' _XCBU]
MHGI'17-$[MQ9F)X\*H4SGN64[XBC_5'ZKJ>'LVJVPUS_ $5?HJ4*5W>TST?M
M7)MSNBS,QZXF/_+CU]J3I#15-,:]-7'KIIB8^M7/$.54[XBC_5"^GA7/*ML)
M<_TS^BK@HY<[5W22BJ:8U'*JX]=-NGB?^9PKG:YZ84=[N1J%7'EQ9I\?^937
MQ3DM&^)H^:^G@W/Z]L)7_IE7 4!O=L;8%-$S9TS5*J_5$V8B/[S@W^V7M>GC
M[GT#-K]O>IX_Q9JN-,BI_P#DT_5IHX"XCKVPM7QTC[KC!;)?[:6!355&/M2[
M7$?@]ZJ8Y<"[VUJ_P##/5QYD%/_ #_I5^C71V;<2U[8?3WU
M4Q]UU0M&R.V?N2N:ON?:>+1$Q[WF]5X?J=9?[8O4*OCW#0]/H]O-R?V66OM&
MR&F=(N3/],M=OLLXDKWMTQ[ZZ5Y@LFN]KCJG7SW+.#;\?53$_72Z[)[4?5S(
MFJ:=3QK/>_DV*)X_4RW.TW):/#%<_P!,?JUT=DF?U>*;.]'$]VS3'U0ZK)ZO]2\J9FYNS+CF./>SQ]3'7VJ9;'@LUS\H^\MUO
ML=S2K]I?HC_5/VA(C5&GXU?[-]KL9
MO?\ -Q/O*XJ^J7397:9Z18O,5:_77,>JBQ5
M/U+#NY3ZZ8D]SM_R*?H8+G:GF=7@M41\Y^\/)6NR#)Z?VEZY/^F/M*]7-[7/
M2_%Y]QJS;_'/X-BJ/\'49';/V33$_40U8+G:5GE>T
MTQ[J?UU>2M=E?#EN/Q4UU>^O](A=%F=M*S/,8&SKWP37D1]7==%F]LG=M<3]
MP;?QK4^KW28J_P#"WH>.N\=Y_=WOS'NB(_*'DK/9YPW9VPT3[YJG\Y5GS>UK
MU4RJ>+-.GV/AIL__ .SHLKM']8LJ9G_*2BS$^JW15$_WE-1XZ[Q/G%Z=:\37
M_JEY6SPKD=C]GA+?^F)_-[',ZR=4L_G[HWKJ4<^JB]53_BZ3,W=NO4)F
MH7N?/O7IEU(\;=S'&7OVEVJ??5/ZO)VCBF8]?=\/&5X'3/HALWIKBTS@X=.7GS'-
MS+OTQ57,_!SSW?F>Z\.<$8_/9B[5'=VOXI\_='G^3T;BCC[+>'(FU$]Y>_AB
M=O\ -/E[MU#^DO91S-0FSKG46KW+&GBNC MS[ZJ/]N?\.%TFB:%I.W-.M:5H
MN#:Q,6S'%%NW3Q$.>/NV2<.X#(+7)A*.OG5/BGX_9^=>(.*Q:KNW;M44T441S55,^J(;L7%RL_+M8&#CUW\F_5%%JU1'-54
M^R%W_0+LZX^U+5G=N\;%-[5[E/>M8U=/-./\T^OS]3V'AWAS%\18GNK$:41X
MJO*(_7V/7.)N)\'PQA>_Q,ZU3X:8WJG[1ZRZ[L^=G:UI%NQO/?&'3SCA?.9]
M9?E?/L^QG$6+JQ>,JUGRCRICTB/_ #4 >6>%
M
M
M
M
M
M
M                            ' UC0](W!A7-.UG3[.7CW(XJHN4\Q,.>
M(UT4W*9IKC6)\I3HKJM5171.DQYQNM9ZI=DFJF;VL].\B(\ZZL"YY3\%$^KY
MY6VZMI&JZ#FUZ=K6GW\/(MS--5%VGCQ^"?*4G#R6^^E^S^HF%5B[BTNW)NV_XOWX
M]_\ %\>OM1TBL_4_LQ[NV75=U+;E-6KZ73S5Q1$S>HCV=WQF5&*HJMW*K-VB
MJBY1/%5%4<54S\,/B^9Y3C,HNS9QEN:9^D^Z=I?=LKSC YU8C$8&Y%=/LWCW
MQO$^\ >.>2
M
M                  .(.(]@#IQ'LAIW:?Y,?0U :=VG^3'T'KFD-_N^1_ZF]_Q)/=\C
M_P!3>_XDM@<]7J:0W^[Y'_J;W_$D]WR/_4WO^)+8'/5ZFD-_N^1_ZF]_Q)/=
M\C_U-[_B2V!SU>II#?[OD?\ J;W_ !)/=\C_ -3>_P")+8'/5ZFD-U5V_5'%
M61=F/ZKU=UF&WW.G_:_2
MD]SI^'Z9;ASFGU-9;>Y3[/UM>Y3_ "6HYJ:RT[M/\F#NT_R8^AJ!JT[M/LAK
MQ'L #B/8 .
M
M       UHHN7;M-BS;JN7:YXIHHCFJJ?@A6_I=V7=S[MJLZMNSO:5ID\51:G
M]^N1[./":7D\KR?&YS>[G!T35/TCWSY/%YMG6!R.Q_:,?E[>TR]F9%R>(BBGWL?'/E"Z/I3V4--TFJSK>_[E&?E1Q73AQ^]T
M3[*O7,_%*M>S.GVU=@Z?3I^V]+MXU,1[ZYQ$W*_Z57K>C?;>'.SO"9;I?Q_^
M)<]/W8_7X_)\$XH[4,;FG-ALLUM6O7]^?C^[\.OM?##PL33\>C%PL>W8M6XX
MIHHIXB(?<'T>(BF-(V?*JJIJG6J=9 '7
M  !LNW*;-NN[7/%-%,U3/P0WO!=<-V_Y'=.-6U.W7W;]=F;5CQXGOS_^CEFQ
MN*HP6'KQ-S:F)GY-> P=S,,5;PEKQ5U13'QG19OUSWG7O?J1J>=;O37B8E:I]LM7Y+Q^,KQ^*N8FYO5,S\W[0P&"MY=
MA;>$L^&B(B/A'W &1J            '+TC2-4U_4;.D:+A7,K+OU131;HCGS
M]<^R'+VKM77-Z:S9T+;V'7D9-VJ(JF(][;CVU3ZE\'1KHEH72[3:,B;=.3K5
MZG_YC*F(F8YCQII]D>?K>W<+<)XGB.]KX;4;U?:/67IW%W&6$X6L?B_%>JC\
M-'WJ](_/R=#T,[/FF=/\>WKVX+=O,UR[3%43,%RC#
MTX7"4\M,?.?;/K+\O9OF^+SS%58S&U\U4_*(](CR@ >0>,
M
M
M
M
M
M
M                                            :54TUTS353$Q/A,3
M'A*E?4WL\[*ZA6Z\JWCTZ9J7C-.1CTQ',_#3Y?J55&+'9=AHG13?/3>_77J6GUY6GQ/%&;9CFB?C>!
MBJ*HYB4GV5B8N=8KQLRQ1>M5Q--5%<ZZILNY1I.=/-4VN
M/]#7/Q>?ZWQ_B#LSNV=;^4SS1_!._P )\WW'AKM8L8CEP^=4\E7\<>&??&\>
M^.GN6>#T&\-@[LV)J%>G[DTB]9[L\4WJ:>];J^*J.8_6\_$Q,IFFJ-XGI+[!8Q%K%6XO6*HJIG:8G6) %*T
M
M
M
M
M           #R\9=UM79FY][:A1INVM)O95RN>._%/%NGXZI\/UK;-BYB*XM
M6:9JJG:(ZRKO7K>'MS=O5133&\S.D1\723,1',R]WTZZ,;WZD9%$Z9I]>-@3
M/O\ ,O1Q1$?![97 ]+NR=HFB>XZOOJ[1J>9'%=.-$?Z*W/LF/7/SK@6G^&-Y]\^7YOD'$W:OA\+KA\FC
MGJ_CGPQ[H\_CT]ZF?3'L^;+Z=VJ,FK'C4M2XB:LG(IB>)]?%/E"J41%,133$
M1$>40U'V/ Y?AV=N.NWB:-M>SI_Q7/+).UEGUY?4^G%JJYIQ,;N1'LYXG_%Z/VAXN<+D=R*=ZYBGZZS^3Z'V
M7X.G%\16ZJMJ(JJ^4:1]947 ?F]^H@          #R\9 >EV!T\W)U(UNWHV
MW\6J:>8]WR)C_1V:?;,NYZ4=&]R=4]2IHQ;=>)I=JJ)OY==,Q$QZXI]L_3YK
MX=B;!V[T]T2WHNW\*BU13$3^N5>NJ9^E[_PCP3?SRN,3BHFFQ'SJ]D>S
MVOG?&G'V'X5/MJ]OI'S=3TLZ3;=Z7Z-1A:;8INYER(G(RJZ>
M:ZZOC]4/= _0.$PEG V:L^54=*H^+V#(N*,SX=N<^!N3$>=,]:9]\?>.J
M,O7M UO:^?5IFX=-OX.13,QW;M$TQ5\,<^<. DBW;L+:N]L&O!W#I%C(IKCB
M*YIXKI^*J/%:_P!2NR7KFA^ZZGL3(JU'&YFK[DK\+E$?!ZI^>7QC/^SK'Y;K
M>P7^+;]GBCX>?P?>.'.T_+#JF%>Q
M^NQY1/X8]]7VA;STQ[).H:C%K5>H=^<:S/%=.%9GWT_!5/AQ\7"Y
MW;6T]O[1P*--V_IEG#L41$<6Z(B:OAF8\Y=N/M>2\-9=D-'+A:/Q>=4]:I^/
MVA\#S_BS-.([G-C+GX?*F.E,?#[SU 'GGK8
M             L9[4^/LTU4_%%-,+YEI7;+VU$5
MBO9?QM(JL;GW_13?S8XKM8,QS1:]?OO;/TPN.LV;6/:IL6+=-NW1'%--,<1$
M/KW"?9Y-?+C,WCIO%'_V_3YOBO&?:=3:BK Y)5K5M-SRCV4__;Y>KA:%H6E;
M;TRSH^BX=O%Q+$<46Z*8B/C\/6[ 'V:BBFW3%%$:1&T/A%RY7=JFNN=9GK,S
MY@"2
M
M
M
M
M
M
M              #QV^^D^RNH>--K<&D6Z[W'%&13$1%VW'_5\T+UFDQS'$O6,\X1RS/8F;U'+7_%3TGX^OQ>W\/<
M;YMPY,46*^:W_!5UCX>]1/%5N[1-%43\4MB07J!T3
MV)U#L5_NKI=%C+F)[N3CTQ17$^V9CCO?/*USJ)V8]];.KNYNB6IUG3:.:N]:
MI_TM-/PTQS];XQGO .9Y1K2W_%5T^4;S^3TGB'C[*.'XFW57WEW^&GK\YVC\_8MHZ<=G/?6_JK>
M7E6)TC3:IB9O9%/%=4?!3X3^I=5T[Z%;$Z>6J+N#IM.3J$1[_+OQ%5
M$*AT446Z8HMTQ333'$1$<1$-S[3D7!>69'$5TT\]S^*KK\HVC\_:^#<1\?9M
MQ#,VZJN[M?PT]/G.\_E[&D1$>$1PU![<](
M                'A^LFPK74/8N?HD4Q.331-W&JG^+^$8.7AY6G9E[3L^S59R<:N;=VBJ.)
MIJA\EU_:5Z#7M8FYOW9^'->;3$U9N-1'[Y3'C-<1'K\9Y^):AXQ55153--5,
MS353/G$QYQ+\N\19!B.'\95A[T?A_=GRF/\ S=^O.&N(L+Q+@:<7AY_%M53Y
MTSZ>[TGS@ >!>?    "9B(YF8B'/T'0-;W3GTZ7MW3;V=DU3QW+5,U=WX9X\
MH7+=+>R3:M>XZQU&O>Z78F*Z<&U5/E,
M?%X#/N)\LX5,=:I]T?>>BB'3CI#O'J;FQ:TC"KQ\*F8]US+U$TT
M1'^SSQWOF7E=+NB>TNF.)17@8M.1J=5'%[,N1$UU3\'AX0]QIFEZ=H^';P-+
MP[.-CVJ8IIMVJ(IB(CX(L_YI\_=L /='H(
M
M
M
M
M
M
M                                        TJIIJB::J8F)\XF/-J I
MQU"Z#["Z@V:Z\O3:,/-G\'*QX[M<3\7E^I:_U%[-.^MC]_+TNW.MZ?3X^Z68
M_P!)1'^U$\?J7SCU+/."\KSO6NNCDN?Q4])^,;3_ .=7NW#W'V;\/Z6Z*^\M
M1^[5UCX3O'PZ>Q%[9F7QO
M/. LTR?6Y;I[RW'G3O'OC?\ .'W+A_M%R?/-+5=7=79_=JVF?95M/QTE2,:W
M*;EFY-F_;KM7*9XJHN4S35$_#$^+1Z3,3$Z2]] '
M
M
M
M                                                 !I,Q$Q'KGRC
MUR.M3GQB/.9\HCQF7O\ 870SJ#U"FF[IVF586',^.3E4]R./;%-7'/S+F^G7
M9>V/M&+6=KEF-9U&CBKOWHB;=,_!3/E]+V[)."LTSN8KHHY+?\572/AYR]-S
M_CO)^'XFB[B.^^HF13]PZ=7A8,_A9F13Q3Q\$>?
MZET73?LR;'V3%&9JEO\ =G48\?=;\>]HG_9B./UPJ_9L6<:U38L6Z;=NB.*:
M:8XB(?1]CR+@/+,FTN5QWESUJV^$;?F^%\1=H^;YYK:M5=S:G]VF>L^^K>?A
MI#99L6<>W%JQ:HMT4QQ%-%,1$-X/=XC3I#T"9F9UD '
M                             &E5--4335$3$^$Q/K6]];>S)B[IOWMS
M[)]SQ-2F)JN8O'%N_/P>R?HCQ7"CQ>;9/A,[P\X;&4ZQY>L3ZQ+S&29[CN'\
M3&*P-?+/G'E,>DQYHS-;V]KNVLRY@:]I61AWK=4TS%='A/Q3'@ZZ*J9\IB4E
MNX=I;;W7C_'V[+.U_+[MN(S"S517_+I5'UF)CZK(.8]K2*HF
M>*>:I]D1RO6L=D?I9;NQ7=MZA^9^S9B.US)+5.MFBNJ?=$?696/;=V#O3=F13C:
M!MS+R>]/'?[O=IC]+A7G8O8[RLB;6?OO6(MT>%4XF/Y_%5,Q]4KI<3"Q,&S3
MCX>/19MTQQ%-$<1#[O=\I[-@YSVL9KCXFW@:8LT
M^L=:OG/2/A#S^U-A[4V7AT86WM&Q\6FF.)JIIYJGX>9YEZ 'T*S8MX>B+=FF
M*:8VB(TA\QOXB[BKDW;]4U53O,SK/U %JD
M
M
M
M
M
M
M                                                        :33%
M4335$3$^$Q/K:@*=;_Z$; Z@457,_2Z,3+F/>Y.-3W)B?;,4\<_.MDZ@]F#?
MFTKES+T&U.M:?3S5$VX_TM-/PTQ''ZU\#28BJ)BJ(F)]4O4\[X,RK.XFJY1R
M5_Q4])^/E+W3(./*K=<<
M54S\+:D(WWT7V'O^Q7&K:/:MY54>]R;4=VNF?J_4MHZA=E/=^V(NYVUK\:QA
M4\U1;\KM,?#SQ$_,^09WV?9IE6MRQ'>T>M._QC?Y:OMV0=I63YSI;OSW-R?*
MK:?=5M\]%#A]LW"SM,R*L74L*]BWJ9XFB[1-,_K?%Z)5351/+5&DOH43%4N9XB(]:JW3_
M +-_4#?'N>5EXW[CX%<\^ZWX]]5'P1'C],+F.GO9RV!L:FC(NX4:GGT\3]T9
M,J^T;R]&S_M"R;(M;?/WMR/W:.OSJVCZ
MS[%K&PN@743?ERU>LZ77I^GU\3.3DQ-,3'^SX>*YOIYV9-B;*KHS\^W5J^?'
M$S:(GX*.9A5^U:M6:(MV;=-%%,<133'$0WOK^2<"97D^ERJGO+D>=7E[
MHV_-\2X@[1LXSS6U15W5J?W:=YCVSO/TCV/G9L6<>W39Q[-%JW3X4T44Q3$?
M%$/H#W2(B.D/09F9G60!UP
M
M
M
M
M
M
M
M                                                   !Y/>G2[9.
M_K%5O<6BV;UR8XB_33$7:?BJX6X=0.R'KNF57,_8N?3FX\TY%QEF_#\Q&%NZT?PU=:?EY?#1&5
MK6A:UMO+JP=>TO(P;U,\<7KT^FU
M7R\_A\GVC(>U;+,PTM9C3W-?KO3/QWCX_-:X._W5L'>.R?B8F.8E\ZOX>[AJYMWJ9IJCRF-)?3[%^UBK<7;%454SM,3K'SAJ
MI6@
M
M
M                                                       <\.SV
M_MC<6Z\JG"VYH^3G7:IXXMTF8=[+OUSQ%NS1-<_1"X?878_U74(MYN^]3^Y+<^^^
MY;'C5/P53/''S+B]G],-E;'QJ_7/P]Z>9?0,F[.,RS#2
MYB_\*CV]:OEY?%\WSWM1RC*];>#_ ,:Y[.E,?U>?P^:U78/94WMN?W+.W+"H8^M9-P
M;E62Z56K?-7_ !5=9^'E#XOGW'>IZ/I>LXU>'JF#9R;-R.*
MJ+E/,2HAO[LE[0U_W3,VI>G1LNJ>]W*?&U,_%QS^M7L>+S+)W
MSCW3N\QE.?YED=SO,!>FCV>4^^-I1\[XZ(=0MAW*JM0TBYEXL3[W(QJ>]$Q[
M>[',P\%,]VJ:*HFFJ/.FJ.)CYI2@7;5J_;JM7K=-=%4<54U1S$PICOKLZ].M
M[17?JTR-/S*O*]BQ%'C[9B..7RW.>RZ8UN97<_IJ^T_J^OY'VO45:6LXM:?S
MT?>G])^"PT5HWUV5]_;8JN96@=S6<*GF8[GA=B/Z,Q
M,BB>*K=ZB::N?BE\PS')L=E-?)C+4T^^.GPG:7UO+,ZR_.;?>8"[37'LGK'O
MC>/D^(#QCR8
M
M
M                                                       -^+8R
M,[(IQ,''NY-^OPIMVJ>]5/S0JSLCLQ]1=V56\C4L>G2,*J8F:KW[Y,?T9X>1
MR_*<;FE?=X.W-<^R/SG9X_,LVP.46^]QUVFB/;/6?=&\_!2+F.>[YS/E$>,R
M]ALSI+OW?=^FWHFAWJ+,^=^_3W*(CV^^XY^9=KL7LR=/-GU6\O+Q)U;-I\[F
M3[ZCGX*)YX5:QL7&P[-./B6*+-JB.*:**>(B/B?3ES-+G+'\-/6?C
M.WRU?)L\[7K%K6WE%KFG^*OI'PIWGXS"W;879 T/3IHS=[ZC.I7HXJ]PM^%J
M)]DQ,Z>GV\]EY%6/N/0,G&B)\+G=YHJ^+A)&XN?IFGZICUXFHXEK(LW(X
MJHKIYB8?/\X[-LMQVM>#F;57LZT_+])?3,D[5LUP&EO'Q%ZCUGI5\XW^,(Q8
MJB?*6J]??/95V#N7W7*T.U.C9EZQ.L:P .
M
M
M
M                            #?CX^3FW8L8.+>R;E4\119MS7,S\SM-,
MU3I3&LDS$1K+8TF8CSE5;9/9KZC[QBWD7\6G2<2KCFYD?A8E7_8_92V#
MMOW/*UZBK6LNCQF;W$VN?@IXY_6]ORC@?.,VTJBWR43YU=/E&\_)Z7G7'^1Y
M+K17=[RN/W:.OSG:/FM(VUL7>&\._%/%-/Q\J\;(['69E1:
MS=\:S[C3X53BXTBSH
M>@XU%5,<3:N7K(B(CB(XB&H^@X?#6<)1%NQ1%-,>41H^98G%W\;
MW8XOV::
M\K8FL]_SF,;*\(CX(KF9F?H75#U_->%LJSB)G$VHYOXHZ3\X^^KV?)N,,YR*
M8C"7IY?X9ZT_*?MHC?W5TXWQLFNJGGF>+?A)IN43
M'Z_)\WS')?BB>/U*G8N'B85N+6)C6
MK-$1Q%-NB*8_4^CY3V67:]*\RNZ1_#3UGY[?+5\NSGM@L6];>569JG^*OI'P
MICK\YA;!LKL<=^FC*WUK-4S$Q,XV-Y?IQ,3^I7C:72S8VRK%-K0] QJ*Z>/]
M+7A#4'GWK0
M
M
M
M
M
M
M
M
M                        Z;<6SML[LQYQ=PZ-C9U$QQ_I:(GCXG9]SK]_
M;Y]D1''"A6\>SWU-V9%5V_I/[HX]/E=Q/?S,?T8YE?VTF(JB8JB)B?.)>DYK
MV>Y/F.M=NF;=7K3M\MOEH^@9/VG9YEFE%ZJ+U'I7O_JCK\]47]ZU?Q;DV)HNT31/T2VI%=U]*MB;RLS:UK;V+55/_U+5N+=?Z5,1*AV\.QMBS37
MD;)UVNW7/,QCY,M>$F+M/LZ3\I^TOJ>4=JN38_2C&1
M-FKV]:?G&WQA:V/;[KZ*]2]FS77JNW+]W'HY_P#F,>F:Z./;SQ#P\SQ7-NJ)
MIKI\)IGSAZ%BL%B<#7W>)MS3/MB8?1<)C<-C[?>X6Y%=/K3,3^34!E:0
M
M
M
M        ;\2QD9]^G%P<>YD7JIXBBW3S,RJ9M/LX=4MTUT7*]'_5,)F(\9GA]\
M'3]1U6_3C:7I^3F7:IXBFQ:JK^J%VVT>Q[M+3_I9.I7X\:K5,S;H^FF
M?'Z%:=O['VIM>Q1CZ)H6'CQ1Y5Q9I[_Z7'+Z!E?9AF.)TKQM<6X]-Y_3ZOF^
M;=K65836C 43=J]?#3]>L_*%FNS^S!U*W53;RB7+E=VJ:[DS,SYSUD 30
M
M
M
M
M
M
M
M
M                                             ;+EJU>I[MVW173[
M*HB8>'W9T3Z<[QHKG5-NX]-^O_ZUN)IJB?;Y\/=C-B<'A\;1W>(HBJ/;$2UX
M3'XK 7.]PMRJBKUB9C\EJV[^QK?M3DG4/9U
MVJG6-MY/N=/_ -6U$5T\>WPF92*-MRW;NT3;NT1535'$Q,>$O1SK'RG[2^BY3VK9S@=*,7$7J?;TJ^)1?5\VZIHNT5451YQ73-,_K$
M@VZNAW37=]-4ZEMO'MW:N?\ 36*(HKY]O/"BN[NQK=B:K^S-?XCGWMC)CG_F
MF8?/M6'TNT^SI/RG[/I>5=J>1X_2G$S-FK^:-:?G'WB%L8]ONGHK
MU*VA57^Z6W+UZU1YW<:)NT\>WWL>#Q%?>M5S;OT56JX\Z*X[LQ\TO1L5@<3@
MJ^3$VYIGVQH^@X3&X;'T=YA;E-=/K3,3^0 RM(
M
M
M                                    #2:HI\9F(!J.3IVF:IK%Z,?2
M--R?&WJ:(]LQK\MU*)F(\9GA]<3#S<^Y%G PK^3Y1S\4\JP[OT65
M[2[.G4_=<6[TZ3^YV-7/[[DS'A'Q1/*M.T.QSMW FC(W;K%W4;D<3-JWX6_B
M\8B5QH^@Y9V>9-E^E5RF;E7K5M\HZ?F^:YKVGY[F.M-FJ+5,^5$=?]4ZS\M'
MF]N=.ME;3M4VM"V]B8W=CCO11S,_3R]'%,4QQ3$1$>J&H]TLX>UAJ>2S3%,>
MD1I^3T&_B;V*KFY?KFJJ?.9F9^H N4
M
M
M
M
M
M
M
M
M
M-MRW;NT3;NVZ:Z9\Z:HYB7D-S](^GV[:*J=7VYBS5,?AVJ(MU<^WFGA[$9\1
MA;&+HY+]$51Z3$2TX7&8C!5]YAKDT5>L3,?DMHW3V-=)O=^_M+7[V-7,S,6;
MTEYEV=9
M-CM:K5,VY_EGI\IU>_97VHY[@-*;]47J?YHZ_.-)^>J,+,Q/ZE(]U=D38FK=^]M_(O
MZ5>GRIHF/A9CV7YAA]:L']CZM9I\8[GO*N/]Z84JUC:6Z=OW:K6L[?S<::9X
M[TV:JJ?IB.'HV/R+,SZ%EV?99FT:X*_37[(GK\IZ_1U(T[
MT<\3/$^R?"6KQ+RX .
M
M
M   3,1XS+6W37>K[EBW7=JGU6Z9JG]3L1,](/:T'K=M=)^H>[+E-.D;9RNY5
MY5W8]SC_ )N%7-K]C?<.9W+^Z=P6<6CF)JLV:9[W'LY\8>=R_AC-LTZX:Q5,
M>LQI'SEZ_F?%6391K&+Q%,3Z1.L_*-?JMUFJFF.9EVNB;5W-N6]38T'0LO-K
MJGB/,\_-PJ7@:/I>E6*7=E>)N:58^]%,>E/6?GM^;YWFG;#@[6M.76)KGUJG2/E&L_DLSV
MGV3^HFN31>URNQI-F?.*IF;G'Q3'"LFTNR1T_P!#JHR-:NY&K7HB)F+DS13S
M\5,JZ#WW+N \ER[2>ZYZO6KK]-OH^M,7>[IGRHZ?7?ZNGT7:&V=
MO6:;.CZ)AXT4>4T6:>]]/'+N >W6[5%FGEMQ$1[.CTB[>N7ZIKNU35,^G:I:FQJ.%9
MR;<^=-VB*H^B7*$:J8KCEJC6$J:JJ)YJ9TE2_='9QZ7;G[]RYH=.'>J\J\68
MM\3\40I)NGL:95J*KNT=Q17[+.13_P!4RNK'KF8<(9-F6LWK$1/K3^&?I]WM
M>6<W+F5:H_^IB\W?#V^$/!95C)
MP+LV,_%NXUR)XFF[1-,_K2?U4TUQ--=,51/G$QRZ+6MB;0W#:FUJVW\*]$QQ
M,^Y1$_3'B](Q_959KUJP-^8]E4:_6-/R>_Y;VQWJ=*VB=/I.OYHV8F
M)\8GEJO2W/V2NG6M37>TJK(TJY5S,>Y3-4<_[TRI5N7L?;RTVFN]M_5\?4**
M?*BYS%R?HCAZ3C^S_.\#K,6^>/6F=?IO]'OV7=I'#V8:1-WNZI\JXT^O6/JH
M$/5:_P!*NHNV*ZJ=8VIF6Z:?&;E-,33Q]+RMRFNS5W+UJNW5[*J9AZCB,'B,
M)5R7Z)IGVQ,/=,/BL/C*>?#UQ7'K3,3^0',3Y2,Z\
M
M
M           !I,Q'G(ZU'UQ<3,S[D6L'$O7ZZIXB**)GE[C;G0KJEN>JFK$V
MQ?QK,SQ-W(\(CX?!LPN7XO&UJ6X)IN9.#9TVS/',WZ^*^/Z,\+
MVM.T#1-)MTVM-TK$QZ:(XCW.S3$_3P[![OE_99@K6E6-NS7/I'2/O+T#,NV'
M'7=:B:IB:C;I\8
MIF.Y5/SS*\T>JX[@/(\=K,VN2?6F=/IM]'N>7]I'$.7Z4]]SQZ5Q%7UW^J.7
M7^EO4+;-=5&J[7S(BCSKM437N47;%7=R+%VS5'JN433/ZTG]RU;O43
M;NVZ:Z9\XJCF)>9UWIAL/<=NJWJFV<"N:O.NFQ337],1R].QW93'6<%?^%4?
M>/T>\9?VR;4X_#?&B?M/ZHY(JB?*8GXFJ\W<'9#Z=:G55=TF_F:;7/EW;DUT
MQ\W,*9;B['>\,*:Z]NZSC9M%/C$7N+8+K%OGC^6=?IO\ 1[O@
M.TCAW'Z1WW=SZ5QI]>L?5;^/;ZWT2ZI;>[U6?M3)N443XUX]-5RGCX^'B\NQ
MDZ?)B[3W7JN)P&*P=7+B+=5,^V)A[CA<=A<='-A;E-[C6ZOX^5%5N./;Y-N%R[%XV>7#6JJO=$RQ
M8O,<'@(YL5=IH_S3$?F\ TFJFG\*J(^.5QFW.QMN#)JIKW/N"UBT^=5./3%<
M_%SS"INW>R=TRT:J+N=:R=1N1X\W;DQ3]',O;,#V>9YC.M=$41_-.GTC67IN
M8=IG#V!UBF[-R?Y(U^LZ0LJL8^5EU11B8>1D53/$1:M55_5#V.W>C/4O=%=,
M:=MC(MTU>55__1QQ[??<+[]&V#LW;]NFWI6W,"QW?*JFQ3WOIX=_3333$4TQ
M$1'E$/<,#V4VJ=)QM^9]E,:?6?T>CYAVQW)UIP&&B/;7.OTC3\UH&W>QONO-
MXN;BW!C8=/G-NU1,U?%S$S"JNW.R?TSTBFBO4[%_4[U/$S-^J)IY^".%:Q[G
M@.",DP'6BS%4^M77\^GT>BYCVA<0YETJOS1'I1'+^77ZNBT/8^TMMT11HF@8
MF)Q''-NV[R*::?"FF(^*&H]HM6;=BGDM4Q3'I$:/3[U^[B*N>]5-4^LSK/U
M%BH
M
M
M
M
M
M
M
M
M
M              !MKHHN4]VY135'LF.8=/JNS-JZW1-O5-!PK],^?-J(GZ8=
MT*[EFW>CEN4Q,>V-5MJ_=L5?/]+AX#4]H[LT6J:=6
MVYG8LQ/'OK?,?JY26OCD8F+EVYM9-BBY1/G35',2]4QG99@+NLX6]51[]*H^
MTO<\#VPYA:TIQEBBN/6-:9^\?1&%5,T3W:Z:J)CU54S!$Q/E*0W7.C/33<--
M4:CM+!FJKSKIM1%7TJ?:]V0^GF?3,Z->S-/N3Y<7(FB/FB'JF,[+\TLZSAZZ
M:X]\Q/UA[C@NUO)L1I&(HKMS[HJCZ3K]%F8N'USL9[IQYFK0-S8N3'JINVYB
M?BYFI3_7NSSU5V_WJK^@?=-%/\;'N17S\T=8'K>P]6GK$:Q]-7M^
M"XPR',-(L8JC6?*9Y9^56BG [#4-N;DTFN:-3V]J./,>?>QJ^/IX==-44SQ5
M[V8\XJ\)>!N6KEJ=*Z9CWO8K==%V.:W,3'LZM1I$Q/E,2U5I
M
M                                           -)F(\YB :C2*HJGBC
MWTSY13XS+LM.VUN;5ZNYIFW=2R)GUTXU?'T\++=FY=G2W3,S[$;ERBU'-43S3_P!NJW29B/.8
MAK1WKE7US)K&L8:W7.8HXC]?"H6W^R[U4UJ:9S,&SIE%7KR)]7^
M[RODLX]C'HBU8M4T41Y13'@^CVO!]EF7VM)Q-VJN?9I3'WGZO3L=VPYE>UIP
MEBBB/6=:I^T?1:_H78MQZ:J:]R;KNW(]=&/3''ZZ52]N=FGI9M_NU5Z+&==I
M\KE^JKGZ(GA54>VX+A#)<#UM8>F9]9_%^>KTS'\<9_F.L7L35$>E/X8^FCJM
M-VMMS2+<6M.T7#L4QY=VU'UNTIIIICBFF(B/5$-1[#1:HM1RT1$1['J]R[[53/LF8_)0C6>Q_TXU"NJYI^3G8$SY13#USL9:Q9[
MT[>W/1?_ )-.11%'ZXY79CUW%<#Y%B][$4S_ "ZQ_M]'M6#[0^(\'I$8F:H]
M*HBK\XU^JP_6>S+U=TFJ?*?.
M:K,Q"21\KF+BWO"]C6J_Z5$2]:Q799E]SKA[M5/OTG]'M>#[8821ZGT_V7K,S.I[;PK_>\^;?'UE.KS55;T*G#KJ_C6*IY_7,O6\5V5X^WUP]ZFKWZQ/WCZO:,)VPY7=T
MC$V*Z/=I5'VE8F+L=:[%^WKW,Z'N;,QI]478IF/U4O%ZQV.M[87-6E:]@YE,
M>4515%4_JB'KN)X#S[#=>YYH]DQ/W>T83M$XFF(Y9_FB8^VB@0J/K'9YZ
MM:/%5=S;-=^W3_&M5T^/ZWC\[9V[]+Y_=';6?8X\YFU-7US5
M3[Z9>RX7-\OQL:X:_15[JHG[NH&ZY:OV9XO8]ZW/^W;JCZX;._1_*A@FF:>D
MP\A'7K#4!P
M                                          !IWZ?Y4-]NU?O3Q9QK
MUS^C;JGZH=BF:ND03TZRVCN,#9F\-4F/W.VSGWXJ\IBUW?KX>PT?L[]6M8[M
M=&VZL>W5_&NUT^'SC=C#;MB8JUOP8;@
M+/L3I/<\OOF(^[UK%]HG#F$UUQ'-/\L3/VT6F5513'-4\06IF_5W+%-5VKV4
MQRONT7LS]*-(FFNO0:JGG]4P]MIFP=F:-Q^YNW,*QQY<6^?K>Q87L
MKQ]SKB+U-/NUF?M^;UC%]L.66M8PUBNOWS%,?>4?ND]/-]:[-,:3M34[2/U>K8SMAS*YK&%L441[=:I^T?1:?H?8RU6]W9W#N>FQ_*IQZ(
MK_7X/=Z+V0>FNG5TW-0O9N?,><57*J(GYHJ5U'LN$X(R+">&Q%4_S:S^?3Z/
M5,9VA<1XW6)Q,TQZ4Q%/Y=?J\7HG1SIQM^FFG VOAS-/E5>M4W)^FJ)>KQ=,
MTW"CC"T_&QXCU6K5-'U0Y(]CL8/#X6.6Q;BF/9$0]6Q./Q6,JYL1L6
M;]/%SS,\%_P /B*Z?=5/Z
MK?=5['.Q\CF=+U3.Q9GRBNYWXCYO!XW5^QAK5GFK1=UV;WLIN6>/US4NT'@L
M3P+D.)WL13_EF8_*='L>%[1>),+MB)JC^:(J_.-5CVI]E'JOIU,UV+6%F1'\
MF]33,_KEY+4NBW5'2N].1M+*K[OG[C3-SZH2'#P6([+LJN=;-==/QB?M#V'#
M=K^<6_V]JBOX3'Y3]D9F;MS?>QJ_P#PZ^OO6I[MZBJW/LKC
MN_6DYO:7IF3_ *QIV+=Y_EV::OKATVH=.]DZI$QF;8TZOGSF,>B)_5#PE_LH
MJ_Y&)^=/Z2]@P_;+:GIB,)/]-7ZPC=BY1/E7'TMT3$^4K^-3[.O2?5.9N[;I
MMU3Z[=VJGCYHEY+4>Q]TYRZN]BY>;B?T:IJ^NIX2_P!F&<6Y_P .JBJ/?I^<
M?=Y[#=K60W?VM-='],3^4K-!=)J78MQ.:ITG=V13'JIN6:7F-1['.^+$35IV
MMX-^(]5=4TS/T4O#W^!<^L;V)GW3$_E+SF'[0N&\1MB8CWQ,?G"@0JKJ'9BZ
MN8,S%G2;.5$?S=[1\=,O&W+
M%VU.E=,Q[X>5MW;=V-;=43[IB6T;(NVY\JOU-T3$^4JYB8W6:3#4.8]HXX
M                                                         -]NQDWIB+.+=KY\N[3+M,/9V[M0X^XMM
M9][GR[MOS6V\/=NSI;IF?=&JJY>M68UN51'OF(_-U ]M@=$NJ^IN?Z9>*O\ $648;]KB
MK=V*9U'7L*S$^<6ZIJF/IAZ;3>Q;IT3$ZMN[)KCUTV[5
M,?XO,6. \^O[6-/?,1^#Q/:WD5K]E3R?U6SZ8JR*,'#CU]Z]35/UPO?'G,/V7Y3;ZW:ZZOC$?9Z_B>
MU[.;G["W;H^$S^<_9:=I/8OU:[$5:QNRU:]M-NS,_KBI['2>QUL7&XJU74L_
M+JCSBF[W8GYO%< /.8;@;(<-M8B?\TS/YR]>Q7:)Q)B]\3-,?RQ%/Y1JI?IG
M9MZ2:75%=O;=%ZJ/7>XK_P 'L--Z?[*TB(_NXG.\RQO_$8BNKWU3^KYVK%FQ3W+-NFBF/5$/H#R$1$=(>,F9GK
M( ZX
M
M
M
M
M
M
M
M
M
M
M                  -LT4U?A4Q/QPW /C5AXE?X>+9J^.B)=;F;/VOJ'/W9
MH>)=Y\^;<.X%5=FUHL3/KMS/^*JX\?=R/++_[3#T3_3'Z/*6.(LWPW[+$
MW(_JG]5"<[L@=-LF)G&RM0QZO5W*Z>/J>=SNQ=I%?/[G[HR;7L[_ !/U4KF!
MXR]P7D5[K5AZ8]VL?=Y>QQ]Q'A_#BJI]^D_G"TS+[%NM6XF<+>&/7[(KHJ_\
M.BR^R!U%LZJ7E;/:EQ':\5RFKWT
MQ]M%BV9V7.KF-$S:TJSD/Y-=,_5*08>.N]
MEN4U_L[E=/QB?L\G9[7\YH_:6K=7PF/NC?R.FW4'%JFF]M'/\/7%'/U.NO[8
MW/B_ZQMW4*/_ /'JG_!)B^-S#Q;W[[CVZ_CIY>/N]E&&G]GB)CWTQ^KR=KMF
MQ$?M<)3\*IC[2C(JP=1H_#TW,I^/'KC_  ?*JW>H_#L7:?Z5N8287MMZ!DQQ
M?T?$N<^'OK42X&1T]V-E1,9&T]+KY\^]C4S_ (,-SLGN?\O$Q\:?]V^WVRX>
M?VF$GX51^D(V^_$><3'S'NE'KJB/G2'Y71CIEF3,W-H:=3WOY%BF/\'59/9T
MZ397>]TVS;I[WGW.(_P8:^RO,8\%ZB?G^CR%KMARFK]I8KCY3]X6#=^B?*NG
MZ3F)\IA?1?[+?2&]3,4Z-?MS/\F]QQ^IUF3V1NEUZKFU1GVO#CB,B62YV8YS
M3X9HGXS^C;;[6L@K\47(_IC]5E8O!O=C?8=41[AJFHT3Z^;TRX-[L8;;J[WN
M&YT[44S_5#91VH<-U;W*H]]$_;5:8+I+_8KQ9B/N?>
M=RF?7WL>9_ZG!O=BW.IN519WA351QX3./Q_U,M? /$%'_(U]U5/ZM=':/PU7
M_P#)T]]-7Z+:1<1<[&>YJ::IM;EQZIC\&)MQ'/\ S.'=['.^XHYLZWAU5>R8
MB/\ %GJX)SZG?#3]/U:J>/.'*]L73\=8^R@8KE7V/NI5-/-&HZ?7/LFN(_Q?
M#([)'4_'M3[0JJX/SRGK.&J^2ZGC3AZKI&,H^?^RB@J]7V6^IM%
M%5CQ8>OY2TT<4Y+<\.*H_U*8BH>
M1T%ZBXUSW.K$P*I]OW5'_A\O\QG43_T6#_\ AI^7_IL3_P#"(/\ -3O+_P!-B?\ X1!_=6._Z57R
M=_O; ?\ 6I^E.\XGC[FQ/_PB'/[KQL].
MZJ^3O]ZX&.O?4_.'D!Z__-3O+_TV)_\ A$'^:G>7_IL3_P#"(=_NK'?]*KY.
M?WM@/^M3\X>0'K_\U.\O_38G_P"$0YECHGU R;47K6'A315Y?NF)
MIUZY%OW33HY]?N\+Z.&,XN1K3AZ_E+/7Q9D=N=*L71\U'17".R#U/F
M>)S-.B/;[K#[4=COJ+-417JV!%/KF)C_ ,M$<&Y[/_QJODSSQMP[&^,H^<_H
MH2+@;78WWE5JHYR-Z=VKGRC&YC^\["SV+-*IJIF_
MNZ_7$?A1%F8Y_P"9HH[/\_K_ .3I[ZJ?U9:^TGAJC_Y&ONIJ_1:H+N+/8RVG
M3$Q?W!FUSZN)F/\ %S['8ZZ=VZHJO9NHW.(\8]WF.9:J.S;/:MZ:8_J9*^U+
MARG:NJ?=1/WF%F_>ICSJCZ6G?HC^/3]*]S&[)G2JS%,7<7-N\3S/>R)\?U.Q
MM=F#I!:\M!N5>//OKO/^#5;[,,XJ\55$?&?T8Z^UO(:?#3SM+GG^5C43_@
MUV^RK,)\=ZB/G+%<[8$GXU1^B.&QM'=N5Q]S;:U&OGR_T%4?7#LL7I;U&S)XL
M[1S8_I1$?6D7MX]BUX6K5-''LCA]&ZWV486/VF(JGW4Q'WEX^[VRXJ?V6$IC
MWU3/VA']A]G[JWG?O.UKD<_RKE$?7+O,3LK]6,B(F]A8^/S_ "ZZ9^J5\HWV
MNR[**/'775\8C[/&7NU[.J_V=NW3\)G\Y6:8?8]W_?XG*UK3[$3ZNY5,P[S&
M[%>IU1$Y>\[5,^N+=%7^,+KQY*UV=Y#:WMS/OJEXR]VH\1W?#=II]U-/Z+;,
M'L8;?HX_=#*O\><18CQ8JJ/=I'Y0I9@]FGI'A3%7^35F]5'KN3,_P"+T6'T@Z:X
M,1&-L_ I[OE/=G_R]B/)VLERVQ^SL41_3'Z/$7^(,VQ/[7$US_55^KJL/:NW
M-/X^X]%Q+7'EQ;AV%.)BT?@8UJGXJ(A]1OHM6[<:44Q'NAXVN]=NSK75,S[9
M:1333Y4Q'Q0U!8J
M
M
M
M
M
M
8                             ?_9
end
XML
10
R1.htm
IDEA: XBRL DOCUMENT
v3.26.1
Cover
Jul. 30, 2026
Class of Stock [Line Items]
Document Type
8-K
Document Period End Date
Jul. 30,  2026
Entity Registrant Name
AMAZON.COM, INC.
Entity Incorporation, State or Country Code
DE
Entity File Number
001-43202
Entity Tax Identification Number
91-1646860
Entity Address, Address Line One
410 Terry Avenue North
Entity Address, City or Town
Seattle
Entity Address, State or Province
WA
Entity Address, Postal Zip Code
98109-5210
City Area Code
206
Local Phone Number
266-1000
Written Communications
false
Soliciting Material
false
Pre-commencement Tender Offer
false
Pre-commencement Issuer Tender Offer
false
Entity Emerging Growth Company
false
Entity Central Index Key
0001018724
Amendment Flag
false
Common Stock, par value $.01 per share
Class of Stock [Line Items]
Title of 12(b) Security
Common Stock, par value $.01 per share
Trading Symbol
AMZN
Security Exchange Name
NASDAQ
Floating Rate Notes due 2028
Class of Stock [Line Items]
Title of 12(b) Security
Floating Rate Notes due 2028
No Trading Symbol Flag
true
Security Exchange Name
NASDAQ
2.800% Notes due 2028
Class of Stock [Line Items]
Title of 12(b) Security
2.800% Notes due 2028
No Trading Symbol Flag
true
Security Exchange Name
NASDAQ
3.100% Notes due 2030
Class of Stock [Line Items]
Title of 12(b) Security
3.100% Notes due 2030
No Trading Symbol Flag
true
Security Exchange Name
NASDAQ
3.350% Notes due 2032
Class of Stock [Line Items]
Title of 12(b) Security
3.350% Notes due 2032
No Trading Symbol Flag
true
Security Exchange Name
NASDAQ
3.700% Notes due 2035
Class of Stock [Line Items]
Title of 12(b) Security
3.700% Notes due 2035
No Trading Symbol Flag
true
Security Exchange Name
NASDAQ
4.050% Notes due 2039
Class of Stock [Line Items]
Title of 12(b) Security
4.050% Notes due 2039
No Trading Symbol Flag
true
Security Exchange Name
NASDAQ
4.450% Notes due 2045
Class of Stock [Line Items]
Title of 12(b) Security
4.450% Notes due 2045
No Trading Symbol Flag
true
Security Exchange Name
NASDAQ
4.850% Notes due 2064
Class of Stock [Line Items]
Title of 12(b) Security
4.850% Notes due 2064
No Trading Symbol Flag
true
Security Exchange Name
NASDAQ
X
- Definition
Boolean flag that is true when the XBRL content amends previously-filed or accepted submission.
+ References
No definition available.
+ Details
Name:
dei_AmendmentFlag
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Area code of city
+ References
No definition available.
+ Details
Name:
dei_CityAreaCode
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
For the EDGAR submission types of Form 8-K: the date of the report, the date of the earliest event reported; for the EDGAR submission types of Form N-1A: the filing date; for all other submission types: the end of the reporting or transition period. The format of the date is YYYY-MM-DD.
+ References
No definition available.
+ Details
Name:
dei_DocumentPeriodEndDate
Namespace Prefix:
dei_
Data Type:
xbrli:dateItemType
Balance Type:
na
Period Type:
duration
X
- Definition
The type of document being provided (such as 10-K, 10-Q, 485BPOS, etc). The document type is limited to the same value as the supporting SEC submission type, or the word 'Other'.
+ References
No definition available.
+ Details
Name:
dei_DocumentType
Namespace Prefix:
dei_
Data Type:
dei:submissionTypeItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Address Line 1 such as Attn, Building Name, Street Name
+ References
No definition available.
+ Details
Name:
dei_EntityAddressAddressLine1
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Name of the City or Town
+ References
No definition available.
+ Details
Name:
dei_EntityAddressCityOrTown
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Code for the postal or zip code
+ References
No definition available.
+ Details
Name:
dei_EntityAddressPostalZipCode
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Name of the state or province.
+ References
No definition available.
+ Details
Name:
dei_EntityAddressStateOrProvince
Namespace Prefix:
dei_
Data Type:
dei:stateOrProvinceItemType
Balance Type:
na
Period Type:
duration
X
- Definition
A unique 10-digit SEC-issued value to identify entities that have filed disclosures with the SEC. It is commonly abbreviated as CIK.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b-2
+ Details
Name:
dei_EntityCentralIndexKey
Namespace Prefix:
dei_
Data Type:
dei:centralIndexKeyItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Indicate if registrant meets the emerging growth company criteria.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b-2
+ Details
Name:
dei_EntityEmergingGrowthCompany
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Commission file number. The field allows up to 17 characters. The prefix may contain 1-3 digits, the sequence number may contain 1-8 digits, the optional suffix may contain 1-4 characters, and the fields are separated with a hyphen.
+ References
No definition available.
+ Details
Name:
dei_EntityFileNumber
Namespace Prefix:
dei_
Data Type:
dei:fileNumberItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Two-character EDGAR code representing the state or country of incorporation.
+ References
No definition available.
+ Details
Name:
dei_EntityIncorporationStateCountryCode
Namespace Prefix:
dei_
Data Type:
dei:edgarStateCountryItemType
Balance Type:
na
Period Type:
duration
X
- Definition
The exact name of the entity filing the report as specified in its charter, which is required by forms filed with the SEC.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b-2
+ Details
Name:
dei_EntityRegistrantName
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
The Tax Identification Number (TIN), also known as an Employer Identification Number (EIN), is a unique 9-digit value assigned by the IRS.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b-2
+ Details
Name:
dei_EntityTaxIdentificationNumber
Namespace Prefix:
dei_
Data Type:
dei:employerIdItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Local phone number for entity.
+ References
No definition available.
+ Details
Name:
dei_LocalPhoneNumber
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Boolean flag that is true only for a security having no trading symbol.
+ References
No definition available.
+ Details
Name:
dei_NoTradingSymbolFlag
Namespace Prefix:
dei_
Data Type:
dei:trueItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as pre-commencement communications pursuant to Rule 13e-4(c) under the Exchange Act.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 13e
-Subsection 4c
+ Details
Name:
dei_PreCommencementIssuerTenderOffer
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as pre-commencement communications pursuant to Rule 14d-2(b) under the Exchange Act.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 14d
-Subsection 2b
+ Details
Name:
dei_PreCommencementTenderOffer
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Title of a 12(b) registered security.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b
+ Details
Name:
dei_Security12bTitle
Namespace Prefix:
dei_
Data Type:
dei:securityTitleItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Name of the Exchange on which a security is registered.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection d1-1
+ Details
Name:
dei_SecurityExchangeName
Namespace Prefix:
dei_
Data Type:
dei:edgarExchangeCodeItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as soliciting material pursuant to Rule 14a-12 under the Exchange Act.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 14a
-Subsection 12
+ Details
Name:
dei_SolicitingMaterial
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Trading symbol of an instrument as listed on an exchange.
+ References
No definition available.
+ Details
Name:
dei_TradingSymbol
Namespace Prefix:
dei_
Data Type:
dei:tradingSymbolItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as written communications pursuant to Rule 425 under the Securities Act.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Securities Act
-Number 230
-Section 425
+ Details
Name:
dei_WrittenCommunications
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- References
No definition available.
+ Details
Name:
us-gaap_ClassOfStockLineItems
Namespace Prefix:
us-gaap_
Data Type:
xbrli:stringItemType
Balance Type:
na
Period Type:
duration
X
- Details
Name:
us-gaap_StatementClassOfStockAxis=us-gaap_CommonStockMember
Namespace Prefix:
Data Type:
na
Balance Type:
Period Type:
X
- Details
Name:
us-gaap_StatementClassOfStockAxis=amzn_FloatingRateNotesDue2028Member
Namespace Prefix:
Data Type:
na
Balance Type:
Period Type:
X
- Details
Name:
us-gaap_StatementClassOfStockAxis=amzn_A2.800NotesDue2028Member
Namespace Prefix:
Data Type:
na
Balance Type:
Period Type:
X
- Details
Name:
us-gaap_StatementClassOfStockAxis=amzn_A3.100NotesDue2030Member
Namespace Prefix:
Data Type:
na
Balance Type:
Period Type:
X
- Details
Name:
us-gaap_StatementClassOfStockAxis=amzn_A3.350NotesDue2032Member
Namespace Prefix:
Data Type:
na
Balance Type:
Period Type:
X
- Details
Name:
us-gaap_StatementClassOfStockAxis=amzn_A3.700NotesDue2035Member
Namespace Prefix:
Data Type:
na
Balance Type:
Period Type:
X
- Details
Name:
us-gaap_StatementClassOfStockAxis=amzn_A4.050NotesDue2039Member
Namespace Prefix:
Data Type:
na
Balance Type:
Period Type:
X
- Details
Name:
us-gaap_StatementClassOfStockAxis=amzn_A4.450NotesDue2045Member
Namespace Prefix:
Data Type:
na
Balance Type:
Period Type:
X
- Details
Name:
us-gaap_StatementClassOfStockAxis=amzn_A4.850NotesDue2064Member
Namespace Prefix:
Data Type:
na
Balance Type:
Period Type:
XML
11
report.css
IDEA: XBRL DOCUMENT
/* Updated 2009-11-04 */
/* v2.2.0.24 */
/* DefRef Styles */
.report table.authRefData{
background-color: #def;
border: 2px solid #2F4497;
font-size: 1em;
position: absolute;
}
.report table.authRefData a {
display: block;
font-weight: bold;
}
.report table.authRefData p {
margin-top: 0px;
}
.report table.authRefData .hide {
background-color: #2F4497;
padding: 1px 3px 0px 0px;
text-align: right;
}
.report table.authRefData .hide a:hover {
background-color: #2F4497;
}
.report table.authRefData .body {
height: 150px;
overflow: auto;
width: 400px;
}
.report table.authRefData table{
font-size: 1em;
}
/* Report Styles */
.pl a, .pl a:visited {
color: black;
text-decoration: none;
}
/* table */
.report {
background-color: white;
border: 2px solid #acf;
clear: both;
color: black;
font: normal 8pt Helvetica, Arial, san-serif;
margin-bottom: 2em;
}
.report hr {
border: 1px solid #acf;
}
/* Top labels */
.report th {
background-color: #acf;
color: black;
font-weight: bold;
text-align: center;
}
.report th.void	{
background-color: transparent;
color: #000000;
font: bold 10pt Helvetica, Arial, san-serif;
text-align: left;
}
.report .pl {
text-align: left;
vertical-align: top;
white-space: normal;
width: 200px;
white-space: normal; /* word-wrap: break-word; */
}
.report td.pl a.a {
cursor: pointer;
display: block;
width: 200px;
overflow: hidden;
}
.report td.pl div.a {
width: 200px;
}
.report td.pl a:hover {
background-color: #ffc;
}
/* Header rows... */
.report tr.rh {
background-color: #acf;
color: black;
font-weight: bold;
}
/* Calendars... */
.report .rc {
background-color: #f0f0f0;
}
/* Even rows... */
.report .re, .report .reu {
background-color: #def;
}
.report .reu td {
border-bottom: 1px solid black;
}
/* Odd rows... */
.report .ro, .report .rou {
background-color: white;
}
.report .rou td {
border-bottom: 1px solid black;
}
.report .rou table td, .report .reu table td {
border-bottom: 0px solid black;
}
/* styles for footnote marker */
.report .fn {
white-space: nowrap;
}
/* styles for numeric types */
.report .num, .report .nump {
text-align: right;
white-space: nowrap;
}
.report .nump {
padding-left: 2em;
}
.report .nump {
padding: 0px 0.4em 0px 2em;
}
/* styles for text types */
.report .text {
text-align: left;
white-space: normal;
}
.report .text .big {
margin-bottom: 1em;
width: 17em;
}
.report .text .more {
display: none;
}
.report .text .note {
font-style: italic;
font-weight: bold;
}
.report .text .small {
width: 10em;
}
.report sup {
font-style: italic;
}
.report .outerFootnotes {
font-size: 1em;
}
XML
12
Show.js
IDEA: XBRL DOCUMENT
// Edgar(tm) Renderer was created by staff of the U.S. Securities and Exchange Commission.  Data and content created by government employees within the scope of their employment are not subject to domestic copyright protection. 17 U.S.C. 105.
var Show={};Show.LastAR=null,Show.showAR=function(a,r,w){if(Show.LastAR)Show.hideAR();var e=a;while(e&&e.nodeName!='TABLE')e=e.nextSibling;if(!e||e.nodeName!='TABLE'){var ref=((window)?w.document:document).getElementById(r);if(ref){e=ref.cloneNode(!0);
e.removeAttribute('id');a.parentNode.appendChild(e)}}
if(e)e.style.display='block';Show.LastAR=e};Show.hideAR=function(){Show.LastAR.style.display='none'};Show.toggleNext=function(a){var e=a;while(e.nodeName!='DIV')e=e.nextSibling;if(!e.style){}else if(!e.style.display){}else{var d,p_;if(e.style.display=='none'){d='block';p='-'}else{d='none';p='+'}
e.style.display=d;if(a.textContent){a.textContent=p+a.textContent.substring(1)}else{a.innerText=p+a.innerText.substring(1)}}}
XML
14
FilingSummary.xml
IDEA: XBRL DOCUMENT
3.26.1
html
10
23
1
false
9
0
false
0
false
false
R1.htm
0000001 - Document - Cover
Sheet
http://www.amazon.com/role/Cover
Cover
Cover
1
false
false
All Reports
Book
All Reports
amzn-20260730.htm
amzn-20260730.xsd
amzn-20260730_def.xml
amzn-20260730_lab.xml
amzn-20260730_pre.xml
http://xbrl.sec.gov/dei/2025
true
false
JSON
16
MetaLinks.json
IDEA: XBRL DOCUMENT
{
"version": "2.2",
"instance": {
"amzn-20260730.htm": {
"nsprefix": "amzn",
"nsuri": "http://www.amazon.com/20260730",
"dts": {
"inline": {
"local": [
"amzn-20260730.htm"
]
},
"schema": {
"local": [
"amzn-20260730.xsd"
],
"remote": [
"http://www.xbrl.org/2003/xbrl-instance-2003-12-31.xsd",
"http://www.xbrl.org/2003/xbrl-linkbase-2003-12-31.xsd",
"http://www.xbrl.org/2003/xl-2003-12-31.xsd",
"http://www.xbrl.org/2003/xlink-2003-12-31.xsd",
"http://www.xbrl.org/2005/xbrldt-2005.xsd",
"http://www.xbrl.org/2006/ref-2006-02-27.xsd",
"http://www.xbrl.org/lrr/role/negated-2009-12-16.xsd",
"http://www.xbrl.org/lrr/role/net-2009-12-16.xsd",
"https://www.xbrl.org/2020/extensible-enumerations-2.0.xsd",
"https://www.xbrl.org/dtr/type/2020-01-21/types.xsd",
"https://www.xbrl.org/dtr/type/2024-01-31/types.xsd",
"https://xbrl.fasb.org/srt/2025/elts/srt-2025.xsd",
"https://xbrl.fasb.org/srt/2025/elts/srt-roles-2025.xsd",
"https://xbrl.fasb.org/srt/2025/elts/srt-types-2025.xsd",
"https://xbrl.fasb.org/us-gaap/2025/elts/us-gaap-2025.xsd",
"https://xbrl.fasb.org/us-gaap/2025/elts/us-roles-2025.xsd",
"https://xbrl.fasb.org/us-gaap/2025/elts/us-types-2025.xsd",
"https://xbrl.sec.gov/country/2025/country-2025.xsd",
"https://xbrl.sec.gov/dei/2025/dei-2025.xsd",
"https://xbrl.sec.gov/stpr/2025/stpr-2025.xsd"
]
},
"definitionLink": {
"local": [
"amzn-20260730_def.xml"
]
},
"labelLink": {
"local": [
"amzn-20260730_lab.xml"
]
},
"presentationLink": {
"local": [
"amzn-20260730_pre.xml"
]
}
},
"keyStandard": 23,
"keyCustom": 0,
"axisStandard": 1,
"axisCustom": 0,
"memberStandard": 1,
"memberCustom": 8,
"hidden": {
"total": 2,
"http://xbrl.sec.gov/dei/2025": 2
},
"contextCount": 10,
"entityCount": 1,
"segmentCount": 9,
"elementCount": 37,
"unitCount": 0,
"baseTaxonomies": {
"http://xbrl.sec.gov/dei/2025": 46
},
"report": {
"R1": {
"role": "http://www.amazon.com/role/Cover",
"longName": "0000001 - Document - Cover",
"shortName": "Cover",
"isDefault": "true",
"groupType": "document",
"subGroupType": "",
"menuCat": "Cover",
"order": "1",
"firstAnchor": {
"contextRef": "c-1",
"name": "dei:DocumentType",
"unitRef": null,
"xsiNil": "false",
"lang": "en-US",
"decimals": null,
"ancestors": [
"span",
"div",
"body",
"html"
],
"reportCount": 1,
"baseRef": "amzn-20260730.htm",
"first": true,
"unique": true
},
"uniqueAnchor": {
"contextRef": "c-1",
"name": "dei:DocumentType",
"unitRef": null,
"xsiNil": "false",
"lang": "en-US",
"decimals": null,
"ancestors": [
"span",
"div",
"body",
"html"
],
"reportCount": 1,
"baseRef": "amzn-20260730.htm",
"first": true,
"unique": true
}
}
},
"tag": {
"amzn_A2.800NotesDue2028Member": {
"xbrltype": "domainItemType",
"nsuri": "http://www.amazon.com/20260730",
"localname": "A2.800NotesDue2028Member",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "2.800% Notes due 2028",
"label": "2.800% Notes due 2028 [Member]",
"documentation": "2.800% Notes due 2028"
}
}
},
"auth_ref": []
},
"amzn_A3.100NotesDue2030Member": {
"xbrltype": "domainItemType",
"nsuri": "http://www.amazon.com/20260730",
"localname": "A3.100NotesDue2030Member",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "3.100% Notes due 2030",
"label": "3.100% Notes due 2030 [Member]",
"documentation": "3.100% Notes due 2030"
}
}
},
"auth_ref": []
},
"amzn_A3.350NotesDue2032Member": {
"xbrltype": "domainItemType",
"nsuri": "http://www.amazon.com/20260730",
"localname": "A3.350NotesDue2032Member",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "3.350% Notes due 2032",
"label": "3.350% Notes due 2032 [Member]",
"documentation": "3.350% Notes due 2032"
}
}
},
"auth_ref": []
},
"amzn_A3.700NotesDue2035Member": {
"xbrltype": "domainItemType",
"nsuri": "http://www.amazon.com/20260730",
"localname": "A3.700NotesDue2035Member",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "3.700% Notes due 2035",
"label": "3.700% Notes due 2035 [Member]",
"documentation": "3.700% Notes due 2035"
}
}
},
"auth_ref": []
},
"amzn_A4.050NotesDue2039Member": {
"xbrltype": "domainItemType",
"nsuri": "http://www.amazon.com/20260730",
"localname": "A4.050NotesDue2039Member",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "4.050% Notes due 2039",
"label": "4.050% Notes due 2039 [Member]",
"documentation": "4.050% Notes due 2039"
}
}
},
"auth_ref": []
},
"amzn_A4.450NotesDue2045Member": {
"xbrltype": "domainItemType",
"nsuri": "http://www.amazon.com/20260730",
"localname": "A4.450NotesDue2045Member",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "4.450% Notes due 2045",
"label": "4.450% Notes due 2045 [Member]",
"documentation": "4.450% Notes due 2045"
}
}
},
"auth_ref": []
},
"amzn_A4.850NotesDue2064Member": {
"xbrltype": "domainItemType",
"nsuri": "http://www.amazon.com/20260730",
"localname": "A4.850NotesDue2064Member",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "4.850% Notes due 2064",
"label": "4.850% Notes due 2064 [Member]",
"documentation": "4.850% Notes due 2064"
}
}
},
"auth_ref": []
},
"dei_AmendmentFlag": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "AmendmentFlag",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Amendment Flag",
"label": "Amendment Flag",
"documentation": "Boolean flag that is true when the XBRL content amends previously-filed or accepted submission."
}
}
},
"auth_ref": []
},
"dei_CityAreaCode": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "CityAreaCode",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "City Area Code",
"label": "City Area Code",
"documentation": "Area code of city"
}
}
},
"auth_ref": []
},
"us-gaap_ClassOfStockDomain": {
"xbrltype": "domainItemType",
"nsuri": "http://fasb.org/us-gaap/2025",
"localname": "ClassOfStockDomain",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Class of Stock [Domain]",
"label": "Class of Stock [Domain]"
}
}
},
"auth_ref": []
},
"us-gaap_ClassOfStockLineItems": {
"xbrltype": "stringItemType",
"nsuri": "http://fasb.org/us-gaap/2025",
"localname": "ClassOfStockLineItems",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Class of Stock [Line Items]",
"label": "Class of Stock [Line Items]"
}
}
},
"auth_ref": []
},
"us-gaap_CommonStockMember": {
"xbrltype": "domainItemType",
"nsuri": "http://fasb.org/us-gaap/2025",
"localname": "CommonStockMember",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Common Stock, par value $.01 per share",
"label": "Common Stock [Member]"
}
}
},
"auth_ref": []
},
"dei_CoverAbstract": {
"xbrltype": "stringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "CoverAbstract",
"lang": {
"en-us": {
"role": {
"label": "Cover [Abstract]",
"documentation": "Cover page."
}
}
},
"auth_ref": []
},
"dei_DocumentPeriodEndDate": {
"xbrltype": "dateItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "DocumentPeriodEndDate",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Document Period End Date",
"label": "Document Period End Date",
"documentation": "For the EDGAR submission types of Form 8-K: the date of the report, the date of the earliest event reported; for the EDGAR submission types of Form N-1A: the filing date; for all other submission types: the end of the reporting or transition period. The format of the date is YYYY-MM-DD."
}
}
},
"auth_ref": []
},
"dei_DocumentType": {
"xbrltype": "submissionTypeItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "DocumentType",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Document Type",
"label": "Document Type",
"documentation": "The type of document being provided (such as 10-K, 10-Q, 485BPOS, etc). The document type is limited to the same value as the supporting SEC submission type, or the word 'Other'."
}
}
},
"auth_ref": []
},
"dei_EntityAddressAddressLine1": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityAddressAddressLine1",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Address, Address Line One",
"label": "Entity Address, Address Line One",
"documentation": "Address Line 1 such as Attn, Building Name, Street Name"
}
}
},
"auth_ref": []
},
"dei_EntityAddressCityOrTown": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityAddressCityOrTown",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Address, City or Town",
"label": "Entity Address, City or Town",
"documentation": "Name of the City or Town"
}
}
},
"auth_ref": []
},
"dei_EntityAddressPostalZipCode": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityAddressPostalZipCode",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Address, Postal Zip Code",
"label": "Entity Address, Postal Zip Code",
"documentation": "Code for the postal or zip code"
}
}
},
"auth_ref": []
},
"dei_EntityAddressStateOrProvince": {
"xbrltype": "stateOrProvinceItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityAddressStateOrProvince",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Address, State or Province",
"label": "Entity Address, State or Province",
"documentation": "Name of the state or province."
}
}
},
"auth_ref": []
},
"dei_EntityCentralIndexKey": {
"xbrltype": "centralIndexKeyItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityCentralIndexKey",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Central Index Key",
"label": "Entity Central Index Key",
"documentation": "A unique 10-digit SEC-issued value to identify entities that have filed disclosures with the SEC. It is commonly abbreviated as CIK."
}
}
},
"auth_ref": [
"r1"
]
},
"dei_EntityEmergingGrowthCompany": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityEmergingGrowthCompany",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Emerging Growth Company",
"label": "Entity Emerging Growth Company",
"documentation": "Indicate if registrant meets the emerging growth company criteria."
}
}
},
"auth_ref": [
"r1"
]
},
"dei_EntityFileNumber": {
"xbrltype": "fileNumberItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityFileNumber",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity File Number",
"label": "Entity File Number",
"documentation": "Commission file number. The field allows up to 17 characters. The prefix may contain 1-3 digits, the sequence number may contain 1-8 digits, the optional suffix may contain 1-4 characters, and the fields are separated with a hyphen."
}
}
},
"auth_ref": []
},
"dei_EntityIncorporationStateCountryCode": {
"xbrltype": "edgarStateCountryItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityIncorporationStateCountryCode",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Incorporation, State or Country Code",
"label": "Entity Incorporation, State or Country Code",
"documentation": "Two-character EDGAR code representing the state or country of incorporation."
}
}
},
"auth_ref": []
},
"dei_EntityRegistrantName": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityRegistrantName",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Registrant Name",
"label": "Entity Registrant Name",
"documentation": "The exact name of the entity filing the report as specified in its charter, which is required by forms filed with the SEC."
}
}
},
"auth_ref": [
"r1"
]
},
"dei_EntityTaxIdentificationNumber": {
"xbrltype": "employerIdItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityTaxIdentificationNumber",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Tax Identification Number",
"label": "Entity Tax Identification Number",
"documentation": "The Tax Identification Number (TIN), also known as an Employer Identification Number (EIN), is a unique 9-digit value assigned by the IRS."
}
}
},
"auth_ref": [
"r1"
]
},
"amzn_FloatingRateNotesDue2028Member": {
"xbrltype": "domainItemType",
"nsuri": "http://www.amazon.com/20260730",
"localname": "FloatingRateNotesDue2028Member",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Floating Rate Notes due 2028",
"label": "Floating Rate Notes due 2028 [Member]",
"documentation": "Floating Rate Notes due 2028"
}
}
},
"auth_ref": []
},
"dei_LocalPhoneNumber": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "LocalPhoneNumber",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Local Phone Number",
"label": "Local Phone Number",
"documentation": "Local phone number for entity."
}
}
},
"auth_ref": []
},
"dei_NoTradingSymbolFlag": {
"xbrltype": "trueItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "NoTradingSymbolFlag",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "No Trading Symbol Flag",
"label": "No Trading Symbol Flag",
"documentation": "Boolean flag that is true only for a security having no trading symbol."
}
}
},
"auth_ref": []
},
"dei_PreCommencementIssuerTenderOffer": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "PreCommencementIssuerTenderOffer",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Pre-commencement Issuer Tender Offer",
"label": "Pre-commencement Issuer Tender Offer",
"documentation": "Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as pre-commencement communications pursuant to Rule 13e-4(c) under the Exchange Act."
}
}
},
"auth_ref": [
"r3"
]
},
"dei_PreCommencementTenderOffer": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "PreCommencementTenderOffer",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Pre-commencement Tender Offer",
"label": "Pre-commencement Tender Offer",
"documentation": "Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as pre-commencement communications pursuant to Rule 14d-2(b) under the Exchange Act."
}
}
},
"auth_ref": [
"r5"
]
},
"us-gaap_ScheduleOfStockByClassTable": {
"xbrltype": "stringItemType",
"nsuri": "http://fasb.org/us-gaap/2025",
"localname": "ScheduleOfStockByClassTable",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Stock, Class of Stock [Table]",
"label": "Stock, Class of Stock [Table]"
}
}
},
"auth_ref": []
},
"dei_Security12bTitle": {
"xbrltype": "securityTitleItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "Security12bTitle",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Title of 12(b) Security",
"label": "Title of 12(b) Security",
"documentation": "Title of a 12(b) registered security."
}
}
},
"auth_ref": [
"r0"
]
},
"dei_SecurityExchangeName": {
"xbrltype": "edgarExchangeCodeItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "SecurityExchangeName",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Security Exchange Name",
"label": "Security Exchange Name",
"documentation": "Name of the Exchange on which a security is registered."
}
}
},
"auth_ref": [
"r2"
]
},
"dei_SolicitingMaterial": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "SolicitingMaterial",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Soliciting Material",
"label": "Soliciting Material",
"documentation": "Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as soliciting material pursuant to Rule 14a-12 under the Exchange Act."
}
}
},
"auth_ref": [
"r4"
]
},
"us-gaap_StatementClassOfStockAxis": {
"xbrltype": "stringItemType",
"nsuri": "http://fasb.org/us-gaap/2025",
"localname": "StatementClassOfStockAxis",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Class of Stock [Axis]",
"label": "Class of Stock [Axis]"
}
}
},
"auth_ref": []
},
"dei_TradingSymbol": {
"xbrltype": "tradingSymbolItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "TradingSymbol",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Trading Symbol",
"label": "Trading Symbol",
"documentation": "Trading symbol of an instrument as listed on an exchange."
}
}
},
"auth_ref": []
},
"dei_WrittenCommunications": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "WrittenCommunications",
"presentation": [
"http://www.amazon.com/role/Cover"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Written Communications",
"label": "Written Communications",
"documentation": "Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as written communications pursuant to Rule 425 under the Securities Act."
}
}
},
"auth_ref": [
"r6"
]
}
}
}
},
"std_ref": {
"r0": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "12",
"Subsection": "b"
},
"r1": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "12",
"Subsection": "b-2"
},
"r2": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "12",
"Subsection": "d1-1"
},
"r3": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "13e",
"Subsection": "4c"
},
"r4": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "14a",
"Subsection": "12"
},
"r5": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "14d",
"Subsection": "2b"
},
"r6": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Securities Act",
"Number": "230",
"Section": "425"
}
}
}
ZIP
17
0001018724-26-000024-xbrl.zip
IDEA: XBRL DOCUMENT
begin 644 0001018724-26-000024-xbrl.zip
M4$L#!!0    ( ,J@_EP4R=,>77$  '(_"@ 7    86UZ;BTR,#(V,#8S,'AE
M>#DY,2YH=&WL?5ESVTBR[OO]%;CNY1ZAEN4=S6I+'4D^?F9<)
M$"B*. 8!-@!JZ5]_,ZL DEI-4)2P94>T+8M$H:KRJZS<\Z=)/HT^_#3A7O#A
M__ST?W=WE8^)/Y_R.%?\E'LY#Y1Y%L:7RN\!S[XJN[O%MPZ3V6T:7DYR15=U
M6_D]2;^&5Y[\/ _SB'\HQ_GI+_+?/_U%O.2G41++3\V$^B)-W[3A7_
M[>,GNV-O&D:W>__O(ISR3#GEU\J79.K%_X]E/ W'\CM9^">'E<#'LYC%8/K6KCT!IC:?>$$4')P?_
M/CL=')Z=* >GIV>_G1X>G2OG1X=GIQ^5?_QV\.7BZ(ORY>C\MU\OSK]%L?*@
M;;87:PZRW:T1@^V%.;S(7P.YIQS>[T4P>A@CD\R 2<('RBWWTMT$T+.+/[5Z
MB6,Y5])YK, N\[<\4:_)6A[?U/.C@XN+7X^*C=GY^;?SX].C
M\W/E]^,O1^^5O\^C6WD3&"H3LD3QQ0/!N@< /J8$VKB>EF(]**:^_]141_LCZBNFL+Q>](780"[J]$!+>]%*\
M*REJYD"0<,'[7WU.3Q#P[I4#?.9[754']H+/ #O*)_P>X)D"YVCFI?#4=0@\
M"SB3,W!6G[EW0 #;UD YNO&C.>Z!&/)[=: M'AE[5TGJC2*NA#"PGROC-)G>
MNPL4?^+%EX*3XD&$9<0*OY&_%(PO@W'39'XY2>:Y>,5BNH]Q85SOW64\-NEU
MF>D=ZCIZO_#^V-N?P'N2PD8?3&%$WX,-OQ2JX7W2:/9].4 @4]/L@5Y"ABBS
M7Z#5-SJ%U.$B+*B.*XKH;C+(_&4@$*,ZPWN^N114X"[E 4?D.X>L1\5
M+8ET;R ,/$XZ;2GY/SQU1+HZQ84G"&8O];N'%%._S2SA8P_2O?P6'.+\P1;;
MPD!2\ CX*YH'\/8XB7>7'&26\MW;XW2N>Y(]%=49Q?>RB3*.DNOZF9!A
M2%.D9FM+; GC.[*B//7"2%@1KWETQ94I##W)'K(=75LU,#[[\%,6_ UY#\'M
M*;A]2CFO'VD!7[GNO!BX5([3$>S,6;G[OH6X( VO>+S"\T:WBG??(%/"6HQN
MVRN8!&8XFZ?^!#[,\--9BNPV1Q=4H/ _YN$,F::T7LN/?K]O\9RM>1<8W[@+-+.VDZ?NHS .^SA*DBGL!1,^7MP4PQX\
MM-P!.?ZA%^Y*O#?7<0PC_?&[!\<""H>3< :OPQ KGB&JN.=/%.Y'\&OT%!<>
M8H&V:9("F28 _^_UI1M>3%S;!WB% 5S5P:WR=R_+;IGR&7 0(C.3+SHZ8TKA
M4U6*Q1['RGD.@\+!N.:*=^D)<2X'[/E)&L"ABP"CZ:V2S22* 2F? :" #3X=
MP9)*47,-<9KX&]R>2'\@L"WSN"78*SXT79@C93[L7P]W@>H1"#-$CE-N%,4B1(
M,:MRFP>X3[ ;@0CT$=%M$R^ ]TA1*D,AX\6(E8K+,/
MYUN)DAR/WXBCKRM$8=D; ;]B8AVPSQ,/3]<RE//*0 3T9-%=$0ZG+1[Q1EJ#L
M_^"1;P3+5>8/]H(_3-*E<_J2[XZ 1W[=]<9 E#TONO9NLWN!?@V)";P;4(:C
MU<[=SH7L+] ]@5]'^%&F9'@1"52)>R.^7: X@E,$K"C%<[ND'1 9G'*K1! )]@%WUX* <+V4W&YYB>5I.(N
MW8:788[:/$HA'OKG[W(V$J%K)R6&+/EW1(/J5"2CWW;)> A/A4"I0$%!20@>
M"7+$^52*"!%?(3O ]?)P:Z$.K$K[!TIGSD/GP$HFF21"B;,N6_
MO=3[.D]#&>/'E!..6(Y!)A)RE3?C8$#H@/O\E
MMHHB_#L">,,TY)T6\F(>O^&&X'.?46]"L9!.R)9/R!<>227]E]2["O,DME!'
M310@*) 2:',%*J8'_"_,;P>++Y7:0(8!Q?!M0\4_46,8\1P%<%"*?;X+G XX
M(TS9+Y0@J>O*$+08, ^4.6'QT&'DH8I_-YIEB,>67
M)+D$E'_D?'8"M%F.P*=33S%+=NCY_']6QT^3KXHY, ;WIH1FJ:LP$,&7H!.C
M?IQQM#7A.@#:Y84EEP2#P^=S."8AR"4KIZ709\NK[E)H[^(8X>]! $)VML]
MIY^!\8;\&BB+9KQ"7A,"V23T)\ :,Q]1FC%)D#"']\$_KKPH#-#()@F:@IX;
MA,+HYL,14*[F$5Y?XMH*T61[G$L1)\/[(,0 Y[P,D1YY -;D$A%Y[S$0_G/N
M30$.< ,$MW ?%*^#QV(X?!R/ICQ#-X3TU[B1$">^-UM2 HA8,OD#!,%A
M@DYZB?Z[7'\>1H+)CR+X\J/,&0B#CSQ%T$X\U!I$FFP.:CV_=,^9V/
ME'/@PK"8'7D]P&U0#%* 6_D*[#_BP247-Q.F%8#@5=PG<+'!F0'6\%Z>O+]Y
MJ=2LY0:-YZE47Z2U&R3&"5PE*&6M\'B<*QSW'+Z?)Y=("L0LCY!T)VX6M9\9'EJ J#UOVUQ'D2
M2]A/> 2ZJI3I&, < 28!@OB;(KZ%K044&'P\2CQ A^>G"7!//@6-ABD(>I $
M06Z'XP3?0UM^E,PQ(2TJKQ6)(3$$.N)*?Q"J"H6(@N5!D:=T
M*6_P'%&*3LD(73>1%U_.X:O+NT)<"^+XE/(,7E#EP<%)>6EZB][4PKX &@4H
M2E[VM;0JH,2784RA2%S$@WF%4MU8, B%] OG?AQY7X'W
M" 04]%P0JA1JSSWO'/8'!5)A%3B//)01S]$W"\<4Q=J_AZG'E NXK,NQ>7H%
M&NAI4DR4Q^*;>*7?OUKY32B% <_WR]L5I=_E"G.88Z:4'$[,(?,G/)A'TI7%
M\7'AJ0914XPD>&\L9E]L\WP6R @03SG\*EA8B-^"*F
M\PI,1Z26SKB_*P(+4%X4^W\IH@#^.TP35AH]0']#0\+9N0(77P"G/L++4UXH
MJ+)\1= FXS$0#T\ W-;_"RH9:B\Q*/9H!$DN4W%;P1D5EJSR-3*B "0US,(3
M^AB^&#"390)CPC(GKY_9!(X?8(MG7X':(@!GBH_CBA?2*&A(HX$<(RP-)U;I
MO_63+-_EXS&JBU>\U'"*V..K(KY!6JB%?C5'?O"HC8/P^%8B(2I#'_G5&=QR
M!R5D%.E W5VB,TO&^;4')"XB"!$ZJ+&("W#EHES!;C8)9\OG,F_,"UD1Y,00
M!KU=Y=V%<5 Y$8Q9N!)1YY &!245_!E9IM3AI%*/ZE>90UI>R*5 J(A0BU2.
M*M:9S1*XCY)+,Y?##BXZ24QBY!" 24$O2V"[U?A3D$HSG@IN1IA&2\
M)PRC""SX5>BC'";P)'2%3!$68&1#*VB12?X41KQE,DU'@:>1RCVXOO*[/#B!I1RLQ=+2Y^\T8:@W"+DS7:
MU N;P/D"IJ5&?RDE$JD\"46^$,L1?/*A0CV8>IDPJ%TET7PJH^V0E*SD47BE
M^@C;PH^DWCP(-)OAQ87*VG)V4J0J3H5\TA8U#-#>+,P2F8+V2'A(@!G16L:"
MS;CWE="S;0/Q/)TE&=]%30G/-6I77G0K/-SRQ,I &FE*N(>MT)>B7*(+(?(PDF/O2BUA>A0N#@K JW_-6FC=W/*!W
M7)6+T'GX'KYXH7@6OM;=F5QJL2Q6 O=&Q']A(@_ NS1>H]^G"#CTIAB@F ;7
M(KT'X;MXL !\N6/ +_^8 VFX/&X1AEKF16!$X)67+U^ !Z T?\0@
M)PK['.K;PG(A1I'B'K[J3RY'249XZ937AQBS-/'YDR0180^P7=>4TY\/BA\^_GZ>
MH+N\N#4*+[ST(<&=B=$^RE1@U4<9V)E/45K-YI)4>5A:@)0]SBT! C*13Z[?!
M.=S**SDV -SI=!Z+J ;QW#0LC-2%D37 _(4_Q6\(I*\%4B34992, *="")"5
M$ %J*"-@KHE3B!W7'IH<^1BSI82UJ934PP*Y@'/A=%\$R C5,D6?.;S'L7Y8
M&%T!&8+UBGH,C['Y2'0I=X.+E5DQH(?[J*251"P/$G(7#>H)CK
M8B349^<+WP6^5;+OU8%"Y*E!")(5EE7&8XK?TU7=47(,@,P)@J\%0;2:($_T
M !QPB=?;D'&
M#8$]+H)2V=*5]<#1]=&+LZ]<^=F+OS+E=W%E?N9Q?#OU?*9\"E$^AM]__@S#
MPV"@-  W/B_O;IR&='%^02Z4#
M^$TX8$SY+1;Z3W'MB*M?^03$#@-/'I@+.+YWO_1;[DT(Z:\5Z0Y\CM_,9)0>
MJ*417.R[PI"RS TL->."AYXFUZ7YI3!\++X*',M0X=*,YR*A,56$25'CF*L"KT-R77\8);(H<75[=TG%X)B6;J_2_ZY!?Q
M2D>7M[-\L#)G='4M?2'PC1B- 3X<^#PM7R-N%]U2'[Y:LGST=]R-"(P2#/HM
M\QG%\T/UAY7\T$LQY65F,$H7&*5PA)_AGB%X;!L>/XNB
MMODR1.S+?#R7)_P@XC?>?\E8&/&S4*;.)\EL)O7X^([F7?Q>075'>E6$,Z-@
MK7>"P&!)>KOT^:^X91913XN7%T5ZE3'WT)E7
M0/2S& G6D!;!IJC3[_X\OQU@-Y HN Z#)7LJ4H\*58G'EZ4/>*EP!3)JNF"6
MG@PPF&4S?@VSM[B\CR?SV;1K1 B
MXX5DAT$N7GR[$F8L#$4H64:1'<1$X5=1"!('!PPR,LWD^#G.I;DZ38@+2,+&XAPEOVTXJD_KX
M][:Z:KE9::>P*D2MN&]^+K$GS4 /1=K%]7Q7OBQ3L^Z6K%AUN @WLDS+7-[K
MYUC)XB/(K1]+>1>D@C%PRPE.T!>>$C&]E6(?L Z=&:KZ7U)BO2]7$I2V7B2S
M],')-(N[OF2@%_"'G,\S>0TOXV]33(.5?$5>Q"5;P82P,8!2]LN2QAX^%?9Y
M+FP]P/.$5PX4^=*MIR'%E1G&X(I<09B0J$#"O:M;N%F749]E0/I*7B_&6&'N
MY&^93"EF*V\K(PD+4U&Q%,GW1( PQOO%J#J794++@&&2_[8,M%]2&%9 ;)&'
M+536A:ZVPJ8^3[QTZOFW$BUEA1_]YFX&VDIZVDHA&'E)+6KHS(#;^&DHY:SB
M@\:*),_-045Q)F9.??X^Z;:'3X 4^QN+D6%6J+':4S//=9+P[
M2_RO/!=>W$PXEI?3ABVZ7R>'+<1'V.7YV!/Q8*E,QIJ+K!&XNM&07\B=Z%G&
M6")D\06GYL'=#$64+*/%HB?$ GA.2(#'-;5>O*$AP$!3QH\OLBH-C ,,U
ME]=B$A625P@L"7TS&;(=$4C%BHS)0L,)9'2^X',K-9A\#Z[8\#(N;L YUB(0
M05I(\XSG\UD108_6[5#4R 5V6MB3EGV7-$T>MH7MYCZ4!XO*3R+60K+2BB5^C7@X!>.L3*@XQZ@MR?TF/(I728N_YQZ?V(NA;@>5].*5XTZ
M][.*I7AX72CNP)R0OR[K#LAH2,GRRWQ]H=M(UCTHGBME4:':R,2!90FS95&1
MLC#?L@+,4M@L[@:4&M':RN]F.$\2 ;.'Y@61HBQB#@K7%R[R;H$V+/*;I,$R
ML@U1C".N@/B^F1,_%O4-\+PM2"!BPN$X%P%!R^IQ*$4MZAA8/Y0126@#(.:]
MW6/Q$041PU[OMPPQ6(5>A..Q<@AWP[RV
MGELHI@GH_A,DCP1/G^@#*"0S31, QIAF9!$%_R]!?UIB4]1P+[&/.BBBQ%7OSRWDJNB5XF10L3W\^N$?KTAHI
MXG'Q*_; 6IPFH;271PK'_ 5M44XIH1^)T)<8T_/',!&,(#F'XX5-"J-,V0%I
MNHCH1-"4C\;**$V\P)>!I*+4ZGL,0U&.YEALEJTNHW@/SGHI@@L3*:SZ7K7*
M1Y>%3PONBZ'1Q8VP.GY](X"*)Z(;+"=)AON4BB*A53XK);=AWX/$13ES?#_!K,\"IR
MH973T@;Z-Q@#4\\N4@_#EI1S86%5#H(I^ISRPC2\\QE3V2S+4HYN^%08V-X+
MJ/T[26Y$*.L$K1+B5RDFI97FB(4!;W8G]408E+V;4"8\B%E*&/!R^&* 65&]
MI$B06WVEQ)?P!(OT$JS_+3S J:@.OT!70KZI5VO,(IV,7&8\\['"QV/A=!PG
M453H_\AW_IB+J@] KG_RF/\YATM2"F#ATI/P,P4:6AIZ<;FX<5$V&L8\]$#6\(K23P+@:!B& 7>_AL+;!FQS
ME!2'1ZQ41N]_9FBTH&(G1 ^90D 7HP< >F(NUJL6QQEF]"
M] _#/($V,!]IK2D7O7EK K?FU@2/-W+\M.AJ_LL\#-"$]6"!;WX6,1!S"?*Q
M3$W9C9)$%*X5^;@R,+;H8Z$LV[FO%$N9P2=%.+,G2/BP&WP1*(VVI/D(2V*(
MY,WY2 3#X)Y@2&Z**6/H%SL#J:!L_>Z).GQH&XLQ[V4.F$)K< :Q+(BHJX$U1_!KODB[@Y6"
M&%167)0A$%<)"BP8R[-J+\1[8\J!$]S*LM)W+7A%?K45\(2[J58" @4B?=,=!?QRE W&5G*:".SW=UZWC0KR8A&F@_&.U+=B3
M'((N^I>EG9>MG)&K2,8E8T%&?)%U^KWF.@-UI;Y[H'P/1%G^2E0+* N;ED^Y
M/\C*5_K]YO:YH.[=/HY'-X^?26D,P.@38"\@6D[$]\7 DHD^&,Q^O)T)',5Y
MA,A?U79&7@:BZ2P)12%C8:TO^@U=%G!3D!G[X:Q@?L!LQUA40@93+V9Y]^H>
MWAM8R.:/\]/GLG<)T)L ^NQ^H]$P>Q+6NCZP[J':7O[F81LW9Z4%G'!4/<0Q
M47.KU+QW%K,,BUBPPKZ7%*FZLJY<+K54.N1P)?
ML> ?8KV:E;RF^D7Q ]S"C579'Q85)L?DIA$"DN K*E8(["Y2*-#*1)>+"\ 0_OU5\<+U2E97E:_&ZA
M$S088D5V_^ZOQ8Z<+W;D31!6T24+ZE_&GZ7B7>4K"-&X!B20=::%'C90#E"5
MBI8*FVB-E^-UA/&V*(?@S*5E8? $8Y+U,KEHIJ49A!J&RH2BPX72*L/IBKM0C71:MQ*!QYLC*]
MJ/ZR:-PHWS(-;XJND#*&7<8@+P+FH^".K>[.,_%"_A2<&@W@R+V70V7W;N&E
M(B2KP^1%O3V9F7<-NM4U7_0$3LL[PKOA15M6GH=2FYLNR_4MU#&V4F7OOD+\
MX,P5"N&B-WTA9PJ]#(-V,O$:G.6"]AAY$WDAUE]%C?BR4"QEBX&B"1GN;?%)
M<3?)-10]-^6ELQ*="RH\T*P8J4Q)+-(0[F1J(QG_++Z7AEBW%E.K8]1-47U>
M[@<3*"P39\)EE3)<2\ Q-WBYXRO,2BD2UC%Z#?Z5N$++-2C>_IV*VO!\67];+*TH>%^N@0]B('SB5M2DYX5"IN6"PCE!&3.T6_T?.CPZ)=Y?L[P6RX%XDH
MYNF+.MVR,=H7CEP67=V?L$*HIN[^=V'H&F7\CSE^LYA,@Z_U@R5&&B4TGBW:
MO*/'BD<% P>),1,^RNRA,"0GT
M7W-18M+8"E"/#O%N2V>),"ZN-*Q9G=B*V1-=S(=8@A;>N$@F E5
M)%4*K,/L_*SH)B CU$50>K8H2UNFPN-1+V7?1\7:Y+'I3)!2LC@#70E[6@PLQ@N.Y:,IFQ&ZL[YG1]8XTA:V1$PF$28Y>/_\I
MG)Z%V4)Z7$1,QRS%.Q[$FDS6 %[X*+#^G[Q.5HN/E;(J'OC$GPL)1WY+QOCA
M35L:J8I>;.*F+>OHX'U_XW,L459&AHL*L "GJ;"9H&*S*!2!<>17TJLZXC*D
M9'$QGN -=EC,=O>08_*!7\I\[-Z7?T;_R)%,W2JR>.Y^ <,0X"N?(T^Z\']/
MTJ^#Q?!ED6RF:+N'$5:.SQ8)Y,_GA M#,5,^K4AZL/-ECNS![^=8MCX.L-M8
MD48V+UW#Y2<,O;]8@OYPDHC*'Y]"=# CQT;Y1OSKXI^+@B!'_@3$7!$3SI2_
MPP*4W[WH*Z;2+H6\V\6WSW/@O4FVK/8"RQ/)Z)]E5Q?A"!1*2]YBUE!FL
MCHM@S\5J!B@VE-VX%FP2XR>S\(&I0K)?(1@*IZ;RXW>VN2\' K!O[E+6K7;)B]@!X6P(LOG?:,G.H\Q?!?V^;T,BOB6GE-P
M :T\$/>F+T,?%AP#LWQV1:C.+.-[Y0_[09C-(N]V+Q0N]EWQT/[=%^ 9%!ET
MH!47+Q'ODQ\7I]AU!X[JX$'.X0CF0?GBXHP/Q!G_2QX\_,RT!J[M//FQ.M">
M_.RY89V!ICW]Y'.C/O^991@T5YIK[^>ZWJA_$=Q <@3@.1F(QW]]9[Q;2@[B
M:M_3![8^RQ4-_T'5?Y\'2?;S[LTU&E5ZA5/MS@W8684Q!B
ML<=NY3V6%\>3N_Q::WS\,KP0SL83Z6P\PEQ?%.W^/H^Y8JALL?;[JWZ(+!67
M^:Y[&W0>WM#V/(,?4DKYT0@(Y 1R)J^@?9C%_T]VZLA=N9M +C&./1*>N5:KWP<
MS9K^#)R7_TWN%L;8QCQHC.W0Y1LZS\/!?)_SE<$V48:F81!$
M?(O7@+.6\_GPX/QO3,$_E:-__';\SX-?CTXOSIER3KA=MR#3;[(9PTVU*V3JS38B0/8WK)O]]45C/0C^=UY4#"H*@R>QC^4,XH5 *^NFY(J/
MF7:B!M"RX(XGZ[.$1>HTJ;DT1B_'V+Z:ZS:37WSD,^ 1X;+&D3=-8%)_+MK9
M8K4HF.:MK+;UQSRJ95PQ6HDZ[6!DJYS!T.B5+-IY3N,G/H$J6:3RECR%R#=+464,H:,LLF^T<+
M*.6 1*&JG5.J&RHEG^>)_W5WY&5<5DSE<7:W"&,5S#V^"2W G,TLHZIKZ%L4
M?RWFL*Z"V%%"J495&98(54L4-^B%524CHE0]E%*=JOV/J/TWBW:5='CMUQ1D7Q#!V-)I)E,&.H$96:3243Q&.+B-1L(MDN4S6#J-1L*IG,
M474B4K.)Y+ALJ-4H._3&]/Z1CWF:BEY2,G@-&\SUR^ZND36C#51RF%TYRI\H
M58>76R/G2 O(9*@;!/@0I>J0AG1FJL[ZPA 1J08BF1HSS;KOI[ZD#Q^*!J;W
MNAG+(&C9(*YH^ONB1(MU-3 :@\9HZAB]T6./B_;?8=^T5S0-6R8)!\TFDE;-
MG$5$JL45QG3')B(UFTB:2R1J.(DL-K0J>)2)2'6$\3'5J=M,UYO0H /?AV6
M;IIRGX=7V*Y5Q /U-5\7Q"%-IW"&AA-IR'2U@F)!1*K#*Z93.F$+R+2C&HQI=@4&M1T(ND:,U670H->?:?/4# MO"H]LZGJS'5(@VTXD4SF:.05
M;SB1;&8X%4*BB4CU:'J63MZ)AA-)LYBFJD2EAE/)8+!M5^
M65 =IEI41J\%A'*9:9*)K@6$VM&8.R2?1+.)Y*@6G:7FD\EF.C6Y:0.AT"VA
M=Z]W0'-%UG3.@[(V2/9"]W][E223N58%/PMILO78P%4*66TZD2I6G" BU:)9
MJ$RUB4H-IY+)AB9=2@TGD@TGJ8+OGZRK&V[T;S'WTAADU91?\7C>,^OJCJ;5
M&&!"FNM:XBD5K6LXB6R5VL>T@$P.6>I:0"7L1EVWH8X(M<[%Y)A="DXUG&8*
MJ*=EA]59FER% 4BJHUME9YZ)2G;O'VVY^A(CZRA) Y[NPDKW<&^R) H#I5Q?
M^T!JZ,S2JKK2-MB*5JG#':.Q:3%C6+4I)M&X731VF65LV#:%:-P.&CL:,[4-
MZ_01C=M!8TW7F&80L^XVD6W,7-NP'=G;$+DO]0./3_]Y='YQ?/J+,[0=A-?/D?YZG_L3#X*MDC+:#&4SI5@1B\3_FX6S*X\VZ
M-+77I6KH3!M2=$+#J6293%VPZF1R#J75FC_=%9_V<)C#Q(%/&:3)]0G15,B\J\@K"V(=?A%<;^KU:ZW\=
M5O9KD9N\#F,8TPS*BVT%H2R'XKA:0"A0XU6*$&H!H; !:54O !&J%D*I'4R.
M;:9T>^"##)N%>9C$F:R-G8QE@)>'GZ0\@-\F\>[42[_R' N^@(0+PFV.8B\\
ML4BE%0_WS(2K 4>ARE -)Y)N,L.J,7>)J+3>4;(I-;WI1#)[O192JIV_X<$B>D!90RE"9JU.R= LH93M,=:NF
M19'E=@L1M=L39]NK4F$)>)>L$PVGDFXS5:7HLH93R< X$7)M-)Q*ILMTFZSF
M3:>2S1R#PIX;3B5'9VZ=*01;-\BVM(*,C"[80@698G\ZELR,/CA3K][1MEG)
MZEO4DKM&7P?N=+-Z/Q2B;TOH:P-]]0I:*M&W7?353(.9%A&XNP36#695*89-
M!&X7@74-%#:GJ5=P7\S;GXY/#TX/MU4J9EW=EL:@,9HZQC=.?A!FL\B[W8N3
MF#__6OIF.[_9EYB]NQG7V21)\]VJE#:<2 8SG0HQ 42D6MB=Q>PA\;N&
M4\D!I9""]1I.))!>;:-&AM=/2VR4Q)=+N;5?UMG5LZ6(1&]*HJ%.IZCI)+(KQ-D0
MB>J)6+.J%.TF(M5$)+=Z>C;95;&5H=ZAC>< I11Z"F
M4TASR2S4=!)1T''32633*6HZB0RU2UW<6UIVQ&)S>
M)A_AOMBV/R4I_#-6_'F:\MB_56"+N9\K22QT""8U"?['/+SR(C1\RR(.*<_R
M-/1ST"GP"_TR>FM,K5Q-B0P.M=B^J9Y#LRFD88L'.DK-)]2.1=;59E-H:--!
M:@&9=@R-RCF\B0T\C/T4PXB5G8#+G[#GTJN+M=W4V$ A-\T*;1))(6\7>76#
M.793.T$0?;=11VA8)1*(Z-LN^KI,C+\=G'JCK=%B#\V*;5A.#OWV+Y%4#[QBYIC9E659?T!AM1NVV&0-T?4 ]5
MYNI5JPL2J G4308U<6H"=>= 39R:0-TY4!.G)E!W#M3-Y]1]\1"?__;Y\Z]'
M)T>G%P>_2GO/IU_/?E>.3S^=?3DYN#@^.]V\!_=#RYP!&Q$D\U'$'U!LH^[)
MZYI2:98TR_[,LC=&:I'=Z0'['R>I$L8YQ\ 5C-F6;?9BGF-]$M^;A3G,\D^1
M^2F_],+(HP[*%VT3(2Q]0Z&X;7(O0:]IT'.,JIFS!#V"WI8RQER"'D&OIG0O
MK6JN(H&/P+>5>G3V8\]7(LTM3'2O@&E,Y5J.KJ15DJMMDWE=#K)],N9)[-SQ;Y >D? SK[)DIUF2.
MK9'*VWQ"ZP4HE0=E+*9H]*9:@&E=),-W;K=4GVQT'Y.47;-;T7G(6Q%-)MR
M>/\]^?9NV.R*[78*OYCC7S$*Q3#$- G",:QI\[B$UJIAKD'!9BT@DV53Z&8+
MR.2ZY"!I 9ETINED)&P!H31F5\X_(D+58DU3S;I/5%^LN<>/=^>Y=P=8B5J]#1@IT6\;V,D'5WS_.@SRR9ZFXF)6GY)OV%.7CWBC+(GF^<-'Y)Y_^&F$LRBV0/QZ
M]4\<.@S^^BX,_+%GCQS5\YNJJ;(]_0?C"X>6@F9SG\)>TQB=CY4R&I:Q:XANX@!W0N&#$
M".?)%'[C>_,@A.U_>IK%@2G8PCV.O)BXX$%+
M%B):#\ "(F^6\;WRA_T@S&:1=[L7QF(NXJ']NR_ 0WE?O<;WR8^+8^VZ@Z%E
MX,DN-/WBQ<6A'XA#?X\;R\],?%)[\F-U\/1GSPVKJ0-;,S8:]OG/+$.GR;9K
MLN9:PW[#3O42<]1"1EA*NO2L1;>OEPPW>7=S1]Z51M_(>2R;W
MZG+G_34^SK(O)BGGR@E\;Y(I1R"F!"B7_'T><\50V1KMEKXIKK=\@\[#F_6V
M9\T3N$X/GHTZBS5Y$T$NM]9IW;7.PONZ@?8V#F/']XA ME60%2SMG@' $#OS
M-@!<8QQZY8M?^3B=-?T90F_NJG:W,,8VYM'V,=KOF?ZV"B#8TBGZEM,DF/OP
M5B]ZF%.T'6OPFW2R6'/)Z[>R>'Z)-;2R6'.%]I#I9D<\$X2_]N'/<9C=E20(
MPE_[\*<9.M,U8H $P+H : Z9J]8-P/8G%U408N'1J]#GCPNQ;0WE77/]KLM,
MJR/M:CM.*DTWF%JYZPW1JA9:N1K3+$KC:@.M=,, D:][A>8=TB[F5\Y3)BET+J5QF&^1P: .I+)59E0U#
M1*I:2&4SM_:B9/W1:R^X/XGA-9>RL%48CU,OR].YG\]3WC,]5W>89M<=!T0"
M^7IMIYEFD9[;!E+!W0M4(E*U@%2VSIQ-/2NDY5;>[G.T)BZHFI?WU1=YMIU"WHDDZ]'J>H=5XE2M2BZS'*KN@.(4O50RG#J
MYG[]47//\LF==KA%J*"R$\9^,N7O1>NPOBF^+LGG;:"36]5P262JQ\9,;?9:
M0:?:VR%N7=NS+I[\&U2]E_J]>P.626L6%<'V4,M87*CL$TL]$90T3E
MEQM*AA9S-E7 B?N$J76HY1IU)TJT!OU?7'1%IZ!
MGKG@=RS-?D_^PF;3",5RDZC4>"JIED-4:CB50 RJ\RSU1H&5\6Y2>U5VBLOU
M!5%N[17G-$!96+JM"-&X7C4&","J7\R6W].M8
MRX4^/^+C).6E=I][-Q10?\>!H[*AM:'*WRRN1#&XS]:#)R)WG,BFSBR#.B9U
MF\CP)[/=1N<_]<8=_SE-KL(L3&(%)(R7"QBM=E39SI#BWBBTI_RI
M'*XW<.,\M@MUP>W[MUA_!1B^M9$)%$7;;+(3:TM*"L&Z3["V=6:;&Y8S(U@3
MK!L*:\-B>F6/ ,&:8-UL6+LZ<]4-&RTTU-'55A/NK<'PY?4*
M"=>$ZX;AVA@8A&O"=>=P/1Q4ME:^+:Y[XT'X&$;SG JG ].Z,OV8#F
MGE%M8+\\+:8)=\_VC%2$ZP[@VAI4;DQ&N"9<-Q[7QD!_N:N,<$VX;ABNAP/K
MY56C&Z4KM-6K\+OX!P]V/9B-=\FEGI I\XQCG"\L?CJ;YUZ."3;)^!&5XL?O
MK.$#*E;9LO4H^F2HW3;"]6B639]E?\KQ"#=?SU+7-)79M;'5WS_.@SR"6P6[L7J4\6BU.4CWBA+
M4+9Y\(BDV8>?1CB+8@?%KU?_Q*'#X*_OPL ?>_;(42UG')C!6!_YGJ.KNCGR
M#=VW3/X?PWQ7/C1)R^G,O$N^.TJY]W77&^<\W?.B:^\VNSOG:1B7Q#7U@8,+
M?FIY4R^]A&\C9<2^2%+LHABY9]@E7L,XX'&^MZL-Q8EZ=IDK@Z]0S^?8TNT\"NN#DX-_GYT.#L].F')\>CBX.^-FS?4PB44 OX>!)>,%1@Q@O.2O6_T1.>Q-P]"V/&GIUF%^#P_?)CXN3
M[+J#H67@82ZTR>+%Q3D?B'-^CW_+STQ\4GOR8W7P]&?/#:NI ULS-AKV^<\L
M0Z?)MFNRYEK#?L,6\A(WWT(L6-S*;R-)B>OUK@RUK9W(/K;F&,;VAN&,-)E'KC
M5BS,LHW&MOIHGO31EF_2QC9%_-R"/CL-@R#BC9- ?XM3#A/\DP?*I1?&F=1S
M>?9> 0DT%JZ<1?.X"0\N8;KPJRQ/YX\+IJH02ET42M52(#6MEPBD[4T3_?&[
MH:[I^Y32VP):Z3IER;>!3G2FVD,KS=RP'Q:)IDW_)FUL4T33UE9U.+CRP@AS
MEG;'2;J;>1%7 CZ"&7!_GH9YR+,7URIK2@4M&F.-,>IS,CZED6'2ZMN?B\.)
M%U^BVU&H5O.G]+-'7 +2(Z 9S'8MZ14P%DX!S62JT5,]S*2J2JT@D\;EH5CF/&]
M$ H%E PA,4GQ2=D1TM1[C.Z*YH$LGHRV)5W=ET%@9=@7OYGQ..-2WF+B*]K^
M?=G+DN;N[^&T%0*7QC13[V48QH[FD&^_V23:S(A*M*KE..G,=#0Z40VGDL$,
MHT:^1T(6&;K;]!O9I?[R=C+/;T*K+ N=
M(NU+K'A$WL:3%\11PS77%W2(LFVAK.&"HO'R]G6O1=[F6;OJ"=@4UJE'G'_H
M\--6HRZU+60!=0K@.]5CY!O$MK9?D;P;5-TP-Y\HVWC*[E2W>A%5B:ID/VO2
M-[=NYG&:&L]XD>1>I"3?JB!!-J!ENK:Q86Q"@]@\:9-/FH%,;<.4&B)OX\FK
M,].BP]M5ZAI#IEID"JI=I#A\1(QXS89:&R&WU?7@MK\[S2TEI\.5[%;US&Q]
MGVK7O.G T(%9MX^AR53[#7KHTHFA$].)$V,XS#$M.C!T8.C K'?%&"ISK3?H
ME?NJNEAW^N0Z[SY0G]P>]R%^U@?R>9WQ'54
M!X_M!AUQ'<=]\N.7M$(UGO[X)7U;-^L&2Y.M;;+K-=I]HXZXM; G;WG%2::K#U,K91$2K6FCEN,QRJTJR1*M:
M[EP5A#ZCZIW[QI4I.V0S6MZY%3.UOI4Y]XB;J(M"[2;K;Z[$ZS!+VW8*Y;/^
MPH9J8X3J+J':9=K6:W<2JFLG:\]1K1G,L+9=LY1@73M=^PYKAQGNAC:WMX'U
M!N$DK^KU7EGU(^E43?'-TRQKG65]C2K?.,CG&",.8Y$4Y44;!?E\XSJB,1HX
M1G^<)-6#?"H9 ]LI"3V_Q.8*.X;-'+LC#A_"7_OP9^I,ZXICA/#7/OPY*M.=
MCCA1"7_MP]\0^_YL6"N+G(UU!?A4"IEK%-X,B^EV1T)J.TXJ4V7FL.[8/R+5
M.J2R'="B-G3P$:G>5N ;LF'E6GO;)E4MQJ)I& 01;U& S[?ZF'3=N_:"]3=7
MX,5JRAOJ6\WR&6^GF"6ANB.H=BJ'K1&J"=7-1K7.+&W;C0()U;63M>>H-IAF
M-AK56PGOV:*_^Q5#4FB679EE;VKX'/Q^3I5[>C)&?QPC5+FG0V4##)4-G8Z8
MHPE_[<.?J3/=T E_A+^:W'$JJ'@=\9P2_MJ'/\=EPTV[.+?;Q]CFH)XVEZQ@
MCE95WFMH$&/7264Q>U.;.I'JK=MYFP:=JC:0RG29:M2=15"+L:AU03T/+S@,JV].3,?KC):&R/1TJ&Z!A
MQJE:5=AIJ'&: -@^ .JJRFRU[L(5!,#> M#0#6;858,L"( $P*VYAW6FZ54K
M"73"Z=CF*)]*87.- IQF#IEE;.B.:)IIMNNT0W!@UTCLNXP<]/Z
MV$3DEA#9<)CE;&C+(B*WA,B6QHQ-DR3>-#R@![K\19)[D1(G\6ZR#0&CO?*L
MQNS*U9])\ZB%?1C,<(E4;2"5R=Q-@]&)4F^;J.TRP]FP@R1I\Y6W^W.:7(59
MF,3*.$F+"U?)O9O>)WNE.>3)(!K]HIG^93#%#P_#Z_@(Z;$/%>2,=Z]/5-X
M=S1K?0B24%X/B2HPB_JBTF-5 ;66HJ#NJBC;UE2%8
M=PO6MLYLDQK+$*R[!6OL0NKV(:J&8-TG6+LZCMHC.:,T1\7R;]^_,YT]O\E_""B*(4"
M"[O.)YOC?8LLBL9XHS&VSM@-IZ%X/TW2?*(<3.%IW^M9L$V=Y<[?>*D_O.I5
MW5%XU%A$A.#1>'C46.&#T-%X=&@;NGQ:#X^MJPJ-%9V.XYRGL9>'2>Q%/8N6
MJGPW4JQ'+62B0A^M(!,E!;6"3!N6IF]N]%1C[];G>IEW5&"LNTL4R?7K560@
M,K6 3'2:6D&FVKL8]D=;7:N)0$?E-BJAUP8RZ:0%M8%,E;UF1*9Z\@ZZIJPV
M-F9DTC8<'<0^"
M!W&/+42*M-:;]?)(D?::>/6.] +L.IEJC(4F,M%IZAB9ZCY-_;%+;!HITEZ!
ML7;++LGUK\(#B$QTFHA,33U-_=%67QPI,7WK\,@G\!K<=35IXJ]5)>/>"/8MGG^\!&Y^@\_C7 6
MQ;3$KU?_Q*'#X*_OPL ?>_;(42UG')C!6!_YGJ.KNCGR#=VW3/X?4WU7/C19
MU*B;>9=\=Y1R[^NN-\YYNN=%U]YM=G?.TS NM\G4!PXN^*GE3;WT$KZ-@!#[
M(B&PBWK!GF&79R2, Q[G>[O:4!SB9Y>Y,O@*:GR.[JBW+R)V<'+P[[/3P>'9
M"5..3P\'=V?Z%L9B2>&B_@'-Q
M:!'1]Y5;?)_\N#@3KCL86@8>BT+1+EY'GS#F%$A7'+=4H824:]^5PW7.B8?N<^G
M(S@6AL848/36&F)5U_?D[_.8*X8J]L.N$J=1);9V'9'GK0K";21^-9F"._/8
MFP[ FGN*W0/@X/S^Z>-I32''HC:M$
M^X1Q>IZFHF-9EO&75*'=@&&TOPIE8S-H#KULHG@Q+!-_X'_,PRLO C(_:/^Z
MG5B15E>F?V*)S34,#&TVK%SAIJ%Q2X2_]N'/&3*]<@IXXP.R&LO+3[ST*R_L
M!MR?IV$>;MC&N[W1"H8-D*M:()0"2^H@E6DRQZF[3%Y_)+WC^ KDNB3=E">T
M-R;8&#)#KPJTAHI!W2>5-JRQ@&_/)(8#WX=UY)F2B@VQ$CAIADD]X
MVC/QP7:8HY/XT 92#8=,=:LFY31>?+";:OZ[2'(O4OP[1L MQ*AV)EQ%UUVF
M#C=4=EO5P++75#9=IC>[J71O'!*?TV0&T[@5P@I:KF?8*4_(+SV36@S+86IE
M#8?$EGJL'C93S;J;.'2P?^;CVWT&+,++84$-'9NP:S10J!I
MNLYLE=HVM(%6^M!DFE%W*:*M2PE.4QTDTNKY.%OXUFJW8/MJ9[C2"];?W%BF
MH38$O7U#?T.S[+O?D*L(UWW"M<94UV+V<$.G9T-MVEU,I/CU^.#GXU^/+XZ/
MSI6#TX_*^<79X7__[>S7CT=?SG_\;JAKSKYR](_?CB_^]9)DBQ6"/I(ZW914
MC UFV1O31IFH$87>*(Q$$"AE:W0CAF\1KS/S;C%8AY(TVA\DK^D:<]6JUV]#
MU6\"8 L!:#K,-.M.$^I5T&4ZYX'";V8\SF#(O@9;.A:SJ/5@.TAE,%/M7M!"
M4UG$;S'WTAAX1,JO>#Q_(.=UW4]G4F.YL&"#1#;-U8]C2KTE\N9OS="JC+%_,
MF-I['PX=9A@=,>9TG%2N":3JG.C2?!81\%'?$C1LB]DFM3MI ZDT?_W3QJA0K'/D?@E=[=:!JRLQ+E2LOFG- @;NO6*HJ2^D##YCGDR2%-P3R
MHS@I/PFS#!VK2:HD\SS+@5G VNZ5W>^)&"M.DKY/*@?1JO$J1[/X$8H;2?PL
M,])4E:E/,R1-8[II"UD%?W2'=_E3.09S#$U^"7X<&N67ML2ZVBM=:UK=^4VD
M!:U'I^ZI0$T-"+E(N9?-TUO)EICBY;#@K&]FU!V'#0WG/8DS1"4*$\-(4I@P
M9@EY$4@H8; ;QHKOS<+'F\^D\
M$OT4190YK'@8B Y3[YLW5K=49AD4@]X&6AFFP])O
M1['HR[TR-8VI-L6B=YO*EJ4Q>]-4QI;&HC>\9M=*()EPLJS/KKZU(P6]BO;J
MCY0?Z6V!I-?PU]JIV09..#AV=MR@^UJS#(Z[6OXC&FZ6K'D,:
MPN"O[\+ 'WOVR%$M9QR8P5@?^9ZCJ[HY\@W=MTS^']-XM_I0L>0'M>3EX17?OPZ#? *4P8U??:K8/G7YB#>"
MG9KG#Q]Y;79WSM,P+I%D
MZ@,'%_S4\J9>>@G?1@R(?5F-,#'LDG>$<0#[O+>[$G/RY#+7H-.KG*''"L:]
M^W!PD- ^A;$7^R'\=!R/DW0J
M"MX)6>WG>0:/9IERPO,T]+,F+VDGC!48,8*Y9TSA-SX'#C+CJ0SG40(O]]XW
M>O[SV)L'8^<-^$&:SR+O="V/Q
M9O'0_MWA\%#>5QMP6^3'RV,]4.71+G28XLW%QP/QT;U[0WYFN ---9_\6!UH
M3W[VW+#.P':>?I)&[<.H]D!UGOYT==1O:-\5@LQ?5M)TZX*>LQ:3^8>FP,5O
MK1'+W\[EZ=U>GM'MY9G=7IXX>W9GEZ>_S?*F81!$_,V7]Z\?OS.=_7\I/Z R
MME$^10EU]*<>RZ"Y;=4Z/IIV\"6:E33"^@%]>?]
MO1;G^E;G11^/[AB.KK*[J^2I%T;XV_R:1U=6G(<)T&X?7V
MI'*OB>98=-=;H*89S%4;T&".H-,ZZ.@:TXRZ(_P(.FV$CJ$RV]4(.@2=ZM!Q
MF:757>Z)H--&Z)A#9AG$=0@ZU:%C:\QL@IC? Q$#C)EG"93)?.B(H4NC#$T)KR"?THMB_RU
M;3=$#1WF.@UH3$'(:1MR-%5GKM4 $R9!IW70T2P*$B'H;&8!&S*C"3VC"3JM
M@X[I,-VMFFE,T"'H?-!LEZEJ T+3NNVNM6L,PZG3]-(7=^VGE/.'GMH=;?VX
M[TI6Q59RR.=7V%A ZR#1ZPUH7D?(:1MRM"'3A@VHW$W(:1UR3.8,ZZ[Z21\T)AN-* [%0&G;<#9<9BMFB_5=%[?>-#:N(T=S=1KV=Y6
M60Y:&KU0]F0L^BV6Y7QW1U[& \6[]M+@3N/$KK0Q6=<5RX9.U0A2LDY6WV77
MJGKWTRYOLLL;ELNG7:ZTRPUPP'=_E\T&.!P[OLL:4W7RS;WV+I-KKLNNN;L"
M]DLEZ=8JD<"Q[=J[6O=BE^T:\V?ZL\N5&R;2+E??9:=R#1#:Y0UVV6J PZ;[
MNSRDVZ]ADC29JELE29^387H9%6:3C>FUM]@ED_2KH[@!"9(=WV*=4/S:8H=+
M7I771K'9@#JBW=[B'+-6B?=V8*-&>33&VX[1%W/![TD:!==AP)6=WW]_+VI7BE*55$RB
M[;ERFF4QVVY Z!)!IW70L1WFJ)2A2]"I#IVARC2[:KH&08>@\T'7#&8,:^SA
M0=!I*W2TH<8LC;@.0:2IA!VBRI#DQ:\E0B#MKI>[ZE,55H!DCFIH8"V+94932A^0M!I'70<
ME:D&E6(GZ%2'CJLQH\YFV@2=MD+'T6SFZ@VH"D/0:1UT3)TYE4LF$W0(.A\<
MQV+VL $75K>]KEJ-A[-.RTE?O:[8"9 \K_<*&Y/QD A+A"7"-F^E?2,L>5X[
M2M@:"Q028X(YAU-+^AQ#36L1H
MJE4K9,@;WQ]O_,/R4
M:["#60M=)6V-O>&)M*^X7+=RNV:B;#LH"X>62-M1TAJ5&S83:5M#6CJUY&WJ
MA[>)*N]V(,#=T9CM-B# G9#3.N383',;4(N.D--"Y.@J\1Q"3G7DN,QUJ& !
M(:?R H<6I9T3<0&F&=O:>=SH X?N*<)-Y05:@R8DU7<[SD(W>QH>#HS*;V@P2X(
M-^W%3>604,(-X>:#,U#)&TBXV0 W6M5 8L(-X>;#<& 0;@@WU6T(^J#./L/]
M"#^HLU-+[1:$O^3>*.+P=Q!>??A)_+&M.0W7FM-_GOUO,>%R>N7$BLW?16ZT
M9XA]E[L>Q@&/\[U=#5[_YAN\H[TO9_R6+]Z_LQON8&CBVC^EG"N^ETV4<91<
M*V&V\H]QFDR51%;/2^),27DP]WF@C&Z5'[\;ZKJZ_WF>^A,O@\DE8V66XG?S
M6\6+ X7_,0]G4]AD)NKKR8_A2 29'%84W!/?#&,?OA9>\6P@1M7V[YVT-:A:
MT/##3R-$ZY:?6SFG.%.>ON)3!;U,1.HLR4+<^+V41QYNT/YU&.23/4U%%*T^
M)3G%GKI\Q!ME"=K 'CSRY"16_\2AP^"O[\+ 'WOVR%$M9QR8P5@?^9ZCJ[HY
M\@W=MTS^']-]5SXT29<;?[?9W3E/P[A$IZD/'%SP
M4\N391MW\V2V)_;E#AWM9\[TD\M<@T[;.)::>N]<.H\RA(.3@W^?G0X.STZ8
M#3+E!.>
MIZ&?-7E).V&LP(@1\KCWC9[H//;F09CSX.EI%F>EX B:. KB]E[RBC3@*4HI
MD3?+^%[YPWX09K/(N]T+8_%F\=#^W>'P]-VW]N.VR(^+\^NZ T=U\ @7CH?B
MQ<7I'HC3?4]\DI^9PX&MVD]^K ZT)S][;EA[H Y-&K7OH[I/?[HZZC=<9J4\
MKRKR;#U3"6U=)YID)V\N_3_.8_ZA*7#!6VL4>FOG\O1N+\_H]O+,;B]/G#V[
ML\O3WV9YTS ((O[FRRL[/M71A9R;;7-NNCH;5JXB2FYQ
M0LX'35692G6'"#J;0,=FNDUF?!*?_$^_
M.D77F.M>YSGH/%VU&C/1B;!$6")L=:6!"-M-PO:T9$7W"5M5B>@@8;=8OK1)
M"]Y*N]A..6"I^$I'+$R&:S*5C),$G>H+-%6 #A76)^AL !W-9$.JPD+0V0 Z
MNLT,E0H_$72J0\=PF&57M9@1= @Z'TS+V*"(-#EB7]LX1H[8]AH3SF0%DOBR
M*/%*?6':7O7:8D.S 36O"3AM P[(995K*Q)P"#@?3.8,J[:N)N 0<#YH&C,=
M:B=$R*D>([=!"@D!AX#SP65:$UK?=3L*0^]I0%POPQ&*&&TEG,X\/\>8A'D\
M]JZ2%&O<46Q"VXVN.X;^GLSTA)@*B#%M0@PAI@IB+(,00XBI@AB'$$.(J78K
M:8080DP5Q-0KQFQ'@6RND6 K\?Q==,$_3(E6=@+NXR#O>Y\L,JIJRB+)$V88M=3,EBMQ1W71'5:DR1:'O#46X;K%AG79;0DYKD3-D
M>N4"^(0<0LX'W6&FVH!\&T).ZY#C,ENCK&)"3N4%&CI339)S"#G5D6,PVVI
M[91N>Z+KY.IU&E'()5NX9"\N3L@MN^*6[6GCJ\Y3UB$73TVNY0E%T\W
M*>M0^%-G*6L299S_^)TU? #T379!
MQ657S3>E,=YVC%[:#$Z?,@1LY^IJI46UI3GTAL$LC1I;$7*J(\=F#K4)(>1L
MTA*-#=T:[3.$G+8BQU*9H]>H2Q)RVHH5A5W
M6>MI&ETO,QCN-,B^6TFK]_6SJ'Q6-^FJ47F/CA*V:@P)$;8EA*432X0EPK:)
ML%3TCDIH]<7W6C7MFPQ,#86V9IK,'))5FZ"S 71<9@UK; =/T&DM="R366Z-
M^0\$G=9"Q];8T*4+BZ"S 72&3'.(ZQ!TJD/',9BM-B!LJ...V)XFSO72$7N_
ME!S5D&M[A0R-J1H5 B/@;  WNFV]O=E&EE)^ ^#O*^]\G3?>U<
MT'G"&G4:_(FRKWF1&MKZ%RD1M25$-2TB:M>(6C4PE.C:#KIJ5'*&LJ8[[J=\
MK,N5Z'!UMX1[3SM<&=0'J:.4-0I*UU'*
MTCU+KJA>NJ*J5*"BN/B&(MQ@;N7$>DJH(.!\L)BF-R"A@H#3/N"H>HUY(@2<
MM@+'9(Y%2:,$G$VN*HNN*@+.!L QA@W@.-WV05/.:+]]L1<7)^2/7?$ U)B3
MT!1K8B.Z)L9RE+_MBM!?4V18\Z
M^/U<.>>74Q[G/WYG#1_ >Y.UJ[C8JJFE-,;;CM%+2\'I4^K_=BZL5EI16YHO
MK[M,MZG2 B&GNBBGLJ%C$'((.9618S"U"0U#"#FM0X[%+(?*21%RJB/'8=:0
MY!Q"3O7()IWI1@,J'W;<,-A3SVHO$Q;N],J^6S2+2F75& S7% ,Y$98(VQ["
MZC5&(1)A7Y.P5-NNHX2ERDK=)&QE+:*#A*6263UQOE9-\R8+4T.AK6D:1LP'-,HT9G*2&GM;SXQTM;)>[;6"EMC
M!1>"35MALZ,9[DM//T&F9Y#158(,0:8*9'3=(,@09"KUN:>+B2!3#3*672MB
MMJ-6-M=T0(W=GFGL1NG2=Z-5:C3DU6EFZCQA-1WD[34%:>SI#4'
M-=8((-*^)FFM055S!Y&V):1UJ&ED5TGK4M=(P4Q<$W%.&FQES*
M]R/D;%02OWJ],D(.(>>#:3"GITUV@DY
M;46.93)[2)FBKQU>T--J[.2.+=RQ%Q7
MM.3XZNZN;(-W3?,OE_
M+/U=^= D+:!=[!R<&_
MSTX'AV)
M^7F>P:-9IISP/ W]K,E+V@EC!4:,8.Z92'CEP*?X=!8EMYPK@9=[[QL]_7GL
MS8,PY\'3TRQ.4,$G[O'@Q<0%FUORE#3@*;+UR)ME?*_\83\(LUGDW>Z%L9B+
M>&C_[@OPE-XW#.'[Y,?%.7?=@:,Z>-0+(U7QXH(+# 07N'>]RL_,X;ZXPKJRDCRG;RXL/WNWE&=U>GMGMY8FS9W=V>?K;+&\:!D'$WWQY9865'U Y
M.9QX\25_9;]=W6Z[Q_/^N)6V/1A92*JB$N&)3>,%#*65>X@^D%]((J
M+]A^J'[=A_1QF]B94/+@?4D*P^UHZQ9*G5P(N147J"M,7-(
MW50(.=610SR'D+/1 H7'WQLMZW
M&I"?E?RL_: KM3TANA)=VT-7\MITDZY4QH[HVE&ZDI>UOTW[2%\?KV>Y[8@T!,(D.=
M:.F"-'S(;LAYTD
MK$X6?R(L$98(V\"5$F&)L)T@+#E?R?G:/>?K^7R4^6DXR\,D7O&^6N1];;]M
M26-.G;V5"#FM18[.=)52B@@YFR#'_/2%G
M$^0X!B7 -BT?@;ROK?*^/FY"(/^1^/?C]G!RM;3PBKDUNUHX2E5I$=)6S59! B;#L(6UEEZ"!AR:W:.;?J
M63[AJ;)C4Q9KZTU'6)2Q 98C D[[@&.ZY.8@X&P"'$J;)^!L ARG";4\"3CM
M XYM$L ([3;;=JG54)ZK21],6M*HT%Y%A]$+1!IL%.TE4C8WXW
M"4NV?*(KT;4]=-6KZGQ$V)80MFI*3P<)VS^O:CF)Q?=G^;N-/:TJ;L)C*C:-
MT:TQMJYEU^Z2=QX]..=YXG_='7D9#Y3#9#KC<>:)BE%'-_@SWP8CV8@X-,;;
MCM&7&)3#),N59*QD7L2S_]_>M?6X;2OAOT(D.,$6D%U?Y,NN>Q8(DO8@#STM
MNBF"/A6T1%M$="LI[=;GUY\9ZN++VEO+6:\E[>0A7EL2.9SY9C@S')%4A]+X
M5+M-&V(3;$Z(\6JPORC!IFFPZ5_3>[8$FQ-2^U0J2;"I#IM)U1U,"38$F]M:
MG!'3[MJ3J_[D6]]A:%P6N7T9L?VC_BGU%]+W Q$FW[A0T"9;^/0(:PMAN[+#
M_HQK/@2;IL)F.KW@N_ $FZ;"9CR]8.D P::QL+$O>%(%P::QL.D1; @VUL('\=A697_>'QZ8&6%)F]EOJ!S\+Q0NAEN6(\=)D,%XKK1*5.DJI'U3*4
M/&V:=1Q8O3$M#1-P*@]P:(U']+(P ><$BS.FJ@("SBG L4,N<@-,\X RF
M=$8) ><$'V=2.>=$M045F7Q!!C*)_*>J@R:GT@=UB"-2K!I
M&FQ&-KU'3+"I/$![2*M]!)OJD]28K W!ICIL^N3;$&RJ^S:5CQ^FRH*JV0*;
M-BUHZ6$9GZ.$^]#=>C-/9W,S3[%_,T_*J3;-2@ZM\;1JS2W\$G*8!Q[:F-M6H$'!. ,Z0-M\AX)P"G!Z5-Q%P3O%Q>L,+'J+V2DH.IE1Q
MT/B*@_UG@9@3-T\Z\&-GP+4\T87::/L)-_MU^VFIW+JQ_0=VDA-@%4@>LTV%_F*.F_V PPH?$.^D$
M]<96D%6U*"VI(FN]7"_X?@#)]8S#O>!!8"37%ZR5)L&>4[!5,TPDV(8(
M]H([M=9%L,\8(=1IP/\U <'[5[F;(41(,9T[!7O!UD;H(]AECA#H-
M^%EBI :O(@G?%\I$22R0?V.@]"\6+=AV^'1JL-38I,CXE9YUT'[!7G#G(!(L
M"98$2Z:8!)N?$DZ";:=@26-I1:E]*TH_!K$?K00T=;5(?;^30+-F#^R8J\1\
M>_=V=#UCXF_'3UVXS8$F%7>22&GV[NUP.F.)".)(<;5BL5 Z"D/AO[)5J+XU
M&O-,GCF]4_/JP_A6RI72,^V4*ZV M%.NI*\D5Y)K<^1*?M.K6_[X/N%S7\"G
M*^]O?S#_/1=ETZ,H^_/ OY+4@K""I)S]'8SA;H:&\QG79>B*,+GI]*=F1\:7
M9?!5OUP/>3R(6+19",I"NP0D\XYJR4:($]Z31 K&5DI,K\O8PB5[/$XPFTEA.=
MD9:3#E3?0U_F9ADR4!\/VH^]E4:EVAK2(E(!3RRF4P?NT7!O]%5;[!YHB>!S
MR8'?%@M2>-(R#^IHD3QP);KLLR>TV.%63D_9?$F0CGR7P:@X@U \U-R,$6Z8
M.]^8"A0:2-I:$O YD(%T@5#[@Q1J18JI'9QH0 "Y0H
MR'&1"^_>3@>#WNQNHTW@MKJ7CM!=<[$_8TU3H$']%2A3$]0 )]5@QH72)13]
M50YX!J(,$#X $+@)X75GG@;]6#_VX(&V*!>T)5.!*$3*$,/,%;X$95LA#&+I
M?$UC!FC!7DO8FW8/XN*7K*WLIL;B85A'/#A1$$BMC1*;4Z3#%5A#GZ/V+E)_
M(7T_0'4WYJ78YV8AT/#@3Q%N!PW:+Y7;P13?JBAC+K6W<6*RZRBF3%UAVN&N
M\;\TBJ'@,2IBQG:<'43H1OA'G,Y]J3WS(T\3S_Q8R@S^3CQP!I<>FH2EXJ#A
MQ3RC8T #J!J>*0[WN5+'/E]E#YO)9Y.*;M/D.ZJC?'D8IOGL'T!+'AA?5#*0
MAHX<:;3Q08*G\#[@_X.Y\5>%>?5 !'.0)&@E2A9,,&  /XL)WL@*A>_*"'T'
M:^TL93Z#Z&0_KS4YC,+.^R]W6[-[@W5Y7$=99[I<&%G0W7NN9)3J7 3&Y82G
M-;LJ%;(PO(4D+.8)[B>>@Q/F^D>4HP.*R6'J].>)B)S*4$MU;.T\)[S=0X
M]^6^RP" 7D#4F8,+B+.O _HO$P8]@!E8*B%P&M"-T_9)C1#P8['H!7)F,HC!
MT38O^'@1Q (_&:_I9ZZ^BN0PE_,^;.1N'&F)\KPQ4 (/:P912N+=]'LX\LVG
MLAC]IK=^A,_!Z4^3QX]D?+K]88ZA]"81F_][:BWU)1@1)?C7#E\D0MUP_X&O
M]';W@0P+YMB#[@1I/T1IP-42[DZB^,8,<0M4XR<@=9#BC<8W4AF@&T#MX6?Q
M*>G^^XUTG04?SR>]T63AVNYB,'?X9- ;V'-G.'!&MOAS-'I3H:OG &"_MX/
M_2=U9%-%%QP\BX'M.8RI&M#Z(3=:'\5"A@:A^B"Y&Q"Y?E:+LJ;5-':#,Z5T
MCC R'_(@B+UWG"@-DZ-HKP;OL\AB_VA,>#6>/;?9/*KW;8[T;9Q%WMS^)F!&
M%*&S&W(&@H?E5\9SYC.A,06(KJ^+ 2Z&K>5-X,@ZQMW*8]7"!XX@O 13C'-@
M'F6R#X\;SNQW.<66E%AYT&KV "W)V_7=BL?R?KCS5RHS2
M T ,HF%J /_(\U0[(P'?-?X$28*,'!V2?C-5"VROHS
MK';7K'93]&H,Z;$2<,E\ Y_U7G2,SXOU'C)R#QNJ^FG^71;LDMZ_@-[G$:[1
M>EVD&0K=M !]$IUE0.8>_<_O1M@!4C?T?P%HW[0/>7M==I?W=A34\W;=P^VV
M$?QHETJ;0- _(_2W9H!LVDM#^5/>=+>: PX?Q(7)*"O
M5&>MKH/^SY[4Z\4,O%;.B-)H@?EM 2$B2Z107?9SZBAF
MNQ""3BESNK]%*WW=/BUZU5/PO&&.+HYRDH*N@XYJ# H=S,4>]:W%3_#'+$_8WTBR;=+(SNQRGIZYONY.1T/,
MT.25ZWG'>?*F:Y(W.S4UV35[VAT-APRX:T_'1S6;
ME_'O9./Z&?+V5]U4.)OS6V_]AY<,ON5=@F>O\CER7LCMQ:<0O'8P=.RW(B(]
MHMZIB>/=7Z_6DL$5.0Y]V&.'#//YF^IWKT=VS->YF1;*N)6
MXS>79?RD+-L)8!RFJ;B4QQS^W43AO@+DED*,U6/(/JJ;K=>2X_?SR%W!AY<$
M_NW_ 5!+ P04    " #*H/YFXM,C R-C V
M,S!X97@Y.3(N:'1MU5A-;]M&$+WW5TP=M+E(C,0ZM2TK!EPW#HHB:9 X\+%8
MD4-QD>4NL[N4K/[ZOMVE:%FQ@R1 #O;!YL=\OIEY._2\]HTZF]D7M)UR>XCC<>]U(5I-U8N:T_Y)/^=KHW]*%90?5[\=%4?'>3DYG!Z?'!?/68A%
M/A'B<#(].?EW>@!5B"<=YS>*7QPT4H]K#OYGAWEV]+SUIVM9^GHVG4Q^.8BB
M9_/*: ]_%OKI,IGYS)CG&S\62B[U+*9TD%2WKPNCC)T]F<2?T_!F7(E&JLWL
MZ95LV-$;7M,[TPC]=.38RBK)./D?(QQ$%F_7*=HCF%!2\S;Z:1[B?7E3RX7T
M='*2Y7>#WLLN^_)+,^S'Y58G\;AO6F\XV6GA)=&TZL1NEV7,MPX
MJHRE#X[)5/2%5$!-:L@UT6Q&EY9A0KB:*F76T7PPRE7%A0^&((L,-?%-40N]9+(8
M;T?(T'0V.'=&R3*.O//X$X;7!473LNUC;YA]-!N3B,$&B7MB:WHDLL=4]7\
MQ&T*%1C,D8P0*:.78\^V&9'K7"B(6"BFI35K7Z,05-V!/Z-K1G7-2I:H]-[+
M+3:TX$*$*J_#I9*\8@()]&J.1)G: :&@ JY%'25$$$VH@&Q:D0HKBD^=M(&D
MH0I)OXG59SQM(Y.O)6(,[A]5,?8:&G6XO:FL:7;[TG+9%6C/&#^ 04HV(/($
M&6[1; 8/W, QA6E:H[=S'[K,K("Q4CMV!FZ($)4&L6KC48% 9N%Q4,.E+#NQ
MJR=60JHX-('<2@GBX]C==@-*:CEP7R0,NL1[OA%-JWBT/SJ#/]3&V-8$#HL>
M<;EEHU9L$G<-,:79@(IL$5-LE@0"I$M>  :;? RJ(<9%V'S8N31@+E%S1N?#
M6*K-*')G(V\>[K([VK>C&%RF\Z$G'(1HVIYEQ89ZC@[XDT='9'0%80XD/MHC
M#$P&R #YBX"^H97D]3YN1JM-*+F(-5:I@) -X0> +'_I!!CL/"XZ#XTDZ%,'
M7&+;KT)C(LU"*BFVW;('%# )[=08Y]&D$/< +F F;&Q>T9BN[RT@SH$D4&'T
M8HDB=(*+G0UQ
MFF)$U2\Z:T,=W\58PL& C!LZ'O_]J,ITM;.F?,LR$MDZS8F+1_#]"PXF"$=V
MK.J'['V&#QREA U3(Y0S:)"'MY?L3HFPQ E;AD']FL5J](#CT;G3H/8A)4V[%$1CHKE.P48NT_3T B>4&=,])QHF& S7XVF 7 8Y]9E+W
M6^G0^Z!03-2&@5[R'-<[K
M_,,J.Y_%80UB^W"$=WZG#_QG\1\+_P-02P,$%     @ RJ#^7!;WPVF>$@
ME+@  !$   !A;7IN+3(P,C8P-S,P+FAT;>U=6W?B2))^[U^12V]/NTG/NK#XU>L]W^\,_Z3Y?_)0B_?^I>
MD\^N,1DS)R1-G]&0F>31"D'AEJ2
MJ%P94HVW.PIAS#!N)[@JC,+0JQ6+CX^/XJ,JNOY]4=9UO3C%/(4H4\V:AD+
MC*7,\%V\=Q^*EF-;#D/:%$.?.@$.G89 S*(BR25!J@JJ_%3/4A73@6_S%B&G
MNE#10K/I^5]J4Y$$21%D):ED&EAI@U0D22[^?G/=,T9L3 7+"4+J&"PI9;*G
M4KS99+B0@(V4DHR30+BGU)MG'M)@P!N($Y8R8TW6.A)(2(+E7F"J^:PC<>9R
M,4I,LM+Q7\Y2S71,_W(=T7#'V(6R5%&E)"\0[_L+O<#D 0V>>K&2?TE0,)5G
MK=D4=*; '.%;KU"_'#%JUB_'+*0$BPKLSXGU<%5HNDX(^B/T9QZT8$3?K@HA
MFX9%+G/%^D\__7096J'-ZC@J(>G^93'Z\;(853UPS5G]TK0>2!#.;'95,*W
ML^FLYK@.@PY8TQIF9'[TT3)-YO"/D-X!)?8M(VI_&G;9\*I@"""H#AUC3%H:"5"G4)1$B2JQ5%NRPNU;I!(PW $A/Q
MY(M-[^>5EPOU(;4#ME)O<7D@/ALR']"*!2GT1[[4 B[>T#+A?*J%0/6K0F"-
M/1OYRW\;^=BQ)5*+T\ $1O#VGAJ)VPS /*Z9? ,E\L//@,YU'(\@5004GN=I
M\VZ::[(F*$-5S64RM?DZ)>2^.
M@S?J$?(&M;/VQ79AEG/NNY"MXX8L^#QA0)KJ27)).U8N-101;+"3YT_I:/FC
MBO(B?U3I)/E3/F+^@+>RP!_E)/E3.6+^5);TIW22_*D>+7\T45K2'_TD^:,?
M,7^T1?YHIZD_LG3$#*HN,JBL'3V#BLN.>W$A-%(TK8FP1])UQ]3YO[U,6Y2DBXP
M()AT05:D7RYPX(+)#-?GD<':Q('A8B[H#CV$;I H[O+SZR0'4Z%/!S8C[I#$
MX;/@LDB!#TC2A!TK3.%-4]NZ=VH&%&$^C#SD]<09!JX/G1& "#;U E9+/EPD
M@;0HSBKP0A=CZM\#FP=N&+KC&K+X@?FA95 [;H2W%R7'W-=UT"05!2 $20O-
MI.%8-D20C>+J[WI5U*7T)$F4^>]%7I^?),8$5[VPP,O 0) R5P6U\&RL<>]E
M+R2!:ULFX;P'QL7IH>NE)'K4Q/6 FD0@;=Y^D=,E(^'7"#]4OJ'4:<^DKI(B
M=87ZMTZ[W_I,>OU&O]5;EI-%M8U8BH,&VET<0+][K>:W;KO?;O5(H_.9M'YO
M_JO1^=HBS=N;FW:OU[[MK!W,F_;^N:ZG]_XW&HQ 3D+7.2>?Q:9(%*FDZ4F/
MWZPS:)
MM"K\^CS$3W*&O0G# %:ZK4Z?=%MWM]W^02!B-DRYF_C!A#HA"5W28P8:$416
MB>L3N71F?D2;(!RQPY":-9C.C(EOA194UIH:(^K<,](P0NRYK*O:$?%BQK63/A%&$,5(RPFF'0FS!CU!>8D"*$4ZO\SL6>1!!3:(:DC8 V[S\'G/F?GQ73JO;S'3
M'\J*=DFOX/&B+/6E,)L@#1&_?/GM"4T((''# SWF,1RB!4&!.8/4$?_
M?=1Q5RKQGO"P3AV?/.-4C=Q[X* B538-'*BR6-&T%P,'V7\OJ>I&)8ZO4^4L
M(99U\90D)**(9.LV!. O@VGOE@V@\P#Z&I,=;X[3Q8T%2SFM62/HJ9[(_[Q:D*?
M3MOQNHO!M6&9V.5"79<%N:R5JV7I12$_(DRI9*+D&<<%=,9=<,)]\A]P= /3
MBKQT=W@Y\(MU:Q%'/NY?Z0^(6KBST IP-8Z@SI)(CO[>-&EW>Z0U]FQW!O*S
MK&:DXXH?5Q5H[;K#@F.EO;%C]2K0;.57-4S39T$0_[F&^N0$9"J%NB9+I,]\
M?T8:X)I/0'S ,Q\]!YSS#<*R2ZTVX>.MWW566=*&DR"MP_CZ>
MY*NJ%#F2\;#0B_1\(*_E49NP*3,FH?6 SB4H%@O.P94T[ GB!(&Q$QS\>G=R
MC\&*;#IUEIW9*-$-G]$E]LJ%NB*M1!$_;B!#URY YMW(=9X97;("59?+($'2
M<16'RY@WP!V"15X54?<07TES:L66:
M-BN\P!.0[(MM!;T!(FF3;XZ%$$!N>B#IU F$C<5]0U?L-]\*0<#1A)XXL8$8
MK-H/ ]>U!Q2D-02=F2.SBE% O:)I%S_L#?\00_:&)9RX,Q#
M5@G6_I82_$0O,HX)MBJ^LD;!]EJ0X*55]KG\:H"\/&N^+'S
M!;0X<%]KF[7JLJBI+Z_ [G]96%%$M?SRSOMW6*M&2KWLEA[1NE(9&\ZP+M#'
MJTY0 UK4&!%^4NDTETDR$\2G//K6FXT'KGT6G.BJ459R=.+M4EP\YM,&0.=O
M(PM^Z<[Q]5068+7,E#\$X>PL\,
M$Q.0 Z]]R85[&VIWW"7$B.Y%6SPW,;2FS!1"?_+$"!D=SJHB*^L=SISF&21\
M4T!1E!Q0LI%;RP0H:J'.+X_Z)4>2'9!Y&R31ALR;X,DY1Q)=B+:&R-))4>2
M;.36,R%)%9%$>XXD6FZ3;$7F;9!$SY%D)Z*]*9)H4HXD&??(2EF@1),12JK/
MH:2\^CA4+M99Z+P%EFA*CB6[$>Z-P43]03!Y;1/S"=Q.5=%%5=_-\4JY*FK2
M%L=_(X8OSRE6>'>*V
M0/<82-P];M"Y]]W'<(2;\CT\V$L!H-D0FN WRT7' *52LN7\V1G Z*92E9SA
MV>G*!3\*F&2V^)UT'MY)A_? 1#O[E8&@I-25=OWIO%+!0RV*=_)73=Y"+5CJ/]W+89,\TRW@RZ/4[ K:Z""HA]%=.YV9$YHRG@K2-
M3G >Y:2PS5L'>%!^TY,5ZT_OZ^]UY/X%-4"A5W9[DT36^6+XP@R -WJD3B?6
MRG40(Y@LF,T,?.[9"Z@2GSI!+Y#;/'#2]$C+*@5O"U[AHWS9Z)Q
MXG%@7)#BLP"_+<2'=J/K,I7M:T\GS04R=Y[Z2G
M(G0 /9F$JT4BN:SS2_C2GLK9].4C?+$O*C/RG_3GG@D#G]'O AV"_-2H_4AG
M 1(@?Q[I^)Y'VM4,E>GJZY=XT&]\NFZ1VR^D>=OIMSK]U3=\#OT6Z2/QRJN*
MJ*J;&5IKO?*2J)4/P@)[0S#95)#?"$PV[$9V,,'K#]O]UDTD[HHH*6+T,?J_
MV^I]N^[W4#-O[UK=1K]]VXF>JOK2[C0ZS7;C&E7V8
M+%*AKN'FYH;6AI'F99,J1X]#1H_R(GKHHB0OH<<31O"'^6YP8H_?N?M7^U.[
MW\L1XV00HWSBB#%_-R 7DJV%!,]/]MI?.XW^MRX^TYGK_LFP53M]W7\S9SG=
M 8WG2 )^GKS-QP,.#WBUC@8M7Y6D[7:O*^ C>
M#D,.+P?H<(BE!&,O0P"F,!HP
MOM)-+0?7VOA5\W']_-I&?I4\WO4/S5'6_IRVR_!XG*5];+?.
M:-5LZ*">7O!M:;Z.#8>+ _ ?Z/@O1T##2"JKTI1-=5T61^&87]T-QF$W-@Y-
M;M:@U[!JG)(C'F5L^Z'!N-;.Q%'W(DORB$?ZO[$1C*/A7/LR-X2[D2%\Q(-;
MMT:40_8/0?8FD:T%O8D\[5YO=JXTL:7O1
MFCT/"T^R&2[TA&!(EPQ]=QR=R&E.?!]#1%WFN7Z(MZTG[Q">QX<@PN@\49O[
MBN3W3]UKU;. ,&HR<.E.'5T4DX3?GG-577_[)7%-%U'5M%\'/5*MO-P>KW\78:=PT_KCMB,W;
MFW/2[C1%D@">J[=P3+0Y<0,  . /
M   1    86UZ;BTR,#(V,#EYU&\[LA&YV!)D
M*)!V199B?2LHZ603E4B-I&*W?_U(RJKMQ(KB#2B,^LFZ^[[C?<:=$0D]G-3?V &:2/2%V)1)
M15C^/7:A!%9?&Y#'.=KM&;=9)\9^@*/ 040I0;-6P:VN_PV4I*U4ZK3LGY94
MM*10Z,VMP&S? 6#/K8A8@GI/:I -R6%4W.("(5-Q6C=<*,2>$4LB,YMP*_&2
MD,90)P[J=NB.YT39QC-HJ>%6WU&.!Y62O04;B[N1A>.-9O!2J8^E<91BOG#/
MP\:$@U#7_#_GL&NETW+H>?\SAZ/M,[0I8TS[+5^9A@TD(7>7_-$K@+ZF(9["
MS9\C+4 8X\KRC65K:QK*2MX9M,G4;]X7\1[*_G0^._G;.1',9C//>O7!M&0B
M!GL-8(W(!0%N3\U;("5@#)US.S _3GZW AP=28]Y-D"AYU@W'H%D/HD
M6[UW.T%]"+,GJ2/U/E30E>B<]1=0GJI?4RBC/X7ZBF2GJM<4J$X4;H@/VH]H
MD3K77-_Z#C*VC_=OAP:]7:N#]K'Z:+OZ+WS["Q#>/0\PLJPK[RGV29160O$G
M6]C_3SMZ2]Y"7B#FI,K;ZG3>80L=I6V-?>FV@\4[G"S=]\'T,;-G>]?:@JC5??PC>-JG3P:F"6E__';Q_>LP+
M7A/*WFJ?";2;M,^4_1:ZB>^_7M,P_BS41&ZPGUWDCZ@9Q)^)FFBRGUTXJF8
M?R9J+@]J/1E5,X _"S6QZQ_4>C:B9A!_)FKB_>SBL;T9Q)^)FF0_NVD\JF8
M_T/5V,NH>TXO+OX%4$L#!!0    ( ,J@_ERAESR1H@@  ,Q*   5    86UZ
M;BTR,#(V,#&ULW9Q;;]LX%L??^RF\V==ES*LD!FT'F;1=!-M+
MT&8P@WT)>#ETA,I2(,E-,I]^*=EN;$MV/::*6:WQ%Y=&CEY2\/
MTVST#VBN'LLT\EM/:*8
M1LMFRV_+,TRDM3JF""A/4 Q:(TTI05%B<((3E7 =_6MR!C:A$0:&G,02<:8T
M2KB(4"24H1%10HAYIUF:?SUK7K2J8.2'EU?MQUW]_?GS[H,CLM
MRLF88LS&R]8GB^8/G?;WK&U-I)3C]MOO3:NTKZ'OEHS_^/#^B[F%J4)I7M4J
M-T\&O'E;?S]Q58T8S[_T3:OTK&K/?U\85;> ?CB$T=86S2>T;(::0XA0Q,CI
M0V5/7K\8C>:>4Z4IBPP^@QLMWO[V^;*K-,WKL4VGXT6;L@>HNI2H=T<*?K =2V':$I3#640TI=ZW=%YU+DIL*F2S55
M?Q;YJ2FFXU;<1?%M'U%J^F>.FJD4QPRWUN-,\;6:,]_[CXNS&QE^U
M#P\UY!;F\\.R]ZPP:XVR9G8JOI^9*0U9>_1F5J&)4GU9*O4Y5NB2RL>#)4C"&KJ^61QDMS
M/CN%S#UW^.B:.=[.,ECT^^MC:^5:Z0PVQ\BM1C(2%&EKJ:5:6V:2@<>X0\[Z
M2)^BY+QOP5"9/F37#,U#YY:CI:==7Y0]KQ$D0$*18)1(1Q
MF#,36V.&CIAM8@:,EQUK<3=^!J.]&46#>+TOA@+#857/FW8MV4O1S4:.\!-F
MR3D)@V%P%3_%UW]+%!":H"11"A$;<^Y3 ,68.E+Z:^GB_P_\
MG2[^&="+Z;3(6T$?VO2Q,SYFD4X,1P:$(9B32#H^-/--$4,B[\NY=^<,AY#9
M!!WDUBYG?"CG)EV_>9<5_@8^GWSV,?VQJ*%Z,P,/(>F7%C&)%"61'W+"G/.#
M58K\Z"9@#SM'"W5H'PYX&;?2SNEI@O&/13&?K*@(*"),N!A+!L[8O%V:OA:.'&>ZW+DP1!I.?XK4(D_VB!$BDM8C]W,\2+ 1U4LG]
M8&ZQ<.0PA_!;%V84"I.OBN);(DPSC231%"68FH@I'V6;U:SM,'LM'#W,<+]U
M8<:A,)-541'O%Z5PA*02&$$4Q1PBQ7B\9P*TQ<+1PPSW6Q=F.R2<4U0G"5>B9R_S )1K9I\+T\-]
M.6#EH!'T-J_3^O$S3-*J+E5>?U33CA[0'$F<<)1P\!D9=7$L=NV+_IAMG]5C
M1QOLR0'+"$]Z+G-3E'=%V?YZIZUH7Q2SO"X?+PK;#3P5(QDYC3 (3IAF4A(Z
M .B=(IX']^'\/& !XDG>NS2#C[/>7,#$2$N&$3&:*ZL2:\BN#9U]F3]9?!Z
M#_3@@!6()RW7ZN'2^E4D=>G\9WG]PF*ND1:4(@[2"K ,]&85XB"T6\P_#\Y#
M^'; 2L63L'-K2ZBJQ7_-<$EW>?$W:>"7%W^+)GB$@<9VUT;=OL![3#\/V*$^
M';"*T1%UX=]^*J^+^YX;0HJTLA;A6'/G.!A&!\3\9/A903[0GP/6-CJ2VCSA
M4WE5%M_2W'32!&L<2A0Q/OYTQ)O!PB#S=[_U9P4[Q+,#%T#6=%T55:VR_Z9W
M?6FA;FX,XE@BYI,(;F.E/+OA>*_9?E:T#_=JE[4,8=W,,>NZ5,US^U\>I[IH%Q$7&6R1L52CF,8**4LIBC1A$J0VDL9!+-?,'3O(PWW7
M0S&H1O6Q6-/R+E.3A1[BD&#-3]J%]@.*5(1G>HC5_\J=.()UAIKF+J3&"^W&/UV,D&>[(';5#A:5X.
M>SN%
MRJ\]O^T(JE+-=5WX?*Y4V:7/Y1[^ QU%B6)()E?7[]8'&Y>FK]H]/K%_P!02P,$%     @ RJ#^7'(E&/!>#@
MK8T  !4   !A;7IN+3(P,C8P-S,P7VQA8BYX;6S%76MOW+@5_9Y?H;HMT )+
M6Q1%/8)-%EDG*8)FG2#V8A==% 9%4;:P,R-#(\=.?WU)S8PMC2B*I![Y$&=L
M7]W#/'C7P#X_>,5"QU'O+JUJENF?-;4?Z9?R7.YQ6ILJ)<
M _"ZONR\N/M6YC>WE>.Y7G P._RV?.G".$V3T /,\R,0LB0!B>=!$$34C=R(
M1'X2_'#SDJ61%[@,@2QV8^ CDH#(QP$(,*%>  G&>.=TE6_^?"F^)&3+'$YO
MLZV_?75R6U5W+\_.'AX>3A^3(9@LW?X ;,Z";O'JAWFW2I9_<)
M:G33YV_Q5(]%49'5 H_%,TRCR2OQ@X_\TQY&.%(DTQIGG[H;366/%=ND;)*U\^ S@'QQ[/G
MEAD'8S4SQ=5L[ K:\KH2W7)1'I,HZ ")YX=\RUG4#+:,GMX47\_XA9R)A\4'
M(#[4SW:/N[-.Z-^4AQ:2D@[$:F]Q1@L^VKBK0"ML65FL=:A4A)8UO/3>_E7G%U79>K-?WFWPW_-FV=!2#T,,4)&D0 .I20A'S$$.^
MKHZD"#-+:8_IM$'UU22/RK"@1G,UTY0A32-9*:E8*4ON<3%Q*0DU]:4V-)>8
MJ"I6GV^+#;NX7R>L/.ZE6.2#*/!3P+BPX@2Z69 $NNHZ=CZSL&HXI\9S=H#Z
MHNK$85A/8]B92?
MLLNJH'^^+=8DWQP+AZ(,Q)[+  YH2C&)LP!K":AI2!$:MI&GHFNG)E*FVJ(;)2*25D6U2T]E?O=,76U7;PT^>A:8 6$1NPP0/
MHM.P-.^MWJQY[26F$]^OR,WQ0) B#"+$ A#Y648]'#'H:W=5+<\S"^T)RQ%@
M^GU4F_UP!V7-R4Q-FG2,>B9ITZVZI;:GQ?HD*8%FAR0W,)?$17%5$C']?OEM
MG12KCC!X5X2A!R+(,I FOI_P?UX0I+K"D/B?61X7A;.'=':8AC*11618+"-Y
MFDG&D**1=!1$K 0D\[>8C!1DFF)2F9E)BJS_M[E^XYU&KGM15&S[]I[Q:$2_
ML$YQQ'L<&!(0)S$$"B==LD9ZZU,%1
M:VPRRF9*D[)U_MC!:HYMU;33_1O.NA2?GWX+;J:;KIUOM%CMLHXP%8DE<$/D
MULE%??$B*4:K_8=$HV=LWH._VU1Y]>W=FI4W/(/]JRP>JMOS8GU'-M^.>_*$
M^2#*O #XR ]]'(8N(:%N3Z[ F3GE[)"= [2SPW;VX/H]NRI2PSW\1/S-\H\E
M=:,>7X.85<^O\KO8"$"#7',DH&-N*]'W^4HV2\H' HA_(A 1$! NS 1[$2*>
MF2Z?G2\C1H%G/$O:B8.NZNS864E-AYB%O+H,1FBJX6QA(75I=-4CL3&7S"6C
M]Z60XB.]Y7>)79 UZ\R1LA 0+^2?LH1ADGB$P4C[%;@$8.Z7X'M(YX#I"%"#
M]^"RF Q+:"Q3,QD9DC1[':Y@8O="7.9PN5?B"CJME^(J.YOZ%)TBW!B$(D]2
MGXKA8D0 830 +(J"V,,LA,C5KT][4&8668W:+E609U*H]05'ISZ=@+*9VJ1L
MK>K3/MHF]>D$].WJ4[.;;EB?#K!2UZ=]%R]8GPZTOUV?#AG;I!O_-&KZ#'SY
M=)@;92#!+@412SU,PBRE(=%/-STH,Z>;&K7]Y 6^B>[Z@J.3;B:@;)9NI&RM
MTDT?;9-T,P%]NW1C=M,-T\T *W6ZZ;MXP70ST/YVNADRMDLW?M.GC^6CFPS&
M(MWPT0V*(0MBZ))8:S),B3)[NO&/GSP?F^E.'AR]=#.:LFFZD;"U3#=RVF;I
M9C1]VW1C^P?G!J=1\@YX)O. /:$2W=S)QP'ZD8/?_?2D?,B[?2;J8=!DL8)H&X2(-Z-8H2U7X\U'<\LOO/Z
M">18C@#3EUJ+^["Z;!F9"4J3C)%\9"VW4DS+T6(BD36_J0OI[\=O$!#2^E"Q
M=6?K&K\2$!AY@(0,!2%*,N)IC2>5*'.+Y&CQ?)V@:^ 16P6>0Z26SV3$#;5D
MP7G4IH$.IQGV#3QC?+>M QV:JMT#76.+7JKXRLHWR;8J":UT4G73?L;G2\ X
M?QR )GBH>AMOEZY;GI;+US("K80M-3!_+ ZGU#P=S/"65RO'\XU>DH#(30GP
M:8(\'_LH14QW%"-%F#E3/YV]LP-U.*HC8/4'-O*X#,MF-%LS^1@3-9*1DHR5
MG.0>%Y.5DE!37FI#0C$&),:!)D
M899J5PS],#,+C@,#VD!V=M!.C:VO.D68AJ4W#7DS_=GQ-A+A,"TK)2K<+B;'
M86I-36I8VU4L]0R=<-D<<[UYS+>=?C +0>+!#% *W0@'$")7:]?+(-+"E8N
M-*Q9^H.D5[=,0GU<[:)F;5RU##*:J'+IQUFT>AFD>US!#%]@.P5^SIV69/6!
M)X#'?[/.7I%4K$E// P02E 6D<"%F=;BOUZ$9::^]Z!.C>IP6-,I[^.XZ$YW
MCV!K-=6M3]1BBKN'S(CI[6./"T]M]Q#J3FOW&=JM1'%;B^EB^<*W(/8!"4,7
M0!J&- TPBR&F;K409
M3=]V)8K)33=>B:)D-;0217[QHBM1E.T_7HFB-AY='7_8;N]9J:B18\;'X9$?
M@"QT(Q]2%T&L?:S#$-C2E?*N =,4S-W(&9?-H^(QLG@V"<68&KJ7XQ25=-?Y
M]ZJG>VDJJNK^:VP'ZU?D\4/*/>?9_M ^^492#$,0$?YMG'H1\I@'0V2XP;L'
M:9G!.P=WVNB6>TS[XJ4[F)\@"E:#>O, 6 SN!\B-&.3W>5YXL#] L#OH'[K
M;I,=;)[T@%SYX%]L>$E@A$!((@^C.(":=;8296:YUJA'XT#7;+>9/#@Z@_\)
M*)MI4\K6*SB&-B6Z]8<_4JLS0)6E1
M7,B9C*@ICAPN7$K(Z70KB!X[0F]9>K]B
M^S?@/W^KWX=?D635[7A\#"+,8D!]-XAB3*";:BVTU,":638UW@_.\9J+&MIT
MJ8DB8&I=31P&,Z791EUL:J_R
M.I7B ,0H\X$+4QS#+/$CJC63W8LPLW1W>,[^^;TCI?.5K'C5\K=3%SIWK'2V
MMZ34'$[V1TE/N:.XF^FU27NX1C7?U-+'9*H-+1W_RVYFZ:/7V3 -HX#XAK6<$F^9TJ[5
MA,8V_GU##'=MZH11M_R;+#A6U>"HN%B4B%IL1U2,:O\+%Y!:9+OUI-YE%A/%
M[U<%$7]?\0MW.?PG"EC(N^$04N!1"FF*DP#K+=;6P)I9] =P1Z#;_[V"@7AI
MS"!/%P4S=:L"8#.=/! )@TGEZ2)B-[5L]6B8S3#K453.,P^X6&ZV68]+:\Y9
M\Q+[+PQAJ+AG)DA.ZN3H(]IC#H%^LG9XB= '].0G?[F+G]Z4=28N.//VJ[_3[G'TFI]1Z )+<>*4YQE,RG\JIXZ/QA
M6$03$-$4 8Q2-\,IC>-0:T2NP%A8EO710KR^%-"6FFS$QU"0=JS'J5&+L+T4
MNY3&Z[#A\_N(L$NJ5X$24_LS/*[XI9W>T'D@"X%E?DQ'37U83K:$S#2DQ\7J)(YFPT<=P%$[6OS'WP^\5[) ]^>?/BQ:M_(?3GK^>G
ML[>YO5Y"5LV."] 5N-E-4EW.JDN8_9$77Y-O>G:6ZLKGQ1*A-\UIQ_G579$L
M+JL9Q31:-5N]6[S$1#EG8HJ  E.T@@#0UYA
MA3C3!DDN(A0);6E$M!#B_J)IDGU]6;\87<(LI)>5S9^O#RZKZNKE?'YS_=ZT3-H:ALN2^9\?3C_;2UAJ
ME&1EI3-;"Y3)R[(Y>)I;736N_S2NV0IG(.?U3]_/S]9D]1+_5>>'=I\.:_?GA_G 8<0:'-B=7<%KP_*9'F5PNK8
M90'^]8%>_I6AND=QS' M]^_[$^<_5*\** ,J39:GX<##^;7*WXT ;BO('-SG
MM+I^FMNU1FGM:/[]S%0;2)NC7QPD7YJK'IFR*K2MOFQ0APU'F@:FA%$TQI%F
M1,OUA.N RQ!QTP$EV,-%_FT>+APZ@HKZE]H-T3BQ)7?ORM^/^[I$"ZVOOM08
MN>L4/OG/56Z__GIWG.JRO- FA%V:AJ<'K?MT
M(*W*U9$?>74(9SW3QP0<%7:6%PZ*<)M9Q:,+NT7#.N /+>97N@@70O8R2=WJ
M;%_DRR'ZM\K_&;?O>S=D<# +1G@H"G"G]YV[,]\FV2K$CFZ3CT&6O+E,L^:!#[ TD"Q
MY0=SR$C+D05A">8D4IX/#! OCL(Z (L*$C[%BX*WK!,4NA4XXL"G@,(B'>P>!'9+'23#:=4-A!T*G4"()P'"$!Z.  3^. F^
M@V;##%+$4"0QM1'3@>C-TM9N$%H5.H$@)P)"?P]' ()\G$3$VY/0.$)*"XP@
MBF(.D68\[CA9W*'0"00U$1#Z>SB&ZM,C3TZ3#$XJ6&Y5Y*1T2%MBD#0FMDQ2
M;NW&'&'0/X,BR=V[S+W5U58"@@$R//9(>*^ID9)K 8-@
ML"8[GJKD<#P\W]<]@_$NJY+J[AP62;VIG%4?]7(K?C <*2PYDAS",HGZ.!9/
M#24_YZ)-=3S5R?Y8]'9U%%2<9#8OKO*BZ81F*_ XO\ZJXNXX=]N0ZSB,IMX@
M#((39IA2A X R9-!C*>0.10SPWD^"H3>)RE\O&Z=9-L8&<4P(M9P[;1TECRU
MG=Z5EQ^*XREN#@7',]T2,P-,H)2Q$$Y 8Z!V2QM
M/@N+'?+CJ7L.Q<@0/H\"F"/G0G>4#S]J>\CV$!I6PZ6T0$1^2$\GGKI
MP( \T]LQX=',HSX59T7^+FP.#C#GMZN.IIPX,2A^7
MQT3+65Y6.OU?=NX9A3^*I*H@JQ]3OLX>EEK;3MB
M,<4<&6J-C@!BP:)>/+3*=H-B(K73_L;NF8S/>9K8I'Y:^4.8$!6)3K>]H$B1
M*!@"GA%KC/*RWR1B6[,;$Q.IC?:T=,] G!50TPQA4MSL'=:?\BP^>;]]P_,L
MC'T86^28BZG@FCCC>X&Q6[L;(!.ICPYD\;A .2G+:RB>R"428:8<%MZ(Q50#
M5I+IGO>1GT70#9J)%$P'M7O?@P[8ZS!PWA%J+I)J^V$7H\G]5PX(*\$+%?,X
MZO>(QZ9B-S0F4B+M9>>>4;@H=/W5%I_OEB9OQDD?6>R0==2@F,8::47[W1**14#[OT5^4UV&2=&5SNZVGC:A+HQY6""%K; .
M-';ZJ:_/Z%KZ;A7O!LE$RIU#F3P*5HZ#?85.3\(T^?8WV$I :H8,5P)1ZQ66
M%HAU0VR0;,AVXV,B==#^QNZ9C*.P?G+U&FHU*CX.7-6?QK>"(!9F3\ MCFRL
M>A&Q)M>-A(D4/Y]OY& $O)IO&1GR^OKFQ<,;]4O]36QO7OP?4$L! A0#%
M  @ RJ#^7!3)TQY=<0  FXM,C R
M-C V,S!X97@Y.3$N:'1M4$L! A0#%     @ RJ#^7+\UVQ/W!   7Q   !<
M             ( !DG$  &%M>FXM,C R-C V,S!X97@Y.3(N:'1M4$L! A0#
M%     @ RJ#^7!;WPVF>$@  E+@  !$              ( !OG8  &%M>FXM
M,C R-C W,S N:'1M4$L! A0#%     @ RJ#^7*Y0-E=Y P  X \  !$
M         ( !BXD  &%M>FXM,C R-C W,S N>'-D4$L! A0#%     @ RJ#^
M7*&7/)&B"   S$H  !4              ( !,XT  &%M>FXM,C R-C W,S!?
M9&5F+GAM;%!+ 0(4 Q0    ( ,J@_EQR)1CP7@X  *V-   5
M  "  0B6  !A;7IN+3(P,C8P-S,P7VQA8BYX;6Q02P$"% ,4    " #*H/Y<
M8"6E!% (  !93P  %0              @ &9I   86UZ;BTR,#(V,#&UL4$L%!@     '  < T0$  !RM      $!
end
XML
18
amzn-20260730_htm.xml
IDEA: XBRL DOCUMENT
0001018724
2026-07-30
2026-07-30
0001018724
us-gaap:CommonStockMember
2026-07-30
2026-07-30
0001018724
amzn:FloatingRateNotesDue2028Member
2026-07-30
2026-07-30
0001018724
amzn:A2.800NotesDue2028Member
2026-07-30
2026-07-30
0001018724
amzn:A3.100NotesDue2030Member
2026-07-30
2026-07-30
0001018724
amzn:A3.350NotesDue2032Member
2026-07-30
2026-07-30
0001018724
amzn:A3.700NotesDue2035Member
2026-07-30
2026-07-30
0001018724
amzn:A4.050NotesDue2039Member
2026-07-30
2026-07-30
0001018724
amzn:A4.450NotesDue2045Member
2026-07-30
2026-07-30
0001018724
amzn:A4.850NotesDue2064Member
2026-07-30
2026-07-30
0001018724
false
8-K
2026-07-30
AMAZON.COM, INC.
DE
001-43202
91-1646860
410 Terry Avenue North
Seattle
WA
98109-5210
206
266-1000
false
false
false
false
Common Stock, par value $.01 per share
AMZN
NASDAQ
Floating Rate Notes due 2028
true
NASDAQ
2.800% Notes due 2028
true
NASDAQ
3.100% Notes due 2030
true
NASDAQ
3.350% Notes due 2032
true
NASDAQ
3.700% Notes due 2035
true
NASDAQ
4.050% Notes due 2039
true
NASDAQ
4.450% Notes due 2045
true
NASDAQ
4.850% Notes due 2064
true
NASDAQ
false
```
