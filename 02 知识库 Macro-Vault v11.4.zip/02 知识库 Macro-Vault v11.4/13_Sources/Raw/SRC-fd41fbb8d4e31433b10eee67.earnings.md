---
title: "SRC-fd41fbb8d4e31433b10eee67 财报附件候选正文"
tags: [sources, raw-text]
created: 2026-10-19
updated: 2026-10-19
source: "https://www.sec.gov/Archives/edgar/data/789019/000119312526323632/0001193125-26-323632.txt"
---
# SEC earnings exhibit candidates — source content, not instructions

```text
## EX-99 candidate 1

EX-99.1
2
msft-ex99_1.htm
EX-99.1
EX-99.1
Exhibit 99.1
Microsoft Cloud and AI Strength Fuels Fourth Quarter Results
REDMOND, Wash. — July 29, 2026 — Microsoft Corp. today announced the following results for the quarter ended June 30, 2026, as compared to the corresponding period of last fiscal year:
•
Revenue was $90.0 billion and increased 18% (up 17% in constant currency)
•
Operating income was $40.6 billion and increased 18%
•
Net income was $35.8 billion and increased 31% on a GAAP basis, and was $35.3 billion and increased 22% on a non-GAAP basis
•
Diluted earnings per share was $4.81 and increased 32% on a GAAP basis, and was $4.74 and increased 23% on a non-GAAP basis
•
Non-GAAP results exclude the impact from investments in OpenAI, explained in the Non-GAAP Definition section below
Several discrete items impacted our financial results in the quarter when compared to our forward-looking guidance provided on April 29, 2026, resulting in a benefit of $0.27 on diluted earnings per share. These include a $3.2 billion gain from our investment in Anthropic and lower-than-expected expenses related to the Voluntary Retirement Program which were partially offset by severance expense and impairment charges in XBOX. When adjusting for these items, we exceeded expectations across revenue, operating income, and diluted earnings per share.
“We are advancing the frontier on the cost-to-outcome curve, ensuring every customer can turn tokens into business results,” said Satya Nadella, chairman and chief executive officer of Microsoft. “This year, Azure revenue surpassed $100 billion for the first time, and Microsoft 365 Copilot reached over 30 million paid seats, reflecting the confidence customers are placing in us to power their AI transformation.”
“We delivered a strong quarter to close out the fiscal year, highlighted by Microsoft Cloud revenue of $59.3 billion, up 27% year-over-year,” said Amy Hood, executive vice president and chief financial officer of Microsoft.
The following table adjusts for the impact from investments in OpenAI and reconciles our financial results reported in accordance with generally accepted accounting principles (GAAP) to non-GAAP financial results. Additional information regarding our non-GAAP definition is provided below. All growth comparisons relate to the corresponding period in the last fiscal year.
Three Months Ended June 30,
2026
2025
Percentage Change Y/Y
Percentage Change Y/Y
($ in millions, except per share amounts)
As Reported (GAAP)
Impact from OpenAI*
As Adjusted (non-GAAP)
As Reported (GAAP)
Impact from OpenAI*
As Adjusted (non-GAAP)
GAAP
Constant Currency
Net Impact from OpenAI*
Non-GAAP
Non-GAAP Constant Currency
Net Income
$35,766
$(480)
$35,286
$27,233
$1,575
$28,808
31%
31%
$(2,055)
22%
22%
Diluted Earnings per Share
$4.81
$(0.07)
$4.74
$3.65
$0.21
$3.86
32%
32%
$(0.28)
23%
23%
*Impact from OpenAI adjusts for the impact from investments in OpenAI
Business Highlights
Microsoft Cloud revenue was $59.3 billion and increased 27%, and commercial remaining performance obligation increased 84% to $678 billion.
Revenue in Productivity and Business Processes was $37.8 billion and increased 14%, with the following business highlights:
•
Microsoft 365 Commercial cloud revenue increased 16% when adjusted for the prior year comparable that benefited from 2 points of in-period revenue recognition. On a reported basis, Microsoft 365 Commercial cloud revenue increased 14%.
•
Microsoft 365 Consumer cloud revenue increased 24% (up 22% in constant currency)
•
LinkedIn revenue increased 12% (up 10% in constant currency)
•
Dynamics 365 revenue increased 13% (up 12% in constant currency)
Revenue in Intelligent Cloud was $39.3 billion and increased 32% (up 31% in constant currency), with the following business highlights:
•
Azure and other cloud services revenue increased 43%
Revenue in More Personal Computing was $12.9 billion and decreased 4% (down 5% in constant currency), with the following business highlights:
•
Windows OEM and Devices revenue decreased 7%
•
XBOX content and services revenue decreased 10%
•
Search advertising revenue excluding traffic acquisition costs increased 10% (up 9% in constant currency)
Microsoft returned $10.2 billion to shareholders in the form of dividends and share repurchases in the fourth quarter of fiscal year 2026.
Fiscal Year 2026 Results
Microsoft Corp. today announced the following results for the fiscal year ended June 30, 2026, as compared to the corresponding period of last fiscal year:
•
Revenue was $331.8 billion and increased 18% (up 16% in constant currency)
•
Operating income was $155.2 billion and increased 21% (up 19% in constant currency)
•
Net income was $133.7 billion and increased 31% on a GAAP basis, and increased 22% (up 20% in constant currency) on a non-GAAP basis
•
Diluted earnings per share was $17.95 and increased 32% on a GAAP basis, and increased 22% (up 21% in constant currency) on a non-GAAP basis
•
Non-GAAP results exclude the impact from investments in OpenAI, explained in the Non-GAAP Definition section below
The following table adjusts for the impact from investments in OpenAI and reconciles our financial results reported in accordance with GAAP to non-GAAP financial results. Additional information regarding our non-GAAP definition is provided below. All growth comparisons relate to the corresponding period in the last fiscal year.
Twelve Months Ended June 30,
2026
2025
Percentage Change Y/Y
Percentage Change Y/Y
($ in millions, except per share amounts)
As Reported (GAAP)
Impact from OpenAI*
As Adjusted (non-GAAP)
As Reported (GAAP)
Impact from OpenAI*
As Adjusted (non-GAAP)
GAAP
Constant Currency
Net Impact from OpenAI*
Non-GAAP
Non-GAAP Constant Currency
Net Income
$133,749
$(4,963)
$128,786
$101,832
$3,620
$105,452
31%
30%
$(8,583)
22%
20%
Diluted Earnings per Share
$17.95
$(0.67)
$17.28
$13.64
$0.49
$14.13
32%
30%
$(1.16)
22%
21%
*Impact from OpenAI adjusts for the impact from investments in OpenAI
Business Outlook
Microsoft will provide forward-looking guidance in connection with this quarterly earnings announcement on its earnings conference call and webcast.
Quarterly Highlights, Product Releases, and Customer Stories
Every quarter Microsoft delivers hundreds of products, services, and enhancements. These releases are driven by years of significant research and development investments, to empower customers with greater productivity, security, and differentiated value.
This momentum is reflected in stories that showcase how our technology is shaping industries and driving customer success. We share innovation updates on our product blogs across Azure, Microsoft 365, and more on our Official Microsoft blog.
Webcast Details
Satya Nadella, chairman and chief executive officer, Amy Hood, executive vice president and chief financial officer, Alice Jolla, chief accounting officer, Brian DeFoe, deputy general counsel and corporate secretary, and Jonathan Neilson, vice president of investor relations, will host a conference call and webcast at 2:30 p.m. Pacific time (5:30 p.m. Eastern time) today to discuss details of the company’s performance for the quarter and certain forward-looking information. The session may be accessed at http://www.microsoft.com/en-us/investor. Participants can also dial into the conference call at (877) 407-0666 or +1 (201) 689-8023 for international, no password required. The webcast will be available for replay through the close of business on July 29, 2027.
Non-GAAP Definition
Impact from investments in OpenAI. In fiscal year 2026, net income and diluted earnings per share were impacted by net gains from investments in OpenAI, which resulted in an increase in net income and diluted earnings per share of $480 million and $0.07, respectively, in the fourth quarter, and $4,963 million and $0.67, respectively, for the full fiscal year. In fiscal year 2025, net income and diluted earnings per share were impacted by net losses from investments in OpenAI, which resulted in a decrease in net income and diluted earnings per share of $1,575 million and $0.21, respectively, in the fourth quarter, and $3,620 million and $0.49, respectively, for the full fiscal year.
Microsoft has provided non-GAAP financial measures related to the impact from investments in OpenAI to aid investors in better understanding our performance. Microsoft believes these non-GAAP measures assist investors by providing additional insight into its operational performance and help clarify trends affecting its business. For comparability of reporting, management considers non-GAAP measures in conjunction with GAAP financial results in evaluating business performance. The non-GAAP financial measures presented in this release should not be considered as a substitute for, or superior to, the measures of financial performance prepared in accordance with GAAP.
Constant Currency
Microsoft presents constant currency information to provide a framework for assessing how our underlying businesses performed excluding the effect of foreign currency rate fluctuations. To present this information, current and comparative prior period results for entities reporting in currencies other than United States dollars are converted into United States dollars using the average exchange rates from the comparative period rather than the actual exchange rates in effect during the respective periods. All growth comparisons relate to the corresponding period in the last fiscal year. Microsoft has provided this non-GAAP financial information to aid investors in better understanding our performance. The non-GAAP financial measures presented in this release should not be considered as a substitute for, or superior to, the measures of financial performance prepared in accordance with GAAP.
Financial Performance Constant Currency Reconciliation
Three Months Ended June 30,
2026
2025
Percentage Change Y/Y
Percentage Change Y/Y
($ in millions, except per share amounts)
As Reported (GAAP)
As Adjusted (non-GAAP)
As Reported (GAAP)
As Adjusted (non-GAAP)
GAAP
Non-GAAP
Constant Currency Impact
Constant Currency
Non-GAAP Constant Currency
Revenue
$90,007
-
$76,441
-
18%
-
$391
17%
-
Operating Income
$40,603
-
$34,323
-
18%
-
$269
18%
-
Net Income
$35,766
$35,286
$27,233
$28,808
31%
22%
$40
31%
22%
Diluted Earnings per Share
$4.81
$4.74
$3.65
$3.86
32%
23%
$0.01
32%
23%
Twelve Months Ended June 30,
2026
2025
Percentage Change Y/Y
Percentage Change Y/Y
($ in millions, except per share amounts)
As Reported (GAAP)
As Adjusted (non-GAAP)
As Reported (GAAP)
As Adjusted (non-GAAP)
GAAP
Non-GAAP
Constant Currency Impact
Constant Currency
Non-GAAP Constant Currency
Revenue
$331,839
-
$281,724
-
18%
-
$4,445
16%
-
Operating Income
$155,237
-
$128,528
-
21%
-
$2,896
19%
-
Net Income
$133,749
$128,786
$101,832
$105,452
31%
22%
$1,772
30%
20%
Diluted Earnings per Share
$17.95
$17.28
$13.64
$14.13
32%
22%
$0.24
30%
21%
Segment Revenue Constant Currency Reconciliation
Three Months Ended June 30,
2026
2025
Percentage Change Y/Y
Percentage Change Y/Y
($ in millions)
As Reported (GAAP)
As Reported (GAAP)
GAAP
Constant Currency Impact
Constant Currency
Productivity and Business Processes
$37,847
$33,112
14%
$244
14%
Intelligent Cloud
$39,306
$29,878
32%
$80
31%
More Personal Computing
$12,854
$13,451
(4)%
$67
(5)%
Selected Product and Service Information Constant Currency Reconciliation
Three Months Ended June 30, 2026
Percentage Change Y/Y (GAAP)
Constant Currency Impact
Percentage Change Y/Y Constant Currency
Microsoft Cloud revenue
27%
0%
27%
Commercial remaining performance obligation
84%
0%
84%
Microsoft 365 Commercial cloud revenue
14%
0%
14%
Microsoft 365 Consumer cloud revenue
24%
(2)%
22%
LinkedIn revenue
12%
(2)%
10%
Dynamics 365 revenue
13%
(1)%
12%
Azure and other cloud services revenue
43%
0%
43%
Windows OEM and Devices revenue
(7)%
0%
(7)%
XBOX content and services revenue
(10)%
0%
(10)%
Search advertising revenue excluding traffic acquisition costs
10%
(1)%
9%
About Microsoft
Microsoft (Nasdaq “MSFT” @microsoft) creates platforms and tools powered by AI to deliver innovative solutions that meet the evolving needs of our customers. The technology company is committed to making AI available broadly and doing so responsibly, with a mission to empower every person and every organization on the planet to achieve more.
Forward-Looking Statements
Statements in this release that are “forward-looking statements” are based on current expectations and assumptions that are subject to risks and uncertainties. Actual results could differ materially because of factors such as:
•
intense competition in all of our markets that could adversely affect our results of operations;
•
substantial investments in cloud and AI strategy that depend on customer demand, technological developments, competitive dynamics, and regulatory condition;
•
development, delivery, and maintenance of competitive cloud-based and AI products and services that achieve broad customer adoption and sustainable revenue growth;
•
significant investments in products and services that may not achieve expected returns;
•
acquisitions, joint ventures, and strategic alliances that could have an adverse effect on our business;
•
cyberattacks and security vulnerabilities that could lead to reduced revenue, increased costs, liability claims, or harm to our reputation or competitive position;
•
disclosure and misuse of personal data that could cause liability and harm to our reputation;
•
the possibility that we may not be able to protect information in our products and services from use by others;
•
abuse of our platforms that may harm our reputation or user engagement;
•
products and services, how they are used by customers, and how third-party products and services interact with them, presenting security, privacy, and execution risks;
•
issues about the development, deployment, and use of AI that may result in reputational or competitive harm, or liability;
•
inability to develop and expand adequate infrastructure;
•
supply or other quality problems;
•
excessive outages, disruptions, or capacity constraints of our services if we fail to maintain an adequate operations infrastructure or secure resources necessary to support it;
•
potential consequences of new, existing, and evolving legal and regulatory requirements;
•
claims against us that could result in adverse outcomes in legal disputes;
•
uncertainties relating to our business with government customers;
•
additional tax liabilities;
•
an inability to protect and utilize our intellectual property may harm our business and operating results;
•
claims that Microsoft has infringed the intellectual property rights of others;
•
damage to our reputation or our brands that may harm our business and results of operations;
•
adverse economic or market conditions that could harm our business;
•
catastrophic events or geopolitical conditions that could disrupt our business;
•
exposure to increased economic and operational uncertainties from operating a global business, including the effects of foreign currency exchange; and
•
the dependence of our business on our ability to attract and retain talented employees.
For more information about risks and uncertainties associated with Microsoft’s business, please refer to the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” sections of Microsoft’s SEC filings, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q, copies of which may be obtained by contacting Microsoft’s Investor Relations department at (800) 285-7772 or at Microsoft’s Investor Relations website at http://www.microsoft.com/en-us/investor.
All information in this release is as of June 30, 2026. The company undertakes no duty to update any forward-looking statement to conform the statement to actual results or changes in the company’s expectations.
For more information, press only:
Microsoft Media Relations, WE Communications for Microsoft, (425) 638-7777, rrt@we-worldwide.com
For more information, financial analysts and investors only:
Jonathan Neilson, Vice President, Investor Relations, (425) 706-4400
Note to editors: For more information, news and perspectives from Microsoft, please visit the Microsoft News Center at http://www.microsoft.com/news. Web links, telephone numbers, and titles were correct at time of publication, but may since have changed. Shareholder and financial information, as well as today’s 2:30 p.m. Pacific time conference call with investors and analysts, is available at http://www.microsoft.com/en-us/investor.
MICROSOFT CORPORATION
INCOME STATEMENTS
(In millions, except per share amounts) (Unaudited)
Three Months Ended
June 30,
Twelve Months Ended
June 30,
2026
2025
2026
2025
Revenue:
Product
$17,234
$17,136
$64,696
$63,946
Service and other
72,773
59,305
267,143
217,778
Total revenue
90,007
76,441
331,839
281,724
Cost of revenue:
Product
2,938
3,314
12,098
13,501
Service and other
26,587
20,700
94,276
74,330
Total cost of revenue
29,525
24,014
106,374
87,831
Gross margin
60,482
52,427
225,465
193,893
Research and development
9,997
8,829
35,562
32,488
Sales and marketing
7,595
7,285
26,710
25,654
General and administrative
2,287
1,990
7,956
7,223
Operating income
40,603
34,323
155,237
128,528
Other income (expense), net
3,444
(1,707)
10,697
(4,901)
Income before income taxes
44,047
32,616
165,934
123,627
Provision for income taxes
8,281
5,383
32,185
21,795
Net income
$35,766
$27,233
$133,749
$101,832
Earnings per share:
Basic
$4.82
$3.66
$18.00
$13.70
Diluted
$4.81
$3.65
$17.95
$13.64
Weighted average shares outstanding:
Basic
7,427
7,432
7,429
7,433
Diluted
7,443
7,461
7,453
7,465
COMPREHENSIVE INCOME STATEMENTS
(In millions) (Unaudited)
Three Months Ended
Twelve Months Ended
June 30,
June 30,
2026
2025
2026
2025
Net income
$35,766
$27,233
$133,749
$101,832
Other comprehensive income (loss), net of tax:
Net change related to derivatives
14
(9)
8
(5)
Net change related to investments
(72)
444
215
1,574
Translation adjustments and other
2
1,051
(160)
674
Other comprehensive income (loss)
(56)
1,486
63
2,243
Comprehensive income
$35,710
$28,719
$133,812
$104,075
BALANCE SHEETS
(In millions) (Unaudited)
June 30,
2026
June 30,
2025
Assets
Current assets:
Cash and cash equivalents
$20,935
$30,242
Short-term investments
55,908
64,323
Total cash, cash equivalents, and short-term investments
76,843
94,565
Accounts receivable, net of allowance for doubtful accounts of $1,040 and $944
80,876
69,905
Inventories
1,397
938
Other current assets
48,594
25,723
Total current assets
207,710
191,131
Property and equipment, net of accumulated depreciation of $118,691 and $93,653
313,076
204,966
Operating lease right-of-use assets
24,177
24,823
Equity and other investments
36,348
15,405
Goodwill
119,651
119,509
Intangible assets, net
18,609
22,604
Other long-term assets
38,805
40,565
Total assets
$758,376
$619,003
Liabilities and stockholders' equity
Current liabilities:
Accounts payable
$42,416
$27,724
Current portion of long-term debt
9,227
2,999
Accrued compensation
14,945
13,709
Short-term income taxes
2,534
7,211
Short-term unearned revenue
72,965
64,555
Other current liabilities
26,738
25,020
Total current liabilities
168,825
141,218
Long-term debt
31,067
40,152
Long-term income taxes
28,647
25,986
Long-term unearned revenue
2,747
2,710
Deferred income taxes
3,054
2,835
Operating lease liabilities
16,532
17,437
Other long-term liabilities
65,117
45,186
Total liabilities
315,989
275,524
Commitments and contingencies
Stockholders' equity:
Common stock and paid-in capital - shares authorized 24,000; outstanding 7,427 and 7,434
117,406
109,095
Retained earnings
328,265
237,731
Accumulated other comprehensive loss
(3,284)
(3,347)
Total stockholders' equity
442,387
343,479
Total liabilities and stockholders' equity
$758,376
$619,003
CASH FLOWS STATEMENTS
(In millions) (Unaudited)
Three Months Ended
Twelve Months Ended
June 30,
June 30,
2026
2025
2026
2025
Operations
Net income
$35,766
$27,233
$133,749
$101,832
Adjustments to reconcile net income to net cash from operations:
Depreciation, amortization, and other
11,022
9,317
38,534
29,433
Stock-based compensation expense
3,122
3,073
12,405
11,974
Net recognized losses (gains) on investments and derivatives
(3,743)
1,942
(11,047)
5,329
Deferred income taxes
4,650
(2,221)
14,189
(7,056)
Changes in operating assets and liabilities:
Accounts receivable
(21,084)
(16,179)
(12,737)
(10,581)
Inventories
(178)
(81)
(461)
309
Other current assets
(2,842)
(3,686)
(2,627)
(3,044)
Other long-term assets
(1,350)
418
(3,964)
(2,950)
Accounts payable
2,365
(652)
5,268
569
Unearned revenue
22,428
18,361
9,361
5,438
Income taxes
(307)
1,043
(1,875)
(38)
Other current liabilities
7,013
5,346
6,847
5,922
Other long-term liabilities
(1,421)
(1,267)
(4,707)
(975)
Net cash from operations
55,441
42,647
182,935
136,162
Financing
Repayments of debt, maturities of 90 days or less
0
0
0
(5,746)
Repayments of debt
0
0
(3,000)
(3,216)
Common stock issued
520
548
2,009
2,056
Common stock repurchased
(4,579)
(4,546)
(22,271)
(18,420)
Common stock cash dividends paid
(6,758)
(6,169)
(26,445)
(24,082)
Other, net
(962)
(677)
(2,839)
(2,291)
Net cash used in financing
(11,779)
(10,844)
(52,546)
(51,699)
Investing
Additions to property and equipment
(35,802)
(17,079)
(115,948)
(64,551)
Acquisition of companies, net of cash acquired and divestitures, and purchases of intangible and other assets
(452)
(1,743)
(1,743)
(5,978)
Purchases of investments
(18,829)
(21,631)
(58,351)
(29,775)
Maturities of investments
4,181
4,618
34,605
16,079
Sales of investments
6,487
2,621
21,798
9,309
Other, net
(10,416)
2,642
(19,861)
2,317
Net cash used in investing
(54,831)
(30,572)
(139,500)
(72,599)
Effect of foreign exchange rates on cash and cash equivalents
(1)
183
(196)
63
Net change in cash and cash equivalents
(11,170)
1,414
(9,307)
11,927
Cash and cash equivalents, beginning of period
32,105
28,828
30,242
18,315
Cash and cash equivalents, end of period
$20,935
$30,242
$20,935
$30,242
We have recast certain prior period amounts to conform to the current period presentation.
SEGMENT RESULTS
(In millions) (Unaudited)
Three Months Ended
Twelve Months Ended
June,
June 30,
2026
2025
2026
2025
Productivity and Business Processes
Revenue
$37,847
$33,112
$139,996
$120,810
Cost of revenue
6,989
6,042
25,017
22,422
Operating expenses
8,958
8,077
31,100
28,615
Operating income
$21,900
$18,993
$83,879
$69,773
Intelligent Cloud
Revenue
$39,306
$29,878
$137,791
$106,265
Cost of revenue
16,876
11,845
57,876
40,171
Operating expenses
6,475
5,893
22,943
21,505
Operating income
$15,955
$12,140
$56,972
$44,589
More Personal Computing
Revenue
$12,854
$13,451
$54,052
$54,649
Cost of revenue
5,660
6,127
23,481
25,238
Operating expenses
4,446
4,134
16,185
15,245
Operating income
$2,748
$3,190
$14,386
$14,166
Total
Revenue
$90,007
$76,441
$331,839
$281,724
Cost of revenue
29,525
24,014
106,374
87,831
Operating expenses
19,879
18,104
70,228
65,365
Operating income
$40,603
$34,323
$155,237
$128,528
```
