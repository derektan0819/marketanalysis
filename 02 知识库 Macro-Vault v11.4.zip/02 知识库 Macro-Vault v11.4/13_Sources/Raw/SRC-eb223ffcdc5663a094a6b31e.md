---
title: "SRC-eb223ffcdc5663a094a6b31e 提取正文"
tags: [sources, raw-text]
created: 2026-10-19
updated: 2026-10-19
source: "https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/amzn-20251231.htm"
---
# Source text — untrusted evidence

```text
amzn-20251231
iso4217:USDxbrli:sharesiso4217:USDxbrli:sharesamzn:segmentxbrli:pureutr:MWhiso4217:EURamzn:extensionamzn:lawsuitamzn:complaint00010187242025-01-012025-12-3100010187242025-06-3000010187242026-01-2800010187242024-01-012024-12-3100010187242022-12-3100010187242023-12-3100010187242024-12-3100010187242023-01-012023-12-3100010187242025-12-310001018724us-gaap:ProductMember2023-01-012023-12-310001018724us-gaap:ProductMember2024-01-012024-12-310001018724us-gaap:ProductMember2025-01-012025-12-310001018724us-gaap:ServiceMember2023-01-012023-12-310001018724us-gaap:ServiceMember2024-01-012024-12-310001018724us-gaap:ServiceMember2025-01-012025-12-310001018724us-gaap:CommonStockMember2022-12-310001018724us-gaap:TreasuryStockCommonMember2022-12-310001018724us-gaap:AdditionalPaidInCapitalMember2022-12-310001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2022-12-310001018724us-gaap:RetainedEarningsMember2022-12-310001018724us-gaap:RetainedEarningsMember2023-01-012023-12-310001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2023-01-012023-12-310001018724us-gaap:CommonStockMember2023-01-012023-12-310001018724us-gaap:AdditionalPaidInCapitalMember2023-01-012023-12-310001018724us-gaap:CommonStockMember2023-12-310001018724us-gaap:TreasuryStockCommonMember2023-12-310001018724us-gaap:AdditionalPaidInCapitalMember2023-12-310001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2023-12-310001018724us-gaap:RetainedEarningsMember2023-12-310001018724us-gaap:RetainedEarningsMember2024-01-012024-12-310001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2024-01-012024-12-310001018724us-gaap:CommonStockMember2024-01-012024-12-310001018724us-gaap:AdditionalPaidInCapitalMember2024-01-012024-12-310001018724us-gaap:CommonStockMember2024-12-310001018724us-gaap:TreasuryStockCommonMember2024-12-310001018724us-gaap:AdditionalPaidInCapitalMember2024-12-310001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2024-12-310001018724us-gaap:RetainedEarningsMember2024-12-310001018724us-gaap:RetainedEarningsMember2025-01-012025-12-310001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2025-01-012025-12-310001018724us-gaap:CommonStockMember2025-01-012025-12-310001018724us-gaap:AdditionalPaidInCapitalMember2025-01-012025-12-310001018724us-gaap:CommonStockMember2025-12-310001018724us-gaap:TreasuryStockCommonMember2025-12-310001018724us-gaap:AdditionalPaidInCapitalMember2025-12-310001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2025-12-310001018724us-gaap:RetainedEarningsMember2025-12-310001018724us-gaap:ServiceLifeMemberus-gaap:TechnologyEquipmentMember2024-12-310001018724us-gaap:ServiceLifeMemberus-gaap:ComputerEquipmentMember2024-12-310001018724us-gaap:ServiceLifeMemberus-gaap:TechnologyEquipmentMember2025-01-010001018724us-gaap:ServiceLifeMemberus-gaap:ComputerEquipmentMember2025-01-010001018724us-gaap:ServiceLifeMember2025-01-012025-12-310001018724us-gaap:SettledLitigationMemberamzn:FederalTradeCommissionMember2025-07-012025-09-300001018724us-gaap:SettledLitigationMemberamzn:LitigationCasesMember2025-10-012025-12-310001018724us-gaap:SettledLitigationMemberamzn:TaxDisputesAndLawsuitMember2025-10-012025-12-3100010187242025-07-012025-09-3000010187242025-10-012025-12-310001018724us-gaap:SalesReturnsAndAllowancesMember2023-01-012023-12-310001018724us-gaap:SalesReturnsAndAllowancesMember2024-01-012024-12-310001018724us-gaap:SalesReturnsAndAllowancesMember2025-01-012025-12-310001018724us-gaap:ShareBasedCompensationAwardTrancheOneMember2025-01-012025-12-310001018724srt:MaximumMember2025-01-012025-12-310001018724amzn:FairValueInputsLevel1AndLevel2Membersrt:MinimumMemberamzn:ElectricFuturePricesMember2025-12-310001018724amzn:FairValueInputsLevel1AndLevel2Membersrt:MaximumMemberamzn:ElectricFuturePricesMember2025-12-310001018724us-gaap:FairValueInputsLevel3Membersrt:MinimumMemberamzn:VariousManagementAssumptionsMember2025-12-310001018724us-gaap:FairValueInputsLevel3Membersrt:MaximumMemberamzn:VariousManagementAssumptionsMember2025-12-310001018724srt:WeightedAverageMember2025-01-012025-12-310001018724us-gaap:TradeAccountsReceivableMember2024-12-310001018724us-gaap:TradeAccountsReceivableMember2025-12-310001018724amzn:VendorAccountsReceivableMember2024-12-310001018724amzn:VendorAccountsReceivableMember2025-12-310001018724amzn:OtherReceivablesMember2024-12-310001018724amzn:OtherReceivablesMember2025-12-310001018724us-gaap:BuildingMember2025-12-310001018724srt:MinimumMemberus-gaap:ComputerEquipmentMember2025-12-310001018724srt:MinimumMemberus-gaap:TechnologyEquipmentMember2025-12-310001018724srt:MaximumMemberus-gaap:TechnologyEquipmentMember2025-12-310001018724srt:MaximumMemberus-gaap:ComputerEquipmentMember2025-12-310001018724srt:MinimumMemberus-gaap:MachineryAndEquipmentMember2025-12-310001018724srt:MaximumMemberus-gaap:MachineryAndEquipmentMember2025-12-310001018724srt:MinimumMemberus-gaap:OtherMachineryAndEquipmentMember2025-12-310001018724srt:MaximumMemberus-gaap:OtherMachineryAndEquipmentMember2025-12-310001018724us-gaap:ServiceLifeMemberus-gaap:TechnologyEquipmentMember2023-12-310001018724us-gaap:ServiceLifeMemberus-gaap:TechnologyEquipmentMember2024-01-010001018724us-gaap:MachineryAndEquipmentMember2024-12-310001018724srt:MinimumMemberus-gaap:EquipmentMember2025-01-012025-12-310001018724srt:MaximumMemberus-gaap:EquipmentMember2025-01-012025-12-310001018724srt:MinimumMemberamzn:PropertyMember2025-01-012025-12-310001018724srt:MaximumMemberamzn:PropertyMember2025-01-012025-12-3100010187242025-04-012025-04-0100010187242023-07-012024-12-310001018724us-gaap:FairValueInputsLevel3Member2024-12-3100010187242025-01-012025-03-3100010187242025-04-012025-06-300001018724us-gaap:PreferredStockMember2025-12-310001018724srt:ScenarioForecastMemberus-gaap:SubsequentEventMember2026-01-012026-03-310001018724us-gaap:WarrantMemberus-gaap:FairValueInputsLevel2Member2024-12-310001018724us-gaap:WarrantMemberus-gaap:FairValueInputsLevel2Member2025-12-310001018724amzn:GiftCardMember2024-12-310001018724amzn:GiftCardMember2025-12-3100010187242026-01-012025-12-310001018724us-gaap:FairValueMeasurementsRecurringMember2024-12-310001018724us-gaap:MoneyMarketFundsMemberus-gaap:FairValueMeasurementsRecurringMemberus-gaap:FairValueInputsLevel1Member2024-12-310001018724us-gaap:FairValueMeasurementsRecurringMemberus-gaap:FairValueInputsLevel1Member2024-12-310001018724us-gaap:USTreasuryAndGovernmentMemberus-gaap:FairValueMeasurementsRecurringMemberus-gaap:FairValueInputsLevel2Member2024-12-310001018724us-gaap:CorporateDebtSecuritiesMemberus-gaap:FairValueMeasurementsRecurringMemberus-gaap:FairValueInputsLevel2Member2024-12-310001018724us-gaap:AssetBackedSecuritiesMemberus-gaap:FairValueMeasurementsRecurringMemberus-gaap:FairValueInputsLevel2Member2024-12-310001018724us-gaap:FixedIncomeSecuritiesMemberus-gaap:FairValueMeasurementsRecurringMemberus-gaap:FairValueInputsLevel2Member2024-12-310001018724us-gaap:FairValueMeasurementsRecurringMember2025-12-310001018724us-gaap:MoneyMarketFundsMemberus-gaap:FairValueMeasurementsRecurringMemberus-gaap:FairValueInputsLevel1Member2025-12-310001018724us-gaap:FairValueMeasurementsRecurringMemberus-gaap:FairValueInputsLevel1Member2025-12-310001018724us-gaap:USTreasuryAndGovernmentMemberus-gaap:FairValueMeasurementsRecurringMemberus-gaap:FairValueInputsLevel2Member2025-12-310001018724us-gaap:CorporateDebtSecuritiesMemberus-gaap:FairValueMeasurementsRecurringMemberus-gaap:FairValueInputsLevel2Member2025-12-310001018724us-gaap:AssetBackedSecuritiesMemberus-gaap:FairValueMeasurementsRecurringMemberus-gaap:FairValueInputsLevel2Member2025-12-310001018724us-gaap:FixedIncomeSecuritiesMemberus-gaap:FairValueMeasurementsRecurringMemberus-gaap:FairValueInputsLevel2Member2025-12-310001018724us-gaap:LandAndBuildingMember2024-12-310001018724us-gaap:LandAndBuildingMember2025-12-310001018724amzn:ServersAndNetworkingEquipmentMember2024-12-310001018724amzn:ServersAndNetworkingEquipmentMember2025-12-310001018724us-gaap:MachineryAndEquipmentMember2025-12-310001018724us-gaap:EquipmentMember2024-12-310001018724us-gaap:EquipmentMember2025-12-310001018724us-gaap:OtherCapitalizedPropertyPlantAndEquipmentMember2024-12-310001018724us-gaap:OtherCapitalizedPropertyPlantAndEquipmentMember2025-12-310001018724us-gaap:ConstructionInProgressMember2024-12-310001018724us-gaap:ConstructionInProgressMember2025-12-310001018724amzn:A1LifeHealthcareMember2023-02-222023-02-220001018724amzn:A1LifeHealthcareMember2023-02-220001018724us-gaap:SeriesOfIndividuallyImmaterialBusinessAcquisitionsMember2024-01-012024-12-310001018724amzn:NorthAmericaSegmentMember2023-12-310001018724amzn:InternationalSegmentMember2023-12-310001018724amzn:AmazonWebServicesSegmentMember2023-12-310001018724amzn:NorthAmericaSegmentMember2024-01-012024-12-310001018724amzn:InternationalSegmentMember2024-01-012024-12-310001018724amzn:AmazonWebServicesSegmentMember2024-01-012024-12-310001018724amzn:NorthAmericaSegmentMember2024-12-310001018724amzn:InternationalSegmentMember2024-12-310001018724amzn:AmazonWebServicesSegmentMember2024-12-310001018724amzn:NorthAmericaSegmentMember2025-01-012025-12-310001018724amzn:InternationalSegmentMember2025-01-012025-12-310001018724amzn:AmazonWebServicesSegmentMember2025-01-012025-12-310001018724amzn:NorthAmericaSegmentMember2025-12-310001018724amzn:InternationalSegmentMember2025-12-310001018724amzn:AmazonWebServicesSegmentMember2025-12-310001018724us-gaap:MarketingRelatedIntangibleAssetsMember2024-12-310001018724us-gaap:MarketingRelatedIntangibleAssetsMember2025-12-310001018724us-gaap:MarketingRelatedIntangibleAssetsMember2025-01-012025-12-310001018724us-gaap:ContractBasedIntangibleAssetsMember2024-12-310001018724us-gaap:ContractBasedIntangibleAssetsMember2025-12-310001018724us-gaap:ContractBasedIntangibleAssetsMember2025-01-012025-12-310001018724us-gaap:TechnologyBasedIntangibleAssetsMember2024-12-310001018724us-gaap:TechnologyBasedIntangibleAssetsMember2025-12-310001018724us-gaap:TechnologyBasedIntangibleAssetsMember2025-01-012025-12-310001018724us-gaap:CustomerRelatedIntangibleAssetsMember2024-12-310001018724us-gaap:CustomerRelatedIntangibleAssetsMember2025-12-310001018724us-gaap:CustomerRelatedIntangibleAssetsMember2025-01-012025-12-310001018724srt:MinimumMember2025-12-310001018724srt:MaximumMember2025-12-310001018724us-gaap:SeniorNotesMember2025-12-310001018724amzn:November2025SeniorUnsecuredNotesMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:SeniorUnsecuredNotes2014Memberus-gaap:SeniorNotesMember2025-12-310001018724amzn:SeniorUnsecuredNotes2014Membersrt:MinimumMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:SeniorUnsecuredNotes2014Membersrt:MaximumMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:SeniorUnsecuredNotes2014Memberus-gaap:SeniorNotesMember2024-12-310001018724amzn:SeniorUnsecuredNotes2017Memberus-gaap:SeniorNotesMember2025-12-310001018724amzn:SeniorUnsecuredNotes2017Membersrt:MinimumMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:SeniorUnsecuredNotes2017Membersrt:MaximumMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:SeniorUnsecuredNotes2017Memberus-gaap:SeniorNotesMember2024-12-310001018724amzn:SeniorUnsecuredNotes2020Memberus-gaap:SeniorNotesMember2025-12-310001018724amzn:SeniorUnsecuredNotes2020Membersrt:MinimumMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:SeniorUnsecuredNotes2020Membersrt:MaximumMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:SeniorUnsecuredNotes2020Memberus-gaap:SeniorNotesMember2024-12-310001018724amzn:SeniorUnsecuredNotes2021Memberus-gaap:SeniorNotesMember2025-12-310001018724amzn:SeniorUnsecuredNotes2021Membersrt:MinimumMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:SeniorUnsecuredNotes2021Membersrt:MaximumMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:SeniorUnsecuredNotes2021Memberus-gaap:SeniorNotesMember2024-12-310001018724amzn:April2022SeniorUnsecuredNotesMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:April2022SeniorUnsecuredNotesMembersrt:MinimumMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:April2022SeniorUnsecuredNotesMembersrt:MaximumMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:April2022SeniorUnsecuredNotesMemberus-gaap:SeniorNotesMember2024-12-310001018724amzn:December2022SeniorUnsecuredNotesMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:December2022SeniorUnsecuredNotesMembersrt:MinimumMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:December2022SeniorUnsecuredNotesMembersrt:MaximumMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:December2022SeniorUnsecuredNotesMemberus-gaap:SeniorNotesMember2024-12-310001018724amzn:November2025SeniorUnsecuredNotesMembersrt:MinimumMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:November2025SeniorUnsecuredNotesMembersrt:MaximumMemberus-gaap:SeniorNotesMember2025-12-310001018724amzn:November2025SeniorUnsecuredNotesMemberus-gaap:SeniorNotesMember2024-12-310001018724amzn:OtherLongTermDebtMember2024-12-310001018724amzn:OtherLongTermDebtMember2025-12-310001018724us-gaap:SeniorNotesMember2024-12-310001018724amzn:SeniorUnsecuredNotes2014Memberus-gaap:SeniorNotesMember2025-01-012025-12-310001018724amzn:SeniorUnsecuredNotes2017Memberus-gaap:SeniorNotesMember2025-01-012025-12-310001018724amzn:SeniorUnsecuredNotes2020Memberus-gaap:SeniorNotesMember2025-01-012025-12-310001018724amzn:SeniorUnsecuredNotes2021Memberus-gaap:SeniorNotesMember2025-01-012025-12-310001018724amzn:April2022SeniorUnsecuredNotesMemberus-gaap:SeniorNotesMember2025-01-012025-12-310001018724amzn:December2022SeniorUnsecuredNotesMemberus-gaap:SeniorNotesMember2025-01-012025-12-310001018724amzn:November2025SeniorUnsecuredNotesMemberus-gaap:SeniorNotesMember2025-01-012025-12-310001018724us-gaap:SeniorNotesMember2025-01-012025-12-310001018724us-gaap:RevolvingCreditFacilityMemberamzn:October2016RevolvingCreditFacilityMemberus-gaap:LineOfCreditMember2024-01-012024-09-300001018724us-gaap:RevolvingCreditFacilityMemberamzn:October2016RevolvingCreditFacilityMemberus-gaap:LineOfCreditMember2023-12-310001018724amzn:TermLoanMemberus-gaap:LoansPayableMember2023-01-310001018724amzn:TermLoanMemberus-gaap:LoansPayableMember2023-01-012023-01-310001018724us-gaap:CommercialPaperMember2025-04-300001018724us-gaap:CommercialPaperMember2025-01-012025-12-310001018724us-gaap:CommercialPaperMember2025-03-310001018724us-gaap:CommercialPaperMember2024-12-310001018724us-gaap:CommercialPaperMember2025-12-310001018724amzn:TheCreditAgreementMemberus-gaap:LineOfCreditMember2023-11-300001018724us-gaap:RevolvingCreditFacilityMemberus-gaap:LineOfCreditMemberamzn:TheCreditAgreementMember2023-11-012023-11-300001018724amzn:TheCreditAgreementMemberus-gaap:LineOfCreditMember2023-11-012023-11-300001018724amzn:TheCreditAgreementMemberus-gaap:LineOfCreditMember2024-12-310001018724amzn:TheCreditAgreementMemberus-gaap:LineOfCreditMember2025-12-310001018724amzn:October2025ShortTermCreditAgreementMemberus-gaap:LineOfCreditMember2025-10-310001018724amzn:October2025ShortTermCreditAgreementMemberus-gaap:LineOfCreditMember2025-10-012025-10-310001018724amzn:October2024ShortTermCreditAgreementMemberus-gaap:LineOfCreditMember2024-10-012024-10-310001018724amzn:October2025ShortTermCreditAgreementMemberus-gaap:LineOfCreditMember2024-10-012024-10-310001018724amzn:ShortTermCreditAgreementMemberus-gaap:LineOfCreditMember2024-12-310001018724amzn:ShortTermCreditAgreementMemberus-gaap:LineOfCreditMember2025-12-310001018724amzn:ShortTermCreditAgreementMemberus-gaap:LineOfCreditMember2025-01-012025-12-310001018724amzn:ShortTermCreditAgreementMemberus-gaap:LineOfCreditMember2024-01-012024-12-310001018724us-gaap:LetterOfCreditMemberamzn:UnsecuredRevolvingCreditFacilityMemberus-gaap:LineOfCreditMember2025-12-310001018724amzn:OperatingAndFinanceLeasesLeaseNotYetCommencedMember2025-12-310001018724amzn:LongTermAgreementsToAcquireAndLicenseDigitalMediaContentProcureEnergyAndLicenseSoftwareMember2025-12-3100010187242024-12-312024-12-3100010187242025-12-312025-12-310001018724us-gaap:PendingLitigationMemberamzn:LegalProceedingsWithRensselaerPolytechnicInstituteAndCFDynamicAdvancesLLCMembersrt:MinimumMember2023-03-310001018724us-gaap:PendingLitigationMemberamzn:LegalProceedingsWithRensselaerPolytechnicInstituteAndCFDynamicAdvancesLLCMembersrt:MaximumMember2023-03-310001018724us-gaap:SettledLitigationMemberamzn:KoveIOInc.Member2024-04-012024-04-300001018724us-gaap:SettledLitigationMemberamzn:KoveIOInc.Member2024-08-012024-08-310001018724country:CA2025-12-310001018724country:GB2025-12-310001018724country:US2025-12-310001018724us-gaap:PendingLitigationMemberamzn:LuxembourgNationalCommissionMatterMember2021-07-310001018724us-gaap:PendingLitigationMemberamzn:ItalianCompetitionAuthorityMatterMember2021-12-310001018724us-gaap:PendingLitigationMemberamzn:ItalianCompetitionAuthorityMatterMember2025-09-3000010187242025-06-012025-06-300001018724amzn:March2022ShareRepurchaseProgramMember2022-03-310001018724srt:MinimumMember2025-01-012025-12-310001018724us-gaap:CostOfSalesMember2023-01-012023-12-310001018724us-gaap:CostOfSalesMember2024-01-012024-12-310001018724us-gaap:CostOfSalesMember2025-01-012025-12-310001018724amzn:FulfillmentExpenseMember2023-01-012023-12-310001018724amzn:FulfillmentExpenseMember2024-01-012024-12-310001018724amzn:FulfillmentExpenseMember2025-01-012025-12-310001018724amzn:TechnologyAndContentExpenseMember2023-01-012023-12-310001018724amzn:TechnologyAndContentExpenseMember2024-01-012024-12-310001018724amzn:TechnologyAndContentExpenseMember2025-01-012025-12-310001018724us-gaap:SellingAndMarketingExpenseMember2023-01-012023-12-310001018724us-gaap:SellingAndMarketingExpenseMember2024-01-012024-12-310001018724us-gaap:SellingAndMarketingExpenseMember2025-01-012025-12-310001018724us-gaap:GeneralAndAdministrativeExpenseMember2023-01-012023-12-310001018724us-gaap:GeneralAndAdministrativeExpenseMember2024-01-012024-12-310001018724us-gaap:GeneralAndAdministrativeExpenseMember2025-01-012025-12-310001018724us-gaap:RestrictedStockUnitsRSUMember2022-12-310001018724us-gaap:RestrictedStockUnitsRSUMember2023-01-012023-12-310001018724us-gaap:RestrictedStockUnitsRSUMember2023-12-310001018724us-gaap:RestrictedStockUnitsRSUMember2024-01-012024-12-310001018724us-gaap:RestrictedStockUnitsRSUMember2024-12-310001018724us-gaap:RestrictedStockUnitsRSUMember2025-01-012025-12-310001018724us-gaap:RestrictedStockUnitsRSUMember2025-12-310001018724us-gaap:AccumulatedTranslationAdjustmentMember2023-01-012023-12-310001018724us-gaap:AccumulatedTranslationAdjustmentMember2024-01-012024-12-310001018724us-gaap:AccumulatedTranslationAdjustmentMember2023-12-310001018724us-gaap:AccumulatedTranslationAdjustmentMember2024-12-310001018724us-gaap:AccumulatedTranslationAdjustmentMember2025-01-012025-12-310001018724us-gaap:AccumulatedTranslationAdjustmentMember2025-12-310001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2023-01-012023-12-310001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2024-01-012024-12-310001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2023-12-310001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2024-12-310001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2025-01-012025-12-310001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2025-12-310001018724amzn:AOCIOtherParentMember2023-01-012023-12-310001018724amzn:AOCIOtherParentMember2024-01-012024-12-310001018724amzn:AOCIOtherParentMember2023-12-310001018724amzn:AOCIOtherParentMember2024-12-310001018724amzn:AOCIOtherParentMember2025-01-012025-12-310001018724amzn:AOCIOtherParentMember2025-12-310001018724us-gaap:ForeignTaxJurisdictionOtherMember2025-12-310001018724amzn:NorthAmericaSegmentMember2023-01-012023-12-310001018724amzn:InternationalSegmentMember2023-01-012023-12-310001018724amzn:AmazonWebServicesSegmentMember2023-01-012023-12-310001018724amzn:OnlineStoresMember2023-01-012023-12-310001018724amzn:OnlineStoresMember2024-01-012024-12-310001018724amzn:OnlineStoresMember2025-01-012025-12-310001018724amzn:PhysicalStoresMember2023-01-012023-12-310001018724amzn:PhysicalStoresMember2024-01-012024-12-310001018724amzn:PhysicalStoresMember2025-01-012025-12-310001018724amzn:ThirdPartySellerServicesMember2023-01-012023-12-310001018724amzn:ThirdPartySellerServicesMember2024-01-012024-12-310001018724amzn:ThirdPartySellerServicesMember2025-01-012025-12-310001018724us-gaap:AdvertisingMember2023-01-012023-12-310001018724us-gaap:AdvertisingMember2024-01-012024-12-310001018724us-gaap:AdvertisingMember2025-01-012025-12-310001018724amzn:SubscriptionServicesMember2023-01-012023-12-310001018724amzn:SubscriptionServicesMember2024-01-012024-12-310001018724amzn:SubscriptionServicesMember2025-01-012025-12-310001018724amzn:AmazonWebServicesMember2023-01-012023-12-310001018724amzn:AmazonWebServicesMember2024-01-012024-12-310001018724amzn:AmazonWebServicesMember2025-01-012025-12-310001018724amzn:OtherServicesMember2023-01-012023-12-310001018724amzn:OtherServicesMember2024-01-012024-12-310001018724amzn:OtherServicesMember2025-01-012025-12-310001018724country:US2023-01-012023-12-310001018724country:US2024-01-012024-12-310001018724country:US2025-01-012025-12-310001018724country:DE2023-01-012023-12-310001018724country:DE2024-01-012024-12-310001018724country:DE2025-01-012025-12-310001018724country:GB2023-01-012023-12-310001018724country:GB2024-01-012024-12-310001018724country:GB2025-01-012025-12-310001018724country:JP2023-01-012023-12-310001018724country:JP2024-01-012024-12-310001018724country:JP2025-01-012025-12-310001018724us-gaap:NonUsMember2023-01-012023-12-310001018724us-gaap:NonUsMember2024-01-012024-12-310001018724us-gaap:NonUsMember2025-01-012025-12-310001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaSegmentMember2023-12-310001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaSegmentMember2024-12-310001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaSegmentMember2025-12-310001018724us-gaap:OperatingSegmentsMemberamzn:InternationalSegmentMember2023-12-310001018724us-gaap:OperatingSegmentsMemberamzn:InternationalSegmentMember2024-12-310001018724us-gaap:OperatingSegmentsMemberamzn:InternationalSegmentMember2025-12-310001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMember2023-12-310001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMember2024-12-310001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMember2025-12-310001018724us-gaap:CorporateNonSegmentMember2023-12-310001018724us-gaap:CorporateNonSegmentMember2024-12-310001018724us-gaap:CorporateNonSegmentMember2025-12-310001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaSegmentMember2023-01-012023-12-310001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaSegmentMember2024-01-012024-12-310001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaSegmentMember2025-01-012025-12-310001018724us-gaap:OperatingSegmentsMemberamzn:InternationalSegmentMember2023-01-012023-12-310001018724us-gaap:OperatingSegmentsMemberamzn:InternationalSegmentMember2024-01-012024-12-310001018724us-gaap:OperatingSegmentsMemberamzn:InternationalSegmentMember2025-01-012025-12-310001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMember2023-01-012023-12-310001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMember2024-01-012024-12-310001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMember2025-01-012025-12-310001018724us-gaap:CorporateNonSegmentMember2023-01-012023-12-310001018724us-gaap:CorporateNonSegmentMember2024-01-012024-12-310001018724us-gaap:CorporateNonSegmentMember2025-01-012025-12-310001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaAndInternationalSegmentMemberamzn:AssetsHeldUnderFinanceLeasesMember2023-01-012023-12-310001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaAndInternationalSegmentMemberamzn:AssetsHeldUnderFinanceLeasesMember2024-01-012024-12-310001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaAndInternationalSegmentMemberamzn:AssetsHeldUnderFinanceLeasesMember2025-01-012025-12-310001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaAndInternationalSegmentMemberamzn:AssetsUnderFinancingObligationsMember2023-01-012023-12-310001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaAndInternationalSegmentMemberamzn:AssetsUnderFinancingObligationsMember2024-01-012024-12-310001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaAndInternationalSegmentMemberamzn:AssetsUnderFinancingObligationsMember2025-01-012025-12-310001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMemberamzn:AssetsHeldUnderFinanceLeasesMember2023-01-012023-12-310001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMemberamzn:AssetsHeldUnderFinanceLeasesMember2024-01-012024-12-310001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMemberamzn:AssetsHeldUnderFinanceLeasesMember2025-01-012025-12-310001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMemberamzn:AssetsUnderFinancingObligationsMember2023-01-012023-12-310001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMemberamzn:AssetsUnderFinancingObligationsMember2024-01-012024-12-310001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMemberamzn:AssetsUnderFinancingObligationsMember2025-01-012025-12-310001018724country:US2023-12-310001018724country:US2024-12-310001018724us-gaap:NonUsMember2023-12-310001018724us-gaap:NonUsMember2024-12-310001018724us-gaap:NonUsMember2025-12-310001018724amzn:DavidA.ZapolskyMember2025-10-012025-12-310001018724amzn:DavidA.ZapolskyMember2025-12-310001018724amzn:DouglasJ.HerringtonMember2025-10-012025-12-310001018724amzn:DouglasJ.HerringtonMember2025-12-310001018724amzn:KeithB.AlexanderMember2025-10-012025-12-310001018724amzn:KeithB.AlexanderMember2025-12-310001018724amzn:ShelleyL.ReynoldsMember2025-10-012025-12-310001018724amzn:ShelleyL.ReynoldsMember2025-12-310001018724amzn:AndrewR.JassyMember2025-10-012025-12-310001018724amzn:AndrewR.JassyMember2025-12-310001018724amzn:JeffreyP.BezosMember2025-10-012025-12-310001018724amzn:JeffreyP.BezosMember2025-12-310001018724amzn:BrianT.OlsavskyMember2025-10-012025-12-310001018724amzn:BrianT.OlsavskyMember2025-12-31
Table of Contents
UNITED STATES
SECURITIES AND EXCHANGE COMMISSION
Washington, D.C. 20549
____________________________________
FORM 10-K
____________________________________
(Mark One)
☒	ANNUAL REPORT PURSUANT TO SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT OF 1934
For the fiscal year ended December 31, 2025
or
☐	TRANSITION REPORT PURSUANT TO SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT OF 1934
For the transition period from            to             .
Commission File No. 000-22513
____________________________________
AMAZON.COM, INC.
(Exact name of registrant as specified in its charter)
Delaware	 	91-1646860
(State or other jurisdiction of
incorporation or organization)	 	(I.R.S. Employer
Identification No.)
410 Terry Avenue North
Seattle, Washington 98109-5210
(206) 266-1000
(Address and telephone number, including area code, of registrant’s principal executive offices)
Securities registered pursuant to Section 12(b) of the Act:
Title of Each Class	Trading Symbol(s)	Name of Each Exchange on Which Registered
Common Stock, par value $.01 per share	AMZN	Nasdaq Global Select Market
Securities registered pursuant to Section 12(g) of the Act:
None
____________________________________
Indicate by check mark if the registrant is a well-known seasoned issuer, as defined in Rule 405 of the Securities Act.    Yes  ☒    No  ☐
Indicate by check mark if the registrant is not required to file reports pursuant to Section 13 or Section 15(d) of the Exchange Act.    Yes  ☐    No  ☒
Indicate by check mark whether the registrant (1) has filed all reports required to be filed by Section 13 or 15(d) of the Securities Exchange Act of 1934 during the preceding 12 months (or for such shorter period that the registrant was required to file such reports), and (2) has been subject to such filing requirements for the past 90 days.    Yes  ☒    No  ☐
Indicate by check mark whether the registrant has submitted electronically every Interactive Data File required to be submitted pursuant to Rule 405 of Regulation S-T during the preceding 12 months (or for such shorter period that the registrant was required to submit such files).    Yes  ☒    No  ☐
Indicate by check mark whether the registrant is a large accelerated filer, an accelerated filer, a non-accelerated filer, a smaller reporting company, or an emerging growth company. See the definitions of “large accelerated filer,” “accelerated filer,” “smaller reporting company,” and “emerging growth company” in Rule 12b-2 of the Exchange Act.
Large accelerated filer		☒	Accelerated filer		☐
Non-accelerated filer		☐	Smaller reporting company		☐
Emerging growth company		☐
If an emerging growth company, indicate by check mark if the registrant has elected not to use the extended transition period for complying with any new or revised financial accounting standards provided pursuant to Section 13(a) of the Exchange Act.  ☐
Indicate by check mark whether the registrant has filed a report on and attestation to its management’s assessment of the effectiveness of its internal control over financial reporting under Section 404(b) of the Sarbanes-Oxley Act (15 U.S.C. 7262(b)) by the registered public accounting firm that prepared or issued its audit report. ☒
If securities are registered pursuant to Section 12(b) of the Exchange Act, indicate by check mark whether the financial statements of the registrant included in the filing reflect the correction of an error to previously issued financial statements.  ☐
Indicate by check mark whether any of those error corrections are restatements that required a recovery analysis of incentive-based compensation received by any of the registrant’s executive officers during the relevant recovery period pursuant to §240.10D-1(b).  ☐
Indicate by check mark whether the registrant is a shell company (as defined in Rule 12b-2 of the Exchange Act).    Yes  ☐    No  ☒
Aggregate market value of voting stock held by non-affiliates of the registrant as of June 30, 2025	$	2,118,061,430,046
Number of shares of common stock outstanding as of January 28, 2026	10,734,920,870
____________________________________
DOCUMENTS INCORPORATED BY REFERENCE
The information required by Part III of this Report, to the extent not set forth herein, is incorporated herein by reference from the registrant’s definitive proxy statement relating to the Annual Meeting of Shareholders to be held in 2026, which definitive proxy statement shall be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this Report relates.
Table of Contents
AMAZON.COM, INC.
FORM 10-K
For the Fiscal Year Ended December 31, 2025
INDEX
Page
PART I
Item 1.
Business
3
Item 1A.
Risk Factors
6
Item 1B.
Unresolved Staff Comments
17
Item 1C.
Cybersecurity
17
Item 2.
Properties
18
Item 3.
Legal Proceedings
18
Item 4.
Mine Safety Disclosures
18
PART II
Item 5.
Market for the Registrant’s Common Stock, Related Shareholder Matters, and Issuer Purchases of Equity Securities
19
Item 6.
Reserved
19
Item 7.
Management’s Discussion and Analysis of Financial Condition and Results of Operations
20
Item 7A.
Quantitative and Qualitative Disclosures About Market Risk
31
Item 8.
Financial Statements and Supplementary Data
33
Item 9.
Changes in and Disagreements with Accountants on Accounting and Financial Disclosure
72
Item 9A.
Controls and Procedures
72
Item 9B.
Other Information
74
Item 9C.
Disclosure Regarding Foreign Jurisdictions that Prevent Inspections
74
PART III
Item 10.
Directors, Executive Officers, and Corporate Governance
74
Item 11.
Executive Compensation
74
Item 12.
Security Ownership of Certain Beneficial Owners and Management and Related Shareholder Matters
74
Item 13.
Certain Relationships and Related Transactions, and Director Independence
75
Item 14.
Principal Accountant Fees and Services
75
PART IV
Item 15.
Exhibits, Financial Statement Schedules
76
Item 16.
Form 10-K Summary
78
Signatures
79
2
Table of Contents
AMAZON.COM, INC.
PART I
Item 1.	Business
This Annual Report on Form 10-K and the documents incorporated herein by reference contain forward-looking statements based on expectations, estimates, and projections as of the date of this filing. Actual results and outcomes may differ materially from those expressed in forward-looking statements. See Item 1A of Part I — “Risk Factors.” As used herein, “Amazon.com,” “we,” “our,” and similar terms include Amazon.com, Inc. and its subsidiaries, unless the context indicates otherwise.
General
We seek to be Earth’s most customer-centric company. We are guided by four principles: customer obsession rather than competitor focus, passion for invention, commitment to operational excellence, and long-term thinking. In each of our segments, we serve our primary customer sets, consisting of consumers, sellers, developers, enterprises, content creators, advertisers, and employees.
We have organized our operations into three segments: North America, International, and Amazon Web Services (“AWS”). These segments reflect the way the Company evaluates its business performance and manages its operations. Information on our net sales is contained in Item 8 of Part II, “Financial Statements and Supplementary Data — Note 10 — Segment Information.”
Consumers
We serve consumers through our online and physical stores and focus on selection, price, and convenience. We design our stores to enable hundreds of millions of unique products to be sold by us and by third parties across dozens of product categories. Customers access our offerings through our websites, mobile apps, Alexa, devices, streaming, and physically visiting our stores. We also manufacture and sell electronic devices, including Kindle, Fire tablet, Fire TV, Echo, Ring, Blink, and eero, and we develop and produce media content. We seek to offer our customers low prices, fast and free delivery, easy-to-use functionality, and timely customer service. In addition, we offer subscription services such as Amazon Prime, a membership program that includes fast, free shipping on tens of millions of items, access to award-winning movies and series, live sports, and other benefits.
We fulfill customer orders in a number of ways, including through: North America and International fulfillment networks that we operate; co-sourced and outsourced arrangements in certain countries; digital delivery; and through our physical stores. We operate customer service centers globally, which are supplemented by co-sourced arrangements. See Item 2 of Part I, “Properties.”
Sellers
We offer programs that enable sellers to grow their businesses, sell their products in our stores, and fulfill orders using our services. We are not the seller of record in these transactions. We earn fixed fees, a percentage of sales, per-unit activity fees, interest, or some combination thereof, for our seller programs.
Developers and Enterprises
We serve developers and enterprises of all sizes, including start-ups, government agencies, and academic institutions, through AWS, which offers a broad set of on-demand technology services, including compute, storage, database, analytics, artificial intelligence and machine learning, and other services.
Content Creators
We offer programs that allow authors, independent publishers, musicians, filmmakers, Twitch streamers, skill and app developers, and others to publish and sell content.
Advertisers
We provide advertising services to sellers, vendors, publishers, authors, and others, through programs such as sponsored ads, display, and video advertising.
3
Table of Contents
Competition
Our businesses encompass a large variety of product types, service offerings, and delivery channels. The worldwide marketplace in which we compete is evolving rapidly and intensely competitive, and we face a broad array of competitors from many different industry sectors around the world. Our current and potential competitors include: (1) physical, e-commerce, and omnichannel retailers, publishers, vendors, distributors, manufacturers, and producers of the products we offer and sell to consumers and businesses; (2) publishers, producers, and distributors of physical, digital, and interactive media of all types and all distribution channels; (3) web search engines, comparison shopping websites, social networks, web portals, virtual assistants, and other online and app-based means of discovering, using, or acquiring goods and services, either directly or in collaboration with other retailers, including through artificial intelligence; (4) companies that provide e-commerce services, including website development and hosting, omnichannel sales, inventory and supply chain management, advertising, fulfillment, customer service, and payment processing; (5) companies that provide fulfillment and logistics services for themselves or for third parties, whether online or offline; (6) companies that provide information technology services or products, including on-premises or cloud-based infrastructure, tools and services relating to artificial intelligence, and other services; (7) companies that design, manufacture, market, or sell consumer electronics, communications, and other electronic devices and services; (8) companies that sell grocery products online and in physical stores; (9) companies that provide advertising services, whether in digital or other formats; and (10) providers of virtual or in-person healthcare services. We believe that the principal competitive factors in our retail businesses include selection, price, and convenience, including fast and reliable fulfillment. Additional competitive factors for our seller and enterprise services include the quality, speed, and reliability of our services and tools, as well as customers’ ability and willingness to change business practices. Some of our current and potential competitors have greater resources, longer histories, more customers, greater brand recognition, and greater control over inputs critical to our various businesses. They may secure better terms from suppliers, adopt more aggressive pricing, pursue restrictive distribution agreements that restrict our access to supply, direct consumers to their own offerings instead of ours, lock-in potential customers with restrictive terms, and devote more resources to technology, infrastructure, fulfillment, and marketing. The internet and other technologies including artificial intelligence facilitate competitive entry and comparison shopping, which enhances the ability of new, smaller, or lesser-known businesses to compete against us. Each of our businesses is also subject to rapid change and the development of new business models and the entry of new and well-funded competitors. Other companies also may enter into business combinations or alliances that strengthen their competitive positions.
Intellectual Property
We regard our trademarks, service marks, copyrights, patents, domain names, trade dress, trade secrets, proprietary technologies, and similar intellectual property as critical to our success, and we rely on trademark, copyright, and patent law, trade-secret protection, and confidentiality and/or license agreements with our employees, customers, partners, and others to protect our proprietary rights. We have registered, or applied for the registration of, a number of U.S. and international domain names, trademarks, service marks, and copyrights. Additionally, we have filed U.S. and international patent applications covering certain of our proprietary technology.
Seasonality
Our business is affected by seasonality, which historically has resulted in higher sales volume during our fourth quarter, which ends December 31.
Human Capital
Our employees are critical to our mission of being Earth’s most customer-centric company. As of December 31, 2025, we employed approximately 1,576,000 full-time and part-time employees. Additionally, we use independent contractors and temporary personnel to supplement our workforce. Competition for qualified personnel is intense, particularly for software engineers, computer scientists, and other technical staff (including for artificial intelligence and machine learning technologies), and constrained labor markets have increased competition for personnel across other parts of our business.
We strive to be Earth’s best employer. We rely on numerous and evolving initiatives to implement this objective and invent mechanisms for talent development, including competitive pay and benefits, flexible work arrangements, and skills training and educational programs such as Amazon Career Choice (education funding for eligible employees). Over 300,000 Amazon employees around the world have participated in Career Choice. We also continue to inspect and refine the mechanisms we use to hire, develop, evaluate, and retain our employees. In addition, safety is integral to everything we do at Amazon and we continue to invest in safety improvements such as capital improvements, new safety technology, vehicle safety controls, and engineering ergonomic solutions. Our safety team is dedicated to using the science of safety to solve complex problems and establish new industry best practices. We also provide mentorship and support resources to our employees, and have deployed numerous programs that advance employee engagement, communication, and feedback.
4
Table of Contents
Available Information
Our investor relations website is amazon.com/ir and we encourage investors to use it as a way of easily finding information about us. We promptly make available on this website, free of charge, the reports that we file or furnish with the Securities and Exchange Commission (“SEC”), corporate governance information (including our Code of Business Conduct and Ethics), and select press releases.
Executive Officers and Directors
The following tables set forth certain information regarding our Executive Officers and Directors as of January 28, 2026:
Information About Our Executive Officers
Name		Age		Position
Jeffrey P. Bezos		62		Executive Chair
Andrew R. Jassy		58		President and Chief Executive Officer
Matthew S. Garman		49		CEO Amazon Web Services
Douglas J. Herrington		59		CEO Worldwide Amazon Stores
Brian T. Olsavsky		62		Senior Vice President and Chief Financial Officer
Shelley L. Reynolds		61		Vice President, Worldwide Controller, and Principal Accounting Officer
David A. Zapolsky		62		Senior Vice President, Chief Global Affairs & Legal Officer
Jeffrey P. Bezos. Mr. Bezos founded Amazon.com in 1994 and has served as Executive Chair since July 2021. He has served as Chair of the Board since 1994 and served as Chief Executive Officer from May 1996 until July 2021, and as President from 1994 until June 1999 and again from October 2000 to July 2021.
Andrew R. Jassy. Mr. Jassy has served as President and Chief Executive Officer since July 2021, CEO Amazon Web Services from April 2016 until July 2021, and Senior Vice President, Amazon Web Services, from April 2006 until April 2016.
Matthew S. Garman. Mr. Garman has served as CEO Amazon Web Services since June 2024, Senior Vice President, Amazon Web Services from February 2021 until June 2024, Vice President, Marketing, Sales and Support of Amazon Web Services from January 2020 to February 2021, Vice President, AWS Compute Services from September 2018 to January 2020, and Vice President, EC2 from December 2012 to September 2018.
Douglas J. Herrington. Mr. Herrington has served as CEO Worldwide Amazon Stores since July 2022, Senior Vice President, North America Consumer from January 2015 to July 2022, Senior Vice President, Consumables from May 2014 to December 2014, and Vice President, Consumables from May 2005 to April 2014.
Brian T. Olsavsky. Mr. Olsavsky has served as Senior Vice President and Chief Financial Officer since June 2015, Vice President, Finance for the Global Consumer Business from December 2011 to June 2015, and numerous financial leadership roles across Amazon with global responsibility since April 2002.
Shelley L. Reynolds. Ms. Reynolds has served as Vice President, Worldwide Controller, and Principal Accounting Officer since April 2007.
David A. Zapolsky. Mr. Zapolsky has served as Senior Vice President, Chief Global Affairs & Legal Officer since February 2025. He served as our Senior Vice President, Global Public Policy and General Counsel from May 2023 to February 2025, Secretary from September 2012 to January 2024, Senior Vice President and General Counsel from May 2014 to May 2023, Vice President and General Counsel from September 2012 to May 2014, and as Vice President and Associate General Counsel for Litigation and Regulatory matters from April 2002 until September 2012.
5
Table of Contents
Board of Directors
Name		Age		Position
Jeffrey P. Bezos		62		Executive Chair
Andrew R. Jassy		58		President and Chief Executive Officer
Keith B. Alexander		74		Former Chair and CEO of IronNet, Inc.
Edith W. Cooper		64		Former Executive Vice President, Goldman Sachs Group, Inc.
Jamie S. Gorelick		75		Senior Counsel, Wilmer Cutler Pickering Hale and Dorr LLP
Daniel P. Huttenlocher		67		Dean, MIT Schwarzman College of Computing
Andrew Y. Ng		49		Managing General Partner, AI Fund, L.P.
Indra K. Nooyi		70		Former Chair and CEO, PepsiCo, Inc.
Jonathan J. Rubinstein		69		Former co-CEO, Bridgewater Associates, LP
Brad D. Smith		61		President, Marshall University
Patricia Q. Stonesifer		69		Former President and Chief Executive Officer, Martha’s Table
Wendell P. Weeks		66		Chairman, CEO, and President, Corning Incorporated
Item 1A.	Risk Factors
Please carefully consider the following discussion of significant factors, events, and uncertainties that make an investment in our securities risky. The events and consequences discussed in these risk factors could, in circumstances we may or may not be able to accurately predict, recognize, or control, have a material adverse effect on our business, growth, reputation, prospects, financial condition, operating results (including components of our financial results), cash flows, liquidity, and stock price. These risk factors do not identify all risks that we face; our operations could also be affected by factors, events, or uncertainties that are not presently known to us or that we currently do not consider to present significant risks to our operations. In addition to the factors discussed in Item 7 of Part II, “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” and in the risk factors below, global economic and geopolitical conditions and additional or unforeseen circumstances, developments, or events may give rise to or amplify many of the risks discussed below. Many of the risks discussed below also impact our customers, including third-party sellers, which could indirectly have a material adverse effect on us. The disclosures in this section reflect our beliefs and opinions as to factors that could materially and adversely affect us in the future. References to past events are provided by way of example only and are not intended to be a complete listing or a representation as to whether or not such factors have occurred in the past.
Business and Industry Risks
We Face Intense Competition
Our businesses are rapidly evolving and intensely competitive, and we have many competitors across geographies, including cross-border competition, and in different industries, including physical, e-commerce, and omnichannel retail, e-commerce services, web and infrastructure computing services, electronic devices, digital content, advertising, grocery, healthcare, communications, and transportation and logistics services. Some of our current and potential competitors have greater resources, longer histories, more customers, and/or greater brand recognition, particularly with our newly-launched products and services and in our newer geographic regions. They may secure better terms from vendors, adopt more aggressive pricing, and devote more resources to technology, infrastructure, fulfillment, and marketing.
Competition continues to intensify, including with the development of new business models and the entry of new and well-funded competitors, and as our competitors enter into business combinations or alliances and established companies in other market segments expand to become competitive with our business. In addition, new and enhanced technologies, including search, web and infrastructure computing services, practical applications of artificial intelligence and machine learning, digital content, satellites, and electronic devices continue to increase our competition. The internet and other technologies including artificial intelligence facilitate competitive entry and comparison shopping, which enhances the ability of new, smaller, or lesser-known businesses to compete against us. As a result of competition, our product and service offerings may not be successful, we may fail to gain or may lose business, and we may be required to increase our spending or lower prices, any of which could materially reduce our sales and profits.
Our Expansion into New Products, Services, Technologies, and Geographic Regions Subjects Us to Additional Risks
We may have limited or no experience in our newer market segments, and our customers may not adopt our product or service offerings. These offerings, which can present new and difficult technology challenges, may subject us to claims if customers of these offerings experience, or are otherwise impacted by, service disruptions, delays, setbacks, or failures or
6
Table of Contents
quality issues. In addition, profitability or other intended benefits, if any, in our newer activities (including development and adoption of automation, artificial intelligence, and machine learning technologies for customer and internal use), may not meet our expectations, and we may not be successful enough in these newer activities to recoup our investments in them, which investments are often significant. Failure to realize the benefits of amounts we invest in new technologies, products, or services could result in the value of those investments being written down or written off. In addition, our sustainability initiatives may be unsuccessful for a variety of reasons, including if we are unable to realize the expected benefits of new technologies or if we do not successfully plan or execute new strategies, which could harm our business or damage our reputation.
Our International Operations Expose Us to a Number of Risks
Our international activities are significant to our revenues and profits, and we plan to further expand internationally. In certain international market segments, we have relatively little operating experience and may not benefit from any first-to-market advantages or otherwise succeed. It is costly to establish, develop, and maintain international operations and stores, and promote our brand internationally. Our international operations may not become profitable on a sustained basis.
In addition to risks described elsewhere in this section, our international sales and operations are subject to a number of risks, including:
•local economic and political conditions;
•government regulation (such as regulation of our product and service offerings and of competition); restrictive governmental actions (such as trade protection or retaliatory measures, including export duties and quotas and custom duties and tariffs, and restrictions around the import and export of certain products, technologies, and components); nationalization; and restrictions on foreign ownership;
•restrictions on sales or distribution of certain products or services and uncertainty regarding liability for products, services, and content, including uncertainty as a result of less internet-friendly legal systems, local laws, lack of legal precedent, and varying rules, regulations, and practices regarding the physical and digital distribution of media products and enforcement of intellectual property rights;
•business licensing or certification requirements, such as for imports, exports, web services, electronic devices, and communications services;
•limitations on the repatriation and investment of funds and foreign currency exchange restrictions;
•limited fulfillment and technology infrastructure;
•shorter payable and longer receivable cycles and the resultant negative impact on cash flow;
•laws and regulations regarding privacy, data use, data protection, data security, data localization, network security, consumer protection, payments, advertising, and restrictions on pricing or discounts;
•lower levels of use of the internet;
•lower levels of consumer spending and fewer opportunities for growth compared to the U.S.;
•lower levels of credit card usage and increased payment risk;
•difficulty in staffing, developing, and managing foreign operations as a result of distance, language, and cultural differences;
•different employee/employer relationships and the existence of works councils and labor unions;
•compliance with the U.S. Foreign Corrupt Practices Act and other applicable U.S. and foreign laws prohibiting corrupt payments to government officials and other third parties;
•laws and policies of the U.S. and other jurisdictions affecting trade (such as tariff policy changes), foreign investment, loans, and taxes; and
•geopolitical events, including war and terrorism.
As international physical, e-commerce, and omnichannel retail, cloud services, and other services grow, competition will intensify, including through adoption of evolving business models. Local companies may have a substantial competitive advantage because of their greater understanding of, and focus on, the local customer, as well as their more established local brand names. The inability to hire, train, retain, and manage sufficient required personnel may limit our international growth.
The People’s Republic of China (“PRC”) and India regulate Amazon’s and its affiliates’ businesses and operations in country through regulations and license requirements that may restrict (i) foreign investment in and operation of the internet, IT infrastructure, data centers, retail, delivery, and other sectors, (ii) internet content, and (iii) the sale of media and other products and services. For example, in order to meet local ownership, regulatory licensing, and cybersecurity requirements, we provide
7
Table of Contents
certain technology services in China through contractual relationships with third parties that hold PRC licenses to provide services. In India, the government restricts the ownership or control of Indian companies by foreign entities involved in online multi-brand retail trading activities. For www.amazon.in, we provide certain marketing tools and logistics services to third-party sellers to enable them to sell online and deliver to customers, and we hold an indirect minority interest in an entity that is a third-party seller on the www.amazon.in marketplace. Although we believe these structures and activities comply with existing laws, they involve unique risks, and the PRC and India may from time to time consider and implement additional changes in their regulatory, licensing, or other requirements that could impact these structures and activities. There are substantial uncertainties regarding the interpretation of PRC and Indian laws and regulations, and it is possible that these governments will ultimately take a view contrary to ours. In addition, our Chinese and Indian businesses and operations may be unable to continue to operate if we or our affiliates are unable to access sufficient funding or, in China, enforce contractual relationships we or our affiliates have in place. Violation of any existing or future PRC, Indian, or other laws or regulations or changes in the interpretations of those laws and regulations could result in our businesses in those countries being subject to fines and other financial penalties, having licenses revoked, or being forced to restructure our operations or shut down entirely.
In addition, because China-based sellers account for significant portions of our third-party seller services and advertising revenues, and China-based suppliers provide significant portions of our components and finished goods, regulatory and trade restrictions, tariff policy changes and trade disputes, data protection and cybersecurity laws, economic factors, geopolitical events, security issues, or other factors negatively impacting China-based sellers and suppliers could adversely affect our operating results.
The Variability in Our Retail Business Places Increased Strain on Our Operations
Demand for our products and services can fluctuate significantly for many reasons, including as a result of seasonality, promotions, product launches, or unforeseeable events, such as in response to global economic conditions such as recessionary fears or rising inflation (including as a result of tariff policy changes), natural or human-caused disasters (including public health crises) or extreme weather (including as a result of climate change), or geopolitical events. For example, we expect a disproportionate amount of our retail sales to occur during our fourth quarter. Our failure to stock or restock popular products in sufficient amounts such that we fail to meet customer demand could significantly affect our revenue and our future growth. When we overstock products, we may be required to take significant inventory markdowns or write-offs and incur commitment costs, which could materially reduce profitability. We regularly experience increases in our net shipping cost due to complimentary upgrades, split-shipments, and additional long-zone shipments necessary to ensure timely delivery for the holiday season. If too many customers access our websites within a short period of time due to increased demand, we may experience system interruptions that make our websites unavailable or prevent us from efficiently fulfilling orders, which may reduce the volume of goods we offer or sell and the attractiveness of our products and services. In addition, we may be unable to adequately staff our fulfillment network and customer service centers during these peak periods and delivery and other fulfillment companies and customer service co-sourcers may be unable to meet the seasonal demand. Risks described elsewhere in this Item 1A relating to fulfillment network optimization and inventory are magnified during periods of high demand.
As a result of holiday sales, as of December 31 of each year, our cash, cash equivalents, and marketable securities balances typically reach their highest level (other than as a result of cash flows provided by or used in investing and financing activities) because consumers primarily use credit cards in our stores and the related receivables settle quickly. Typically, there is also a corresponding increase in accounts payable as of December 31 due to inventory purchases and third-party seller sales. Our accounts payable balance generally declines during the first three months of the year as vendors and sellers are paid, resulting in a corresponding decline in our cash, cash equivalents, and marketable securities balances.
We Are Impacted by Fraudulent or Unlawful Activities of Sellers
The law relating to the liability of online service providers is currently unsettled. In addition, governmental agencies have in the past and could in the future require changes in the way this business is conducted. Under our seller programs, we maintain policies and processes designed to prevent sellers from collecting payments, fraudulently or otherwise, when buyers never receive the products they ordered or when the products received are materially different from the sellers’ descriptions, and to prevent sellers in our stores or through other stores from selling unlawful, counterfeit, pirated, or stolen goods, selling goods in an unlawful or unethical manner, violating the proprietary rights of others, or otherwise violating our policies. When these policies and processes are circumvented or fail to operate sufficiently, it can harm our business or damage our reputation and we could face civil or criminal liability for unlawful activities by our sellers. Under our A-to-z Guarantee, we may reimburse customers for payments up to certain limits in these situations, and as our third-party seller sales grow, the cost of this program will increase and could negatively affect our operating results.
8
Table of Contents
We Face Risks Related to Adequately Protecting Our Intellectual Property Rights and Being Accused of Infringing Intellectual Property Rights of Third Parties
We regard our trademarks, service marks, copyrights, patents, trade dress, trade secrets, proprietary technology, and similar intellectual property as critical to our success, and we rely on trademark, copyright, and patent law, trade secret protection, and confidentiality and/or license agreements with our employees, customers, and others to protect our proprietary rights. Effective intellectual property protection is not available in every country in which our products and services are made available. We also may not be able to acquire or maintain appropriate domain names in all countries in which we do business. Furthermore, regulations governing domain names may not protect our trademarks and similar proprietary rights. We may be unable to prevent third parties from acquiring domain names that are similar to, infringe upon, or diminish the value of our trademarks and other proprietary rights.
We are not always able to discover or determine the extent of any unauthorized use of our proprietary rights. Actions taken by third parties that license our proprietary rights may materially diminish the value of our proprietary rights or reputation. The protection of our intellectual property requires the expenditure of significant financial and managerial resources. Moreover, the steps we take to protect our intellectual property do not always adequately protect our rights or prevent third parties from infringing or misappropriating our proprietary rights. We also cannot be certain that others will not independently develop or otherwise acquire equivalent or superior technology or other intellectual property rights.
We have been subject to, and expect to continue to be subject to, claims and legal proceedings regarding alleged infringement by us of the intellectual property rights of third parties. Such claims, whether or not meritorious, have in the past, and may in the future, result in the expenditure of significant financial and managerial resources, injunctions against us, or significant payments for damages, including to satisfy indemnification obligations or to obtain licenses from third parties who allege that we have infringed their rights. Such licenses may not be available on terms acceptable to us or at all. These risks have been amplified by the increase in third parties whose sole or primary business is to assert such claims. In addition, our and our customers’ development and use of artificial intelligence may result in increased claims of infringement or other claims, including those based on unauthorized use of third-party technology or content.
Our digital content offerings depend in part on effective digital rights management technology to control access to digital content. Breach or malfunctioning of the digital rights management technology that we use could subject us to claims, and content providers may be unwilling to include their content in our service.
We Have Foreign Exchange Risk
The results of operations of, and certain of our intercompany balances associated with, our international stores and product and service offerings are exposed to foreign exchange rate fluctuations. Due to these fluctuations, operating results may differ materially from expectations, and we may record significant gains or losses on the remeasurement of intercompany balances. As we have expanded our international operations, our exposure to exchange rate fluctuations has increased. We also hold cash equivalents and/or marketable securities in foreign currencies such as British Pounds, Canadian Dollars, Euros, and Japanese Yen. When the U.S. Dollar strengthens compared to these currencies, cash equivalents, and marketable securities balances, when translated, may be materially less than expected and vice versa.
Operating Risks
Our Expansion Places a Significant Strain on our Management, Operational, Financial, and Other Resources
We are continuing to rapidly and significantly expand our global operations, including increasing our product and service offerings, scaling our infrastructure to support our retail and services businesses (including our technology infrastructure), and adopting and utilizing artificial intelligence and machine learning technologies. The complexity of the current scale of our business can place significant strain on our management, personnel, operations, systems, technical performance, financial resources, and internal financial control and reporting functions, and our expansion increases these factors. Failure to manage growth effectively could damage our reputation, limit our growth, and negatively affect our operating results.
We Experience Significant Fluctuations in Our Operating Results and Growth Rate
We are not always able to accurately forecast our growth rate. We base our expense levels and investment plans on sales estimates. A significant portion of our expenses and investments is fixed, and we are not always able to adjust our spending quickly enough if our sales are less than expected.
9
Table of Contents
Our revenue growth may not be sustainable, and our percentage growth rates may decrease. Our revenue and operating profit growth depends on the continued growth of demand for the products and services offered by us or our sellers, and our business is affected by, among other things, general economic, business, and geopolitical conditions worldwide. A softening of demand, whether caused by changes in customer preferences or a weakening of the U.S. or global economies, may result in decreased revenue or growth.
Our sales and operating results will also fluctuate for many other reasons, including due to factors described elsewhere in this section and the following:
•our ability to retain and increase sales to existing customers, attract new customers, and satisfy our customers’ demands;
•our ability to retain and expand our network of sellers;
•our ability to offer products on favorable terms, manage inventory, and fulfill orders;
•the introduction of competitive stores, websites, products, services, price decreases, or improvements;
•changes in usage or adoption rates of the internet, e-commerce, electronic devices, web services, satellite communications services, and artificial intelligence and machine learning technologies, products, and services, including outside the U.S.;
•timing, effectiveness, and costs of expansion and upgrades of our systems and infrastructure;
•the success of our geographic, service, and product line expansions;
•the extent to which we finance, and the terms of any such financing for, our current operations and future growth;
•the outcomes of legal proceedings and claims, which may include significant monetary damages or injunctive relief and could have a material adverse impact on our operating results;
•variations in the mix of products and services we sell;
•variations in our level of merchandise and vendor returns;
•the extent to which we offer fast and free delivery, continue to reduce prices worldwide, and provide additional benefits to our customers;
•factors affecting our reputation or brand image (including any actual or perceived inability to achieve our goals or commitments, whether related to sustainability, customers, employees, or other topics), and public perceptions regarding our positions on social or ethical issues and our development and use of artificial intelligence, machine learning, and automation technologies, products, and services;
•the extent to which we invest in technology and infrastructure, fulfillment, and other expense categories;
•availability of and increases in the prices of transportation (including fuel), resources such as land, water, and energy, commodities like paper and packing supplies and hardware products, and technology infrastructure products, including as a result of inflationary pressures;
•constrained labor markets, which increase our payroll costs;
•the extent to which operators of networks, systems, and services between us and customers successfully divert customers from or charge fees to access our stores and service offerings;
•our ability to collect amounts owed to us when they become due;
•the extent to which new and existing technologies, or industry trends, restrict online advertising or affect our ability to customize advertising or otherwise tailor our product and service offerings;
•the extent to which use of our services is affected by spyware, viruses, phishing and other spam emails, denial of service attacks, data theft, computer intrusions, outages, and similar events;
•the extent to which we fail to maintain our unique culture of innovation, customer obsession, and long-term thinking, which has been critical to our growth and success;
•disruptions from natural or human-caused disasters (including public health crises) or extreme weather (including as a result of climate change), geopolitical events and security issues (including terrorist attacks, armed hostilities, and political conflicts, including those involving China), labor or trade disputes (including restrictive governmental actions impacting us, our customers, and our third-party sellers and suppliers in China or other foreign countries), tariff policy changes (such as tariffs proposed or implemented by the U.S. and other countries and any retaliatory actions), and similar events; and
10
Table of Contents
•potential negative impacts of climate change, including: increased operating costs due to more frequent extreme weather events or climate-related changes, such as rising temperatures and water scarcity; increased investment requirements associated with the transition to a low-carbon economy; decreased demand for our products and services as a result of changes in customer behavior; increased compliance costs due to more extensive and global regulations and third-party requirements; and reputational damage resulting from perceptions of our environmental impact.
We Face Risks Related to Successfully Optimizing and Operating Our Fulfillment Network and Data Centers
Failures to adequately predict customer demand and consumer spending patterns or otherwise optimize and operate our fulfillment network and data centers successfully from time to time result in excess or insufficient fulfillment or data center capacity, service interruptions, increased costs, and impairment charges, any of which could materially harm our business. As we continue to add fulfillment and data center capability or add new businesses with different requirements, our fulfillment and data center networks become increasingly complex and operating them becomes more challenging. There can be no assurance that we will be able to operate our networks effectively.
In addition, failure to optimize inventory management or staffing in our fulfillment network increases our net shipping cost by increasing the distance products are shipped and reducing the number of units per shipment or delivery. We and our co-sourcers may be unable to adequately staff our fulfillment network and customer service centers. For example, productivity across our fulfillment network is affected by regional labor market constraints, which increase payroll costs and make it difficult to hire, train, and deploy a sufficient number of people to operate our fulfillment network as efficiently as we would like.
Under some of our commercial agreements, we maintain the inventory of other companies, thereby increasing the complexity of tracking inventory and operating our fulfillment network. Our failure to adequately predict seller demand for storage or to properly handle such inventory or the inability of the other businesses on whose behalf we perform inventory fulfillment services to accurately forecast product demand may result in us being unable to secure sufficient storage space or to optimize our fulfillment network or cause other unexpected costs and other harm to our business and reputation.
We rely on a limited number of shipping companies to deliver inventory to us and completed orders to our customers. An inability to negotiate acceptable terms with these companies or performance problems, staffing limitations, or other difficulties experienced by these companies or by our own transportation systems, including as a result of labor market constraints and related costs, could negatively impact our operating results and customer experience. In addition, our ability to receive inbound inventory efficiently and ship completed orders to customers also may be negatively affected by natural or human-caused disasters (including public health crises) or extreme weather (including as a result of climate change), geopolitical events and security issues, labor or trade disputes, tariff policy changes, and similar events.
We Could Be Harmed by Data Loss or Other Security Incidents
Because we collect, process, store, and transmit large amounts of data, including confidential, classified, sensitive, proprietary, and business and personal information, failure to prevent, detect, or mitigate data loss, theft, misuse, unauthorized access, or other security incidents or vulnerabilities affecting our or our vendors’ or customers’ technology, products, and systems, could: expose us or our customers to a risk of loss, disclosure, or misuse of such information; adversely affect our operating results; result in litigation, liability, or regulatory action (including under laws related to privacy, data use, data protection, data security, network security, and consumer protection); deter customers or sellers from using our stores, products, and services; and otherwise harm our business and reputation. We use third-party technology and systems for a variety of reasons, including, without limitation, artificial intelligence technologies, encryption and authentication technology, employee email and other communication technologies, content delivery to customers, back-office support, and other functions. Some of our systems have experienced past security incidents, and, although they did not have a material adverse effect on our operating results, there can be no assurance that future incidents will not have material adverse effects on our operations or financial results. Although we have developed systems and processes that are designed to protect customer data and prevent, detect, or mitigate such incidents, including systems and processes designed to reduce the impact of a security incident at a third-party vendor or customer, such measures cannot provide absolute security and may fail to operate as intended or be circumvented, including by use of developing technologies such as artificial intelligence.
We Face Risks Related to System Interruption and Lack of Redundancy
We experience occasional system interruptions and delays that make our websites and services unavailable or slow to respond and prevent us from efficiently accepting or fulfilling orders or providing services to customers and third parties, which may reduce our net sales and the attractiveness of our products and services. Steps we take to add software and hardware, upgrade our systems and network infrastructure, and improve the stability and efficiency of our systems may not be sufficient to avoid system interruptions or delays that could adversely affect our operating results.
11
Table of Contents
Our computer and communications systems and operations in the past have been, or in the future could be, damaged or interrupted due to events such as natural or human-caused disasters (including public health crises) or extreme weather (including as a result of climate change), geopolitical events and security issues (including terrorist attacks and armed hostilities), computer viruses, physical or electronic break-ins, operational failures (including from energy shortages), and similar events or disruptions. Any of these events could cause system interruption, delays, and loss of critical data, and could prevent us from accepting and fulfilling customer orders and providing services, which could make our product and service offerings less attractive and subject us to liability. Our systems are not fully redundant and our disaster recovery planning may not be sufficient. In addition, our insurance may not provide sufficient coverage to compensate for related losses. Any of these events could damage our reputation and be expensive to remedy.
The Loss of Key Senior Management Personnel or the Failure to Hire and Retain Highly Skilled and Other Personnel Could Negatively Affect Our Business
We depend on our senior management and other key personnel, including our President and CEO. We do not have “key person” life insurance policies. We also rely on other highly skilled personnel. Competition for qualified personnel in the industries in which we operate, as well as senior management, has historically been intense. For example, we experience significant competition in the technology industry, particularly for software engineers, computer scientists, and other technical staff (including for artificial intelligence and machine learning technologies). In addition, changes we make to our current and future work environments may not meet the needs or expectations of our employees or may be perceived as less favorable compared to other companies’ policies, which could negatively impact our ability to hire and retain qualified personnel. The loss of any of our executive officers or other key employees, the failure to successfully transition key roles, or the inability to hire, train, retain, and manage qualified personnel, could harm our business.
We also rely on a significant number of personnel to operate our stores, fulfillment network, and data centers and carry out our other operations. Failure to successfully hire, train, manage, and retain sufficient personnel to meet our needs can strain our operations, increase payroll and other costs, and harm our business and reputation. In addition, changes in laws and regulations applicable to employees, independent contractors, and temporary personnel could increase our payroll costs, decrease our operational flexibility, and negatively impact how we are able to staff our operations and supplement our workforce.
We are also subject to labor union efforts to organize groups of our employees from time to time. These organizational efforts, if successful, decrease our operational flexibility, which could adversely affect our operating efficiency. In addition, our response to any organizational efforts could be perceived negatively and harm our business and reputation.
Our Supplier Relationships Subject Us to a Number of Risks
We have significant suppliers, including content and technology licensors, and in some cases, limited or single-sources of supply, that are important to our sourcing, services, manufacturing, and any related ongoing servicing of merchandise and content. We do not have long-term arrangements with most of our suppliers to guarantee availability of merchandise, content, components, or services, particular payment terms, or the extension of credit limits. Decisions by our current suppliers to limit or stop selling or licensing merchandise, content, components, or services to us on acceptable terms, or delay delivery, including as a result of one or more supplier bankruptcies due to poor economic conditions, natural or human-caused disasters (including public health crises), geopolitical events, labor and trade disputes, or for other reasons, may result in our being unable to procure alternatives from other suppliers in a timely and efficient manner and on acceptable terms, or at all. For example, we rely on a limited group of suppliers for semiconductor products, including products related to artificial intelligence infrastructure such as graphics processing units. Constraints on the availability of these products could adversely affect our ability to develop and operate artificial intelligence technologies, products, or services. In addition, violations by our suppliers or other vendors of applicable laws, regulations, contractual terms, intellectual property rights of others, or our Supply Chain Standards, as well as products or practices regarded as unethical, unsafe, or hazardous, could expose us to claims, damage our reputation, limit our growth, and negatively affect our operating results.
Our Commercial Agreements, Strategic Alliances, and Other Business Relationships Expose Us to Risks
We provide physical, e-commerce, and omnichannel retail, cloud services, and other services to businesses through commercial agreements, strategic alliances, and business relationships. Under these agreements, we provide web services, technology, fulfillment, computing, digital storage, and other services, as well as enable sellers to offer products or services through our stores. These arrangements are complex and require substantial infrastructure capacity, personnel, and other resource commitments, which may limit the amount of business we can service. We may not be able to implement, maintain, and develop the components of these commercial relationships, which may include web services, fulfillment, customer service, inventory management, tax collection, payment processing, hardware, content, and third-party software, and engaging third parties to perform services. The amount of compensation we receive under certain of our commercial agreements is partially
12
Table of Contents
dependent on the volume of the other company’s sales. Therefore, when the other company’s offerings are not successful, the compensation we receive may be lower than expected or the agreement may be terminated. Moreover, we may not be able to enter into additional or alternative commercial relationships and strategic alliances on favorable terms. We also may be subject to claims from businesses to which we provide these services if we are unsuccessful in implementing, maintaining, or developing these services.
As our agreements terminate, we may be unable to renew or replace these agreements on comparable terms, or at all. We may in the future enter into amendments on less favorable terms or encounter parties that have difficulty meeting their contractual obligations to us, which could adversely affect our operating results.
Our present and future commercial agreements, strategic alliances, and business relationships create additional risks such as:
•disruption of our ongoing business, including loss of management focus on existing businesses;
•impairment of other relationships;
•variability in revenue and income from entering into, amending, or terminating such agreements or relationships; and
•difficulty integrating under the commercial agreements.
Our Business Suffers When We Are Unsuccessful in Making, Integrating, and Maintaining Acquisitions and Investments
We have acquired and invested in a number of companies, and we may in the future acquire or invest in or enter into joint ventures with additional companies. These transactions involve risks such as:
•disruption of our ongoing business, including loss of management focus on existing businesses;
•problems retaining key personnel;
•additional operating losses and expenses of the businesses we acquired or in which we invested;
•the potential impairment of tangible and intangible assets and goodwill, including as a result of acquisitions;
•the potential impairment of customer and other relationships of the company we acquired or in which we invested or our own customers as a result of any integration of operations;
•the difficulty of completing such transactions, including obtaining regulatory approvals or satisfying other closing conditions, and achieving anticipated benefits within expected timeframes, or at all;
•the difficulty of incorporating acquired operations, technology, and rights into our offerings, and unanticipated expenses related to such integration;
•the difficulty of integrating a new company’s accounting, financial and sustainability reporting, management, information and data security, human resource, and other administrative systems to permit effective management, and the lack of control if such integration is delayed or not successfully implemented;
•losses we may incur as a result of declines in the value of an investment or as a result of incorporating an investee’s financial performance into our financial results;
•for investments in which an investee’s financial performance is incorporated into our financial results, either in full or in part, or investments for which we are required to file financial statements or provide financial information, the dependence on the investee’s accounting, financial and sustainability reporting, and similar systems, controls, and processes;
•the difficulty of implementing at companies we acquire the controls, procedures, and policies appropriate for a larger public company;
•the risks associated with businesses we acquire or invest in, which may differ from or be more significant than the risks our other businesses face;
•potential unknown liabilities associated with a company we acquire or in which we invest; and
•for foreign transactions, additional risks related to the integration of operations across different cultures and languages, and the economic, political, and regulatory risks associated with specific countries.
As a result of future acquisitions or mergers, we might need to issue additional equity securities, spend our cash, or incur debt, contingent liabilities, or amortization expenses related to intangible assets, any of which could reduce our profitability and harm our business or only be available on unfavorable terms, if at all. In addition, valuations supporting our acquisitions and strategic investments could change rapidly. We could determine that such valuations have experienced impairments or other-than-temporary declines in fair value which could adversely impact our financial results.
13
Table of Contents
We Face Significant Inventory Risk
In addition to risks described elsewhere in this Item 1A relating to fulfillment network and inventory optimization by us and third parties, we are exposed to significant inventory risks that may adversely affect our operating results as a result of seasonality, new product launches, rapid changes in product cycles and pricing (including as a result of tariff policy changes), defective merchandise, changes in customer demand and consumer spending patterns, changes in consumer tastes with respect to our products, spoilage, and other factors. We endeavor to accurately predict these trends and avoid overstocking or understocking products we manufacture and/or sell. Demand for products, however, can change significantly between the time inventory or components are ordered and the date of sale. In addition, when we begin selling or manufacturing a new product or offering a new service, it may be difficult to establish vendor relationships, determine appropriate product or component selection, and accurately forecast demand. The acquisition of certain types of inventory or components requires significant lead-time and prepayment and they may not be returnable. We carry a broad selection and significant inventory levels of certain products, such as consumer electronics, and at times we are unable to sell products in sufficient quantities or to meet demand during the relevant selling seasons. Any one of the inventory risk factors set forth above may adversely affect our operating results.
We Are Subject to Payments-Related Risks
We accept payments using a variety of methods, including credit card, debit card, credit accounts (including promotional financing), gift cards, direct debit from a customer’s bank account, consumer invoicing, checks, and payment upon delivery. For existing and future payment options we offer to our customers, we currently are subject to, and may become subject to additional, regulations and compliance requirements (including obligations to implement enhanced authentication processes that could result in significant costs and reduce the ease of use of our payments products), as well as fraud. For certain payment methods, including credit and debit cards, we pay interchange and other fees, which may increase over time and raise our operating costs and lower profitability. We rely on third parties to provide certain Amazon-branded payment methods and payment processing services, including the processing of credit cards, debit cards, electronic checks, and promotional financing. In each case, it could disrupt our business if these companies become unwilling or unable to provide these services to us. We also offer co-branded credit card programs, which could adversely affect our operating results if renewed on less favorable terms or terminated. We are also subject to payment card association operating rules, including data security rules, certification requirements, and rules governing electronic funds transfers, which could change or be reinterpreted to make it difficult or impossible for us to comply. Failure to comply with these rules or requirements, as well as any breach, compromise, or failure to otherwise detect or prevent fraudulent activity involving our data security systems, could result in our being liable for card issuing banks’ costs, subject to fines and higher transaction fees, and loss of our ability to accept credit and debit card payments from our customers, process electronic funds transfers, or facilitate other types of online payments, and our business and operating results could be adversely affected.
In addition, we provide regulated services in certain jurisdictions because we enable customers to keep account balances with us and transfer money to third parties, and because we provide services to third parties to facilitate payments on their behalf. Jurisdictions subject us to requirements for licensing, regulatory inspection, bonding and capital maintenance, the use, handling, and segregation of transferred funds, consumer disclosures, maintaining or processing data, and authentication. We are also subject to or voluntarily comply with a number of other laws and regulations relating to payments, money laundering, international money transfers, privacy, data use, data protection, data security, data localization, network security, consumer protection, and electronic fund transfers. If we were found to be in violation of applicable laws or regulations, we could be subject to additional requirements and civil and criminal penalties, or forced to cease providing certain services.
We Have a Rapidly Evolving Business Model and Our Stock Price Is Highly Volatile
We have a rapidly evolving business model. The trading price of our common stock fluctuates significantly in response to, among other risks, the risks described elsewhere in this Item 1A, as well as:
•changes in interest rates;
•conditions or trends in the internet, other technologies including artificial intelligence, and the industry segments we operate in;
•quarterly variations in operating results;
•fluctuations in the stock market in general and market prices for technology-related companies in particular;
•changes in financial estimates by us or decisions to increase or decrease future spending or investment levels;
•changes in financial estimates and recommendations by securities analysts;
•changes in our capital structure, including issuance of additional debt or equity to the public;
14
Table of Contents
•changes in the valuation methodology of, or performance by, other e-commerce or technology companies; and
•transactions in our common stock by major investors and certain analyst reports, news, social media activity, and speculation.
Volatility in our stock price could adversely affect our business and financing opportunities and force us to increase our cash compensation to employees or grant larger stock awards than we have historically, which could hurt our operating results or reduce the percentage ownership of our existing stockholders, or both.
Legal and Regulatory Risks
Government Regulation Is Evolving and Unfavorable Changes Could Harm Our Business
We are subject to general business regulations and laws, as well as regulations and laws specifically governing the internet, physical, e-commerce, and omnichannel retail, digital content, web services, electronic devices, advertising, artificial intelligence technologies and services, satellite communications services, healthcare, and other products and services that we offer or sell. These regulations and laws cover taxation, privacy, data use, data protection, data security, data localization, network security, consumer protection, pricing, content, copyrights, distribution, transportation, communications, electronic device certification, electronic waste, energy consumption, environmental and climate-related regulation, electronic contracts and other communications, competition, employment, trade and protectionist measures, web services, the provision of online payment services, registration, licensing, and information reporting requirements, insurance, unencumbered internet access to our services or access to our facilities, the design and operation of websites, health, safety, and sanitation standards, the characteristics, legality, and quality of products and services, product labeling, the commercial operation of unmanned aircraft systems, healthcare, and other matters. It is not clear how existing laws governing issues such as property ownership, libel, privacy, data use, data protection, data security, data localization, network security, and consumer protection apply to aspects of our operations such as the internet, e-commerce, digital content, web services, electronic devices, advertising, artificial intelligence technologies and services, satellite communications services, and healthcare. A large number of jurisdictions regulate our operations, and the extent, nature, and scope of such regulations is evolving and expanding as the scope of our businesses expand. We are regularly subject to formal and informal reviews, investigations, and other proceedings by governments and regulatory authorities under existing laws, regulations, or interpretations or pursuing new and novel approaches to regulate our operations. For example, we face a number of open investigations based on claims that aspects of our operations infringe competition-related or consumer protection rules or regulations, including aspects of Amazon’s operation of its stores, including its fulfillment network and Prime, and certain aspects of AWS’s offering of cloud services. We strongly dispute these claims and intend to defend ourselves vigorously in these investigations. Similarly, we face investigations under a growing patchwork of laws and regulations governing the collection, use, and disclosure of data, the interpretation of which continues to evolve, leading to uncertainty about how regulators will view our privacy practices. In addition, regulators and lawmakers are increasingly focused on controlling additional aspects of the operations of technology companies and companies they have characterized to be online “gatekeepers” through the application of existing regulations and laws and the adoption of new regulations and laws, which increases our compliance costs and limits the operation of our business. Unfavorable regulations, laws, decisions, or interpretations by government or regulatory authorities applying those laws and regulations, or inquiries, investigations, or enforcement actions threatened or initiated by them, could cause us to incur substantial costs, expose us to unanticipated civil and criminal liability or penalties (including substantial monetary fines), diminish the demand for, or availability of, our products and services, increase our cost of doing business, require us to change our business practices in a manner materially adverse to our business, damage our reputation, impede our growth, or otherwise have a material effect on our operations. The media, political, and regulatory scrutiny we face, which may continue to increase, amplifies these risks.
Claims, Litigation, Government Investigations, and Other Proceedings May Adversely Affect Our Business and Results of Operations
As an innovative company offering a wide range of consumer and business products and services around the world, we are regularly subject to actual and threatened claims, litigation, reviews, investigations, and other proceedings, including proceedings by governments and regulatory authorities, involving a wide range of issues, including patent and other intellectual property matters, taxes, labor and employment (including the characterization of delivery drivers), competition and antitrust, privacy, data use, data protection, data security, data localization, network security, consumer protection, commercial disputes, goods and services offered by us and by third parties (including artificial intelligence technologies and services), healthcare, and other matters. The number and scale of these proceedings have increased over time as our businesses have expanded in scope and geographic reach, as our products, services, and operations have become more complex and available to, and used by, more people, and as governments and regulatory authorities seek to regulate us on a pre-emptive basis. For example, we are litigating a number of matters alleging price fixing, monopolization, and consumer protection claims, including those brought by state attorneys general and the Federal Trade Commission. Any of these types of proceedings can have an adverse effect on us
15
Table of Contents
because of legal costs, disruption of our operations, diversion of management resources, negative publicity, and other factors. The outcomes of these matters are inherently unpredictable and subject to significant uncertainties. Determining legal reserves or possible losses from such matters involves judgment and may not reflect the full range of uncertainties and unpredictable outcomes. Until the final resolution of such matters, we may be exposed to losses in excess of the amount recorded, and such amounts could be material. Should any of our estimates and assumptions change or prove to have been incorrect, it could have a material effect on our business, consolidated financial position, results of operations, or cash flows. In addition, it is possible that a resolution of one or more such proceedings, including as a result of a settlement, could involve licenses, sanctions, consent decrees, or orders requiring us to make substantial future payments, preventing us from offering certain products or services, requiring us to change our business practices in a manner materially adverse to our business, requiring development of non-infringing or otherwise altered products or technologies, damaging our reputation, or otherwise having a material effect on our operations.
We Are Subject to Product Liability Claims When People or Property Are Harmed by the Products We Sell or Manufacture
Some of the products we sell or manufacture expose us to product liability or food safety claims relating to personal injury or illness, death, or environmental or property damage, and can require product recalls or other actions. Third parties who sell products using our services and stores also expose us to product liability claims. Additionally, under our A-to-z Guarantee, we may reimburse customers for certain product liability claims up to certain limits in these situations, and as our third-party seller sales grow, the cost of this program will increase and could negatively affect our operating results. Although we maintain liability insurance, we cannot be certain that our coverage will be adequate for liabilities actually incurred or that insurance will continue to be available to us on economically reasonable terms, or at all. Although we impose contractual terms on sellers that are intended to prohibit sales of certain type of products, we may not be able to detect, enforce, or collect sufficient damages for breaches of such agreements. In addition, some of our agreements with our vendors and sellers do not indemnify us from product liability.
We Face Additional Tax Liabilities and Collection Obligations
We are subject to a variety of taxes and tax collection obligations in the U.S. (federal and state) and numerous foreign jurisdictions. We may recognize additional tax expense and be subject to additional tax liabilities, including other liabilities for tax collection obligations due to changes in laws, regulations, administrative practices, principles, and interpretations related to tax, including changes to the global tax framework, competition, and other laws and accounting rules in various jurisdictions. Such changes could come about as a result of economic, political, and other conditions. An increasing number of jurisdictions are considering or have adopted laws or administrative practices that impose new tax measures, including revenue-based taxes, targeting online commerce and the remote selling of goods and services. These include new obligations to withhold or collect sales, consumption, value added, or other taxes on online marketplaces and remote sellers, or other requirements that may result in liability for third party obligations. For example, non-U.S. jurisdictions have proposed or enacted taxes on online advertising and marketplace service revenues. Proliferation of these or similar unilateral tax measures may continue unless broader international tax reform is implemented. In addition, the European Union and other countries (including those in which we operate) have enacted or may enact global minimum taxes, which may increase our tax expense.
Our results of operations and cash flows could be adversely affected by additional taxes imposed on us prospectively or retroactively or additional taxes or penalties resulting from the failure to comply with any collection obligations or failure to provide information about our customers, suppliers, and other third parties for tax reporting purposes to various government agencies. In some cases we also may not have sufficient notice to enable us to build systems and adopt processes to properly comply with new reporting or collection obligations by the effective date.
Our tax expense and liabilities are also affected by other factors, such as changes in our business operations, acquisitions, investments, entry into new businesses and geographies, intercompany transactions, the relative amount of our foreign earnings, losses incurred in jurisdictions for which we are not able to realize related tax benefits, the applicability of special or extraterritorial tax regimes, changes in foreign exchange rates, changes in our stock price, changes to our forecasts of income and loss and the mix of jurisdictions to which they relate, and changes in our tax assets and liabilities and their valuation. In the ordinary course of our business, there are many transactions and calculations for which the ultimate tax determination is uncertain. Significant judgment is required in evaluating and estimating our tax expense, assets, and liabilities.
We are also subject to tax controversies in various jurisdictions that can result in tax assessments against us. Developments in an audit, investigation, or other tax controversy can have a material effect on our operating results or cash flows in the period or periods for which that development occurs, as well as for prior and subsequent periods. Due to the inherent complexity and uncertainty of these matters, interpretations of certain tax laws by authorities, and judicial, administrative, and regulatory processes in certain jurisdictions, the final outcome of any such controversy may be materially different from our expectations. For example, the Indian tax authority has asserted that tax applies to cloud services fees paid to
16
Table of Contents
Amazon in the U.S. We are contesting this position; however, if this matter is adversely resolved, we may be required to pay additional amounts with respect to current and prior periods and our taxes in the future could increase. We regularly assess the likelihood of an adverse outcome resulting from these proceedings to determine the adequacy of our tax accruals. Although we believe our tax estimates are reasonable, the final outcome of audits, investigations, and any other tax controversies could be materially different from our historical tax accruals.
We Are Subject to Risks Related to Government Contracts and Related Procurement Regulations
Our contracts with U.S., as well as state, local, and foreign, government entities are subject to various procurement regulations and other requirements relating to their formation, administration, and performance. We are subject to audits and investigations relating to our government contracts, and any violations could result in various civil and criminal penalties and administrative sanctions, including termination of contract, refunding or suspending of payments, forfeiture of profits, payment of fines, and suspension or debarment from future government business. In addition, some of these contracts are subject to periodic funding approval and/or provide for termination by the government at any time, without cause.
Item 1B.	Unresolved Staff Comments
None.
Item 1C.	Cybersecurity
We have processes in place for assessing, identifying, and managing material risks from potential unauthorized occurrences on or through our electronic information systems that could adversely affect the confidentiality, integrity, or availability of our information systems or the information residing on those systems. These include a wide variety of mechanisms, controls, technologies, methods, systems, and other processes that are designed to prevent, detect, or mitigate data loss, theft, misuse, unauthorized access, or other security incidents or vulnerabilities affecting the data. The data include confidential, proprietary, and business and personal information that we collect, process, store, and transmit as part of our business, including on behalf of third parties. We also use systems and processes designed to reduce the impact of a security incident at a third-party vendor or customer. Additionally, we use processes to oversee and identify material risks from cybersecurity threats associated with our use of third-party technology and systems, including: artificial intelligence technologies; technology and systems we use for encryption and authentication; employee email and other communication technologies; content delivery to customers; back-office support; and other functions.
As part of our risk management process, we conduct application security assessments, vulnerability management, penetration testing, security audits, and ongoing risk assessments. We also maintain a variety of incident response plans that are utilized when incidents are detected. We require employees with access to information systems, including all corporate employees, to undertake data protection and cybersecurity training and compliance programs annually.
We have a unified and centrally-coordinated team, led by our chief security officer, that is responsible for implementing and maintaining centralized cybersecurity and data protection practices at Amazon in close coordination with senior leadership and other teams across Amazon. Reporting to our chief security officer are a number of experienced chief information security officers responsible for various parts of our business, including AWS, each of whom is supported by a team of trained cybersecurity professionals. In addition to our extensive in-house cybersecurity capabilities, at times we also engage assessors, consultants, auditors, or other third parties to assist with assessing, identifying, and managing cybersecurity risks.
Our cybersecurity risks and associated mitigations are evaluated by senior leadership, including as part of our enterprise risk assessments that are reviewed by the Audit Committee and our Board of Directors. Such risks and mitigations are also subject to oversight by the Security Committee of our Board of Directors. Additional information about cybersecurity risks we face is discussed in Item 1A of Part I, “Risk Factors,” under the heading “We Could Be Harmed by Data Loss or Other Security Incidents,” which should be read in conjunction with the information above.
The Security Committee, which is comprised of independent directors, oversees our policies and procedures for protecting our cybersecurity infrastructure and for compliance with applicable data protection and security regulations, and related risks. The Security Committee receives reports regarding such risks from management, including our chief security officer, and reports to the Board at least annually. The Security Committee also oversees the Board’s response to any significant cybersecurity incidents.
Our chief security officer, who has extensive cybersecurity knowledge and skills gained from over 15 years of work experience on the security team at Amazon and an extensive career in the technology and cybersecurity industries as a senior executive in the federal government, heads the team responsible for implementing and maintaining cybersecurity and data protection practices at Amazon and reports directly to the Chief Executive Officer.
17
Table of Contents
Item 2.	Properties
As of December 31, 2025, we operated the following facilities (in thousands):
Description of Use		Leased Square Footage (1)		Owned Square Footage		Location
Office space		31,028		9,160		North America
Office space		26,495		1,802		International
Physical stores (2)		23,932		706		North America
Physical stores (2)		148		—		International
Fulfillment, data centers, and other		474,128		45,803		North America
Fulfillment, data centers, and other		185,814		20,660		International
Total		741,545		78,131
___________________
(1)For leased properties, represents the total leased space excluding sub-leased space.
(2)This includes 615 North America and 8 International stores as of December 31, 2025.
Segment		Leased Square Footage (1)		Owned Square Footage (1)
North America		481,153		25,437
International		174,499		13,263
AWS		28,370		28,469
Total		684,022		67,169
___________________
(1)Segment amounts exclude corporate facilities. Shared facilities are allocated among the segments based on usage and primarily relate to facilities that hold our technology infrastructure. See Item 8 of Part II, “Financial Statements and Supplementary Data — Note 10 — Segment Information.”
We own and lease our corporate headquarters in Washington’s Puget Sound region and Arlington, Virginia.
Item 3.	Legal Proceedings
See Item 8 of Part II, “Financial Statements and Supplementary Data — Note 7 — Commitments and Contingencies — Legal Proceedings.”
Item 4.	Mine Safety Disclosures
Not applicable.
18
Table of Contents
PART II
Item 5.	Market for the Registrant’s Common Stock, Related Shareholder Matters, and Issuer Purchases of Equity Securities
Market Information
Our common stock is traded on the Nasdaq Global Select Market under the symbol “AMZN.”
Holders
As of January 28, 2026, there were 12,165 shareholders of record of our common stock, although there is a much larger number of beneficial owners.
Recent Sales of Unregistered Securities
None.
Issuer Purchases of Equity Securities
None.
Item 6.	Reserved
19
Table of Contents
Item 7.	Management’s Discussion and Analysis of Financial Condition and Results of Operations
Forward-Looking Statements
This Annual Report on Form 10-K includes forward-looking statements within the meaning of the Private Securities Litigation Reform Act of 1995. All statements other than statements of historical fact, including statements regarding guidance, industry prospects, or future results of operations or financial position, made in this Annual Report on Form 10-K are forward-looking. We use words such as anticipates, believes, expects, future, intends, and similar expressions to identify forward-looking statements. Forward-looking statements reflect management’s current expectations and are inherently uncertain. Actual results and outcomes could differ materially for a variety of reasons, including, among others, fluctuations in foreign exchange rates and energy prices, changes in global economic conditions, tariff and trade policies, resource and supply volatility, including for memory chips, and customer demand and spending, inflation, interest rates, regional labor market constraints, world events, the rate of growth of the internet, online commerce, cloud services, and new and emerging technologies, the amount that Amazon.com invests in new business opportunities and the timing of those investments, the mix of products and services sold to customers, the mix of net sales derived from products as compared with services, the extent to which we owe income or other taxes, competition, management of growth, potential fluctuations in operating results, international growth and expansion, the outcomes of claims, litigation, government investigations, and other proceedings, fulfillment, sortation, delivery, and data center optimization, risks of inventory management, variability in demand, the degree to which we enter into, maintain, and develop commercial agreements, proposed and completed acquisitions and strategic transactions, payments risks, and risks of fulfillment throughput and productivity. In addition, global economic and geopolitical conditions and additional or unforeseen circumstances, developments, or events may give rise to or amplify many of these risks. These risks and uncertainties, as well as other risks and uncertainties that could cause our actual results or outcomes to differ significantly from management’s expectations, are described in greater detail in Item 1A of Part I, “Risk Factors.”
Overview
Our primary source of revenue is the sale of a wide range of products and services to customers. The products offered through our stores include merchandise and content we have purchased for resale and products offered by third-party sellers, and we also manufacture and sell electronic devices and produce media content. Generally, we recognize gross revenue from items we sell from our inventory as product sales and recognize our net share of revenue of items sold by third-party sellers as service sales. We seek to increase unit sales across our stores, through increased product selection, across numerous product categories. We also offer other services such as compute, storage, and database offerings, fulfillment, advertising, publishing, and digital content subscriptions.
Our financial focus is on long-term, sustainable growth in free cash flow. Free cash flow is driven primarily by increasing operating income and efficiently managing accounts receivable, inventory, accounts payable, and cash capital expenditures, including our decision to purchase or lease property and equipment. Increases in operating income primarily result from increases in sales of products and services and efficiently managing our operating costs, partially offset by investments we make in longer-term strategic initiatives, including capital expenditures focused on improving the customer experience. To increase sales of products and services, we focus on improving all aspects of the customer experience, including lowering prices, improving availability, offering faster delivery and performance times, increasing selection, producing original content, increasing product categories and service offerings, expanding product information, improving ease of use, improving reliability, and earning customer trust. See “Results of Operations — Non-GAAP Financial Measures” below for additional information on our non-GAAP free cash flow measure.
We seek to reduce our variable costs per unit and work to leverage our fixed costs. Our variable costs include product and content costs, payment processing and related transaction costs, picking, packaging, and preparing orders for shipment, transportation, customer service support, costs necessary to run AWS, and a portion of our marketing costs. Our fixed costs include the costs necessary to build and run our technology infrastructure; to build, enhance, and add features to our online stores, web services, electronic devices, and digital offerings; and to build and optimize our fulfillment network. Variable costs generally change directly with sales volume, while fixed costs generally are dependent on the timing of capacity needs, geographic expansion, category expansion, and other factors. To decrease our variable costs on a per unit basis and enable us to lower prices for customers, we seek to increase our direct sourcing, increase discounts from suppliers, and reduce defects in our processes. To minimize unnecessary growth in fixed costs, we seek to improve process efficiencies and maintain a lean culture.
We seek to turn inventory quickly and collect from consumers before our payments to vendors and sellers become due. Because consumers primarily use credit cards in our stores, our receivables from consumers settle quickly. We expect variability in inventory turnover over time since it is affected by numerous factors, including our product mix, the mix of sales by us and by third-party sellers, our continuing focus on in-stock inventory availability and selection of product offerings, supply chain disruptions and resulting vendor lead times, our investment in new geographies and product lines, and the extent to which we choose to utilize third-party fulfillment providers. We also expect some variability in accounts payable days over
20
Table of Contents
time since they are affected by several factors, including the mix of product sales, the mix of sales by third-party sellers, the mix of suppliers, seasonality, and changes in payment and other terms over time, including the effect of balancing pricing and timing of payment terms with suppliers.
We expect spending in technology and infrastructure will increase over time, which can negatively impact short-term free cash flow, as we add infrastructure and employees, including to support our artificial intelligence and machine learning initiatives, to support long-term growth. Our technology and infrastructure investment and capital spending projects often support a variety of product and service offerings due to geographic expansion and the cross-functionality of our systems and operations. We seek to invest efficiently in several areas of technology and infrastructure, including AWS, and expansion of new and existing product categories and service offerings, as well as in infrastructure to enhance the customer experience and improve our process efficiencies. We believe that advances in technology, specifically the speed and reduced cost of processing power, data storage and analytics, improved wireless connectivity, and the practical applications of artificial intelligence and machine learning, will continue to improve users’ experience on the internet and increase its ubiquity in people’s lives. To best take advantage of these continued advances in technology, we are investing in AWS, which offers a broad set of on-demand technology services, including compute, storage, database, analytics, and machine learning, and other services to developers and enterprises of all sizes. We are also investing in initiatives to build and deploy innovative and efficient software and electronic devices as well as other initiatives including the development of a satellite network for global broadband service and autonomous vehicles for ride-hailing services.
We seek to efficiently manage shareholder dilution while maintaining the flexibility to issue shares for strategic purposes, such as financings, acquisitions, and aligning employee compensation with shareholders’ interests. We utilize restricted stock units as our primary vehicle for equity compensation because we believe this compensation model aligns the long-term interests of our shareholders and employees. In measuring shareholder dilution, we include all vested and unvested stock awards outstanding, without regard to estimated forfeitures. Total shares outstanding plus outstanding stock awards were 10.9 billion and 11.0 billion as of December 31, 2024 and 2025.
Our financial reporting currency is the U.S. Dollar and changes in foreign exchange rates significantly affect our reported results and consolidated trends. For example, if the U.S. Dollar weakens year-over-year relative to currencies in our international locations, our consolidated net sales and operating expenses will be higher than if currencies had remained constant. Likewise, if the U.S. Dollar strengthens year-over-year relative to currencies in our international locations, our consolidated net sales and operating expenses will be lower than if currencies had remained constant. We believe that our increasing diversification beyond the U.S. economy through our growing international businesses benefits our shareholders over the long-term. We also believe it is useful to evaluate our operating results and growth rates before and after the effect of currency changes.
In addition, the remeasurement of our intercompany balances can result in significant gains and losses associated with the effect of movements in foreign exchange rates. Currency volatilities may continue, which may significantly impact (either positively or negatively) our reported results and consolidated trends and comparisons.
For additional information about each line item addressed above, refer to Item 8 of Part II, “Financial Statements and Supplementary Data — Note 1 — Description of Business, Accounting Policies, and Supplemental Disclosures.”
Our Annual Report on Form 10-K for the year ended December 31, 2024 includes a discussion and analysis of our financial condition and results of operations for the year ended December 31, 2023 in Item 7 of Part II, “Management’s Discussion and Analysis of Financial Condition and Results of Operations.”
Critical Accounting Estimates
The preparation of financial statements in conformity with generally accepted accounting principles of the United States (“GAAP”) requires estimates and assumptions that affect the reported amounts of assets and liabilities, revenues and expenses, and related disclosures of contingent liabilities in the consolidated financial statements and accompanying notes. Critical accounting estimates are those estimates made in accordance with GAAP that involve a significant level of estimation uncertainty and have had or are reasonably likely to have a material impact on the financial condition or results of operations of the Company. Based on this definition, we have identified the critical accounting estimates addressed below. We also have other key accounting policies, which involve the use of estimates, judgments, and assumptions that are significant to understanding our results. For additional information, see Item 8 of Part II, “Financial Statements and Supplementary Data — Note 1 — Description of Business, Accounting Policies, and Supplemental Disclosures.” Although we believe that our estimates, assumptions, and judgments are reasonable, they are based upon information presently available. Actual results may differ significantly from these estimates under different assumptions, judgments, or conditions.
21
Table of Contents
Inventories
Inventories, consisting of products available for sale, are primarily accounted for using the first-in first-out method, and are valued at the lower of cost and net realizable value. This valuation requires us to make judgments, based on currently available information, about the likely method of disposition, such as through sales to individual customers, returns to product vendors, or liquidations, and expected recoverable values of each disposition category. These assumptions about future disposition of inventory are inherently uncertain and changes in our estimates and assumptions may cause us to realize material write-downs in the future. As a measure of sensitivity, for every 1% of additional inventory valuation allowance as of December 31, 2025, we would have recorded an additional cost of sales of approximately $405 million.
In addition, we enter into supplier commitments for certain electronic device components and certain products. These commitments are based on forecasted customer demand. If we reduce these commitments, we may incur additional costs.
Income Taxes
We are subject to income taxes in the U.S. (federal and state) and numerous foreign jurisdictions. Tax laws, regulations, administrative practices, principles, and interpretations in various jurisdictions may be subject to significant change, with or without notice, due to economic, political, and other conditions, and significant judgment is required in evaluating and estimating our provision and accruals for these taxes. There are many transactions that occur during the ordinary course of business for which the ultimate tax determination is uncertain. In addition, our actual and forecasted earnings are subject to change due to economic, political, and other conditions and significant judgment is required in determining our ability to use our deferred tax assets.
Our effective tax rates could be affected by numerous factors, such as changes in our business operations, acquisitions, investments, entry into new businesses and geographies, intercompany transactions, the relative amount of our foreign earnings, including earnings being lower than anticipated in jurisdictions where we have lower statutory rates and higher than anticipated in jurisdictions where we have higher statutory rates, losses incurred in jurisdictions for which we are not able to realize related tax benefits, the applicability of special tax regimes, changes in foreign exchange rates, changes in our stock price, changes to our forecasts of income and loss and the mix of jurisdictions to which they relate, changes in our deferred tax assets and liabilities and their valuation, changes in the laws, regulations, administrative practices, principles, and interpretations related to tax, including changes to the global tax framework, competition, and other laws and accounting rules in various jurisdictions. In addition, a number of countries have enacted or are actively pursuing changes to their tax laws applicable to corporate multinationals.
We are also currently subject to tax controversies in various jurisdictions, and these jurisdictions may assess additional income tax liabilities against us. Developments in an audit, investigation, or other tax controversy could have a material effect on our operating results or cash flows in the period or periods for which that development occurs, as well as for prior and subsequent periods. We regularly assess the likelihood of an adverse outcome resulting from these proceedings to determine the adequacy of our tax accruals. Although we believe our tax estimates are reasonable, the final outcome of audits, investigations, and any other tax controversies could be materially different from our historical income tax provisions and accruals.
Liquidity and Capital Resources
Cash flow information is as follows (in millions):
Year Ended December 31,
2024		2025
Cash provided by (used in):
Operating activities	$	115,877 			$	139,514
Investing activities	(94,342)			(142,545)
Financing activities	(11,812)			9,661
Our principal sources of liquidity are cash flows generated from operations and our cash, cash equivalents, and marketable securities balances, which, at fair value, were $101.2 billion and $123.0 billion as of December 31, 2024 and 2025. Amounts held in foreign currencies were $25.5 billion and $29.7 billion as of December 31, 2024 and 2025. Our foreign currency balances include British Pounds, Canadian Dollars, Euros, Indian Rupees, and Japanese Yen.
Cash provided by (used in) operating activities was $115.9 billion and $139.5 billion in 2024 and 2025. Our operating cash flows result primarily from cash received from our consumer, seller, developer, enterprise, and content creator customers, and advertisers, offset by cash payments we make for products and services, employee compensation, payment processing and related transaction costs, operating leases, and interest payments. Cash received from our customers and other activities generally corresponds to our net sales. The increase in operating cash flow in 2025, compared to the prior year, was due to an increase in net income (loss), excluding non-cash expenses, and changes in working capital. Working capital at any specific
22
Table of Contents
point in time is subject to many variables, including variability in demand, inventory management and category expansion, the timing of cash receipts and payments, customer and vendor payment terms, and fluctuations in foreign exchange rates.
Cash provided by (used in) investing activities corresponds with cash capital expenditures, including leasehold improvements, incentives received from property and equipment vendors, proceeds from asset sales, cash outlays for acquisitions, investments in other companies and intellectual property rights, and purchases, sales, and maturities of marketable securities. Cash provided by (used in) investing activities was $(94.3) billion and $(142.5) billion in 2024 and 2025, with the variability caused primarily by purchases, sales, and maturities of marketable securities and cash capital expenditures. Cash capital expenditures were $77.7 billion, and $128.3 billion in 2024 and 2025, which primarily reflect investments in technology infrastructure (the majority of which is to support AWS business growth) and in additional capacity to support our fulfillment network, both of which we expect to increase in 2026. We made cash payments, net of acquired cash, related to acquisition and other investment activity of $7.1 billion and $3.8 billion in 2024 and 2025, which primarily reflect investments in convertible notes from Anthropic, PBC (“Anthropic”), including $2.7 billion we invested in 2025.
Cash provided by (used in) financing activities was $(11.8) billion and $9.7 billion in 2024 and 2025. Cash inflows from financing activities resulted from proceeds from short-term debt, and other and long-term-debt of $5.1 billion and $25.0 billion in 2024 and 2025. Cash outflows from financing activities resulted from payments of short-term debt, and other, long-term debt, finance leases, and financing obligations of $17.0 billion and $15.3 billion in 2024 and 2025. Property and equipment acquired under finance leases was $854 million and $2.9 billion in 2024 and 2025.
We had no borrowings outstanding under the two unsecured revolving credit facilities or the commercial paper programs as of December 31, 2025. See Item 8 of Part II, “Financial Statements and Supplementary Data — Note 6 — Debt” for additional information.
As of December 31, 2025, cash, cash equivalents, and marketable securities held by foreign subsidiaries were $7.1 billion. We intend to invest substantially all of our foreign subsidiary earnings, as well as our capital in our foreign subsidiaries, indefinitely outside of the U.S. in those jurisdictions in which we would incur significant, additional costs upon repatriation of such amounts.
Our U.S. taxable income is reduced by accelerated depreciation deductions and the resulting U.S. tax liability is reduced by tax credits, primarily related to the U.S. federal research and development credit. The One Big Beautiful Bill Act of 2025 (the “2025 Tax Act”) made changes to the U.S. corporate income tax, including reinstating the option to claim 100% accelerated depreciation deductions on qualified property, with retroactive application beginning January 20, 2025 and immediate expensing of domestic research and development costs, with retroactive application beginning January 1, 2025. The 2025 Tax Act significantly decreased our cash taxes in 2025. Cash paid for U.S. (federal and state) and foreign income taxes (net of refunds) totaled $12.3 billion and $8.3 billion for 2024 and 2025. We expect the 2025 Tax Act to have a similar effect on our cash taxes in 2026. See Item 8 of Part II, “Financial Statements and Supplementary Data — Note 9 — Income Taxes” for additional cash taxes paid information.
As of December 31, 2024 and 2025, restricted cash, cash equivalents, and marketable securities were $3.5 billion and $3.3 billion. See Item 8 of Part II, “Financial Statements and Supplementary Data — Note 6 — Debt” and “Financial Statements and Supplementary Data — Note 7 — Commitments and Contingencies” for additional discussion of our principal contractual commitments, as well as our pledged assets. Additionally, we have purchase obligations and open purchase orders, including for inventory and capital expenditures, that support normal operations and are primarily due in the next twelve months. These purchase obligations and open purchase orders are generally cancellable in full or in part through the contractual provisions.
We believe that cash flows generated from operations and our cash, cash equivalents, and marketable securities balances, as well as our borrowing arrangements, will be sufficient to meet our anticipated operating cash needs for at least the next twelve months. However, any projections of future cash needs and cash flows are subject to substantial uncertainty. See Item 1A of Part I, “Risk Factors.” We continually evaluate opportunities to sell additional equity or debt securities, obtain credit facilities, obtain finance and operating lease arrangements, enter into financing obligations, repurchase common stock, pay dividends, repurchase, refinance, or otherwise restructure our debt, or access capital through other financing arrangements for strategic reasons or to further strengthen our financial position.
The sale of additional equity or convertible debt securities would be dilutive to our shareholders. In addition, we will, from time to time, consider the acquisition of, or investment in, complementary businesses, products, services, capital infrastructure, and technologies, which might affect our liquidity requirements or cause us to secure additional financing, or issue additional equity or debt securities. There can be no assurance that additional credit lines or financing instruments will be available in amounts or on terms acceptable to us, if at all. In addition, economic conditions and actions by policymaking bodies are contributing to changing interest rates and significant capital market volatility, which, along with any increases in our borrowing levels, could increase our future borrowing costs.
23
Table of Contents
Results of Operations
We have organized our operations into three segments: North America, International, and AWS. These segments reflect the way the Company evaluates its business performance and manages its operations. See Item 8 of Part II, “Financial Statements and Supplementary Data — Note 10 — Segment Information.”
Overview
Macroeconomic factors, including changes in inflation and interest rates, resource and supply volatility, global economic and geopolitical developments, including unpredictable shifts in global tariff and trade policies, and the development and adoption of technologies and services, including artificial intelligence, have direct and indirect impacts on our results of operations that are difficult to predict, isolate, and quantify. These could affect customer demand for our products and services, our ability to forecast growth needs, expenses, and benefits from new technologies. Further, we expect to continue making additional investments in our artificial intelligence initiatives. We expect some or all of these factors to continue to impact our results of operations into Q1 2026.
Net Sales
Net sales include product and service sales. Product sales represent revenue from the sale of products and related shipping fees and digital media content where we record revenue gross. Service sales primarily represent third-party seller fees, which includes commissions and any related fulfillment and shipping fees, AWS sales, advertising services, Amazon Prime membership fees, and certain digital media content subscriptions. Net sales information is as follows (in millions):
Year Ended December 31,
2024		2025
Net Sales:
North America	$	387,497 			$	426,305
International	142,906 			161,894
AWS	107,556 			128,725
Consolidated	$	637,959 			$	716,924
Year-over-year Percentage Growth:
North America	10 	%		10 	%
International	9 			13
AWS	19 			20
Consolidated	11 			12
Year-over-year Percentage Growth, excluding the effect of foreign exchange rates:
North America	10 	%		10 	%
International	10 			10
AWS	19 			20
Consolidated	11 			12
Net Sales Mix:
North America	61 	%		59 	%
International	22 			23
AWS	17 			18
Consolidated	100 	%		100 	%
Sales increased 12% in 2025, compared to the prior year. Changes in foreign exchange rates increased net sales by $4.4 billion in 2025. For a discussion of the effect of foreign exchange rates on sales growth, see “Effect of Foreign Exchange Rates” below.
North America sales increased 10% in 2025, compared to the prior year. The sales growth primarily reflects increased unit sales, including sales by third-party sellers, advertising sales, and subscription services. Increased unit sales were driven largely by our continued focus on price, selection, and convenience for our customers, including from our fast shipping offers. Changes in foreign exchange rates reduced North America net sales by $454 million in 2025.
International sales increased 13% in 2025, compared to the prior year. The sales growth primarily reflects increased unit sales, including sales by third-party sellers, advertising sales, and subscription services. Increased unit sales were driven largely
24
Table of Contents
by our continued focus on price, selection, and convenience for our customers, including from our fast shipping offers. Changes in foreign exchange rates increased International net sales by $4.9 billion in 2025.
AWS sales increased 20% in 2025, compared to the prior year. The sales growth primarily reflects increased customer usage, partially offset by pricing changes primarily driven by long-term customer contracts.
Operating Expenses
Information about operating expenses is as follows (in millions):
Year Ended December 31,
2024		2025
Operating Expenses:
Cost of sales	$	326,288 			$	356,414
Fulfillment	98,505 			109,074
Technology and infrastructure	88,544 			108,521
Sales and marketing	43,907 			47,129
General and administrative	11,359 			11,172
Other operating expense (income), net	763 			4,639
Total operating expenses	$	569,366 			$	636,949
Year-over-year Percentage Growth (Decline):
Cost of sales	7 	%		9 	%
Fulfillment	9 			11
Technology and infrastructure	3 			23
Sales and marketing	(1)			7
General and administrative	(4)			(2)
Other operating expense (income), net	(1)			508
Percent of Net Sales:
Cost of sales	51.1 	%		49.7 	%
Fulfillment	15.4 			15.2
Technology and infrastructure	13.9 			15.1
Sales and marketing	6.9 			6.6
General and administrative	1.8 			1.6
Other operating expense (income), net	0.1 			0.6
Cost of Sales
Cost of sales primarily consists of the purchase price of consumer products, inbound and outbound shipping costs, including costs related to sortation and delivery centers and where we are the transportation service provider, and digital media content costs where we record revenue gross, including video and music.
The increase in cost of sales in 2025, compared to the prior year, is primarily due to increased product and shipping costs resulting from increased sales, partially offset by operational efficiencies. Changes in foreign exchange rates increased cost of sales by $2.8 billion in 2025.
Shipping costs were $95.8 billion and $102.7 billion in 2024 and 2025. Shipping costs to receive products from our suppliers are included in our inventory and recognized as cost of sales upon sale of products to our customers. We expect our cost of shipping to continue to increase to the extent our customers accept and use our shipping offers at an increasing rate, we use more expensive shipping methods, and we offer additional services. We seek to mitigate costs of shipping over time in part through achieving higher sales volumes, optimizing our fulfillment network, negotiating better terms with our suppliers, and achieving better operating efficiencies. We believe that offering low prices to our customers is fundamental to our future success, and one way we offer lower prices is through shipping offers.
Costs to operate our AWS segment are primarily classified as “Technology and infrastructure” as we leverage a shared infrastructure that supports both our internal technology requirements and external sales to AWS customers.
25
Table of Contents
Fulfillment
Fulfillment costs primarily consist of those costs incurred in operating and staffing our North America and International fulfillment centers, physical stores, and customer service centers and payment processing costs. While AWS payment processing and related transaction costs are included in “Fulfillment,” AWS costs are primarily classified as “Technology and infrastructure.” Fulfillment costs as a percentage of net sales may vary due to several factors, such as payment processing and related transaction costs, our level of productivity and accuracy, changes in volume, size, and weight of units received and fulfilled, the extent to which third-party sellers utilize Fulfillment by Amazon services, timing of fulfillment network and physical store expansion, the extent we utilize fulfillment services provided by third parties, mix of products and services sold, and our ability to affect customer service contacts per unit by implementing improvements in our operations and enhancements to our customer self-service features. Additionally, sales by our sellers have higher payment processing and related transaction costs as a percentage of net sales compared to our retail sales because payment processing costs are based on the gross purchase price of underlying transactions.
The increase in fulfillment costs in 2025, compared to the prior year, is primarily due to increased sales and investments in our fulfillment network, partially offset by operational efficiencies. Changes in foreign exchange rates increased fulfillment costs by $609 million in 2025.
We seek to expand our fulfillment network to accommodate a greater selection and in-stock inventory levels and to meet anticipated shipment volumes from sales of our own products as well as sales by third parties for which we provide the fulfillment services. We regularly evaluate our facility requirements.
Technology and Infrastructure
Technology and infrastructure costs include payroll and related expenses for employees involved in the research and development of new and existing products and services, development, design, and maintenance of our stores, curation and display of products and services made available in our online stores, and infrastructure costs. Infrastructure costs include servers, networking equipment, and data center related depreciation and amortization, rent, utilities, and other expenses necessary to support AWS and other Amazon businesses. Collectively, these costs reflect the investments we make in order to offer a wide variety of products and services to our customers, including expenditures related to initiatives to build and deploy innovative and efficient software and electronic devices and the development of a satellite network for global broadband service and autonomous vehicles for ride-hailing services.
We seek to invest efficiently in numerous areas of technology and infrastructure so we may continue to enhance the customer experience and improve our process efficiency through rapid technology developments, while operating at an ever increasing scale. Our technology and infrastructure investment and capital spending projects often support a variety of product and service offerings due to geographic expansion and the cross-functionality of our systems and operations. We expect spending in technology and infrastructure to increase over time as we continue to add infrastructure and employees, including to support our artificial intelligence and machine learning initiatives. These costs are allocated to segments based on usage. The increase in technology and infrastructure costs in 2025, compared to the prior year, is primarily due to an increase in spending on infrastructure, including depreciation and amortization. Changes in foreign exchange rates increased technology and infrastructure costs by $312 million in 2025. We currently expense the majority of the costs associated with the development of our satellite network for global broadband service (including production, launch, and payroll costs, and launch services deposits upon launch). We will capitalize certain of these costs once the service achieves commercial viability, including sales to customers.
Sales and Marketing
Sales and marketing costs include advertising and payroll and related expenses for personnel engaged in marketing and selling activities, including sales commissions related to AWS. We direct customers to our stores primarily through a number of marketing channels, such as our sponsored search, third-party customer referrals, social and online advertising, television advertising, and other initiatives. Our marketing costs are largely variable, based on growth in sales and changes in rates. To the extent there is increased or decreased competition for these traffic sources, or to the extent our mix of these channels shifts, we would expect to see a corresponding change in our marketing costs.
The increase in sales and marketing costs in 2025, compared to the prior year, is primarily due to increased third-party advertising expenses. Changes in foreign exchange rates increased sales and marketing costs by $283 million in 2025.
While costs associated with Amazon Prime membership benefits and other shipping offers are not included in sales and marketing expense, we view these offers as effective worldwide marketing tools, and intend to continue offering them indefinitely.
26
Table of Contents
General and Administrative
General and administrative costs in 2025 did not significantly change compared to the prior year.
Other Operating Expense (Income), Net
Other operating expense (income), net was $763 million and $4.6 billion during 2024 and 2025. The increase in 2025 was primarily related to the settlement of a lawsuit with the Federal Trade Commission (the “FTC”) in Q3 2025, and also included the resolution of tax disputes associated with our stores business in Italy, and physical stores and other asset impairments.
Operating Income
Operating income by segment is as follows (in millions):
Year Ended December 31,
2024		2025
Operating Income
North America	$	24,967 			$	29,619
International	3,792 			4,750
AWS	39,834 			45,606
Consolidated	$	68,593 			$	79,975
Operating income was $68.6 billion and $80.0 billion for 2024 and 2025. Operating income for 2025 includes charges of $2.5 billion we recorded in Q3 2025 related to the settlement of a lawsuit with the FTC and $2.7 billion, of which $1.8 billion was recorded in Q3 2025, of estimated severance costs primarily related to planned role eliminations. We believe that operating income is a more meaningful measure than gross profit and gross margin due to the diversity of our product categories and services. For more information on the operating expenses that impact segment operating income, see “Operating Expenses” and the descriptions of operating expense line item changes on pages 25 to 27, and “Note 10 — Segment Information” on page 67.
The increase in North America operating income in 2025, compared to the prior year, is primarily due to increased unit sales and increased advertising sales, partially offset by increased fulfillment, technology and infrastructure, shipping, and other operating costs. Changes in foreign exchange rates negatively impacted operating income by $204 million in 2025.
The increase in International operating income in 2025, compared to the prior year, is primarily due to increased unit sales and increased advertising sales, partially offset by increased fulfillment and shipping costs. Changes in foreign exchange rates positively impacted operating income by $903 million in 2025.
The increase in AWS operating income in 2025, compared to the prior year, is primarily due to increased sales, partially offset by spending on technology infrastructure that was primarily driven by additional investments to support AWS business growth. Changes in foreign exchange rates negatively impacted operating income by $341 million in 2025.
Interest Income and Expense
Our interest income was $4.7 billion and $4.4 billion during 2024 and 2025, primarily due to a decrease in prevailing rates, offset by a higher average balance of invested funds. We generally invest our excess cash in investment grade short- to intermediate-term marketable debt securities and AAA-rated money market funds. Our interest income corresponds with the average balance of invested funds based on the prevailing rates, which vary depending on the geographies and currencies in which they are invested.
Interest expense was $2.4 billion and $2.3 billion in 2024 and 2025 and was primarily related to debt and finance leases. See Item 8 of Part II, “Financial Statements and Supplementary Data — Note 4 — Leases and Note 6 — Debt” for additional information.
Our long-term lease liabilities were $78.3 billion and $87.3 billion as of December 31, 2024 and 2025. Our long-term debt was $52.6 billion and $65.6 billion as of December 31, 2024 and 2025. See Item 8 of Part II, “Financial Statements and Supplementary Data — Note 4 — Leases and Note 6 — Debt” for additional information.
Other Income (Expense), Net
Other income (expense), net was $(2.3) billion and $15.2 billion during 2024 and 2025. The primary components of other income (expense), net are related to equity securities valuations and adjustments, equity warrant valuations, foreign currency, and reclassification adjustments for gains (losses) on available-for-sale debt securities. The net loss of $(2.3) billion in 2024 is primarily from the marketable securities loss from our equity investment in Rivian Automotive, Inc. (“Rivian”). The net gain of $15.2 billion in 2025 is primarily from an upward adjustment for observable changes in price relating to our nonvoting
27
Table of Contents
preferred stock in Anthropic, and the reclassification adjustments for the gains on available-for-sale debt securities from the portions of our convertible notes investments in Anthropic that were converted to nonvoting preferred stock during 2025.
Income Taxes
Our effective tax rate is subject to significant variation due to several factors, including variability in our pre-tax and taxable income and loss and the mix of jurisdictions to which they relate, intercompany transactions, the applicability of special tax regimes, changes in how we do business, acquisitions, investments, developments in tax controversies, changes in our stock price, changes in our deferred tax assets and liabilities and their valuation, foreign currency gains (losses), changes in statutes, regulations, case law, and administrative practices, principles, and interpretations related to tax, including changes to the global tax framework, competition, and other laws and accounting rules in various jurisdictions, and relative changes of expenses or losses for which tax benefits are not recognized. Our effective tax rate can be more or less volatile based on the amount of pre-tax income or loss. For example, the impact of discrete items and non-deductible expenses on our effective tax rate is greater when our pre-tax income is lower. In addition, we record valuation allowances against deferred tax assets when there is uncertainty about our ability to generate future income in relevant jurisdictions.
We recorded a provision for income taxes of $9.3 billion and $19.1 billion in 2024 and 2025. See Item 8 of Part II, “Financial Statements and Supplementary Data — Note 9 — Income Taxes” for additional information.
Equity-Method Investment Activity, Net of Tax
Equity-method investment activity, net of tax was $(101) million and $(554) million during 2024 and 2025. The primary components of equity-method investment activity, net of tax are related to our share of the earnings or losses as reported by equity-method investees, amortization of basis differences, related gains or losses, and impairments. The net loss of $(554) million in 2025 is primarily from impairments.
Non-GAAP Financial Measures
Regulation G, Conditions for Use of Non-GAAP Financial Measures, and other SEC regulations define and prescribe the conditions for use of certain non-GAAP financial information. Free cash flow and the effect of foreign exchange rates on our consolidated statements of operations meet the definition of non-GAAP financial measures.
Free Cash Flow
Our financial focus is on long-term, sustainable growth in free cash flow. We provide a free cash flow measure because we believe it provides additional perspective on the impact of acquiring property and equipment with cash. Free cash flow is cash flow from operations reduced by “Purchases of property and equipment, net of proceeds from sales and incentives.” The following is a reconciliation of free cash flow to the most comparable GAAP cash flow measure, “Net cash provided by (used in) operating activities,” for 2024 and 2025 (in millions):
Year Ended December 31,
2024		2025
Net cash provided by (used in) operating activities	$	115,877 			$	139,514
Purchases of property and equipment, net of proceeds from sales and incentives	(77,658)			(128,320)
Free cash flow	$	38,219 			$	11,194
Net cash provided by (used in) investing activities	$	(94,342)			$	(142,545)
Net cash provided by (used in) financing activities	$	(11,812)			$	9,661
Free cash flow has limitations as it omits certain components of the overall cash flow statement and does not represent the residual cash flow available for discretionary expenditures. For example, free cash flow does not incorporate the portion of payments representing principal reductions of debt or cash payments for business acquisitions. Additionally, our mix of property and equipment acquisitions with cash or other financing options may change over time. Therefore, we believe it is important to view free cash flow only as a complement to our entire consolidated statements of cash flows.
28
Table of Contents
Effect of Foreign Exchange Rates
Information regarding the effect of foreign exchange rates, versus the U.S. Dollar, on our net sales, operating expenses, and operating income is provided to show reported period operating results had the foreign exchange rates remained the same as those in effect in the comparable prior year period. The effect on our net sales, operating expenses, and operating income from changes in our foreign exchange rates versus the U.S. Dollar is as follows (in millions):
Year Ended December 31, 2024		Year Ended December 31, 2025
As
Reported		Exchange
Rate
Effect (1)		At Prior
Year
Rates (2)		As
Reported		Exchange
Rate
Effect (1)		At Prior
Year
Rates (2)
Net sales	$	637,959 			$	2,335 			$	640,294 			$	716,924 			$	(4,409)			$	712,515
Operating expenses	569,366 			2,466 			571,832 			636,949 			(4,051)			632,898
Operating income	68,593 			(131)			68,462 			79,975 			(358)			79,617
___________________
(1)Represents the change in reported amounts resulting from changes in foreign exchange rates from those in effect in the comparable prior year period for operating results.
(2)Represents the outcome that would have resulted had foreign exchange rates in the reported period been the same as those in effect in the comparable prior year period for operating results.
29
Table of Contents
Guidance
We provided guidance on February 5, 2026, in our earnings release furnished on Form 8-K as set forth below. These forward-looking statements reflect Amazon.com’s expectations as of February 5, 2026, and are subject to substantial uncertainty. Our results are inherently unpredictable and may be materially affected by many factors, such as fluctuations in foreign exchange rates and energy prices, changes in global economic and geopolitical conditions, tariff and trade policies, resource and supply volatility, including for memory chips, and customer demand and spending (including the impact of recessionary fears), inflation, interest rates, regional labor market constraints, world events, the rate of growth of the internet, online commerce, cloud services, and new and emerging technologies, as well as those outlined in Item 1A of Part I, “Risk Factors.”
First Quarter 2026 Guidance
•Net sales are expected to be between $173.5 billion and $178.5 billion, or to grow between 11% and 15% compared with first quarter 2025. This guidance anticipates a favorable impact of approximately 180 basis points from foreign exchange rates.
•Operating income is expected to be between $16.5 billion and $21.5 billion, compared with $18.4 billion in first quarter 2025. This guidance includes approximately $1 billion of higher year-over-year Amazon Leo costs as we scale in 2026, as well as investment in quick commerce and even sharper prices in our international stores business.
•This guidance assumes, among other things, that no additional business acquisitions, restructurings, or legal settlements are concluded.
30
Table of Contents
Item 7A.	Quantitative and Qualitative Disclosures About Market Risk
We are exposed to market risk for the effect of interest rate changes, foreign currency fluctuations, and changes in the market values of our investments. Information relating to quantitative and qualitative disclosures about market risk is set forth below and in Item 7 of Part II, “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Liquidity and Capital Resources.”
Interest Rate Risk
Our exposure to market risk for changes in interest rates relates primarily to our investment portfolio and our debt. Our long-term debt is carried at amortized cost and fluctuations in interest rates do not impact our consolidated financial statements. However, the fair value of our long-term debt, which pays interest at a fixed rate, will generally fluctuate with movements of interest rates, increasing in periods of declining rates of interest and declining in periods of increasing rates of interest.
We generally invest our excess cash in investment grade short- to intermediate-term marketable debt securities and AAA-rated money market funds. Marketable debt securities with fixed interest rates may have their fair market value adversely affected due to a rise in interest rates, and we may suffer losses in principal if forced to sell securities that have declined in market value due to changes in interest rates. The following table provides information about our cash equivalents and marketable debt securities, including principal cash flows by expected maturity and the related weighted-average interest rates as of December 31, 2025 (in millions, except percentages):
2026		2027		2028		2029		2030		Thereafter		Total		Estimated Fair Value as of December 31, 2025
Money market funds		$	29,046 			$	— 			$	— 			$	— 			$	— 			$	— 			$	29,046 			$	29,777
Weighted average interest rate		3.73 	%		— 	%		— 	%		— 	%		— 	%		— 	%		3.73 	%
Corporate debt securities		63,890 			2,867 			2,008 			391 			— 			423 			69,579 			69,585
Weighted average interest rate		3.98 	%		4.54 	%		4.54 	%		4.63 	%		— 	%		4.61 	%		4.03 	%
U.S. government and agency securities		4,057 			617 			311 			45 			173 			19 			5,222 			5,222
Weighted average interest rate		3.68 	%		3.94 	%		3.27 	%		3.21 	%		2.20 	%		1.43 	%		3.62 	%
Asset-backed securities		245 			331 			370 			404 			253 			177 			1,780 			1,780
Weighted average interest rate		4.52 	%		4.62 	%		4.24 	%		4.38 	%		3.81 	%		4.40 	%		4.33 	%
Other financial instruments		109 			7 			9 			— 			— 			4 			129 			129
Weighted average interest rate		3.90 	%		4.42 	%		4.32 	%		— 	%		— 	%		4.19 	%		3.96 	%
$	97,347 			$	3,822 			$	2,698 			$	840 			$	426 			$	623 			$	105,756
Cash equivalents and marketable debt securities																$	106,493
As of December 31, 2025, we had long-term debt with a face value of $68.8 billion, including the current portion, primarily consisting of fixed rate unsecured senior notes. See Item 8 of Part II, “Financial Statements and Supplementary Data — Note 6 — Debt” for additional information.
31
Table of Contents
Foreign Exchange Risk
During 2025, net sales from our International segment accounted for 23% of our consolidated revenues. Net sales and related expenses generated from our internationally-focused stores, including within Canada and Mexico (which are included in our North America segment), are primarily denominated in the functional currencies of the corresponding stores and primarily include Euros, British Pounds, and Japanese Yen. The results of operations of, and certain of our intercompany balances associated with, our internationally-focused stores and AWS are exposed to foreign exchange rate fluctuations. Upon consolidation, as foreign exchange rates vary, net sales and other operating results may differ materially from expectations, and we may record significant gains or losses on the remeasurement of intercompany balances. For example, as a result of fluctuations in foreign exchange rates throughout the year compared to rates in effect the prior year, International segment net sales increased by $4.9 billion in comparison with the prior year.
We have foreign exchange risk related to foreign-denominated cash, cash equivalents, and marketable securities (“foreign funds”). Based on the balance of foreign funds as of December 31, 2025, of $29.7 billion, an assumed 5%, 10%, and 20% adverse change to foreign exchange would result in declines of $1.5 billion, $3.0 billion, and $5.9 billion.
We also have foreign exchange risk related to our intercompany balances denominated in various currencies. Based on the intercompany balances as of December 31, 2025, an assumed 5%, 10%, and 20% adverse change to foreign exchange rates would result in losses of $600 million, $1.2 billion, and $2.4 billion, recorded to “Other income (expense), net.”
See Item 7 of Part II, “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Results of Operations — Effect of Foreign Exchange Rates” for additional information on the effect on reported results of changes in foreign exchange rates.
Equity Investment Risk
As of December 31, 2025, our recorded value in equity, equity warrant, and convertible debt investments in public and private companies was $69.1 billion. Our equity and equity warrant investments in publicly traded companies, which include our equity investment in Rivian, represent $5.0 billion of our investments as of December 31, 2025, and are recorded at fair value, which is subject to market price volatility. We record our equity warrant investments in private companies at fair value and adjust our equity investments in private companies, which primarily relate to our equity investment in Anthropic, for observable price changes or impairments. We record our available-for-sale convertible debt investments in private companies at fair value, which primarily relate to Anthropic. Valuations of private companies are inherently more complex due to the lack of readily available market data. The current global economic conditions provide additional uncertainty. As such, we believe that market sensitivities are not practicable. See Item 8 of Part II, “Financial Statements and Supplementary Data — Note 1 — Description of Business, Accounting Policies, and Supplemental Disclosures” for additional information.
32
Table of Contents
Item 8.	Financial Statements and Supplementary Data
INDEX TO CONSOLIDATED FINANCIAL STATEMENTS
Page
Report of Ernst & Young LLP, Independent Registered Public Accounting Firm (PCAOB ID: 42)
34
Consolidated Statements of Cash Flows
36
Consolidated Statements of Operations
37
Consolidated Statements of Comprehensive Income
38
Consolidated Balance Sheets
39
Consolidated Statements of Stockholders’ Equity
40
Notes to Consolidated Financial Statements
41
33
Table of Contents
Report of Independent Registered Public Accounting Firm
The Board of Directors and Shareholders
Amazon.com, Inc.
Opinion on the Financial Statements
We have audited the accompanying consolidated balance sheets of Amazon.com, Inc. (the Company) as of December 31, 2025 and 2024, the related consolidated statements of operations, comprehensive income, stockholders’ equity, and cash flows for each of the three years in the period ended December 31, 2025, and the related notes (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company at December 31, 2025 and 2024, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2025, in conformity with U.S. generally accepted accounting principles.
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company’s internal control over financial reporting as of December 31, 2025, based on criteria established in Internal Control-Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) and our report dated February 5, 2026 expressed an unqualified opinion thereon.
Basis for Opinion
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s consolidated financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. We believe that our audits provide a reasonable basis for our opinion.
Critical Audit Matter
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that: (1) relates to accounts or disclosures that are material to the consolidated financial statements and (2) involved our especially challenging, subjective or complex judgments. The communication of the critical audit matter does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.
34
Table of Contents
Uncertain Tax Positions
Description of
the Matter
As discussed in Notes 1 and 9 of the consolidated financial statements, the Company is subject to income taxes in the U.S. and numerous foreign jurisdictions and during the ordinary course of business, there are many tax positions for which the ultimate tax determination is uncertain. As a result, significant judgment is required in evaluating the Company’s tax positions and determining its provision for income taxes. The Company uses significant judgment in (1) determining whether a tax position’s technical merits are more likely than not to be sustained and (2) measuring the amount of tax benefit that qualifies for recognition. As of December 31, 2025, the Company reported accrued liabilities of $6.6 billion for various tax contingencies.
Auditing the recognition and measurement of certain of the Company’s uncertain tax positions was challenging because the evaluation of whether a tax position is more likely than not to be sustained and the measurement of the benefit of various tax positions can be complex and involves significant auditor judgment. Management’s evaluation of tax positions is based on interpretations of tax laws and legal rulings, and may be impacted by regulatory changes and judicial and examination activity.
How We
Addressed the
Matter in Our
Audit
We tested controls over the Company’s process to assess the technical merits of its tax contingencies, including controls over: the assessment as to whether a tax position is more likely than not to be sustained; the measurement of the benefit of its tax positions, both initially and on an ongoing basis; and the development of the related disclosures.
We involved our tax subject matter professionals in assessing the technical merits of certain of the Company’s tax positions. Depending on the nature of the specific tax position and, as applicable, developments with the relevant tax authorities relating thereto, our procedures included obtaining and examining the Company’s analysis including the Company’s correspondence with such tax authorities and evaluating the underlying facts upon which the tax positions are based. We used our knowledge of and experience with income tax laws of the relevant taxing jurisdictions to evaluate the Company’s accounting for its tax contingencies. We evaluated developments in the applicable regulatory environments to assess potential effects on the Company’s positions, including recent decisions in relevant court cases. We analyzed the appropriateness of the Company’s assumptions and the accuracy of the Company’s calculations and data used to determine the amount of tax benefits to recognize. We evaluated the Company’s income tax disclosures in relation to these matters.
/s/ Ernst & Young LLP
We have served as the Company’s auditor since 1996.
Seattle, Washington
February 5, 2026
35
Table of Contents
AMAZON.COM, INC.
CONSOLIDATED STATEMENTS OF CASH FLOWS
(in millions)
Year Ended December 31,
2023		2024		2025
CASH, CASH EQUIVALENTS, AND RESTRICTED CASH, BEGINNING OF PERIOD	$	54,253 			$	73,890 			$	82,312
OPERATING ACTIVITIES:
Net income	30,425 			59,248 			77,670
Adjustments to reconcile net income to net cash from operating activities:
Depreciation and amortization of property and equipment and capitalized content costs, operating lease assets, and other	48,663 			52,795 			65,756
Stock-based compensation	24,023 			22,011 			19,467
Non-operating expense (income), net	(748)			2,012 			(14,880)
Deferred income taxes	(5,876)			(4,648)			11,470
Changes in operating assets and liabilities:
Inventories	1,449 			(1,884)			(3,002)
Accounts receivable, net and other	(8,348)			(3,249)			(7,333)
Other assets	(12,265)			(14,483)			(15,632)
Accounts payable	5,473 			2,972 			11,231
Accrued expenses and other	(2,428)			(2,904)			(5,019)
Unearned revenue	4,578 			4,007 			(214)
Net cash provided by (used in) operating activities	84,946 			115,877 			139,514
INVESTING ACTIVITIES:
Purchases of property and equipment	(52,729)			(82,999)			(131,819)
Proceeds from property and equipment sales and incentives	4,596 			5,341 			3,499
Acquisitions, net of cash acquired, non-marketable investments, and other, net	(5,839)			(7,082)			(3,841)
Sales and maturities of marketable securities	5,627 			16,403 			44,386
Purchases of marketable securities	(1,488)			(26,005)			(54,770)
Net cash provided by (used in) investing activities	(49,833)			(94,342)			(142,545)
FINANCING ACTIVITIES:
Proceeds from short-term debt, and other	18,129 			5,142 			9,320
Repayments of short-term debt, and other	(25,677)			(5,060)			(8,426)
Proceeds from long-term debt	— 			— 			15,673
Repayments of long-term debt	(3,676)			(9,182)			(5,021)
Principal repayments of finance leases	(4,384)			(2,043)			(1,557)
Principal repayments of financing obligations	(271)			(669)			(328)
Net cash provided by (used in) financing activities	(15,879)			(11,812)			9,661
Foreign currency effect on cash, cash equivalents, and restricted cash	403 			(1,301)			1,164
Net increase (decrease) in cash, cash equivalents, and restricted cash	19,637 			8,422 			7,794
CASH, CASH EQUIVALENTS, AND RESTRICTED CASH, END OF PERIOD	$	73,890 			$	82,312 			$	90,106
See accompanying notes to consolidated financial statements.
36
Table of Contents
AMAZON.COM, INC.
CONSOLIDATED STATEMENTS OF OPERATIONS
(in millions, except per share data)
Year Ended December 31,
2023		2024		2025
Net product sales	$	255,887 			$	272,311 			$	296,266
Net service sales	318,898 			365,648 			420,658
Total net sales	574,785 			637,959 			716,924
Operating expenses:
Cost of sales	304,739 			326,288 			356,414
Fulfillment	90,619 			98,505 			109,074
Technology and infrastructure	85,622 			88,544 			108,521
Sales and marketing	44,370 			43,907 			47,129
General and administrative	11,816 			11,359 			11,172
Other operating expense (income), net	767 			763 			4,639
Total operating expenses	537,933 			569,366 			636,949
Operating income	36,852 			68,593 			79,975
Interest income	2,949 			4,677 			4,381
Interest expense	(3,182)			(2,406)			(2,274)
Other income (expense), net	938 			(2,250)			15,229
Total non-operating income	705 			21 			17,336
Income before income taxes	37,557 			68,614 			97,311
Provision for income taxes	(7,120)			(9,265)			(19,087)
Equity-method investment activity, net of tax	(12)			(101)			(554)
Net income	$	30,425 			$	59,248 			$	77,670
Basic earnings per share	$	2.95 			$	5.66 			$	7.29
Diluted earnings per share	$	2.90 			$	5.53 			$	7.17
Weighted-average shares used in computation of earnings per share:
Basic	10,304 			10,473 			10,656
Diluted	10,492 			10,721 			10,827
See accompanying notes to consolidated financial statements.
37
Table of Contents
AMAZON.COM, INC.
CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME
(in millions)
Year Ended December 31,
2023		2024		2025
Net income	$	30,425 			$	59,248 			$	77,670
Other comprehensive income (loss):
Foreign currency translation adjustments, net of tax of $(55), $226, and $(194)	1,027 			(3,333)			4,226
Available-for-sale debt securities:
Change in net unrealized gains (losses), net of tax of $(110), $(2,086), and $(8,754)	366 			6,339 			28,304
Less: reclassification adjustment for net losses (gains) included in “Other income (expense), net,” net of tax of $(15), $(2), and $1,327	50 			5 			(4,273)
Net change	416 			6,344 			24,031
Other, net of tax of $(1), $1, and $(1)	4 			(5)			7
Total other comprehensive income (loss)	1,447 			3,006 			28,264
Comprehensive income	$	31,872 			$	62,254 			$	105,934
See accompanying notes to consolidated financial statements.
38
Table of Contents
AMAZON.COM, INC.
CONSOLIDATED BALANCE SHEETS
(in millions, except per share data)
December 31,
2024		2025
ASSETS
Current assets:
Cash and cash equivalents	$	78,779 			$	86,810
Marketable securities	22,423 			36,219
Inventories	34,214 			38,325
Accounts receivable, net and other	55,451 			67,729
Total current assets	190,867 			229,083
Property and equipment, net	252,665 			357,025
Operating leases	76,141 			86,054
Goodwill	23,074 			23,273
Other assets	82,147 			122,607
Total assets	$	624,894 			$	818,042
LIABILITIES AND STOCKHOLDERS’ EQUITY
Current liabilities:
Accounts payable	$	94,363 			$	121,909
Accrued expenses and other	66,965 			75,520
Unearned revenue	18,103 			20,576
Total current liabilities	179,431 			218,005
Long-term lease liabilities	78,277 			87,339
Long-term debt	52,623 			65,648
Other long-term liabilities	28,593 			35,985
Commitments and contingencies (Note 7)
Stockholders’ equity:
Preferred stock ($0.01 par value; 500 shares authorized; no shares issued or outstanding)	— 			—
Common stock ($0.01 par value; 100,000 shares authorized; 11,108 and 11,246 shares issued; 10,593 and 10,731 shares outstanding)	111 			112
Treasury stock, at cost	(7,837)			(7,837)
Additional paid-in capital	120,864 			140,024
Accumulated other comprehensive income (loss)	(34)			28,230
Retained earnings	172,866 			250,536
Total stockholders’ equity	285,970 			411,065
Total liabilities and stockholders’ equity	$	624,894 			$	818,042
See accompanying notes to consolidated financial statements.
39
Table of Contents
AMAZON.COM, INC.
CONSOLIDATED STATEMENTS OF STOCKHOLDERS’ EQUITY
(in millions)
Common Stock
Shares		Amount		Treasury
Stock		Additional
Paid-In
Capital		Accumulated Other Comprehensive Income (Loss)		Retained
Earnings		Total
Stockholders’
Equity
Balance as of January 1, 2023	10,242 			$	108 			$	(7,837)			$	75,066 			$	(4,487)			$	83,193 			$	146,043
Net income	— 			— 			— 			— 			— 			30,425 			30,425
Other comprehensive income (loss)	— 			— 			— 			— 			1,447 			— 			1,447
Stock-based compensation and issuance of employee benefit plan stock	141 			1 			— 			23,959 			— 			— 			23,960
Balance as of December 31, 2023	10,383 			109 			(7,837)			99,025 			(3,040)			113,618 			201,875
Net income	— 			— 			— 			— 			— 			59,248 			59,248
Other comprehensive income (loss)	— 			— 			— 			— 			3,006 			— 			3,006
Stock-based compensation and issuance of employee benefit plan stock	210 			2 			— 			21,839 			— 			— 			21,841
Balance as of December 31, 2024	10,593 			111 			(7,837)			120,864 			(34)			172,866 			285,970
Net income	— 			— 			— 			— 			— 			77,670 			77,670
Other comprehensive income (loss)	— 			— 			— 			— 			28,264 			— 			28,264
Stock-based compensation and issuance of employee benefit plan stock	138 			1 			— 			19,160 			— 			— 			19,161
Balance as of December 31, 2025	10,731 			$	112 			$	(7,837)			$	140,024 			$	28,230 			$	250,536 			$	411,065
See accompanying notes to consolidated financial statements.
40
Table of Contents
AMAZON.COM, INC.
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS
Note 1 — DESCRIPTION OF BUSINESS, ACCOUNTING POLICIES, AND SUPPLEMENTAL DISCLOSURES
Description of Business
We seek to be Earth’s most customer-centric company. In each of our segments, we serve our primary customer sets, consisting of consumers, sellers, developers, enterprises, content creators, advertisers, and employees. We serve consumers through our online and physical stores and focus on selection, price, and convenience. We offer programs that enable sellers to grow their businesses, sell their products in our stores, and fulfill orders using our services, and programs that allow authors, independent publishers, musicians, filmmakers, Twitch streamers, skill and app developers, and others to publish and sell content. We serve developers and enterprises of all sizes through AWS, which offers a broad set of on-demand technology services, including compute, storage, database, analytics, artificial intelligence and machine learning, and other services. We also manufacture and sell electronic devices. In addition, we provide advertising services to sellers, vendors, publishers, authors, and others, through programs such as sponsored ads, display, and video advertising.
We have organized our operations into three segments: North America, International, and AWS. See “Note 10 — Segment Information.”
Principles of Consolidation
The consolidated financial statements include the accounts of Amazon.com, Inc. and its consolidated entities (collectively, the “Company”), consisting of its wholly-owned subsidiaries and those entities in which we have a variable interest and of which we are the primary beneficiary, including certain entities in India and certain entities that support our healthcare services and production and distribution of video content. Intercompany balances and transactions between consolidated entities are eliminated.
Use of Estimates
The preparation of financial statements in conformity with GAAP requires estimates and assumptions that affect the reported amounts of assets and liabilities, revenues and expenses, and related disclosures of contingent liabilities in the consolidated financial statements and accompanying notes. Estimates are used for, but not limited to, collectability of receivables, commitments and contingencies, impairment of property and equipment and operating leases, income taxes, inventory valuation, self-insurance liabilities, stock-based compensation forfeiture rates, the determination of when to capitalize certain costs relating to new products or service offerings, useful lives of equipment, valuation and impairment of investments, valuation of acquired intangibles and goodwill, valuation of derivative instruments, vendor funding, and viewing patterns of capitalized video content. Actual results could differ materially from these estimates. We review the useful lives of equipment on an ongoing basis.
Effective January 1, 2025 we changed our estimate of the useful lives of a subset of our servers and networking equipment from six years to five years. The shorter useful lives are due to the increased pace of technology development, particularly in the area of artificial intelligence and machine learning. The effect of this change in estimate for the year ended December 31, 2025, based on servers and networking equipment that were included in “Property and equipment, net” as of December 31, 2024 and those acquired during the year ended December 31, 2025, was an increase in depreciation and amortization expense of $1.4 billion and a reduction in net income of $1.0 billion, or $0.10 per basic share and $0.10 per diluted share, which primarily impacted our AWS segment.
During Q3 2025, we recorded $2.5 billion of expense related to the settlement of a lawsuit with the FTC. This charge was recorded in “Other operating expense (income), net” and impacted our North America segment.
During Q4 2025, we recorded $2.4 billion of expense related to settlements of a lawsuit and tax disputes, severance costs, and asset impairments. Of this total, $1.1 billion related to the resolution of tax disputes associated with our stores business in Italy, and the settlement of a lawsuit, recorded primarily in “Other operating expense (income), net” and “Fulfillment,” and primarily impacted our International segment.
For the year ended December 31, 2025, we recorded approximately $2.7 billion of estimated severance costs primarily related to planned role eliminations, of which $1.8 billion was recorded in Q3 2025 and $730 million was recorded in the fourth quarter. These charges increased our payroll and related expenses, were recorded primarily in “Technology and infrastructure,” “Fulfillment,” and “Sales and marketing,” and impacted all of our segments.
For the year ended December 31, 2025, we recorded approximately $1.3 billion of asset impairments, of which $610 million was recorded in the fourth quarter, primarily consisting of property and equipment and operating leases related to
41
Table of Contents
physical stores. These fourth quarter charges were recorded in “Other operating expense (income), net” and primarily impacted our North America segment.
Supplemental Cash Flow Information
The following table shows supplemental cash flow information (in millions):
Year Ended December 31,
2023		2024		2025
SUPPLEMENTAL CASH FLOW INFORMATION:
Cash paid for interest on debt, net of capitalized interest	$	2,608 			$	1,858 			$	1,458
Cash paid for operating leases	10,453 			12,341 			15,038
Cash paid for interest on finance leases	308 			287 			295
Cash paid for interest on financing obligations	196 			219 			196
Cash paid for income taxes, net of refunds	11,179 			12,308 			8,295
Assets acquired under operating leases	14,052 			15,424 			19,930
Property and equipment acquired under finance leases, net of remeasurements and modifications	642 			854 			2,911
Increase (decrease) in property and equipment acquired but not yet paid	(1,414)			7,039 			10,155
Earnings Per Share
Basic earnings per share is calculated using our weighted-average outstanding common shares. Diluted earnings per share is calculated using our weighted-average outstanding common shares including the dilutive effect of stock awards as determined under the treasury stock method. In periods when we have a net loss, stock awards are excluded from our calculation of earnings per share as their inclusion would have an antidilutive effect.
The following table shows the calculation of diluted shares (in millions):
Year Ended December 31,
2023		2024		2025
Shares used in computation of basic earnings per share	10,304 			10,473 			10,656
Total dilutive effect of outstanding stock awards	188 			248 			171
Shares used in computation of diluted earnings per share	10,492 			10,721 			10,827
Revenue
Revenue is measured based on the amount of consideration that we expect to receive, reduced by estimates for return allowances, promotional discounts, and rebates. Revenue also excludes any amounts collected on behalf of third parties, including sales and indirect taxes. In arrangements where we have multiple performance obligations, the transaction price is allocated to each performance obligation using the relative stand-alone selling price. We generally determine stand-alone selling prices based on the prices charged to customers or using expected cost plus a margin.
A description of our principal revenue generating activities is as follows:
Retail sales - We offer consumer products through our online and physical stores. Revenue is recognized when control of the goods is transferred to the customer, which generally occurs upon our delivery to a third-party carrier or, in the case of an Amazon delivery, to the customer.
Third-party seller services - We offer programs that enable sellers to sell their products in our stores, and fulfill orders using our services. We are not the seller of record in these transactions. The commissions and any related fulfillment and shipping fees we earn from these arrangements are recognized when the services are rendered, which generally occurs upon delivery of the related products to a third-party carrier or, in the case of an Amazon delivery, to the customer.
Advertising services - We provide advertising services to sellers, vendors, publishers, authors, and others, through programs such as sponsored ads, display, and video advertising. Revenue is recognized as ads are delivered based on the number of clicks or impressions.
42
Table of Contents
Subscription services - Our subscription sales include fees associated with Amazon Prime memberships and access to content including digital video, audiobooks, digital music, e-books, and other non-AWS subscription services. Prime memberships provide our customers with access to an evolving suite of benefits that represent a single stand-ready obligation. Subscriptions are paid for at the time of or in advance of delivering the services. Revenue from such arrangements is recognized over the subscription period.
AWS - Our AWS arrangements include global sales of compute, storage, database, and other services. Revenue is allocated to services using stand-alone selling prices and is primarily recognized when the customer uses these services, based on the quantity of services rendered, such as compute or storage capacity delivered on-demand. Certain services, including compute and database, are also offered as a fixed quantity over a specified term, for which revenue is recognized ratably. Sales commissions we pay in connection with contracts that exceed one year are capitalized and amortized over the contract term.
Other - Other revenue includes sales related to various other offerings, such as healthcare services, certain licensing and distribution of video content, and shipping services, and our co-branded credit card agreements. Revenue is recognized when content is licensed or distributed and as or when services are performed.
Return Allowances
Return allowances, which reduce revenue and cost of sales, are estimated using historical experience. Liabilities for return allowances are included in “Accrued expenses and other” and were $1.4 billion, $1.4 billion, and $1.6 billion as of December 31, 2023, 2024, and 2025. Additions to the allowance were $5.2 billion, $5.5 billion, and $5.8 billion and deductions from the allowance were $5.1 billion, $5.5 billion, and $5.8 billion in 2023, 2024, and 2025. Included in “Inventories” on our consolidated balance sheets are assets totaling $992 million, $998 million, and $1.2 billion as of December 31, 2023, 2024, and 2025, for the rights to recover products from customers associated with our liabilities for return allowances.
Cost of Sales
Cost of sales primarily consists of the purchase price of consumer products, inbound and outbound shipping costs, including costs related to sortation and delivery centers and where we are the transportation service provider, and digital media content costs where we record revenue gross, including video and music. Shipping costs to receive products from our suppliers are included in our inventory, and recognized as cost of sales upon sale of products to our customers. Payment processing and related transaction costs, including those associated with seller transactions, are classified in “Fulfillment” on our consolidated statements of operations.
Vendor Agreements
We have agreements with our vendors to receive consideration primarily for cooperative marketing efforts, promotions, incentives, and volume rebates. We generally consider these amounts received from vendors to be a reduction of the prices we pay for their goods, including property and equipment, or services, and are recorded as a reduction of the cost of inventory, cost of services, or cost of property and equipment. Volume rebates typically depend on reaching minimum purchase thresholds. We evaluate the likelihood of reaching purchase thresholds using past experience and current year forecasts. When volume rebates can be reasonably estimated, we record a portion of the rebate as we make progress towards the purchase threshold.
Fulfillment
Fulfillment costs primarily consist of those costs incurred in operating and staffing our North America and International segments’ fulfillment centers, physical stores, and customer service centers, including facilities and equipment expenses, such as depreciation and amortization, and rent; costs attributable to buying, receiving, inspecting, and warehousing inventories; picking, packaging, and preparing customer orders for shipment; payment processing and related transaction costs, including costs associated with our guarantee for certain seller transactions; responding to inquiries from customers; and supply chain management for our manufactured electronic devices. Fulfillment costs also include amounts paid to third parties that assist us in fulfillment and customer service operations.
43
Table of Contents
Technology and Infrastructure
Technology and infrastructure costs include payroll and related expenses for employees involved in the research and development of new and existing products and services, development, design, and maintenance of our stores, curation and display of products and services made available in our online stores, and infrastructure costs. Infrastructure costs include servers, networking equipment, and data center related depreciation and amortization, rent, utilities, and other expenses necessary to support AWS and other Amazon businesses. Collectively, these costs reflect the investments we make in order to offer a wide variety of products and services to our customers, including expenditures related to initiatives to build and deploy innovative and efficient software and electronic devices and the development of a satellite network for global broadband service and autonomous vehicles for ride-hailing services. Technology and infrastructure costs are generally expensed as incurred.
Sales and Marketing
Sales and marketing costs include advertising and payroll and related expenses for personnel engaged in marketing and selling activities, including sales commissions related to AWS. We pay commissions to third parties when their customer referrals result in sales. We also participate in cooperative advertising arrangements with certain of our vendors, and other third parties.
Advertising and other promotional costs to market our products and services are expensed as incurred and were $20.3 billion, $21.4 billion, and $23.5 billion in 2023, 2024, and 2025.
General and Administrative
General and administrative expenses primarily consist of costs for corporate functions, including payroll and related expenses; facilities and equipment expenses, such as depreciation and amortization expense and rent; and professional fees.
Stock-Based Compensation
Compensation cost for all equity-classified stock awards expected to vest is measured at fair value on the date of grant and recognized over the service period. The fair value of restricted stock units is determined based on the number of shares granted and the quoted price of our common stock. Such value is recognized as expense over the service period, net of estimated forfeitures, using the accelerated method. Under this method, approximately 50% of the grant date fair value is recognized as expense in the first year of grant for the majority of our stock-based compensation awards. The accelerated method also adds a higher level of sensitivity and complexity in estimating forfeitures. If an award is forfeited early in its life, the adjustment to compensation expense is much greater under an accelerated method than under a straight-line method. The estimated number of stock awards that will ultimately vest requires judgment, and to the extent actual results or updated estimates differ from our current estimates, such amounts will be recorded as a cumulative adjustment in the period estimates are revised. We consider many factors when estimating expected forfeitures, including historical forfeiture experience. Additionally, we have stock-based compensation awards that are expected to settle in cash. These liability-classified awards are remeasured to fair value at the end of each reporting period until settlement or expiration.
Other Operating Expense (Income), Net
Other operating expense (income), net, consists primarily of the amortization of intangible assets and asset impairments. During 2025, we also recorded the settlement of a lawsuit with the FTC and the resolution of tax disputes associated with our stores business in Italy.
44
Table of Contents
Other Income (Expense), Net
Other income (expense), net, is as follows (in millions):
Year Ended December 31,
2023		2024		2025
Marketable equity securities valuation gains (losses), net	$	984 			$	(1,278)			$	1,439
Equity warrant valuation gains (losses), net	26 			(192)			553
Reclassification adjustments for gains (losses) on available-for-sale debt securities, net	(65)			(7)			5,600
Upward adjustments relating to equity investments in private companies	40 			49 			7,709
Foreign currency gains (losses), net	65 			(408)			19
Other, net	(112)			(414)			(91)
Total other income (expense), net	$	938 			$	(2,250)			$	15,229
The marketable equity securities valuation gain (loss) of $984 million, $(1.3) billion, and $1.4 billion in 2023, 2024, and 2025 is primarily from our equity investment in Rivian. The reclassification adjustments for the gains on available-for-sale debt securities of $5.6 billion for the year ended December 31, 2025 is primarily from the portions of our convertible notes investments in Anthropic that were converted to nonvoting preferred stock during the year ended December 31, 2025. The upward adjustments relating to equity investments in private companies of $7.7 billion for the year ended December 31, 2025 reflect observable changes in prices, primarily from our nonvoting preferred stock in Anthropic.
Income Taxes
Income tax expense includes U.S. (federal and state) and foreign income taxes. Certain foreign subsidiary earnings and losses are subject to current U.S. taxation and the subsequent repatriation of those earnings is not subject to tax in the U.S. We intend to invest substantially all of our foreign subsidiary earnings, as well as our capital in our foreign subsidiaries, indefinitely outside of the U.S. in those jurisdictions in which we would incur significant, additional costs upon repatriation of such amounts.
Deferred income tax balances reflect the effects of temporary differences between the carrying amounts of assets and liabilities and their tax bases, as well as net operating loss and tax credit carryforwards, and are stated at enacted tax rates expected to be in effect when taxes are actually paid or recovered.
Deferred tax assets represent amounts available to reduce income taxes payable in future periods. Deferred tax assets are evaluated for future realization and reduced by a valuation allowance to the extent we believe they will not be realized. We consider many factors when assessing the likelihood of future realization of our deferred tax assets, including recent cumulative loss experience and expectations of future earnings, capital gains and investment in such jurisdiction, the carry-forward periods available to us for tax reporting purposes, and other relevant factors.
We utilize a two-step approach to recognizing and measuring uncertain income tax positions (income tax contingencies). The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates it is more likely than not the position will be sustained on audit, including resolution of related appeals or litigation processes. The second step is to measure the tax benefit as the largest amount which is more than 50% likely of being realized upon ultimate settlement. We consider many factors when evaluating our tax positions and estimating our tax benefits, which may require periodic adjustments and which may not accurately forecast actual outcomes. We include interest and penalties related to our income tax contingencies in income tax expense.
Fair Value of Financial Instruments
Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. To increase the comparability of fair value measures, the following hierarchy prioritizes the inputs to valuation methodologies used to measure fair value:
Level 1 — Valuations based on quoted prices for identical assets and liabilities in active markets.
Level 2 — Valuations based on observable inputs other than quoted prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data.
Level 3 — Valuations based on unobservable inputs reflecting our own assumptions, consistent with reasonably available assumptions made by other market participants. These valuations require significant judgment.
45
Table of Contents
We measure the fair value of money market funds and certain marketable equity securities based on quoted prices in active markets for identical assets or liabilities. Other marketable securities were valued either based on recent trades of securities in inactive markets or based on quoted market prices of similar instruments and other significant inputs derived from or corroborated by observable market data.
Derivative Instruments
We enter into energy contracts to secure electricity supply for our existing and future operations, some of which extend 20 years. We may make or receive net cash payments, rather than take delivery of electricity, when our consumption is less than committed quantities due to operational variability. Because we may make or receive net cash payments, these contracts are derivative instruments. These contracts are not traded on exchanges or transacted in secondary markets and are not used for trading or speculative purposes.
Derivative instruments are measured at fair value each reporting period. Fair value measurements are based on valuation methods using both common factors like electricity futures prices where there are more liquid trading volumes generally for remaining contractual periods up to four to five years, forward capacity auctions and risk-free interest rates, and a number of management assumptions for remaining contractual periods greater than four to five years where there is significantly less or no trading data such as long-dated forward commodity prices and implied volatility curves, and credit adjustments. The extent of management judgment is significant (Level 3).
Fair value measurements will not impact cash flows but may be material to our statements of operations and balance sheet due to the duration of these contracts and volatility inherent in valuation methods. Generally, we can terminate our contracts by paying cash in the form of fixed penalties, such as reimbursing the counterparty for the costs of new construction incurred. Termination penalties are generally not based on fair value measurements.
As of December 31, 2025, the energy contract quantities subject to derivative accounting fair value measurements were approximately 200 million megawatt-hours and the weighted-average remaining duration of these contracts is approximately 16 years, with the majority of these megawatt-hours to be delivered beyond the next nine years. The impact of these fair value measurements on our consolidated statement of operations for the year ended December 31, 2025 was not significant.
Changes in fair value measurements will create unrealized gains and losses recorded within operating expenses on our statements of operations with corresponding assets (unrealized gains) and liabilities (unrealized losses) recorded on our balance sheet.
Certain of our energy contracts are subject to regulatory approval and are exempt from derivative guidance until the approval is obtained. If possible, we may elect the normal purchases and normal sales (NPNS) scope exemption from derivative guidance for energy contracts where we expect to consume substantially all committed quantities. A contract that no longer meets the NPNS exemption must be measured at fair value with immediate recognition in our financial statements.
Cash and Cash Equivalents
We classify all highly liquid instruments with an original maturity of three months or less as cash equivalents.
Inventories
Inventories, consisting of products available for sale, are primarily accounted for using the first-in, first-out method, and are valued at the lower of cost and net realizable value. This valuation requires us to make judgments, based on currently available information, about the likely method of disposition, such as through sales to individual customers, returns to product vendors, or liquidations, and expected recoverable values of each disposition category. The inventory valuation allowance, representing a write-down of inventory, was $3.0 billion and $3.3 billion as of December 31, 2024 and 2025.
We provide Fulfillment by Amazon services in connection with certain of our sellers’ programs. Third-party sellers maintain ownership of their inventory, regardless of whether fulfillment is provided by us or the third-party sellers, and therefore these products are not included in our inventories.
We also purchase electronic device components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate supply, we enter into agreements with contract manufacturers and suppliers for certain electronic device components. We have certain non-cancellable purchase commitments arising from these agreements. These commitments are based on forecasted customer demand. If we reduce these commitments, we may incur additional costs.
46
Table of Contents
Accounts Receivable, Net and Other
Included in “Accounts receivable, net and other” on our consolidated balance sheets are receivables primarily related to customers, vendors, and prepaid expenses and other current assets. As of December 31, 2024 and 2025, customer receivables, net, were $34.3 billion and $40.4 billion, vendor receivables, net, were $11.6 billion and $15.9 billion, and other receivables, net, were $3.4 billion and $4.5 billion. Prepaid expenses and other current assets, which include amounts related to non-income taxes and satellite network launch services deposits, were $6.3 billion and $6.9 billion as of December 31, 2024 and December 31, 2025. We currently expense satellite network launch services deposits upon launch to “Technology and infrastructure.”
We estimate losses on receivables based on expected losses, including our historical experience of actual losses. Receivables are considered impaired and written-off when it is probable that all contractual payments due will not be collected in accordance with the terms of the agreement. The allowance for doubtful accounts was $1.7 billion, $2.0 billion, and $2.4 billion as of December 31, 2023, 2024, and 2025. Additions to the allowance were $1.9 billion, $1.9 billion, and $1.6 billion, and deductions to the allowance were $1.6 billion, $1.6 billion, and $1.2 billion in 2023, 2024, and 2025.
Software Development Costs
We incur software development costs related to products to be sold, leased, or marketed to external users, internal-use software, and our websites. Software development costs capitalized were not significant for the years presented. All other costs, including those related to design or maintenance, are expensed as incurred.
Property and Equipment, Net
Property and equipment are stated at cost less accumulated depreciation and amortization. Incentives that we receive from property and equipment vendors are recorded as a reduction to our costs. Property includes buildings and land that we own, along with property we have acquired under build-to-suit lease arrangements when we have control over the building during the construction period and finance lease arrangements. Heavy equipment consists primarily of assets that support the infrastructure of our fulfillment network and data centers. Other equipment consists primarily of fulfillment equipment. Depreciation and amortization is recorded on a straight-line basis over the estimated useful lives of the assets and classified within the corresponding operating expense categories on our consolidated statements of operations. The estimated useful lives as of December 31, 2025, are as follows:
Property and equipment		Estimated useful life
Buildings
Lesser of forty years or the remaining life of the underlying building
Servers and networking equipment
Five to six years (1)
Heavy equipment
Ten to thirteen years (2)
Other equipment
Three to ten years
___________________
(1)Effective January 1, 2024, we changed our estimate of the useful lives for our servers from five to six years, and effective January 1, 2025, we changed our estimate of the useful lives of a subset of our servers and networking equipment from six to five years.
(2)Ten years prior to January 1, 2025.
Leases
We categorize leases with contractual terms longer than twelve months as either operating or finance. Finance leases are generally those leases that allow us to substantially utilize or pay for the entire asset over its estimated life. Assets acquired under finance leases are recorded in “Property and equipment, net.” All other leases are categorized as operating leases. Our leases generally have terms that range from one to ten years for equipment and one to twenty years for property.
Certain lease contracts include obligations to pay for other services, such as operations and maintenance. For leases of property, we account for these other services as a component of the lease. For substantially all other leases, the services are accounted for separately and we allocate payments to the lease and other services components based on estimated stand-alone prices.
Lease liabilities are recognized at the present value of the fixed lease payments, reduced by landlord incentives using a discount rate based on similarly secured borrowings available to us. Lease assets are recognized based on the initial present value of the fixed lease payments, reduced by landlord incentives, plus any direct costs from executing the leases or lease prepayments reclassified from “Other assets” upon lease commencement. Leasehold improvements are capitalized at cost and amortized over the lesser of their expected useful life or the lease term.
47
Table of Contents
When we have the option to extend the lease term, terminate the lease before the contractual expiration date, or purchase the leased asset, and it is reasonably certain that we will exercise the option, we consider the option in determining the classification and measurement of the lease. Our leases may include variable payments based on measures that include changes in price indices, market interest rates, or the level of sales at a physical store, which are expensed as incurred.
Costs associated with operating lease assets are recognized on a straight-line basis within operating expenses over the term of the lease. Finance lease assets are amortized within operating expenses on a straight-line basis over the shorter of the estimated useful lives of the assets or, in the instance where title does not transfer at the end of the lease term, the lease term. The interest component of a finance lease is included in interest expense and recognized using the effective interest method over the lease term.
We establish assets and liabilities for the present value of estimated future costs to retire long-lived assets at the termination or expiration of a lease. Such assets are amortized over the lease period into operating expense, and the recorded liabilities are accreted to the future value of the estimated retirement costs.
Financing Obligations
We record assets and liabilities for estimated construction costs under build-to-suit lease arrangements when we have control over the building during the construction period. If we continue to control the building after the construction period, the arrangement is classified as a financing obligation instead of a lease. The building is depreciated over the shorter of its useful life or the term of the obligation.
If we do not control the building after the construction period ends, the assets and liabilities for construction costs are derecognized, and we classify the lease as operating.
Goodwill and Indefinite-Lived Intangible Assets
We evaluate goodwill and indefinite-lived intangible assets for impairment annually or more frequently when an event occurs or circumstances change that indicate the carrying value may not be recoverable. We may elect to utilize a qualitative assessment to evaluate whether it is more likely than not that the fair value of a reporting unit or indefinite-lived intangible asset is less than its carrying value and if so, we perform a quantitative test. We compare the carrying value of each reporting unit and indefinite-lived intangible asset to its estimated fair value and if the fair value is determined to be less than the carrying value, we recognize an impairment loss for the difference. We estimate the fair value of the reporting units using discounted cash flows. Forecasts of future cash flows are based on our best estimate of future net sales and operating expenses, based primarily on expected category expansion, pricing, market segment share, and general economic conditions.
We completed the required annual impairment test of goodwill for all reporting units and indefinite-lived intangible assets as of April 1, 2025, resulting in no impairments. The fair value of our reporting units substantially exceeded their carrying value. There were no events that caused us to update our annual impairment test. See “Note 5 — Acquisitions, Goodwill, and Acquired Intangible Assets.”
Other Assets
Included in “Other assets” on our consolidated balance sheets are amounts primarily related to convertible notes and certain equity investments; video and music content, net of accumulated amortization; long-term deferred tax assets; acquired intangible assets, net of accumulated amortization;  satellite network launch services deposits; and affordable housing loans. We will reclassify the satellite network launch service deposits to construction-in-progress included within “Property and equipment, net” on our consolidated balance sheet once the service achieves commercial viability, including sales to customers. We recognize certain transactions with governments when it is probable that incentives included in the agreements, such as cash or certain tax credits, will be received and we are able to comply with any related conditions. These incentives are recorded as reductions to the cost of related assets or expenses.
Digital Video and Music Content
We obtain video content, inclusive of episodic television and movies, and music content for customers through licensing agreements that have a wide range of licensing provisions including both fixed and variable payment schedules. When the license fee for a specific video or music title is determinable or reasonably estimable and the content is available to us, we recognize an asset and a corresponding liability for the amounts owed. We reduce the liability as payments are made and we amortize the asset to “Cost of sales” on an accelerated basis, based on estimated usage or viewing patterns, or on a straight-line basis. If the licensing fee is not determinable or reasonably estimable, no asset or liability is recorded and licensing costs are expensed as incurred. We also develop original video content for which the production costs are capitalized and amortized to “Cost of sales” predominantly on an accelerated basis that follows the estimated viewing patterns associated with the content.
48
Table of Contents
The weighted average remaining life of our capitalized video content is 3.2 years. We review usage and viewing patterns impacting the amortization of capitalized video content on an ongoing basis and reflect any changes prospectively.
Our produced and licensed video content is primarily monetized together as a unit, referred to as a film group, in each major geography where we offer Amazon Prime memberships. These film groups are evaluated for impairment whenever an event occurs or circumstances change indicating the fair value is less than the carrying value. The total capitalized costs of video, which is primarily released content, and music as of December 31, 2024 and 2025 were $19.6 billion and $21.3 billion. Total video and music expense was $20.4 billion and $22.4 billion for the year ended December 31, 2024 and 2025. Total video and music expense includes licensing and production costs associated with content offered within Amazon Prime memberships, and costs associated with digital subscriptions and sold or rented content.
Cash Equivalents and Marketable Securities
We generally invest our excess cash in investment grade short- to intermediate-term marketable debt securities and AAA-rated money market funds. Such investments are included in “Cash and cash equivalents” or “Marketable securities” on the accompanying consolidated balance sheets.
Marketable debt securities are classified as available-for-sale and reported at fair value with unrealized gains and losses included in “Accumulated other comprehensive income (loss).” Each reporting period, we evaluate whether declines in fair value below carrying value are due to expected credit losses, as well as our ability and intent to hold the investment until a forecasted recovery occurs. Expected credit losses are recorded as an allowance through “Other income (expense), net” on our consolidated statements of operations.
Equity investments that have readily determinable fair values, including investments for which we have elected the fair value option, are included in “Marketable securities” on our consolidated balance sheets and measured at fair value with changes recognized in “Other income (expense), net” on our consolidated statements of operations.
Non-Marketable Investments
Notes that are convertible to equity classified as available-for-sale are reported at fair value with unrealized gains and losses included in “Accumulated other comprehensive income (loss),” a separate component of stockholders’ equity. Credit losses, if any, are recorded as an allowance through “Other income (expense), net” on our consolidated statements of operations. Upon conversion, the amount of the notes reported at fair value are reclassified generally from available-for-sale to equity investments accounted for at cost, with any associated unrealized gain or loss reclassified from “Accumulated other comprehensive income (loss)” to “Other income (expense), net” on our consolidated statements of operations.
From Q3 2023 to Q4 2024, we invested $5.3 billion in convertible notes from Anthropic, which are classified as available-for-sale and as Level 3 assets, and as of December 31, 2024 had an estimated fair value of approximately $13.8 billion. In making these estimates, we utilized valuation methods based on information available, including the rights and obligations of the convertible notes, other outstanding classes of securities, observable transactions such as new securities offerings, estimates of expected time to and type of liquidity events and anticipated securities offerings, and discounts for lack of marketability. Some of these notes converted to nonvoting preferred stock in Q1 2025. As a result of conversions, a significant portion of the unrealized gain associated with the notes as of December 31, 2024 was reclassified and a gain of approximately $3.3 billion was recorded in “Other income (expense), net” in our consolidated statement of operations. The investment in nonvoting preferred stock was initially recorded at its estimated fair value at the time of the conversion and is accounted for as a component of our equity investments in private companies not accounted for under the equity-method, with future adjustments for observable changes in prices or impairments representing Level 3 fair value measurements recognized in “Other income (expense), net” on our consolidated statements of operations. In Q2 2025, we invested $1.3 billion in a new convertible note from Anthropic. In Q3 2025, an additional portion of our notes was converted to nonvoting preferred stock, and as a result of the conversion a portion of the unrealized gain associated with the notes was reclassified and a gain of approximately $2.3 billion was recorded in “Other income (expense), net.” We also recorded an upward adjustment of $7.2 billion to our nonvoting preferred stock in “Other income (expense), net” to reflect observable changes in price. In Q4 2025, we invested $1.4 billion in a new convertible note from Anthropic. As of December 31, 2025, the amount recorded on our consolidated balance sheet for nonvoting preferred stock was approximately $14.8 billion. As of December 31, 2025, the estimated fair value of our convertible notes recorded on our consolidated balance sheet was approximately $45.8 billion, and the associated pre-tax unrealized gain included in “Accumulated other comprehensive income (loss)” was $39.5 billion. We also have a commercial arrangement primarily for the provision of AWS cloud services, which includes the use of AWS chips.
Subsequent to December 31, 2025, an additional portion of our notes was converted to nonvoting preferred stock. As a result of this conversion, in our Q1 2026 financial statements, we will reclassify a portion of the unrealized gain associated with the notes as of December 31, 2025 and record a gain of approximately $3 billion in “Other income (expense), net.” In our Q1
49
Table of Contents
2026 financial statements, we will also record an upward adjustment of approximately $12 billion to our nonvoting preferred stock as of December 31, 2025 in “Other income (expense), net” to reflect observable changes in price.
Equity investments in private companies not accounted for under the equity-method, which primarily relate to nonvoting preferred stock in Anthropic, are accounted for at cost, with adjustments for observable changes in prices or impairments representing Level 3 fair value measurements recognized in “Other income (expense), net” on our consolidated statements of operations. Each reporting period, we perform a qualitative assessment to evaluate whether the investment is impaired. Our assessment includes a review of recent operating results and trends, recent sales/acquisitions of the investee securities, and other publicly available data. If the investment is impaired, we write it down to its estimated fair value. As of December 31, 2024 and 2025, these investments had a carrying value of $989 million and $16.2 billion.
Equity investments where we can exercise significant influence, but not control, over an investee are accounted for using the equity-method of accounting, or at fair value if we elect the fair value option. Our share of the earnings or losses as reported by equity-method investees, amortization of basis differences, related gains or losses, and impairments, if any, are recognized in “Equity-method investment activity, net of tax” on our consolidated statements of operations. Each reporting period, we evaluate whether declines in fair value below carrying value are other-than-temporary and if so, we write down the investment to its estimated fair value. As of December 31, 2024 and 2025, these investments had a carrying value of $1.2 billion and $659 million.
As of December 31, 2024 and 2025, equity warrants measured at fair value were $2.7 billion, with changes recognized in “Other income (expense), net” on our consolidated statements of operations. These warrants are classified as Level 2 and 3 assets.
These non-marketable investments are included within “Other assets” on our consolidated balance sheets.
Certain of our investments represent a variable interest in an entity for which we do not consolidate because we are not the primary beneficiary.
Long-Lived Assets
Long-lived assets, other than goodwill and indefinite-lived intangible assets, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of the assets might not be recoverable. Conditions that would necessitate an impairment assessment include a significant decline in the observable market value of an asset, a significant change in the extent or manner in which an asset is used, or any other significant adverse change that would indicate that the carrying amount of an asset or group of assets may not be recoverable.
For long-lived assets used in operations, including lease assets, impairment losses are only recorded if the asset’s carrying amount is not recoverable through its undiscounted, probability-weighted future cash flows. We measure the impairment loss based on the difference between the carrying amount and estimated fair value. Long-lived assets are considered held for sale when certain criteria are met, including when management has committed to a plan to sell the asset, the asset is available for sale in its immediate condition, and the sale is probable within one year of the reporting date. Assets held for sale are reported at the lower of cost or fair value less costs to sell. Assets held for sale were not significant as of December 31, 2024 and 2025.
Accrued Expenses and Other
Included in “Accrued expenses and other” on our consolidated balance sheets are liabilities primarily related to tax-related liabilities, leases and asset retirement obligations, payroll and related expenses, self-insurance liabilities, unredeemed gift cards, other operating expenses, customer liabilities, marketing liabilities, current debt, and acquired digital media content.
As of December 31, 2024 and 2025, our liabilities for payroll related expenses were $7.5 billion and $10.5 billion and our liabilities for unredeemed gift cards were $5.4 billion and $5.6 billion. We reduce the liability for a gift card when redeemed by a customer. The portion of gift cards that we do not expect to be redeemed is recognized based on customer usage patterns.
Self-Insurance Liabilities
Although we maintain certain high-deductible, third-party insurance coverage for catastrophic losses, we effectively self-insure for exposure primarily related to workers’ compensation, employee healthcare benefits, general and product liability, and automobile liability, including liability resulting from third-party transportation service providers. We estimate self-insurance liabilities by considering historical claims experience, frequency and costs of claims, projected claims development, inflation, and other actuarial assumptions. Changes in the number or costs of claims, healthcare costs, judgment and settlement amounts, associated legal expenses, and other factors could cause actual results to differ materially from these estimates. As of December 31, 2024 and 2025, our total self-insurance liabilities, which primarily relate to automobile liability, were $8.5 billion and $10.4 billion and are included in “Accrued expenses and other” on our consolidated balance sheets.
50
Table of Contents
Unearned Revenue
Unearned revenue is recorded when payments are received or due in advance of performing our service obligations and is recognized over the service period. Unearned revenue primarily relates to prepayments of AWS services and Amazon Prime memberships. Our total unearned revenue as of December 31, 2024 was $24.6 billion, of which $17.4 billion was recognized as revenue during the year ended December 31, 2025 and our total unearned revenue as of December 31, 2025 was $25.0 billion. Included in “Other long-term liabilities” on our consolidated balance sheets was $6.5 billion and $4.4 billion of unearned revenue as of December 31, 2024 and 2025.
Additionally, we have performance obligations, primarily related to AWS, associated with commitments in customer contracts for future services that we expect to fulfill but have not yet been recognized in our financial statements. For contracts with original terms that exceed one year, those commitments not yet recognized were approximately $244 billion as of December 31, 2025. The weighted average remaining life of our long-term contracts is 4.1 years. The amount and timing of revenue recognition will be driven by customer usage and our performance in accordance with contractual obligations, which can extend beyond the original contractual duration and commitment.
Other Long-Term Liabilities
Included in “Other long-term liabilities” on our consolidated balance sheets are liabilities primarily related to deferred tax liabilities, financing obligations, asset retirement obligations, unearned revenue, tax contingencies, and digital video and music content.
Foreign Currency
We have internationally-focused stores for which the net sales generated, as well as most of the related expenses directly incurred from those operations, are denominated in local functional currencies. The functional currency of our subsidiaries that either operate or support these stores is generally the same as the local currency. Assets and liabilities of these subsidiaries are translated into U.S. Dollars at period-end foreign exchange rates, and revenues and expenses are translated at average rates prevailing throughout the period. Translation adjustments are included in “Accumulated other comprehensive income (loss),” a separate component of stockholders’ equity. Transaction gains and losses including intercompany transactions denominated in a currency other than the functional currency of the entity involved are included in “Other income (expense), net” on our consolidated statements of operations. In connection with the settlement and remeasurement of intercompany balances, we recorded gains (losses) of $(329) million, $413 million, and $(863) million in 2023, 2024, and 2025.
Accounting Pronouncements Recently Adopted
In December 2023, the Financial Accounting Standards Board (“FASB”) issued an Accounting Standards Update (“ASU”) amending existing income tax disclosure guidance, primarily requiring more detailed disclosure for income taxes paid and the effective tax rate reconciliation. We adopted this ASU for the year ended December 31, 2025 on a retroactive basis. See “Note 9 — Income Taxes.”
Accounting Pronouncements Not Yet Adopted
In November 2024, the FASB issued an ASU amending existing income statement disclosure guidance, primarily requiring more detailed disclosure for expenses. The ASU is effective for annual reporting periods beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027, with early adoption permitted. The amendments can be applied on either a prospective or retroactive basis. We are currently evaluating the ASU to determine its impact on our disclosures.
51
Table of Contents
Note 2 — FINANCIAL INSTRUMENTS
Cash, Cash Equivalents, Restricted Cash, and Marketable Securities
As of December 31, 2024 and 2025, our cash, cash equivalents, restricted cash, and marketable securities primarily consisted of cash, AAA-rated money market funds, U.S. government and agency securities, other investment grade securities, and marketable equity securities. Cash equivalents and marketable securities are recorded at fair value. The following table summarizes, by major investment type, our cash, cash equivalents, restricted cash, and marketable securities that are measured at fair value on a recurring basis and are categorized using the fair value hierarchy (in millions):
December 31, 2024
Cost or
Amortized
Cost		Gross
Unrealized
Gains		Gross
Unrealized
Losses		Total
Estimated
Fair Value
Cash and time deposits	$	17,055 			$	— 			$	— 			$	17,055
Level 1:
Money market funds	28,282 			— 			— 			28,282
Equity securities (1)							3,318
Level 2:
U.S. government and agency securities	3,452 			1 			(52)			3,401
Corporate debt securities	50,959 			3 			(50)			50,912
Asset-backed securities	1,539 			2 			(18)			1,523
Other financial instruments	245 			— 			(1)			244
$	101,532 			$	6 			$	(121)			$	104,735
Less: Restricted cash, cash equivalents, and marketable securities (2)							(3,533)
Total cash, cash equivalents, and marketable securities							$	101,202
52
Table of Contents
December 31, 2025
Cost or
Amortized
Cost		Gross
Unrealized
Gains		Gross
Unrealized
Losses		Total
Estimated
Fair Value
Cash and time deposits	$	16,145 			$	— 			$	— 			$	16,145
Level 1:
Money market funds	29,777 			— 			— 			29,777
Equity securities (1)							3,687
Level 2:
U.S. government and agency securities	5,231 			8 			(17)			5,222
Corporate debt securities	69,542 			50 			(7)			69,585
Asset-backed securities	1,781 			8 			(9)			1,780
Other financial instruments	129 			— 			— 			129
$	122,605 			$	66 			$	(33)			$	126,325
Less: Restricted cash, cash equivalents, and marketable securities (2)							(3,296)
Total cash, cash equivalents, and marketable securities							$	123,029
___________________
(1)The related unrealized gain (loss) recorded in “Other income (expense), net” was $1.0 billion, $(1.3) billion, and $1.2 billion for the years ended December 31, 2023, 2024, and 2025.
(2)We are required to pledge or otherwise restrict a portion of our cash, cash equivalents, and marketable debt securities primarily as collateral for real estate, amounts due to third-party sellers in certain jurisdictions, debt, standby and trade letters of credit, and licenses of digital media content. We classify cash, cash equivalents, and marketable debt securities with use restrictions of less than twelve months as “Accounts receivable, net and other” and of twelve months or longer as non-current “Other assets” on our consolidated balance sheets. See “Note 7 — Commitments and Contingencies.”
The following table summarizes gross gains and gross losses realized on sales of marketable debt securities (in millions):
Year Ended December 31,
2023		2024		2025
Realized gains	$	2 			$	3 			$	18
Realized losses	67 			10 			7
The following table summarizes the remaining contractual maturities of our cash equivalents and marketable debt securities as of December 31, 2025 (in millions):
Amortized
Cost		Estimated
Fair Value
Due within one year	$	96,776 			$	96,778
Due after one year through five years	8,217 			8,264
Due after five years through ten years	501 			501
Due after ten years	966 			950
Total	$	106,460 			$	106,493
Actual maturities may differ from the contractual maturities because borrowers may have certain prepayment conditions.
53
Table of Contents
Consolidated Statements of Cash Flows Reconciliation
The following table provides a reconciliation of the amount of cash, cash equivalents, and restricted cash reported within the consolidated balance sheets to the total of the same such amounts shown in the consolidated statements of cash flows (in millions):
December 31, 2024		December 31, 2025
Cash and cash equivalents	$	78,779 			$	86,810
Restricted cash included in accounts receivable, net and other	247 			300
Restricted cash included in other assets	3,286 			2,996
Total cash, cash equivalents, and restricted cash shown in the consolidated statements of cash flows	$	82,312 			$	90,106
Note 3 — PROPERTY AND EQUIPMENT
Property and equipment, at cost, consisted of the following (in millions):
December 31,
2024		2025
Gross property and equipment (1):
Land and buildings	$	123,039 			$	155,121
Servers and networking equipment	113,156 			172,492
Heavy equipment	52,228 			65,545
Other equipment	53,509 			63,376
Other assets	5,487 			5,819
Construction in progress	46,636 			71,745
Gross property and equipment	394,055 			534,098
Total accumulated depreciation and amortization (1)	141,390 			177,073
Total property and equipment, net	$	252,665 			$	357,025
__________________
(1)Includes the original cost and accumulated depreciation of fully-depreciated assets.
Property and equipment acquired but not yet paid are included within “Accounts payable” and were $16.8 billion and $27.0 billion as of December 31, 2024 and 2025.
Depreciation and amortization expense on property and equipment was $30.2 billion, $32.1 billion, and $41.9 billion which includes amortization of property and equipment acquired under finance leases of $5.9 billion, $3.9 billion, and $3.3 billion for 2023, 2024, and 2025.
54
Table of Contents
Note 4 — LEASES
We have entered into non-cancellable operating and finance leases for fulfillment network, data center, office, and physical store facilities as well as server and networking equipment, aircraft, and vehicles. Gross assets acquired under finance leases, including those where title transfers at the end of the lease, are recorded in “Property and equipment, net” and were $56.5 billion and $55.6 billion as of December 31, 2024 and 2025. Accumulated amortization associated with finance leases was $41.8 billion and $40.4 billion as of December 31, 2024 and 2025.
Lease cost recognized in our consolidated statements of operations is summarized as follows (in millions):
Year Ended December 31,
2023		2024		2025
Operating lease cost	$	10,550 			$	11,961 			$	14,006
Finance lease cost:
Amortization of lease assets	5,899 			3,866 			3,284
Interest on lease liabilities	304 			285 			312
Finance lease cost	6,203 			4,151 			3,596
Variable lease cost	2,165 			2,465 			2,694
Total lease cost	$	18,918 			$	18,577 			$	20,296
Other information about lease amounts recognized in our consolidated financial statements is as follows:
December 31, 2024		December 31, 2025
Weighted-average remaining lease term – operating leases	10.6 years		10.0 years
Weighted-average remaining lease term – finance leases	11.9 years		12.6 years
Weighted-average discount rate – operating leases	3.5 	%		3.7 	%
Weighted-average discount rate – finance leases	3.0 	%		3.4 	%
Our lease liabilities were as follows (in millions):
December 31, 2024
Operating Leases		Finance   Leases		Total
Gross lease liabilities	$	95,294 			$	12,520 			$	107,814
Less: imputed interest	(15,698)			(1,918)			(17,616)
Present value of lease liabilities	79,596 			10,602 			90,198
Less: current portion of lease liabilities	(10,546)			(1,375)			(11,921)
Total long-term lease liabilities	$	69,050 			$	9,227 			$	78,277
December 31, 2025
Operating Leases		Finance   Leases		Total
Gross lease liabilities	$	106,914 			$	14,917 			$	121,831
Less: imputed interest	(17,662)			(2,631)			(20,293)
Present value of lease liabilities	89,252 			12,286 			101,538
Less: current portion of lease liabilities	(12,655)			(1,544)			(14,199)
Total long-term lease liabilities	$	76,597 			$	10,742 			$	87,339
55
Table of Contents
Note 5 — ACQUISITIONS, GOODWILL, AND ACQUIRED INTANGIBLE ASSETS
2023 Acquisition Activity
On February 22, 2023, we acquired 1Life Healthcare, Inc. (One Medical), for cash consideration of approximately $3.5 billion, net of cash acquired, to provide healthcare options for customers. The acquired assets primarily consist of $1.3 billion of intangible assets and $2.5 billion of goodwill, which is allocated to our North America segment.
During 2023, we also completed acquisition activity for immaterial aggregate cash consideration, net of cash acquired.
2024 Acquisition Activity
During 2024, we completed acquisition activity for aggregate cash consideration of $780 million, net of cash acquired.
2025 Acquisition Activity
During 2025, we completed acquisition activity for immaterial aggregate cash consideration, net of cash acquired.
The primary reasons for these transactions were to acquire technologies and know-how to enable Amazon to serve customers more effectively or to expand our customer base.
Pro forma results of operations have not been presented because the effects of the 2025 transactions, individually and in the aggregate, were not material to our consolidated results of operations. Transaction-related costs were expensed as incurred and were not significant.
Goodwill
The goodwill resulting from the acquisition activity is primarily related to expected improvements in technology performance and functionality, as well as sales growth from future product and service offerings and new customers, together with certain intangible assets that do not qualify for separate recognition. The goodwill resulting from the acquisition activity is generally not deductible for tax purposes. The following summarizes our goodwill activity in 2024 and 2025 by segment (in millions):
North
America		International		AWS		Consolidated
Goodwill - January 1, 2024	$	19,126 			$	2,412 			$	1,251 			$	22,789
Acquisition activity	191 			77 			52 			320
Other adjustments (1)	(28)			(4)			(3)			(35)
Goodwill - December 31, 2024	19,289 			2,485 			1,300 			23,074
Acquisition activity	25 			85 			2 			112
Other adjustments (1)	49 			8 			30 			87
Goodwill - December 31, 2025	$	19,363 			$	2,578 			$	1,332 			$	23,273
___________________
(1)Primarily includes changes in foreign exchange rates.
56
Table of Contents
Intangible Assets
Acquired identifiable intangible assets are valued primarily by using discounted cash flows. These assets are included within “Other assets” on our consolidated balance sheets and consist of the following (in millions):
December 31,
2024		2025
Acquired
Intangibles,
Gross (1)		Accumulated
Amortization (1)		Acquired
Intangibles,
Net		Acquired
Intangibles,
Gross (1)		Accumulated
Amortization (1)		Acquired
Intangibles,
Net		Weighted
Average Life
Remaining
Finite-lived intangible assets (2):
Marketing-related	$	2,629 			$	(860)			$	1,769 			$	2,402 			$	(754)			$	1,648 			16.5
Contract-based	5,767 			(1,541)			4,226 			7,068 			(1,957)			5,111 			16.6
Technology- and content-based	1,246 			(284)			962 			1,463 			(605)			858 			3.1
Customer-related	764 			(282)			482 			654 			(237)			417 			5.2
Total finite-lived intangible assets	$	10,406 			$	(2,967)			$	7,439 			$	11,587 			$	(3,553)			$	8,034 			14.5
IPR&D and other (3)	$	1,163 			 			$	1,163 			$	1,163 			 			$	1,163
Total acquired intangibles 	$	11,569 			$	(2,967)			$	8,602 			$	12,750 			$	(3,553)			$	9,197
___________________
(1)Excludes the original cost and accumulated amortization of fully-amortized intangibles.
(2)Finite-lived intangible assets, excluding acquired video content, have estimated useful lives of between one and forty years, and are being amortized to operating expenses on a straight-line basis.
(3)Intangible assets acquired in a business combination that are in-process and used in research and development activities (“IPR&D”) are considered indefinite-lived until the completion or abandonment of the research and development efforts. Once the research and development efforts are completed, we reclassify the cost of the IPR&D assets to finite-lived intangible assets, determine the useful life, and begin amortization.
Amortization expense for acquired finite-lived intangibles was $706 million, $838 million, and $817 million in 2023, 2024, and 2025. Expected future amortization expense of acquired finite-lived intangible assets as of December 31, 2025, is as follows (in millions):
Year Ended December 31,
2026	$	1,085
2027	962
2028	764
2029	690
2030	593
Thereafter	3,940
$	8,034
57
Table of Contents
Note 6 — DEBT
As of December 31, 2025, we had $68.0 billion of unsecured senior notes outstanding (the “Notes”), including $15.0 billion issued in November 2025 for general corporate purposes. Our total long-term debt obligations are as follows (in millions):
Maturities (1)		Stated Interest Rates		Effective Interest Rates		December 31, 2024		December 31, 2025
2014 Notes issuance of $6.0 billion	2034 - 2044
4.80% - 4.95%
4.93% - 5.12%		$	2,750 			$	2,750
2017 Notes issuance of $17.0 billion	2027 - 2057
3.15% - 4.25%
3.25% - 4.33%		13,000 			12,000
2020 Notes issuance of $10.0 billion	2027 - 2060
1.20% - 2.70%
1.26% - 2.77%		9,000 			7,750
2021 Notes issuance of $18.5 billion	2026 - 2061
1.00% - 3.25%
1.14% - 3.31%		15,000 			15,000
April 2022 Notes issuance of $12.8 billion	2027 - 2062
3.30% - 4.10%
3.40% - 4.15%		11,250 			9,750
December 2022 Notes issuance of $8.3 billion	2027 - 2032
4.55% - 4.70%
4.61% - 4.74%		7,000 			5,750
2025 Notes issuance of $15.0 billion	2028 - 2065
3.90% - 5.55%
3.99% - 5.62%		— 			15,000
Other long-term debt							— 			836
Total face value of long-term debt							58,000 			68,836
Unamortized discount and issuance costs, net							(360)			(440)
Less: current portion of long-term debt							(5,017)			(2,748)
Long-term debt							$	52,623 			$	65,648
___________________
(1)The weighted-average remaining lives of the 2014, 2017, 2020, 2021, April 2022, December 2022, and 2025 Notes were 14.4, 15.4, 18.1, 13.2, 13.8, 4.4, and 15.6 years as of December 31, 2025. The combined weighted-average remaining life of the Notes was 14.1 years as of December 31, 2025.
Interest on the Notes is payable semi-annually in arrears. We may redeem the Notes at any time in whole, or from time to time, in part at specified redemption prices. We are not subject to any financial covenants under the Notes. The estimated fair value of the Notes was approximately $50.2 billion and $61.1 billion as of December 31, 2024 and 2025, which is based on quoted prices for our debt as of those dates.
As of September 30, 2024, we had repaid outstanding borrowings and terminated the secured revolving credit facility with a lender that was secured by certain seller receivables (the “Credit Facility”). The Credit Facility bore interest based on the daily Secured Overnight Financing Rate plus 1.25%, and had a commitment fee of up to 0.45% on the undrawn portion. There were $682 million of borrowings outstanding under the Credit Facility as of December 31, 2023, which had an interest rate of 6.6%.
As of December 31, 2025, future principal payments for our total long-term debt were as follows (in millions):
Year Ended December 31,
2026	$	2,752
2027	8,832
2028	4,752
2029	3,000
2030	4,500
Thereafter	45,000
$	68,836
In January 2023, we entered into an $8.0 billion unsecured 364-day term loan with a syndicate of lenders (the “Term Loan”), maturing in January 2024 and bearing interest at the Secured Overnight Financing Rate specified in the Term Loan plus 0.75%. The Term Loan was classified as short-term debt and included within “Accrued expenses and other” on our consolidated balance sheets. As of December 31, 2023, the entire amount of the Term Loan had been repaid.
We have U.S. Dollar and Euro commercial paper programs (the “Commercial Paper Programs”) under which we may from time to time issue unsecured commercial paper up to a total of $30.0 billion (including up to €3.0 billion) at the date of issue, with individual maturities that may vary but will not exceed 397 days from the date of issue. In April 2025, we increased the size of the Commercial Paper Programs from $20.0 billion to $30.0 billion. There were no borrowings outstanding under the
58
Table of Contents
Commercial Paper Programs as of December 31, 2024 and 2025. We use the net proceeds from the issuance of commercial paper for general corporate purposes.
We have a $15.0 billion unsecured revolving credit facility with a syndicate of lenders (the “Credit Agreement”), with a term that extends to November 2028 and may be extended for one or more additional one-year terms subject to approval by the lenders. The interest rate applicable to outstanding balances under the Credit Agreement is the applicable benchmark rate specified in the Credit Agreement plus 0.45%, with a commitment fee of 0.03% on the undrawn portion of the credit facility. There were no borrowings outstanding under the Credit Agreement as of December 31, 2024 and 2025.
In October 2025, we entered into a $5.0 billion unsecured 364-day revolving credit facility with a syndicate of lenders (the “Short-Term Credit Agreement”), which replaced the prior 364-day revolving credit agreement entered into in October 2024. The Short-Term Credit Agreement matures in October 2026 and may be extended for one additional period of 364 days subject to approval by the lenders. The interest rate applicable to outstanding balances under the Short-Term Credit Agreement is the Secured Overnight Financing Rate specified in the Short-Term Credit Agreement plus 0.45%, with a commitment fee of 0.03% on the undrawn portion. There were no borrowings outstanding under the Short-Term Credit Agreement or the prior 364-day revolving credit agreement as of December 31, 2024 and 2025.
We also utilize other short-term credit facilities for working capital purposes. There were $151 million and $455 million of borrowings outstanding under these facilities as of December 31, 2024 and 2025, which were included in “Accrued expenses and other” on our consolidated balance sheets. In addition, we had $9.5 billion of unused letters of credit as of December 31, 2025.
Note 7 — COMMITMENTS AND CONTINGENCIES
Commitments
The following summarizes our principal contractual commitments, excluding open orders for purchases that support normal operations and are generally cancellable, as of December 31, 2025 (in millions):
Year Ended December 31,
2026		2027		2028		2029		2030		Thereafter		Total
Long-term debt principal and interest	$	5,201 			$	11,250 			$	6,891 			$	4,993 			$	6,381 			$	73,486 			$	108,202
Operating lease liabilities	15,380 			13,186 			12,140 			10,911 			9,710 			45,587 			106,914
Finance lease liabilities, including interest	1,838 			1,626 			1,726 			1,285 			1,122 			7,320 			14,917
Financing obligations, including interest (1)	577 			582 			592 			601 			612 			6,651 			9,615
Leases not yet commenced	5,808 			9,103 			6,420 			6,571 			6,738 			61,733 			96,373
Unconditional purchase obligations (2)	19,906 			8,934 			7,195 			6,658 			6,602 			35,477 			84,772
Other commitments (3)	2,956 			1,578 			1,120 			1,000 			988 			11,226 			18,868
Total commitments	$	51,666 			$	46,259 			$	36,084 			$	32,019 			$	32,153 			$	241,480 			$	439,661
___________________
(1)Includes non-cancellable financing obligations for fulfillment network and data center facilities. Excluding interest, current financing obligations of $312 million and $358 million are recorded within “Accrued expenses and other” and $7.1 billion and $7.8 billion are recorded within “Other long-term liabilities” as of December 31, 2024 and 2025. The weighted-average remaining term of the financing obligations was 16.1 years and 15.0 years and the weighted-average imputed interest rate was 3.1% and 2.9% as of December 31, 2024 and 2025.
(2)Includes unconditional purchase obligations related to long-term agreements to acquire and license digital media content, procure energy, acquire property and equipment, and license software that are not reflected on the consolidated balance sheets. For those agreements with variable terms or subject to certain regulatory approvals, we do not estimate the total obligation beyond any minimum quantities and/or pricing, or termination penalties, as of the reporting date. Purchase obligations associated with renewal provisions solely at the option of the content provider are included to the extent such commitments are fixed or a minimum amount is specified. Energy agreements based on actual generation without a fixed or minimum volume commitment are not included. Certain of our energy agreements also provide the right to receive energy certificates.
(3)Includes asset retirement obligations, the estimated timing and amounts of payments for rent and tenant improvements associated with build-to-suit lease arrangements that are under construction, and liabilities associated with digital media content agreements with initial terms greater than one year. Excludes approximately $6.6 billion of income tax contingencies for which we cannot make a reasonably reliable estimate of the amount and period of payment, if any.
59
Table of Contents
Suppliers
During 2025, no vendor accounted for 10% or more of our purchases. We generally do not have long-term contracts or arrangements with our vendors to guarantee the availability of merchandise, particular payment terms, or the extension of credit limits.
Other Contingencies
We are disputing claims and denials of refunds or credits, and monitoring or evaluating potential claims, related to various non-income taxes (such as sales, value added, consumption, service, and similar taxes), including in jurisdictions in which we already collect and remit these taxes. These non-income tax controversies typically include (i) the taxability of products and services, including cross-border intercompany transactions, (ii) collection and withholding on transactions with third parties, including as a result of evolving requirements imposed on marketplaces with respect to third-party sellers, and (iii) the adequacy of compliance with reporting obligations, including evolving documentation requirements. Due to the inherent complexity and uncertainty of these matters and the judicial and regulatory processes in certain jurisdictions, the final outcome of any such controversies may be materially different from our expectations.
Legal Proceedings
The Company is involved from time to time in claims, proceedings, and litigation, including the following:
In May 2018, Rensselaer Polytechnic Institute and CF Dynamic Advances LLC filed a complaint against Amazon.com, Inc. in the United States District Court for the Northern District of New York. The complaint alleged, among other things, that “Alexa Voice Software and Alexa enabled devices” infringe U.S. Patent No. 7,177,798. The complaint sought an injunction, an unspecified amount of damages, enhanced damages, an ongoing royalty, interest, attorneys’ fees, and costs. In March 2023, the plaintiffs alleged in their damages report that in the event of a finding of liability Amazon could be subject to $140 million to $267 million in damages. In March 2024, the district court granted summary judgment ruling that the patent is invalid and dismissed the case. In April 2024, the plaintiffs filed a notice of appeal. We dispute the allegations of wrongdoing and will continue to defend ourselves vigorously in this matter.
In December 2018, Kove IO, Inc. filed a complaint against Amazon Web Services, Inc. in the United States District Court for the Northern District of Illinois. The complaint alleged, among other things, that Amazon S3 and DynamoDB infringe U.S. Patent Nos. 7,814,170; 7,103,640; and 7,233,978. The complaint sought an unspecified amount of damages, enhanced damages, attorneys’ fees, costs, interest, and injunctive relief. In April 2024, a jury found that Amazon infringed the asserted patents and awarded Kove $525 million in damages. In August 2024, the court awarded Kove $148 million in pre-judgment interest. In September 2024, we filed a notice of appeal. We disagree with the jury’s findings and will continue to defend ourselves vigorously in this matter.
Beginning in June 2019 with Wilcosky v. Amazon.com, Inc., now pending in the United States District Court for the Northern District of Illinois (“N.D. Ill.”), private litigants have filed a number of cases in U.S. federal and state courts, including Hogan v. Amazon.com, Inc. (N.D. Ill.), alleging, among other things, that Amazon’s collection, storage, use, retention, and protection of biometric identifiers violated the Illinois Biometric Information Privacy Act. The complaints allege purported classes of Illinois residents who had biometric identifiers collected through Amazon products or services, including Amazon Photos, Alexa, AWS cloud services, Amazon Connect, Amazon’s virtual try-on technology, and Amazon’s Just Walk Out technology. The complaints seek certification as class actions, unspecified amounts of damages, injunctive relief, attorneys’ fees, costs, and interest. We dispute the allegations of wrongdoing and intend to defend ourselves vigorously in these matters.
Since March 2020, private litigants, state Attorneys General, and the Federal Trade Commission have filed cases in the U.S., Canada, and the United Kingdom alleging, among other things: price fixing arrangements between each of Amazon and its vendors and Amazon and its third-party sellers; abuse of dominance, monopolization, and attempted monopolization; and consumer protection and unjust enrichment claims, in violation of federal and state antitrust, state consumer protection, and Canadian and U.K. antitrust laws. The first of these complaints was Frame-Wilson v. Amazon.com, Inc., which was filed in the United States District Court for the Western District of Washington (“W.D. Wash.”). These complaints seek billions of dollars of alleged damages, treble damages, punitive damages, injunctive relief, structural relief, civil penalties, attorneys’ fees, and costs. Some of the private plaintiff cases include allegations of distinct purported classes, including consumers who purchased a product through Amazon’s stores and consumers who purchased a product offered by Amazon through another e-commerce retailer. Some of the cases include allegations that Amazon has a monopoly in markets for online superstores, marketplace services, or intermediation services and that we unlawfully engage in anticompetitive practices relating to our pricing policies, selection of the Featured Offers, use of seller data, advertising practices, the structure of Prime, and promotion of our own products on our website. In the U.S., most of Amazon’s motions to dismiss were granted in part, but in each case, at least some of the claims survived. In Canada, class certification was denied in a case before the Federal Court of Canada, finding that plaintiffs had not stated a viable claim, and plaintiffs’ appeal of that ruling is pending. Two Canadian class actions before other
60
Table of Contents
courts are pre-certification. In the United Kingdom, two class actions have been certified and a third is pre-certification. In the U.S., one class action has been certified, and three others are pre-certification. We dispute the allegations of wrongdoing and intend to defend ourselves vigorously in these matters.
In July 2021, the Luxembourg National Commission for Data Protection (the “CNPD”) issued a decision against Amazon Europe Core S.à r.l. claiming that Amazon’s processing of personal data did not comply with the EU General Data Protection Regulation. The decision imposes a fine of €746 million and corresponding practice revisions. In March 2025, the Luxembourg Administrative Court dismissed our appeal of the CNPD’s decision. In April 2025, we appealed the court’s decision to the Luxembourg Administrative Court of Appeal. We believe the CNPD’s decision to be without merit and will continue to defend ourselves vigorously in this matter.
In December 2021, the Italian Competition Authority (the “ICA”) issued a decision against Amazon Services Europe S.à r.l., Amazon Europe Core S.à r.l., Amazon EU S.à r.l., Amazon Italia Services S.r.l., and Amazon Italia Logistica S.r.l. claiming that certain of our marketplace and logistics practices in Italy infringe EU competition rules. The decision imposes remedial actions and a fine of €1.13 billion, which we have paid and will seek to recover pending conclusion of all appeals. In September 2025, the Italian Administrative Tribunal (the “TAR”) affirmed the ICA’s decision but reduced the fine to €752 million. In December 2025, we appealed the TAR’s ruling. We disagree with the TAR’s decision and will continue to defend ourselves vigorously in this matter.
In June 2025, Xockets, Inc. filed two complaints against Amazon.com, Inc. and Amazon Web Services, Inc. in the United States District Court for the Western District of Texas. The complaints allege, among other things, that certain versions of the AWS Nitro System infringe U.S. Patent Nos. 11,080,209; 10,649,924; 11,082,350; 10,223,297; 9,378,161; 9,436,640; and 10,212,092. The complaints seek an unspecified amount of damages, enhanced damages, attorneys’ fees, costs, interest, and injunctive relief. We dispute the allegations of wrongdoing and intend to defend ourselves vigorously in these matters.
Beginning in November 2025, InterDigital, Inc. and related entities filed complaints alleging infringement of patents on video-related technologies against Amazon.com, Inc. and related entities in multiple courts in the United States, Germany, and Brazil, the Unified Patent Court of the European Union, and the United States International Trade Commission. The complaints were filed after Amazon’s August 2025 rate-setting complaint on video-related technologies was filed against InterDigital and related entities in the United Kingdom. InterDigital’s complaints allege, among other things, that certain Amazon Prime Video services and features of Amazon devices carrying the Prime Video app infringe InterDigital’s patents. The complaints seek, among other things, injunctive relief and, in some cases, unspecified money damages, enhanced damages, attorneys’ fees, costs, interest, and declaratory relief. We dispute the allegations of wrongdoing and intend to defend ourselves vigorously in these matters.
In December 2025, Primos Storage Technology LLC filed a complaint against Amazon.com, Inc. and Amazon Web Services, Inc. in the United States District Court for the District of Delaware. The complaint alleges, among other things, that Amazon S3, Amazon EMR, Amazon EC2 instances using Amazon EBS, and Amazon FSx for Lustre infringe U.S. Patent Nos. 7,386,663; 7,937,528; and 10,599,344, and that Amazon S3 and Amazon EMR infringe U.S. Patent Nos. 8,078,944 and 8,312,356. The complaint seeks injunctive relief, an ongoing royalty, an unspecified amount of damages, enhanced damages, attorneys’ fees, costs, and interest. We dispute the allegations of wrongdoing and intend to defend ourselves vigorously in this matter.
In addition, we are regularly subject to claims, litigation, and other proceedings, including potential regulatory proceedings, involving patent and other intellectual property matters, taxes, labor and employment, competition and antitrust, privacy and data protection, consumer protection, commercial disputes, goods and services offered by us and by third parties, and other matters.
The outcomes of our legal proceedings and other contingencies are inherently unpredictable, subject to significant uncertainties, and could be material to our operating results and cash flows for a particular period. We evaluate, on a regular basis, developments in our legal proceedings and other contingencies that could affect the amount of liability, including amounts in excess of any previous accruals and reasonably possible losses disclosed, and make adjustments and changes to our accruals and disclosures as appropriate. For the matters we disclose that do not include an estimate of the amount of loss or range of losses, such an estimate is not possible or is immaterial, and we may be unable to estimate the possible loss or range of losses that could potentially result from the application of non-monetary remedies. Until the final resolution of such matters, if any of our estimates and assumptions change or prove to have been incorrect, we may experience losses in excess of the amounts recorded, which could have a material effect on our business, consolidated financial position, results of operations, or cash flows.
See also “Note 9 — Income Taxes.”
61
Table of Contents
Note 8 — STOCKHOLDERS’ EQUITY
Preferred Stock
We have authorized 500 million shares of $0.01 par value preferred stock. No preferred stock was outstanding for any year presented.
Common Stock
Common shares outstanding plus shares underlying outstanding stock awards totaled 10.8 billion, 10.9 billion, and 11.0 billion, as of December 31, 2023, 2024, and 2025. These totals include all vested and unvested stock awards outstanding, including those awards we estimate will be forfeited.
Stock Repurchase Activity
In March 2022, the Board of Directors authorized a program to repurchase up to $10.0 billion of our common stock, with no fixed expiration. There were no repurchases of our common stock in 2023, 2024, or 2025. As of December 31, 2025, we have $6.1 billion remaining under the repurchase program.
Stock Award Plans
Employees vest in restricted stock unit awards over the corresponding service term, generally between two and five years. The majority of outstanding restricted stock unit awards are granted at the date of hire or in Q2 as part of the annual compensation review and primarily vest quarterly in the relevant compensation year.
Stock Award Activity
Stock-based compensation expense is as follows (in millions):
Year Ended December 31,
2023		2024		2025
Cost of sales	$	836 			$	838 			$	777
Fulfillment	3,090 			2,973 			2,703
Technology and infrastructure	13,434 			12,150 			10,871
Sales and marketing	4,623 			4,084 			3,445
General and administrative	2,040 			1,966 			1,671
Total stock-based compensation expense (1)	$	24,023 			$	22,011 			$	19,467
___________________
(1)The related tax benefits were $5.4 billion, $5.0 billion, and $4.4 billion for 2023, 2024, and 2025.
The following table summarizes our restricted stock unit activity (in millions):
Number of Units		Weighted Average
Grant-Date
Fair Value
Outstanding as of January 1, 2023	384.4 			$	144
Units granted	218.1 			106
Units vested	(139.9)			143
Units forfeited	(56.8)			135
Outstanding as of December 31, 2023	405.8 			125
Units granted	126.9 			183
Units vested	(209.7)			132
Units forfeited	(39.9)			133
Outstanding as of December 31, 2024	283.1 			145
Units granted	112.9 			200
Units vested	(138.1)			135
Units forfeited	(35.4)			157
Outstanding as of December 31, 2025	222.5 			178
62
Table of Contents
Scheduled vesting for outstanding restricted stock units as of December 31, 2025, is as follows (in millions):
Year Ended
2026		2027		2028		2029		2030		Thereafter		Total
Scheduled vesting — restricted stock units	110.4 			69.9 			30.7 			9.8 			0.8 			0.9 			222.5
As of December 31, 2025, there was $16.9 billion of net unrecognized compensation cost related to unvested stock-based compensation arrangements. This compensation is recognized on an accelerated basis with more than half of the compensation expected to be expensed in the next twelve months, and has a remaining weighted-average recognition period of 1.0 year.
During 2023, 2024, and 2025, the fair value of restricted stock units that vested was $17.6 billion, $39.6 billion, and $30.0 billion.
Common Stock Available for Future Issuance
As of December 31, 2025, common stock available for future issuance to employees is 1.4 billion shares.
Accumulated Other Comprehensive Income (Loss)
The following table summarizes the changes in “Accumulated other comprehensive income (loss)” by separate components (in millions):
December 31,
2024		2025
Total beginning accumulated other comprehensive income (loss), net of tax of $99 and $(1,762)	$	(3,040)			$	(34)
Foreign currency translation adjustments:
Beginning of year balance, net of tax of $66 and $292	(2,841)			(6,174)
Foreign currency translation adjustments, net of tax of $226 and $(194)	(3,333)			4,226
End of year balance, net of tax of $292 and $98	(6,174)			(1,948)
Unrealized gains (losses) on available-for-sale debt securities:
Beginning of year balance, net of tax of $34 and $(2,054)	(205)			6,139
Change in net unrealized gains (losses), net of tax of $(2,086) and $(8,754)	6,339 			28,304
Reclassification adjustment for net losses (gains) included in “Other income (expense), net,” net of tax of $(2) and $1,327	5 			(4,273)
End of year balance, net of tax of $(2,054) and $(9,481)	6,139 			30,170
Other:
Beginning of year balance, net of tax of $(1) and $0	6		1
Other, net of tax of $1 and $(1)	(5)			7
End of year balance, net of tax of $0 and $(1)	1 			8
Total ending accumulated other comprehensive income (loss), net of tax of $(1,762) and $(9,384)	$	(34)			$	28,230
Note 9 — INCOME TAXES
In 2023, 2024, and 2025, we recorded a net tax provision of $7.1 billion, $9.3 billion, and $19.1 billion. Our U.S. taxable income is reduced by accelerated depreciation deductions and the resulting U.S. tax liability is reduced by tax credits, primarily related to the U.S. federal research and development credit. Cash paid for income taxes, net of refunds, was $11.2 billion, $12.3 billion, and $8.3 billion for 2023, 2024, and 2025.
63
Table of Contents
The 2025 Tax Act was signed into law on July 4, 2025. The 2025 Tax Act makes changes to the U.S. corporate income tax, including reinstating the option to claim 100% accelerated depreciation deductions on qualified property, with retroactive application beginning January 20, 2025, and immediate expensing of domestic research and development costs, with retroactive application beginning January 1, 2025. For 2025, the 2025 Tax Act increased our income tax provision, primarily due to a decrease in the foreign income deduction, and significantly decreased our cash taxes.
The components of cash paid for income taxes, net of refunds, are as follows (in millions):
Year Ended December 31,
2023		2024		2025
U.S. Federal	$	7,435 			$	7,630 			$	2,751
U.S. State	2,070 			2,450 			2,125
International	1,674 			2,228 			3,419
Total cash taxes paid, net of refunds	$	11,179 			$	12,308 			$	8,295
Certain foreign subsidiary earnings and losses are subject to current U.S. taxation and the subsequent repatriation of those earnings is not subject to tax in the U.S.
The components of the provision for income taxes, net are as follows (in millions):
Year Ended December 31,
2023		2024		2025
U.S. Federal:
Current	$	8,652 			$	9,039 			$	1,220
Deferred	(5,505)			(4,101)			11,134
Total	3,147 			4,938 			12,354
U.S. State:
Current	2,158 			2,109 			2,067
Deferred	(498)			(453)			984
Total	1,660 			1,656 			3,051
International:
Current	2,186 			2,765 			4,330
Deferred	127 			(94)			(648)
Total	2,313 			2,671 			3,682
Provision for income taxes, net	$	7,120 			$	9,265 			$	19,087
U.S. and international components of income before income taxes are as follows (in millions):
Year Ended December 31,
2023		2024		2025
U.S.	$	32,328 			$	61,947 			$	89,537
International	5,229 			6,667 			7,774
Income before income taxes	$	37,557 			$	68,614 			$	97,311
64
Table of Contents
The items accounting for differences between income taxes computed at the federal statutory rate and the provision recorded for income taxes are as follows (in millions, except percentages):
Year Ended December 31,
2023		2024		2025
Income taxes computed at the federal statutory rate	$	7,887 			21.0 	%		$	14,409 			21.0 	%		$	20,435 			21.0 	%
Federal:
Tax credits:
Research and development tax credits	(2,196)			(5.8)			(2,644)			(3.9)			(2,403)			(2.5)
Foreign tax credits	(558)			(1.5)			(440)			(0.6)			(642)			(0.7)
Other credits	(185)			(0.5)			(176)			(0.3)			(139)			(0.1)
Effect of cross-border tax laws:
Foreign income deduction (1)	(1,429)			(3.8)			(2,379)			(3.5)			(522)			(0.5)
Other effects of cross-border tax laws	(18)			— 			(33)			— 			(271)			(0.3)
Nontaxable and nondeductible items:
Stock-based compensation (2)	784 			2.1 			(2,236)			(3.3)			(2,029)			(2.1)
Other nontaxable and nondeductible items 	162 			0.4 			158 			0.3 			372 			0.4
Other	186 			0.5 			33 			— 			486 			0.5
State and local income taxes, net of federal effect (3)	1,292 			3.4 			1,321 			1.9 			2,455 			2.5
Foreign tax effects	1,117 			3.0 			1,150 			1.7 			1,517 			1.6
Worldwide changes in prior period unrecognized tax benefits	78 			0.2 			102 			0.2 			(172)			(0.2)
Total	$	7,120 			19.0 	%		$	9,265 			13.5 	%		$	19,087 			19.6 	%
___________________
(1)U.S. companies are eligible for a deduction that lowers the effective tax rate on certain foreign income. This regime is referred to as the Foreign-Derived Intangible Income deduction and is dependent on the amount of our U.S. taxable income.
(2)Includes amounts related to non-taxable and non-deductible stock-based compensation, in addition to excess tax benefits or shortfalls from stock-based compensation. Our tax provision includes $519 million of tax shortfalls from stock-based compensation for 2023, and $2.8 billion and $2.6 billion of excess tax benefits from stock-based compensation for 2024 and 2025.
(3)The jurisdictions that contribute to the majority of the tax effect in this category are Illinois, Maryland, New Jersey, New York, Pennsylvania, and Virginia.
Our provision for income taxes in 2024 was higher than in 2023 primarily due to an increase in pretax income, partially offset by an increase in excess tax benefits from stock-based compensation and an increase in our foreign income deduction.
Our provision for income taxes in 2025 was higher than in 2024 primarily due to an increase in pretax income and a decrease in foreign income deduction resulting from the effects of the 2025 Tax Act.
We intend to invest substantially all of our foreign subsidiary earnings, as well as our capital in our foreign subsidiaries, indefinitely outside of the U.S. in those jurisdictions in which we would incur significant, additional costs upon repatriation of such amounts.
65
Table of Contents
Deferred income tax assets and liabilities are as follows (in millions):
December 31,
2024		2025
Deferred tax assets (1):
Loss carryforwards U.S. - Federal/States	$	692 			$	632
Loss carryforwards - Foreign	2,687 			2,936
Accrued liabilities, reserves, and other expenses	4,254 			5,545
Stock-based compensation	4,089 			4,295
Depreciation and amortization	1,133 			1,503
Operating lease liabilities	20,921 			23,596
Capitalized research and development	22,701 			18,725
Other items	1,688 			2,166
Tax credits	1,773 			2,812
Total gross deferred tax assets	59,938 			62,210
Less valuation allowances (2)	(4,893)			(5,560)
Deferred tax assets, net of valuation allowances	55,045 			56,650
Deferred tax liabilities:
Depreciation and amortization	(16,240)			(23,159)
Operating lease assets	(19,517)			(22,177)
Assets held for investment	(2,133)			(13,149)
Other items	(1,190)			(1,159)
Net deferred tax assets (liabilities), net of valuation allowances	$	15,965 			$	(2,994)
___________________
(1)Deferred tax assets are presented after tax effects and net of tax contingencies.
(2)Relates primarily to deferred tax assets that would only be realizable upon the generation of net income in certain foreign taxing jurisdictions or future capital gains, as well as tax credits.
Our valuation allowances primarily relate to foreign deferred tax assets, including substantially all of our foreign net operating loss carryforwards as of December 31, 2025. Our foreign net operating loss carryforwards for income tax purposes as of December 31, 2025 were approximately $10.6 billion before tax effects and certain of these amounts are subject to annual limitations under applicable tax law. If not utilized, a portion of these losses will begin to expire in 2026.
Income Tax Contingencies
We are subject to income taxes in the U.S. (federal and state) and numerous foreign jurisdictions. Significant judgment is required in evaluating our tax positions and determining our provision for income taxes. During the ordinary course of business, there are many transactions and calculations for which the ultimate tax determination is uncertain. We establish reserves for tax-related uncertainties based on estimates of whether, and the extent to which, additional taxes will be due. These reserves are established when we believe that certain positions might be challenged despite our belief that our tax return positions are fully supportable. We adjust these reserves in light of changing facts and circumstances, such as the outcome of tax audits. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate.
66
Table of Contents
The reconciliation of our income tax contingencies is as follows (in millions):
December 31,
2023		2024		2025
Gross tax contingencies – January 1	$	4,002 			$	5,228 			$	6,485
Gross increases to tax positions in prior periods	440 			154 			310
Gross decreases to tax positions in prior periods	(38)			(129)			(1,180)
Gross increases to current period tax positions	1,009 			1,392 			1,292
Settlements with tax authorities	(106)			(9)			(312)
Lapse of statute of limitations	(79)			(151)			(29)
Gross tax contingencies – December 31 (1)	$	5,228 			$	6,485 			$	6,566
___________________
(1)As of December 31, 2025, we had approximately $6.6 billion of income tax contingencies of which $5.0 billion, if fully recognized, would decrease our effective tax rate.
As of December 31, 2024 and 2025, we had accrued interest and penalties, net of federal income tax benefit, related to tax contingencies of $316 million and $400 million. Interest and penalties, net of federal income tax benefit, recognized for the years ended December 31, 2023, 2024, and 2025 were $91 million, $121 million, and $84 million.
We are under examination, or may be subject to examination, by the Internal Revenue Service for the calendar year 2016 and thereafter. These examinations may lead to ordinary course adjustments or proposed adjustments to our taxes or our net operating losses with respect to years under examination as well as subsequent periods.
We are also subject to taxation in various states and foreign jurisdictions including Germany, India, Japan, Luxembourg, and the United Kingdom. We are under, or may be subject to, audit or examination and additional assessments by the relevant authorities in respect of these particular jurisdictions primarily for 2011 and thereafter. We are currently disputing tax assessments in multiple jurisdictions, including with respect to the allocation and characterization of income.
In September 2022, the Luxembourg tax authority (“LTA”) denied the tax basis of certain intangible assets that we distributed from Luxembourg to the U.S. in 2021. When we are assessed by the LTA, we will need to remit taxes related to this matter. We believe the LTA’s position is without merit, we intend to defend ourselves vigorously in this matter, and we expect to recoup taxes paid.
The Indian tax authority (“ITA”) has asserted that tax applies to cloud services fees paid to Amazon in the U.S. We will need to remit taxes related to this matter until it is resolved, which payments could be significant in the aggregate. We believe the ITA’s position is without merit, we are defending our position vigorously, and we expect to recoup taxes paid. If this matter is adversely resolved, we could recognize significant additional tax expense, including for taxes previously paid.
Changes in tax laws, regulations, administrative practices, principles, and interpretations may impact our tax contingencies. Due to various factors, including the inherent complexities and uncertainties of the judicial, administrative, and regulatory processes in certain jurisdictions, the timing of the resolution of income tax controversies is highly uncertain, and the amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ from the amounts accrued.
Note 10 — SEGMENT INFORMATION
We have organized our operations into three segments: North America, International, and AWS. We allocate to segment results the operating expenses “Fulfillment,” “Technology and infrastructure,” “Sales and marketing,” and “General and administrative” based on usage, which is generally reflected in the segment in which the costs are incurred. The majority of technology costs recorded in “Technology and infrastructure” are incurred in the U.S. and are included in our North America and AWS segments. The majority of infrastructure costs recorded in “Technology and infrastructure” are allocated to the AWS segment based on usage. There are no internal revenue transactions between our reportable segments. Our chief operating decision maker (“CODM”) is our President and Chief Executive Officer. Our CODM regularly reviews consolidated net sales, consolidated operating expenses, and consolidated operating income (loss) by segment. Amounts included in consolidated operating expenses include “Cost of sales,” “Fulfillment,” “Technology and infrastructure,” “Sales and marketing,” “General and administrative,” and “Other operating expense (income), net.” Our CODM manages our business primarily by reviewing consolidated results by segment on a quarterly basis, and using those results along with forecasts and other non-financial information in our annual budgeting process.
67
Table of Contents
North America
The North America segment primarily consists of amounts earned from retail sales of consumer products (including from sellers) and advertising and subscription services through North America-focused online and physical stores. This segment includes export sales from these online stores.
International
The International segment primarily consists of amounts earned from retail sales of consumer products (including from sellers) and advertising and subscription services through internationally-focused online stores. This segment includes export sales from these internationally-focused online stores (including export sales from these online stores to customers in the U.S., Mexico, and Canada), but excludes export sales from our North America-focused online stores.
AWS
The AWS segment consists of amounts earned from global sales of compute, storage, database, and other services for start-ups, enterprises, government agencies, and academic institutions.
Information on reportable segments and reconciliation to consolidated net income is as follows (in millions):
Year Ended December 31,
2023		2024		2025
North America
Net sales	$	352,828 			$	387,497 			$	426,305
Operating expenses	337,951 			362,530 			396,686
Operating income	$	14,877 			$	24,967 			$	29,619
International
Net sales	$	131,200 			$	142,906 			$	161,894
Operating expenses	133,856 			139,114 			157,144
Operating income (loss)	$	(2,656)			$	3,792 			$	4,750
AWS
Net sales	$	90,757 			$	107,556 			$	128,725
Operating expenses	66,126 			67,722 			83,119
Operating income	$	24,631 			$	39,834 			$	45,606
Consolidated
Net sales	$	574,785 			$	637,959 			$	716,924
Operating expenses	537,933 			569,366 			636,949
Operating income	36,852 			68,593 			79,975
Total non-operating income	705 			21 			17,336
Provision for income taxes	(7,120)			(9,265)			(19,087)
Equity-method investment activity, net of tax	(12)			(101)			(554)
Net income	$	30,425 			$	59,248 			$	77,670
68
Table of Contents
Net sales by groups of similar products and services, which also have similar economic characteristics, is as follows (in millions):
Year Ended December 31,
2023		2024		2025
Net Sales:
Online stores (1)	$	231,872 			$	247,029 			$	269,287
Physical stores (2)	20,030 			21,215 			22,561
Third-party seller services (3)	140,053 			156,146 			172,162
Advertising services (4)	46,906 			56,214 			68,635
Subscription services (5)	40,209 			44,374 			49,619
AWS	90,757 			107,556 			128,725
Other (6)	4,958 			5,425 			5,935
Consolidated	$	574,785 			$	637,959 			$	716,924
___________________
(1)Includes product sales and digital media content where we record revenue gross. We leverage our retail infrastructure to offer a wide selection of consumable and durable goods that includes media products available in both a physical and digital format, such as books, videos, games, music, and software. These product sales include digital products sold on a transactional basis. Digital media content subscriptions that provide unlimited viewing or usage rights are included in “Subscription services.”
(2)Includes product sales where our customers physically select items in a store. Sales to customers who order goods online for delivery or pickup at our physical stores are included in “Online stores.”
(3)Includes commissions and any related fulfillment and shipping fees, and other third-party seller services.
(4)Includes sales of advertising services to sellers, vendors, publishers, authors, and others, through programs such as sponsored ads, display, and video advertising.
(5)Includes annual and monthly fees associated with Amazon Prime memberships, as well as digital video, audiobook, digital music, e-book, and other non-AWS subscription services.
(6)Includes sales related to various other offerings (such as shipping services, healthcare services, and certain licensing and distribution of video content) and our co-branded credit card agreements.
Net sales are attributed to countries primarily based on country-focused online and physical stores or, for AWS purposes, the selling entity.
Net sales attributed to countries that represent a significant portion of consolidated net sales are as follows (in millions):
Year Ended December 31,
2023		2024		2025
United States	$	395,637 			$	438,015 			$	489,657
Germany	37,588 			40,856 			45,900
United Kingdom	33,591 			37,855 			43,212
Japan	26,002 			27,401 			30,688
Rest of world	81,967 			93,832 			107,467
Consolidated	$	574,785 			$	637,959 			$	716,924
69
Table of Contents
Total segment assets exclude corporate assets, such as cash and cash equivalents, marketable securities, other long-term investments, corporate facilities, goodwill and other acquired intangible assets, and tax assets. Technology infrastructure assets, which are included in property and equipment, net, net additions, and the depreciation and amortization expense on these assets, are allocated among the segments based on usage, with the majority allocated to the AWS segment. Usage of technology infrastructure assets by the North America and International segments, and the related allocation of total net additions, can fluctuate on a quarter-to-quarter basis, and is affected by seasonality, peak periods, new product or service offerings, and other factors.
Total segment assets reconciled to consolidated amounts are as follows (in millions):
December 31,
2023		2024		2025
North America (1)	$	196,029 			$	210,120 			$	235,652
International (1)	69,718 			69,487 			81,984
AWS (2)	108,533 			155,953 			252,588
Corporate	153,574 			189,334 			247,818
Consolidated	$	527,854 			$	624,894 			$	818,042
___________________
(1)North America and International segment assets primarily consist of property and equipment, operating leases, inventory, accounts receivable, and digital video and music content.
(2)AWS segment assets primarily consist of property and equipment, accounts receivable, and operating leases.
Property and equipment, net by segment is as follows (in millions):
December 31,
2023		2024		2025
North America	$	93,632 			$	103,041 			$	122,043
International	24,357 			25,618 			30,632
AWS	72,701 			110,683 			190,055
Corporate	13,487 			13,323 			14,295
Consolidated	$	204,177 			$	252,665 			$	357,025
Total net additions to property and equipment include technology infrastructure assets and the effect of non-cash activity such as property and equipment acquired but not yet paid.
Total net additions to property and equipment are as follows (in millions):
Year Ended December 31,
2023		2024		2025
North America (1)	$	17,529 			$	24,348 			$	35,919
International (1)	4,144 			6,643 			7,617
AWS (2)	24,843 			53,267 			96,496
Corporate	1,828 			1,494 			2,320
Consolidated	$	48,344 			$	85,752 			$	142,352
___________________
(1)Includes property and equipment added under finance leases of $525 million, $616 million, and $1.0 billion in 2023, 2024, and 2025, and under build-to-suit lease arrangements of $356 million, $89 million, and $20 million in 2023, 2024, and 2025.
(2)Includes property and equipment added under finance leases of $117 million, $238 million, and $1.9 billion in 2023, 2024, and 2025, and under build-to-suit lease arrangements of $1 million, $8 million, and $421 million in 2023, 2024, and 2025.
U.S. property and equipment, net and operating leases were $196.0 billion, $241.6 billion, and $321.9 billion, as of December 31, 2023, 2024, and 2025, and non-U.S. property and equipment, net and operating leases were $80.7 billion, $87.2 billion, and $121.2 billion as of December 31, 2023, 2024, and 2025. Except for the U.S., property and equipment, net and operating leases in any single country were less than 10% of consolidated property and equipment, net and operating leases.
70
Table of Contents
Depreciation and amortization expense on property and equipment, including corporate property and equipment, are allocated to all segments based on usage.
Total depreciation and amortization expense, by segment, is as follows (in millions):
Year Ended December 31,
2023		2024		2025
North America	$	13,678 			$	14,285 			$	15,503
International	4,016 			4,462 			4,907
AWS	12,531 			13,320 			21,450
Consolidated	$	30,225 			$	32,067 			$	41,860
71
Table of Contents
Item 9.	Changes in and Disagreements with Accountants On Accounting and Financial Disclosure
None.
Item 9A.	Controls and Procedures
Evaluation of Disclosure Controls and Procedures
We carried out an evaluation required by the Securities Exchange Act of 1934 (the “1934 Act”), under the supervision and with the participation of our principal executive officer and principal financial officer, of the effectiveness of the design and operation of our disclosure controls and procedures, as defined in Rule 13a-15(e) of the 1934 Act, as of December 31, 2025. Based on this evaluation, our principal executive officer and principal financial officer concluded that, as of December 31, 2025, our disclosure controls and procedures were effective to provide reasonable assurance that information required to be disclosed by us in the reports that we file or submit under the 1934 Act is recorded, processed, summarized, and reported within the time periods specified in the SEC’s rules and forms and to provide reasonable assurance that such information is accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.
Management’s Report on Internal Control over Financial Reporting
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as defined in Rule 13a-15(f) of the 1934 Act. Management has assessed the effectiveness of our internal control over financial reporting as of December 31, 2025 based on criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. As a result of this assessment, management concluded that, as of December 31, 2025, our internal control over financial reporting was effective in providing reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. Ernst & Young has independently assessed the effectiveness of our internal control over financial reporting and its report is included below.
Changes in Internal Control Over Financial Reporting
There were no changes in our internal control over financial reporting during the quarter ended December 31, 2025 that materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
Limitations on Controls
Our disclosure controls and procedures and internal control over financial reporting are designed to provide reasonable assurance of achieving their objectives as specified above. Management does not expect, however, that our disclosure controls and procedures or our internal control over financial reporting will prevent or detect all error and fraud. Any control system, no matter how well designed and operated, is based upon certain assumptions and can provide only reasonable, not absolute, assurance that its objectives will be met. Further, no evaluation of controls can provide absolute assurance that misstatements due to error or fraud will not occur or that all control issues and instances of fraud, if any, within the Company have been detected.
72
Table of Contents
Report of Independent Registered Public Accounting Firm
The Board of Directors and Shareholders
Amazon.com, Inc.
Opinion on Internal Control Over Financial Reporting
We have audited Amazon.com, Inc.’s internal control over financial reporting as of December 31, 2025, based on criteria established in Internal Control-Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) (the COSO criteria). In our opinion, Amazon.com, Inc. (the Company) maintained, in all material respects, effective internal control over financial reporting as of December 31, 2025, based on the COSO criteria.
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated balance sheets of the Company as of December 31, 2025 and 2024, the related consolidated statements of operations, comprehensive income, stockholders’ equity, and cash flows for each of the three years in the period ended December 31, 2025, and the related notes and our report dated February 5, 2026 expressed an unqualified opinion thereon.
Basis for Opinion
The Company’s management is responsible for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects.
Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.
Definition and Limitations of Internal Control Over Financial Reporting
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.
/s/ Ernst & Young LLP
Seattle, Washington
February 5, 2026
73
Table of Contents
Item 9B.	Other Information
On November 3, 2025, David A. Zapolsky, Senior Vice President, Chief Global Affairs and Legal Officer, adopted a trading plan intended to satisfy Rule 10b5-1(c) to sell up to 64,059 shares of Amazon.com, Inc. common stock over a period ending on November 30, 2026, subject to certain conditions.
On November 10, 2025, Douglas J. Herrington, CEO Worldwide Amazon Stores, adopted a trading plan intended to satisfy Rule 10b5-1(c) to sell up to 132,937 shares of Amazon.com, Inc. common stock over a period ending on December 31, 2026, subject to certain conditions.
On November 11, 2025, Keith B. Alexander, a member of our Board of Directors, adopted a trading plan intended to satisfy Rule 10b5-1(c) to sell up to 1,800 shares of Amazon.com, Inc. common stock over a period ending on November 4, 2026, subject to certain conditions.
On November 11, 2025, Shelley L. Reynolds, Vice President, Worldwide Controller, adopted a trading plan intended to satisfy Rule 10b5-1(c) to sell up to 9,744 shares of Amazon.com, Inc. common stock over a period ending on November 29, 2026, subject to certain conditions.
On November 14, 2025, Andrew R. Jassy, President and Chief Executive Officer, adopted a trading plan intended to satisfy Rule 10b5-1(c) to sell up to 142,224 shares of Amazon.com, Inc. common stock over a period ending on December 31, 2026, subject to certain conditions.
On November 14, 2025, Jeffrey P. Bezos, our founder and Executive Chair, adopted a trading plan intended to satisfy Rule 10b5-1(c) to sell up to 15,000,000 shares of Amazon.com, Inc. common stock over a period ending on February 26, 2027, subject to certain conditions.
On November 19, 2025, Brian T. Olsavsky, Senior Vice President and Chief Financial Officer, terminated a trading plan intended to satisfy Rule 10b5-1(c) initially adopted on May 20, 2025 to sell up to 53,249 shares of Amazon.com, Inc. common stock over a period ending on March 2, 2026.
Item 9C.	Disclosure Regarding Foreign Jurisdictions that Prevent Inspections
Not applicable.
PART III
Item 10.
Directors, Executive Officers, and Corporate Governance
Information regarding our Executive Officers required by Item 10 of Part III is set forth in Item 1 of Part I “Business — Information About Our Executive Officers.” Information required by Item 10 of Part III regarding our Directors and Executive Officers, as applicable, and any material changes to the process by which security holders may recommend nominees to the Board of Directors is included in our Proxy Statement relating to our 2026 Annual Meeting of Shareholders, and is incorporated herein by reference. Information relating to our Code of Business Conduct and Ethics, insider trading policies and procedures, and, to the extent applicable, compliance with Section 16(a) of the 1934 Act is set forth in our Proxy Statement relating to our 2026 Annual Meeting of Shareholders and is incorporated herein by reference. To the extent permissible under Nasdaq rules, we intend to disclose amendments to our Code of Business Conduct and Ethics, as well as waivers of the provisions thereof, on our investor relations website under the heading “Corporate Governance” at amazon.com/ir.
Item 11.
Executive Compensation
Information required by Item 11 of Part III is included in our Proxy Statement relating to our 2026 Annual Meeting of Shareholders and is incorporated herein by reference.
Item 12.
Security Ownership of Certain Beneficial Owners and Management and Related Shareholder Matters
Information required by Item 12 of Part III is included in our Proxy Statement relating to our 2026 Annual Meeting of Shareholders and is incorporated herein by reference.
74
Table of Contents
Item 13.
Certain Relationships and Related Transactions, and Director Independence
Information required by Item 13 of Part III is included in our Proxy Statement relating to our 2026 Annual Meeting of Shareholders and is incorporated herein by reference.
Item 14.
Principal Accountant Fees and Services
Information required by Item 14 of Part III is included in our Proxy Statement relating to our 2026 Annual Meeting of Shareholders and is incorporated herein by reference.
75
Table of Contents
PART IV
Item 15.
Exhibits, Financial Statement Schedules
(a) List of Documents Filed as a Part of This Report:
(1) Index to Consolidated Financial Statements:
Report of Ernst & Young LLP, Independent Registered Public Accounting Firm
Consolidated Statements of Cash Flows for each of the three years ended December 31, 2025
Consolidated Statements of Operations for each of the three years ended December 31, 2025
Consolidated Statements of Comprehensive Income for each of the three years ended December 31, 2025
Consolidated Balance Sheets as of December 31, 2024 and 2025
Consolidated Statements of Stockholders’ Equity for each of the three years ended December 31, 2025
Notes to Consolidated Financial Statements
Report of Ernst & Young LLP, Independent Registered Public Accounting Firm
(2) Index to Financial Statement Schedules:
All schedules have been omitted because the required information is included in the consolidated financial statements or the notes thereto, or because it is not required.
(3) Index to Exhibits
See exhibits listed under Part (b) below.
(b) Exhibits:
Exhibit Number		Description
3.1
Amended and Restated Certificate of Incorporation of Amazon.com, Inc. (incorporated by reference to the Company’s Current Report on Form 8-K, filed May 27, 2022).
3.2
Amended and Restated Bylaws of Amazon.com, Inc. (incorporated by reference to the Company’s Current Report on Form 8-K, filed May 3, 2024).
4.1
Indenture, dated as of November 29, 2012, between Amazon.com, Inc. and Wells Fargo Bank, National Association, as trustee (incorporated by reference to the Company’s Current Report on Form 8-K, filed November 29, 2012).
4.2
Supplemental Indenture, dated as of April 13, 2022, among Amazon.com, Inc., Wells Fargo Bank, National Association, as prior trustee, and Computershare Trust Company, National Association, as successor trustee, containing Form of 2.730% Note due 2024, Form of 3.000% Note due 2025, Form of 3.300% Note due 2027, Form of 3.450% Note due 2029, Form of 3.600% Note due 2032, Form of 3.950% Note due 2052, and Form of 4.100% Note due 2062 (incorporated by reference to the Company’s Current Report on Form 8-K, filed April 13, 2022).
4.3
Officers’ Certificate of Amazon.com, Inc., dated as of December 5, 2014, containing Form of 2.600% Note due 2019, Form of 3.300% Note due 2021, Form of 3.800% Note due 2024, Form of 4.800% Note due 2034, and Form of 4.950% Note due 2044 (incorporated by reference to the Company’s Current Report on Form 8-K, filed December 5, 2014).
4.4
Officers’ Certificate of Amazon.com, Inc., dated as of August 22, 2017, containing Form of 1.900% Note due 2020, Form of 2.400% Note due 2023, Form of 2.800% Note due 2024, Form of 3.150% Note due 2027, Form of 3.875% Note due 2037, Form of 4.050% Note due 2047, and Form of 4.250% Note due 2057 (incorporated by reference to the Company’s Current Report on Form 8-K, filed August 22, 2017).
4.5
Officers’ Certificate of Amazon.com, Inc., dated as of June 3, 2020, containing Form of 0.400% Note due 2023, Form of 0.800% Note due 2025, Form of 1.200% Note due 2027, Form of 1.500% Note due 2030, Form of 2.500% Note due 2050, and Form of 2.700% Note due 2060 (incorporated by reference to the Company’s Current Report on Form 8-K, filed June 3, 2020).
76
Table of Contents
4.6
Officers’ Certificate of Amazon.com, Inc., dated as of May 12, 2021, containing Form of 0.250% Note due 2023, Form of 0.450% Note due 2024, Form of 1.000% Note due 2026, Form of 1.650% Note due 2028, Form of 2.100% Note due 2031, Form of 2.875% Note due 2041, Form of 3.100% Note due 2051, and Form of 3.250% Note due 2061 (incorporated by reference to the Company’s Current Report on Form 8-K, filed May 12, 2021).
4.7
Officers’ Certificate of Amazon.com, Inc., dated as of December 1, 2022, containing Form of 4.700% Note due 2024, Form of 4.600% Note due 2025, Form of 4.550% Note due 2027, Form of 4.650% Note due 2029, and Form of 4.700% Note due 2032 (incorporated by reference to the Company’s Current Report on Form 8-K, filed December 1, 2022).
4.8
Officers’ Certificate of Amazon.com, Inc., dated as of November 20, 2025, containing Form of 3.900% Note due 2028, Form of 4.100% Note due 2030, Form of 4.350% Note due 2033, Form of 4.650% Note due 2035, Form of 5.450% Note due 2055, and Form of 5.550% Note due 2065 (incorporated by reference to the Company’s Current Report on Form 8-K, filed November 20, 2025).
4.9
Description of Securities (incorporated by reference to the Company’s Annual Report on Form 10-K for the Year ended December 31, 2019).
10.1†
1997 Stock Incentive Plan (amended and restated) (incorporated by reference to the Company’s Quarterly Report on Form 10-Q for the Quarter ended June 30, 2022).
10.2†
1999 Nonofficer Employee Stock Option Plan (amended and restated) (incorporated by reference to the Company’s Quarterly Report on Form 10-Q for the Quarter ended June 30, 2022).
10.3†
Form of Indemnification Agreement between Amazon.com, Inc. and each of its Directors (incorporated by reference to Exhibit 10.1 to the Company’s Registration Statement on Form S-1 (Registration No. 333-23795) filed March 24, 1997, as amended on April 21, 1997).
10.4†
Form of Restricted Stock Unit Agreement for Officers and Employees (incorporated by reference to the Company’s Annual Report on Form 10-K for the Year ended December 31, 2002).
10.5†
Form of Restricted Stock Unit Agreement for Directors (incorporated by reference to the Company’s Annual Report on Form 10-K for the Year ended December 31, 2002).
10.6†
Form of Restricted Stock Agreement (incorporated by reference to the Company’s Annual Report on Form 10-K for the Year ended December 31, 2001).
10.7†
Form of Global Restricted Stock Unit Award Agreement for Executive Officers (incorporated by reference to the Company’s Annual Report on Form 10-K for the Year ended December 31, 2023).
10.8
Five-Year Revolving Credit Agreement, dated as of November 1, 2023, among Amazon.com, Inc., Citibank N.A., as administrative agent, and the lenders party thereto (incorporated by reference to the Company’s Current Report on Form 8-K, filed November 1, 2023).
10.9
364-Day Revolving Credit Agreement, dated as of October 29, 2025, among Amazon.com, Inc., Citibank N.A., as administrative agent, and the lenders party thereto (incorporated by reference to the Company’s Quarterly Report on Form 10-Q for the Quarter ended September 30, 2025).
19.1
Amazon.com, Inc. Insider Trading Policy (incorporated by reference to the Company’s Annual Report on Form 10-K for the Year ended December 31, 2024).
21.1
List of Significant Subsidiaries.
23.1
Consent of Independent Registered Public Accounting Firm.
31.1
Certification of Andrew R. Jassy, President and Chief Executive Officer of Amazon.com, Inc., pursuant to Rule 13a-14(a) under the Securities Exchange Act of 1934.
31.2
Certification of Brian T. Olsavsky, Senior Vice President and Chief Financial Officer of Amazon.com, Inc., pursuant to Rule 13a-14(a) under the Securities Exchange Act of 1934.
32.1
Certification of Andrew R. Jassy, President and Chief Executive Officer of Amazon.com, Inc., pursuant to 18 U.S.C. Section 1350.
77
Table of Contents
32.2
Certification of Brian T. Olsavsky, Senior Vice President and Chief Financial Officer of Amazon.com, Inc., pursuant to 18 U.S.C. Section 1350.
97.1
Amazon.com, Inc. Clawback Policy (incorporated by reference to the Company’s Annual Report on Form 10-K for the Year ended December 31, 2023).
101
The following financial statements from the Company’s Annual Report on Form 10-K for the year ended December 31, 2025, formatted in Inline XBRL: (i) Consolidated Statements of Cash Flows, (ii) Consolidated Statements of Operations, (iii) Consolidated Statements of Comprehensive Income, (iv) Consolidated Balance Sheets, (v) Consolidated Statements of Stockholders’ Equity, and (vi) Notes to Consolidated Financial Statements, tagged as blocks of text and including detailed tags.
As permitted by Item 601(b)(4)(iii)(A) of Regulation S-K, the Company has not filed with this Annual Report on Form 10-K certain instruments defining the rights of holders of long-term debt of the Company and its subsidiaries because the total amount of securities authorized thereunder does not exceed 10 percent of the total assets of the Company and its subsidiaries on a consolidated basis. The Company agrees to furnish a copy of such agreements to the Commission upon request.
104
The cover page from the Company’s Annual Report on Form 10-K for the year ended December 31, 2025, formatted in Inline XBRL (included as Exhibit 101).
__________________
†    Executive Compensation Plan or Agreement.
Item 16.
Form 10-K Summary
None.
78
Table of Contents
SIGNATURES
Pursuant to the requirements of Section 13 or 15(d) of the Securities Exchange Act of 1934, the registrant has duly caused this Report to be signed on its behalf by the undersigned, thereunto duly authorized, as of February 5, 2026.
AMAZON.COM, INC.
By:	/s/ Andrew R. Jassy
Andrew R. Jassy
President and Chief Executive Officer
Pursuant to the requirements of the Securities Exchange Act of 1934, this Report has been signed below by the following persons on behalf of the registrant and in the capacities indicated as of February 5, 2026.
Signature		Title
/s/ Andrew R. Jassy
Andrew R. Jassy		President and Chief Executive Officer (Principal Executive Officer) and Director
/s/ Brian T. Olsavsky
Brian T. Olsavsky		Senior Vice President and Chief Financial Officer (Principal Financial Officer)
/s/ Shelley L. Reynolds
Shelley L. Reynolds		Vice President, Worldwide Controller (Principal Accounting Officer)
/s/ Jeffrey P. Bezos
Jeffrey P. Bezos		Executive Chair
/s/ Keith B. Alexander
Keith B. Alexander		Director
/s/ Edith W. Cooper
Edith W. Cooper		Director
/s/ Jamie S. Gorelick
Jamie S. Gorelick		Director
/s/ Daniel P. Huttenlocher
Daniel P. Huttenlocher		Director
/s/ Andrew Y. Ng
Andrew Y. Ng		Director
/s/ Indra K. Nooyi
Indra K. Nooyi		Director
/s/ Jonathan J. Rubinstein
Jonathan J. Rubinstein		Director
/s/ Brad D. Smith
Brad D. Smith		Director
/s/ Patricia Q. Stonesifer
Patricia Q. Stonesifer		Director
/s/ Wendell P. Weeks
Wendell P. Weeks		Director
79
```
