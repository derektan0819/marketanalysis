---
title: "SRC-c1ec319cd0b030514ec1e7fd 提取正文"
tags: [sources, raw-text]
created: 2026-10-19
updated: 2026-10-19
source: "https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/amzn-20260630.htm"
---
# Source text — untrusted evidence

```text
amzn-20260630
xbrli:sharesiso4217:USDiso4217:USDxbrli:sharesutr:MWhxbrli:pureiso4217:EURiso4217:CHFiso4217:GBPamzn:extensionamzn:segment00010187242026-01-012026-06-300001018724us-gaap:CommonStockMember2026-01-012026-06-300001018724amzn:FloatingRateNotesDue2028Member2026-01-012026-06-300001018724amzn:A2.800NotesDue2028Member2026-01-012026-06-300001018724amzn:A3.100NotesDue2030Member2026-01-012026-06-300001018724amzn:A3.350NotesDue2032Member2026-01-012026-06-300001018724amzn:A3.700NotesDue2035Member2026-01-012026-06-300001018724amzn:A4.050NotesDue2039Member2026-01-012026-06-300001018724amzn:A4.450NotesDue2045Member2026-01-012026-06-300001018724amzn:A4.850NotesDue2064Member2026-01-012026-06-3000010187242026-07-2200010187242025-03-3100010187242026-03-3100010187242024-12-3100010187242025-12-3100010187242024-06-3000010187242025-06-3000010187242025-04-012025-06-3000010187242026-04-012026-06-3000010187242025-01-012025-06-3000010187242024-07-012025-06-3000010187242025-07-012026-06-3000010187242026-06-300001018724us-gaap:ProductMember2025-04-012025-06-300001018724us-gaap:ProductMember2026-04-012026-06-300001018724us-gaap:ProductMember2025-01-012025-06-300001018724us-gaap:ProductMember2026-01-012026-06-300001018724us-gaap:ServiceMember2025-04-012025-06-300001018724us-gaap:ServiceMember2026-04-012026-06-300001018724us-gaap:ServiceMember2025-01-012025-06-300001018724us-gaap:ServiceMember2026-01-012026-06-300001018724amzn:IEEPATariffRefundMember2026-04-012026-06-300001018724srt:MaximumMember2026-01-012026-06-300001018724amzn:ElectricFuturePricesMembersrt:MinimumMemberus-gaap:FairValueInputsLevel3Member2026-06-300001018724amzn:ElectricFuturePricesMembersrt:MaximumMemberus-gaap:FairValueInputsLevel3Member2026-06-300001018724amzn:VariousManagementAssumptionsMembersrt:MinimumMemberus-gaap:FairValueInputsLevel3Member2026-06-300001018724amzn:VariousManagementAssumptionsMembersrt:MaximumMemberus-gaap:FairValueInputsLevel3Member2026-06-300001018724srt:WeightedAverageMember2026-01-012026-06-300001018724us-gaap:NetInvestmentHedgingMember2026-06-300001018724us-gaap:TradeAccountsReceivableMember2025-12-310001018724us-gaap:TradeAccountsReceivableMember2026-06-300001018724amzn:VendorAccountsReceivableMember2025-12-310001018724amzn:VendorAccountsReceivableMember2026-06-300001018724amzn:OtherReceivablesMember2025-12-310001018724amzn:OtherReceivablesMember2026-06-3000010187242026-07-012026-06-300001018724amzn:OpenAIGroupPBCMember2026-07-012026-03-310001018724amzn:OpenAIGroupPBCMember2026-07-012026-01-012026-03-310001018724amzn:AnthropicMember2026-07-012026-04-012026-06-300001018724amzn:AnthropicMember2026-07-012026-06-300001018724us-gaap:MoneyMarketFundsMemberus-gaap:FairValueInputsLevel1Member2025-12-310001018724us-gaap:MoneyMarketFundsMemberus-gaap:FairValueInputsLevel1Member2026-06-300001018724us-gaap:FairValueInputsLevel1Member2025-12-310001018724us-gaap:FairValueInputsLevel1Member2026-06-300001018724us-gaap:USTreasuryAndGovernmentMemberus-gaap:FairValueInputsLevel2Member2025-12-310001018724us-gaap:USTreasuryAndGovernmentMemberus-gaap:FairValueInputsLevel2Member2026-06-300001018724us-gaap:CorporateDebtSecuritiesMemberus-gaap:FairValueInputsLevel2Member2025-12-310001018724us-gaap:CorporateDebtSecuritiesMemberus-gaap:FairValueInputsLevel2Member2026-06-300001018724us-gaap:AssetBackedSecuritiesMemberus-gaap:FairValueInputsLevel2Member2025-12-310001018724us-gaap:AssetBackedSecuritiesMemberus-gaap:FairValueInputsLevel2Member2026-06-300001018724us-gaap:FixedIncomeSecuritiesMemberus-gaap:FairValueInputsLevel2Member2025-12-310001018724us-gaap:FixedIncomeSecuritiesMemberus-gaap:FairValueInputsLevel2Member2026-06-300001018724us-gaap:FairValueInputsLevel2Member2025-12-310001018724us-gaap:FairValueInputsLevel2Member2026-06-3000010187242023-07-012025-12-310001018724us-gaap:SeriesGPreferredStockMember2026-04-012026-06-300001018724us-gaap:LineOfCreditMemberamzn:AnthropicMember2026-06-300001018724us-gaap:LineOfCreditMemberamzn:AnthropicMember2026-01-012026-06-300001018724us-gaap:PreferredStockMember2025-12-310001018724us-gaap:PreferredStockMember2026-06-3000010187242025-01-012025-12-310001018724us-gaap:SeriesCPreferredStockMember2026-01-012026-03-310001018724us-gaap:SeriesCPreferredStockMember2026-03-310001018724us-gaap:SeriesCPreferredStockMember2026-04-012026-06-300001018724us-gaap:SeriesCPreferredStockMember2026-06-300001018724us-gaap:SeriesCPreferredStockMemberus-gaap:SubsequentEventMember2026-07-012026-07-300001018724us-gaap:WarrantMemberus-gaap:FairValueInputsLevel2Member2025-12-310001018724us-gaap:WarrantMemberus-gaap:FairValueInputsLevel2Member2026-06-300001018724amzn:OperatingAndFinanceLeasesLeaseNotYetCommencedMember2026-06-300001018724amzn:LongTermAgreementsToAcquireAndLicenseDigitalMediaContentProcureEnergyAndLicenseSoftwareMember2026-06-3000010187242025-12-312025-12-3100010187242026-06-302026-06-300001018724amzn:GlobalstarInc.Member2026-04-130001018724amzn:GlobalstarInc.Member2026-04-132026-04-130001018724srt:ScenarioForecastMembersrt:MaximumMemberamzn:GlobalstarInc.Member2027-01-012027-12-310001018724us-gaap:SeniorNotesMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2014SeniorUnsecuredNotesMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2014SeniorUnsecuredNotesMembersrt:MinimumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2014SeniorUnsecuredNotesMembersrt:MaximumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2014SeniorUnsecuredNotesMember2025-12-310001018724us-gaap:SeniorNotesMemberamzn:A2017SeniorUnsecuredNotesMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2017SeniorUnsecuredNotesMembersrt:MinimumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2017SeniorUnsecuredNotesMembersrt:MaximumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2017SeniorUnsecuredNotesMember2025-12-310001018724us-gaap:SeniorNotesMemberamzn:A2020SeniorUnsecuredNotesMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2020SeniorUnsecuredNotesMembersrt:MinimumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2020SeniorUnsecuredNotesMembersrt:MaximumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2020SeniorUnsecuredNotesMember2025-12-310001018724us-gaap:SeniorNotesMemberamzn:A2021SeniorUnsecuredNotesMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2021SeniorUnsecuredNotesMembersrt:MinimumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2021SeniorUnsecuredNotesMembersrt:MaximumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2021SeniorUnsecuredNotesMember2025-12-310001018724us-gaap:SeniorNotesMemberamzn:April2022SeniorUnsecuredNotesMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:April2022SeniorUnsecuredNotesMembersrt:MinimumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:April2022SeniorUnsecuredNotesMembersrt:MaximumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:April2022SeniorUnsecuredNotesMember2025-12-310001018724us-gaap:SeniorNotesMemberamzn:December2022SeniorUnsecuredNotesMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:December2022SeniorUnsecuredNotesMembersrt:MinimumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:December2022SeniorUnsecuredNotesMembersrt:MaximumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:December2022SeniorUnsecuredNotesMember2025-12-310001018724us-gaap:SeniorNotesMemberamzn:A2025SeniorUnsecuredNotesMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2025SeniorUnsecuredNotesMembersrt:MinimumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2025SeniorUnsecuredNotesMembersrt:MaximumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2025SeniorUnsecuredNotesMember2025-12-310001018724us-gaap:SeniorNotesMemberamzn:March2026SeniorUnsecuredNotesMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:March2026SeniorUnsecuredNotesMembersrt:MinimumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:March2026SeniorUnsecuredNotesMembersrt:MaximumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:March2026SeniorUnsecuredNotesMember2025-12-310001018724us-gaap:SeniorNotesMemberamzn:March2026EuroDenominatedNotesMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:March2026EuroDenominatedNotesMembersrt:MinimumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:March2026EuroDenominatedNotesMembersrt:MaximumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:March2026EuroDenominatedNotesMember2025-12-310001018724us-gaap:SeniorNotesMemberamzn:May2026SwissFrancDenominatedNotesMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:May2026SwissFrancDenominatedNotesMembersrt:MinimumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:May2026SwissFrancDenominatedNotesMembersrt:MaximumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:May2026SwissFrancDenominatedNotesMember2025-12-310001018724us-gaap:SeniorNotesMemberamzn:June2026CanadianDollarDenominatedNotesMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:June2026CanadianDollarDenominatedNotesMembersrt:MinimumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:June2026CanadianDollarDenominatedNotesMembersrt:MaximumMember2026-06-300001018724us-gaap:SeniorNotesMemberamzn:June2026CanadianDollarDenominatedNotesMember2025-12-310001018724amzn:OtherLongTermDebtMember2025-12-310001018724amzn:OtherLongTermDebtMember2026-06-300001018724us-gaap:SeniorNotesMember2025-12-310001018724us-gaap:SeniorNotesMemberamzn:A2014SeniorUnsecuredNotesMember2026-01-012026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2017SeniorUnsecuredNotesMember2026-01-012026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2020SeniorUnsecuredNotesMember2026-01-012026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2021SeniorUnsecuredNotesMember2026-01-012026-06-300001018724us-gaap:SeniorNotesMemberamzn:April2022SeniorUnsecuredNotesMember2026-01-012026-06-300001018724us-gaap:SeniorNotesMemberamzn:December2022SeniorUnsecuredNotesMember2026-01-012026-06-300001018724us-gaap:SeniorNotesMemberamzn:A2025SeniorUnsecuredNotesMember2026-01-012026-06-300001018724us-gaap:SeniorNotesMemberamzn:March2026SeniorUnsecuredNotesMember2026-01-012026-06-300001018724us-gaap:SeniorNotesMemberamzn:March2026EuroDenominatedNotesMember2026-01-012026-06-300001018724us-gaap:SeniorNotesMemberamzn:May2026SwissFrancDenominatedNotesMember2026-01-012026-06-300001018724us-gaap:SeniorNotesMemberamzn:June2026CanadianDollarDenominatedNotesMember2026-01-012026-06-300001018724us-gaap:SeniorNotesMember2026-01-012026-06-300001018724us-gaap:SeniorNotesMemberamzn:FloatingRateNotesDue2028And2029Member2026-06-300001018724us-gaap:SeniorNotesMemberamzn:FloatingRateNotesDue2028Member2026-06-300001018724us-gaap:SeniorNotesMemberamzn:FloatingRateNotesDue2029Member2026-06-300001018724us-gaap:SeniorNotesMemberamzn:EuroDenominatedFloatingRateNotesDue2028Member2026-06-300001018724us-gaap:SeniorNotesMemberus-gaap:SubsequentEventMemberamzn:July2026USDollarDenominatedNotesMember2026-07-300001018724us-gaap:SeniorNotesMemberus-gaap:SubsequentEventMemberamzn:FloatingRateNotesDue2029Member2026-07-300001018724us-gaap:SeniorNotesMemberus-gaap:SubsequentEventMemberamzn:July2026USDollarDenominatedNotesMembersrt:MinimumMember2026-07-300001018724us-gaap:SeniorNotesMemberus-gaap:SubsequentEventMemberamzn:July2026USDollarDenominatedNotesMembersrt:MaximumMember2026-07-300001018724us-gaap:CommercialPaperMember2026-06-300001018724us-gaap:CommercialPaperMember2026-01-012026-06-300001018724us-gaap:CommercialPaperMember2025-12-310001018724us-gaap:LineOfCreditMember2026-06-300001018724us-gaap:LineOfCreditMemberamzn:TheCreditAgreementMember2026-06-300001018724us-gaap:LineOfCreditMemberamzn:ShortTermCreditAgreementMember2026-06-300001018724us-gaap:LineOfCreditMemberamzn:ShortTermCreditAgreementMember2026-01-012026-06-300001018724us-gaap:LineOfCreditMemberamzn:TheCreditAgreementMemberus-gaap:RevolvingCreditFacilityMember2026-01-012026-06-300001018724us-gaap:LineOfCreditMemberamzn:TheCreditAgreementMember2026-01-012026-06-300001018724us-gaap:LineOfCreditMemberamzn:ShortTermCreditAgreementMember2025-12-310001018724us-gaap:LineOfCreditMemberamzn:TheCreditAgreementMember2025-12-310001018724us-gaap:DelayedDrawTermLoanMemberamzn:TermLoanMember2026-06-300001018724us-gaap:DelayedDrawTermLoanMemberamzn:TermLoanMember2026-06-012026-06-300001018724us-gaap:DelayedDrawTermLoanMemberamzn:TermLoanMembersrt:MinimumMember2026-06-012026-06-300001018724us-gaap:DelayedDrawTermLoanMemberamzn:TermLoanMembersrt:MaximumMember2026-06-012026-06-300001018724us-gaap:LineOfCreditMemberamzn:UnsecuredRevolvingCreditFacilityMemberus-gaap:LetterOfCreditMember2026-06-300001018724amzn:March2022ShareRepurchaseProgramMember2022-03-310001018724srt:MinimumMember2026-01-012026-06-300001018724us-gaap:CostOfGoodsAndServicesSold2025-04-012025-06-300001018724us-gaap:CostOfGoodsAndServicesSold2026-04-012026-06-300001018724us-gaap:CostOfGoodsAndServicesSold2025-01-012025-06-300001018724us-gaap:CostOfGoodsAndServicesSold2026-01-012026-06-300001018724amzn:FulfillmentExpense2025-04-012025-06-300001018724amzn:FulfillmentExpense2026-04-012026-06-300001018724amzn:FulfillmentExpense2025-01-012025-06-300001018724amzn:FulfillmentExpense2026-01-012026-06-300001018724amzn:TechnologyAndInfrastructureExpense2025-04-012025-06-300001018724amzn:TechnologyAndInfrastructureExpense2026-04-012026-06-300001018724amzn:TechnologyAndInfrastructureExpense2025-01-012025-06-300001018724amzn:TechnologyAndInfrastructureExpense2026-01-012026-06-300001018724us-gaap:MarketingExpense2025-04-012025-06-300001018724us-gaap:MarketingExpense2026-04-012026-06-300001018724us-gaap:MarketingExpense2025-01-012025-06-300001018724us-gaap:MarketingExpense2026-01-012026-06-300001018724us-gaap:GeneralAndAdministrativeExpense2025-04-012025-06-300001018724us-gaap:GeneralAndAdministrativeExpense2026-04-012026-06-300001018724us-gaap:GeneralAndAdministrativeExpense2025-01-012025-06-300001018724us-gaap:GeneralAndAdministrativeExpense2026-01-012026-06-300001018724us-gaap:RestrictedStockUnitsRSUMember2025-12-310001018724us-gaap:RestrictedStockUnitsRSUMember2026-01-012026-06-300001018724us-gaap:RestrictedStockUnitsRSUMember2026-06-300001018724us-gaap:CommonStockMember2025-03-310001018724us-gaap:CommonStockMember2026-03-310001018724us-gaap:CommonStockMember2024-12-310001018724us-gaap:CommonStockMember2025-12-310001018724us-gaap:CommonStockMember2025-04-012025-06-300001018724us-gaap:CommonStockMember2026-04-012026-06-300001018724us-gaap:CommonStockMember2025-01-012025-06-300001018724us-gaap:CommonStockMember2026-01-012026-06-300001018724us-gaap:CommonStockMember2025-06-300001018724us-gaap:CommonStockMember2026-06-300001018724us-gaap:TreasuryStockCommonMember2025-03-310001018724us-gaap:TreasuryStockCommonMember2025-06-300001018724us-gaap:TreasuryStockCommonMember2026-03-310001018724us-gaap:TreasuryStockCommonMember2026-06-300001018724us-gaap:TreasuryStockCommonMember2024-12-310001018724us-gaap:TreasuryStockCommonMember2025-12-310001018724us-gaap:AdditionalPaidInCapitalMember2025-03-310001018724us-gaap:AdditionalPaidInCapitalMember2026-03-310001018724us-gaap:AdditionalPaidInCapitalMember2024-12-310001018724us-gaap:AdditionalPaidInCapitalMember2025-12-310001018724us-gaap:AdditionalPaidInCapitalMember2025-04-012025-06-300001018724us-gaap:AdditionalPaidInCapitalMember2026-04-012026-06-300001018724us-gaap:AdditionalPaidInCapitalMember2025-01-012025-06-300001018724us-gaap:AdditionalPaidInCapitalMember2026-01-012026-06-300001018724us-gaap:AdditionalPaidInCapitalMember2025-06-300001018724us-gaap:AdditionalPaidInCapitalMember2026-06-300001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2025-03-310001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2026-03-310001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2024-12-310001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2025-12-310001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2025-04-012025-06-300001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2026-04-012026-06-300001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2025-01-012025-06-300001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2026-01-012026-06-300001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2025-06-300001018724us-gaap:AccumulatedOtherComprehensiveIncomeMember2026-06-300001018724us-gaap:RetainedEarningsMember2025-03-310001018724us-gaap:RetainedEarningsMember2026-03-310001018724us-gaap:RetainedEarningsMember2024-12-310001018724us-gaap:RetainedEarningsMember2025-12-310001018724us-gaap:RetainedEarningsMember2025-04-012025-06-300001018724us-gaap:RetainedEarningsMember2026-04-012026-06-300001018724us-gaap:RetainedEarningsMember2025-01-012025-06-300001018724us-gaap:RetainedEarningsMember2026-01-012026-06-300001018724us-gaap:RetainedEarningsMember2025-06-300001018724us-gaap:RetainedEarningsMember2026-06-300001018724us-gaap:AccumulatedTranslationAdjustmentMember2025-03-310001018724us-gaap:AccumulatedTranslationAdjustmentMember2026-03-310001018724us-gaap:AccumulatedTranslationAdjustmentMember2024-12-310001018724us-gaap:AccumulatedTranslationAdjustmentMember2025-12-310001018724us-gaap:AccumulatedTranslationAdjustmentMember2025-04-012025-06-300001018724us-gaap:AccumulatedTranslationAdjustmentMember2026-04-012026-06-300001018724us-gaap:AccumulatedTranslationAdjustmentMember2025-01-012025-06-300001018724us-gaap:AccumulatedTranslationAdjustmentMember2026-01-012026-06-300001018724us-gaap:AccumulatedTranslationAdjustmentMember2025-06-300001018724us-gaap:AccumulatedTranslationAdjustmentMember2026-06-300001018724amzn:AOCINetInvestmentHedgeParentMember2025-03-310001018724amzn:AOCINetInvestmentHedgeParentMember2026-03-310001018724amzn:AOCINetInvestmentHedgeParentMember2024-12-310001018724amzn:AOCINetInvestmentHedgeParentMember2025-12-310001018724amzn:AOCINetInvestmentHedgeParentMember2025-04-012025-06-300001018724amzn:AOCINetInvestmentHedgeParentMember2026-04-012026-06-300001018724amzn:AOCINetInvestmentHedgeParentMember2025-01-012025-06-300001018724amzn:AOCINetInvestmentHedgeParentMember2026-01-012026-06-300001018724amzn:AOCINetInvestmentHedgeParentMember2025-06-300001018724amzn:AOCINetInvestmentHedgeParentMember2026-06-300001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2025-03-310001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2026-03-310001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2024-12-310001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2025-12-310001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2025-04-012025-06-300001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2026-04-012026-06-300001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2025-01-012025-06-300001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2026-01-012026-06-300001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2025-06-300001018724us-gaap:AccumulatedNetUnrealizedInvestmentGainLossMember2026-06-300001018724amzn:AOCIOtherParentMember2025-03-310001018724amzn:AOCIOtherParentMember2026-03-310001018724amzn:AOCIOtherParentMember2024-12-310001018724amzn:AOCIOtherParentMember2025-12-310001018724amzn:AOCIOtherParentMember2025-04-012025-06-300001018724amzn:AOCIOtherParentMember2026-04-012026-06-300001018724amzn:AOCIOtherParentMember2025-01-012025-06-300001018724amzn:AOCIOtherParentMember2026-01-012026-06-300001018724amzn:AOCIOtherParentMember2025-06-300001018724amzn:AOCIOtherParentMember2026-06-300001018724amzn:NorthAmericaSegmentMember2025-04-012025-06-300001018724amzn:NorthAmericaSegmentMember2026-04-012026-06-300001018724amzn:NorthAmericaSegmentMember2025-01-012025-06-300001018724amzn:NorthAmericaSegmentMember2026-01-012026-06-300001018724amzn:InternationalSegmentMember2025-04-012025-06-300001018724amzn:InternationalSegmentMember2026-04-012026-06-300001018724amzn:InternationalSegmentMember2025-01-012025-06-300001018724amzn:InternationalSegmentMember2026-01-012026-06-300001018724amzn:AmazonWebServicesSegmentMember2025-04-012025-06-300001018724amzn:AmazonWebServicesSegmentMember2026-04-012026-06-300001018724amzn:AmazonWebServicesSegmentMember2025-01-012025-06-300001018724amzn:AmazonWebServicesSegmentMember2026-01-012026-06-300001018724amzn:OnlineStoresMember2025-04-012025-06-300001018724amzn:OnlineStoresMember2026-04-012026-06-300001018724amzn:OnlineStoresMember2025-01-012025-06-300001018724amzn:OnlineStoresMember2026-01-012026-06-300001018724amzn:PhysicalStoresMember2025-04-012025-06-300001018724amzn:PhysicalStoresMember2026-04-012026-06-300001018724amzn:PhysicalStoresMember2025-01-012025-06-300001018724amzn:PhysicalStoresMember2026-01-012026-06-300001018724amzn:ThirdPartySellerServicesMember2025-04-012025-06-300001018724amzn:ThirdPartySellerServicesMember2026-04-012026-06-300001018724amzn:ThirdPartySellerServicesMember2025-01-012025-06-300001018724amzn:ThirdPartySellerServicesMember2026-01-012026-06-300001018724amzn:AdvertisingServicesMember2025-04-012025-06-300001018724amzn:AdvertisingServicesMember2026-04-012026-06-300001018724amzn:AdvertisingServicesMember2025-01-012025-06-300001018724amzn:AdvertisingServicesMember2026-01-012026-06-300001018724amzn:SubscriptionServicesMember2025-04-012025-06-300001018724amzn:SubscriptionServicesMember2026-04-012026-06-300001018724amzn:SubscriptionServicesMember2025-01-012025-06-300001018724amzn:SubscriptionServicesMember2026-01-012026-06-300001018724amzn:AmazonWebServicesMember2025-04-012025-06-300001018724amzn:AmazonWebServicesMember2026-04-012026-06-300001018724amzn:AmazonWebServicesMember2025-01-012025-06-300001018724amzn:AmazonWebServicesMember2026-01-012026-06-300001018724amzn:OtherServicesMember2025-04-012025-06-300001018724amzn:OtherServicesMember2026-04-012026-06-300001018724amzn:OtherServicesMember2025-01-012025-06-300001018724amzn:OtherServicesMember2026-01-012026-06-300001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaSegmentMember2025-12-310001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaSegmentMember2026-06-300001018724us-gaap:OperatingSegmentsMemberamzn:InternationalSegmentMember2025-12-310001018724us-gaap:OperatingSegmentsMemberamzn:InternationalSegmentMember2026-06-300001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMember2025-12-310001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMember2026-06-300001018724us-gaap:CorporateNonSegmentMember2025-12-310001018724us-gaap:CorporateNonSegmentMember2026-06-300001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaSegmentMember2025-04-012025-06-300001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaSegmentMember2026-04-012026-06-300001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaSegmentMember2025-01-012025-06-300001018724us-gaap:OperatingSegmentsMemberamzn:NorthAmericaSegmentMember2026-01-012026-06-300001018724us-gaap:OperatingSegmentsMemberamzn:InternationalSegmentMember2025-04-012025-06-300001018724us-gaap:OperatingSegmentsMemberamzn:InternationalSegmentMember2026-04-012026-06-300001018724us-gaap:OperatingSegmentsMemberamzn:InternationalSegmentMember2025-01-012025-06-300001018724us-gaap:OperatingSegmentsMemberamzn:InternationalSegmentMember2026-01-012026-06-300001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMember2025-04-012025-06-300001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMember2026-04-012026-06-300001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMember2025-01-012025-06-300001018724us-gaap:OperatingSegmentsMemberamzn:AmazonWebServicesSegmentMember2026-01-012026-06-300001018724us-gaap:CorporateNonSegmentMember2025-04-012025-06-300001018724us-gaap:CorporateNonSegmentMember2026-04-012026-06-300001018724us-gaap:CorporateNonSegmentMember2025-01-012025-06-300001018724us-gaap:CorporateNonSegmentMember2026-01-012026-06-300001018724amzn:NorthAmericaAndInternationalSegmentMemberus-gaap:OperatingSegmentsMemberamzn:AssetsHeldUnderFinanceLeasesMember2025-04-012025-06-300001018724amzn:NorthAmericaAndInternationalSegmentMemberus-gaap:OperatingSegmentsMemberamzn:AssetsHeldUnderFinanceLeasesMember2026-04-012026-06-300001018724amzn:NorthAmericaAndInternationalSegmentMemberus-gaap:OperatingSegmentsMemberamzn:AssetsHeldUnderFinanceLeasesMember2025-01-012025-06-300001018724amzn:NorthAmericaAndInternationalSegmentMemberus-gaap:OperatingSegmentsMemberamzn:AssetsHeldUnderFinanceLeasesMember2026-01-012026-06-300001018724amzn:AmazonWebServicesSegmentMemberus-gaap:OperatingSegmentsMemberamzn:AssetsHeldUnderFinanceLeasesMember2025-04-012025-06-300001018724amzn:AmazonWebServicesSegmentMemberus-gaap:OperatingSegmentsMemberamzn:AssetsHeldUnderFinanceLeasesMember2026-04-012026-06-300001018724amzn:AmazonWebServicesSegmentMemberus-gaap:OperatingSegmentsMemberamzn:AssetsHeldUnderFinanceLeasesMember2025-01-012025-06-300001018724amzn:AmazonWebServicesSegmentMemberus-gaap:OperatingSegmentsMemberamzn:AssetsHeldUnderFinanceLeasesMember2026-01-012026-06-300001018724amzn:MatthewS.GarmanMember2026-04-012026-06-300001018724amzn:MatthewS.GarmanMember2026-06-300001018724amzn:DanielP.HuttenlocherMember2026-04-012026-06-300001018724amzn:DanielP.HuttenlocherMember2026-06-300001018724amzn:JonathanJ.RubinsteinMember2026-04-012026-06-300001018724amzn:JonathanJ.RubinsteinMember2026-06-300001018724amzn:BrianT.OlsavskyMember2026-04-012026-06-300001018724amzn:BrianT.OlsavskyMember2026-06-30
Table of Contents
UNITED STATES
SECURITIES AND EXCHANGE COMMISSION
Washington, D.C. 20549
____________________________________
FORM 10-Q
____________________________________
(Mark One)
☒	QUARTERLY REPORT PURSUANT TO SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT OF 1934
For the quarterly period ended June 30, 2026
or
☐	TRANSITION REPORT PURSUANT TO SECTION 13 OR 15(d) OF THE SECURITIES EXCHANGE ACT OF 1934
For the transition period from            to             .
Commission File No. 001-43202
____________________________________
AMAZON.COM, INC.
(Exact name of registrant as specified in its charter)
____________________________________
Delaware	 	91-1646860
(State or other jurisdiction of
incorporation or organization)	 	(I.R.S. Employer
Identification No.)
410 Terry Avenue North, Seattle, Washington 98109-5210
(206) 266-1000
(Address and telephone number, including area code, of registrant’s principal executive offices)
Securities registered pursuant to Section 12(b) of the Act:
Title of Each Class	Trading Symbol(s)	Name of Each Exchange on Which Registered
Common Stock, par value $.01 per share	AMZN	The Nasdaq Stock Market LLC
Floating Rate Notes due 2028	—
The Nasdaq Stock Market LLC
2.800% Notes due 2028	—
The Nasdaq Stock Market LLC
3.100% Notes due 2030	—
The Nasdaq Stock Market LLC
3.350% Notes due 2032	—
The Nasdaq Stock Market LLC
3.700% Notes due 2035	—
The Nasdaq Stock Market LLC
4.050% Notes due 2039	—
The Nasdaq Stock Market LLC
4.450% Notes due 2045	—
The Nasdaq Stock Market LLC
4.850% Notes due 2064	—
The Nasdaq Stock Market LLC
____________________________________
Indicate by check mark whether the registrant (1) has filed all reports required to be filed by Section 13 or 15(d) of the Securities Exchange Act of 1934 during the preceding 12 months (or for such shorter period that the registrant was required to file such reports), and (2) has been subject to such filing requirements for the past 90 days.    Yes  ☒    No  ☐
Indicate by check mark whether the registrant has submitted electronically every Interactive Data File required to be submitted pursuant to Rule 405 of Regulation S-T during the preceding 12 months (or for such shorter period that the registrant was required to submit such files).    Yes  ☒    No  ☐
Indicate by check mark whether the registrant is a large accelerated filer, an accelerated filer, a non-accelerated filer, a smaller reporting company, or an emerging growth company. See the definitions of “large accelerated filer,” “accelerated filer,” “smaller reporting company,” and “emerging growth company” in Rule 12b-2 of the Exchange Act.
Large accelerated filer		☒	Accelerated filer		☐
Non-accelerated filer		☐	Smaller reporting company		☐
Emerging growth company		☐
If an emerging growth company, indicate by check mark if the registrant has elected not to use the extended transition period for complying with any new or revised financial accounting standards provided pursuant to Section 13(a) of the Exchange Act.     ☐
Indicate by check mark whether the registrant is a shell company (as defined in Rule 12b-2 of the Exchange Act).    Yes  ☐    No  ☒
10,786,313,572 shares of common stock, par value $0.01 per share, outstanding as of July 22, 2026
Table of Contents
AMAZON.COM, INC.
FORM 10-Q
For the Quarterly Period Ended June 30, 2026
INDEX
Page
PART I. FINANCIAL INFORMATION
Item 1.
Financial Statements
3
Consolidated Statements of Cash Flows
3
Consolidated Statements of Operations
4
Consolidated Statements of Comprehensive Income
5
Consolidated Balance Sheets
6
Notes to Consolidated Financial Statements
7
Item 2.
Management’s Discussion and Analysis of Financial Condition and Results of Operations
26
Item 3.
Quantitative and Qualitative Disclosures About Market Risk
36
Item 4.
Controls and Procedures
37
PART II. OTHER INFORMATION
Item 1.
Legal Proceedings
38
Item 1A.
Risk Factors
38
Item 2.
Unregistered Sales of Equity Securities and Use of Proceeds
50
Item 3.
Defaults Upon Senior Securities
50
Item 4.
Mine Safety Disclosures
50
Item 5.
Other Information
50
Item 6.
Exhibits
51
Signatures
52
2
Table of Contents
PART I. FINANCIAL INFORMATION
Item 1.	Financial Statements
AMAZON.COM, INC.
CONSOLIDATED STATEMENTS OF CASH FLOWS
(in millions)
(unaudited)
Three Months Ended
June 30,		Six Months Ended
June 30,		Twelve Months Ended
June 30,
2025		2026		2025		2026		2025		2026
CASH, CASH EQUIVALENTS, AND RESTRICTED CASH, BEGINNING OF PERIOD	$	69,893 			$	104,692 			$	82,312 			$	90,106 			$	71,673 			$	61,453
OPERATING ACTIVITIES:
Net income	18,164 			62,647 			35,291 			92,902 			70,623 			135,281
Adjustments to reconcile net income to net cash from operating activities:
Depreciation and amortization of property and equipment and capitalized content costs, operating lease assets, and other	15,227 			19,988 			29,489 			38,933 			58,562 			75,200
Stock-based compensation	6,534 			6,038 			10,223 			10,070 			20,551 			19,314
Non-operating expense (income), net	(1,258)			(53,381)			(4,075)			(69,013)			(4,702)			(79,818)
Deferred income taxes	11 			17,691 			518 			30,489 			(2,407)			41,441
Changes in operating assets and liabilities:
Inventories	(4,054)			(1,818)			(5,276)			(196)			(5,851)			2,078
Accounts receivable, net and other	(1,125)			(8,204)			122 			(13,954)			(4,602)			(21,409)
Other assets	(2,971)			(4,717)			(6,373)			(8,528)			(15,100)			(17,787)
Accounts payable	7,058 			9,442 			(1,985)			705 			6,264 			13,921
Accrued expenses and other	(4,952)			(2,018)			(9,013)			(10,063)			(4,842)			(6,069)
Unearned revenue	(119)			(281)			609 			74 			2,641 			(749)
Net cash provided by (used in) operating activities	32,515 			45,387 			49,530 			71,419 			121,137 			161,403
INVESTING ACTIVITIES:
Purchases of property and equipment	(32,183)			(54,208)			(57,202)			(98,411)			(107,656)			(173,028)
Proceeds from property and equipment sales and incentives	815 			1,132 			1,579 			2,101 			4,703 			4,021
Acquisitions, net of cash acquired, non-marketable investments, and other, net	(1,700)			(24,359)			(1,652)			(39,767)			(4,809)			(41,956)
Sales and maturities of marketable securities	11,441 			24,196 			19,178 			41,882 			30,924 			67,090
Purchases of marketable securities	(17,797)			(26,006)			(31,130)			(49,262)			(46,731)			(72,902)
Net cash provided by (used in) investing activities	(39,424)			(79,245)			(69,227)			(143,457)			(123,569)			(216,775)
FINANCING ACTIVITIES:
Proceeds from short-term debt, and other	2,093 			9,368 			3,908 			15,386 			8,187 			20,798
Repayments of short-term debt, and other	(1,392)			(9,573)			(3,474)			(15,682)			(7,901)			(20,634)
Proceeds from long-term debt	— 			13,557 			746 			66,998 			746 			81,925
Repayments of long-term debt	(2,751)			(2,752)			(2,751)			(2,752)			(7,434)			(5,022)
Principal repayments of finance leases	(411)			(395)			(821)			(863)			(1,556)			(1,599)
Principal repayments of financing obligations	(78)			(59)			(194)			(174)			(694)			(308)
Net cash provided by (used in) financing activities	(2,539)			10,146 			(2,586)			62,913 			(8,652)			75,160
Foreign currency effect on cash, cash equivalents, and restricted cash	1,008 			(53)			1,424 			(54)			864 			(314)
Net increase (decrease) in cash, cash equivalents, and restricted cash	(8,440)			(23,765)			(20,859)			(9,179)			(10,220)			19,474
CASH, CASH EQUIVALENTS, AND RESTRICTED CASH, END OF PERIOD	$	61,453 			$	80,927 			$	61,453 			$	80,927 			$	61,453 			$	80,927
See accompanying notes to consolidated financial statements.
3
Table of Contents
AMAZON.COM, INC.
CONSOLIDATED STATEMENTS OF OPERATIONS
(in millions, except per share data)
(unaudited)
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Net product sales	$	68,246 			$	77,602 			$	132,216 			$	148,906
Net service sales	99,456 			123,004 			191,153 			233,219
Total net sales	167,702 			200,606 			323,369 			382,125
Operating expenses:
Cost of sales	80,809 			95,778 			157,785 			183,241
Fulfillment	25,976 			29,633 			50,569 			56,922
Technology and infrastructure	27,166 			33,158 			50,160 			62,725
Sales and marketing	11,416 			11,698 			21,179 			22,012
General and administrative	2,965 			2,788 			5,593 			5,375
Other operating expense (income), net	199 			90 			507 			537
Total operating expenses	148,531 			173,145 			285,793 			330,812
Operating income	19,171 			27,461 			37,576 			51,313
Interest income	1,085 			1,295 			2,151 			2,430
Interest expense	(516)			(1,314)			(1,057)			(2,114)
Other income (expense), net	1,117 			53,415 			3,866 			69,062
Total non-operating income	1,686 			53,396 			4,960 			69,378
Income before income taxes	20,857 			80,857 			42,536 			120,691
Provision for income taxes	(2,678)			(18,199)			(7,231)			(27,759)
Equity-method investment activity, net of tax	(15)			(11)			(14)			(30)
Net income	$	18,164 			$	62,647 			$	35,291 			$	92,902
Basic earnings per share	$	1.71 			$	5.82 			$	3.32 			$	8.64
Diluted earnings per share	$	1.68 			$	5.75 			$	3.27 			$	8.53
Weighted-average shares used in computation of earnings per share:
Basic	10,637 			10,769 			10,620 			10,756
Diluted	10,806 			10,903 			10,800 			10,889
See accompanying notes to consolidated financial statements.
4
Table of Contents
AMAZON.COM, INC.
CONSOLIDATED STATEMENTS OF COMPREHENSIVE INCOME
(in millions)
(unaudited)
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Net income	$	18,164 			$	62,647 			$	35,291 			$	92,902
Other comprehensive income (loss):
Foreign currency translation adjustments, net of tax of $(142), $(66), $(208), and $(79)	3,314 			(799)			4,849 			(1,563)
Unrealized gains (losses) on net investment hedging instruments, net of tax of $0, $(69), $0, and $(45)	— 			229 			— 			144
Available-for-sale debt securities:
Change in net unrealized gains (losses), net of tax of $(12), $(13,695), $(23), and $(14,035)	40 			41,988 			77 			42,814
Less: reclassification adjustments for losses (gains) included in “Other income (expense), net,” net of tax of $5, $0, $814, and $1,142	(17)			— 			(2,471)			(3,337)
Net change	23 			41,988 			(2,394)			39,477
Other, net of tax of $(1), $1, $0, and $(1)	(3)			1 			(1)			(1)
Total other comprehensive income (loss)	3,334 			41,419 			2,454 			38,057
Comprehensive income	$	21,498 			$	104,066 			$	37,745 			$	130,959
See accompanying notes to consolidated financial statements.
5
Table of Contents
AMAZON.COM, INC.
CONSOLIDATED BALANCE SHEETS
(in millions, except per share data)
December 31, 2025		June 30, 2026
(unaudited)
ASSETS
Current assets:
Cash and cash equivalents	$	86,810 			$	78,213
Marketable securities	36,219 			44,775
Inventories	38,325 			38,184
Accounts receivable, net and other	67,729 			88,092
Total current assets	229,083 			249,264
Property and equipment, net	357,025 			446,046
Operating leases	86,054 			92,743
Goodwill	23,273 			23,504
Other assets	122,607 			284,132
Total assets	$	818,042 			$	1,095,689
LIABILITIES AND STOCKHOLDERS’ EQUITY
Current liabilities:
Accounts payable	$	121,909 			$	147,440
Accrued expenses and other	75,520 			73,406
Unearned revenue	20,576 			20,428
Total current liabilities	218,005 			241,274
Long-term lease liabilities	87,339 			94,338
Long-term debt	65,648 			128,894
Other long-term liabilities	35,985 			79,563
Commitments and contingencies (Note 4)
Stockholders’ equity:
Preferred stock ($0.01 par value; 500 shares authorized; no shares issued or outstanding)	— 			—
Common stock ($0.01 par value; 100,000 shares authorized; 11,246 and 11,298 shares issued; 10,731 and 10,783 shares outstanding)	112 			113
Treasury stock, at cost	(7,837)			(7,837)
Additional paid-in capital	140,024 			149,619
Accumulated other comprehensive income (loss)	28,230 			66,287
Retained earnings	250,536 			343,438
Total stockholders’ equity	411,065 			551,620
Total liabilities and stockholders’ equity	$	818,042 			$	1,095,689
See accompanying notes to consolidated financial statements.
6
Table of Contents
AMAZON.COM, INC.
NOTES TO CONSOLIDATED FINANCIAL STATEMENTS
(unaudited)
Note 1 — ACCOUNTING POLICIES AND SUPPLEMENTAL DISCLOSURES
Unaudited Interim Financial Information
We have prepared the accompanying consolidated financial statements pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) for interim financial reporting. These consolidated financial statements are unaudited and, in our opinion, include all adjustments, consisting of normal recurring adjustments and accruals necessary for a fair presentation of our consolidated cash flows, operating results, and balance sheets for the periods presented. Operating results for the periods presented are not necessarily indicative of the results that may be expected for 2026 due to seasonal and other factors. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States (“GAAP”) have been omitted in accordance with the rules and regulations of the SEC. These consolidated financial statements should be read in conjunction with the audited consolidated financial statements and accompanying notes in Item 8 of Part II, “Financial Statements and Supplementary Data,” of our 2025 Annual Report on Form 10-K.
Principles of Consolidation
The consolidated financial statements include the accounts of Amazon.com, Inc. and its consolidated entities (collectively, the “Company”), consisting of its wholly-owned subsidiaries and those entities in which we have a variable interest (“VIEs”) and of which we are the primary beneficiary, including certain entities in India and certain entities that support our healthcare services and production and distribution of video content. We are the primary beneficiary if we have the power to direct the activities of the VIE and absorb the losses or benefits that would be significant to the VIE. Intercompany balances and transactions between consolidated entities are eliminated.
Use of Estimates
The preparation of financial statements in conformity with GAAP requires estimates and assumptions that affect the reported amounts of assets and liabilities, revenues and expenses, and related disclosures of contingent liabilities in the consolidated financial statements and accompanying notes. Estimates are used for, but not limited to, collectability of receivables, commitments and contingencies, impairment of property and equipment and operating leases, income taxes, inventory valuation, self-insurance liabilities, stock-based compensation forfeiture rates, the determination of when to capitalize certain costs relating to new products or service offerings, useful lives of equipment, valuation and impairment of investments, valuation of acquired intangibles and goodwill, valuation of derivative instruments, vendor funding, and viewing patterns of capitalized video content. Actual results could differ materially from these estimates. We review the useful lives of equipment on an ongoing basis.
During Q2 2026, we received approximately $640 million of tariff refunds under the International Emergency Economic Powers Act (“IEEPA”). These tariff refunds were primarily recorded as a reduction to “Cost of sales” and primarily impacted our North America segment. This represents the significant majority of refunds we expect to receive.
7
Table of Contents
Supplemental Cash Flow Information
The following table shows supplemental cash flow information (in millions):
Three Months Ended
June 30,		Six Months Ended
June 30,		Twelve Months Ended
June 30,
2025		2026		2025		2026		2025		2026
SUPPLEMENTAL CASH FLOW INFORMATION:
Cash paid for interest on debt, net of capitalized interest	$	523 			$	736 			$	759 			$	1,010 			$	1,668 			$	1,709
Cash paid for operating leases	3,758 			3,489 			7,320 			7,804 			13,485 			15,522
Cash paid for interest on finance leases	72 			85 			143 			187 			284 			339
Cash paid for interest on financing obligations	52 			50 			107 			126 			212 			215
Cash paid for income taxes, net of refunds	4,761 			2,655 			5,638 			3,978 			11,788 			6,635
Assets acquired under operating leases	4,621 			7,670 			8,942 			13,909 			16,702 			24,897
Property and equipment acquired under finance leases, net of remeasurements and modifications	937 			563 			991 			2,128 			1,622 			4,048
Increase (decrease) in property and equipment acquired but not yet paid	(1,600)			10,700 			1,508 			20,620 			5,376 			29,267
Earnings Per Share
Basic earnings per share is calculated using our weighted-average outstanding common shares. Diluted earnings per share is calculated using our weighted-average outstanding common shares including the dilutive effect of stock awards as determined under the treasury stock method. In periods when we have a net loss, stock awards are excluded from our calculation of earnings per share as their inclusion would have an antidilutive effect.
The following table shows the calculation of diluted shares (in millions):
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Shares used in computation of basic earnings per share	10,637 			10,769 			10,620 			10,756
Total dilutive effect of outstanding stock awards	169 			134 			180 			133
Shares used in computation of diluted earnings per share	10,806 			10,903 			10,800 			10,889
Other Income (Expense), Net
Other income (expense), net is as follows (in millions):
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Marketable equity securities valuation gains (losses), net	$	388 			$	1,319 			$	250 			$	430
Equity warrant valuation gains (losses), net	590 			1,449 			212 			1,051
Reclassification adjustments for gains (losses) on available-for-sale debt securities, net 	22 			— 			3,285 			4,479
Upward adjustments relating to equity investments in private companies	49 			50,486 			86 			62,814
Foreign currency gains (losses), net	70 			227 			68 			387
Other, net	(2)			(66)			(35)			(99)
Total other income (expense), net	$	1,117 			$	53,415 			$	3,866 			$	69,062
The reclassification adjustments for the gains on available-for-sale debt securities of $3.3 billion and $4.5 billion for the six months ended June 30, 2025 and 2026 are primarily from the portions of our convertible notes investments in Anthropic, PBC (“Anthropic”) that were converted to nonvoting preferred stock during Q1 2025 and Q1 2026. The upward adjustments relating to equity investments in private companies of $50.5 billion in Q2 2026 and $62.8 billion for the six months ended June 30, 2026 reflect observable changes in prices, primarily from our nonvoting preferred stock in Anthropic.
8
Table of Contents
Derivatives and Hedging
Energy Contracts — We enter into energy contracts to secure electricity supply for our existing and future operations, some of which extend 20 years. We may make or receive net cash payments, rather than take delivery of electricity, when our consumption is less than committed quantities due to operational variability. Because we may make or receive net cash payments, these contracts are derivative instruments. These contracts are not traded on exchanges or transacted in secondary markets and are not used for trading or speculative purposes.
Derivative instruments are measured at fair value each reporting period. Fair value measurements are based on valuation methods using both common factors like electricity futures prices where there are more liquid trading volumes generally for remaining contractual periods up to four to six years, forward capacity auctions, and risk-free interest rates, and a number of management assumptions for remaining contractual periods greater than four to six years where there is significantly less or no trading data such as long-dated forward commodity prices and implied volatility curves, and credit adjustments. The extent of management judgment is significant (Level 3).
Fair value measurements will not impact cash flows but may be material to our statements of operations and balance sheet due to the duration of these contracts and volatility inherent in valuation methods. Generally, we can terminate our contracts by paying cash in the form of fixed penalties, such as reimbursing the counterparty for the costs of new construction incurred. Termination penalties are generally not based on fair value measurements.
As of June 30, 2026, the energy contract quantities subject to derivative accounting fair value measurements were approximately 270 million megawatt-hours and the weighted-average remaining duration of these contracts is approximately 15 years, with the majority of these megawatt-hours to be delivered beyond the next nine years. The impact of these fair value measurements on our consolidated statements of operations was not significant in Q2 2025 and for the six months ended June 30, 2025, and resulted in net unrealized gains of $551 million in Q2 2026 and $599 million for the six months ended June 30, 2026, recorded within “Technology and infrastructure” and primarily impacting our AWS segment.
Changes in fair value measurements will create unrealized gains and losses recorded within operating expenses on our statements of operations with corresponding assets (unrealized gains) and liabilities (unrealized losses) recorded on our balance sheet within “Other assets” and “Other long-term liabilities.” As of December 31, 2025 and June 30, 2026, we had recorded assets of $112 million and $705 million, and liabilities of $139 million and $133 million.
Certain of our energy contracts are subject to regulatory approval and are exempt from derivative guidance until the approval is obtained. If possible, we may elect the normal purchases and normal sales (NPNS) scope exemption from derivative guidance for energy contracts where we expect to consume substantially all committed quantities. A contract that no longer meets the NPNS exemption must be measured at fair value with immediate recognition in our financial statements.
Net Investment Hedges — Our foreign currency-denominated unsecured senior notes create exposure to changes in foreign exchange rates. As of June 30, 2026, we have designated $20.7 billion of our Euro- and Canadian Dollar-denominated Notes as net investment hedges to mitigate foreign currency exposures related to the translation of our investments in foreign operations to U.S. dollars. Foreign currency unrealized gains and losses on these notes are included in “Accumulated other comprehensive income (loss),” a separate component of stockholders’ equity, until the foreign operations are sold or substantially liquidated, at which point these amounts and any translation adjustment of the foreign operations are reclassified to our consolidated statements of operations.
Inventories
Inventories, consisting of products available for sale, are primarily accounted for using the first-in, first-out method, and are valued at the lower of cost and net realizable value. This valuation requires us to make judgments, based on currently available information, about the likely method of disposition, such as through sales to individual customers, returns to product vendors, or liquidations, and expected recoverable values of each disposition category. The inventory valuation allowance, representing a write-down of inventory, was $3.3 billion and $3.0 billion as of December 31, 2025 and June 30, 2026.
Accounts Receivable, Net and Other
Included in “Accounts receivable, net and other” on our consolidated balance sheets are receivables primarily related to customers, vendors, and prepaid expenses and other current assets. As of December 31, 2025 and June 30, 2026, customer receivables, net, were $40.4 billion and $49.2 billion, vendor receivables, net, were $15.9 billion and $21.7 billion, and other receivables, net, were $4.5 billion and $9.8 billion. Prepaid expenses and other current assets, which include amounts related to satellite network launch services deposits, were $6.9 billion and $7.4 billion as of December 31, 2025 and June 30, 2026. We currently expense satellite network launch services deposits upon launch to “Technology and infrastructure.”
We estimate losses on receivables based on expected losses, including our historical experience of actual losses. The allowance for doubtful accounts was $2.4 billion and $2.8 billion as of December 31, 2025 and June 30, 2026.
9
Table of Contents
Digital Video and Music Content
Included in “Other assets” on our consolidated balance sheets are the total capitalized costs of video, which is primarily released content, and music, which as of December 31, 2025 and June 30, 2026 were $21.3 billion. Total video and music expense was $5.1 billion and $6.9 billion in Q2 2025 and Q2 2026, and $10.2 billion and $12.9 billion for the six months ended June 30, 2025 and 2026.
Unearned Revenue
Unearned revenue is recorded when payments are received or due in advance of performing our service obligations and is recognized over the service period. Unearned revenue primarily relates to prepayments of AWS services and Amazon Prime memberships. Our total unearned revenue as of December 31, 2025 was $25.0 billion, of which $15.2 billion was recognized as revenue during the six months ended June 30, 2026. Included in “Other long-term liabilities” on our consolidated balance sheets was $4.4 billion and $4.5 billion of unearned revenue as of December 31, 2025 and June 30, 2026.
Additionally, we have performance obligations, primarily related to AWS, associated with commitments in customer contracts for future services that we expect to fulfill but have not yet been recognized in our financial statements. For contracts with original terms that exceed one year, those commitments not yet recognized were approximately $496 billion as of June 30, 2026. The weighted-average remaining life of our long-term contracts is 6.4 years. The amount and timing of revenue recognition will be driven by customer usage and our performance in accordance with contractual obligations, which can extend beyond the original contractual duration and commitment.
In Q1 2026, AWS and OpenAI Group PBC (“OpenAI”) announced an expansion of the existing $38.0 billion multi-year commitment and commercial arrangement with OpenAI by $100.0 billion over 8.0 years, which includes contractual obligations related to the performance of AWS chips.
In Q2 2026, AWS and Anthropic announced an expansion of the strategic collaboration and existing multi-year commitment by more than $100.0 billion over 10.0 years, which includes contractual obligations related to the performance of AWS chips.
Accounting Pronouncements Not Yet Adopted
In November 2024, the FASB issued an ASU amending existing income statement disclosure guidance, primarily requiring more detailed disclosure for expenses. The ASU is effective for annual reporting periods beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027, with early adoption permitted. The amendments can be applied on either a prospective or retroactive basis. We are currently evaluating the ASU to determine its impact on our disclosures.
Note 2 — FINANCIAL INSTRUMENTS
Cash, Cash Equivalents, Restricted Cash, and Marketable Securities
As of December 31, 2025 and June 30, 2026, our cash, cash equivalents, restricted cash, and marketable securities primarily consisted of cash, AAA-rated money market funds, U.S. government and agency securities, other investment grade securities, and marketable equity securities. Cash equivalents and marketable securities are recorded at fair value. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. To increase the comparability of fair value measures, the following hierarchy prioritizes the inputs to valuation methodologies used to measure fair value:
Level 1 — Valuations based on quoted prices for identical assets and liabilities in active markets.
Level 2 — Valuations based on observable inputs other than quoted prices included in Level 1, such as quoted prices for identical unrestricted assets in active markets, similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data.
Level 3 — Valuations based on unobservable inputs reflecting our own assumptions, consistent with reasonably available assumptions made by other market participants. These valuations require significant judgment.
We measure the fair value of money market funds and certain marketable equity securities based on quoted prices in active markets for identical assets or liabilities. Other marketable securities were valued either based on recent trades of unrestricted securities in active markets, securities in inactive markets, or quoted market prices of similar instruments and other significant inputs derived from or corroborated by observable market data.
10
Table of Contents
The following table summarizes, by major investment type, our cash, cash equivalents, restricted cash, and marketable securities that are measured at fair value on a recurring basis and are categorized using the fair value hierarchy (in millions):
December 31, 2025		June 30, 2026
Total
Estimated
Fair Value		Cost or
Amortized
Cost		Gross
Unrealized
Gains		Gross
Unrealized
Losses		Total
Estimated
Fair Value
Cash and time deposits	$	16,145 			$	14,497 			$	— 			$	— 			$	14,497
Level 1:
Money market funds	29,777 			40,845 			— 			— 			40,845
Equity securities (1)	3,687 									3,498
Level 2:
U.S. government and agency securities	5,222 			4,558 			— 			(24)			4,534
Corporate debt securities	69,585 			59,458 			6 			(33)			59,431
Asset-backed securities	1,780 			1,690 			1 			(10)			1,681
Other financial instruments	129 			27 			— 			— 			27
Equity securities (1)	$	— 									$	1,189
$	126,325 			$	121,075 			$	7 			$	(67)			$	125,702
Less: Restricted cash, cash equivalents, and marketable securities (2)	(3,296)									(2,714)
Total cash, cash equivalents, and marketable securities	$	123,029 									$	122,988
___________________
(1)The related unrealized gain (loss) recorded in “Other income (expense), net” was $393 million and $1.3 billion in Q2 2025 and Q2 2026, and $188 million and $454 million for the six months ended June 30, 2025 and 2026.
(2)We are required to pledge or otherwise restrict a portion of our cash, cash equivalents, and marketable debt securities primarily as collateral for real estate, amounts due to third-party sellers in certain jurisdictions, debt, standby and trade letters of credit, and licenses of digital media content. We classify cash, cash equivalents, and marketable debt securities with use restrictions of less than twelve months as “Accounts receivable, net and other” and of twelve months or longer as non-current “Other assets” on our consolidated balance sheets. See “Note 4 — Commitments and Contingencies.”
The following table summarizes the remaining contractual maturities of our cash equivalents and marketable debt securities as of June 30, 2026 (in millions):
Amortized
Cost		Estimated
Fair Value
Due within one year	$	96,479 			$	96,471
Due after one year through five years	8,733 			8,702
Due after five years through ten years	440 			439
Due after ten years	926 			906
Total	$	106,578 			$	106,518
Actual maturities may differ from the contractual maturities because borrowers may have certain prepayment conditions.
Non-Marketable Investments
Anthropic — From Q3 2023 to Q4 2025, we invested $8.0 billion in convertible notes from Anthropic, which are classified as available-for-sale and reported at fair value with unrealized gains and losses included in “Accumulated other comprehensive income (loss)” and as Level 3 assets. In making these estimates, we utilized valuation methods based on information available, including the rights and obligations of the convertible notes, other outstanding classes of securities, observable transactions such as new securities offerings, estimates of expected time to and type of liquidity events and anticipated securities offerings, and discounts for lack of marketability. The convertible notes are subject to our ownership cap, which may be waived at our election.
In Q1 2025 and Q1 2026, a portion of the then-outstanding notes was converted to nonvoting preferred stock. The investments in nonvoting preferred stock are initially recorded at their estimated fair value at the time of each conversion and are accounted for as a component of our equity investments in private companies not accounted for under the equity-method, with future adjustments for observable changes in prices or impairments representing Level 3 fair value measurements
11
Table of Contents
recognized in “Other income (expense), net” on our consolidated statements of operations. As a result of these conversions, a portion of the unrealized gain associated with the notes included in “Accumulated other comprehensive income (loss)” was reclassified and gains of approximately $3.3 billion and $4.5 billion for the six months ended June 30, 2025 and 2026 were recorded in “Other income (expense), net.”
In Q2 2026, we invested $5.0 billion in Anthropic Series G nonvoting preferred stock. We also amended our commercial arrangement primarily for the provision of AWS cloud services, which includes contractual obligations related to the performance of AWS chips. Additionally, we entered into a financing arrangement to make available to Anthropic an aggregate facility not to exceed $20.0 billion that will expire 30 months after an Anthropic liquidity event, including an initial public offering (“IPO”). At inception, there is no amount available to be drawn against and as we reach certain delivery milestones of compute capacity under the amended commercial arrangement, amounts under this facility are made available for Anthropic to draw upon at its discretion. Draws against the facility will be in the form of new Anthropic convertible notes or, after an IPO or other liquidity event and subject to our ownership cap, Anthropic common stock, which will be issued to us in exchange for cash. Under this financing arrangement, in Q2 2026, we exercised our option to participate in subsequent Anthropic equity financings by investing $5.0 billion in Anthropic Series H nonvoting preferred stock, which reduced the amount available under the facility to $15.0 billion.
We recorded upward adjustments of approximately $50.5 billion in Q2 2026 and $62.8 billion for the six months ended June 30, 2026 to our nonvoting preferred stock in “Other income (expense), net” to reflect observable changes in price related to Anthropic’s fundings. In making these Level 3 fair value measurements, we utilized valuation methods based on information available, including the rights and obligations of the nonvoting preferred stock, other outstanding classes of securities, estimates of expected time to and type of liquidity events and anticipated securities offerings, and discounts for lack of marketability.
As of December 31, 2025 and June 30, 2026, the amounts recorded on our consolidated balance sheets for nonvoting preferred stock were approximately $14.8 billion and $92.5 billion. As of December 31, 2025 and June 30, 2026, the estimated fair value of our convertible notes recorded on our consolidated balance sheets was approximately $45.8 billion and $97.9 billion, and the associated unrealized gain included in “Accumulated other comprehensive income (loss)” was $39.5 billion and $92.0 billion.
In the event Anthropic consummates an IPO or other liquidity event, then-outstanding notes would be converted to nonvoting common stock, subject to our ownership cap, and nonvoting preferred stock would be converted to nonvoting common stock. Any then-outstanding notes that are not converted to nonvoting common stock would continue to be convertible to nonvoting common stock, subject to our ownership cap. We expect to be subject to a customary lock-up period following an IPO, and thereafter will remain subject to applicable securities laws restrictions.
OpenAI — In Q1 2026, we and OpenAI entered into (i) a commercial arrangement primarily for the provision of AWS cloud services, which includes the use and performance of AWS chips, and (ii) a joint collaboration agreement pursuant to which certain services using OpenAI models will be made available to the Company and on AWS. We also invested $15.0 billion in Series C Preferred Stock of OpenAI and entered into an equity commitment letter agreement (the “Letter Agreement”), pursuant to which we agreed to purchase additional shares of Series C Preferred Stock (the “Commitment Shares”) with an aggregate purchase price of $35.0 billion (the “Commitment Amount”). In Q2 2026, we invested $13.7 billion of the Commitment Amount in Series C Preferred Stock. We account for our $28.7 billion investment in Series C Preferred Stock recorded on our consolidated balance sheet as of June 30, 2026, and the remaining Commitment Amount as a component of our equity investments in private companies not accounted for under the equity-method, with future adjustments for observable changes in prices or impairments representing Level 3 fair value measurements recognized in “Other income (expense), net” on our consolidated statements of operations.
In the event OpenAI consummates an IPO or other liquidity event, then-outstanding Series C Preferred Stock would be converted to common stock. We expect to be subject to a customary lock-up period following an IPO and thereafter will remain subject to applicable securities laws restrictions.
Subsequent to June 30, 2026, we invested the remaining $21.3 billion Commitment Amount in shares of Series C Preferred Stock of OpenAI.
As of December 31, 2025 and June 30, 2026, equity investments in private companies not accounted for under the equity-method, which primarily relate to nonvoting preferred stock in Anthropic and preferred stock in OpenAI, had a carrying value of $16.2 billion and $122.3 billion, with adjustments for observable changes in prices or impairments representing Level 3 fair value measurements recognized in “Other income (expense), net” on our consolidated statements of operations.
As of December 31, 2025 and June 30, 2026, equity investments accounted for under the equity-method of accounting, including investments for which we have elected the fair value option, had a carrying value of $659 million and $395 million.
12
Table of Contents
We hold equity warrants giving us the right to acquire stock of other companies. As of December 31, 2025 and June 30, 2026, these warrants had a fair value of $2.7 billion and $4.3 billion, with gains and losses recognized in “Other income (expense), net” on our consolidated statements of operations. These warrants are classified as Level 2 and 3 assets.
These non-marketable investments are included within “Other assets” on our consolidated balance sheets.
Certain of our investments, including our investments in Anthropic and OpenAI, represent a variable interest in entities that we do not consolidate because we are not the primary beneficiary. Our maximum exposure to loss is generally limited to the current carrying values of these investments and any future funding commitments.
Consolidated Statements of Cash Flows Reconciliation
The following table provides a reconciliation of the amount of cash, cash equivalents, and restricted cash reported within the consolidated balance sheets to the total of the same such amounts shown in the consolidated statements of cash flows (in millions):
December 31, 2025		June 30, 2026
Cash and cash equivalents	$	86,810 			$	78,213
Restricted cash included in “Accounts receivable, net and other”	300 			283
Restricted cash included in “Other assets”	2,996 			2,431
Total cash, cash equivalents, and restricted cash shown in the consolidated statements of cash flows	$	90,106 			$	80,927
Note 3 — LEASES
We have entered into non-cancellable operating and finance leases for fulfillment network, data center, office, and physical store facilities as well as server and networking equipment, aircraft, and vehicles. Gross assets acquired under finance leases, including those where title transfers at the end of the lease, are recorded in “Property and equipment, net” and were $55.6 billion as of December 31, 2025 and June 30, 2026. Accumulated amortization associated with finance leases was $40.4 billion and $39.8 billion as of December 31, 2025 and June 30, 2026.
Lease cost recognized in our consolidated statements of operations is summarized as follows (in millions):
Three Months Ended June 30,		Six Months Ended June 30,
2025		2026		2025		2026
Operating lease cost	$	3,426 			$	4,118 			$	6,666 			$	8,035
Finance lease cost:
Amortization of lease assets	827 			692 			1,700 			1,425
Interest on lease liabilities	72 			108 			143 			209
Finance lease cost	899 			800 			1,843 			1,634
Variable lease cost	659 			718 			1,355 			1,460
Total lease cost	$	4,984 			$	5,636 			$	9,864 			$	11,129
Other information about lease amounts recognized in our consolidated financial statements is as follows:
December 31, 2025		June 30, 2026
Weighted-average remaining lease term – operating leases	10.0 years		10.0 years
Weighted-average remaining lease term – finance leases	12.6 years		12.6 years
Weighted-average discount rate – operating leases	3.7 	%		3.9 	%
Weighted-average discount rate – finance leases	3.4 	%		3.6 	%
13
Table of Contents
Our lease liabilities were as follows (in millions):
December 31, 2025
Operating Leases		Finance   Leases		Total
Gross lease liabilities	$	106,914 			$	14,917 			$	121,831
Less: imputed interest	(17,662)			(2,631)			(20,293)
Present value of lease liabilities	89,252 			12,286 			101,538
Less: current portion of lease liabilities	(12,655)			(1,544)			(14,199)
Total long-term lease liabilities	$	76,597 			$	10,742 			$	87,339
June 30, 2026
Operating Leases		Finance   Leases		Total
Gross lease liabilities	$	116,350 			$	16,660 			$	133,010
Less: imputed interest	(20,030)			(3,209)			(23,239)
Present value of lease liabilities	96,320 			13,451 			109,771
Less: current portion of lease liabilities	(13,745)			(1,688)			(15,433)
Total long-term lease liabilities	$	82,575 			$	11,763 			$	94,338
14
Table of Contents
Note 4 — COMMITMENTS AND CONTINGENCIES
Commitments
The following summarizes our principal contractual commitments, excluding open orders for purchases that support normal operations and are generally cancellable, as of June 30, 2026 (in millions):
Six Months Ended December 31,		Year Ended December 31,
2026		2027		2028		2029		2030		Thereafter		Total
Long-term debt principal and interest	$	2,361 			$	14,060 			$	17,087 			$	13,528 			$	11,112 			$	162,161 			$	220,309
Operating lease liabilities	9,336 			14,765 			13,924 			12,599 			11,269 			54,457 			116,350
Finance lease liabilities, including interest	1,088 			1,775 			1,885 			1,482 			1,269 			9,161 			16,660
Financing obligations, including interest (1)	352 			682 			694 			706 			720 			7,916 			11,070
Leases not yet commenced	4,018 			11,732 			9,278 			9,483 			9,227 			93,476 			137,214
Unconditional purchase obligations (2)	23,452 			33,026 			9,326 			7,961 			7,659 			48,641 			130,065
Other commitments (3)	2,145 			2,044 			1,212 			1,008 			963 			10,994 			18,366
Total commitments	$	42,752 			$	78,084 			$	53,406 			$	46,767 			$	42,219 			$	386,806 			$	650,034
___________________
(1)Includes non-cancellable financing obligations for fulfillment network and data center facilities. Excluding interest, current financing obligations of $358 million and $415 million are recorded within “Accrued expenses and other” and $7.8 billion and $8.9 billion are recorded within “Other long-term liabilities” as of December 31, 2025 and June 30, 2026. The weighted-average remaining term of the financing obligations was 15.0 years and 14.9 years and the weighted-average imputed interest rate was 2.9% and 3.2% as of December 31, 2025 and June 30, 2026.
(2)Includes unconditional purchase obligations related to long-term agreements to procure energy, acquire and license digital media content, acquire property and equipment, and license software that are not reflected on the consolidated balance sheets. For those agreements with variable terms or subject to certain regulatory approvals, we do not estimate the total obligation beyond any minimum quantities and/or pricing, or termination penalties, as of the reporting date. Purchase obligations associated with renewal provisions solely at the option of the content provider are included to the extent such commitments are fixed or a minimum amount is specified. Energy agreements based on actual generation without a fixed or minimum volume commitment are not included. Certain of our energy agreements also provide the right to receive energy certificates.
(3)Includes asset retirement obligations, the estimated timing and amounts of payments for rent and tenant improvements associated with build-to-suit lease arrangements that are under construction, and liabilities associated with digital media content agreements with initial terms greater than one year. Excludes approximately $7.1 billion of income tax contingencies for which we cannot make a reasonably reliable estimate of the amount and period of payment, if any.
On April 13, 2026, Amazon entered into a definitive merger agreement to acquire Globalstar, Inc. (“Globalstar”), a Delaware corporation, for a mix of cash and stock consideration. Under the terms of the merger agreement, prior to closing, Globalstar stockholders will elect to receive, for each share of Globalstar common stock they own, either (i) $90.00 in cash or (ii) 0.3210 shares of Amazon common stock (with a value capped at $90.00 per share). The value of the total consideration will vary based on the price of shares of Amazon common stock and the elections of Globalstar stockholders. The total consideration is also subject to (i) a proration mechanism that caps aggregate cash elections to a maximum of 40% of total Globalstar shares, and automatically converts excess cash consideration into stock consideration on a pro rata basis and (ii) a downward adjustment of a maximum of $110 million in the event Globalstar does not meet certain operational milestones. As of the date of the merger agreement, the acquisition implied a value for Globalstar of approximately $10.9 billion, including its debt. On the date of the merger agreement, we also entered into agreements with Apple Inc. (“Apple”), Globalstar’s largest customer, to provide certain services after the acquisition and to redeem certain equity interests held by Apple in a Globalstar special purpose entity.
The acquisition is expected to close in 2027, subject to the satisfaction of certain closing conditions, including receipt of regulatory approvals and Globalstar’s achievement of certain satellite replacement milestones.
Other Contingencies
We are disputing claims and denials of refunds or credits, and monitoring or evaluating potential claims, related to various non-income taxes (such as sales, value added, consumption, service, and similar taxes), including in jurisdictions in which we already collect and remit these taxes. These non-income tax controversies typically include (i) the taxability of products and services, including cross-border intercompany transactions, (ii) collection and withholding on transactions with
15
Table of Contents
third parties, including as a result of evolving requirements imposed on marketplaces with respect to third-party sellers, and (iii) the adequacy of compliance with reporting obligations, including evolving documentation requirements. Due to the inherent complexity and uncertainty of these matters and the judicial and regulatory processes in certain jurisdictions, the final outcome of any such controversies may be materially different from our expectations.
Legal Proceedings
The Company is involved from time to time in claims, proceedings, and litigation, including the matters described in Item 8 of Part II, “Financial Statements and Supplementary Data — Note 7 — Commitments and Contingencies — Legal Proceedings” of our 2025 Annual Report on Form 10-K and in Item 1 of Part I, “Financial Statements — Note 4 — Commitments and Contingencies — Legal Proceedings” of our Quarterly Report on Form 10-Q for the period ended March 31, 2026, as supplemented by the following:
Beginning in June 2019 with Wilcosky v. Amazon.com, Inc., now pending in the United States District Court for the Northern District of Illinois (“N.D. Ill.”), private litigants have filed a number of cases in U.S. federal and state courts, including Hogan v. Amazon.com, Inc. (N.D. Ill.), alleging, among other things, that Amazon’s collection, storage, use, retention, and protection of biometric identifiers violated the Illinois Biometric Information Privacy Act. The complaints allege purported classes of Illinois residents who had biometric identifiers collected through Amazon products or services, including Amazon’s voice-based AI products and services, Amazon Photos, Alexa, AWS cloud services, Amazon Connect, Amazon’s virtual try-on technology, and Amazon’s Just Walk Out technology. The complaints seek certification as class actions, unspecified amounts of damages, injunctive relief, attorneys’ fees, costs, and interest. We dispute the allegations of wrongdoing and intend to defend ourselves vigorously in these matters.
Since March 2020, private litigants, state Attorneys General, and the Federal Trade Commission have filed cases in the U.S., Canada, and the United Kingdom alleging, among other things: price fixing arrangements between each of Amazon and its vendors and Amazon and its third-party sellers; abuse of dominance, monopolization, and attempted monopolization; and consumer protection and unjust enrichment claims, in violation of federal and state antitrust, state consumer protection, and Canadian and U.K. antitrust laws. The first of these complaints was Frame-Wilson v. Amazon.com, Inc., which was filed in the United States District Court for the Western District of Washington (“W.D. Wash.”). These complaints seek billions of dollars of alleged damages, treble damages, punitive damages, injunctive relief, structural relief, civil penalties, attorneys’ fees, and costs. Some of the private plaintiff cases include allegations of distinct purported classes, including consumers who purchased a product through Amazon’s stores and consumers who purchased a product offered by Amazon through another e-commerce retailer. Some of the cases include allegations that Amazon has a monopoly in markets for online superstores, marketplace services, or intermediation services and that we unlawfully engage in anticompetitive practices relating to our pricing policies, selection of the Featured Offers, use of seller data, advertising practices, the structure of Prime, and promotion of our own products on our website. In the U.S., most of Amazon’s motions to dismiss were granted in part, but in each case, at least some of the claims survived. In Canada, class certification was denied in a case before the Federal Court of Canada, finding that plaintiffs had not stated a viable claim, and plaintiffs’ appeal of that ruling is pending. Three Canadian class actions before other courts are pre-certification. In the United Kingdom, two class actions have been certified and a third is pre-certification. In the U.S., one class action has been certified, and three others are pre-certification. We dispute the allegations of wrongdoing and intend to defend ourselves vigorously in these matters.
In June 2025, Xockets, Inc. filed two complaints against Amazon.com, Inc. and Amazon Web Services, Inc. in the United States District Court for the Western District of Texas. The complaints allege, among other things, that certain versions of the AWS Nitro System infringe U.S. Patent Nos. 11,080,209; 10,649,924; 11,082,350; 10,223,297; 9,378,161; 9,436,640; and 10,212,092. The complaints seek an unspecified amount of damages, enhanced damages, attorneys’ fees, costs, interest, and injunctive relief. In May 2026, Xockets filed a complaint against Amazon.com, Inc., Amazon Web Services, Inc., Annapurna Labs (U.S.), Inc., NVIDIA Corporation, and Microsoft Corporation at the United States International Trade Commission alleging, among other things, that EC2 P6e-GB200 UltraServers, DGX Cloud with GB200 on AWS, SageMaker HyperPod, and EKS with P6e-GB200 UltraServers infringe U.S. Patent Nos. 10,223,297; 9,378,161; 10,212,092; 9,436,640; and 11,082,350 and seeking injunctive relief. In June 2026, the International Trade Commission instituted an investigation. We dispute the allegations of wrongdoing and intend to defend ourselves vigorously in these matters.
In addition, we are regularly subject to claims, litigation, and other proceedings, including government inquiries and investigations that could lead to the foregoing and potential regulatory proceedings, involving patent and other intellectual property matters, taxes, labor and employment, competition and antitrust, privacy and data protection, consumer protection, commercial disputes, goods and services offered by us and by third parties, and other matters.
The outcomes of our legal proceedings and other contingencies are inherently unpredictable, subject to significant uncertainties, and could be material to our operating results and cash flows for a particular period. We evaluate, on a regular basis, developments in our legal proceedings and other contingencies that could affect the amount of liability, including amounts in excess of any previous accruals and reasonably possible losses disclosed, and make adjustments and changes to our
16
Table of Contents
accruals and disclosures as appropriate. For the matters we disclose that do not include an estimate of the amount of loss or range of losses, such an estimate is not possible or is immaterial, and we may be unable to estimate the possible loss or range of losses that could potentially result from the application of non-monetary remedies. Until the final resolution of such matters, if any of our estimates and assumptions change or prove to have been incorrect, we may experience losses in excess of the amounts recorded, which could have a material effect on our business, consolidated financial position, results of operations, or cash flows.
See also “Note 7 — Income Taxes.”
Note 5 — DEBT
As of June 30, 2026, we had $132.1 billion of unsecured senior notes outstanding (the “Notes”), including foreign currency-denominated Notes issued for general corporate purposes, the carrying values of which are subject to foreign exchange rate fluctuations. Our total long-term debt obligations are as follows (in millions):
Maturities (1)		Stated Interest Rates		Effective Interest Rates		December 31, 2025		June 30, 2026
2014 Notes issuance of $6.0 billion	2034 - 2044
4.80% - 4.95%
4.93% - 5.12%		2,750 			2,750
2017 Notes issuance of $17.0 billion	2027 - 2057
3.15% - 4.25%
3.25% - 4.33%		12,000 			12,000
2020 Notes issuance of $10.0 billion	2027 - 2060
1.20% - 2.70%
1.26% - 2.77%		7,750 			7,750
2021 Notes issuance of $18.5 billion	2028 - 2061
1.65% - 3.25%
1.70% - 3.31%		15,000 			12,250
April 2022 Notes issuance of $12.8 billion	2027 - 2062
3.30% - 4.10%
3.40% - 4.15%		9,750 			9,750
December 2022 Notes issuance of $8.3 billion	2027 - 2032
4.55% - 4.70%
4.61% - 4.74%		5,750 			5,750
2025 Notes issuance of $15.0 billion	2028 - 2065
3.90% - 5.55%
3.99% - 5.62%		15,000 			15,000
March 2026 Notes issuance of $37.0 billion (2)	2028 - 2076
3.85% - 6.05%
3.96% - 6.12%		— 			37,000
March 2026 Euro-denominated Notes issuance of €14.5 billion (3)	2028 - 2064
2.50% - 4.85%
2.59% - 4.88%		— 			16,550
May 2026 Swiss franc-denominated Notes issuance of CHF2.8 billion	2029 - 2051
0.84% - 2.08%
0.90% - 2.10%		— 			3,487
June 2026 Canadian Dollar-denominated Notes issuance of C$14.0 billion	2029 - 2056
3.40% - 5.00%
3.46% - 5.05%		— 			9,853
Other long-term debt							836 			855
Total face value of long-term debt							68,836 			132,995
Unamortized discount and issuance costs, net							(440)			(771)
Less: current portion of long-term debt							(2,748)			(3,330)
Long-term debt							$	65,648 			$	128,894
___________________
(1)  The weighted-average remaining lives of the 2014, 2017, 2020, 2021, April 2022, December 2022, 2025, March 2026, March 2026 Euro-denominated, May 2026 Swiss franc-denominated, and June 2026 Canadian Dollar-denominated Notes were 13.9, 14.9, 17.6, 15.6, 13.3, 3.9, 15.1, 16.4, 10.1, 8.9, and 14.8 years as of June 30, 2026. The combined weighted-average remaining life of the Notes was 14.2 years as of June 30, 2026.
(2)  Includes $2.8 billion of floating rate Notes due in 2028 and 2029. Interest is calculated using the compounded Secured Overnight Financing Rate (“SOFR”) plus 0.44% and 0.59%, respectively, and payable quarterly in arrears.
(3)  Includes €1.8 billion of floating rate Notes due in 2028. Interest is calculated using Euro Interbank Offered Rate (“EURIBOR”) plus 0.35%, payable quarterly in arrears.
Interest on the Notes is primarily payable semi-annually in arrears except for the fixed rate March 2026 Euro-denominated Notes and May 2026 Swiss franc-denominated Notes for which interest is primarily payable annually in arrears. We may redeem the fixed rate Notes at any time in whole, or from time to time, in part at specified redemption prices, except for the May 2026 Swiss franc-denominated Notes, which we may redeem on or after the applicable par call dates in whole, but not in part. The floating rate Notes are generally not redeemable prior to maturity. We are not subject to any financial covenants under the Notes.
The estimated fair value of the Notes was approximately $61.1 billion and $123.8 billion as of December 31, 2025 and June 30, 2026, which is based on quoted prices for our debt as of those dates.
17
Table of Contents
Subsequent to June 30, 2026, we issued $25.0 billion of U.S. Dollar-denominated Notes for general corporate purposes with maturities between 2029 and 2066, including $750 million of floating rate Notes due in 2029 based on the compounded SOFR plus 0.58%. The fixed rate Notes have stated interest rates between 4.60% and 6.25%, and effective interest rates between 4.67% and 6.33%.
We have U.S. Dollar and Euro commercial paper programs (the “Commercial Paper Programs”) under which we may from time to time issue unsecured commercial paper up to a total of $30.0 billion (including up to €3.0 billion) at the date of issue, with individual maturities that may vary but will not exceed 397 days from the date of issue. There were no borrowings outstanding under the Commercial Paper Programs as of December 31, 2025 and June 30, 2026. We use the net proceeds from the issuance of commercial paper for general corporate purposes.
We have an aggregate $20.0 billion in unsecured revolving credit facilities with syndicates of lenders, consisting of a $15.0 billion facility (the “Credit Agreement”) and a $5.0 billion 364-day facility (the “Short-Term Credit Agreement”). The Credit Agreement has a term that extends to November 2028 and may be extended for one or more additional one-year terms subject to approval by the lenders. The interest rate applicable to outstanding balances under the Credit Agreement is the applicable benchmark rate specified in the Credit Agreement plus 0.45%, with a commitment fee of 0.03% on the undrawn portion of the credit facility. The Short-Term Credit Agreement matures in October 2026 and may be extended for one additional period of 364 days subject to approval by the lenders. The interest rate applicable to outstanding balances under the Short-Term Credit Agreement is the SOFR specified in the Short-Term Credit Agreement plus 0.45%, with a commitment fee of 0.03% on the undrawn portion. There were no borrowings outstanding under the Credit Agreement and the Short-Term Credit Agreement as of December 31, 2025 and June 30, 2026.
In June 2026, we entered into a $17.5 billion unsecured delayed draw term loan with a syndicate of lenders (“Term Loan”), which matures three years from the date of borrowing and bears interest at the SOFR specified in the Term Loan plus a margin ranging from 0.625% to 0.875% based on our credit ratings. We may draw up to $17.5 billion in a single draw on any business day on or prior to September 30, 2026, after which any undrawn commitments will automatically terminate. Amounts borrowed and repaid may not be reborrowed. There were no borrowings outstanding under the Term Loan as of June 30, 2026.
We also utilize other short-term credit facilities for working capital purposes. There were $455 million and $325 million of borrowings outstanding under these facilities as of December 31, 2025 and June 30, 2026, which were included in “Accrued expenses and other” on our consolidated balance sheets.
Standby letters of credit are guarantees issued by financial institutions on our behalf, which can only be drawn in the event we fail to perform under the underlying obligation, and do not reduce the amount of borrowings available under our credit facilities. As of June 30, 2026, our total standby letter of credit facilities assigned to specific beneficiaries was $13.4 billion, primarily related to our payment-related services, and workers’ compensation and insurance programs.
Note 6 — STOCKHOLDERS’ EQUITY
Stock Repurchase Activity
In March 2022, the Board of Directors authorized a program to repurchase up to $10.0 billion of our common stock, with no fixed expiration. There were no repurchases of our common stock during the six months ended June 30, 2025 or 2026. As of June 30, 2026, we have $6.1 billion remaining under the repurchase program.
Stock Award Plans
Employees vest in restricted stock unit awards over the corresponding service term, generally between two and five years. The majority of outstanding restricted stock unit awards are granted at the date of hire or in Q2 as part of the annual compensation review and primarily vest quarterly in the relevant compensation year.
18
Table of Contents
Stock Award Activity
Common shares outstanding plus shares underlying outstanding stock awards totaled 11.0 billion as of December 31, 2025 and June 30, 2026. These totals include all vested and unvested stock awards outstanding, including those awards we estimate will be forfeited. Stock-based compensation expense is as follows (in millions):
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Cost of sales	$	250 			$	208 			$	398 			$	379
Fulfillment	880 			764 			1,377 			1,365
Technology and infrastructure	3,655 			3,701 			5,715 			5,987
Sales and marketing	1,207 			845 			1,860 			1,508
General and administrative	542 			520 			873 			831
Total stock-based compensation expense	$	6,534 			$	6,038 			$	10,223 			$	10,070
The following table summarizes our restricted stock unit activity for the six months ended June 30, 2026 (in millions):
Number of Units		Weighted-Average
Grant-Date
Fair Value
Outstanding as of December 31, 2025	222.5 			$	178
Units granted	98.4 			218
Units vested	(52.0)			162
Units forfeited	(24.5)			181
Outstanding as of June 30, 2026	244.4 			197
Scheduled vesting for outstanding restricted stock units as of June 30, 2026, is as follows (in millions):
Six Months Ended December 31,		Year Ended December 31,
2026		2027		2028		2029		2030		Thereafter		Total
Scheduled vesting — restricted stock units	53.2 			100.3 			61.8 			22.2 			4.8 			2.1 			244.4
As of June 30, 2026, there was $24.8 billion of net unrecognized compensation cost related to unvested stock-based compensation arrangements. This compensation is recognized on an accelerated basis with more than half of the compensation expected to be expensed in the next twelve months, and has a remaining weighted-average recognition period of one year.
19
Table of Contents
Changes in Stockholders’ Equity
The following table shows changes in stockholders’ equity (in millions):
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Total beginning stockholders’ equity	$	305,867 			$	441,914 			$	285,970 			$	411,065
Beginning common stock	111 			113 			111 			112
Stock-based compensation and issuance of employee benefit plan stock	1 			— 			1 			1
Ending common stock	112 			113 			112 			113
Beginning and ending treasury stock	(7,837)			(7,837)			(7,837)			(7,837)
Beginning additional paid-in capital	124,514 			143,979 			120,864 			140,024
Stock-based compensation and issuance of employee benefit plan stock	6,409 			5,640 			10,059 			9,595
Ending additional paid-in capital	130,923 			149,619 			130,923 			149,619
Beginning accumulated other comprehensive income (loss)	(914)			24,868 			(34)			28,230
Other comprehensive income (loss)	3,334 			41,419 			2,454 			38,057
Ending accumulated other comprehensive income (loss)	2,420 			66,287 			2,420 			66,287
Beginning retained earnings	189,993 			280,791 			172,866 			250,536
Net income	18,164 			62,647 			35,291 			92,902
Ending retained earnings	208,157 			343,438 			208,157 			343,438
Total ending stockholders’ equity	$	333,775 			$	551,620 			$	333,775 			$	551,620
20
Table of Contents
Accumulated Other Comprehensive Income (Loss)
The following table summarizes the changes in “Accumulated other comprehensive income (loss)” by separate components (in millions):
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Total beginning accumulated other comprehensive income (loss), net of tax of $(1,029), $(8,573), $(1,762), and $(9,384)	$	(914)			$	24,868 			$	(34)			$	28,230
Foreign currency translation adjustments:
Beginning balance, net of tax of $226, $85, $292, and $98	(4,639)			(2,712)			(6,174)			(1,948)
Foreign currency translation adjustments, net of tax of $(142), $(66), $(208), and $(79)	3,314 			(799)			4,849 			(1,563)
Ending balance, net of tax of $84, $19, $84, and $19	(1,325)			(3,511)			(1,325)			(3,511)
Unrealized gains (losses) on net investment hedging instruments:
Beginning balance, net of tax of $0, $24, $0, and $0	— 			(85)			— 			—
Change in net unrealized gains (losses), net of tax of $0, $(69), $0, and $(45)	— 			229 			— 			144
Ending balance, net of tax of $0, $(45), $0, and $(45)	— 			144 			— 			144
Unrealized gains (losses) on available-for-sale debt securities:
Beginning balance, net of tax of $(1,256), $(8,679), $(2,054), and $(9,481)	3,722 			27,659 			6,139 			30,170
Change in net unrealized gains (losses), net of tax of $(12), $(13,695), $(23), and $(14,035)	40 			41,988 			77 			42,814
Reclassification adjustments for net losses (gains) included in “Other income (expense), net,” net of tax of $5, $0, $814, and $1,142	(17)			— 			(2,471)			(3,337)
Ending balance, net of tax of $(1,263), $(22,374), $(1,263), and $(22,374)	3,745 			69,647 			3,745 			69,647
Other:
Beginning balance, net of tax of $1, $(3), $0, and $(1)	3 			6 			1 			8
Other, net of tax of $(1), $1, $0, and $(1)	(3)			1 			(1)			(1)
Ending balance, net of tax of $0, $(2), $0, and $(2)	— 			7 			— 			7
Total ending accumulated other comprehensive income (loss), net of tax of $(1,179), $(22,402), $(1,179), and $(22,402)	$	2,420 			$	66,287 			$	2,420 			$	66,287
Note 7 — INCOME TAXES
Our tax provision or benefit from income taxes for interim periods is determined using an estimate of our annual effective tax rate, adjusted for discrete items, if any, that are taken into account in the relevant period. Each quarter we update our estimate of the annual effective tax rate, and if our estimated tax rate changes, we make a cumulative adjustment.
Our quarterly tax provision, and our quarterly estimate of our annual effective tax rate, is subject to significant variation due to several factors, including variability in accurately predicting our pre-tax and taxable income and loss and the mix of jurisdictions to which they relate, intercompany transactions, the applicability of special tax regimes, changes in how we do business, acquisitions, investments, developments in tax controversies, changes in our stock price, changes in our deferred tax assets and liabilities and their valuation, foreign currency gains (losses), changes in statutes, regulations, case law, and administrative practices, principles, and interpretations related to tax, including changes to the global tax framework, competition, and other laws and accounting rules in various jurisdictions, and relative changes of expenses or losses for which tax benefits are not recognized. Our effective tax rate can be more or less volatile based on the amount of pre-tax income or
21
Table of Contents
loss. For example, the impact of discrete items and non-deductible expenses on our effective tax rate is greater when our pre-tax income is lower. In addition, we record valuation allowances against deferred tax assets when there is uncertainty about our ability to generate future income in relevant jurisdictions.
For 2026, we estimate that our effective tax rate will be adversely affected by state income taxes and favorably impacted by the U.S. federal research and development credit.
Our income tax provision for the six months ended June 30, 2025 was $7.2 billion, which included $753 million of net discrete tax benefits primarily attributable to excess tax benefits from stock-based compensation. Our income tax provision for the six months ended June 30, 2026 was $27.8 billion, which included $15.9 billion of net discrete tax expense primarily attributable to the upward adjustments to our investments in Anthropic.
On February 18, 2026, the IRS issued Notice 2026-7 (the “2026 Notice”), which included guidance on the U.S. tax treatment of previously capitalized domestic research and development costs. We expect the 2026 Notice, which applied retroactively to 2025, to result in a significant decrease of 2024 and 2025 cash taxes paid. Cash paid for income taxes, net of refunds was $4.8 billion and $2.7 billion in Q2 2025 and Q2 2026, and $5.6 billion and $4.0 billion for the six months ended June 30, 2025 and 2026.
As of December 31, 2025 and June 30, 2026, income tax contingencies were approximately $6.6 billion and $7.1 billion. Changes in tax laws, regulations, administrative practices, principles, and interpretations may impact our tax contingencies. Due to various factors, including the inherent complexities and uncertainties of the judicial, administrative, and regulatory processes in certain jurisdictions, the timing of the resolution of income tax controversies is highly uncertain, and the amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ from the amounts accrued. It is reasonably possible that within the next twelve months we will receive additional assessments by various tax authorities or possibly reach resolution of income tax controversies in one or more jurisdictions. These assessments or settlements could result in changes to our contingencies related to positions on prior years’ tax filings.
We are under examination, or may be subject to examination, by the Internal Revenue Service for the calendar year 2016 and thereafter. These examinations may lead to ordinary course adjustments or proposed adjustments to our taxes or our net operating losses with respect to years under examination as well as subsequent periods.
We are also subject to taxation in various states and foreign jurisdictions including Germany, India, Japan, Luxembourg, and the United Kingdom. We are under, or may be subject to, audit or examination and additional assessments by the relevant authorities in respect of these particular jurisdictions primarily for 2011 and thereafter. We are currently disputing tax assessments in multiple jurisdictions, including with respect to the allocation and characterization of income.
In September 2022, the Luxembourg tax authority (“LTA”) denied the tax basis of certain intangible assets that we distributed from Luxembourg to the U.S. in 2021. When we are assessed by the LTA, we will need to remit taxes related to this matter. We believe the LTA’s position is without merit, we intend to defend ourselves vigorously in this matter, and we expect to recoup taxes paid.
The Indian tax authority (“ITA”) has asserted that tax applies to cloud services fees paid to Amazon in the U.S. We will need to remit taxes related to this matter until it is resolved, which payments could be significant in the aggregate. We believe the ITA’s position is without merit, we are defending our position vigorously, and we expect to recoup taxes paid. If this matter is adversely resolved, we could recognize significant additional tax expense, including for taxes previously paid.
Note 8 — SEGMENT INFORMATION
We have organized our operations into three segments: North America, International, and AWS. We allocate to segment results the operating expenses “Fulfillment,” “Technology and infrastructure,” “Sales and marketing,” and “General and administrative” based on usage, which is generally reflected in the segment in which the costs are incurred. The majority of technology costs recorded in “Technology and infrastructure” are incurred in the U.S. and are included in our North America and AWS segments. The majority of infrastructure costs recorded in “Technology and infrastructure” are allocated to the AWS segment based on usage. There are no internal revenue transactions between our reportable segments. Our chief operating decision maker (“CODM”) is our President and Chief Executive Officer. Our CODM regularly reviews consolidated net sales, consolidated operating expenses, and consolidated operating income (loss) by segment. Amounts included in consolidated operating expenses include “Cost of sales,” “Fulfillment,” “Technology and infrastructure,” “Sales and marketing,” “General and administrative,” and “Other operating expense (income), net.” Our CODM manages our business primarily by reviewing consolidated results by segment on a quarterly basis, and using those results along with forecasts and other non-financial information in our annual budgeting process.
22
Table of Contents
North America
The North America segment primarily consists of amounts earned from retail sales of consumer products (including from sellers) and advertising and subscription services through North America-focused online and physical stores. This segment includes export sales from these online stores.
International
The International segment primarily consists of amounts earned from retail sales of consumer products (including from sellers) and advertising and subscription services through internationally-focused online stores. This segment includes export sales from these internationally-focused online stores (including export sales from these online stores to customers in the U.S., Mexico, and Canada), but excludes export sales from our North America-focused online stores.
AWS
The AWS segment consists of amounts earned from global sales of compute, storage, database, and other services for start-ups, enterprises, government agencies, and academic institutions.
Information on reportable segments and reconciliation to consolidated net income is as follows (in millions):
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
North America
Net sales	$	100,068 			$	116,177 			$	192,955 			$	220,320
Operating expenses	92,551 			107,054 			179,597 			202,930
Operating income	$	7,517 			$	9,123 			$	13,358 			$	17,390
International
Net sales	$	36,761 			$	42,197 			$	70,274 			$	81,986
Operating expenses	35,267 			40,480 			67,763 			78,845
Operating income	$	1,494 			$	1,717 			$	2,511 			$	3,141
AWS
Net sales	$	30,873 			$	42,232 			$	60,140 			$	79,819
Operating expenses	20,713 			25,611 			38,433 			49,037
Operating income	$	10,160 			$	16,621 			$	21,707 			$	30,782
Consolidated
Net sales	$	167,702 			$	200,606 			$	323,369 			$	382,125
Operating expenses	148,531 			173,145 			285,793 			330,812
Operating income	19,171 			27,461 			37,576 			51,313
Total non-operating income	1,686 			53,396 			4,960 			69,378
Provision for income taxes	(2,678)			(18,199)			(7,231)			(27,759)
Equity-method investment activity, net of tax	(15)			(11)			(14)			(30)
Net income	$	18,164 			$	62,647 			$	35,291 			$	92,902
23
Table of Contents
Net sales by groups of similar products and services, which also have similar economic characteristics, is as follows (in millions):
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Net Sales:
Online stores (1)	$	61,485 			$	70,432 			$	118,892 			$	134,686
Physical stores (2)	5,595 			5,794 			11,128 			11,579
Third-party seller services (3)	40,348 			46,780 			76,860 			88,358
Advertising services (4)	15,694 			19,809 			29,615 			37,052
Subscription services (5)	12,208 			13,730 			23,923 			27,157
AWS	30,873 			42,232 			60,140 			79,819
Other (6)	1,499 			1,829 			2,811 			3,474
Consolidated	$	167,702 			$	200,606 			$	323,369 			$	382,125
____________________________
(1)Includes product sales and digital media content where we record revenue gross. We leverage our retail infrastructure to offer a wide selection of consumable and durable goods that includes media products available in both a physical and digital format, such as books, videos, games, music, and software. These product sales include digital products sold on a transactional basis. Digital media content subscriptions that provide unlimited viewing or usage rights are included in “Subscription services.”
(2)Includes product sales where our customers physically select items in a store. Sales to customers who order goods online for delivery or pickup at our physical stores are included in “Online stores.”
(3)Includes commissions and any related fulfillment and shipping fees, and other third-party seller services.
(4)Includes sales of advertising services to sellers, vendors, publishers, authors, and others, through programs such as sponsored ads, display, and video advertising.
(5)Includes annual and monthly fees associated with Amazon Prime memberships, as well as digital video, audiobook, digital music, e-book, and other non-AWS subscription services.
(6)Includes sales related to various other offerings (such as shipping services, healthcare services, and certain licensing and distribution of video content) and our co-branded credit card agreements.
Total segment assets exclude corporate assets, such as cash and cash equivalents, marketable securities, other long-term investments, corporate facilities, goodwill and other acquired intangible assets, and tax assets. Technology infrastructure assets, which are included in property and equipment, net, net additions, and the depreciation and amortization expense on these assets, are allocated among the segments based on usage, with the majority allocated to the AWS segment. Usage of technology infrastructure assets by the North America and International segments, and the related allocation of total net additions, can fluctuate on a quarter-to-quarter basis, and is affected by seasonality, peak periods, new product or service offerings, and other factors.
Total segment assets reconciled to consolidated amounts are as follows (in millions):
December 31, 2025		June 30, 2026
North America (1)	$	235,652 			$	249,006
International (1)	81,984 			85,271
AWS (2)	252,588 			350,170
Corporate	247,818 			411,242
Consolidated	$	818,042 			$	1,095,689
___________________
(1)North America and International segment assets primarily consist of property and equipment, operating leases, inventory, accounts receivable, and digital video and music content.
(2)AWS segment assets primarily consist of property and equipment, accounts receivable, and operating leases.
24
Table of Contents
Property and equipment, net by segment is as follows (in millions):
December 31, 2025		June 30, 2026
North America	$	122,043 			$	135,013
International	30,632 			32,879
AWS	190,055 			263,750
Corporate	14,295 			14,404
Consolidated	$	357,025 			$	446,046
Total net additions to property and equipment include technology infrastructure assets and the effect of non-cash activity such as property and equipment acquired but not yet paid.
Total net additions to property and equipment are as follows (in millions):
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
North America (1)	$	11,272 			$	12,139 			$	16,368 			$	23,265
International (1)	2,531 			2,540 			4,037 			4,267
AWS (2)	16,043 			48,604 			36,507 			90,120
Corporate	915 			608 			1,298 			996
Consolidated	$	30,761 			$	63,891 			$	58,210 			$	118,648
___________________
(1)Includes property and equipment added under finance leases of $21 million and $235 million in Q2 2025 and Q2 2026, and $75 million and $472 million for the six months ended June 30, 2025 and 2026.
(2)Includes property and equipment added under finance leases of $916 million and $328 million in Q2 2025 and Q2 2026, and $916 million and $1.7 billion for the six months ended June 30, 2025 and 2026.
Depreciation and amortization expense on property and equipment, including corporate property and equipment, are allocated to all segments based on usage.
Total depreciation and amortization expense, by segment, is as follows (in millions):
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
North America	$	3,742 			$	4,500 			$	7,272 			$	8,780
International	1,180 			1,293 			2,316 			2,570
AWS	4,844 			8,076 			9,234 			15,353
Consolidated	$	9,766 			$	13,869 			$	18,822 			$	26,703
25
Table of Contents
Item 2.	Management’s Discussion and Analysis of Financial Condition and Results of Operations
Forward-Looking Statements
This Quarterly Report on Form 10-Q includes forward-looking statements within the meaning of the Private Securities Litigation Reform Act of 1995. All statements other than statements of historical fact, including statements regarding guidance, industry prospects, or future results of operations or financial position, made in this Quarterly Report on Form 10-Q are forward-looking. We use words such as anticipates, believes, expects, future, intends, and similar expressions to identify forward-looking statements. Forward-looking statements reflect management’s current expectations and are inherently uncertain. Actual results and outcomes could differ materially for a variety of reasons, including, among others, fluctuations in foreign exchange rates and energy prices, changes in global economic conditions, tariff and trade policies, resource and supply volatility, including for memory chips, and customer demand and spending, inflation, interest rates, regional labor market constraints, world events, the rate of growth of the internet, online commerce, cloud services, and new and emerging technologies, the amount that Amazon.com invests in new business opportunities and the timing of those investments, the mix of products and services sold to customers, the mix of net sales derived from products as compared with services, the extent to which we owe income or other taxes, competition, management of growth, potential fluctuations in operating results, international growth and expansion, the outcomes of claims, litigation, government investigations, and other proceedings, fulfillment, sortation, delivery, and data center optimization, risks of inventory management, variability in demand, the degree to which we enter into, maintain, and develop commercial agreements, proposed and completed acquisitions and strategic transactions, payments risks, and risks of fulfillment throughput and productivity. In addition, global economic and geopolitical conditions and additional or unforeseen circumstances, developments, or events may give rise to or amplify many of these risks. These risks and uncertainties, as well as other risks and uncertainties that could cause our actual results or outcomes to differ significantly from management’s expectations, are described in greater detail in Item 1A of Part II, “Risk Factors.”
For additional information, see Item 7 of Part II, “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Overview” of our 2025 Annual Report on Form 10-K.
Critical Accounting Estimates
The preparation of financial statements in conformity with GAAP requires estimates and assumptions that affect the reported amounts of assets and liabilities, revenues and expenses, and related disclosures of contingent liabilities in the consolidated financial statements and accompanying notes. Critical accounting estimates are those estimates made in accordance with GAAP that involve a significant level of estimation uncertainty and have had or are reasonably likely to have a material impact on the financial condition or results of operations of the Company. Based on this definition, we have identified the critical accounting estimates addressed below. We also have other key accounting policies, which involve the use of estimates, judgments, and assumptions that are significant to understanding our results. For additional information, see Item 8 of Part II, “Financial Statements and Supplementary Data — Note 1 — Description of Business, Accounting Policies, and Supplemental Disclosures” of our 2025 Annual Report on Form 10-K and Item 1 of Part I, “Financial Statements — Note 1 — Accounting Policies and Supplemental Disclosures,” of this Form 10-Q. Although we believe that our estimates, assumptions, and judgments are reasonable, they are based upon information presently available. Actual results may differ significantly from these estimates under different assumptions, judgments, or conditions.
Inventories
Inventories, consisting of products available for sale, are primarily accounted for using the first-in, first-out method, and are valued at the lower of cost and net realizable value. This valuation requires us to make judgments, based on currently available information, about the likely method of disposition, such as through sales to individual customers, returns to product vendors, or liquidations, and expected recoverable values of each disposition category. These assumptions about future disposition of inventory are inherently uncertain and changes in our estimates and assumptions may cause us to realize material write-downs in the future. As a measure of sensitivity, for every 1% of additional inventory valuation allowance as of June 30, 2026, we would have recorded an additional cost of sales of approximately $405 million.
In addition, we enter into supplier commitments for certain electronic device components and certain products. These commitments are based on forecasted customer demand. If we reduce these commitments, we may incur additional costs.
Income Taxes
We are subject to income taxes in the U.S. (federal and state) and numerous foreign jurisdictions. Tax laws, regulations, administrative practices, principles, and interpretations in various jurisdictions may be subject to significant change, with or without notice, due to economic, political, and other conditions, and significant judgment is required in evaluating and estimating our provision and accruals for these taxes. There are many transactions that occur during the ordinary course of business for which the ultimate tax determination is uncertain. In addition, our actual and forecasted earnings are subject to
26
Table of Contents
change due to economic, political, and other conditions and significant judgment is required in determining our ability to use our deferred tax assets.
Our effective tax rates could be affected by numerous factors, such as changes in our business operations, acquisitions, investments, entry into new businesses and geographies, intercompany transactions, the relative amount of our foreign earnings, including earnings being lower than anticipated in jurisdictions where we have lower statutory rates and higher than anticipated in jurisdictions where we have higher statutory rates, losses incurred in jurisdictions for which we are not able to realize related tax benefits, the applicability of special tax regimes, changes in foreign exchange rates, changes in our stock price, changes to our forecasts of income and loss and the mix of jurisdictions to which they relate, changes in our deferred tax assets and liabilities and their valuation, changes in the laws, regulations, administrative practices, principles, and interpretations related to tax, including changes to the global tax framework, competition, and other laws and accounting rules in various jurisdictions. In addition, a number of countries have enacted or are actively pursuing changes to their tax laws applicable to corporate multinationals.
We are also currently subject to tax controversies in various jurisdictions, and these jurisdictions may assess additional income tax liabilities against us. Developments in an audit, investigation, or other tax controversy could have a material effect on our operating results or cash flows in the period or periods for which that development occurs, as well as for prior and subsequent periods. We regularly assess the likelihood of an adverse outcome resulting from these proceedings to determine the adequacy of our tax accruals. Although we believe our tax estimates are reasonable, the final outcome of audits, investigations, and any other tax controversies could be materially different from our historical income tax provisions and accruals.
Liquidity and Capital Resources
Cash flow information is as follows (in millions):
Three Months Ended
June 30,		Six Months Ended
June 30,		Twelve Months Ended
June 30,
2025		2026		2025		2026		2025		2026
Cash provided by (used in):
Operating activities	$	32,515 			$	45,387 			$	49,530 			$	71,419 			$	121,137 			$	161,403
Investing activities	(39,424)			(79,245)			(69,227)			(143,457)			(123,569)			(216,775)
Financing activities	(2,539)			10,146 			(2,586)			62,913 			(8,652)			75,160
Our principal sources of liquidity are cash flows generated from operations and our cash, cash equivalents, and marketable securities balances, which, at fair value, were $123.0 billion as of December 31, 2025 and June 30, 2026. Amounts held in foreign currencies were $29.7 billion and $20.4 billion as of December 31, 2025 and June 30, 2026. Our foreign currency balances include British Pounds, Canadian Dollars, Euros, Indian Rupees, and Japanese Yen.
Cash provided by (used in) operating activities was $32.5 billion and $45.4 billion for Q2 2025 and Q2 2026, and $49.5 billion and $71.4 billion for the six months ended June 30, 2025 and 2026. Our operating cash flows result primarily from cash received from our consumer, seller, developer, enterprise, and content creator customers, and advertisers, offset by cash payments we make for products and services, employee compensation, payment processing and related transaction costs, operating leases, and interest payments. Cash received from our customers and other activities generally corresponds to our net sales. The increase in operating cash flow for the trailing twelve months ended June 30, 2026, compared to the comparable prior year period, was due to an increase in net income, excluding non-cash income and expenses, and changes in working capital. Working capital at any specific point in time is subject to many variables, including variability in demand, inventory management and category expansion, the timing of cash receipts and payments, customer and vendor payment terms, and fluctuations in foreign exchange rates.
Cash provided by (used in) investing activities corresponds with cash capital expenditures, including leasehold improvements, incentives received from property and equipment vendors, proceeds from asset sales, cash outlays for acquisitions, investments in other companies and intellectual property rights, and purchases, sales, and maturities of marketable securities. Cash provided by (used in) investing activities was $(39.4) billion and $(79.2) billion for Q2 2025 and Q2 2026, and $(69.2) billion and $(143.5) billion for the six months ended June 30, 2025 and 2026, with the variability caused primarily by purchases, sales, and maturities of marketable securities and cash capital expenditures. Cash capital expenditures were $31.4 billion and $53.1 billion during Q2 2025 and Q2 2026, and $55.6 billion and $96.3 billion for the six months ended June 30, 2025 and 2026, which primarily reflect investments in technology infrastructure (the majority of which is to support AWS business growth) and in additional capacity to support our fulfillment network, both of which we expect to increase in 2026. We made cash payments, net of acquired cash, related to acquisition and other investment activity of $1.7 billion and $24.4 billion during Q2 2025 and Q2 2026, and $1.7 billion and $39.8 billion for the six months ended June 30, 2025 and 2026. In Q2 2025, we invested $1.3 billion in convertible notes from Anthropic. We invested $28.7 billion in OpenAI’s Series C Preferred Stock for the six months ended June 30, 2026, including $13.7 billion invested in Q2 2026. Subsequent to June 30, 2026, we funded
27
Table of Contents
the remaining Commitment Amount of $21.3 billion. In Q2 2026, we also invested $10.0 billion in Anthropic nonvoting preferred stock.
Cash provided by (used in) financing activities was $(2.5) billion and $10.1 billion for Q2 2025 and Q2 2026, and $(2.6) billion and $62.9 billion for the six months ended June 30, 2025 and 2026. Cash inflows from financing activities resulted from proceeds from short-term debt, and other and long-term debt of $2.1 billion and $22.9 billion for Q2 2025 and Q2 2026, and $4.7 billion and $82.4 billion for the six months ended June 30, 2025 and 2026. We expect to undertake additional financing activities in 2026. Cash outflows from financing activities resulted from payments of short-term debt, and other, long-term debt, finance leases, and financing obligations of $4.6 billion and $12.8 billion for Q2 2025 and Q2 2026, and $7.2 billion and $19.5 billion for the six months ended June 30, 2025 and 2026. Property and equipment acquired under finance leases was $937 million and $563 million during Q2 2025 and Q2 2026, and $991 million and $2.1 billion for the six months ended June 30, 2025 and 2026.
We had no borrowings outstanding under the two unsecured revolving credit facilities or the commercial paper programs as of June 30, 2026. See Item 1 of Part I, “Financial Statements — Note 5 — Debt” for additional information.
Certain foreign subsidiary earnings and losses are subject to current U.S. taxation and the subsequent repatriation of those earnings is not subject to tax in the U.S. We intend to invest substantially all of our foreign subsidiary earnings, as well as our capital in our foreign subsidiaries, indefinitely outside of the U.S. in those jurisdictions in which we would incur significant, additional costs upon repatriation of such amounts.
Our U.S. taxable income is reduced by accelerated depreciation deductions and the amortization of previously capitalized research and development costs. U.S. tax rules provide for enhanced accelerated depreciation deductions by allowing the election of full expensing of qualified property, as well as various alternatives for amortizing previously capitalized research and development costs. The 2026 Notice, which applied retroactively to 2025, is expected to result in a significant decrease of 2024 and 2025 cash taxes paid. Cash paid for U.S. (federal and state) and foreign income taxes (net of refunds) totaled $4.8 billion and $2.7 billion for Q2 2025 and Q2 2026, and $5.6 billion and $4.0 billion for the six months ended June 30, 2025 and 2026.
As of December 31, 2025 and June 30, 2026, restricted cash, cash equivalents, and marketable securities were $3.3 billion and $2.7 billion. See Item 1 of Part I, “Financial Statements — Note 4 — Commitments and Contingencies” and “Financial Statements — Note 5 — Debt” for additional discussion of our principal contractual commitments, as well as our pledged assets. Additionally, we have purchase obligations and open purchase orders, including for inventory and capital expenditures, that support normal operations and are primarily due in the next twelve months. These purchase obligations and open purchase orders are generally cancellable in full or in part through the contractual provisions.
We believe that cash flows generated from operations and our cash, cash equivalents, and marketable securities balances, as well as our borrowing arrangements and other financing activities, will be sufficient to meet our anticipated operating cash needs for at least the next twelve months. However, any projections of future cash needs and cash flows are subject to substantial uncertainty. See Item 1A of Part II, “Risk Factors.” We continually evaluate opportunities to sell additional equity or debt securities, obtain credit facilities, obtain finance and operating lease arrangements, enter into financing obligations, repurchase common stock, pay dividends, repurchase, refinance, or otherwise restructure our debt, or access capital through other financing arrangements for strategic reasons or to further strengthen our financial position.
The sale of additional equity or convertible debt securities would be dilutive to our shareholders. In addition, we will, from time to time, consider the acquisition of, or investment in, complementary businesses, products, services, capital infrastructure, and technologies, which might affect our liquidity requirements or cause us to secure additional financing, or issue additional equity or debt securities. There can be no assurance that additional credit lines or financing instruments will be available in amounts or on terms acceptable to us, if at all. In addition, economic conditions and actions by policymaking bodies are contributing to changing interest rates and significant capital market volatility, which, along with any increases in our borrowing levels, could increase our future borrowing costs.
28
Table of Contents
Results of Operations
We have organized our operations into three segments: North America, International, and AWS. These segments reflect the way the Company evaluates its business performance and manages its operations. See Item 1 of Part I, “Financial Statements — Note 8 — Segment Information.”
Overview
Macroeconomic factors, including changes in inflation and interest rates, resource and supply volatility, global economic and geopolitical developments, including unpredictable shifts in global tariff and trade policies, and the development and adoption of technologies and services, including artificial intelligence, have direct and indirect impacts on our results of operations that are difficult to predict, isolate, and quantify. These could affect customer demand for our products and services, our ability to forecast growth needs, expenses, and benefits from new technologies. Further, we expect to continue making additional investments in our artificial intelligence initiatives. We expect some or all of these factors to continue to impact our results of operations into Q3 2026.
Net Sales
Net sales include product and service sales. Product sales represent revenue from the sale of products and related shipping fees and digital media content where we record revenue gross. Service sales primarily represent third-party seller fees, which include commissions and any related fulfillment and shipping fees, AWS sales, advertising services, Amazon Prime membership fees, and certain digital media content subscriptions. Net sales information is as follows (in millions):
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Net Sales:
North America	$	100,068 			$	116,177 			$	192,955 			$	220,320
International	36,761 			42,197 			70,274 			81,986
AWS	30,873 			42,232 			60,140 			79,819
Consolidated	$	167,702 			$	200,606 			$	323,369 			$	382,125
Year-over-year Percentage Growth:
North America	11 	%		16 	%		9 	%		14 	%
International	16 			15 			10 			17
AWS	17 			37 			17 			33
Consolidated	13 			20 			11 			18
Year-over-year Percentage Growth, excluding the effect of foreign exchange rates:
North America	11 	%		16 	%		10 	%		14 	%
International	11 			15 			9 			13
AWS	17 			37 			17 			33
Consolidated	12 			20 			11 			17
Net Sales Mix:
North America	60 	%		58 	%		60 	%		58 	%
International	22 			21 			22 			21
AWS	18 			21 			18 			21
Consolidated	100 	%		100 	%		100 	%		100 	%
Sales increased 20% in Q2 2026, and 18% for the six months ended June 30, 2026 compared to the comparable prior year periods. Changes in foreign exchange rates did not significantly impact net sales for Q2 2026, but increased net sales by $3.0 billion for the six months ended June 30, 2026. For a discussion of the effect of foreign exchange rates on sales growth, see “Effect of Foreign Exchange Rates” below.
North America sales increased 16% in Q2 2026, and 14% for the six months ended June 30, 2026 compared to the comparable prior year periods. The sales growth primarily reflects increased unit sales, including sales by third-party sellers, advertising sales, and subscription services. Increased unit sales were driven largely by our continued focus on price, selection, and
29
Table of Contents
convenience for our customers, including from our fast shipping offers. Changes in foreign exchange rates increased North America net sales by $139 million for Q2 2026, and by $485 million for the six months ended June 30, 2026.
International sales increased 15% in Q2 2026, and 17% for the six months ended June 30, 2026 compared to the comparable prior year periods. The sales growth primarily reflects increased unit sales, including sales by third-party sellers, advertising sales, and subscription services. Increased unit sales were driven largely by our continued focus on price, selection, and convenience for our customers, including from our fast shipping offers. Changes in foreign exchange rates did not significantly impact International net sales for Q2 2026, but increased International net sales by $2.4 billion for the six months ended June 30, 2026.
AWS sales increased 37% in Q2 2026, and 33% for the six months ended June 30, 2026 compared to the comparable prior year periods. The sales growth primarily reflects increased customer usage, partially offset by pricing changes primarily driven by long-term customer contracts.
Operating Expenses
Information about operating expenses is as follows (in millions):
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Operating Expenses:
Cost of sales	$	80,809 			$	95,778 			$	157,785 			$	183,241
Fulfillment	25,976 			29,633 			50,569 			56,922
Technology and infrastructure	27,166 			33,158 			50,160 			62,725
Sales and marketing	11,416 			11,698 			21,179 			22,012
General and administrative	2,965 			2,788 			5,593 			5,375
Other operating expense (income), net	199 			90 			507 			537
Total operating expenses	$	148,531 			$	173,145 			$	285,793 			$	330,812
Year-over-year Percentage Growth (Decline):
Cost of sales	10 	%		19 	%		8 	%		16 	%
Fulfillment	10 			14 			10 			13
Technology and infrastructure	22 			22 			17 			25
Sales and marketing	9 			2 			5 			4
General and administrative	(3)			(6)			(3)			(4)
Other operating expense (income), net	108 			(54)			56 			6
Percent of Net Sales:
Cost of sales	48.2 	%		47.7 	%		48.8 	%		48.0 	%
Fulfillment	15.5 			14.8 			15.6 			14.9
Technology and infrastructure	16.2 			16.5 			15.5 			16.4
Sales and marketing	6.8 			5.8 			6.5 			5.8
General and administrative	1.8 			1.4 			1.7 			1.4
Other operating expense (income), net	0.1 			— 			0.2 			0.1
Cost of Sales
Cost of sales primarily consists of the purchase price of consumer products, inbound and outbound shipping costs, including costs related to sortation and delivery centers and where we are the transportation service provider, and digital media content costs where we record revenue gross, including video and music.
The increase in cost of sales in Q2 2026 and for the six months ended June 30, 2026, compared to the comparable prior year periods, is primarily due to increased product and shipping costs resulting from increased sales, partially offset by operational efficiencies. Cost of sales in Q2 2026 includes tariff refunds received under the IEEPA. Changes in foreign exchange rates did not significantly impact cost of sales for Q2 2026, but increased cost of sales by $1.8 billion for the six months ended June 30, 2026.
Shipping costs were $23.4 billion and $27.9 billion in Q2 2025 and Q2 2026, and $45.9 billion and $53.6 billion for the six months ended June 30, 2025 and 2026. Shipping costs to receive products from our suppliers are included in our inventory and recognized as cost of sales upon sale of products to our customers. We expect our cost of shipping to continue to increase to the
30
Table of Contents
extent our customers accept and use our shipping offers at an increasing rate, we use more expensive shipping methods, and we offer additional services. We seek to mitigate costs of shipping over time in part through achieving higher sales volumes, optimizing our fulfillment network, negotiating better terms with our suppliers, and achieving better operating efficiencies. We believe that offering low prices to our customers is fundamental to our future success, and one way we offer lower prices is through shipping offers.
Costs to operate our AWS segment are primarily classified as “Technology and infrastructure” as we leverage a shared infrastructure that supports both our internal technology requirements and external sales to AWS customers.
Fulfillment
Fulfillment costs primarily consist of those costs incurred in operating and staffing our North America and International fulfillment centers, physical stores, and customer service centers and payment processing costs. While AWS payment processing and related transaction costs are included in “Fulfillment,” AWS costs are primarily classified as “Technology and infrastructure.” Fulfillment costs as a percentage of net sales may vary due to several factors, such as payment processing and related transaction costs, our level of productivity and accuracy, changes in volume, size, and weight of units received and fulfilled, the extent to which third-party sellers utilize Fulfillment by Amazon services, timing of fulfillment network and physical store expansion, the extent we utilize fulfillment services provided by third parties, mix of products and services sold, and our ability to affect customer service contacts per unit by implementing improvements in our operations and enhancements to our customer self-service features. Additionally, sales by our sellers have higher payment processing and related transaction costs as a percentage of net sales compared to our retail sales because payment processing costs are based on the gross purchase price of underlying transactions.
The increase in fulfillment costs in Q2 2026 and for the six months ended June 30, 2026, compared to the comparable prior year periods, is primarily due to increased sales and investments in our fulfillment network, partially offset by operational efficiencies. Changes in foreign exchange rates did not significantly impact fulfillment costs for Q2 2026, but increased fulfillment costs by $523 million for the six months ended June 30, 2026.
We seek to expand our fulfillment network to accommodate a greater selection and in-stock inventory levels and to meet anticipated shipment volumes from sales of our own products as well as sales by third parties for which we provide the fulfillment services. We regularly evaluate our facility requirements.
Technology and Infrastructure
Technology and infrastructure costs include payroll and related expenses for employees involved in the research and development of new and existing products and services, development, design, and maintenance of our stores, curation and display of products and services made available in our online stores, and infrastructure costs. Infrastructure costs include servers, networking equipment, and data center related depreciation and amortization, rent, utilities, and other expenses necessary to support AWS and other Amazon businesses. Collectively, these costs reflect the investments we make in order to offer a wide variety of products and services to our customers, including expenditures related to initiatives to build and deploy innovative and efficient software and electronic devices and the development of a satellite network for global broadband service and autonomous vehicles for ride-hailing services.
We seek to invest efficiently in numerous areas of technology and infrastructure so we may continue to enhance the customer experience and improve our process efficiency through rapid technology developments, while operating at an ever increasing scale. Our technology and infrastructure investment and capital spending projects often support a variety of product and service offerings due to geographic expansion and the cross-functionality of our systems and operations. We expect spending in technology and infrastructure to increase over time as we continue to add infrastructure and employees, including to support our artificial intelligence and machine learning initiatives. These costs are allocated to segments based on usage. The increase in technology and infrastructure costs in Q2 2026 and for the six months ended June 30, 2026, compared to the comparable prior year periods, is primarily due to an increase in spending on infrastructure, including depreciation and amortization. Changes in foreign exchange rates did not significantly impact technology and infrastructure costs for Q2 2026, but increased technology and infrastructure costs by $427 million for the six months ended June 30, 2026. Technology and infrastructure costs in Q2 2026 include net unrealized gains for energy contracts that are subject to derivative accounting, primarily related to AWS. Fair value measurements for these contracts do not impact cash flows but may be material to technology and infrastructure costs in future periods due to the duration of these contracts and volatility inherent in valuation methods. We currently expense the majority of the costs associated with the development of our satellite network for global broadband service (including production, launch, and payroll costs, and launch services deposits upon launch). We will capitalize certain of these costs once the service achieves commercial viability, including sales to customers. See Item 7 of Part II, “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Overview” of our 2025 Annual Report on Form 10-K for a discussion of how management views advances in technology and the importance of innovation.
31
Table of Contents
Sales and Marketing
Sales and marketing costs include advertising and payroll and related expenses for personnel engaged in marketing and selling activities, including sales commissions related to AWS. We direct customers to our stores primarily through a number of marketing channels, such as our third-party customer referrals, sponsored search, social and online advertising, television advertising, and other initiatives. Our marketing costs are largely variable, based on growth in sales and changes in rates. To the extent there is increased or decreased competition for these traffic sources, or to the extent our mix of these channels shifts, we would expect to see a corresponding change in our marketing costs.
Sales and marketing costs in Q2 2026 and for the six months ended June 30, 2026 did not significantly change compared to the comparable prior year periods. Changes in foreign exchange rates did not significantly impact sales and marketing costs for Q2 2026, but increased sales and marketing costs by $293 million for the six months ended June 30, 2026.
While costs associated with Amazon Prime membership benefits and other shipping offers are not included in sales and marketing expense, we view these offers as effective worldwide marketing tools, and intend to continue offering them indefinitely.
General and Administrative
The decrease in general and administrative costs in Q2 2026 and for the six months ended June 30, 2026, compared to the comparable prior year periods, is primarily due to a decrease in payroll and related expenses.
Other Operating Expense (Income), Net
Other operating expense (income), net was $199 million and $90 million for Q2 2025 and Q2 2026, and $507 million and $537 million for the six months ended June 30, 2025 and 2026, and was primarily related to asset impairments and the amortization of intangible assets.
Operating Income
Operating income by segment is as follows (in millions):
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Operating Income
North America	$	7,517 			$	9,123 			$	13,358 			$	17,390
International 	1,494 			1,717 			2,511 			3,141
AWS	10,160 			16,621 			21,707 			30,782
Consolidated	$	19,171 			$	27,461 			$	37,576 			$	51,313
Operating income increased from $19.2 billion in Q2 2025 to $27.5 billion in Q2 2026, and increased from $37.6 billion for the six months ended June 30, 2025 to $51.3 billion for the six months ended June 30, 2026. We believe that operating income is a more meaningful measure than gross profit and gross margin due to the diversity of our product categories and services. For more information on the operating expenses that impact segment operating income, see “Operating Expenses” and the descriptions of operating expense line item changes on pages 30 to 32, and “Note 8 — Segment Information” on page 22.
The increase in North America operating income in Q2 2026 and for the six months ended June 30, 2026, compared to the comparable prior year periods, is primarily due to increased unit sales and increased advertising sales, partially offset by increased shipping, fulfillment, and technology and infrastructure costs.
The increase in International operating income in Q2 2026 and for the six months ended June 30, 2026, compared to the comparable prior year periods, is primarily due to increased unit sales and increased advertising sales, partially offset by increased shipping and fulfillment costs. Changes in foreign exchange rates did not significantly impact operating income for Q2 2026, but positively impacted operating income by $304 million for the six months ended June 30, 2026.
The increase in AWS operating income in Q2 2026 and for the six months ended June 30, 2026, compared to the comparable prior year periods, is primarily due to increased sales, partially offset by spending on technology infrastructure that was primarily driven by additional investments to support AWS business growth. Changes in foreign exchange rates did not significantly impact operating income for Q2 2026, but negatively impacted operating income by $395 million for the six months ended June 30, 2026.
32
Table of Contents
Interest Income and Expense
Our interest income was $1.1 billion and $1.3 billion during Q2 2025 and Q2 2026, and $2.2 billion and $2.4 billion for the six months ended June 30, 2025 and 2026, primarily due to a higher average balance of invested funds, offset by a decrease in prevailing rates. We generally invest our excess cash in investment grade short- to intermediate-term marketable debt securities and AAA-rated money market funds. Our interest income corresponds with the average balance of invested funds based on the prevailing rates, which vary depending on the geographies and currencies in which they are invested.
Interest expense was $516 million and $1.3 billion during Q2 2025 and Q2 2026, and $1.1 billion and $2.1 billion for the six months ended June 30, 2025 and 2026, and was primarily related to debt, including new issuances of Notes, and finance leases. See Item 1 of Part I, “Financial Statements — Note 3 — Leases and Note 5 — Debt” for additional information.
Other Income (Expense), Net
Other income (expense), net was $1.1 billion and $53.4 billion during Q2 2025 and Q2 2026, and $3.9 billion and $69.1 billion for the six months ended June 30, 2025 and 2026. The primary components of other income (expense), net are related to equity securities valuations and adjustments, equity warrant valuations, foreign currency, and reclassification adjustments for gains (losses) on available-for-sale debt securities. The net gain of $1.1 billion in Q2 2025 is primarily from equity warrant valuations. The net gain of $3.9 billion for the six months ended June 30, 2025 is primarily from the reclassification adjustment for the gain on available-for-sale debt securities from the portion of our convertible notes investments in Anthropic that were converted to nonvoting preferred stock during the three months ended March 31, 2025. The net gain of $53.4 billion in Q2 2026 and $69.1 billion for the six months ended June 30, 2026 is primarily from upward adjustments for observable changes in price relating to our nonvoting preferred stock in Anthropic and the reclassification adjustment for the gains on available-for-sale debt securities from the portions of our convertible notes investments in Anthropic that were converted to nonvoting preferred stock during the three months ended March 31, 2026.
Income Taxes
Our income tax provision for the six months ended June 30, 2025 was $7.2 billion, which included $753 million of net discrete tax benefits primarily attributable to excess tax benefits from stock-based compensation. Our income tax provision for the six months ended June 30, 2026 was $27.8 billion, which included $15.9 billion of net discrete tax expense primarily attributable to the upward adjustments to our investments in Anthropic. See Item 1 of Part I, “Financial Statements — Note 7 — Income Taxes” for additional information.
Non-GAAP Financial Measures
Regulation G, Conditions for Use of Non-GAAP Financial Measures, and other SEC regulations define and prescribe the conditions for use of certain non-GAAP financial information. Free cash flow and the effect of foreign exchange rates on our consolidated statements of operations meet the definition of non-GAAP financial measures.
Free Cash Flow
Our financial focus is on long-term, sustainable growth in free cash flow. We provide a free cash flow measure because we believe it provides additional perspective on the impact of acquiring property and equipment with cash. Free cash flow is cash flow from operations reduced by “Purchases of property and equipment, net of proceeds from sales and incentives.” The following is a reconciliation of free cash flow to the most comparable GAAP cash flow measure, “Net cash provided by (used in) operating activities,” for the trailing twelve months ended June 30, 2025 and 2026 (in millions):
Twelve Months Ended
June 30,
2025		2026
Net cash provided by (used in) operating activities	$	121,137 			$	161,403
Purchases of property and equipment, net of proceeds from sales and incentives	(102,953)			(169,007)
Free cash flow	$	18,184 			$	(7,604)
Net cash provided by (used in) investing activities	$	(123,569)			$	(216,775)
Net cash provided by (used in) financing activities	$	(8,652)			$	75,160
Free cash flow has limitations as it omits certain components of the overall cash flow statement and does not represent the residual cash flow available for discretionary expenditures. For example, free cash flow does not incorporate the portion of payments representing principal reductions of debt or cash payments for business acquisitions. Additionally, our mix of property
33
Table of Contents
and equipment acquisitions with cash or other financing options may change over time. Therefore, we believe it is important to view free cash flow only as a complement to our entire consolidated statements of cash flows.
Effect of Foreign Exchange Rates
Information regarding the effect of foreign exchange rates, versus the U.S. Dollar, on our net sales, operating expenses, and operating income is provided to show reported period operating results had the foreign exchange rates remained the same as those in effect in the comparable prior year period. The effect on our net sales, operating expenses, and operating income from changes in our foreign exchange rates versus the U.S. Dollar is as follows (in millions):
Three Months Ended June 30,		Six Months Ended June 30,
2025		2026		2025		2026
As
Reported		Exchange
Rate
Effect (1)		At Prior
Year
Rates (2)		As Reported		Exchange
Rate
Effect (1)		At Prior
Year
Rates (2)		As
Reported		Exchange
Rate
Effect (1)		At Prior
Year
Rates (2)		As Reported		Exchange
Rate
Effect (1)		At Prior
Year
Rates (2)
Net sales	$	167,702 			$	(1,515)			$	166,187 			$	200,606 			$	(75)			$	200,531 			$	323,369 			$	(75)			$	323,294 			$	382,125 			$	(2,952)			$	379,173
Operating expenses	148,531 			(1,362)			147,169 			173,145 			(180)			172,965 			285,793 			131 			285,924 			330,812 			(3,090)			327,722
Operating income	19,171 			(153)			19,018 			27,461 			105 			27,566 			37,576 			(206)			37,370 			51,313 			138 			51,451
___________________
(1)Represents the change in reported amounts resulting from changes in foreign exchange rates from those in effect in the comparable prior year period for operating results.
(2)Represents the outcome that would have resulted had foreign exchange rates in the reported period been the same as those in effect in the comparable prior year period for operating results.
34
Table of Contents
Guidance
We provided guidance on July 30, 2026, in our earnings release furnished on Form 8-K as set forth below. These forward-looking statements reflect Amazon.com’s expectations as of July 30, 2026, and are subject to substantial uncertainty. Our results are inherently unpredictable and may be materially affected by many factors, such as fluctuations in foreign exchange rates and energy prices, changes in global economic and geopolitical conditions, tariff and trade policies, resource and supply volatility, including for memory chips, and customer demand and spending (including the impact of recessionary fears), inflation, interest rates, regional labor market constraints, world events, the rate of growth of the internet, online commerce, cloud services, and new and emerging technologies, as well as those outlined in Item 1A of Part II, “Risk Factors.”
Third Quarter 2026 Guidance
•Net sales are expected to be between $197.0 billion and $202.0 billion, or to grow between 9% and 12% compared with third quarter 2025. Excluding the impact of Prime Day in both 2025 and 2026, third quarter 2026 year-over-year growth would be nearly 400 basis points higher. This guidance anticipates an unfavorable impact of approximately 80 basis points from foreign exchange rates.
•Operating income is expected to be between $22.5 billion and $26.5 billion, compared with $17.4 billion in third quarter 2025.
•This guidance assumes, among other things, no impact from energy derivative contract remeasurements, and that no additional business acquisitions, restructurings, or legal settlements are concluded.
35
Table of Contents
Item 3.	Quantitative and Qualitative Disclosures About Market Risk
We are exposed to market risk for the effect of interest rate changes, foreign currency fluctuations, and changes in the market values of our investments. Information relating to quantitative and qualitative disclosures about market risk is set forth below and in Item 2 of Part I, “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Liquidity and Capital Resources.”
Interest Rate Risk
Our exposure to market risk for changes in interest rates relates primarily to our investment portfolio and our debt. Our long-term debt primarily bears interest at fixed rates and is carried at amortized cost and fluctuations in interest rates do not impact our consolidated financial statements. However, the fair value of our long-term debt will generally fluctuate with movements of interest rates, increasing in periods of declining rates of interest and declining in periods of increasing rates of interest. We generally invest our excess cash in investment grade short- to intermediate-term marketable debt securities and AAA-rated money market funds. Marketable debt securities with fixed interest rates may have their fair market value adversely affected due to a rise in interest rates, and we may suffer losses in principal if forced to sell securities that have declined in market value due to changes in interest rates.
Foreign Exchange Risk
During Q2 2026, net sales from our International segment accounted for 21% of our consolidated revenues. Net sales and related expenses generated from our internationally-focused stores, including within Canada and Mexico (which are included in our North America segment), are primarily denominated in the functional currencies of the corresponding stores and primarily include Euros, British Pounds, and Japanese Yen. The results of operations of, and certain of our intercompany balances associated with, our internationally-focused stores and AWS are exposed to foreign exchange rate fluctuations. Upon consolidation, as foreign exchange rates vary, net sales and other operating results may differ materially from expectations, and we may record significant gains or losses on the remeasurement of intercompany balances. For example, as a result of fluctuations in foreign exchange rates throughout the period compared to rates in effect the prior year, International segment net sales in Q2 2026 decreased by $82 million in comparison with Q2 2025.
We have foreign exchange risk related to foreign-denominated cash, cash equivalents, and marketable securities (“foreign funds”). Based on the balance of foreign funds as of June 30, 2026, of $20.4 billion, an assumed 5%, 10%, and 20% adverse change to foreign exchange rates would result in declines of $1.0 billion, $2.0 billion, and $4.1 billion.
We also have foreign exchange risk related to our intercompany balances denominated in various currencies. Based on the intercompany balances as of June 30, 2026, an assumed 5%, 10%, and 20% adverse change to foreign exchange rates would result in losses of $400 million, $795 million, and $1.6 billion, recorded to “Other income (expense), net.”
Our foreign currency-denominated unsecured senior notes create exposure to changes in foreign exchange rates. As of June 30, 2026, we have designated $20.7 billion of our Euro- and Canadian Dollar-denominated Notes as net investment hedges to mitigate foreign currency exposures related to the translation of our investments in foreign operations to U.S. dollars. Foreign currency unrealized gains and losses on these notes are included in “Accumulated other comprehensive income (loss)” until the foreign operations are sold or substantially liquidated, at which point these amounts and any translation adjustment of the foreign operations are reclassified to our consolidated statements of operations.
See Item 2 of Part I, “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Results of Operations — Effect of Foreign Exchange Rates” for additional information on the effect on reported results of changes in foreign exchange rates.
Equity Investment Risk
As of June 30, 2026, our recorded value in equity, equity warrant, and convertible debt investments in public and private companies was $229.7 billion. Our equity and equity warrant investments in publicly traded companies represent $7.4 billion of our investments as of June 30, 2026, and are recorded at fair value, which is subject to market price volatility. We record our equity warrant investments in private companies at fair value and adjust our equity investments in private companies, which primarily relate to our equity investments in Anthropic and OpenAI, for observable price changes or impairments. We record our available-for-sale convertible debt investments in private companies at fair value, which primarily relate to Anthropic. Valuations of private companies are inherently more complex due to the lack of readily available market data. The current global economic conditions provide additional uncertainty. As such, we believe that market sensitivities are not practicable.
36
Table of Contents
Item 4.	Controls and Procedures
We carried out an evaluation required by the Securities Exchange Act of 1934 (the “1934 Act”), under the supervision and with the participation of our principal executive officer and principal financial officer, of the effectiveness of the design and operation of our disclosure controls and procedures, as defined in Rule 13a-15(e) of the 1934 Act, as of the end of the period covered by this report. Based on this evaluation, our principal executive officer and principal financial officer concluded that our disclosure controls and procedures were effective to provide reasonable assurance that information required to be disclosed by us in the reports that we file or submit under the 1934 Act is recorded, processed, summarized, and reported within the time periods specified in the SEC’s rules and forms and to provide reasonable assurance that such information is accumulated and communicated to our management, including our principal executive officer and principal financial officer, as appropriate to allow timely decisions regarding required disclosure.
During the most recent fiscal quarter, there has not occurred any change in our internal control over financial reporting that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.
Our disclosure controls and procedures are designed to provide reasonable assurance of achieving their objectives as specified above. Management does not expect, however, that our disclosure controls and procedures will prevent or detect all error and fraud. Any control system, no matter how well designed and operated, is based upon certain assumptions and can provide only reasonable, not absolute, assurance that its objectives will be met. Further, no evaluation of controls can provide absolute assurance that misstatements due to error or fraud will not occur or that all control issues and instances of fraud, if any, within the Company have been detected.
37
Table of Contents
PART II. OTHER INFORMATION
Item 1.	Legal Proceedings
See Item 1 of Part I, “Financial Statements — Note 4 — Commitments and Contingencies — Legal Proceedings.”
Item 1A.	Risk Factors
Please carefully consider the following discussion of significant factors, events, and uncertainties that make an investment in our securities risky. The events and consequences discussed in these risk factors could, in circumstances we may or may not be able to accurately predict, recognize, or control, have a material adverse effect on our business, growth, reputation, prospects, financial condition, operating results (including components of our financial results), cash flows, liquidity, and stock price. These risk factors do not identify all risks that we face; our operations could also be affected by factors, events, or uncertainties that are not presently known to us or that we currently do not consider to present significant risks to our operations. In addition to the factors discussed in Item 7 of Part II, “Management’s Discussion and Analysis of Financial Condition and Results of Operations,” and in the risk factors below, global economic and geopolitical conditions and additional or unforeseen circumstances, developments, or events may give rise to or amplify many of the risks discussed below. Many of the risks discussed below also impact our customers, including third-party sellers, which could indirectly have a material adverse effect on us. The disclosures in this section reflect our beliefs and opinions as to factors that could materially and adversely affect us in the future. References to past events are provided by way of example only and are not intended to be a complete listing or a representation as to whether or not such factors have occurred in the past.
Business and Industry Risks
We Face Intense Competition
Our businesses are rapidly evolving and intensely competitive, and we have many competitors across geographies, including cross-border competition, and in different industries, including physical, e-commerce, and omnichannel retail, e-commerce services, web and infrastructure computing services, electronic devices, digital content, advertising, grocery, healthcare, communications, and transportation and logistics services. Some of our current and potential competitors have greater resources, longer histories, more customers, and/or greater brand recognition, particularly with our newly-launched products and services and in our newer geographic regions. They may secure better terms from vendors, adopt more aggressive pricing, and devote more resources to technology, infrastructure, fulfillment, and marketing.
Competition continues to intensify, including with the development of new business models and the entry of new and well-funded competitors, and as our competitors enter into business combinations or alliances and established companies in other market segments expand to become competitive with our business. In addition, new and enhanced technologies, including search, web and infrastructure computing services, practical applications of artificial intelligence and machine learning, digital content, satellites, and electronic devices continue to increase our competition. The internet and other technologies including artificial intelligence facilitate competitive entry and comparison shopping, which enhances the ability of new, smaller, or lesser-known businesses to compete against us. As a result of competition, our product and service offerings may not be successful, we may fail to gain or may lose business, and we may be required to increase our spending or lower prices, any of which could materially reduce our sales and profits.
Our Expansion into New Products, Services, Technologies, and Geographic Regions Subjects Us to Additional Risks
We may have limited or no experience in our newer market segments, and our customers may not adopt our product or service offerings. These offerings, which can present new and difficult technology challenges, may subject us to claims if customers of these offerings experience, or are otherwise impacted by, service disruptions, delays, setbacks, or failures or quality issues. In addition, profitability or other intended benefits, if any, in our newer activities (including development and adoption of automation, artificial intelligence, and machine learning technologies for customer and internal use), may not meet our expectations, and we may not be successful enough in these newer activities to recoup our investments in them, which investments are often significant. Failure to realize the benefits of amounts we invest in new technologies, products, or services could result in the value of those investments being written down or written off. In addition, our sustainability initiatives may be unsuccessful for a variety of reasons, including if we are unable to realize the expected benefits of new technologies or if we do not successfully plan or execute new strategies, which could harm our business or damage our reputation.
38
Table of Contents
Our International Operations Expose Us to a Number of Risks
Our international activities are significant to our revenues and profits, and we plan to further expand internationally. In certain international market segments, we have relatively little operating experience and may not benefit from any first-to-market advantages or otherwise succeed. It is costly to establish, develop, and maintain international operations and stores, and promote our brand internationally. Our international operations may not become profitable on a sustained basis.
In addition to risks described elsewhere in this section, our international sales and operations are subject to a number of risks, including:
•local economic and political conditions;
•government regulation (such as regulation of our product and service offerings and of competition); restrictive governmental actions (such as trade protection or retaliatory measures, including export duties and quotas and custom duties and tariffs, and restrictions around the import and export of certain products, technologies, and components); nationalization; and restrictions on foreign ownership;
•restrictions on sales or distribution of certain products or services and uncertainty regarding liability for products, services, and content, including uncertainty as a result of less internet-friendly legal systems, local laws, lack of legal precedent, and varying rules, regulations, and practices regarding the physical and digital distribution of media products and enforcement of intellectual property rights;
•business licensing or certification requirements, such as for imports, exports, web services, electronic devices, and communications services;
•limitations on the repatriation and investment of funds and foreign currency exchange restrictions;
•limited fulfillment and technology infrastructure;
•shorter payable and longer receivable cycles and the resultant negative impact on cash flow;
•laws and regulations regarding privacy, data use, data protection, data security, data localization, network security, consumer protection, payments, advertising, and restrictions on pricing or discounts;
•lower levels of use of the internet;
•lower levels of consumer spending and fewer opportunities for growth compared to the U.S.;
•lower levels of credit card usage and increased payment risk;
•difficulty in staffing, developing, and managing foreign operations as a result of distance, language, and cultural differences;
•different employee/employer relationships and the existence of works councils and labor unions;
•compliance with the U.S. Foreign Corrupt Practices Act and other applicable U.S. and foreign laws prohibiting corrupt payments to government officials and other third parties;
•laws and policies of the U.S. and other jurisdictions affecting trade (such as tariff policy changes), foreign investment, loans, and taxes; and
•geopolitical events, including war and terrorism.
As international physical, e-commerce, and omnichannel retail, cloud services, and other services grow, competition will intensify, including through adoption of evolving business models. Local companies may have a substantial competitive advantage because of their greater understanding of, and focus on, the local customer, as well as their more established local brand names. The inability to hire, train, retain, and manage sufficient required personnel may limit our international growth.
The People’s Republic of China (“PRC”) and India regulate Amazon’s and its affiliates’ businesses and operations in country through regulations and license requirements that may restrict (i) foreign investment in and operation of the internet, IT infrastructure, data centers, retail, delivery, and other sectors, (ii) internet content, and (iii) the sale of media and other products and services. For example, in order to meet local ownership, regulatory licensing, and cybersecurity requirements, we provide certain technology services in China through contractual relationships with third parties that hold PRC licenses to provide services. In India, the government restricts the ownership or control of Indian companies by foreign entities involved in online multi-brand retail trading activities. For www.amazon.in, we provide certain marketing tools and logistics services to third-party sellers to enable them to sell online and deliver to customers, and we hold an indirect minority interest in an entity that is a third-party seller on the www.amazon.in marketplace. Although we believe these structures and activities comply with existing laws, they involve unique risks, and the PRC and India may from time to time consider and implement additional changes in their regulatory, licensing, or other requirements that could impact these structures and activities. There are substantial uncertainties regarding the interpretation of PRC and Indian laws and regulations, and it is possible that these governments will
39
Table of Contents
ultimately take a view contrary to ours. In addition, our Chinese and Indian businesses and operations may be unable to continue to operate if we or our affiliates are unable to access sufficient funding or, in China, enforce contractual relationships we or our affiliates have in place. Violation of any existing or future PRC, Indian, or other laws or regulations or changes in the interpretations of those laws and regulations could result in our businesses in those countries being subject to fines and other financial penalties, having licenses revoked, or being forced to restructure our operations or shut down entirely.
In addition, because China-based sellers account for significant portions of our third-party seller services and advertising revenues, and China-based suppliers provide significant portions of our components and finished goods, regulatory and trade restrictions, tariff policy changes and trade disputes, data protection and cybersecurity laws, economic factors, geopolitical events, security issues, or other factors negatively impacting China-based sellers and suppliers could adversely affect our operating results.
The Variability in Our Retail Business Places Increased Strain on Our Operations
Demand for our products and services can fluctuate significantly for many reasons, including as a result of seasonality, promotions, product launches, or unforeseeable events, such as in response to global economic conditions such as recessionary fears or rising inflation (including as a result of tariff policy changes), natural or human-caused disasters (including public health crises) or extreme weather (including as a result of climate change), or geopolitical events. For example, we expect a disproportionate amount of our retail sales to occur during our fourth quarter. Our failure to stock or restock popular products in sufficient amounts such that we fail to meet customer demand could significantly affect our revenue and our future growth. When we overstock products, we may be required to take significant inventory markdowns or write-offs and incur commitment costs, which could materially reduce profitability. We regularly experience increases in our net shipping cost due to complimentary upgrades, split-shipments, and additional long-zone shipments necessary to ensure timely delivery for the holiday season. If too many customers access our websites within a short period of time due to increased demand, we may experience system interruptions that make our websites unavailable or prevent us from efficiently fulfilling orders, which may reduce the volume of goods we offer or sell and the attractiveness of our products and services. In addition, we may be unable to adequately staff our fulfillment network and customer service centers during these peak periods and delivery and other fulfillment companies and customer service co-sourcers may be unable to meet the seasonal demand. Risks described elsewhere in this Item 1A relating to fulfillment network optimization and inventory are magnified during periods of high demand.
As a result of holiday sales, as of December 31 of each year, our cash, cash equivalents, and marketable securities balances typically reach their highest level (other than as a result of cash flows provided by or used in investing and financing activities) because consumers primarily use credit cards in our stores and the related receivables settle quickly. Typically, there is also a corresponding increase in accounts payable as of December 31 due to inventory purchases and third-party seller sales. Our accounts payable balance generally declines during the first three months of the year as vendors and sellers are paid, resulting in a corresponding decline in our cash, cash equivalents, and marketable securities balances.
We Are Impacted by Fraudulent or Unlawful Activities of Sellers
The law relating to the liability of online service providers is currently unsettled. In addition, governmental agencies have in the past and could in the future require changes in the way this business is conducted. Under our seller programs, we maintain policies and processes designed to prevent sellers from collecting payments, fraudulently or otherwise, when buyers never receive the products they ordered or when the products received are materially different from the sellers’ descriptions, and to prevent sellers in our stores or through other stores from selling unlawful, counterfeit, pirated, or stolen goods, selling goods in an unlawful or unethical manner, violating the proprietary rights of others, or otherwise violating our policies. When these policies and processes are circumvented or fail to operate sufficiently, it can harm our business or damage our reputation and we could face civil or criminal liability for unlawful activities by our sellers. Under our A-to-z Guarantee, we may reimburse customers for payments up to certain limits in these situations, and as our third-party seller sales grow, the cost of this program will increase and could negatively affect our operating results.
We Face Risks Related to Adequately Protecting Our Intellectual Property Rights and Being Accused of Infringing Intellectual Property Rights of Third Parties
We regard our trademarks, service marks, copyrights, patents, trade dress, trade secrets, proprietary technology, and similar intellectual property as critical to our success, and we rely on trademark, copyright, and patent law, trade secret protection, and confidentiality and/or license agreements with our employees, customers, and others to protect our proprietary rights. Effective intellectual property protection is not available in every country in which our products and services are made available. We also may not be able to acquire or maintain appropriate domain names in all countries in which we do business. Furthermore, regulations governing domain names may not protect our trademarks and similar proprietary rights. We may be unable to prevent third parties from acquiring domain names that are similar to, infringe upon, or diminish the value of our trademarks and other proprietary rights.
40
Table of Contents
We are not always able to discover or determine the extent of any unauthorized use of our proprietary rights. Actions taken by third parties that license our proprietary rights may materially diminish the value of our proprietary rights or reputation. The protection of our intellectual property requires the expenditure of significant financial and managerial resources. Moreover, the steps we take to protect our intellectual property do not always adequately protect our rights or prevent third parties from infringing or misappropriating our proprietary rights. We also cannot be certain that others will not independently develop or otherwise acquire equivalent or superior technology or other intellectual property rights.
We have been subject to, and expect to continue to be subject to, claims and legal proceedings regarding alleged infringement by us of the intellectual property rights of third parties. Such claims, whether or not meritorious, have in the past, and may in the future, result in the expenditure of significant financial and managerial resources, injunctions against us, or significant payments for damages, including to satisfy indemnification obligations or to obtain licenses from third parties who allege that we have infringed their rights. Such licenses may not be available on terms acceptable to us or at all. These risks have been amplified by the increase in third parties whose sole or primary business is to assert such claims. In addition, our and our customers’ development and use of artificial intelligence may result in increased claims of infringement or other claims, including those based on unauthorized use of third-party technology or content.
Our digital content offerings depend in part on effective digital rights management technology to control access to digital content. Breach or malfunctioning of the digital rights management technology that we use could subject us to claims, and content providers may be unwilling to include their content in our service.
We Have Foreign Exchange Risk
The results of operations of, and certain of our intercompany balances associated with, our international stores and product and service offerings are exposed to foreign exchange rate fluctuations. Due to these fluctuations, operating results may differ materially from expectations, and we may record significant gains or losses on the remeasurement of intercompany balances. As we have expanded our international operations, our exposure to exchange rate fluctuations has increased. We also hold cash equivalents and/or marketable securities in foreign currencies such as British Pounds, Canadian Dollars, Euros, and Japanese Yen, and issue notes in foreign currencies. When the U.S. Dollar strengthens compared to these currencies, cash equivalents, marketable securities balances, and foreign-denominated note balances and payments, when translated, may be materially less than expected and vice versa.
Operating Risks
Our Expansion Places a Significant Strain on our Management, Operational, Financial, and Other Resources
We are continuing to rapidly and significantly expand our global operations, including increasing our product and service offerings, scaling our infrastructure to support our retail and services businesses (including our technology infrastructure), and adopting and utilizing artificial intelligence and machine learning technologies. The complexity of the current scale of our business can place significant strain on our management, personnel, operations, systems, technical performance, financial resources, and internal financial control and reporting functions, and our expansion increases these factors. Failure to manage growth effectively could damage our reputation, limit our growth, and negatively affect our operating results.
We Experience Significant Fluctuations in Our Operating Results and Growth Rate
We are not always able to accurately forecast our growth rate. We base our expense levels and investment plans on sales estimates. A significant portion of our expenses and investments is fixed, and we are not always able to adjust our spending quickly enough if our sales are less than expected.
Our revenue growth may not be sustainable, and our percentage growth rates may decrease. Our revenue and operating profit growth depends on the continued growth of demand for the products and services offered by us or our sellers, and our business is affected by, among other things, general economic, business, and geopolitical conditions worldwide. A softening of demand, whether caused by changes in customer preferences or a weakening of the U.S. or global economies, may result in decreased revenue or growth.
Our sales and operating results will also fluctuate for many other reasons, including due to factors described elsewhere in this section and the following:
•our ability to retain and increase sales to existing customers, attract new customers, and satisfy our customers’ demands;
•our ability to retain and expand our network of sellers;
•our ability to offer products on favorable terms, manage inventory, and fulfill orders;
•the introduction of competitive stores, websites, products, services, price decreases, or improvements;
41
Table of Contents
•changes in usage or adoption rates of the internet, e-commerce, electronic devices, web services, satellite communications services, and artificial intelligence and machine learning technologies, products, and services, including outside the U.S.;
•timing, effectiveness, and costs of expansion and upgrades of our systems and infrastructure;
•the success of our geographic, service, and product line expansions;
•the extent to which we finance, and the terms of any such financing for, our current operations and future growth;
•the outcomes of legal proceedings and claims, which may include significant monetary damages or injunctive relief and could have a material adverse impact on our operating results;
•variations in the mix of products and services we sell;
•variations in our level of merchandise and vendor returns;
•the extent to which we offer fast and free delivery, continue to reduce prices worldwide, and provide additional benefits to our customers;
•factors affecting our reputation or brand image (including any actual or perceived inability to achieve our goals or commitments, whether related to sustainability, customers, employees, or other topics), and public perceptions regarding our positions on social or ethical issues and our development and use of artificial intelligence, machine learning, and automation technologies, products, and services;
•the extent to which we invest in technology and infrastructure, fulfillment, and other expense categories;
•availability of and increases in the prices of transportation (including fuel), resources such as land, water, and energy, commodities like paper and packing supplies and hardware products, and technology infrastructure products, including as a result of inflationary pressures;
•constrained labor markets, which increase our payroll costs;
•the extent to which operators of networks, systems, and services between us and customers successfully divert customers from or charge fees to access our stores and service offerings;
•our ability to collect amounts owed to us when they become due;
•the extent to which new and existing technologies, or industry trends, restrict online advertising or affect our ability to customize advertising or otherwise tailor our product and service offerings;
•the extent to which use of our services is affected by spyware, viruses, phishing and other spam emails, denial of service attacks, data theft, computer intrusions, outages, and similar events;
•the extent to which we fail to maintain our unique culture of innovation, customer obsession, and long-term thinking, which has been critical to our growth and success;
•disruptions from natural or human-caused disasters (including public health crises) or extreme weather (including as a result of climate change), geopolitical events and security issues (including terrorist attacks, armed hostilities, and political conflicts, including those involving China), labor or trade disputes (including restrictive governmental actions impacting us, our customers, and our third-party sellers and suppliers in China or other foreign countries), tariff policy changes (such as tariffs proposed or implemented by the U.S. and other countries and any retaliatory actions), and similar events; and
•potential negative impacts of climate change, including: increased operating costs due to more frequent extreme weather events or climate-related changes, such as rising temperatures and water scarcity; increased investment requirements associated with the transition to a low-carbon economy; decreased demand for our products and services as a result of changes in customer behavior; increased compliance costs due to more extensive and global regulations and third-party requirements; and reputational damage resulting from perceptions of our environmental impact.
We Face Risks Related to Successfully Optimizing and Operating Our Fulfillment Network and Data Centers
Failures to adequately predict customer demand and consumer spending patterns or otherwise optimize and operate our fulfillment network and data centers successfully from time to time result in excess or insufficient fulfillment or data center capacity, service interruptions, increased costs, and impairment charges, any of which could materially harm our business. As we continue to add fulfillment and data center capability or add new businesses with different requirements, our fulfillment and data center networks become increasingly complex and operating them becomes more challenging. There can be no assurance that we will be able to operate our networks effectively.
42
Table of Contents
In addition, failure to optimize inventory management or staffing in our fulfillment network increases our net shipping cost by increasing the distance products are shipped and reducing the number of units per shipment or delivery. We and our co-sourcers may be unable to adequately staff our fulfillment network and customer service centers. For example, productivity across our fulfillment network is affected by regional labor market constraints, which increase payroll costs and make it difficult to hire, train, and deploy a sufficient number of people to operate our fulfillment network as efficiently as we would like.
Under some of our commercial agreements, we maintain the inventory of other companies, thereby increasing the complexity of tracking inventory and operating our fulfillment network. Our failure to adequately predict seller demand for storage or to properly handle such inventory or the inability of the other businesses on whose behalf we perform inventory fulfillment services to accurately forecast product demand may result in us being unable to secure sufficient storage space or to optimize our fulfillment network or cause other unexpected costs and other harm to our business and reputation.
We rely on a limited number of shipping companies to deliver inventory to us and completed orders to our customers. An inability to negotiate acceptable terms with these companies or performance problems, staffing limitations, or other difficulties experienced by these companies or by our own transportation systems, including as a result of labor market constraints and related costs, could negatively impact our operating results and customer experience. In addition, our ability to receive inbound inventory efficiently and ship completed orders to customers also may be negatively affected by natural or human-caused disasters (including public health crises) or extreme weather (including as a result of climate change), geopolitical events and security issues, labor or trade disputes, tariff policy changes, and similar events.
We Could Be Harmed by Data Loss or Other Security Incidents
Because we collect, process, store, and transmit large amounts of data, including confidential, classified, sensitive, proprietary, and business and personal information, failure to prevent, detect, or mitigate data loss, theft, misuse, unauthorized access, or other security incidents or vulnerabilities affecting our or our vendors’ or customers’ technology, products, and systems, could: expose us or our customers to a risk of loss, disclosure, or misuse of such information; adversely affect our operating results; result in litigation, liability, or regulatory action (including under laws related to privacy, data use, data protection, data security, network security, and consumer protection); deter customers or sellers from using our stores, products, and services; and otherwise harm our business and reputation. We use third-party technology and systems for a variety of reasons, including, without limitation, artificial intelligence technologies, encryption and authentication technology, employee email and other communication technologies, content delivery to customers, back-office support, and other functions. Some of our systems have experienced past security incidents, and, although they did not have a material adverse effect on our operating results, there can be no assurance that future incidents will not have material adverse effects on our operations or financial results. Although we have developed systems and processes that are designed to protect customer data and prevent, detect, or mitigate such incidents, including systems and processes designed to reduce the impact of a security incident at a third-party vendor or customer, such measures cannot provide absolute security and may fail to operate as intended or be circumvented, including by use of developing technologies such as artificial intelligence.
We Face Risks Related to System Interruption and Lack of Redundancy
We experience occasional system interruptions and delays that make our websites and services unavailable or slow to respond and prevent us from efficiently accepting or fulfilling orders or providing services to customers and third parties, which may reduce our net sales and the attractiveness of our products and services. Steps we take to add software and hardware, upgrade our systems and network infrastructure, and improve the stability and efficiency of our systems may not be sufficient to avoid system interruptions or delays that could adversely affect our operating results.
Our computer and communications systems and operations in the past have been, or in the future could be, damaged or interrupted due to events such as natural or human-caused disasters (including public health crises) or extreme weather (including as a result of climate change), geopolitical events and security issues (including terrorist attacks and armed hostilities), computer viruses, physical or electronic break-ins, operational failures (including from energy shortages), and similar events or disruptions. Any of these events could cause system interruption, delays, and loss of critical data, and could prevent us from accepting and fulfilling customer orders and providing services, which could make our product and service offerings less attractive and subject us to liability. Our systems are not fully redundant and our disaster recovery planning may not be sufficient. In addition, our insurance may not provide sufficient coverage to compensate for related losses. Any of these events could damage our reputation and be expensive to remedy.
The Loss of Key Senior Management Personnel or the Failure to Hire and Retain Highly Skilled and Other Personnel Could Negatively Affect Our Business
We depend on our senior management and other key personnel, including our President and CEO. We do not have “key person” life insurance policies. We also rely on other highly skilled personnel. Competition for qualified personnel in the
43
Table of Contents
industries in which we operate, as well as senior management, has historically been intense. For example, we experience significant competition in the technology industry, particularly for software engineers, computer scientists, and other technical staff (including for artificial intelligence and machine learning technologies). In addition, changes we make to our current and future work environments may not meet the needs or expectations of our employees or may be perceived as less favorable compared to other companies’ policies, which could negatively impact our ability to hire and retain qualified personnel. The loss of any of our executive officers or other key employees, the failure to successfully transition key roles, or the inability to hire, train, retain, and manage qualified personnel, could harm our business.
We also rely on a significant number of personnel to operate our stores, fulfillment network, and data centers and carry out our other operations. Failure to successfully hire, train, manage, and retain sufficient personnel to meet our needs can strain our operations, increase payroll and other costs, and harm our business and reputation. In addition, changes in laws and regulations applicable to employees, independent contractors, and temporary personnel could increase our payroll costs, decrease our operational flexibility, and negatively impact how we are able to staff our operations and supplement our workforce.
We are also subject to labor union efforts to organize groups of our employees from time to time. These organizational efforts, if successful, decrease our operational flexibility, which could adversely affect our operating efficiency. In addition, our response to any organizational efforts could be perceived negatively and harm our business and reputation.
Our Supplier Relationships Subject Us to a Number of Risks
We have significant suppliers, including content and technology licensors, and in some cases, limited or single-sources of supply, that are important to our sourcing, services, manufacturing, and any related ongoing servicing of merchandise and content. We do not have long-term arrangements with most of our suppliers to guarantee availability of merchandise, content, components, or services, particular payment terms, or the extension of credit limits. Decisions by our current suppliers to limit or stop selling or licensing merchandise, content, components, or services to us on acceptable terms, or delay delivery, including as a result of one or more supplier bankruptcies due to poor economic conditions, natural or human-caused disasters (including public health crises), geopolitical events, labor and trade disputes, or for other reasons, may result in our being unable to procure alternatives from other suppliers in a timely and efficient manner and on acceptable terms, or at all. For example, we rely on a limited group of suppliers for semiconductor products, including products related to artificial intelligence infrastructure such as graphics processing units. Constraints on the availability of these products could adversely affect our ability to develop and operate artificial intelligence technologies, products, or services. In addition, violations by our suppliers or other vendors of applicable laws, regulations, contractual terms, intellectual property rights of others, or our Supply Chain Standards, as well as products or practices regarded as unethical, unsafe, or hazardous, could expose us to claims, damage our reputation, limit our growth, and negatively affect our operating results.
Our Commercial Agreements, Strategic Alliances, and Other Business Relationships Expose Us to Risks
We provide physical, e-commerce, and omnichannel retail, cloud services, and other services to businesses through commercial agreements, strategic alliances, and business relationships. Under these agreements, we provide web services, technology, fulfillment, computing, digital storage, and other services, as well as enable sellers to offer products or services through our stores. These arrangements are complex and require substantial infrastructure capacity, personnel, and other resource commitments, which may limit the amount of business we can service. We may not be able to implement, maintain, and develop the components of these commercial relationships, which may include web services, fulfillment, customer service, inventory management, tax collection, payment processing, hardware, content, and third-party software, and engaging third parties to perform services. The amount of compensation we receive under certain of our commercial agreements is partially dependent on the volume of the other company’s sales. Therefore, when the other company’s offerings are not successful, the compensation we receive may be lower than expected or the agreement may be terminated. Moreover, we may not be able to enter into additional or alternative commercial relationships and strategic alliances on favorable terms. We also may be subject to claims from businesses to which we provide these services if we are unsuccessful in implementing, maintaining, or developing these services.
As our agreements terminate, we may be unable to renew or replace these agreements on comparable terms, or at all. We may in the future enter into amendments on less favorable terms or encounter parties that have difficulty meeting their contractual obligations to us, which could adversely affect our operating results.
Our present and future commercial agreements, strategic alliances, and business relationships create additional risks such as:
•disruption of our ongoing business, including loss of management focus on existing businesses;
•impairment of other relationships;
•variability in revenue and income from entering into, amending, or terminating such agreements or relationships; and
44
Table of Contents
•difficulty integrating under the commercial agreements.
Our Business Suffers When We Are Unsuccessful in Making, Integrating, and Maintaining Acquisitions and Investments
We have acquired and invested in a number of companies, and we may in the future acquire or invest in or enter into joint ventures with additional companies. These transactions involve risks such as:
•disruption of our ongoing business, including loss of management focus on and diversion of resources from existing businesses;
•problems retaining key personnel;
•additional operating losses and expenses of the businesses we acquired or in which we invested;
•the potential impairment of tangible and intangible assets and goodwill, including as a result of acquisitions;
•the potential impairment of customer and other relationships of the company we acquired or in which we invested or our own customers as a result of any integration of operations;
•the difficulty of completing such transactions, including obtaining regulatory approvals or satisfying other closing conditions, and achieving anticipated benefits within expected timeframes, or at all;
•the difficulty of incorporating acquired operations, technology, and rights into our offerings, and unanticipated expenses related to such integration;
•the difficulty of integrating a new company’s accounting, financial and sustainability reporting, management, information and data security, human resource, and other administrative systems to permit effective management, and the lack of control if such integration is delayed or not successfully implemented;
•losses we may incur as a result of declines in the value of an investment or as a result of incorporating an investee’s financial performance into our financial results;
•for investments in which an investee’s financial performance is incorporated into our financial results, either in full or in part, or investments for which we are required to file financial statements or provide financial information, the dependence on the investee’s accounting, financial and sustainability reporting, and similar systems, controls, and processes;
•the difficulty of implementing at companies we acquire the controls, procedures, and policies appropriate for a larger public company;
•the risks associated with businesses we acquire or invest in, which may differ from or be more significant than the risks our other businesses face;
•investees may have different strategic priorities than us, and we do not control their decisions regarding strategy, operations, governance, or compliance;
•potential unknown liabilities associated with a company we acquire or in which we invest; and
•for foreign transactions, additional risks related to the integration of operations across different cultures and languages, and the economic, political, and regulatory risks associated with specific countries.
As a result of acquisitions or investments, we might need to issue additional equity securities, spend our cash, or incur debt, contingent liabilities, or amortization expenses related to intangible assets, any of which could reduce our profitability and harm our business or only be available on unfavorable terms, if at all. In addition, valuations supporting our acquisitions and strategic investments could change rapidly. We could determine that such valuations have experienced impairments or other-than-temporary declines in fair value which could adversely impact our financial results.
We Face Significant Inventory Risk
In addition to risks described elsewhere in this Item 1A relating to fulfillment network and inventory optimization by us and third parties, we are exposed to significant inventory risks that may adversely affect our operating results as a result of seasonality, new product launches, rapid changes in product cycles and pricing (including as a result of tariff policy changes), defective merchandise, changes in customer demand and consumer spending patterns, changes in consumer tastes with respect to our products, spoilage, and other factors. We endeavor to accurately predict these trends and avoid overstocking or understocking products we manufacture and/or sell. Demand for products, however, can change significantly between the time inventory or components are ordered and the date of sale. In addition, when we begin selling or manufacturing a new product or offering a new service, it may be difficult to establish vendor relationships, determine appropriate product or component selection, and accurately forecast demand. The acquisition of certain types of inventory or components requires significant lead-time and prepayment and they may not be returnable. We carry a broad selection and significant inventory levels of certain
45
Table of Contents
products, such as consumer electronics, and at times we are unable to sell products in sufficient quantities or to meet demand during the relevant selling seasons. Any one of the inventory risk factors set forth above may adversely affect our operating results.
We Are Subject to Payments-Related Risks
We accept payments using a variety of methods, including credit card, debit card, credit accounts (including promotional financing), gift cards, direct debit from a customer’s bank account, consumer invoicing, checks, and payment upon delivery. For existing and future payment options we offer to our customers, we currently are subject to, and may become subject to additional, regulations and compliance requirements (including obligations to implement enhanced authentication processes that could result in significant costs and reduce the ease of use of our payments products), as well as fraud. For certain payment methods, including credit and debit cards, we pay interchange and other fees, which may increase over time and raise our operating costs and lower profitability. We rely on third parties to provide certain Amazon-branded payment methods and payment processing services, including the processing of credit cards, debit cards, electronic checks, and promotional financing. In each case, it could disrupt our business if these companies become unwilling or unable to provide these services to us. We also offer co-branded credit card programs, which could adversely affect our operating results if renewed on less favorable terms or terminated. We are also subject to payment card association operating rules, including data security rules, certification requirements, and rules governing electronic funds transfers, which could change or be reinterpreted to make it difficult or impossible for us to comply. Failure to comply with these rules or requirements, as well as any breach, compromise, or failure to otherwise detect or prevent fraudulent activity involving our data security systems, could result in our being liable for card issuing banks’ costs, subject to fines and higher transaction fees, and loss of our ability to accept credit and debit card payments from our customers, process electronic funds transfers, or facilitate other types of online payments, and our business and operating results could be adversely affected.
In addition, we provide regulated services in certain jurisdictions because we enable customers to keep account balances with us and transfer money to third parties, and because we provide services to third parties to facilitate payments on their behalf. Jurisdictions subject us to requirements for licensing, regulatory inspection, bonding and capital maintenance, the use, handling, and segregation of transferred funds, consumer disclosures, maintaining or processing data, and authentication. We are also subject to or voluntarily comply with a number of other laws and regulations relating to payments, money laundering, international money transfers, privacy, data use, data protection, data security, data localization, network security, consumer protection, and electronic fund transfers. If we were found to be in violation of applicable laws or regulations, we could be subject to additional requirements and civil and criminal penalties, or forced to cease providing certain services.
We Have a Rapidly Evolving Business Model and Our Stock Price Is Highly Volatile
We have a rapidly evolving business model. The trading price of our common stock fluctuates significantly in response to, among other risks, the risks described elsewhere in this Item 1A, as well as:
•changes in interest rates;
•conditions or trends in the internet, other technologies including artificial intelligence, and the industry segments we operate in;
•quarterly variations in operating results;
•fluctuations in the stock market in general and market prices for technology-related companies in particular;
•changes in financial estimates by us or decisions to increase or decrease future spending or investment levels;
•changes in financial estimates and recommendations by securities analysts;
•changes in our capital structure, including issuance of additional debt or equity to the public;
•changes in the valuation methodology of, or performance by, other e-commerce or technology companies; and
•transactions in our common stock by major investors and certain analyst reports, news, social media activity, and speculation.
Volatility in our stock price could adversely affect our business and financing opportunities and force us to increase our cash compensation to employees or grant larger stock awards than we have historically, which could hurt our operating results or reduce the percentage ownership of our existing stockholders, or both.
46
Table of Contents
Legal and Regulatory Risks
Government Regulation Is Evolving and Unfavorable Changes Could Harm Our Business
We are subject to general business regulations and laws, as well as regulations and laws specifically governing the internet, physical, e-commerce, and omnichannel retail, digital content, web services, electronic devices, advertising, artificial intelligence technologies and services, satellite communications services, healthcare, and other products and services that we offer or sell. These regulations and laws cover taxation, privacy, data use, data protection, data security, data localization, network security, consumer protection, pricing, content, copyrights, distribution, transportation, communications, electronic device certification, electronic waste, energy consumption, environmental and climate-related regulation, electronic contracts and other communications, competition, employment, trade and protectionist measures, web services, the provision of online payment services, registration, licensing, and information reporting requirements, insurance, unencumbered internet access to our services or access to our facilities, the design and operation of websites, health, safety, and sanitation standards, the characteristics, legality, and quality of products and services, product labeling, the commercial operation of unmanned aircraft systems, healthcare, and other matters. It is not clear how existing laws governing issues such as property ownership, libel, privacy, data use, data protection, data security, data localization, network security, and consumer protection apply to aspects of our operations such as the internet, e-commerce, digital content, web services, electronic devices, advertising, artificial intelligence technologies and services, satellite communications services, and healthcare. A large number of jurisdictions regulate our operations, and the extent, nature, and scope of such regulations is evolving and expanding as the scope of our businesses expand. We are regularly subject to formal and informal reviews, investigations, and other proceedings by governments and regulatory authorities under existing laws, regulations, or interpretations or pursuing new and novel approaches to regulate our operations. For example, we are facing a number of tax and other challenges in Italy. Additionally, we face a number of open investigations based on claims that aspects of our operations infringe competition-related or consumer protection rules or regulations, including aspects of Amazon’s operation of its stores, including its fulfillment network and Prime, and certain aspects of AWS’s offering of cloud services. We strongly dispute these claims and intend to defend ourselves vigorously in these investigations. Similarly, we face investigations under a growing patchwork of laws and regulations governing the collection, use, and disclosure of data, the interpretation of which continues to evolve, leading to uncertainty about how regulators will view our privacy practices. In addition, regulators and lawmakers are increasingly focused on controlling additional aspects of the operations of technology companies and companies they have characterized to be online “gatekeepers” through the application of existing regulations and laws and the adoption of new regulations and laws, which increases our compliance costs and limits the operation of our business. Unfavorable regulations, laws, decisions, or interpretations by government or regulatory authorities applying those laws and regulations, or inquiries, investigations, or enforcement actions threatened or initiated by them, could cause us to incur substantial costs, expose us to unanticipated civil and criminal liability or penalties (including substantial monetary fines), diminish the demand for, or availability of, our products and services, increase our cost of doing business, require us to change our business practices in a manner materially adverse to our business, damage our reputation, impede our growth, or otherwise have a material effect on our operations. The media, political, and regulatory scrutiny we face, which may continue to increase, amplifies these risks.
Claims, Litigation, Government Investigations, and Other Proceedings May Adversely Affect Our Business and Results of Operations
As an innovative company offering a wide range of consumer and business products and services around the world, we are regularly subject to actual and threatened claims, litigation, reviews, investigations, and other proceedings, including proceedings by governments and regulatory authorities, involving a wide range of issues, including patent and other intellectual property matters, taxes, labor and employment (including the characterization of delivery drivers), competition and antitrust, privacy, data use, data protection, data security, data localization, network security, consumer protection, commercial disputes, goods and services offered by us and by third parties (including artificial intelligence technologies and services), healthcare, and other matters. The number and scale of these proceedings have increased over time as our businesses have expanded in scope and geographic reach, as our products, services, and operations have become more complex and available to, and used by, more people, and as governments and regulatory authorities seek to regulate us on a pre-emptive basis. For example, we are litigating a number of matters alleging price fixing, monopolization, and consumer protection claims, including those brought by state attorneys general and the Federal Trade Commission. Any of these types of proceedings can have an adverse effect on us because of legal costs, disruption of our operations, diversion of management resources, negative publicity, and other factors. The outcomes of these matters are inherently unpredictable and subject to significant uncertainties. Determining legal reserves or possible losses from such matters involves judgment and may not reflect the full range of uncertainties and unpredictable outcomes. Until the final resolution of such matters, we may be exposed to losses in excess of the amount recorded, and such amounts could be material. Should any of our estimates and assumptions change or prove to have been incorrect, it could have a material effect on our business, consolidated financial position, results of operations, or cash flows. In addition, it is possible that a resolution of one or more such proceedings, including as a result of a settlement, could involve licenses, sanctions, consent decrees, or orders requiring us to make substantial future payments, preventing us from offering certain products or
47
Table of Contents
services, requiring us to change our business practices in a manner materially adverse to our business, requiring development of non-infringing or otherwise altered products or technologies, damaging our reputation, or otherwise having a material effect on our operations.
We Are Subject to Product Liability Claims When People or Property Are Harmed by the Products We Sell or Manufacture
Some of the products we sell or manufacture expose us to product liability or food safety claims relating to personal injury or illness, death, or environmental or property damage, and can require product recalls or other actions. Third parties who sell products using our services and stores also expose us to product liability claims. Additionally, under our A-to-z Guarantee, we may reimburse customers for certain product liability claims up to certain limits in these situations, and as our third-party seller sales grow, the cost of this program will increase and could negatively affect our operating results. Although we maintain liability insurance, we cannot be certain that our coverage will be adequate for liabilities actually incurred or that insurance will continue to be available to us on economically reasonable terms, or at all. Although we impose contractual terms on sellers that are intended to prohibit sales of certain type of products, we may not be able to detect, enforce, or collect sufficient damages for breaches of such agreements. In addition, some of our agreements with our vendors and sellers do not indemnify us from product liability.
We Face Additional Tax Liabilities and Collection Obligations
We are subject to a variety of taxes and tax collection obligations in the U.S. (federal and state) and numerous foreign jurisdictions. We may recognize additional tax expense and be subject to additional tax liabilities, including other liabilities for tax collection obligations due to changes in laws, regulations, administrative practices, principles, and interpretations related to tax, including changes to the global tax framework, competition, and other laws and accounting rules in various jurisdictions. Such changes could come about as a result of economic, political, and other conditions. An increasing number of jurisdictions are considering or have adopted laws or administrative practices that impose new tax measures, including revenue-based taxes, targeting online commerce and the remote selling of goods and services. These include new obligations to withhold or collect sales, consumption, value added, or other taxes on online marketplaces and remote sellers, or other requirements that may result in liability for third party obligations. For example, non-U.S. jurisdictions have proposed or enacted taxes on online advertising and marketplace service revenues. Proliferation of these or similar unilateral tax measures may continue unless broader international tax reform is implemented. In addition, the European Union and other countries (including those in which we operate) have enacted or may enact global minimum taxes, which may increase our tax expense.
Our results of operations and cash flows could be adversely affected by additional taxes imposed on us prospectively or retroactively or additional taxes or penalties resulting from the failure to comply with any collection obligations or failure to provide information about our customers, suppliers, and other third parties for tax reporting purposes to various government agencies. In some cases we also may not have sufficient notice to enable us to build systems and adopt processes to properly comply with new reporting or collection obligations by the effective date.
Our tax expense and liabilities are also affected by other factors, such as changes in our business operations, acquisitions, investments, entry into new businesses and geographies, intercompany transactions, the relative amount of our foreign earnings, losses incurred in jurisdictions for which we are not able to realize related tax benefits, the applicability of special or extraterritorial tax regimes, changes in foreign exchange rates, changes in our stock price, changes to our forecasts of income and loss and the mix of jurisdictions to which they relate, and changes in our tax assets and liabilities and their valuation. In the ordinary course of our business, there are many transactions and calculations for which the ultimate tax determination is uncertain. Significant judgment is required in evaluating and estimating our tax expense, assets, and liabilities.
We are also subject to tax controversies in various jurisdictions that can result in tax assessments against us. Developments in an audit, investigation, or other tax controversy can have a material effect on our operating results or cash flows in the period or periods for which that development occurs, as well as for prior and subsequent periods. Due to the inherent complexity and uncertainty of these matters, interpretations of certain tax laws by authorities, and judicial, administrative, and regulatory processes in certain jurisdictions, the final outcome of any such controversy may be materially different from our expectations. For example, the Indian tax authority has asserted that tax applies to cloud services fees paid to Amazon in the U.S. We are contesting this position; however, if this matter is adversely resolved, we may be required to pay additional amounts with respect to current and prior periods and our taxes in the future could increase. We regularly assess the likelihood of an adverse outcome resulting from these proceedings to determine the adequacy of our tax accruals. Although we believe our tax estimates are reasonable, the final outcome of audits, investigations, and any other tax controversies could be materially different from our historical tax accruals.
48
Table of Contents
We Are Subject to Risks Related to Government Contracts and Related Procurement Regulations
Our contracts with U.S., as well as state, local, and foreign, government entities are subject to various procurement regulations and other requirements relating to their formation, administration, and performance. We are subject to audits and investigations relating to our government contracts, and any violations could result in various civil and criminal penalties and administrative sanctions, including termination of contract, refunding or suspending of payments, forfeiture of profits, payment of fines, and suspension or debarment from future government business. In addition, some of these contracts are subject to periodic funding approval and/or provide for termination by the government at any time, without cause.
49
Table of Contents
Item 2.	Unregistered Sales of Equity Securities and Use of Proceeds
None.
Item 3.	Defaults Upon Senior Securities
None.
Item 4.	Mine Safety Disclosures
Not applicable.
Item 5.	Other Information
On May 4, 2026, Matthew S. Garman, CEO Amazon Web Services, adopted a trading plan intended to satisfy Rule 10b5-1(c) to sell up to 63,743 shares of Amazon.com, Inc. common stock over a period ending on May 28, 2027, subject to certain conditions.
On May 4, 2026, Daniel P. Huttenlocher, a member of our Board of Directors, adopted a trading plan intended to satisfy Rule 10b5-1(c) to sell up to 783 shares of Amazon.com, Inc. common stock over a period ending on November 23, 2026, subject to certain conditions.
On May 12, 2026, Jonathan J. Rubinstein, a member of our Board of Directors, adopted a trading plan intended to satisfy Rule 10b5-1(c) to sell up to 13,361 shares of Amazon.com, Inc. common stock over a period ending on May 9, 2028, subject to certain conditions.
On May 14, 2026, Brian T. Olsavsky, Senior Vice President and Chief Financial Officer, adopted a trading plan intended to satisfy Rule 10b5-1(c) to sell up to 6,172 shares of Amazon.com, Inc. common stock over a period ending on August 31, 2026, subject to certain conditions.
50
Table of Contents
Item 6.	Exhibits
Exhibit
Number		Description
3.1
Amended and Restated Certificate of Incorporation of Amazon.com, Inc. (incorporated by reference to the Company’s Current Report on Form 8-K, filed May 27, 2022).
3.2
Amended and Restated Bylaws of Amazon.com, Inc. (incorporated by reference to the Company’s Current Report on Form 8-K, filed May 3, 2024).
4.1
Officers’ Certificate of Amazon.com, Inc., dated as of June 12, 2026, containing Form of 3.400% Note due 2029, Form of 3.700% Note due 2031, Form of 4.000% Note due 2033, Form of 4.350% Note due 2036, and Form of 5.000% Note due 2056 (incorporated by reference to the Company’s Current Report on Form 8-K, filed June 12, 2026).
10.1
Term Loan Agreement, dated as of June 8, 2026, among Amazon.com, Inc., Citibank N.A., as administrative agent, and the lenders party thereto (incorporated by reference to the Company’s Current Report on Form 8-K, filed June 10, 2026).
10.2
Amended and Restated 364-Day Revolving Credit Agreement, dated as of October 29, 2025, as amended by the First Amendment thereto, dated as of June 8, 2026, among Amazon.com, Inc., Citibank N.A., as administrative agent, and the lenders party thereto.
10.3
Five-Year Revolving Credit Agreement, dated as of November 1, 2023, as amended by the First Amendment thereto, dated as of June 8, 2026, among Amazon.com, Inc., Citibank N.A., as administrative agent, and the lenders party thereto.
31.1
Certification of Andrew R. Jassy, President and Chief Executive Officer of Amazon.com, Inc., pursuant to Rule 13a-14(a) under the Securities Exchange Act of 1934.
31.2
Certification of Brian T. Olsavsky, Senior Vice President and Chief Financial Officer of Amazon.com, Inc., pursuant to Rule 13a-14(a) under the Securities Exchange Act of 1934.
32.1
Certification of Andrew R. Jassy, President and Chief Executive Officer of Amazon.com, Inc., pursuant to 18 U.S.C. Section 1350.
32.2
Certification of Brian T. Olsavsky, Senior Vice President and Chief Financial Officer of Amazon.com, Inc., pursuant to 18 U.S.C. Section 1350.
101
The following financial statements from the Company’s Quarterly Report on Form 10-Q for the quarter ended June 30, 2026, formatted in Inline XBRL: (i) Consolidated Statements of Cash Flows, (ii) Consolidated Statements of Operations, (iii) Consolidated Statements of Comprehensive Income, (iv) Consolidated Balance Sheets, and (v) Notes to Consolidated Financial Statements, tagged as blocks of text and including detailed tags.
104
The cover page from the Company’s Quarterly Report on Form 10-Q for the quarter ended June 30, 2026, formatted in Inline XBRL (included as Exhibit 101).
51
Table of Contents
SIGNATURES
Pursuant to the requirements of the Securities Exchange Act of 1934, the Registrant has duly caused this report to be signed on its behalf by the undersigned, thereunto duly authorized.
AMAZON.COM, INC. (REGISTRANT)
By:	/s/ Shelley L. Reynolds
Shelley L. Reynolds
Vice President, Worldwide Controller
(Principal Accounting Officer)
Dated: July 30, 2026
52
```
