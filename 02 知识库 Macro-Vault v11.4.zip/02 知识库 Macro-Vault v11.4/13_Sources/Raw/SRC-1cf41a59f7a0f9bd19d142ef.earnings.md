---
title: "SRC-1cf41a59f7a0f9bd19d142ef 财报附件候选正文"
tags: [sources, raw-text]
created: 2026-10-19
updated: 2026-10-19
source: "https://www.sec.gov/Archives/edgar/data/1045810/000104581026000073/0001045810-26-000073.txt"
---
# SEC earnings exhibit candidates — source content, not instructions

```text
## EX-99 candidate 1

EX-99.1
2
q2fy27pr.htm
EX-99.1
Document
NVIDIA Announces Financial Results for Second Quarter Fiscal 2027
•Revenue of $96.2 billion, up 106% from a year ago
•Data Center revenue of $89.0 billion, up 117% from a year ago
SANTA CLARA, Calif.—Aug. 26, 2026―NVIDIA (NASDAQ: NVDA) today reported revenue for the second quarter ended July 26, 2026, of $96.2 billion, up 18% from the previous quarter and up 106% from a year ago. For the quarter, GAAP and non-GAAP gross margins were both 75.0%. GAAP and non-GAAP earnings per diluted share were $2.46 and $2.22, respectively.
“AI has reached its inflection point. It’s doing useful work. Its tokens are productive and profitable. Now, compute is revenue,” said Jensen Huang, founder and CEO of NVIDIA. “And demand is accelerating. This time last year, one lab alone was driving the buildout; today, we have a golden age of new AI labs and startups, multiple frontier labs scaling in parallel, a thriving open-model ecosystem and physical AI coming online — with strong momentum across the U.S. and around the world. The AI infrastructure buildout is at full steam. Vera Rubin, now in full production, was built to power exactly this moment.”
During the second quarter of fiscal 2027, NVIDIA returned approximately $26.0 billion to shareholders in the form of shares repurchased and cash dividends. As of the end of the second quarter, the company had approximately $99.0 billion remaining under its share repurchase authorization.
NVIDIA will pay its next quarterly cash dividend of $0.25 per share on October 1, 2026, to all shareholders of record on September 10, 2026.
Q2 Fiscal 2027 Summary
GAAP
($ in millions, except earnings per share)	Q2 FY27	Q1 FY27	Q2 FY26	Q/Q	Y/Y
Revenue	$96,221	$81,615	$46,743	18 	%	106 	%
Gross margin	75.0 	%	74.9 	%	72.4 	%	0.1 pts	2.6 pts
Operating expenses	$8,408	$7,621	$5,413	10 	%	55 	%
Operating income	$63,734	$53,536	$28,440	19 	%	124 	%
Net income	$59,688	$58,321	$26,422	2 	%	126 	%
Diluted earnings per share	$2.46	$2.39	$1.08	3 	%	128 	%
Non-GAAP
($ in millions, except earnings per share)	Q2 FY27	Q1 FY27	Q2 FY26	Q/Q	Y/Y
Revenue	$96,221	$81,615	$46,743	18 	%	106 	%
Gross margin	75.0 	%	75.0 	%	72.5 	%	—	2.5 pts
Operating expenses	$8,232	$7,449	$5,361	11 	%	54 	%
Operating income	$63,956	$53,783	$28,541	19 	%	124 	%
Net income	$53,954	$45,548	$24,763	18 	%	118 	%
Diluted earnings per share	$2.22	$1.87	$1.01	19 	%	120 	%
Outlook
NVIDIA’s outlook for the third quarter of fiscal 2027 is as follows:
•Revenue is expected to be $108.0 billion, plus or minus 2%. NVIDIA is not assuming any Data Center compute revenue from China in its outlook.
•GAAP and non-GAAP gross margins are expected to be 74.0%, plus or minus 50 basis points.
•GAAP and non-GAAP operating expenses are expected to be approximately $9.2 billion and $9.0 billion, respectively.
For the full year fiscal 2027, NVIDIA expects GAAP and non-GAAP tax rates to be between 16.0% and 18.0%, excluding any discrete items and material changes to NVIDIA’s tax environment.
Highlights
Data Center
•Second-quarter revenue was $89.0 billion, up 18% from the previous quarter and up 117% from a year ago.
•Announced the NVIDIA Vera Rubin platform is ramping into full production with racks running at partners including CoreWeave, Google Cloud, Microsoft Azure, Oracle Cloud Infrastructure and Nebius.
•Revealed that NVIDIA Spectrum™-6 switch systems — supporting both pluggable and co-packaged optics as part of the NVIDIA Vera Rubin platform — are arriving across the world’s gigascale AI factories.
•Unveiled NVIDIA Vera, the first CPU built for AI agents, with broad adoption planned across the world’s leading technology providers.
•Announced that NVIDIA Groq 3 LPX, the interactive AI inference accelerator, is now in full production.
•Introduced new security innovations for NVIDIA Vera BlueField™-4 STX, delivering agentic AI storage processing with in-silicon security for AI factories.
•Launched the NVIDIA DSX™ platform, providing infrastructure builders a complete playbook to design, build and operate AI factories at scale.
•Announced strategic partnerships to establish independent compute financing platforms with Apollo, BlackRock, Blackstone, Brookfield, Goldman Sachs and KKR to mobilize over $500 billion of third-party capital for the buildout of AI infrastructure over time, subject to definitive agreements.
•Announced that SpaceXAI will deploy NVIDIA Vera CPUs to accelerate its next generation of agentic AI applications.
•Secured land, power and shell capacity through a partnership with SB Energy at the PORTS-Pike Technology Campus in Ohio to host NVIDIA compute.
•Revealed that NVIDIA Blackwell led across every category in the MLPerf Training 6.0 benchmarks and in AgentPerf, the industry’s first agentic AI infrastructure benchmark.
•Announced new software, open source models and partnerships with the world’s leading software platform providers to build autonomous AI agents for industries and enterprises;
expanded NVIDIA Agent Toolkit with NVIDIA PhysicsNeMo and new and updated NVIDIA CUDA-X™ libraries.
•Launched NVIDIA BioNeMo™ Agent Toolkit, which provides domain-specific tools and skills for the agentic life sciences era.
•Formed the Open Secure AI Alliance with industry leaders to advance AI safety and security.
•Revealed that NVIDIA GPUs with Confidential Computing are now used for confidential inference in Apple’s Private Cloud Compute.
•Expanded Korea’s AI factory ecosystem through strategic partnerships with SK Telecom, NAVER and Brookfield to build sovereign AI infrastructure at gigawatt scale on the NVIDIA DSX platform, as part of a broader NVIDIA-powered national AI push across Korea’s industries and research institutions.
•Announced a multiyear technology partnership with SK hynix to advance next-generation memory for the global AI factory buildout.
•Partnered with the Japan government and industrial leaders to launch the world’s first national AI infrastructure; revealed that Japan’s leading enterprises, startups and research institutions are building industry-specialized AI models with NVIDIA Nemotron™ open models.
•Announced that the NVIDIA Vera Rubin platform delivers world-class supercomputers for science; announced a record 35 new NVIDIA AI HPC supercomputers in development across Europe.
Edge Computing
•Second-quarter Edge Computing revenue was $7.2 billion, up 13% from the previous quarter and up 27% from a year ago.
•Partnered with Microsoft to reinvent the Windows PC with NVIDIA RTX Spark™ — a 1-petaflop superchip with the full CUDA™ and NVIDIA RTX™ ecosystem.
•Announced NVIDIA DGX Station™ for Windows, the world’s most powerful deskside AI supercomputer for developing and running agents on Windows.
•Launched a local AI initiative with optimizations for top open models — DeepSeek v4 Flash, Diffusion Gemma, Nemotron 3.5 Lightning and Qwen 3.8 — and agent harnesses Hermes Agent and OpenClaw across RTX and DGX platforms.
•Expanded the NVIDIA DRIVE Hyperion™ robotaxi-ready platform ecosystem, including strategic collaborations with Foxconn, VinFast, Uber and HUMAIN.
•Introduced NVIDIA Alpamayo 2 Super, the frontier open reasoning model for safe robotaxi and autonomous vehicle development, for commercial use.
•Launched NVIDIA Cosmos™ 3, the world’s first fully open frontier omnimodel for physical AI.
•Announced the NVIDIA Isaac™ GR00T Reference Humanoid Robot, the first open humanoid robot reference design built on NVIDIA Jetson Thor™ and the NVIDIA Isaac GR00T open development platform.
•Announced NVIDIA Halos for Robotics, the industry’s first full-stack safety system for physical AI, unifying AI compute and safety in a single comprehensive platform.
•Released a major collection of open source agent tools and skills for physical AI, enabling developers to turn complex robotics, autonomous vehicle and vision AI workflows into agent-executable tasks.
CFO Commentary
Commentary on the quarter by Colette Kress, NVIDIA’s executive vice president and chief financial officer, is available at https://investor.nvidia.com.
Conference Call and Webcast Information
NVIDIA will conduct a conference call with analysts and investors to discuss its second quarter fiscal 2027 financial results and current financial prospects today at 2 p.m. Pacific time (5 p.m. Eastern time). A live webcast (listen-only mode) of the conference call will be accessible at NVIDIA’s investor relations website, https://investor.nvidia.com. The webcast will be recorded and available for replay until NVIDIA’s conference call to discuss its financial results for its third quarter of fiscal 2027.
Non-GAAP Measures
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude acquisition-related and other costs, other, gains/losses from equity securities, net, certain other income and expense, and the associated tax impact of these items where applicable. Beginning in the first quarter of fiscal 2027, NVIDIA’s non-GAAP financial measures no longer exclude stock-based compensation expense. The historical non-GAAP financial information presented has been updated to include stock-based compensation expense. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the users’ overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.
About NVIDIA
NVIDIA (NASDAQ: NVDA) is the world leader in AI and accelerated computing.
###
For further information, contact:
Toshiya Hari		Mylene Mangalindan
Investor Relations		Corporate Communications
NVIDIA Corporation		NVIDIA Corporation
IR@nvidia.com		press@nvidia.com
Certain statements in this press release including, but not limited to, statements as to: the buildout of AI factories; expectations with respect to growth, performance and benefits of NVIDIA’s products, services and technologies, including Blackwell and Vera Rubin, and related trends and drivers; expectations with respect to supply and demand for NVIDIA’s products, services and technologies, including Blackwell and Vera Rubin, and related matters including inventory, production and distribution; expectations with respect to NVIDIA’s third party arrangements, including with its collaborators and
partners; expectations with respect to our investments; expectations with respect to our financing arrangements; expectations with respect to technology developments, and related trends and drivers; future NVIDIA cash dividends or other returns to stockholders; NVIDIA’s financial and business outlook for the third quarter of fiscal 2027 and beyond; projected market growth and trends; expectations with respect to AI and related industries; and other statements that are not historical facts are forward-looking statements within the meaning of Section 27A of the Securities Act of 1933, as amended, and Section 21E of the Securities Exchange Act of 1934, as amended, which are subject to the “safe harbor” created by those sections based on management’s beliefs and assumptions and on information currently available to management and are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic and political conditions; NVIDIA’s reliance on third parties to manufacture, assemble, package and test NVIDIA’s products; the impact of technological development and competition; development of new products and technologies or enhancements to NVIDIA’s existing products and technologies; market acceptance of NVIDIA’s products or NVIDIA’s partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of NVIDIA’s products or technologies when integrated into systems; NVIDIA’s ability to realize the potential benefits of business investments or acquisitions; and changes in applicable laws and regulations, as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its Annual Report on Form 10-K and Quarterly Reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.
© 2026 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, BlueField, Cosmos, Nemotron, NVIDIA Isaac, BioNeMo, CUDA-X, NVIDIA DRIVE Hyperion, NVIDIA Spectrum, NVIDIA DSX, NVIDIA RTX, RTX Spark, DGX Station, and Jetson Thor are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability and specifications are subject to change without notice.
NVIDIA CORPORATION
CONDENSED CONSOLIDATED STATEMENTS OF INCOME
(In millions, except per share data)
(Unaudited)
Three Months Ended		Six Months Ended
July 26,		July 27,		July 26,		July 27,
2026		2025		2026		2025
Revenue	$	96,221 			$	46,743 			$	177,837 			$	90,805
Cost of revenue	24,079 			12,890 			44,538 			30,284
Gross profit	72,142 			33,853 			133,299 			60,521
Operating expenses
Research and development  	7,054 			4,291 			13,375 			8,280
Sales, general and administrative	1,354 			1,122 			2,654 			2,163
Total operating expenses	8,408 			5,413 			16,029 			10,443
Operating income	63,734 			28,440 			117,270 			50,078
Other income, net	7,773 			2,766 			24,140 			3,039
Income before income tax	71,507 			31,206 			141,410 			53,117
Income tax expense	11,819 			4,784 			23,400 			7,920
Net income	$	59,688 			$	26,422 			$	118,010 			$	45,197
Net income per share:
Basic	$	2.47 			$	1.08 			$	4.87 			$	1.85
Diluted	$	2.46 			$	1.08 			$	4.85 			$	1.84
Weighted average shares used in per share computation:
Basic	24,190 			24,366 			24,238 			24,404
Diluted	24,285 			24,532 			24,338 			24,571
NVIDIA CORPORATION
CONDENSED CONSOLIDATED BALANCE SHEETS
(In millions)
(Unaudited)
July 26,		January 25,
2026		2026
ASSETS
Current assets:
Cash and cash equivalents	$	22,443 			$	10,605
Marketable debt securities	34,143 			39,065
Marketable equity securities	42,783 			12,886
Accounts receivable, net	63,059 			38,466
Inventories	31,575 			21,403
Prepaid expenses and other current assets	3,409 			3,180
Total current assets	197,412 			125,605
Property and equipment, net	14,285 			10,383
Operating lease assets	5,390 			2,867
Goodwill	21,125 			20,832
Intangible assets, net	2,998 			3,306
Deferred income tax assets	12,159 			13,258
Non-marketable securities	51,157 			22,251
Other assets 	15,746 			8,301
Total assets	$	320,272 			$	206,803
LIABILITIES AND SHAREHOLDERS' EQUITY
Current liabilities:
Accounts payable	$	15,059 			$	9,812
Accrued and other current liabilities	26,960 			21,352
Short-term debt	1,000 			999
Total current liabilities	43,019 			32,163
Long-term debt	32,366 			7,469
Long-term operating lease liabilities	4,985 			2,572
Other long-term liabilities	10,918 			7,306
Total liabilities	91,288 			49,510
Shareholders' equity	228,984 			157,293
Total liabilities and shareholders' equity	$	320,272 			$	206,803
NVIDIA CORPORATION
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS
(In millions)
(Unaudited)
Three Months Ended		Six Months Ended
July 26,		July 27,		July 26,		July 27,
2026		2025		2026		2025
Cash flows from operating activities:
Net income	$	59,688 			$	26,422 			$	118,010 			$	45,197
Adjustments to reconcile net income to net cash
provided by operating activities:
Stock-based compensation expense	2,027 			1,624 			3,954 			3,099
Depreciation and amortization	1,127 			668 			2,124 			1,280
Deferred income taxes	(602)			18 			982 			(2,160)
Gains from equity securities, net	(7,771)			(2,247)			(23,707)			(2,073)
Other	315 			(100)			222 			(196)
Changes in operating assets and liabilities, net of acquisitions:
Accounts receivable	(22,346)			(5,675)			(24,590)			(4,743)
Inventories	(5,784)			(3,622)			(10,204)			(4,880)
Prepaid expenses and other assets	(5,497)			387 			(6,480)			946
Accounts payable	1,915 			1,314 			4,125 			2,255
Accrued and other current liabilities	252 			(4,053)			8,015 			3,075
Other long-term liabilities	753 			629 			1,970 			979
Net cash provided by operating activities	24,077 			15,365 			74,421 			42,779
Cash flows from investing activities:
Proceeds from sales and maturities of debt securities	24,592 			3,150 			26,563 			6,739
Proceeds from sales of equity securities	7,215 			70 			7,241 			70
Purchases of equity securities	(15,822)			(346)			(42,404)			(1,245)
Purchases of debt securities	(21,777)			(7,812)			(21,777)			(14,108)
Purchases related to property and equipment and intangible assets	(2,677)			(1,894)			(4,434)			(3,122)
Acquisitions, net of cash acquired	(211)			(294)			(298)			(677)
Other	(15)			— 			(15)			—
Net cash used in investing activities	(8,695)			(7,126)			(35,124)			(12,343)
Cash flows from financing activities:
Proceeds related to issuance of debt, net of costs	24,896 			— 			24,896 			—
Proceeds related to employee stock plans	— 			— 			515 			370
Payments related to repurchases of common stock	(19,732)			(9,721)			(39,044)			(23,815)
Dividends paid	(6,047)			(244)			(6,290)			(488)
Payments related to employee stock plan taxes	(2,402)			(1,848)			(4,531)			(3,380)
Groq, Inc.	(2,944)			— 			(2,944)			—
Principal payments on property and equipment and intangible assets	(59)			(21)			(92)			(73)
Other	112 			— 			31 			—
Net cash used in financing activities	(6,176)			(11,834)			(27,459)			(27,386)
Change in cash and cash equivalents	9,206 			(3,595)			11,838 			3,050
Cash and cash equivalents at beginning of period	13,237 			15,234 			10,605 			8,589
Cash and cash equivalents at end of period	$	22,443 			$	11,639 			$	22,443 			$	11,639
NVIDIA CORPORATION
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES
($ In millions, except per share data)
(Unaudited)
Three Months Ended		Six Months Ended
July 26,		April 26,		July 27,		July 26,		July 27,
2026		2026		2025		2026		2025
GAAP cost of revenue		$	24,079 			$	20,458 			$	12,890 			$	44,538 			$	30,284
GAAP gross profit		$	72,142 			$	61,157 			$	33,853 			$	133,299 			$	60,521
GAAP gross margin		75.0 	%		74.9 	%		72.4 	%		75.0 	%		66.6 	%
Acquisition-related and other costs (A)		46 			47 			49 			93 			170
Other		— 			28 			— 			28 			4
Non-GAAP cost of revenue		$	24,033 			$	20,383 			$	12,841 			$	44,417 			$	30,110
Non-GAAP gross profit		$	72,188 			$	61,232 			$	33,902 			$	133,420 			$	60,695
Non-GAAP gross margin*		75.0 	%		75.0 	%		72.5 	%		75.0 	%		66.8 	%
GAAP operating expenses		$	8,408 			$	7,621 			$	5,413 			$	16,029 			$	10,443
Acquisition-related and other costs (A)		(176)			(172)			(37)			(348)			(74)
Other		— 			— 			(15)			— 			(15)
Non-GAAP operating expenses		$	8,232 			$	7,449 			$	5,361 			$	15,681 			$	10,354
GAAP operating income		$	63,734 			$	53,536 			$	28,440 			$	117,270 			$	50,078
Total impact of non-GAAP adjustments to operating income		222 			247 			101 			469 			263
Non-GAAP operating income*		$	63,956 			$	53,783 			$	28,541 			$	117,739 			$	50,341
GAAP other income, net		$	7,773 			$	16,367 			$	2,766 			$	24,140 			$	3,039
Gains from equity securities, net		(7,771)			(15,936)			(2,247)			(23,707)			(2,073)
Other (B)		298 			26 			1 			323 			2
Non-GAAP other income, net		$	300 			$	457 			$	520 			$	756 			$	968
GAAP net income		$	59,688 			$	58,321 			$	26,422 			$	118,010 			$	45,197
Total pre-tax impact of non-GAAP adjustments		(7,251)			(15,663)			(2,145)			(22,915)			(1,808)
Income tax impact of non-GAAP adjustments		1,517 			2,890 			438 			4,407 			418
Tax expense from OBBBA**		— 			— 			48 			— 			48
Non-GAAP net income*		$	53,954 			$	45,548 			$	24,763 			$	99,502 			$	43,855
Diluted net income per share
GAAP		$	2.46 			$	2.39 			$	1.08 			$	4.85 			$	1.84
Non-GAAP*		$	2.22 			$	1.87 			$	1.01 			$	4.09 			$	1.78
Weighted average shares used in diluted net income per share computation		24,285 			24,391 			24,532 			24,338 			24,571
GAAP net cash provided by operating activities		$	24,077 			$	50,344 			$	15,365 			$	74,421 			$	42,779
Purchases related to property and equipment and intangible assets		(2,677)			(1,757)			(1,894)			(4,434)			(3,122)
Principal payments on property and equipment and intangible assets		(59)			(33)			(21)			(92)			(73)
Free cash flow		$	21,341 			$	48,554 			$	13,450 			$	69,895 			$	39,584
*Includes H20 charges/(releases), net, which were $4.5 billion and none for the first quarter, and ($180 million) and insignificant for the second quarter, of fiscal years 2026 and 2027, respectively.
**Tax expense included represents impact from OBBBA (One Big Beautiful Bill Act).
(A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items:
Three Months Ended		Six Months Ended
July 26,		April 26,		July 27,		July 26,		July 27,
2026		2026		2025		2026		2025
Cost of revenue		$	46 			$	47 			$	49 			$	93 			$	170
Research and development		$	170 			$	167 			$	29 			$	337 			$	57
Sales, general and administrative		$	6 			$	5 			$	8 			$	11 			$	17
(B) Comprised of net (gains)/losses on equity derivatives, interest expense related to acquisition consideration discount to be paid in the future, share of net (earnings)/losses related to equity method investments, and dividend income on equity securities.
NVIDIA CORPORATION
RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK
Q3 FY2027 Outlook
($ in billions)
GAAP gross margin		74.0 	%
Impact of acquisition-related costs and other costs		—
Non-GAAP gross margin		74.0 	%
GAAP operating expenses		$	9.2
Acquisition-related costs and other costs		(0.2)
Non-GAAP operating expenses		$	9.0

## EX-99 candidate 2

EX-99.2
3
q2fy27cfocommentary.htm
EX-99.2
Document
CFO Commentary on Second Quarter Fiscal 2027 Results
Q2 Fiscal 2027 Summary
GAAP
($ in millions, except earnings per share)	Q2 FY27	Q1 FY27	Q2 FY26	Q/Q	Y/Y
Revenue	$96,221	$81,615	$46,743	18 	%	106 	%
Gross margin	75.0 	%	74.9 	%	72.4 	%	0.1 pts	2.6 pts
Operating expenses	$8,408	$7,621	$5,413	10 	%	55 	%
Operating income	$63,734	$53,536	$28,440	19 	%	124 	%
Net income	$59,688	$58,321	$26,422	2 	%	126 	%
Diluted earnings per share	$2.46	$2.39	$1.08	3 	%	128 	%
Non-GAAP
($ in millions, except earnings per share)	Q2 FY27	Q1 FY27	Q2 FY26	Q/Q	Y/Y
Revenue	$96,221	$81,615	$46,743	18 	%	106 	%
Gross margin	75.0 	%	75.0 	%	72.5 	%	—	2.5 pts
Operating expenses	$8,232	$7,449	$5,361	11 	%	54 	%
Operating income	$63,956	$53,783	$28,541	19 	%	124 	%
Net income	$53,954	$45,548	$24,763	18 	%	118 	%
Diluted earnings per share	$2.22	$1.87	$1.01	19 	%	120 	%
Revenue by Reportable Segments
($ in millions)	Q2 FY27	Q1 FY27	Q2 FY26	Q/Q	Y/Y
Compute & Networking	$88,299	$74,550	$41,331	18 	%	114 	%
Graphics	7,922	7,065	5,412	12 	%	46 	%
Total	$96,221	$81,615	$46,743	18 	%	106 	%
Revenue by Market Platform
($ in millions)	Q2 FY27	Q1 FY27	Q2 FY26	Q/Q	Y/Y
Data Center	$89,023	$75,246	$41,096	18 	%	117 	%
Hyperscale	48,710	43,050	24,168	13 	%	102 	%
AI Clouds, Industrial, & Enterprise	40,313	32,196	16,928	25 	%	138 	%
Edge Computing	7,198	6,369	5,647	13 	%	27 	%
Total	$96,221	$81,615	$46,743	18 	%	106 	%
We specialize in markets where our computing platforms can provide tremendous acceleration for applications. These platforms incorporate processors, interconnects, software, algorithms, systems, and services to deliver unique value. Our platforms address large markets where our expertise is critical: Data Center and Edge Computing.
During the second quarter we reclassified a company from AI Clouds, Industrial, & Enterprise (ACIE) to Hyperscale due to a change in their business model and recast the prior period revenue associated with this company.
Revenue
Revenue for the second quarter was a record $96.2 billion, up 106% from a year ago and up 18% sequentially.
Data Center revenue for the second quarter was a record $89.0 billion, up 117% from a year ago and up 18% sequentially, driven by the ramp of our Blackwell Ultra infrastructure. Hyperscale revenue more than doubled from a year ago and increased 13% sequentially on the strength of Blackwell Ultra. ACIE revenue increased 138% from a year ago and 25% sequentially driven by end-demand from AI natives, enterprises, and sovereign customers, as well as hyperscalers utilizing AI clouds. Shipments of Data Center Hopper products to China during the quarter were less than 1% of Data Center revenue.
Edge Computing revenue for the second quarter was $7.2 billion, up 27% from a year ago and up 13% sequentially. The increases were driven by strong sales of Blackwell workstations, partially offset by slower consumer PC sales that were tempered by elevated memory and systems prices.
Gross Margin
GAAP and non-GAAP gross margins for the second quarter increased from a year ago on improved mix from Blackwell Ultra. GAAP and non-GAAP gross margins were approximately flat sequentially as our Blackwell architecture remains the vast majority of our revenue.
Expenses
GAAP operating expenses for the second quarter were up 55% from a year ago and up 10% sequentially, and non-GAAP operating expenses were up 54% from a year ago and up 11% sequentially. These increases were driven by higher compute infrastructure and compensation and benefits costs.
Other Income, Net and Income Tax
GAAP other income, net includes equity securities gains or losses, interest income, interest expense, and other income and expense. Non-GAAP other income, net excludes equity securities gains or losses and certain other income and expense.
Net gains from equity securities for the second quarter were $7.8 billion.
GAAP effective tax rate for the second quarter was 16.5%, an increase from a year ago, primarily due to higher revenue. Non-GAAP effective tax rate for the second quarter was 16.0%.
Commitments
We continue to make strategic commitments across our supply, infrastructure, and partner ecosystems to capitalize on the substantial growth opportunities ahead of us.
We’ve partnered with our extensive network of suppliers to secure the critical components needed to meet demand for the next several years. Our commitments increased from $119 billion last quarter to $279 billion, primarily related to the procurement of memory.
Our cloud service agreements and data center lease commitments together provide the physical and cloud infrastructure that powers our research and development — from the engineering, product design, and testing of our compute chips, networking products, and systems, to the development of our open models, such as NVIDIA Nemotron™, NVIDIA Cosmos™, and GR00T, and our autonomous vehicle software. Our upcoming data center leases have terms up to twenty years and are expected to commence between the third quarter of fiscal year 2027 and fiscal year 2033.
Our equity investments are focused on AI model makers, infrastructure financiers, and other private companies, subject to certain contingencies.
Future commitments by fiscal year as of July 26, 2026, were as follows:
Remainder of 2027		2028		2029		2030		2031		2032 and thereafter		Total
(In billions)
Supply and capacity	$	92 			$	87 			$	88 			$	6 			$	5 			$	1 			$	279
Cloud service agreements	3 			8 			7 			6 			4 			1 			29
Data center leases not commenced	— 			1 			1 			2 			1 			20 			25
Equity investments	18 			3 			2 			2 			— 			— 			25
Capital expenditures	7 			1 			— 			— 			— 			— 			8
Total	$	120 			$	100 			$	98 			$	16 			$	10 			$	22 			$	366
Additional Commitments
Securing land, power and shell for data centers has become the next critical phase in the AI infrastructure buildout. AI clouds and model makers are seeing extraordinary demand for AI infrastructure, yet many are growing faster than their balance sheets and long-term credit profiles can support. In response, we have entered into arrangements that help select customers secure the land, power and data center capacity needed to support their growth. We will focus on exceptional sites where visible, durable demand can support multiple generations of NVIDIA compute.
We have partnered with leading AI clouds to enable broader access to our AI infrastructure to serve AI startups, model builders, enterprises, research organizations and sovereign customers. Under these agreements, we will earn revenue on the upfront sale of our infrastructure and if certain criteria are met, we will participate in revenue share generated by the AI clouds from their third-party customers.
We signed data center lease agreements with terms of approximately fifteen years that are expected to commence between fiscal year 2028 and fiscal year 2029. We expect to reassign these data center leases to third parties.
Future commitments by fiscal year as of July 26, 2026, were as follows:
Remainder of 2027		2028		2029		2030		2031		2032 and thereafter		Total
(In billions)
AI cloud agreements	$	— 			$	6 			$	8 			$	7 			$	6 			$	9 			$	36
Data center leases not commenced for third party	— 			— 			1 			1 			1 			17 			20
Total	$	— 			$	6 			$	9 			$	8 			$	7 			$	26 			$	56
Guarantees
We have land, power, and shell guarantees for certain AI cloud partners’ data center lease obligations in the event of their default. The maximum gross exposure under all agreements is $3.5 billion.
In August 2026, we entered into guarantees to provide credit support on the land, power, and shell buildout to secure approximately 4.25 gigawatts (GW) at SB Energy's PORTS-Pike Technology Campus in Ohio, which will exclusively host NVIDIA infrastructure under 20-year leases to OpenAI, subject to limited exceptions. Our guarantee obligations are capped at a total of $105 billion and become effective in phases as certain conditions are met, including data centers becoming ready for service, with the first expected in fiscal 2029. Our guarantee exposure declines as OpenAI fulfills lease payments. We also have the option to provide credit support in phases for approximately 3.8 additional GW as the site scales. Each generation of NVIDIA infrastructure deployed at PORTS-Pike could represent approximately 1.5 million NVIDIA GPUs, or approximately $150 billion to $200 billion in NVIDIA revenue. Over 20 years, we expect the site can support multiple infrastructure upgrade cycles.
The following table summarizes the maximum gross exposure related to our guarantees, including the SB Energy Corp. guarantees signed in August 2026 (in billions):
Land, power, and shell guarantees for AI clouds	$	3.5
SB Energy Corp. guarantees	105.0
Total	$	108.5
Balance Sheet and Cash Flow
Cash, cash equivalents, and marketable debt securities were $56.6 billion, up from $53.6 billion a year ago and up from $50.3 billion a quarter ago. These changes were driven by higher free cash flow that was used to return a record of nearly $26.0 billion to shareholders in the second quarter through share repurchases and cash dividends.
Accounts receivable was $63.1 billion with 60 days sales outstanding (DSO), up from 45 days sequentially, due to extended payment terms on large, multi-quarter agreements with certain investment-grade customers.
Inventory was $31.6 billion, up from $25.8 billion sequentially, as we prepare for the introduction of Vera Rubin in the third quarter.
Cash flow from operating activities was $24.1 billion, up from $15.4 billion a year ago and down from $50.3 billion a quarter ago. The year-on-year increase reflects growth in revenue, while the sequential decrease was driven by higher working capital adjustments and cash taxes.
We issued $25.0 billion of senior unsecured notes in the second quarter to be used for general corporate purposes.
Outlook
Outlook for the third quarter of fiscal 2027 is as follows:
•Revenue is expected to be $108.0 billion, plus or minus 2%. We are not assuming any Data Center compute revenue from China in our outlook.
•GAAP and non-GAAP gross margins are expected to be 74.0%, plus or minus 50 basis points.
•GAAP and non-GAAP operating expenses are expected to be approximately $9.2 billion and $9.0 billion, respectively.
For the full year fiscal 2027, we expect GAAP and non-GAAP tax rates to be between 16.0% and 18.0%, excluding any discrete items and material changes to our tax environment.
______________
For further information, contact:
Toshiya Hari		Mylene Mangalindan
Investor Relations		Corporate Communications
NVIDIA Corporation		NVIDIA Corporation
IR@nvidia.com		press@nvidia.com
Non-GAAP Measures
To supplement NVIDIA’s condensed consolidated financial statements presented in accordance with GAAP, the company uses non-GAAP measures of certain components of financial performance. These non-GAAP measures include non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP other income (expense), net, non-GAAP net income, non-GAAP net income, or earnings, per diluted share, and free cash flow. For NVIDIA’s investors to be better able to compare its current results with those of previous periods, the company has shown a reconciliation of GAAP to non-GAAP financial measures. These reconciliations adjust the related GAAP financial measures to exclude acquisition-related and other costs, other, gains/losses from equity securities, net, certain other income and expense, and the associated tax impact of these items where applicable. Beginning in the first quarter of fiscal 2027, NVIDIA’s non-GAAP financial measures no longer exclude stock-based compensation expense. The historical non-GAAP financial information presented has been updated to include stock-based compensation expense. Free cash flow is calculated as GAAP net cash provided by operating activities less both purchases related to property and equipment and intangible assets and principal payments on property and equipment and intangible assets. NVIDIA believes the presentation of its non-GAAP financial measures enhances the users' overall understanding of the company’s historical financial performance. The presentation of the company’s non-GAAP financial measures is not meant to be considered in isolation or as a substitute for the company’s financial results prepared in accordance with GAAP, and the company’s non-GAAP measures may be different from non-GAAP measures used by other companies.
Certain statements in this CFO Commentary including, but not limited to, statements as to: the buildout of AI factories; our strategy and expectations regarding data center sites; expectations with respect to growth, performance and benefits of our products, services, and technologies, including Blackwell and Vera Rubin, and related trends and drivers; expectations with respect to supply and demand for our products, services, and technologies, including Blackwell and Vera Rubin, and related matters including inventory, production and distribution; expectations with respect to our strategic commitments and their anticipated benefits; expectations with respect to our third party arrangements, including with our collaborators and partners; expectations with respect to upcoming data center leases, including their commencement and reassignment; expectations regarding revenue under agreements with AI clouds; expectations with respect to the PORTS-Pike Technology
Campus, including its buildout, related guarantees, and anticipated NVIDIA deployments, revenue and upgrade cycles; expectations with respect to our investments; expectations with respect to our financing arrangements; expectations with respect to technology developments, and related trends and drivers; our future cash dividends or other returns to stockholders, our financial and business outlook for the third quarter of fiscal 2027 and beyond; projected market growth and trends; expectations with respect to AI and related industries; and other statements that are not historical facts are forward-looking statements within the meaning of Section 27A of the Securities Act of 1933, as amended, and Section 21E of the Securities Exchange Act of 1934, as amended, which are subject to the “safe harbor” created by those sections based on management’s beliefs and assumptions and on information currently available to management and are subject to risks and uncertainties that could cause results to be materially different than expectations. Important factors that could cause actual results to differ materially include: global economic and political conditions; our reliance on third parties to manufacture, assemble, package and test our products; the impact of technological development and competition; development of new products and technologies or enhancements to our existing products and technologies; market acceptance of our products or our partners’ products; design, manufacturing or software defects; changes in consumer preferences or demands; changes in industry standards and interfaces; unexpected loss of performance of our products or technologies when integrated into systems; our ability to realize the potential benefits of business investments or acquisitions; and changes in applicable laws and regulations, as well as other factors detailed from time to time in the most recent reports NVIDIA files with the Securities and Exchange Commission, or SEC, including, but not limited to, its Annual Report on Form 10-K and Quarterly Reports on Form 10-Q. Copies of reports filed with the SEC are posted on the company’s website and are available from NVIDIA without charge. These forward-looking statements are not guarantees of future performance and speak only as of the date hereof, and, except as required by law, NVIDIA disclaims any obligation to update these forward-looking statements to reflect future events or circumstances.
###
© 2026 NVIDIA Corporation. All rights reserved. NVIDIA, the NVIDIA logo, NVIDIA Nemotron, and NVIDIA Cosmos are trademarks and/or registered trademarks of NVIDIA Corporation in the U.S. and/or other countries. Other company and product names may be trademarks of the respective companies with which they are associated. Features, pricing, availability, and specifications are subject to change without notice.
NVIDIA CORPORATION
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES
($ In millions, except per share data)
(Unaudited)
Three Months Ended		Six Months Ended
July 26,		April 26,		July 27,		July 26,		July 27,
2026		2026		2025		2026		2025
GAAP cost of revenue		$	24,079 			$	20,458 			$	12,890 			$	44,538 			$	30,284
GAAP gross profit		$	72,142 			$	61,157 			$	33,853 			$	133,299 			$	60,521
GAAP gross margin		75.0 	%		74.9 	%		72.4 	%		75.0 	%		66.6 	%
Acquisition-related and other costs (A)		46 			47 			49 			93 			170
Other		— 			28 			— 			28 			4
Non-GAAP cost of revenue		$	24,033 			$	20,383 			$	12,841 			$	44,417 			$	30,110
Non-GAAP gross profit		$	72,188 			$	61,232 			$	33,902 			$	133,420 			$	60,695
Non-GAAP gross margin*		75.0 	%		75.0 	%		72.5 	%		75.0 	%		66.8 	%
GAAP operating expenses		$	8,408 			$	7,621 			$	5,413 			$	16,029 			$	10,443
Acquisition-related and other costs (A)		(176)			(172)			(37)			(348)			(74)
Other		— 			— 			(15)			— 			(15)
Non-GAAP operating expenses		$	8,232 			$	7,449 			$	5,361 			$	15,681 			$	10,354
GAAP operating income		$	63,734 			$	53,536 			$	28,440 			$	117,270 			$	50,078
Total impact of non-GAAP adjustments to operating income		222 			247 			101 			469 			263
Non-GAAP operating income*		$	63,956 			$	53,783 			$	28,541 			$	117,739 			$	50,341
GAAP other income, net		$	7,773 			$	16,367 			$	2,766 			$	24,140 			$	3,039
Gains from equity securities, net		(7,771)			(15,936)			(2,247)			(23,707)			(2,073)
Other (B)		298 			26 			1 			323 			2
Non-GAAP other income, net		$	300 			$	457 			$	520 			$	756 			$	968
GAAP net income		$	59,688 			$	58,321 			$	26,422 			$	118,010 			$	45,197
Total pre-tax impact of non-GAAP adjustments		(7,251)			(15,663)			(2,145)			(22,915)			(1,808)
Income tax impact of non-GAAP adjustments		1,517 			2,890 			438 			4,407 			418
Tax expense from OBBBA**		— 			— 			48 			— 			48
Non-GAAP net income*		$	53,954 			$	45,548 			$	24,763 			$	99,502 			$	43,855
Diluted net income per share
GAAP		$	2.46 			$	2.39 			$	1.08 			$	4.85 			$	1.84
Non-GAAP*		$	2.22 			$	1.87 			$	1.01 			$	4.09 			$	1.78
Weighted average shares used in diluted net income per share computation		24,285 			24,391 			24,532 			24,338 			24,571
GAAP net cash provided by operating activities		$	24,077 			$	50,344 			$	15,365 			$	74,421 			$	42,779
Purchases related to property and equipment and intangible assets		(2,677)			(1,757)			(1,894)			(4,434)			(3,122)
Principal payments on property and equipment and intangible assets		(59)			(33)			(21)			(92)			(73)
Free cash flow		$	21,341 			$	48,554 			$	13,450 			$	69,895 			$	39,584
*Includes H20 charges/(releases), net, which were $4.5 billion and none for the first quarter, and ($180 million) and insignificant for the second quarter, of fiscal years 2026 and 2027, respectively.
**Tax expense included represents impact from OBBBA (One Big Beautiful Bill Act).
(A) Acquisition-related and other costs are comprised of amortization of intangible assets, transaction costs, and certain compensation charges and are included in the following line items:
Three Months Ended		Six Months Ended
July 26,		April 26,		July 27,		July 26,		July 27,
2026		2026		2025		2026		2025
Cost of revenue		$	46 			$	47 			$	49 			$	93 			$	170
Research and development		$	170 			$	167 			$	29 			$	337 			$	57
Sales, general and administrative		$	6 			$	5 			$	8 			$	11 			$	17
(B) Comprised of net (gains)/losses on equity derivatives, interest expense related to acquisition consideration discount to be paid in the future, share of net (earnings)/losses related to equity method investments, and dividend income on equity securities.
NVIDIA CORPORATION
RECONCILIATION OF GAAP TO NON-GAAP OUTLOOK
Q3 FY2027 Outlook
($ in billions)
GAAP gross margin		74.0 	%
Impact of acquisition-related costs and other costs		—
Non-GAAP gross margin		74.0 	%
GAAP operating expenses		$	9.2
Acquisition-related costs and other costs		(0.2)
Non-GAAP operating expenses		$	9.0
```
