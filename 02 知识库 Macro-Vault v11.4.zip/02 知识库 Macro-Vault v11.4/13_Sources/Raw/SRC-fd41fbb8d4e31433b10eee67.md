---
title: "SRC-fd41fbb8d4e31433b10eee67 提取正文"
tags: [sources, raw-text]
created: 2026-10-19
updated: 2026-10-19
source: "https://www.sec.gov/Archives/edgar/data/789019/000119312526323632/0001193125-26-323632.txt"
---
# Source text — untrusted evidence

```text
0001193125-26-323632.txt : 20260729
0001193125-26-323632.hdr.sgml : 20260729
20260729160453
ACCESSION NUMBER:		0001193125-26-323632
CONFORMED SUBMISSION TYPE:	8-K
PUBLIC DOCUMENT COUNT:		10
CONFORMED PERIOD OF REPORT:	20260729
ITEM INFORMATION:		Results of Operations and Financial Condition
ITEM INFORMATION:		Financial Statements and Exhibits
FILED AS OF DATE:		20260729
DATE AS OF CHANGE:		20260729
FILER:
COMPANY DATA:
COMPANY CONFORMED NAME:			MICROSOFT CORP
CENTRAL INDEX KEY:			0000789019
STANDARD INDUSTRIAL CLASSIFICATION:	SERVICES-PREPACKAGED SOFTWARE [7372]
ORGANIZATION NAME:           	06 Technology
EIN:				911144442
STATE OF INCORPORATION:			WA
FISCAL YEAR END:			0630
FILING VALUES:
FORM TYPE:		8-K
SEC ACT:		1934 Act
SEC FILE NUMBER:	001-37845
FILM NUMBER:		261217337
BUSINESS ADDRESS:
STREET 1:		ONE MICROSOFT WAY
CITY:			REDMOND
STATE:			WA
ZIP:			98052-6399
BUSINESS PHONE:		425-882-8080
MAIL ADDRESS:
STREET 1:		ONE MICROSOFT WAY
CITY:			REDMOND
STATE:			WA
ZIP:			98052-6399
8-K
1
msft-20260729.htm
8-K
8-K
00007890192026-07-292026-07-290000789019us-gaap:CommonStockMember2026-07-292026-07-290000789019msft:NotesTwoPointSixTwoFivePercentDueMayTwoTwentyThirtyThreeMember2026-07-292026-07-290000789019msft:NotesThreePointOneTwoFivePercentDueDecemberSixTwentyTwentyEightMember2026-07-292026-07-29
UNITED STATES
SECURITIES AND EXCHANGE COMMISSION
WASHINGTON, D.C. 20549
FORM 8-K
CURRENT REPORT
PURSUANT TO SECTION 13 OR 15(D)
OF THE SECURITIES EXCHANGE ACT OF 1934
Date of Report (Date of earliest event reported) July 29, 2026
Microsoft Corporation
Washington
001-37845
91-1144442
(State or Other Jurisdiction
of Incorporation)
(Commission
File Number)
(IRS Employer
Identification No.)
One Microsoft Way, Redmond, Washington 98052-6399
(425) 882-8080
www.microsoft.com/investor
Check the appropriate box below if the Form 8-K filing is intended to simultaneously satisfy the filing obligation of the registrant under any of the following provisions (see General Instruction A.2. below):

Written communications pursuant to Rule 425 under the Securities Act (17 CFR 230.425)

Soliciting material pursuant to Rule 14a-12 under the Exchange Act (17 CFR 240.14a-12)

Pre-commencement communications pursuant to Rule 14d-2(b) under the Exchange Act (17 CFR 240.14d-2(b))

Pre-commencement communications pursuant to Rule 13e-4(c) under the Exchange Act (17 CFR 240.13e-4(c))
Securities registered pursuant to Section 12(b) of the Act:
Title of each class
Trading Symbol
Name of exchange on which registered
Common stock, $0.00000625 par value per share
MSFT
Nasdaq
3.125% Notes due 2028
MSFT
Nasdaq
2.625% Notes due 2033
MSFT
Nasdaq
Indicate by check mark whether the registrant is an emerging growth company as defined in Rule 405 of the Securities Act of 1933 (§230.405 of this chapter) or Rule 12b-2 of the Securities Exchange Act of 1934 (§240.12b-2 of this chapter). Emerging growth company ¨
If an emerging growth company, indicate by check mark if the registrant has elected not to use the extended transition period for complying with any new or revised financial accounting standards provided pursuant to Section 13(a) of the Exchange Act. ¨
Item 2.02.
Results of Operations and Financial Condition
On July 29, 2026, Microsoft Corporation issued a press release announcing its financial results for the fiscal quarter and year ended June 30, 2026. A copy of the press release is furnished as Exhibit 99.1 to this report.
In accordance with General Instruction B.2 of Form 8-K, the information in this Current Report on Form 8-K, including Exhibit 99.1, shall not be deemed to be “filed” for purposes of Section 18 of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), or otherwise subject to the liability of that section, and shall not be incorporated by reference into any registration statement or other document filed under the Securities Act of 1933, as amended, or the Exchange Act, except as shall be expressly set forth by specific reference in such filing.
Item 9.01.
Financial Statements and Exhibits
(d) Exhibits:
99.1
Press release, dated July 29, 2026 issued by Microsoft Corporation
104
Cover Page Interactive Data File (embedded within the Inline XBRL document)
SIGNATURE
Pursuant to the requirements of the Securities Exchange Act of 1934, the registrant has duly caused this report to be signed on its behalf by the undersigned hereunto duly authorized.
MICROSOFT CORPORATION
(Registrant)
Date: July 29, 2026
/s/ ALICE L. JOLLA
Alice L. Jolla
Corporate Vice President and
Chief Accounting Officer
EX-99.1
2
msft-ex99_1.htm
EX-99.1
EX-99.1
Exhibit 99.1
Microsoft Cloud and AI Strength Fuels Fourth Quarter Results
REDMOND, Wash. — July 29, 2026 — Microsoft Corp. today announced the following results for the quarter ended June 30, 2026, as compared to the corresponding period of last fiscal year:
•
Revenue was $90.0 billion and increased 18% (up 17% in constant currency)
•
Operating income was $40.6 billion and increased 18%
•
Net income was $35.8 billion and increased 31% on a GAAP basis, and was $35.3 billion and increased 22% on a non-GAAP basis
•
Diluted earnings per share was $4.81 and increased 32% on a GAAP basis, and was $4.74 and increased 23% on a non-GAAP basis
•
Non-GAAP results exclude the impact from investments in OpenAI, explained in the Non-GAAP Definition section below
Several discrete items impacted our financial results in the quarter when compared to our forward-looking guidance provided on April 29, 2026, resulting in a benefit of $0.27 on diluted earnings per share. These include a $3.2 billion gain from our investment in Anthropic and lower-than-expected expenses related to the Voluntary Retirement Program which were partially offset by severance expense and impairment charges in XBOX. When adjusting for these items, we exceeded expectations across revenue, operating income, and diluted earnings per share.
“We are advancing the frontier on the cost-to-outcome curve, ensuring every customer can turn tokens into business results,” said Satya Nadella, chairman and chief executive officer of Microsoft. “This year, Azure revenue surpassed $100 billion for the first time, and Microsoft 365 Copilot reached over 30 million paid seats, reflecting the confidence customers are placing in us to power their AI transformation.”
“We delivered a strong quarter to close out the fiscal year, highlighted by Microsoft Cloud revenue of $59.3 billion, up 27% year-over-year,” said Amy Hood, executive vice president and chief financial officer of Microsoft.
The following table adjusts for the impact from investments in OpenAI and reconciles our financial results reported in accordance with generally accepted accounting principles (GAAP) to non-GAAP financial results. Additional information regarding our non-GAAP definition is provided below. All growth comparisons relate to the corresponding period in the last fiscal year.
Three Months Ended June 30,
2026
2025
Percentage Change Y/Y
Percentage Change Y/Y
($ in millions, except per share amounts)
As Reported (GAAP)
Impact from OpenAI*
As Adjusted (non-GAAP)
As Reported (GAAP)
Impact from OpenAI*
As Adjusted (non-GAAP)
GAAP
Constant Currency
Net Impact from OpenAI*
Non-GAAP
Non-GAAP Constant Currency
Net Income
$35,766
$(480)
$35,286
$27,233
$1,575
$28,808
31%
31%
$(2,055)
22%
22%
Diluted Earnings per Share
$4.81
$(0.07)
$4.74
$3.65
$0.21
$3.86
32%
32%
$(0.28)
23%
23%
*Impact from OpenAI adjusts for the impact from investments in OpenAI
Business Highlights
Microsoft Cloud revenue was $59.3 billion and increased 27%, and commercial remaining performance obligation increased 84% to $678 billion.
Revenue in Productivity and Business Processes was $37.8 billion and increased 14%, with the following business highlights:
•
Microsoft 365 Commercial cloud revenue increased 16% when adjusted for the prior year comparable that benefited from 2 points of in-period revenue recognition. On a reported basis, Microsoft 365 Commercial cloud revenue increased 14%.
•
Microsoft 365 Consumer cloud revenue increased 24% (up 22% in constant currency)
•
LinkedIn revenue increased 12% (up 10% in constant currency)
•
Dynamics 365 revenue increased 13% (up 12% in constant currency)
Revenue in Intelligent Cloud was $39.3 billion and increased 32% (up 31% in constant currency), with the following business highlights:
•
Azure and other cloud services revenue increased 43%
Revenue in More Personal Computing was $12.9 billion and decreased 4% (down 5% in constant currency), with the following business highlights:
•
Windows OEM and Devices revenue decreased 7%
•
XBOX content and services revenue decreased 10%
•
Search advertising revenue excluding traffic acquisition costs increased 10% (up 9% in constant currency)
Microsoft returned $10.2 billion to shareholders in the form of dividends and share repurchases in the fourth quarter of fiscal year 2026.
Fiscal Year 2026 Results
Microsoft Corp. today announced the following results for the fiscal year ended June 30, 2026, as compared to the corresponding period of last fiscal year:
•
Revenue was $331.8 billion and increased 18% (up 16% in constant currency)
•
Operating income was $155.2 billion and increased 21% (up 19% in constant currency)
•
Net income was $133.7 billion and increased 31% on a GAAP basis, and increased 22% (up 20% in constant currency) on a non-GAAP basis
•
Diluted earnings per share was $17.95 and increased 32% on a GAAP basis, and increased 22% (up 21% in constant currency) on a non-GAAP basis
•
Non-GAAP results exclude the impact from investments in OpenAI, explained in the Non-GAAP Definition section below
The following table adjusts for the impact from investments in OpenAI and reconciles our financial results reported in accordance with GAAP to non-GAAP financial results. Additional information regarding our non-GAAP definition is provided below. All growth comparisons relate to the corresponding period in the last fiscal year.
Twelve Months Ended June 30,
2026
2025
Percentage Change Y/Y
Percentage Change Y/Y
($ in millions, except per share amounts)
As Reported (GAAP)
Impact from OpenAI*
As Adjusted (non-GAAP)
As Reported (GAAP)
Impact from OpenAI*
As Adjusted (non-GAAP)
GAAP
Constant Currency
Net Impact from OpenAI*
Non-GAAP
Non-GAAP Constant Currency
Net Income
$133,749
$(4,963)
$128,786
$101,832
$3,620
$105,452
31%
30%
$(8,583)
22%
20%
Diluted Earnings per Share
$17.95
$(0.67)
$17.28
$13.64
$0.49
$14.13
32%
30%
$(1.16)
22%
21%
*Impact from OpenAI adjusts for the impact from investments in OpenAI
Business Outlook
Microsoft will provide forward-looking guidance in connection with this quarterly earnings announcement on its earnings conference call and webcast.
Quarterly Highlights, Product Releases, and Customer Stories
Every quarter Microsoft delivers hundreds of products, services, and enhancements. These releases are driven by years of significant research and development investments, to empower customers with greater productivity, security, and differentiated value.
This momentum is reflected in stories that showcase how our technology is shaping industries and driving customer success. We share innovation updates on our product blogs across Azure, Microsoft 365, and more on our Official Microsoft blog.
Webcast Details
Satya Nadella, chairman and chief executive officer, Amy Hood, executive vice president and chief financial officer, Alice Jolla, chief accounting officer, Brian DeFoe, deputy general counsel and corporate secretary, and Jonathan Neilson, vice president of investor relations, will host a conference call and webcast at 2:30 p.m. Pacific time (5:30 p.m. Eastern time) today to discuss details of the company’s performance for the quarter and certain forward-looking information. The session may be accessed at http://www.microsoft.com/en-us/investor. Participants can also dial into the conference call at (877) 407-0666 or +1 (201) 689-8023 for international, no password required. The webcast will be available for replay through the close of business on July 29, 2027.
Non-GAAP Definition
Impact from investments in OpenAI. In fiscal year 2026, net income and diluted earnings per share were impacted by net gains from investments in OpenAI, which resulted in an increase in net income and diluted earnings per share of $480 million and $0.07, respectively, in the fourth quarter, and $4,963 million and $0.67, respectively, for the full fiscal year. In fiscal year 2025, net income and diluted earnings per share were impacted by net losses from investments in OpenAI, which resulted in a decrease in net income and diluted earnings per share of $1,575 million and $0.21, respectively, in the fourth quarter, and $3,620 million and $0.49, respectively, for the full fiscal year.
Microsoft has provided non-GAAP financial measures related to the impact from investments in OpenAI to aid investors in better understanding our performance. Microsoft believes these non-GAAP measures assist investors by providing additional insight into its operational performance and help clarify trends affecting its business. For comparability of reporting, management considers non-GAAP measures in conjunction with GAAP financial results in evaluating business performance. The non-GAAP financial measures presented in this release should not be considered as a substitute for, or superior to, the measures of financial performance prepared in accordance with GAAP.
Constant Currency
Microsoft presents constant currency information to provide a framework for assessing how our underlying businesses performed excluding the effect of foreign currency rate fluctuations. To present this information, current and comparative prior period results for entities reporting in currencies other than United States dollars are converted into United States dollars using the average exchange rates from the comparative period rather than the actual exchange rates in effect during the respective periods. All growth comparisons relate to the corresponding period in the last fiscal year. Microsoft has provided this non-GAAP financial information to aid investors in better understanding our performance. The non-GAAP financial measures presented in this release should not be considered as a substitute for, or superior to, the measures of financial performance prepared in accordance with GAAP.
Financial Performance Constant Currency Reconciliation
Three Months Ended June 30,
2026
2025
Percentage Change Y/Y
Percentage Change Y/Y
($ in millions, except per share amounts)
As Reported (GAAP)
As Adjusted (non-GAAP)
As Reported (GAAP)
As Adjusted (non-GAAP)
GAAP
Non-GAAP
Constant Currency Impact
Constant Currency
Non-GAAP Constant Currency
Revenue
$90,007
-
$76,441
-
18%
-
$391
17%
-
Operating Income
$40,603
-
$34,323
-
18%
-
$269
18%
-
Net Income
$35,766
$35,286
$27,233
$28,808
31%
22%
$40
31%
22%
Diluted Earnings per Share
$4.81
$4.74
$3.65
$3.86
32%
23%
$0.01
32%
23%
Twelve Months Ended June 30,
2026
2025
Percentage Change Y/Y
Percentage Change Y/Y
($ in millions, except per share amounts)
As Reported (GAAP)
As Adjusted (non-GAAP)
As Reported (GAAP)
As Adjusted (non-GAAP)
GAAP
Non-GAAP
Constant Currency Impact
Constant Currency
Non-GAAP Constant Currency
Revenue
$331,839
-
$281,724
-
18%
-
$4,445
16%
-
Operating Income
$155,237
-
$128,528
-
21%
-
$2,896
19%
-
Net Income
$133,749
$128,786
$101,832
$105,452
31%
22%
$1,772
30%
20%
Diluted Earnings per Share
$17.95
$17.28
$13.64
$14.13
32%
22%
$0.24
30%
21%
Segment Revenue Constant Currency Reconciliation
Three Months Ended June 30,
2026
2025
Percentage Change Y/Y
Percentage Change Y/Y
($ in millions)
As Reported (GAAP)
As Reported (GAAP)
GAAP
Constant Currency Impact
Constant Currency
Productivity and Business Processes
$37,847
$33,112
14%
$244
14%
Intelligent Cloud
$39,306
$29,878
32%
$80
31%
More Personal Computing
$12,854
$13,451
(4)%
$67
(5)%
Selected Product and Service Information Constant Currency Reconciliation
Three Months Ended June 30, 2026
Percentage Change Y/Y (GAAP)
Constant Currency Impact
Percentage Change Y/Y Constant Currency
Microsoft Cloud revenue
27%
0%
27%
Commercial remaining performance obligation
84%
0%
84%
Microsoft 365 Commercial cloud revenue
14%
0%
14%
Microsoft 365 Consumer cloud revenue
24%
(2)%
22%
LinkedIn revenue
12%
(2)%
10%
Dynamics 365 revenue
13%
(1)%
12%
Azure and other cloud services revenue
43%
0%
43%
Windows OEM and Devices revenue
(7)%
0%
(7)%
XBOX content and services revenue
(10)%
0%
(10)%
Search advertising revenue excluding traffic acquisition costs
10%
(1)%
9%
About Microsoft
Microsoft (Nasdaq “MSFT” @microsoft) creates platforms and tools powered by AI to deliver innovative solutions that meet the evolving needs of our customers. The technology company is committed to making AI available broadly and doing so responsibly, with a mission to empower every person and every organization on the planet to achieve more.
Forward-Looking Statements
Statements in this release that are “forward-looking statements” are based on current expectations and assumptions that are subject to risks and uncertainties. Actual results could differ materially because of factors such as:
•
intense competition in all of our markets that could adversely affect our results of operations;
•
substantial investments in cloud and AI strategy that depend on customer demand, technological developments, competitive dynamics, and regulatory condition;
•
development, delivery, and maintenance of competitive cloud-based and AI products and services that achieve broad customer adoption and sustainable revenue growth;
•
significant investments in products and services that may not achieve expected returns;
•
acquisitions, joint ventures, and strategic alliances that could have an adverse effect on our business;
•
cyberattacks and security vulnerabilities that could lead to reduced revenue, increased costs, liability claims, or harm to our reputation or competitive position;
•
disclosure and misuse of personal data that could cause liability and harm to our reputation;
•
the possibility that we may not be able to protect information in our products and services from use by others;
•
abuse of our platforms that may harm our reputation or user engagement;
•
products and services, how they are used by customers, and how third-party products and services interact with them, presenting security, privacy, and execution risks;
•
issues about the development, deployment, and use of AI that may result in reputational or competitive harm, or liability;
•
inability to develop and expand adequate infrastructure;
•
supply or other quality problems;
•
excessive outages, disruptions, or capacity constraints of our services if we fail to maintain an adequate operations infrastructure or secure resources necessary to support it;
•
potential consequences of new, existing, and evolving legal and regulatory requirements;
•
claims against us that could result in adverse outcomes in legal disputes;
•
uncertainties relating to our business with government customers;
•
additional tax liabilities;
•
an inability to protect and utilize our intellectual property may harm our business and operating results;
•
claims that Microsoft has infringed the intellectual property rights of others;
•
damage to our reputation or our brands that may harm our business and results of operations;
•
adverse economic or market conditions that could harm our business;
•
catastrophic events or geopolitical conditions that could disrupt our business;
•
exposure to increased economic and operational uncertainties from operating a global business, including the effects of foreign currency exchange; and
•
the dependence of our business on our ability to attract and retain talented employees.
For more information about risks and uncertainties associated with Microsoft’s business, please refer to the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” sections of Microsoft’s SEC filings, including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q, copies of which may be obtained by contacting Microsoft’s Investor Relations department at (800) 285-7772 or at Microsoft’s Investor Relations website at http://www.microsoft.com/en-us/investor.
All information in this release is as of June 30, 2026. The company undertakes no duty to update any forward-looking statement to conform the statement to actual results or changes in the company’s expectations.
For more information, press only:
Microsoft Media Relations, WE Communications for Microsoft, (425) 638-7777, rrt@we-worldwide.com
For more information, financial analysts and investors only:
Jonathan Neilson, Vice President, Investor Relations, (425) 706-4400
Note to editors: For more information, news and perspectives from Microsoft, please visit the Microsoft News Center at http://www.microsoft.com/news. Web links, telephone numbers, and titles were correct at time of publication, but may since have changed. Shareholder and financial information, as well as today’s 2:30 p.m. Pacific time conference call with investors and analysts, is available at http://www.microsoft.com/en-us/investor.
MICROSOFT CORPORATION
INCOME STATEMENTS
(In millions, except per share amounts) (Unaudited)
Three Months Ended
June 30,
Twelve Months Ended
June 30,
2026
2025
2026
2025
Revenue:
Product
$17,234
$17,136
$64,696
$63,946
Service and other
72,773
59,305
267,143
217,778
Total revenue
90,007
76,441
331,839
281,724
Cost of revenue:
Product
2,938
3,314
12,098
13,501
Service and other
26,587
20,700
94,276
74,330
Total cost of revenue
29,525
24,014
106,374
87,831
Gross margin
60,482
52,427
225,465
193,893
Research and development
9,997
8,829
35,562
32,488
Sales and marketing
7,595
7,285
26,710
25,654
General and administrative
2,287
1,990
7,956
7,223
Operating income
40,603
34,323
155,237
128,528
Other income (expense), net
3,444
(1,707)
10,697
(4,901)
Income before income taxes
44,047
32,616
165,934
123,627
Provision for income taxes
8,281
5,383
32,185
21,795
Net income
$35,766
$27,233
$133,749
$101,832
Earnings per share:
Basic
$4.82
$3.66
$18.00
$13.70
Diluted
$4.81
$3.65
$17.95
$13.64
Weighted average shares outstanding:
Basic
7,427
7,432
7,429
7,433
Diluted
7,443
7,461
7,453
7,465
COMPREHENSIVE INCOME STATEMENTS
(In millions) (Unaudited)
Three Months Ended
Twelve Months Ended
June 30,
June 30,
2026
2025
2026
2025
Net income
$35,766
$27,233
$133,749
$101,832
Other comprehensive income (loss), net of tax:
Net change related to derivatives
14
(9)
8
(5)
Net change related to investments
(72)
444
215
1,574
Translation adjustments and other
2
1,051
(160)
674
Other comprehensive income (loss)
(56)
1,486
63
2,243
Comprehensive income
$35,710
$28,719
$133,812
$104,075
BALANCE SHEETS
(In millions) (Unaudited)
June 30,
2026
June 30,
2025
Assets
Current assets:
Cash and cash equivalents
$20,935
$30,242
Short-term investments
55,908
64,323
Total cash, cash equivalents, and short-term investments
76,843
94,565
Accounts receivable, net of allowance for doubtful accounts of $1,040 and $944
80,876
69,905
Inventories
1,397
938
Other current assets
48,594
25,723
Total current assets
207,710
191,131
Property and equipment, net of accumulated depreciation of $118,691 and $93,653
313,076
204,966
Operating lease right-of-use assets
24,177
24,823
Equity and other investments
36,348
15,405
Goodwill
119,651
119,509
Intangible assets, net
18,609
22,604
Other long-term assets
38,805
40,565
Total assets
$758,376
$619,003
Liabilities and stockholders' equity
Current liabilities:
Accounts payable
$42,416
$27,724
Current portion of long-term debt
9,227
2,999
Accrued compensation
14,945
13,709
Short-term income taxes
2,534
7,211
Short-term unearned revenue
72,965
64,555
Other current liabilities
26,738
25,020
Total current liabilities
168,825
141,218
Long-term debt
31,067
40,152
Long-term income taxes
28,647
25,986
Long-term unearned revenue
2,747
2,710
Deferred income taxes
3,054
2,835
Operating lease liabilities
16,532
17,437
Other long-term liabilities
65,117
45,186
Total liabilities
315,989
275,524
Commitments and contingencies
Stockholders' equity:
Common stock and paid-in capital - shares authorized 24,000; outstanding 7,427 and 7,434
117,406
109,095
Retained earnings
328,265
237,731
Accumulated other comprehensive loss
(3,284)
(3,347)
Total stockholders' equity
442,387
343,479
Total liabilities and stockholders' equity
$758,376
$619,003
CASH FLOWS STATEMENTS
(In millions) (Unaudited)
Three Months Ended
Twelve Months Ended
June 30,
June 30,
2026
2025
2026
2025
Operations
Net income
$35,766
$27,233
$133,749
$101,832
Adjustments to reconcile net income to net cash from operations:
Depreciation, amortization, and other
11,022
9,317
38,534
29,433
Stock-based compensation expense
3,122
3,073
12,405
11,974
Net recognized losses (gains) on investments and derivatives
(3,743)
1,942
(11,047)
5,329
Deferred income taxes
4,650
(2,221)
14,189
(7,056)
Changes in operating assets and liabilities:
Accounts receivable
(21,084)
(16,179)
(12,737)
(10,581)
Inventories
(178)
(81)
(461)
309
Other current assets
(2,842)
(3,686)
(2,627)
(3,044)
Other long-term assets
(1,350)
418
(3,964)
(2,950)
Accounts payable
2,365
(652)
5,268
569
Unearned revenue
22,428
18,361
9,361
5,438
Income taxes
(307)
1,043
(1,875)
(38)
Other current liabilities
7,013
5,346
6,847
5,922
Other long-term liabilities
(1,421)
(1,267)
(4,707)
(975)
Net cash from operations
55,441
42,647
182,935
136,162
Financing
Repayments of debt, maturities of 90 days or less
0
0
0
(5,746)
Repayments of debt
0
0
(3,000)
(3,216)
Common stock issued
520
548
2,009
2,056
Common stock repurchased
(4,579)
(4,546)
(22,271)
(18,420)
Common stock cash dividends paid
(6,758)
(6,169)
(26,445)
(24,082)
Other, net
(962)
(677)
(2,839)
(2,291)
Net cash used in financing
(11,779)
(10,844)
(52,546)
(51,699)
Investing
Additions to property and equipment
(35,802)
(17,079)
(115,948)
(64,551)
Acquisition of companies, net of cash acquired and divestitures, and purchases of intangible and other assets
(452)
(1,743)
(1,743)
(5,978)
Purchases of investments
(18,829)
(21,631)
(58,351)
(29,775)
Maturities of investments
4,181
4,618
34,605
16,079
Sales of investments
6,487
2,621
21,798
9,309
Other, net
(10,416)
2,642
(19,861)
2,317
Net cash used in investing
(54,831)
(30,572)
(139,500)
(72,599)
Effect of foreign exchange rates on cash and cash equivalents
(1)
183
(196)
63
Net change in cash and cash equivalents
(11,170)
1,414
(9,307)
11,927
Cash and cash equivalents, beginning of period
32,105
28,828
30,242
18,315
Cash and cash equivalents, end of period
$20,935
$30,242
$20,935
$30,242
We have recast certain prior period amounts to conform to the current period presentation.
SEGMENT RESULTS
(In millions) (Unaudited)
Three Months Ended
Twelve Months Ended
June,
June 30,
2026
2025
2026
2025
Productivity and Business Processes
Revenue
$37,847
$33,112
$139,996
$120,810
Cost of revenue
6,989
6,042
25,017
22,422
Operating expenses
8,958
8,077
31,100
28,615
Operating income
$21,900
$18,993
$83,879
$69,773
Intelligent Cloud
Revenue
$39,306
$29,878
$137,791
$106,265
Cost of revenue
16,876
11,845
57,876
40,171
Operating expenses
6,475
5,893
22,943
21,505
Operating income
$15,955
$12,140
$56,972
$44,589
More Personal Computing
Revenue
$12,854
$13,451
$54,052
$54,649
Cost of revenue
5,660
6,127
23,481
25,238
Operating expenses
4,446
4,134
16,185
15,245
Operating income
$2,748
$3,190
$14,386
$14,166
Total
Revenue
$90,007
$76,441
$331,839
$281,724
Cost of revenue
29,525
24,014
106,374
87,831
Operating expenses
19,879
18,104
70,228
65,365
Operating income
$40,603
$34,323
$155,237
$128,528
EX-101.SCH
3
msft-20260729.xsd
XBRL TAXONOMY EXTENSION SCHEMA WITH EMBEDDED LINKBASES DOCUMENT
75000 - Document - Document and Entity Information
link:presentationLink
link:calculationLink
link:definitionLink
Entity Incorporation, State or Country Code
Entity Incorporation, State or Country Code
2.625% Notes Due 2033 [Member]
Notes Two Point Six Two Five Percent Due May Two Twenty Thirty Three [Member]
Notes Two Point Six Two Five Percent Due May Two Twenty Thirty Three [Member]
Amendment Flag
Amendment Flag
Pre-commencement Issuer Tender Offer
Pre-commencement Issuer Tender Offer
Entity Address, Postal Zip Code
Entity Address, Postal Zip Code
Common Stock [Member]
Common Stock [Member]
Entity Address, Address Line One
Entity Address, Address Line One
Document Type
Document Type
Entity Central Index Key
Entity Central Index Key
Entity Address, State or Province
Entity Address, State or Province
Pre-commencement Tender Offer
Pre-commencement Tender Offer
Entity Address, City or Town
Entity Address, City or Town
Security Exchange Name
Security Exchange Name
Written Communications
Written Communications
Document Period End Date
Document Period End Date
Class of Stock
Class of Stock [Axis]
Entity File Number
Securities Act File Number
Cover [Abstract]
Cover [Abstract]
Entities [Table]
Entities [Table]
Title of 12(b) Security
Title of 12(b) Security
Trading Symbol
Trading Symbol
3.125% Notes Due 2028 [Member]
Notes Three Point One Two Five Percent Due December Six Twenty Twenty Eight [Member]
Notes Three Point One Two Five Percent Due December Six Twenty Twenty Eight [Member]
Entity Registrant Name
Entity Registrant Name
City Area Code
City Area Code
Soliciting Material
Soliciting Material
Entity Information [Line Items]
Entity Information [Line Items]
Entity Tax Identification Number
Entity Tax Identification Number
Local Phone Number
Local Phone Number
Class of Stock
Class of Stock [Domain]
Entity Emerging Growth Company
Entity Emerging Growth Company
XML
5
R1.htm
IDEA: XBRL DOCUMENT
v3.26.1
Document and Entity Information
Jul. 29, 2026
Entity Information [Line Items]
Document Type
8-K
Document Period End Date
Jul. 29,  2026
Entity Registrant Name
Microsoft Corporation
Entity Incorporation, State or Country Code
WA
Entity File Number
001-37845
Entity Tax Identification Number
91-1144442
Entity Address, Address Line One
One Microsoft Way
Entity Address, City or Town
Redmond
Entity Address, State or Province
WA
Entity Address, Postal Zip Code
98052-6399
City Area Code
425
Local Phone Number
882-8080
Written Communications
false
Soliciting Material
false
Pre-commencement Tender Offer
false
Pre-commencement Issuer Tender Offer
false
Entity Emerging Growth Company
false
Amendment Flag
false
Entity Central Index Key
0000789019
Common Stock [Member]
Entity Information [Line Items]
Title of 12(b) Security
Common stock, $0.00000625 par value per share
Trading Symbol
MSFT
Security Exchange Name
NASDAQ
3.125% Notes Due 2028 [Member]
Entity Information [Line Items]
Title of 12(b) Security
3.125% Notes due 2028
Trading Symbol
MSFT
Security Exchange Name
NASDAQ
2.625% Notes Due 2033 [Member]
Entity Information [Line Items]
Title of 12(b) Security
2.625% Notes due 2033
Trading Symbol
MSFT
Security Exchange Name
NASDAQ
X
- Definition
Boolean flag that is true when the XBRL content amends previously-filed or accepted submission.
+ References
No definition available.
+ Details
Name:
dei_AmendmentFlag
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Area code of city
+ References
No definition available.
+ Details
Name:
dei_CityAreaCode
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
For the EDGAR submission types of Form 8-K: the date of the report, the date of the earliest event reported; for the EDGAR submission types of Form N-1A: the filing date; for all other submission types: the end of the reporting or transition period. The format of the date is YYYY-MM-DD.
+ References
No definition available.
+ Details
Name:
dei_DocumentPeriodEndDate
Namespace Prefix:
dei_
Data Type:
xbrli:dateItemType
Balance Type:
na
Period Type:
duration
X
- Definition
The type of document being provided (such as 10-K, 10-Q, 485BPOS, etc). The document type is limited to the same value as the supporting SEC submission type, or the word 'Other'.
+ References
No definition available.
+ Details
Name:
dei_DocumentType
Namespace Prefix:
dei_
Data Type:
dei:submissionTypeItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Address Line 1 such as Attn, Building Name, Street Name
+ References
No definition available.
+ Details
Name:
dei_EntityAddressAddressLine1
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Name of the City or Town
+ References
No definition available.
+ Details
Name:
dei_EntityAddressCityOrTown
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Code for the postal or zip code
+ References
No definition available.
+ Details
Name:
dei_EntityAddressPostalZipCode
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Name of the state or province.
+ References
No definition available.
+ Details
Name:
dei_EntityAddressStateOrProvince
Namespace Prefix:
dei_
Data Type:
dei:stateOrProvinceItemType
Balance Type:
na
Period Type:
duration
X
- Definition
A unique 10-digit SEC-issued value to identify entities that have filed disclosures with the SEC. It is commonly abbreviated as CIK.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b-2
+ Details
Name:
dei_EntityCentralIndexKey
Namespace Prefix:
dei_
Data Type:
dei:centralIndexKeyItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Indicate if registrant meets the emerging growth company criteria.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b-2
+ Details
Name:
dei_EntityEmergingGrowthCompany
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Commission file number. The field allows up to 17 characters. The prefix may contain 1-3 digits, the sequence number may contain 1-8 digits, the optional suffix may contain 1-4 characters, and the fields are separated with a hyphen.
+ References
No definition available.
+ Details
Name:
dei_EntityFileNumber
Namespace Prefix:
dei_
Data Type:
dei:fileNumberItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Two-character EDGAR code representing the state or country of incorporation.
+ References
No definition available.
+ Details
Name:
dei_EntityIncorporationStateCountryCode
Namespace Prefix:
dei_
Data Type:
dei:edgarStateCountryItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Line items represent financial concepts included in a table. These concepts are used to disclose reportable information associated with domain members defined in one or many axes to the table.
+ References
No definition available.
+ Details
Name:
dei_EntityInformationLineItems
Namespace Prefix:
dei_
Data Type:
xbrli:stringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
The exact name of the entity filing the report as specified in its charter, which is required by forms filed with the SEC.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b-2
+ Details
Name:
dei_EntityRegistrantName
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
The Tax Identification Number (TIN), also known as an Employer Identification Number (EIN), is a unique 9-digit value assigned by the IRS.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b-2
+ Details
Name:
dei_EntityTaxIdentificationNumber
Namespace Prefix:
dei_
Data Type:
dei:employerIdItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Local phone number for entity.
+ References
No definition available.
+ Details
Name:
dei_LocalPhoneNumber
Namespace Prefix:
dei_
Data Type:
xbrli:normalizedStringItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as pre-commencement communications pursuant to Rule 13e-4(c) under the Exchange Act.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 13e
-Subsection 4c
+ Details
Name:
dei_PreCommencementIssuerTenderOffer
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as pre-commencement communications pursuant to Rule 14d-2(b) under the Exchange Act.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 14d
-Subsection 2b
+ Details
Name:
dei_PreCommencementTenderOffer
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Title of a 12(b) registered security.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection b
+ Details
Name:
dei_Security12bTitle
Namespace Prefix:
dei_
Data Type:
dei:securityTitleItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Name of the Exchange on which a security is registered.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 12
-Subsection d1-1
+ Details
Name:
dei_SecurityExchangeName
Namespace Prefix:
dei_
Data Type:
dei:edgarExchangeCodeItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as soliciting material pursuant to Rule 14a-12 under the Exchange Act.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Exchange Act
-Number 240
-Section 14a
-Subsection 12
+ Details
Name:
dei_SolicitingMaterial
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Trading symbol of an instrument as listed on an exchange.
+ References
No definition available.
+ Details
Name:
dei_TradingSymbol
Namespace Prefix:
dei_
Data Type:
dei:tradingSymbolItemType
Balance Type:
na
Period Type:
duration
X
- Definition
Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as written communications pursuant to Rule 425 under the Securities Act.
+ References
Reference 1: http://www.xbrl.org/2003/role/presentationRef
-Publisher SEC
-Name Securities Act
-Number 230
-Section 425
+ Details
Name:
dei_WrittenCommunications
Namespace Prefix:
dei_
Data Type:
xbrli:booleanItemType
Balance Type:
na
Period Type:
duration
X
- Details
Name:
us-gaap_StatementClassOfStockAxis=us-gaap_CommonStockMember
Namespace Prefix:
Data Type:
na
Balance Type:
Period Type:
X
- Details
Name:
us-gaap_StatementClassOfStockAxis=msft_NotesThreePointOneTwoFivePercentDueDecemberSixTwentyTwentyEightMember
Namespace Prefix:
Data Type:
na
Balance Type:
Period Type:
X
- Details
Name:
us-gaap_StatementClassOfStockAxis=msft_NotesTwoPointSixTwoFivePercentDueMayTwoTwentyThirtyThreeMember
Namespace Prefix:
Data Type:
na
Balance Type:
Period Type:
XML
6
report.css
IDEA: XBRL DOCUMENT
/* Updated 2009-11-04 */
/* v2.2.0.24 */
/* DefRef Styles */
.report table.authRefData{
background-color: #def;
border: 2px solid #2F4497;
font-size: 1em;
position: absolute;
}
.report table.authRefData a {
display: block;
font-weight: bold;
}
.report table.authRefData p {
margin-top: 0px;
}
.report table.authRefData .hide {
background-color: #2F4497;
padding: 1px 3px 0px 0px;
text-align: right;
}
.report table.authRefData .hide a:hover {
background-color: #2F4497;
}
.report table.authRefData .body {
height: 150px;
overflow: auto;
width: 400px;
}
.report table.authRefData table{
font-size: 1em;
}
/* Report Styles */
.pl a, .pl a:visited {
color: black;
text-decoration: none;
}
/* table */
.report {
background-color: white;
border: 2px solid #acf;
clear: both;
color: black;
font: normal 8pt Helvetica, Arial, san-serif;
margin-bottom: 2em;
}
.report hr {
border: 1px solid #acf;
}
/* Top labels */
.report th {
background-color: #acf;
color: black;
font-weight: bold;
text-align: center;
}
.report th.void	{
background-color: transparent;
color: #000000;
font: bold 10pt Helvetica, Arial, san-serif;
text-align: left;
}
.report .pl {
text-align: left;
vertical-align: top;
white-space: normal;
width: 200px;
white-space: normal; /* word-wrap: break-word; */
}
.report td.pl a.a {
cursor: pointer;
display: block;
width: 200px;
overflow: hidden;
}
.report td.pl div.a {
width: 200px;
}
.report td.pl a:hover {
background-color: #ffc;
}
/* Header rows... */
.report tr.rh {
background-color: #acf;
color: black;
font-weight: bold;
}
/* Calendars... */
.report .rc {
background-color: #f0f0f0;
}
/* Even rows... */
.report .re, .report .reu {
background-color: #def;
}
.report .reu td {
border-bottom: 1px solid black;
}
/* Odd rows... */
.report .ro, .report .rou {
background-color: white;
}
.report .rou td {
border-bottom: 1px solid black;
}
.report .rou table td, .report .reu table td {
border-bottom: 0px solid black;
}
/* styles for footnote marker */
.report .fn {
white-space: nowrap;
}
/* styles for numeric types */
.report .num, .report .nump {
text-align: right;
white-space: nowrap;
}
.report .nump {
padding-left: 2em;
}
.report .nump {
padding: 0px 0.4em 0px 2em;
}
/* styles for text types */
.report .text {
text-align: left;
white-space: normal;
}
.report .text .big {
margin-bottom: 1em;
width: 17em;
}
.report .text .more {
display: none;
}
.report .text .note {
font-style: italic;
font-weight: bold;
}
.report .text .small {
width: 10em;
}
.report sup {
font-style: italic;
}
.report .outerFootnotes {
font-size: 1em;
}
XML
7
Show.js
IDEA: XBRL DOCUMENT
// Edgar(tm) Renderer was created by staff of the U.S. Securities and Exchange Commission.  Data and content created by government employees within the scope of their employment are not subject to domestic copyright protection. 17 U.S.C. 105.
var Show={};Show.LastAR=null,Show.showAR=function(a,r,w){if(Show.LastAR)Show.hideAR();var e=a;while(e&&e.nodeName!='TABLE')e=e.nextSibling;if(!e||e.nodeName!='TABLE'){var ref=((window)?w.document:document).getElementById(r);if(ref){e=ref.cloneNode(!0);
e.removeAttribute('id');a.parentNode.appendChild(e)}}
if(e)e.style.display='block';Show.LastAR=e};Show.hideAR=function(){Show.LastAR.style.display='none'};Show.toggleNext=function(a){var e=a;while(e.nodeName!='DIV')e=e.nextSibling;if(!e.style){}else if(!e.style.display){}else{var d,p_;if(e.style.display=='none'){d='block';p='-'}else{d='none';p='+'}
e.style.display=d;if(a.textContent){a.textContent=p+a.textContent.substring(1)}else{a.innerText=p+a.innerText.substring(1)}}}
XML
9
FilingSummary.xml
IDEA: XBRL DOCUMENT
3.26.1
html
4
22
1
false
3
0
false
0
false
false
R1.htm
75000 - Document - Document and Entity Information
Sheet
http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation
Document and Entity Information
Cover
1
false
false
All Reports
Book
All Reports
msft-20260729.htm
msft-20260729.xsd
http://xbrl.sec.gov/dei/2025
false
false
JSON
11
MetaLinks.json
IDEA: XBRL DOCUMENT
{
"version": "2.2",
"instance": {
"msft-20260729.htm": {
"nsprefix": "msft",
"nsuri": "http://www.microsoft.com/20260729",
"dts": {
"inline": {
"local": [
"msft-20260729.htm"
]
},
"schema": {
"local": [
"msft-20260729.xsd"
],
"remote": [
"http://www.xbrl.org/2003/xbrl-instance-2003-12-31.xsd",
"http://www.xbrl.org/2003/xbrl-linkbase-2003-12-31.xsd",
"http://www.xbrl.org/2003/xl-2003-12-31.xsd",
"http://www.xbrl.org/2003/xlink-2003-12-31.xsd",
"http://www.xbrl.org/2005/xbrldt-2005.xsd",
"http://www.xbrl.org/2006/ref-2006-02-27.xsd",
"http://www.xbrl.org/lrr/arcrole/esma-arcrole-2018-11-21.xsd",
"https://www.xbrl.org/2020/extensible-enumerations-2.0.xsd",
"https://www.xbrl.org/dtr/type/2020-01-21/types.xsd",
"https://www.xbrl.org/dtr/type/2024-01-31/types.xsd",
"https://xbrl.fasb.org/srt/2025/elts/srt-2025.xsd",
"https://xbrl.fasb.org/srt/2025/elts/srt-roles-2025.xsd",
"https://xbrl.fasb.org/srt/2025/elts/srt-types-2025.xsd",
"https://xbrl.fasb.org/us-gaap/2025/elts/us-gaap-2025.xsd",
"https://xbrl.fasb.org/us-gaap/2025/elts/us-roles-2025.xsd",
"https://xbrl.fasb.org/us-gaap/2025/elts/us-types-2025.xsd",
"https://xbrl.sec.gov/country/2025/country-2025.xsd",
"https://xbrl.sec.gov/dei/2025/dei-2025.xsd",
"https://xbrl.sec.gov/stpr/2025/stpr-2025.xsd"
]
}
},
"keyStandard": 22,
"keyCustom": 0,
"axisStandard": 1,
"axisCustom": 0,
"memberStandard": 1,
"memberCustom": 2,
"hidden": {
"total": 2,
"http://xbrl.sec.gov/dei/2025": 2
},
"contextCount": 4,
"entityCount": 1,
"segmentCount": 3,
"elementCount": 30,
"unitCount": 0,
"baseTaxonomies": {
"http://xbrl.sec.gov/dei/2025": 28
},
"report": {
"R1": {
"role": "http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation",
"longName": "75000 - Document - Document and Entity Information",
"shortName": "Document and Entity Information",
"isDefault": "true",
"groupType": "document",
"subGroupType": "",
"menuCat": "Cover",
"order": "1",
"firstAnchor": {
"contextRef": "C_d2a3139c-070f-469c-a18b-a84f5dda19b1",
"name": "dei:DocumentType",
"unitRef": null,
"xsiNil": "false",
"lang": "en-US",
"decimals": null,
"ancestors": [
"span",
"p",
"div",
"body",
"html"
],
"reportCount": 1,
"baseRef": "msft-20260729.htm",
"first": true,
"unique": true
},
"uniqueAnchor": {
"contextRef": "C_d2a3139c-070f-469c-a18b-a84f5dda19b1",
"name": "dei:DocumentType",
"unitRef": null,
"xsiNil": "false",
"lang": "en-US",
"decimals": null,
"ancestors": [
"span",
"p",
"div",
"body",
"html"
],
"reportCount": 1,
"baseRef": "msft-20260729.htm",
"first": true,
"unique": true
}
}
},
"tag": {
"dei_AmendmentFlag": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "AmendmentFlag",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Amendment Flag",
"label": "Amendment Flag",
"documentation": "Boolean flag that is true when the XBRL content amends previously-filed or accepted submission."
}
}
},
"auth_ref": []
},
"dei_CityAreaCode": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "CityAreaCode",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "City Area Code",
"label": "City Area Code",
"documentation": "Area code of city"
}
}
},
"auth_ref": []
},
"us-gaap_ClassOfStockDomain": {
"xbrltype": "domainItemType",
"nsuri": "http://fasb.org/us-gaap/2025",
"localname": "ClassOfStockDomain",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Class of Stock",
"label": "Class of Stock [Domain]"
}
}
},
"auth_ref": []
},
"us-gaap_CommonStockMember": {
"xbrltype": "domainItemType",
"nsuri": "http://fasb.org/us-gaap/2025",
"localname": "CommonStockMember",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Common Stock [Member]",
"label": "Common Stock [Member]"
}
}
},
"auth_ref": []
},
"dei_CoverAbstract": {
"xbrltype": "stringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "CoverAbstract",
"lang": {
"en-us": {
"role": {
"terseLabel": "Cover [Abstract]",
"label": "Cover [Abstract]",
"documentation": "Cover page."
}
}
},
"auth_ref": []
},
"dei_DocumentPeriodEndDate": {
"xbrltype": "dateItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "DocumentPeriodEndDate",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Document Period End Date",
"label": "Document Period End Date",
"documentation": "For the EDGAR submission types of Form 8-K: the date of the report, the date of the earliest event reported; for the EDGAR submission types of Form N-1A: the filing date; for all other submission types: the end of the reporting or transition period. The format of the date is YYYY-MM-DD."
}
}
},
"auth_ref": []
},
"dei_DocumentType": {
"xbrltype": "submissionTypeItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "DocumentType",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Document Type",
"label": "Document Type",
"documentation": "The type of document being provided (such as 10-K, 10-Q, 485BPOS, etc). The document type is limited to the same value as the supporting SEC submission type, or the word 'Other'."
}
}
},
"auth_ref": []
},
"dei_EntitiesTable": {
"xbrltype": "stringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntitiesTable",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entities [Table]",
"label": "Entities [Table]",
"documentation": "Container to assemble all relevant information about each entity associated with the document instance"
}
}
},
"auth_ref": []
},
"dei_EntityAddressAddressLine1": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityAddressAddressLine1",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Address, Address Line One",
"label": "Entity Address, Address Line One",
"documentation": "Address Line 1 such as Attn, Building Name, Street Name"
}
}
},
"auth_ref": []
},
"dei_EntityAddressCityOrTown": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityAddressCityOrTown",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Address, City or Town",
"label": "Entity Address, City or Town",
"documentation": "Name of the City or Town"
}
}
},
"auth_ref": []
},
"dei_EntityAddressPostalZipCode": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityAddressPostalZipCode",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Address, Postal Zip Code",
"label": "Entity Address, Postal Zip Code",
"documentation": "Code for the postal or zip code"
}
}
},
"auth_ref": []
},
"dei_EntityAddressStateOrProvince": {
"xbrltype": "stateOrProvinceItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityAddressStateOrProvince",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Address, State or Province",
"label": "Entity Address, State or Province",
"documentation": "Name of the state or province."
}
}
},
"auth_ref": []
},
"dei_EntityCentralIndexKey": {
"xbrltype": "centralIndexKeyItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityCentralIndexKey",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Central Index Key",
"label": "Entity Central Index Key",
"documentation": "A unique 10-digit SEC-issued value to identify entities that have filed disclosures with the SEC. It is commonly abbreviated as CIK."
}
}
},
"auth_ref": [
"r1"
]
},
"dei_EntityEmergingGrowthCompany": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityEmergingGrowthCompany",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Emerging Growth Company",
"label": "Entity Emerging Growth Company",
"documentation": "Indicate if registrant meets the emerging growth company criteria."
}
}
},
"auth_ref": [
"r1"
]
},
"dei_EntityFileNumber": {
"xbrltype": "fileNumberItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityFileNumber",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity File Number",
"label": "Securities Act File Number",
"documentation": "Commission file number. The field allows up to 17 characters. The prefix may contain 1-3 digits, the sequence number may contain 1-8 digits, the optional suffix may contain 1-4 characters, and the fields are separated with a hyphen."
}
}
},
"auth_ref": []
},
"dei_EntityIncorporationStateCountryCode": {
"xbrltype": "edgarStateCountryItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityIncorporationStateCountryCode",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Incorporation, State or Country Code",
"label": "Entity Incorporation, State or Country Code",
"documentation": "Two-character EDGAR code representing the state or country of incorporation."
}
}
},
"auth_ref": []
},
"dei_EntityInformationLineItems": {
"xbrltype": "stringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityInformationLineItems",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Information [Line Items]",
"label": "Entity Information [Line Items]",
"documentation": "Line items represent financial concepts included in a table. These concepts are used to disclose reportable information associated with domain members defined in one or many axes to the table."
}
}
},
"auth_ref": []
},
"dei_EntityRegistrantName": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityRegistrantName",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Registrant Name",
"label": "Entity Registrant Name",
"documentation": "The exact name of the entity filing the report as specified in its charter, which is required by forms filed with the SEC."
}
}
},
"auth_ref": [
"r1"
]
},
"dei_EntityTaxIdentificationNumber": {
"xbrltype": "employerIdItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "EntityTaxIdentificationNumber",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Entity Tax Identification Number",
"label": "Entity Tax Identification Number",
"documentation": "The Tax Identification Number (TIN), also known as an Employer Identification Number (EIN), is a unique 9-digit value assigned by the IRS."
}
}
},
"auth_ref": [
"r1"
]
},
"dei_LocalPhoneNumber": {
"xbrltype": "normalizedStringItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "LocalPhoneNumber",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Local Phone Number",
"label": "Local Phone Number",
"documentation": "Local phone number for entity."
}
}
},
"auth_ref": []
},
"msft_NotesThreePointOneTwoFivePercentDueDecemberSixTwentyTwentyEightMember": {
"xbrltype": "domainItemType",
"nsuri": "http://www.microsoft.com/20260729",
"localname": "NotesThreePointOneTwoFivePercentDueDecemberSixTwentyTwentyEightMember",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "3.125% Notes Due 2028 [Member]",
"label": "Notes Three Point One Two Five Percent Due December Six Twenty Twenty Eight [Member]",
"documentation": "Notes Three Point One Two Five Percent Due December Six Twenty Twenty Eight [Member]"
}
}
},
"auth_ref": []
},
"msft_NotesTwoPointSixTwoFivePercentDueMayTwoTwentyThirtyThreeMember": {
"xbrltype": "domainItemType",
"nsuri": "http://www.microsoft.com/20260729",
"localname": "NotesTwoPointSixTwoFivePercentDueMayTwoTwentyThirtyThreeMember",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "2.625% Notes Due 2033 [Member]",
"label": "Notes Two Point Six Two Five Percent Due May Two Twenty Thirty Three [Member]",
"documentation": "Notes Two Point Six Two Five Percent Due May Two Twenty Thirty Three [Member]"
}
}
},
"auth_ref": []
},
"dei_PreCommencementIssuerTenderOffer": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "PreCommencementIssuerTenderOffer",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Pre-commencement Issuer Tender Offer",
"label": "Pre-commencement Issuer Tender Offer",
"documentation": "Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as pre-commencement communications pursuant to Rule 13e-4(c) under the Exchange Act."
}
}
},
"auth_ref": [
"r3"
]
},
"dei_PreCommencementTenderOffer": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "PreCommencementTenderOffer",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Pre-commencement Tender Offer",
"label": "Pre-commencement Tender Offer",
"documentation": "Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as pre-commencement communications pursuant to Rule 14d-2(b) under the Exchange Act."
}
}
},
"auth_ref": [
"r5"
]
},
"dei_Security12bTitle": {
"xbrltype": "securityTitleItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "Security12bTitle",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Title of 12(b) Security",
"label": "Title of 12(b) Security",
"documentation": "Title of a 12(b) registered security."
}
}
},
"auth_ref": [
"r0"
]
},
"dei_SecurityExchangeName": {
"xbrltype": "edgarExchangeCodeItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "SecurityExchangeName",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Security Exchange Name",
"label": "Security Exchange Name",
"documentation": "Name of the Exchange on which a security is registered."
}
}
},
"auth_ref": [
"r2"
]
},
"dei_SolicitingMaterial": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "SolicitingMaterial",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Soliciting Material",
"label": "Soliciting Material",
"documentation": "Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as soliciting material pursuant to Rule 14a-12 under the Exchange Act."
}
}
},
"auth_ref": [
"r4"
]
},
"us-gaap_StatementClassOfStockAxis": {
"xbrltype": "stringItemType",
"nsuri": "http://fasb.org/us-gaap/2025",
"localname": "StatementClassOfStockAxis",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Class of Stock",
"label": "Class of Stock [Axis]"
}
}
},
"auth_ref": []
},
"dei_TradingSymbol": {
"xbrltype": "tradingSymbolItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "TradingSymbol",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Trading Symbol",
"label": "Trading Symbol",
"documentation": "Trading symbol of an instrument as listed on an exchange."
}
}
},
"auth_ref": []
},
"dei_WrittenCommunications": {
"xbrltype": "booleanItemType",
"nsuri": "http://xbrl.sec.gov/dei/2025",
"localname": "WrittenCommunications",
"presentation": [
"http://www.microsoft.com/20260729/taxonomy/role/Role_DocumentDocumentAndEntityInformation"
],
"lang": {
"en-us": {
"role": {
"terseLabel": "Written Communications",
"label": "Written Communications",
"documentation": "Boolean flag that is true when the Form 8-K filing is intended to satisfy the filing obligation of the registrant as written communications pursuant to Rule 425 under the Securities Act."
}
}
},
"auth_ref": [
"r6"
]
}
}
}
},
"std_ref": {
"r0": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "12",
"Subsection": "b"
},
"r1": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "12",
"Subsection": "b-2"
},
"r2": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "12",
"Subsection": "d1-1"
},
"r3": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "13e",
"Subsection": "4c"
},
"r4": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "14a",
"Subsection": "12"
},
"r5": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Exchange Act",
"Number": "240",
"Section": "14d",
"Subsection": "2b"
},
"r6": {
"role": "http://www.xbrl.org/2003/role/presentationRef",
"Publisher": "SEC",
"Name": "Securities Act",
"Number": "230",
"Section": "425"
}
}
}
ZIP
12
0001193125-26-323632-xbrl.zip
IDEA: XBRL DOCUMENT
begin 644 0001193125-26-323632-xbrl.zip
M4$L#!!0    ( )F@_5PC;[)-8!<  ''W   1    ;7-F="TR,#(V,#GJ;.HD26WX&J.0P%/717 2?0VWWV2QW9NB:>X>'/__CTP\[?*"6?#PZ/R!%D\^B!-+BC#N4N93[9X;9XG;+M!J&Z[K_PUB+L8EJ66^0Q^>=DFR&
M'XBJA7VG*20)#,A!G(HTC$5"3D>];B&888/L)@EIJVH%:4,!^07(1M5HIT1\
M($[2XN/&!.B79B/+SYN&[_O-*U5FHRK4N@KR1,;CLNI1E^2,.LR^WQ2(K,XH9['U:K$J,*_8*>"]$;5XA$$>C"
MPP]3K>/ J!I8\<"XL8Y%F4%-XQK#)468I^J-QG"-X&:9B[2(LKRKV43AWZ;,
MFVBG6T3E5"/=.,RS(HM*S6J*-YC+_8EN9X-Z7Y^<4\:IX8Q15.9WXM-OXM>-
M3S^0G0X(B7_)3AF7"7SRZ&\[S>JG>MF%4F@I0>&O?GSQ<6,O2TN4'?0,\;5!
MPNKIXT8)5V53LUY3-=H-GI!*EU2U2XOX/T"%_'>_*%L&8S]M][(B5H-N
MY9 ()>ZV-S2T,KX8=2;CHI>(@:)Y]74GOFHIF""O?L920JI_7C,%B>7'C8-O
M-LZ#X3M(!8(Q:MFFI%[DV!2$$3@VEYXI$,6IZ*I>(&[MIXBNP1ZB(1?)H8+_
M-Q@,47-5MB%"I'V37)B&Z8EOE22_R 1YW-!
M2"IZ^[B!!-J*XBN0-!()RJY/^L\MJ)O3N,XA@APU&!2?=I0<:Q5:;" $1,NU
MEN+"CQL%4D2B9(A^U\D5@(J!Z(A-&E>%1$+3S4^VJ1^+K)_K)RVG6\-1:I0]
M=AZ&54'/[.@IENHYBB$G&FR8*13V#G^;GL>;E3^-7DVWWD.$97+TA%(T+Y6R
M_72M:T?UKK^-P91W%!U]&3V/.FE.H68VIICK.M+W&/61R*@%CHN_'$DMU_4<
MTS""2'C/C:GA@.%<$6WU*+&SJUX2AW'Y%;H!=B%C_*HMI(VA[&^=ECAJ56L*R
MD-!#APH?0AIQTY&<.V 98@VG3XF!UE%60G%VF9UD<5J>QE?X\P"5P D@WZ?E
MYSY\%0-\=W:)3X.S3IRK_W. -SG1)F>!&Z'\=YA$B18P03TF!;5,-)? #TT9
MK/E$JZG34WVE9@U:%9I__B,^0;-[NP9[?8&Y4+LAS!
MI&760P!:?7F.^2I,E>U!:D0>AG+LH-63SG"#_;U]Q\-AVWO-%67B-#>
M! KN'J(Y_Q 5U4-^[9_^D1%B=/]O=_;AV>'^Z=D]^@SV?]S[U^[1[_LD[WCKU\/3T\/CX_6
M&CU\0?3\L7OZK\.C7\Z.C[;(Y\9>@W!F6_Y+H626>'@L0C0D-ZGC9M^/1P29
M.>8A[ K.EHENKH9=R=L4GXV&[9D_W2,XGX:7H8 >/ANW!/2PO [?J3>F_#/SDA[_^2X??:NK923W]NGO^\B+LZ."1IT9VBU$<,D
MQVUBV)N?/[QKW!P?D+-_[9,).W=LX^[NG1'\;/BF]S8\=^ANR8V(A=RG'A.HA\TPI('P@8+I^")R
MN2=]=UFZ^T3'+?:K:,;TXH#$-[2+O714-2K%@ YP_!32U9JK7_O)@'!_2R]/
M/Z#V[U6UM5I=2;5ZW16?'>NY@XV$Y"$7 :-2&CZU7(/3@-L>#9V 2
MHFQ4K1RVX3PNU&)N>81?ELH==PSY\=/W=;1*3?:R'*657FI>A$O6P2#5%!#%
MQ;=^.@YRRV^E"))Y9^=%H@1Q+(GH%M KH"62XX=X&U7H^:OHB
M+N(@3E!XM$;%1Z6PF!S'OG7SW&IXEFK^2HU?@3(*[^.K;;U?8V8]8XXZEM]@
MS@OUA>-ZN-I.L\QOH>\2,4V#',3WEOZ?JA>SR>8V,]R"9KBMI>(TM=0R?-8R
M3[VX@+R,0Y$,V\%RXS(CIINH5HDG]6;CY9G[;M:9X:(^VC4S0]]T#4M2
MSW0L:G&+4\_W#,JD%T%D^Z$KY')M[0JB@X6*A_EGJV$5GYY"KL;YTO;_?%.,?MHWHTBWXY"
M9-;0!HY\& #U/.E3'R(#F'# ,F$YO'L0)X!]!Y"_*!\R=7S ]2S[I=AP<:O%
M;=C/2#"+Q!">'@VI^>]^_G-<;@J#"RI- ZC%1$@]"QAU3=_QP+5PW4OCBKJS,[<5$\
M.V>O!3:4?4LJG;I\1J^-RIK!7X'!#]NG9+_;2[*!.K;S[EE\VGXF1UEC-J>/
M#5;\H=885W=1^%TNP.HCZ^NW3EE']NO(_@M')X05<0@C1LU(^M2*9$1%P!TJ
M;$34EV"[ELL]UUC2S$$AJ(;-2+P1!F;2\P'4L5[K!4B=2AW:.\Y,\NXAU
M4J&U7'![S1E?;,*Y:T8&$QZUP31PPDU)A6\Q:KC2=T3H>8ZUI#VPPPD_R7!&
MD_^+>WI]]44CQ1ZS.75,WY\K4OP4PWO53CLLNB-S\X'3"[/;O_/T0NA:?F#2
MT%?;KDW7H+XA\=%T.9(.,SV5?&DQDE/Z81?MMF42V7)0:?&'E@U7"-@'CZT\
M:>)##T081D!-AZ%R,:5!/9N[U(EG%U"4V4-QHB5*7Y5_+HX&RSU:\^1S
MFAT(OY.R T3TT/+I8?422)!=D0"2[)+$D?YX@)82\>AO)(H3;)/$!8E5$Q(D
M*3-2Q-U^4HH4LGZ1#$@ARKB(!KKFL$(6X)BKN%-6-9F/SZF0/K:3$Y$.1M^B
M+,'.53UEC<4J1%^0S0* _ (IY"(AARG6[>ME.;+;X(T*W ^M=3C*H"&Y2<%O
M/6IE-8QY=O+[]F-.&]0AEJ4N?4PV__,?"*("L_AYJT#-$=V9Y,$!!HYM4Q\M
M+FJ!\M ])F@4<$\$=L1#8V%W[H\\+G'RU<)=/QW&L8M[LD@^WX+.WW]T#(=Y
MV\]@7RWJFZW*$M.+D^TS(WA(?$C"D]1'>OV\Z"LMAGJPW4?!BU;W4*,I578*
M81\KQCC8W; DFX9+]@[:A)NL@07?Q ),K&M(7%%@Y_G^2@_#&5,E_GWU-!H?PXBE26WUJAU0KM^1&,%$C#"1)\
MT$-3ASWY9O#A<>JM*ELKN%K!U0INU10<^*9O<<^C$GTV:K'0107'+,H-UW>%
M;7*31TM6<(=%T8>\5G.UFEMY-6<"M=15>8]1<\.R2U1SRU\:?6)&M(6/8MU6
M;)/YY[0:6YJFFZ(W76]!W6<_O$M\1A*L!N?SY-MB#6^>:@UWCEJFW> /]_92
MVADG0M'+QPU[8UXYMX1$03=8[V86TQ>R,><-2%TOD52; B '.27.L(1>Z3>T
MU3[<)( BK+4R>NX^%SQX,9[-YG.U(W*U1T 8:>Z:V_59,HS(_C]")4E(G*QS=CSTFHNU#C)Z: ;
M9$E-IC69KB29JML2M$0=A.Z6/5Y7KKA[?CB53F]5K+UJ6A\=W
MG=2K)L>:'&L_;[E4?WM:[LI%(L )7,NBEFV&U.*F2D/"0NK91F Q" /@M[9B
M,==UI.\QZCO"I18X+OYR)+5'W+?+?K*&[<;A->B(G%R+I ^D!TEA'Y+"F2<77FM7?#!\NF!6(^X8, ^E3
M\%Q.+61**3X:UD)Q6N;;8DVFP6FY[F&1R/'<:CE
MF3X54G J(IDT*=(N,&^*$I [$R-IO9
M,+C]$SG*2L2G1 .-,^Z]/R51VV:KHB8%UOHMD&V;]C
M$$_,,OSHH\ANY%F>;7CJ,+%!K="WJ.<@X_)(N(;/3$>8"Q]%KK*;CT;VBQ[8
M7C6N99]"?BPVGB;M'SRP_$QI=X?'+D?/*G\P*;(DEF2$B97CV^@>3MQ"_IO)
MUO&MW+H=9%I(("R1:=-,GZ;K%Z!+X8B'&7R5\([U"3N4W7$F%2WIOI*!ZOPR
MQJX5[Z2(8/R2PT5<8#T4!2(-5?XH$8;J)G-5N"A%*D4NBRIWK[SK*)^Y*<9'
M^29YO#&30U>&;)5"D?&%TB,[^'<$WW\HS@AC5,=U.UWTVT9
M%[U$#%KJJ^YJ&!-@#0>MD"'%C7K5I2C.S78OJ^:EE4,BROA"G?>][K\SCC ,
MZ3U.$Y3.%*<@'QXBGOZ 35:O>^(G3VP6U#?#YQJ
M0Q],4-!AU=$A7?47GU7>A!M=V+-;?.F,*D\EKOF3J#SBP/FJ9%(Q6,.*Q\Q6/PV%MD"BN/B60]%/RN);%GW+4)(/\R,/R7M4J*@DTS?^;2R_
MO\5I93W@^XWE7@XQK_HKH4MX@_'&JCO9*Y-69%FH;U=$I'3S\9B(4/U+S-&R;EWJL&ZNUG%*?NTG \+]+;60[FQ-7,FV=WV/-CI911^M
M(H$&$A0JYT$"Z"XCAE.TH928)S&B_]JX&G*U-LJJ*Q4*I&;R5Q^UO+XW09(!
MB)Q4QMRO_12(R2H0&F07[;C>^&*%Z1[17XKZ.+"BH\!1KE8'-4))?+]A*%M-
M>U0Y(.!EXYD-]%6;R\-4V[2YQ#F R@">=?7$/QO:]1Q=C[&ED3PA3)6?K+&X
MU\]SE;.GK;&ISA9=UXG3,.GK(W*3$["E=LHFB3;: T#'&WT!?=D&/OS]1X]S
M%#QQ E+_-K8U=:"AC284:-X=&]K>(YWJ+44"Z&IJ*MI4%8;=3!8>]O9A2_D!
MF0HA7*(K0(I^\&_LKR(:($DL*LNBZEJ@LU5!LZ6I=6I@\?B.>>P6O9D<(LA5
MCB-UPTBFW8Z1.Z/'HR]IT_F/1A 0F85]_48CY.[DZ\.0Q.1 ]3ANNB!;ZA 8
MH(N(Y2I8 ^4M:>91UYM J;"-)('@%CT(U9VZ4W C/L+.\.J3IW+.@K;L6,U?
M*_\9R=B%V/A46]&U%;W.5I/T&,VJ#]Z51?VW6GH[EB]930W4\.[7"/4:N'I^*::0EFK7<1IY_)KMWX8RP
MBU_7*#^,\;0^MV^]MSOC+62\.12//5\UGS7>\2QX)TS?VH^@>MI<0#B,K+>WY
MJ96.:G%OH=DYF0R5;!&I_=.I^,XHD(->X,Q SWANQ7IM$EU'R;=P.NU53-CP
MU@2>P:P:Q<^+XKT,\4-.Q#F00[7Q3(1J&95\%J4@!S$:IIO0#4"J$)\*:NKP
MI"JJA>:?_VQ_&0?35O7"BU=B7\=D8L-2M9_JKS[R=149>NQJRHR-6%*9
MCZ'HJ\U3$XMKPU4=107X0:T:83-2-:0MVV&!#N305VLCNCGDZDZ6
MX[#E"Z\TU.&7QX=?_(8_U[T*\]U?9'F/Z6X%\Q8N[GD8_%5,CS4_[O#^D/9N
M*6W%8P^+NG/K.2FOR_YUG'J-8@JODAOYZ^%>^_CT^.",[!VW3X[;NV>'QT>U
M>*G%2RU>:O&RN'C9;(_=Y >BCK6KLAK"9'SK'9_[UKMWB\![5:2Q]BKRC2VH
M?!8EM*;7?6L=^_9UK+$(.F^>-G9O'S=^5C6\G"!XLVB2W87/XKJWMC<^%8XO
MAWO[BX"QZ"5]KS<#7UYAV,]Q_/JI,/RZ E1W_.7+;NWAKHM-56O?-Z5]WYR'
MNYO$(9 O#?*K6BNLY4HM5VJY4LN596SW&QZ=)?^K!(S:LQRK8T?J^-)KVLS/
ML@-E)2>@$T-$=J_3'QU'$O_DJ^V?W&D&F1Q\^F&GV2F[R:?_
M!U!+ P04    " "9H/U<&:;S@&0.  "FU   $0   &US9G0M,C R-C W,CDN
M>'-D[5UM;]LX$OZ^OX+GXH MKK)LIVD;H^DBE[2'X-JF2%+O5KKXDLD0-GWGX/C.DWOZQ6F#P$U(/$?=T,!Z.!@"Z
M-G&0>W($\&Q,OH!#\
M?O/I.?CSG]3TX&
MP/)]BF:!#S\0NKB U/&IX3\N
MH1?+=36C>$CHGF_PQS_FE,1H;1V/U)G2#Q21Z*WJ#)1R9<.5#UT,S# V>
M#%)!N6=,>,F'KR^\N5](TS YHRN6^N%(YC8:FW]^^AA6!Y48(_>'7A^6_LCD
MCV>6!U7RP#/N+&L9O3&WO)E(+1]P,,<181#%E?:@/;PC/TWV():0/W1\'4&C
M8S-\N)X4Y0!FM=EG%2P"O$HI*.D8GYR=0$2%O"L(54@\]^.L?+6E
M6BA'3[VMK6TFQ+ZG[AC\3A8"?64M#&%3:Q>_O4*TZ_J*[:A(-B5^D:N\O@$^
M96JY+O%%3OR6NKE<(G=.PCOL'J\I4THPO&7@ ;_X>GU9H&LR?6M%7+)X-/D[
MYC7[\UV-1^K_F>N\=WWD/UZR'.E"0!D Q/JRXLD54 75@6QX0T*IU\4Z(!0&UJ2]-9,R$M(##SI7[CMQO:1LS')# C^R&_)EF23G1=O"=H"W
M?^\)5N9K\J8JKW@IJD8O&,:R%UQ/8%&;OWD-YT!>KI=U5)61ZYL.6I@RC6EA
MS/I>(>&>PGGQ/N/9VIN\;9P./-80L.R5*D#&KOE(2US#";
MKX[2I8D!8EU//E$VE$B!?FM!^8IA:P8Q[V]E:@XV9V(E=!%33"4=^?R%2$P\
M5[$4<-B"XRG;*&-BQY)B/BL@FF(N-D%XQGY\5QS8A++YAF#AA@U@\)P$KD\?
MSXD#E7P!^'10]"US1P72YA5QJ"'E;=,\=A3M]-I;=5=
MM=U1G;/+*WI+'MQ-Y*ZE; CH#;0#RG)]O[+O+?<.C;S6(]N^QI<\>=-\H785-F:X<*RS*)+U/$LN;*A:EE
MS06TQ7Q0+'G$VD;\?<_=;IM62V4%-]K$K^$=XDW%]3.&)&VRIIHZ'[(IM#)6
M'K''3;4I@I'-FK)[]XEUT119NMJK2=1HH:Z9:_A"X9*-);J1/"=QHW!OK=6E
MPUH!FLOIQ(8Q)RM]0Z"YHPE_N2=N]MB82M+>2GAM G$1,V@GE\+IA(U6@O<+
M2.]8B_D7)0_^/9M=+BTW>T6G3ZT#S-_D+FYVQ0-#H&M\O8E;$]F*@ 0T9TF6
M:\/[CF=1%U#$RLGZ P]^Y%D,WD6NM#7Y+X#( 1 *9"Z 9R-=5 +;'FB).Z-@
M!6;,,D4\&;Z:'/\=" " 900FHZ,C\"T4_+\#4EJ6>*@H$PM$MH#E*W[QG(',
M6O# ,A-=I/-OPSG
M3+9AKPD'H700B@="_C[IAKNA5K;'HX+)@!3[ H2" 9/YE6F 6P"?ZZRJLFG("\ %@RNWN;911J&,IM&D+NN>NC+E$<4#
MM]J%7V0-$25@G?%Z4R>J%&]V3D[S*AL.E\GK&Y>Z!*AG-I2DM=/$ 94I#R0-*(. 2
MNZX!;@N\-M2A#/]2((A+[+P*N"WTVC".2F:NH43 1(I-FYU7(CF;;0C_QH"4
M4BMK+@N0>;@\W1L5L X]^,9%-;"T?@JXJ6!8YL) **W+R.,# ((>W\7=%/A8
M/%$Y0Q(3Q.J)%%5K72D%&C>/-Q8?5;IB\QKR38CJ+FC[TG6V&0ON[0G1W^$S@.F"R]\W\O2,L* :U@\ODDL/:%
M?!4:X+; KX>YEII_"A,6$U2[/[D,8MPTV'2P;BD+6R0-*''=!H];P9T=>EQ)
M/&4D%GSC@H&0W$ ?685"N".Z9$195U ^3#*(BV[,!E&14KA]?9(AYF7*1<@"
M0M@>(,=-@\X.D=\?ZV=Y[!EFSU!8 _V1-N2_@MY(R06A8" E[XE"N")=SFA\
M8X=%;05#GG>3@T0=CV,3UX9+WPA!R=?GE"R*GXBB0)#MMB9D[?RH6ZT*CUWA
M*E<5F-X6':GPZV1YIF.SVX1:](@6A;Y0/'.;"F4'\NH;5F;(;UM*;#S A>//
M#Y+M#/^Z8UVT]*>B2MM407?8BT*="L=LG^N,(V#B/.OB&=N'GG\PC+:FZ(+_
M.M2!%N\Z.]MII@^1T19$(J*L3?AY1\LH[)E16&T"SSUP1B'/CE_J0B>I/88F
MV5NFXW[:'ETW'D>S/LKFQ\VTWW#3A]3$6VPB[*1-P-JC:Q3:=,A&Z]PF#[2)
M$1L+?.A"!Y@\YB;9^<7B!MH$K#W\1J%-.]X[L+:MZ*R!^D\3RVV@]ISM6)NJ&D[Z[5IIUYVD[4N/4.L/:K1=X9/$GK5H;3J'TE-IS,
M$]V(6$+U5O_V*DWN:3[S:9)O!UT\57[-@
MLT;R(WG>>/*K$ED6]'H.59>GE2=!Q/T!;1Q:WNR)A+_0R9A[<\):XV3AR:R?C'LC7#3I^N/2>?1QDCS_ ],N?W+\C7QW^O$H!
MNUBQ"-%?^J-JN4$_*?Y:^NY3Z2^4K!L2*['9+BW*Y!GV/<+.%K[> D8Z0EG?
M>#H8#<"2(L(;U^E@,@"!QV"1)5> #V),(=9[4NA\#%DH'*3=$7(*>7/BIK:#
M)F9++T7:4G;0[!2+G\BH4Y*9\6$SLU6#2A@P#YJA8BVK2I/J+T'G5A%O.NXE
M2Y/A@7=96\0M),W8BJ*#)&CK=KF[9?V@>=PM0";76"_Y.NKYTO@&)#DO>W(V
M>2?HJB?:^N=CXJ??FZ=[_U4//73[")N5\56/]76>7H5
M._T4.^5L5M3T,^LLE[=BJ)]2;_"X*Z+Z277*TZ_LC_VL.C/>0%%TN%/KW*WJ
M">>FLC&>-.$G5<3KK[.Y
M:G?0WUG3MP*L#:SZ=7?8]9O5^LUJ_6:U?K-:OUFMWZS6;U;K-ZOUF]7ZS6K]
M9K5^LUJ_6:W?K-9O5MN3S6I/1DVM!?@IDI\#=/RIC8D'G=.!3P/X=).X/ESY
M[['H-4X''KSC%UD&Y,@PR]9)IH,6D?W8PN7/OGLR .:8C7FOSGJK>
MX&ZQ.A@ZZF;EV& 'KX.)E]UD8MV@7H?:Q]U4.]-87P<'K[K)@=;V7X?^KSNM
M_[H[H0[MWW1:^Y2/H@X*3CI-0<+G4]TSL%:]&]H_.Z#&]C+1:@SDWL$O[+6I3NW,PNPS]:3'FY#R2^ST,]
M5I\+8G]FE@?#VV_-E>=,K>42,6S\EKSANB3<1R+N\5LP](T"Y%1DI'-9:SX=
ME)42EJGC4X-?>=.P(#BUH1/%"V8>8S3@NK!6%"Q/![P0T12Q)&'AH^E2&.%O
M0U$!E=\Q[_4$L#
M!!0    ( )F@_5QLG:F\0F,  '#!#0 /    ;7-F="UE>#DY7S$N:'1M[7UK
M>]M&DN[W_15]O/:)O:?)X$J05&:>XW&<'<\9VUG;L]GY"!%-$1,08'#1);_^
M5#< BI(HQX) J@&\\?-$$HEKU5M579>N^N%_C4;LQY_>?6"O%WEX+GX,LT64
M9$4JV,O/[U^QOWYY_W?V8[(HUB+.V8BM\GPS__[[BXN+<; ,XRR)BCQ,XFR\
M2-;?L]'HSS_("[Y)A2\_9C_ZN6!SR[ F(\,;6;,OICVWW+GMC%W/LO^/8KG+UR3
M/"UCGT0FTG,1C.4U_^V'5;Z._OQO[(>5\ /ZR7[(PSP2?W[[/Z/9;&S^\'WY
M)QWP?77$#Z=)<,6R_"H2?WJV\8,@C,_FT\WER=I/S\)X[A=Y\K_"]29)A"G/X:YJ-<7.:C+/Q=C/S@7T66STW#>'&R2;)0/O$\%9$O
MJ7SR3#U.$)[7-ZLO99VLPWBT$O)]YL9X$L9[S_[A>SIW>XU%Y&?9GYZM?3IU
MD<0YL4K]I+]%^NSV+=S]5]S4QRWI3/4.]/";O'KU49YLZ#W5=TM_'497\R_A
M6F3L@[A@GY*U']<'GB9YGJSI6$4+/PK/Z#[R=>1-Y/GU?19)E*3S?S?4?R<7
MJS 7HVSC+\1\DXK11>IO3FX]RN[=7Z>$A?*37T4:2T;%22P4^2["(%_-EV%>
M4X-N_?9R%9Z&.2LY+\\C(FZ^Z;5-Z]:]'_#FD5C>]^(3]=]77ORB1,%I$@6[
ME+ ?28GWX2)-LF29LS=14@3,CP/V^AW[G*> =^2;H9LSP)_"L"89P4\4($+%\)MDRB*+F@2[&TQ!U]
MDJIO?JOP*$B5!?22L6"V4;XD9W[&R QM_%1>)E''+Y*4+K%)8JG*V4:D81*P
M9,E(8^9L2<:.#,J5\-/Y+HIV="K18CV*PBP?B4A(&ZCHL=E1JQ5<)#3F]MBV
M[1#-S9CJN:4SLF??BY"))@]$IK09^G?\JQ(8>
M,]I2)XSE^XT4D;Y"E&=_5N"UK).:13MF\^:UVGWU!TNB.!=Q(=@%P?#YS!@;
M[#2,(KD*DAHVC!=$AHR0:4Y?L)?%AIG>"_J4$!IGL*V@ZM*R\'YH '\#7"O@^B/P&[&QW/+T'
M=K;Y@LD/V7^^?OTS(U:'Y-O)0^H3[7M.M*SJ1'J2T?7)P# PW J&?PRC(B><
MT0)1'IS)!23+5K3 K%3I>&K>QK+U-2P[8\^YC6$;& :&#ZB':UC5KI2X7$1%
M()1[%)*WM"!'*$W6!,ESD>422YE2K(;]L'78T=\W;(_)E6_RDYD\1ZDNR<2"OEI2(P$2\I4O(WZQAF
MS8N*I+57>[$2\0T75IV5I!<^X35*DE_E6NZL" .ZC&";-#D/I1M,A'^]2<-H
MZ^_SZ@;ETH]TRZF(B5FY]'R?&V/+DZ<$]RJW,?NR$IF02DHAQ2-6SDK5['^2I--N%":3D"@TA'^/_C-DODM)EC%82J0HO9!7;.-U*RHD0
M0?7$BUP%M#/FR^B%?'CE['&6W%ICE\K^*[3M2+BJ':DHXTZ+DU^((\0[/SB7
M D#$4E&>E(X+B3!)7,5JR)SER2@I8YD\A5]FM&+TED+
MGTXK4OI?\BL=0_0G))T6&>DJQ2 E8;Q\@N"$97X8L,]^?N6S#WX@HLCG$A8$
M$+]<5BY6H5@2L\6BD#%Q":]P(9]NR;8QJSK MCCYL@HS%3GB[/7O,EU2(8+1
MPV[(1!/SGYO&=0R@#F MPS3+61[62+D.A]D35Z9 PBC)Z6+^8B4EFUZ9V09;
M5U?9R)?(A$\O1L>0.5KD-36)Z$O2!E((:A)EBNBDOA>5(B@R*6T;*97RG#"5
M@=^<)">CQULKA(]K@@T5IP0-XK[4OSX]"T'T;*N>B78R.4;0*/**F=L (F>K
M\&P5R1@OG4HZZ7:8O<:'5,'N[-JEX:S8,,M[H:XRD@P?J>O=!.[K]17[:Y($
M? >@YZ$R B*3;,]W,'QM9_9B^+"<58=KQ=PO-R+*N7\:B4KU7\>5_W AI,B;
M"KKJ(HSH]??;\U3(W&"Y5O(7"UIF*JMT$>8K=D8V.%6&B[X1&WF4/(2,G@I-
MDXI;A!MYZ9=R=?5*HFWK$MRYTYB]#@*U]J+/PG@KOO3]&2T6Y!7E$VXO$%RO
MU4AO;5<.:KU6IE#/TN2"GK)[PCF=4].25>D>C)YY&7)OTD#Q_1*IZ$O3RDO LI];'QHCZ>WBGR-YF8
M9X+(1M2JI4&E/,OS5+)7/D!:W_T\S$(2_S"_FM<7J(^BPX+ZL/*&L[$[F\H;
M7DK*R(>K<[STD]D/'&;/S,Y\M]T+OV6WI&ZJJI"1CM._<6OI/"*.!A56FFI_MN-#*C_
MC^0'^W7571MW_=AT43HZ_M,ST]D&9*IZDK*28FR8LK2C^DBI(8,^(.N?AZ1$
MJ^N6)G5[6+UVH@,K]5-_,G8WI&:3B%8*=4%%?5):E9*H&^ZO\YC(TULI]&@U
M0=[8W*="L/?T]RIC;V_DB7=7/MI@Y1#P> #SS0.R_GYF-UZGFQ/C9"\;;\J=
M/2BQ6Q!U1/K4@BSYLCL*&74L"$*$(4G$047HJ"=*%A=$ 4M!*$A)WX6
MJ;RO?R;8FY4?TX]_?O_/3@O"8=D!48 H',4!.;3#T9#O>RR%MO[IHR3RY7,9
M*JW2.!E7R44BT74]B;^6D>#LE3;*\AO9=BU;!V7JQRH38:" V
M,$$P08/F#DR0/CR#"7IR%AQ8J4FA #NT8<>;>KOHFVJ[*'BCKX61>^"P*-!9
MG.K-+&")=BQAWZ;JOA8]][2*GJ_#((C$0*/GK:I4M=/F$")[2!9]560]/42V
M+2X]MUWN30Y2#31T%C7ER$MG:AS$N1TZ0]J4&6NJC\Q\<_SA*[:G/19I44@$
M(7ER(;$\;MDV6*2/83&YZQVDV''H#&E/9J9\:DRU81$,RU-SH$="TI AMOD"
MW  W^LV-U@S(2XL;K@OO41^)L2Q(C/[<>'AL6KCR'V+3G8Q-U^T"W^YV??HL
MR[LAJQI;-]G%$0S21ID^?TFOZV&QH;?(>(XV#$(\X:DY !'9D\T93Q 5UC)@,_A=>HC\!8-@1&?VYL0]3T
MB^QX^TTMH2=/V.N[#!D_AA3_<7=+QL/[03^ZP?'CWX,-?/3E7^I>_W^M.Z]G
MAR6(?JW-[VLRKX8-[7:9OSUTR'M1CA]8).NU2*O.XG* <%CV]E8-Q67K\N24
M7K5L+7Y]^M1Y(;N"/Y]XVY%>#^TJ_R2)GG8'/9(N^#E-@D(.S@[S*T7/+2;I
MFP7]I+V*G!Q0XGNP'/RHIS-Y-?] NIUPB8-Z3[%E..>-8#NC<.^.8[4.F^C_Y(KM$^'T4QH&XG%LG
MBFQ!F):CYN3@C&(=WT3C;:=P[))_)U^IJKDQQA/Z8"\_1!R<;)),2>!<#3X)
MS\7NJ(&M=WEYCW_8[@IG5_",FT-%C&\/!9KS6_O4MW/U7A"6!)7FP
M)?E[&/\J@G?QOA6+55H-T[C':F Y Q"V,]CY*J83%YE:S>P!HET!\;[ERR!'
MW.[$/=[19^3'GXFXCCR548[[(TYV)=MRUOM>DL+_A_0?"#%3BWR=$LI]%FJF)DV^2]:90'9#[@.Q)1V)
M?9!$
M,W_Q6Q&6(1[":J8J'79 J9;N,SA#^P+BJ-L;5=!N5).=EEE40!
M+9OJ2=DRL2Y30$0E.;8]R$J5H&; I&)3$,M\F37>'EZDM#JJ)] GR]TIVTQ.
M7#SP.'?=BT!^*LGQSYH<[%,Y(+TC5&F]#"1)-V/"7N#+>H0X*>(%(?/FXKH>
M5E_G,'<1)6[,RU44Y8R6^&5R4U[J*\/@"9VW!\%CU0X[UI(36D:8;',\O2?$
M9$ZKJ-T$X6- \I"0_$B@\%7X(U2M:*LHB.ONV/];!7=FA4"D_9*K?=E5H= NX5=S>NB\G5UZ@'I]27@1@!IC;R=-5'57$
M;D>5TEDJP>V-9^Z>3-.W@OJ^9!1 #5 ?3D/7L*H=L3(<([YMXXF<'4NO$LJ(
M0Q4DV%[P1[$,RR)2EI5E]7^IH?O]%&Z0];GQHLP
MHM=/BI0\W-B/JUT3)0^WY;ITGK\@]SA0VR=4;DOQAASGK3ZY<_J8O0X"Q3CZ
M+(S5[@O%OE2<^:GRL>5MMQ<(KAD=DE),$QE,"DIFT[6BB)VER07=NO3;PXPT
M'%.E6^*K'GP%J-M>_&Z,2>T5*TFY1Z^I$K:J5%+R5;+(.%&'CTC^DJ(ZI.26
M:1ACXT5]/&$C\C>9F&="%E+G6Y56%OJI\Y[=::=V'F8AK6["_&I>7V!?3[3R
MAK.Q.YN^V"WKK(O?JKK.O;L4RW.GXXG9M7/-L>DTOJWC#NAUO3&9I(Z=.QE/
MW,/?]QCCZ>]:C>O'IHO2T?&?GIG.=BFEPS2F(70T_'(AHG/!WM,'JXR]O1$<
M?G#'RV. Y1#X> #WS3XU?-D*GCTHN;MN O"4DB"O5GY,?WXY_?_[+0@')8=$ 6(PE$<
MD$,[' -HN?\HB7SY7 8JUV5*,Y,!\84@$EWGAOPU,3C/#M(-[I!LZ\)4Y[96
M=:\S]JF.F;^406UP2Y]N<1A:WS59>EUWIGE9)XGTD:=O;J;\E#SK4#]EB U,
M4'>X!1.D,W=@@O3A&4S0D[/@P$I-"@78H0T[WM2%GV^JPD_P1E\+(PO;L2C0
M69SJ.E2P1#N6L&]3=0\?6/M4T7,,K&U+I:J]0IC4H:_ADUNXN.?,P"-MU.KS
MEPZ?36R,&]):;*PI]S!34.=B(DC)TTN)8?*I;8%'^A@7FT\L PS16FA<[KCZ
M" U,RU-SH$=2TG1 JHEYCQIQPP W=+8@+Z?H
MA2O_(4+=R0AUW0#H[6X#H,^RR!NRJK%U4WV9P"%MM.GSE\9XXF&UH;G,6%-M
M.(2(PE-S #*R+Q,ZGCC@D#YVQ1@C+ZVWQ#ACT]:&0[ J3\V!'LE(T\@HXCPZ
M<0-Q:JWMQTMS;$[@..HC, A3:\6->Y*>VS U_2*;WWY3O^7)$\X@*L/&CR'%
M?]S=G/'P9LLU,9_P/1C;Y:C&LZ,.-%'K+_7LU8]%'B7)KQVA1MN3M"["**H[
M:TO\7OAI,)+TH&NPLR(L^WN7TP/BJMEZ-B">AR71+R<+Q#*
MSN_UEW21I9#[,@0CG1RIGN,7XG3A9_F- 6^J=SOIE=W>]K^/PC@0EW/K1'7#
M#\*T?!S9#[M8QS>'#-Q6\&.7=+6D1I5#,\83^F!OFWT1!R>;I!P2.%?-Q,-S
ML=M!>&LI+N_1];>Q\CC/;;?ON'&S5[CQ[6Y=^6#F+=Q\]X9N=)J&W_',C[-1
M)M)P^2BGKU/4>,QPAS_T?FL$K[;IV^IAJSD/:II#V>W]YA>$O_+CC7\FRE3N
MR%^2E,W]Z,*_RLJ\[7[)N(/PNT!^=DNZJKD>:Y].K7MCRY]R],+U4(_Z%N[^
M*VJL, ]D/OYKJ_G^NIW=S=G/:1(49/D_B4B.8*DFLKPA-9.L948W3])09(^Q
M_@=ZG:XL!MIYV[?D%5QMIXU>&\- 1 3H-&.K(@Y2$61RUN.FY"GQLIYH7')5
MQ"N_LG/9F'U9B4R.-BWYSF1[MB"EB\7L]$H-EU#7RNC]PR7Y([$KY533%)B"!R>3Z57*A$C%V2HR@%Y+JH@O,>/U[<5U ]'0DYAT@U;4-L">N#B23
M4K-.")45!/4GX4[JFI927IR?FP$>'_U+ZU^Q'06OZ:%@3PS_[^97/
M/OBTL(M\SA8K/TSIH95T+5:A6#)Q20LFZ<;0\HSP*U+.7J]I49\D =_Y4J[[
MR R(3$ZSSW?.OYYQ=GU^) _^6U+=4AXE1Z45L1JENSWL+_0N,7'EIT1P6O]M
MBOR*G0ERNNA:\NA,E/$1DMV-%%\AUW8I,3&M%G=_2V*?5@TQ,8/XFL3\]E/2
M@K-<2R9I.16M[".L0CZKA"#A?RT@PV@]8LUM@VW&ZS'[V5_(A2O+B?WLI;O]
M_"T=29Q0G[^J)K+3FC4(,[+U&;V7 IU\E'(:VWKCQU=J@J$Y.U%UKFH*G'R
M.GI:K\O5RXM4>J)W(E,[P^/4VIMHDV72\5?='F1P=O.EW\>X42XGE"8G.]8#L,A)P_XAAD=8I*SE<\TJ=>D9:-_OJ?%9Z
MK<6JFNQ9#02-M\.'Y9_?_@0DE<^=J5'WNE>'/S?&AL?E]3#.
M):V(\U5M*$IK^%RU*KE]B.M /@^U:3GUU*G*Y1E*+$MGQ+ BKX;D[*ZKQKBLFHE"6693MO.[TCRS4IT8!EQ6F6ASG)LI0D+I=$6:'F$Y-8)5Q!
M8WN39-?1V*4QW9WH=?\\YD,*H^Z.[U=[ ?;>];T6_0JA*OM>$F11$>3&#&Z2
MYKH.P"=MY*\%+;M_56K>SY1[13)2QZ5+9^AJ5VS$5G"D=5*SWN77$L="2;Q"
M<9(2L^/K)U".[3(J%GE1^J?%KF/;-__1SJ$I(BT>TK2(U5
M$C,HTOINUW:YNEAVB.'H[!Y3IWBT1T/>PE9#"]8C]8NB%A2UH*AER$4M'0@!
M_;35B1*H:6!4#WX*(0K?"0*5KY%O)YR%YD(>/
M2,\E175(^6BF88R-%_7Q"VEF-YF89T(93W%34M1YS^XTS3@/L[!T)^;U!?9U
MOJAO.#:\R8M=Q5C#I]*,>PO1MR=/[:6PZ0WKHZ=AUO8;G>F/';'JN:8XM
ML^G[/N:AO_W<8PP&O:O!]@R+-3LQ+;97762^K%(AV'OZ>Y6QM[%BZ=L5?RP+93)]1NCT:JH=!X@/E%D958U0UQ 9*KM?<
M@I*#DAN*V#1D"*95:\4.#!#7W[#@=OGE+%W:T<:VG<
MT5.% #'NJ 7E^DF'L*=U8 )D) ]:W2'
MVQ:4F,8L@A*#$NNGA" FIQ,W^J>OP)R[]MZ:S, ?J+)^VQR)KJPR*XLQHP 7*R9XWN<ONQ
MFJ[X=G>ZXF?9H0ZRJK-A&T]1^*TW@SQ'&P;!=]6 "9"2/>'J\>0@C=/!H-88
MA&P"U%A/I:2I'XN@CT;UW%C:8I-JIH:2=?&A,4L4DU0>:HB&D ;YS'"*%5]>8-1JGT,
M 6*4JO9%K.WM&K)-/K71!55C'NG30AB[NC1@ B1D7P,RDWN6/KNXP2-H,6BQ
M@4@(NIWKQ(W^Z2LP9T_/%NXX:$>AD3*;0)EI+"\8IXIP',:I=DA@GYNNRRW;
M X_TY9$^*T1XM!HP 1*R1XM94^Y:^DP& (^@Q:#%!B(A3;>UHO-R,R@SC>4%(U41E\-(U4Z(ZG/3MKGGH%).:QY94^ZA#3I<
M6@C*'PB*(>(8B<,TYI%'U#QQ8#9@ ,=F7
M6AA/L'E5:PXY8]/6AD-09!HPH4=BTM271>Q'(VX@$J>W"3'&:%"AD;@@$*<3
M-^XKNC[&=%5U^*$B4NW,7_TLSM;T&ZLZJMUMMT??T-&+, K]/$SBODQJI15&
MXYFEL\;G/F).:N,!K4W/FXR-:>,YITU/],;?.!_UV#-?MG-_)EK-_1EB3/W+
M*A4/F5*J<0/7K_#,[-/4+#VI_]553UOT?_((1A^F8VFK^R!)?RQ)FC2B'N"D
M7DTX!"%Y
MET9=PJ)IP 2(#$0&(C-4D6G($ RVU%N#8;"E]B*$F8D]_01EC_:
M5(V4TA#\H_=)*MC/(LV2V(_8FV2]*>048 BJQGK4M/C4U2?6A-6?!DR G.SK
MG,<=U]2&19 3#9C0(SEI6ISOO(*;I+/:FNA3(=(C]C25%O<>:4'SJ:KY5"06
MLA*^JDU396F?17H>+@1[%R^3=*V:3@VF*Y7K-FZ<=/Q635KV:=*SUG@P$8&O
M]&9B6C7.0(L@,  ,  -@IH9HIEBOI+"MM@]:>+![VT#HME6V1UO,L"T0DK8K
M:8?:.XA"V [;R_?A(DVR9%F5P;*T[!;>*]G6)-386@<^[R"!>K"G'?8<9D8$
MN'-8X4%]TZ#,WIMDO:9%$IU$%F_MA_(,.<%5)2;BA6#)*3WK[0P$I%DS:9X>
M9N\CV -3V'_NW"<\\  '90JO/4![XK(=P[B 0]@-03Y0!P"P!U:P_]QIKR$
M',(>6<$X*\@.P@9V18PMV$"=V?/2.DQU.?C3DOCKI+[8VM*K&['EI
MPNKIS)_[%HWP\P9E]5[_7J1"[!_QO[W_]^:1GF
MXN3]YY^^E+\')^S_KNOC7K$%K89R>L--Y.=RAWVFG,T\22+Z++D0J0C8Z15[
M_8X^8X&(0I)H%L9Q:R0S'=R\;$\@YZ.2!++MTEH:;$*Z3BV3E(Q
MOB%Y07@N!>X'^EFS_/=1& ?B^FLMO
M[VC"L4M*3;*W6M0:XPE]\"\B6[B\JCFM3AV).#C9).6"9YZ*2/%CMSOP5J5>
MWJ,4;X/_<6O%W8[/QLTNS<9ML?@C03!O"<)W;^A&IVGX'<_\.!ME(@V7#Y"+
MNSTH.T6-VVKA]K,\AA!;!*^V_E3UL&$K-C
M'>5I67'Z+SI,FI4TS'XMCRSB!2V4"ACY\F3_3L7"+^@-R+@N_46>I!E=7?K+V;QF[M-1_$:WUQT!IKNN1U&8
MY2.BOZ2JNO-F1X9W5:<]MFW[Q4V;>1N4>ZVC4ELG"GXC>>2]V UF_"K&AQXRVU*D4LR+25X@BS0#A
MV+*VAF!'1]^\UM,*;2A_(7S+M:'(R\@.22^])%;^*O)*NDHQ4<$BXC0M
M#TE>2-#D<;4DR=,(:J6,7MM!:6>J_Q\*J1, M;] )9VNVK?*UBQA?"ZR?&MJ
MRO)-J>/)AO >DL*G3@0+DGYT@/<4NA?0>_:OV)Q220B7Z.2.$E^/^)#+#-7V2I(3Q="U/+QW 39%7T?WTQ@*E
MCA,"Z\!Z2POE,*-5;U9OXUN'616D*[-.TJ'SI!J24>+\1V%7M*\)4^%F&0UKRY7!Z$.]-APW*IL'\YO$R3-9.8
M/KTJM[%B*0'@?>6LG)95A"M?%5G)Q<1MP+#
MFRBY*G]7F>U25\OZL5I!E\DXN8"XUM"T*+[EETDUKMRX[;(8:U]@N+7,4I:F?PY*%$ L*V,\683R;+3JLL/H4W!
MD58 Y'.M8:Z!M):0)BYI#9E)BTKVFIP?6GK2XZ7%IDH>2+/KT]U5\%2.H4UE
M,G=;L7V]"EW*X,#2#Z.R+#M4I9=E#J%2EM>E-;?TIKR)6J;*C&U&EY47C(5\
M,#]5.EC*0Y+2H@".&9#?EF.6R%_4N"2")&%4J"P8 3L6%YQ,/8&(+E*Y2_5^
MA4B7^Y38*%$+; 6.M84RF,74P4N<_KX=Z'TGHS 1Y$H=^70
M080E.N%&LFFK&E7GWM(14NTJU,8#0!:0;77-J!:*U]N]5W[I"O_3.QO]Q.Z<>4%..^+/T-Q8E]6@#I0=>45;4S?92L
MPX4$9[F%\'K#U*TRZ5LH10X28&S+DONYC) GFQ4!458V2[V7LC.1;!+IZ"S*
MP.4>5%;Q>P 3P#Q,QFA35B^3,;^NM-_JS!T'1WGG-T-&JO+SVO_QV5F4G-)1
M-4Y5\7[=N6]5;SQ1%G^9I(*87_536%S)'G\KGU:T)_*>@#?@W5K=<[GU6E3[
M56\L0ZLM4#M1 3_/5?E=N4!56<_Z,RO*P,NZ>YB6R*DBQ"7Q)/19&W3FS97&5VDNWHBDW9HB45LO,)L4+R;MO2
MS(^K6M[K,W\,LT51]OQ2FXU)/UUEH=(N/X5R?[+,!KZIC:HZYM.UR_%QZW)<
M-WJA(^H;?J(W8C^5C5:V!V1ENP
M['1&7ZO"S[CL_**RX?2(1.$U,XW1_U./\EM!HB;2Z*HZ(ML]Y+]D;X!-6*8X
MB?.+E?*T3@GCIZI-4EF"2LRC=Y#Z=\_SOE.;78FKGU3H7[X8R0K=5(7Y:07R
M>YUERP;(;B/CJA2[$:48O*T]HV)Y&83\@2U2R:5Z0#*=2HY2M
M(MM$]BK/-_/OO[^XN!AON^6-%\GZ>Q&/BNS[L'J]I^^S@WYTZ$>'?G3H1Z?G
M N%U%-W>-7:C^5HH%P327OVM("UN&YS1$G)2=@>M6X(J+9_[O\J:L80%1;DJ
M*S:!K#F3!]S;L$T>1\\B;Z^6#C>^\&\V69-U<,K;J#K$;>]_;=-V&[R-'RB]
M_6LK>&?A5^Y*D4L2NN!C#..!GIEUA&5M]P)^+X+0OUZ'70M4'Y("_P1@; THX[\Y(4&KCP[!=Q
MRNC5?\UDZ\=(;%9T.(N+]>EVJW >YI&0,914+DS35)4I$6,(GZJU2'$:5=:\
M#"[)R$\6R@"G:O54+FV#,?N\\E.Q(KTD>4?7O=:%-S#BRUO1VIU^YDG@[RR"
MK;EML,UX/68_^PO9(ZU\!KG,%JF*J"YD@U85V[O6J&I37:5LN5KU;[OY=QM!
M" CBL$C
MD?[0%SZNH%\/Q'HZ<_3NPYN/[]^RSU]>?WG[_NV'+Y\?^/*3YNMQ'5[_Y;N8
MT8E1Z9K(K;B;7"Z[62:78O36\C#1[1(28KJD/)6IF&,C1?U\<3IR-]D8I[)!*:?BYMF
M3IWW[,XP4>GOE*G_>7V!DST30=FPV/M4<
MXZYZW/5K VF5L.@SD?;^V8N/F#>KB;%J(YYV^!F7.M#Y8UM8Y-XE+;*6[
MQ7]Z9C][$D)_=51H:Z368E+HEU4J!'M/?Z\R]I:X[_
M"Q&=/U  8-1UC#G QG=*QT&O'136LDQ*+^(#V4!V2\AV]2(^D UD0V<#V4#V
M@W7V7E>J"^[3MCJA+GS8Y&55":MK7A\C6Q M4+_/U/^ZZCNDY@,# /\GIS[@
M#_@/F/J /^ _8.H/ _Z=]>P@/*!M'VD[#+4#Z/:0MH NH-M1V@*Z@&Y':3L,
MZ#8HYA.N_'=\GX4.[5(2]\#%^9]D3^1"S/42&F3,^YDQ'P1] 5Z M[/T!7@!
MWL[2%^ %>)_ DSE4]D611;8RB>G6#MWZ6*[-;G, :^Q.O1(6S%Z_96/%#_*:D_C +CIV! J2D-&P(  8  0  @ $-C  0  J"- '36
MOX/P@+9]I.TPU Z@VT/: KJ ;D=I"^@"NAVE[3"@J^D.*FOZ1(5^[MCL:Z'?
MER3W(Y:6/23TDC4DV(>=8&^K>F1F<,/P]"(_L#UL;#>M5YUPQS'UHC:@/&PH
MMZ6F;=OD4WNF%_T![F&#NVF1W]3DGK5_ZW9GDT H,^MVCA741X:[CPQ B0<$
M  (  8  0  @ !  '9-G7?#O(#R@;1]I.PRU ^CVD+: +J#;4=H"NH!N1VD[
M#.AJU,WO6#5]1TK>'CBY^";) MX_$!7@!WLX2%^ %
M>#M+W(& 5]-M2^A/CL%/T&$=UF%';W?+9_;^!J& -J#=I3IXF]LF!I@!R1HA
MN2TE;5KTPH*OISBD,?#K4P*?%S1X2>LD<\NS#SK.W5NHWXZ[E
MZD5^8'O8V&X*98<;V$D%*.L$Y=9V4AD3;GL -\"M$;@;4GOJ\:G]@*U47<@%
MH=JLVZE64!^)[CXR )4>$  (  0  @ !@ !  '3,H77!OX/P@+9]I.TPU Z@
MVT/: KJ ;D=I"^@"NAVE[3"@JVE+/]3ZM9^-_,\TR3)6/I->HH;T^K#3ZVW5
MCDP,[DPMO<@/; \;VPVI[5KQ :2AXWDMI2T[7)W@M 6L*T1MIM"V>+.=/^L-(VR4?"8
M'C0NRH_HZ:2[1,_UJ\CI!+W$";IJV+JJ+3OL<7>&R"6@K1&T&R/9F@+)0+)&
M2&YQJI]G8A0:L*T1MIM"V>43=W\W%*27.NHL_:>(1>I'REWR SHJS/+4S\-S
M=-Z#RM)(9;5FCFFEB003H*T1M)M6>_#9#.M*(%DC)+<7V)JYF+ +:&L$[>:!
M+>L!!7GZ>$GW,Q-MW[K=\P34?TKJ#V,G)UHN00 @ !" 0=$? @ !@ !  #KN
MWT%X0-L^TG88:@?0[2%M 5U MZ.T!70!W8[2=AC0Q3:GCE;N?=P(6:@7G[$P
M7B1KU.M!,VF4+V^K%,0Q^,38GT$'MH'M+M6"V ZW[RD& 90!Y4ZK:=-UN66C
ML!K@U@C<3;%L3;EKM=84 ON 3=#P%MG7"=E,][?"9
M8>[7TYVMAL-^FVX7FX+Z*/7M(P-0ZPX!@ !  "  $  (  1 QRK"+OAW$![0
MMH^T'8;: 71[2%M %]#M*&T!74"WH[0=!G2QVZFC]7OORLJ]4[%,4E'7\>7^
MI=.V]MWY/##0=U(<"V1MAN6HEJ\8F)=LZ LD90;JU\;^+RF8TZ
M:X!;(W WWO=D\XFU?\V!?4\=]9M^3I/S, N3F)'C!+\).DM3G=6609YR:VKJ
M17U >]C0;DAME]M3=(L DC5"(< 0  @ !  "  $  *@8RUA%_P[" ]HVT?:#D/M +H]
MI"V@"^AVE+: +J#;4=H. [K8\]31VKT/(L=L)^@D[5+E;96!/+==[DVP,P3@
MU@C<3;%L>=RR4:\'+&N$Y=84M6G;W'-F>C$ Z!XVNAN#V3#YU+:0TT$8 ;1]
M:MK>3#9;8PO99HTX@'H+B !$ "( $8 (0 0@ CJ( %PT2 ]HJQ%MAZ%V -T>
MTA;0!70[2EM %]#M*&V' 5VTS.MHV=U;7QV4L8T@OJW\5,SUDA\DOON9^!X$
M?0%>@+>S] 5X =[.TA?@!7A[M)=(D26, WKFN>G0K8_EY53\4;>QQN[4>W'C
M62KF=MX-^HN?A0N]A P:K)\:[.CU[,YXNK_^%] &M#M5S&Z/L8$.2-8)R>UM
M.IJ.#4,O\@/;P\9V\_US8V\_E#7*$L&A.BP*?@RC(A>!7D('C39LC=:F2X6Y
M2X"V1M!^A$N%V31 LD9(;L^E\L;W#*L!MH'M3FEIUA0[LYDN^9?0$D \F=5]*8401H:P3M1RCI_;/D
M-$H:P9W"?B&DO8>ESUHTU4Z'AF4"V;U'=G,@3SJT[PU [CV06U31+E0TD*T/
MLA^AHO=O>NOL3J&;PZ*,\<-G14&40/VA4G\8Y<4:,P#P!_P'S # '_ ?, ,
M?\#_:%6'](M_&@F=,K#7]_[:[1Y%AB \EV__ _VLG^=WE1Z[G%LGRTA"<'LIWUN^RQ;"ET=)C.\F"XWZKTHX'LHS\Q;/OGM#
M-SI-P^]XYL?9*!-IN'P4XSI%C:,@>+6-RU0/&\91&--CY7Z:S_TB3TYN?D'X
M*S_>^&>B#->,_"6IO+D?7?A761F;V2\9=Q!^%\C/;DG7(O*S3#XU;N/NO>$BV7^O[)B&W_9Q^J*)^\_']SY_>_O7MA\_O_OLM>_>!_G[+
M/G]Y_>7M^[K%KU&K1KZS:
MWH5@];!CL_&IYAAWU>.N&NUJZ7;QXN,T+__3,?O8D
MA.Y CK.M[/V752H$>T]_KS+VEA:?':HC!.:!^4:8OQ#1^3> 'L9;@Z+HMI@.
M6PZ]UG.]]K>BJK]C+Z,DRUYQ%HN<)4N6^Y=SO40+
MR?!^)L,'05^ %^#M+'T!7H"WL_0%> '>'NTO4F21\Q]CNK5#MSZ6 U3Q1]W&
M&KM3[\6-9ZF8VWD/2>Y(6JS\^$PP-513!"Q/6"#2\%Q-V,ST$D!HMWYJMV/7
MOYN.7J0'KH>-ZX;4?CE[I1>I@>-AX[@M_3S5B_* ];!AW50]N_O5LT;Y)/A7
M3^%?A3%Y5OF:#H%_!46GD:)KRWZ_]"RL3(%LC9#=D-J.@T@!<*P1CEL;;V-B
M(AF K1&PFT9RN>OM5]'(8@W&R_J2^G%&WE68Q,P/_E54OA7SXX EL@90+VF$
MJANVJFO-ANM%>$#;
M/M)V&&H'T.TA;0%=0+>CM 5T =V.TG88T-5T2Y4U?:)B/W=L]K78[P^;^NDE
M?TBX#SOAWEHMB3L!LH%LC9#=N-[/F6)$-)"L$9+;TM$3C(L&KC7"==-]!=QR
M]B.YL^D@%)QU.]L*ZB/7W4<&H-@# @ !@ !  "  $  (@(YIM"[X=Q >T+:/
MM!V&V@%T>TA;0!?0[2AM 5U MZ.T'09T->KMU[_L[8&SBV_V5.[I)4-(FP\[
M;=Y6.:>A%?X![V.!NBF5K2EB>Z45N8'G86&Y-49NVS:-K:"H6  H(U&M#V9MK9&EO(.VO$ 51>0 0@ A !B !$
M "( $=!!!+;^&?WBGT9")^__^MY?N]VCR!"$Y_+M?Z"?]?/\KOI77,ZMDV4D
M+D=!F(J%'/0T)U>U6,;AU'_50G'0WEFWN+9
M=V_H1J=I^!W/_#@;92(-EX]B7*>H<10$K[;1E>IAPS@*8WJLW$_SN5_DR1OR25-_>C"_\J*R,L^R7C#L+O OG9+>E:1'Z6R8>C4ZL7
M4C_I;Y$^NWT+=_\5#\GV:WW?)':VG],/5=1_>?WWUQ_>O&6?__KV[9?/#P3\
MY ]@IOF[OWP7,SHQ(IYGK]C+?\1^$= =@U='E?M'BO:C+;,RQ28V?NKGXJ964^<]
MNQ.J/0^S\#2,POQJ7E]@7^BUO.%D-G:FDQ>[1JP6]:8^G
MKJ?S;37J%M:_]-&QDW>L._%R9.WZG[5K"]9_*V+!;(/_<)K^V3(L=$P"RON/
M\DXFK0^Y[11!1U!_J-0?1L178P8 _H _.@Z@;DJ[!3)HBPV$'24OH OH#F;O
MZP'*N?L4N7Z=92+/#B%#'2,\M--AHWJ#H"_ "_#V:(Q4SU3\H9M*%&E*OS%?
MF=0Y;"K44H_4$FQJ'XD[$/!JY*\JLE3C$$WGB48S6F.WKZ,9W_C9BOEQP!;R
M%_%;$9[[$7W5R,<=/+.@!/M5Z_+<,OC,WE_B @L/<#\)N!NW-C.XY>QOF*.1
M$SUX&W)@&'Q>)6D^(HRO61B?BRQ?P]I#(79:(;9E[5V7SXRI7N2'L1\VMAM2
M>^)PV\) 4%1R@/J@_H J;3 .#@(P: 'HK'6'\("V?:3M,-0.H-M#V@X#NIHF
MNZWI$T54W;'9U]CWER3W(Y7IYG?RW5QEP;.#1,<'R4NH2#TBB&U%Q[T)GSK[
M0XI:6G]@N__8;DCMF>;\"V1MAN6CTPXS.CM?41M@9TE$?]GW8T&X:_[#W5[DB^*&/]3@P!#[F*Y&RQ8T]^+#R
M4(6=585M67EGRMU9HX@6S#RPK969MUSN81, *H9 ?5!_2!5=V 0  1BT '36
MND-X0-L^TG88:@?0[2%MAP%=3=/:@RP>W+JWD;OSKFOV
M%XMB741^+@(6"+KC(O3S,(GU*=8WIWPR,Q_U, WO75;JVWSB'F0'5\=P"N6N
MAW)O2[)LT^8&:N\!;IW W7@5[O#99#^6-8I2],PB'+K:CM8MM!:)SU@D_$PP
M]?JC9#DJZ(_F(8B>,0&:2P_-U5I P>&FAXIY8%LC;#>'\O0AI70()^AOE-_^
M5H15,"%1U?"/[/C3,^I#8^FAL5ISDB?<=M#='MC6"-M-H_LN=_3?G]XS>W!@
MGOYGD@07813!\D([::*=6MLX;L[XQ-V?C(3I!;@[97H)RZXQ@R?<)]O[+L[]
M^"P\C>I@M,JIPQ)#66FBK%JSQ%,^N4=YP1 #VUTRQ)9%4-[?IP ^<$?M<-F4
M)4HD#64+>F2&H:NTTE6MQ:*G?'I/  ]V&-CNDAUVC(?UDM?'!T:;#SUE"=3O
M-O6'L6,6358@ (,6@,Y:=P@/:-M'V@Y#[0"Z/:3M,*"K47YXMV&&,WNBYAVS
ML3'MYZ-WBJ##@JVMO??7)XM<5756DV7>JG6A^A5)KZ*X#Q^8&
M05^ %^#M4;:X9RK^P.F!-]5HC>C:X,YA6*&;>J2;8%C[2-R!@%UU@;D&.76@[0A1W*Y-TE:3[RZ[B(2B--&O;P&SS3H1CUT8UN&
M?\8M"^,H &V-H-VT^1>?S5KKP0GGOIM&GYS[M! !6R3KC8@S->L2=A[*L+/*
ML+4NGPZ?.>@N!FQKA.VF4+:YIW^W[<%;D .CX/.*_/K2F0]C,O>"Y?ZE>/3.
MZD&R"@I1#X78VI!)[MK[XY^P]8!VEVR]QRUS_Y 8./7ZV(_CF?HB%GX:DX.?
MBG,1%TC>0R=V5R>V9>X]B\_N:;<,>P]L=\G>3QSNNJU-L81OWTV#7\[\6-RM
MF8>YATKLK$ILS;N?<,_&T&I@6R-L-X6RRPW+Z%=;%HRJT*?M$:C?->H/HX,&
M!H5   8M )VU[A >T+:/M!V&V@%T>TC;84!7TWRW-7VBB*H[-OL:_BXGA1P@
M_#U(9D$'ZA$B;*V2?3+E4POI;H!;(W WWI5A'NF3TXFOU][,:PGM$=
MNDH/7=5:(=B43QS886!;(VPW+P2;3?>W'X0?W'D[W,:NK9[1'OI*#WW5WI9K
M#Z88T-8)VLV1;#Z@)!L>L?Z6^$>Q%&E*]A<.,325AIJJM< T-UST/0&T-8)V
M8R,\M;7?!MTS:W#H3^JJ]*BWNVOL3:[#%
MP':7;+'I<']N!1]Q58ZPZC%S/ X$QAL+23V&U98PG+C=-1*>!;8VPW;1@
MBZ#\D$2Q/MXP>E;H*4N@?K>I/XSMG^@8 @$8M !TUKI#>$#;/M)V&&H'T.TA
M;8BL
M=8?P@+9]I.TPU Z@VT/:#@.Z*,KN:!C[3;)>A_F:_LB8'P=,?D,GB7B!LFSH
MJ,/'\ 9!7X 7X.U19KEG*O[ %O9SGBQ^7251(-+L.R9^*\+\:@[+"N74(^4$
MR]I'X@X$O!KYKKLU.*;S1/5 UMCMZY0GZ>TF,=V,3+)R=S=^&-!+LH6_"64]
MUXAE*S^E-_"+?)6D]+X!LQPN4R,L*?(LIY/H+JP&TIYG=V?RWQ%J;3SN6-Y7
M'N101"Q%25)/;M)OU/MI\#B'_="C-*BUUBNR886Q?X\L%D< =Y?JWDQCQHV9
M]IW0!F]##@R#3R+W0]E 7/81IZ,?7> ^2"9!%^JA"ULK<+>FW)I@$B; K1&X
MFQ:XVQ[W;!-!$YDF#I1BYAA6P'QYYX[Y;:'?=] MT;H;@KFB3GCAF$?UVF^
MBZDGX"]6QZ"E5M$[:VQ]8_@.Y&Z=W%^/5H/@P'?[GC7]XI]&0J=%V_6]OW:[
M1Y$A",_EV_] /^OG^5TY99=SZV09BO@A/&>$(?_*O(\G!Y53^*.G4DXN!DDV2ANG8J(C\/SP6A]%*^
MMWR7+6 OC[*6WG51C?JO2A(>RC/S%L^^>T,W.DW#[WCFQ]DH$VFX?!3C.D6-
MHR!XM5T45P\;QE$8TV/E?IK/_2)/3FY^0?@K/][X9Z)<*X_\);D69?#@ZM7HA]5.V^$F?W;Z%N_^*AV3[M5_5Q.79
MS^D'MX=\_?FO[*>_?_SE,_O\Y?67M^_??OCR^8&XG_P!VC0GP0AX_(-"5%
M=4AY*].@E$B<]TM_A/S^QG3T+H#@2;VX+XEU4J!'M/?Z\R]I96H0$P#\SW'/,7
M(CK_!M##EL.6]XWLT&O]U6M_*V+!;(,#Z4#Z@)$.LPVSW3>R]R(7#06V);]E
M6*A>!++[B6R,:0"R^XELZ&P@NY_(?L#H/8WNMQ@P
M_ '_ 3, \ ?\!\P P!_P1S>N \1$(#R@K:ZT'8;: 71[2%M %]#M*&T!74"W
MH[0=!G0UZH'X1ZQLJVO>D9*XQTXR?MR(U)=[VQM-M4<2O8=*ZJ!)]$'0%^ %
M>#M+7X 7X.TL?0%>@+='$TX'ZMPTY.D'D;,P7B1KH9?<0"GU4RD=O<&Z[7)O
M@FIW@%LC<#?%LN5QR][?7AU8!I:[K:A-V^:>LW^>+M -='=*4YN&R:>VA410
MGWREUX%L!+ZF/S*6)RP5]-4BC 2+MTZ4_%S^M?"S%5NFR9HEVV317"_I@VKK
MIVH;!'T!7H"WL_0%> '>SM(7X 5X>Y0M4F2IIKB:SA--E+7&[M3KYSS@'P5=
M9A$J#X@S?YT0,7^O_XH#EN0KD>HEA-!P_=1PQXYHFB8WK/TA(& ;V.Y2/'/&
M;=/3B]A \K"1W):6MJ?%R'1<'G/%G\
M.CKU,R$;^:\W(LZ4O\7$I?P==7Y0=1JINM;,.#?A:P':.D&[,9(-#S5^0+)&
M2&XM(F9QQT!/?6!;(VPW#^[.O/UA V2W!N-KR=U3L@SP+*8W"5B49!D][P
MP=W4QO.9@Y@"D*P1DEM3T[(XP?&@IX%NC=#=D-HNMZW]^P:1]AJ,*_:C6(HT
M)2>LWHCE7\+'@GK32;VU9;P=/G$-O:@/: \;VDV7H1:W+!.K4&!9(RRWENUR
MN#E%/PM@6R-L-]73'C?Y5^%O=L5/H!W3JANS&8#>Y.[RD8T#01!4>K?1R\B\_IER0-4>('
MO::37FO/:GM3F&Q 6R-H-T7R?>8:0 :0NZVCG0F@#6CK!.VF+8>,3FV?@D?5
M/@0^RC[L;%&D*?U=U?3I)7[0;WEKOC4L6"X 6Z-P-V\V\ID>D]=/K ,
M+'==44\L)*X ;IW W5Q1&\X]]3+(6PW,RXH22761KN%G0<-II^':2V%QVS5@
MO@%NC<#=M..*.=6+U,#QL''<8KO6V01UW "W3N!N'B^8W;?@0"9K,#[6=A/6
MQK_"#BSH-KUT6UN&V^+V!)-4 &V-H-W4;$]<9&.!9)V0W):2=KDU0>  T-8(
MVDV1/&FM0A"YJV[Z5?^(A9_&(F"I.!=Q ;\*>DTCO=::7V5QQX+-!K8UPG;3
M_M-3;D],O:@-* \;RFVIZ1F@#6CK!>W&,0+'WK_>0,YJ,+[5.\RL@E;34JNU
M5VABH)0?T-8)VDW=*FXXME[$!I*'C>062[:GG@LU#7!K!.[&"XY[&F@A9348
MM^IF4XN=Z51Z"2$TW+ U7%OFV^.&B94IH*T1M!L'16UGHA>Q@>1A([DM)3WA
M4\?3B_J ]K"AW5A)SRP+F2NX6+L=+>!D01:C)$Z%OK^ MPZ@;LYEJT)
MTK+ LDY8;J\]._=0W9>6W>MJ'2^#U9R9IW1GD6X_&;L;(F82
MA0'[=T/]]RA9@BB!^GVF_M=575]&IS\% TI-:=@0  @ !  "  $8&@,@ !
M;02@L_X=A >T[2-MAZ%V -T>TA;0!70[2EM %]#M*&V' 5U-=U4YUA.5_'EC
MS[/[6?+W0>1LX6=IE&FO;4>OBYW'+2: K8UPG9#
M:CL6GV#O":"L$Y3;4M/FU.(S&Q,Q &Z-P-T4R_:$FY,';*WJ0CX(%6?=3K>"
M^DAV]Y$!J/:  $  (  0  @ !  "H&,>K0O^'80'M.TC;8>A=@#='M(6T 5T
M.TI;0!?0[2AMAP%=C5K\':N\[TC)VV-GSG\*8S]>T&%ZB1%RY_W,G0^"O@ O
MP-M9^@*\ &]GZ0OP KP]VLO4/T$Y<.WD)['QK];T>\:2)0O$:<[9VL^+5+4D
MEY_-#!;X5_1KRB*18=<2U)=&%<-M.?6&7I0'K(<-:Z 8*.X^BJ&< >L>PKII
M3W*7>\ZDM1F[R [IZ3[I)4[05H*R&K:Q::WYG
M88D)8&L$[*8X=J9ZD1HX'C:.VU+0%GE*,[VH#V@/&]K-D>Q.D$SJK9N4BDV1
M+E9^!E\)^DHG?=7BO'G7FR%J"7!K!.Y'8/F^V@Y@&5CNMJ*V+&YY)M -=&N$
M[J9@-J?Y)EB+!U ?/2#9Y!Z5!6@#VIVROQ// Y*!9(V0W)Z?Q*D_C F'6 D(00  @ !&!3](0 0  @ !*#C_AV$
M![3M(VV'H78 W1[2%M %=#M*6T 7T.TH;8V@O
M 71KA>[&8#;XU'$ 9H!9(S"WIJI="]U3@&[-T-T8S":?S.Y9=W0V+X3*LVZG
M74%])+W[R !4?4  (  0  @ !  "  '0,9_6!?\.P@/:]I&VPU [@&X/:0OH
M KH=I2V@"^AVE+;#@"ZZ]#UU%5];N?-W\;G(\A!5?-!1QTB>#X*^ "_ VUGZ
M KP ;V?I"_ "O#W:TS10WZ8A3U_36^=A$FXJ]3E,P#=%,T3A[ON0WJ4(T?4 3]J0>Y2IEPIEBS9(EEO_#@4F1KNI#Z1;2!\>50J
M N5@!:'*(N5%*@^3GVR*=+'R,WI-.B&,9R#.]1!5Z
M<-AZL#4S[[APQP!MG:#=>,'*/<<&EH%EC;#$S261AJK/7,\Y5,+H7^@6R=T-P6S9?*)?4]L%& &
MF+NMJMTIM^^+_ /=0'>W5/6,>YZ+-%:O?*?W?EZD81[">8+.TEAGM661'6Y.
M3;VH#V@/&]J-D3PQIWH1&T@>-I+;4M(V8=MP]2(_L#UL;#>DMCF19=I(-_7)
M9?KL1_"6H*PT5E9M&>()=Z:>7M0'M(<-[8;4MOC$@M\/)&N$Y+:4M&5R;X9(
M +"M$;8;4GO&;:,U9PGY)1V-9W#'Q%1%H%LG
M=#?WDAQ++V(#R<-&L:G$Y3B =TZH;NQGK;-_7'9SHY&PO#5;D\> _6?
MDOK#F*> P8<0  @ !&!0](< 0  @ !" COMW$![0MH^T'8;: 71[2%M %]#M
M*&T!74"WH[0=!G0UVMRDR!+& 3WSW+'HUL8
M=0)S>T5_]HR[A@%X ]X:P;LIFCV+N[-[&O]V-C&$TK-NYUU!?62]^\@ E'U
M "  $  (  0  @ !T#&AU@7_#L(#VO:1ML-0.X!N#VD+Z *Z':4MH OH=I2V
MPX N&O5UM(SO[7(I%KEL:[Y,4N)7S,3E8N7'9X*E?BX;GL=EF9\?!^4OXK^0@*1P!LC8#=D-KFU-:+U,#QL''<8E,_=%X%M'6"=D-J
M3_9KZ,YF?5!7UNVD*JB/E'8?&8":#@@ !  "  &  $  (  Z9LNZX-]!>$#;
M/M)V&&H'T.TA;0%=0+>CM 5T =V.TG88T-6HG1^J^A[%U8D<
M>GOE(28W/71_ KIU0G?3(C[NF(Y>Q :2AXWDUO3TC-N&!S4-<&L$[J9JVN0S
MZP&S>;$U2G\GZLU];A-GIX*>4UY!;IS:B#1, KTD#6ILV&JL+1MM6]PT7+W(
M#VP/&]L-J6U-^=2:ZD5M0'G84&Y-31O<M+9&EO?F'D&
MN5LG]]<++4!PX+O;Y :^@>\^DQOX!KZ/G5ZB7_S32'R34VA:]/>WO[ ZO*5D
MS/7S/(8@OPBV\L\%2\7"SW*V( SY82]K^0#_K]_Q]%,:!N)Q;)\M(7(Z"
MD!Y!GC@G A3K^"0(LTWD7\WEMW=0/'8)C_*=JOR?,9[0!_\JLCQ<7M6OITX=
MB3@XV219J*Z=BHB>[ER0#%Q*"DKZ;,7A\BB!ENK[4FSKORHY^W;\EP]FWN+^
M=V_H1J=I^!W/_#@;9<26Y:.DHU/4N"T+MY_E46JB1O!J&S*I'C:,HS"FQ\K]
M-)_[19ZB'UD_X6Z;/;MW#W7_&0;+\.NCV=UOO\]C_?O_WPA7UZ^_D??__R
M^8&(GSQ*Y^OP_B_?Q8Q.C(COV2OV\A^Q7P1TQV"W*Y@RA4MR0VR\-'I+63HCJDO+MIT!+B17T\O6OD;S(QS\3&E^/.;\J].N_9G0CE
M>9B%IV$4YE?S^@+[(HSE#5UC[%DO=K5\+0N5FM^[RJH>=FPV/M4Z6_RG9_:S1Q!Z'09!)'J:H&L+XE]6J1#L
M/?V]RMA;6IP=I!RN.2N >6"^=R0Z_U5Z_]K8@%A_D&
MS/L/R=RC[VW 'VH"TEV58$]AHP+I_L#[(%@; &K"&M@:L
M >NC:.O.-F5#VV=]2CM!_2-J-;2;/ KU[S?8P#ZP#^P#^\ ^L _L _L:8;^S
MWAPD![35E[8'B2_U1>=H&1@%;H%;X+:KM 5N@=LNTA:X[4=;[>XE:X^=3_PY
M38)BD8?G87ZE6F[_I^TILDRUFR9"E\
M)B@KW9156Z9XPF?3F5[4![2'#>W&2#;N&3 .) /)G5;2ELL-$W$M8%LC;#>%
MLL4=:[^:1EZIN[[2QXU(_9P.8^)R(V)LZX&VTDI;M66)IWSF3O6B/J ];&@W
M1K+A84D))&N$Y+:4M&URT]@?CP>V@>TN:6EKRB=F)SMRHS^BGAN*0/UN]P8=
M1HWQ4S"@U)2�&  $  (  0@*$Q  (  =!& #KKWT%X],QS@;;8W:DQ>0%=
M0+>CY 5T =V.DA?0!71[TZ];D26, WKFN>G0K8\H-Q6+U)VLL3OU7MQXG(J_
M/2KT"^-%LL:N**@SC;+LK6U0MDP^0PD)P*T3N!OO3Y[RV0!?0[2AY 5U ]^CI&,Q5TJ3=PB?,GH5..E;PY.B;=^T9
MMPU,@0>X-0)WXXXA,S[U,!H,6-8(RZTI:M/VN#5&Q)G(X#!!6^FCK=JR
MQ!/N>%AD MH:0;OIFI)/T<8;2-8)R6TI:0%=0+-KB;8MEQN#N=Z9@,VO5D,-U5<]DZB/L$VCXHK=W^H&I,T7P,
M!]JH[( (0 0ZS $4-_5 !'J3-8 (0 0&+@+PZ>#3P:=[>MH>*!:%U>H!XZB
M+J"K,WFQ@$1954?)"^@"NKVI".Q?DO?8&?;W22K8SR+-DMB/V)MDO2ED^5]G
MG!QDW#N<<1\$?0%>@+>S] 5X =[.TA?@!7@[GL5!'*!G21G0%C$6G_2D#*8K:=)TX1-FT$(G'2MX"Q:?NHY>] >XAPWN
MQEBVN>/N'V\(+ /+W5;4KL,-%[T6 &Z-P/T(+$^7L0&DH>-Y-:&T-KJ9KW3=REM<;D29Z$5]0'O8T&Z,
M9--&HA1(U@C);2EI<\+-*08N -L:8;LIE,E=H'X5^8;Q(UM@5!76F
M49:]M>W)%O><_57*6EIJ8+O_V&X*99N;,^SP Y0U@G)[[7X<;D]1CPUP:P3N
M1V#9G.S'\A!309C*>#A?"+1]4(ZZ_;G3&(KY& ZT4:8!$8 (=)@#J%2""$ $
M8 4@ IJ( %RTP4H/7+3.18IZHW:@%GI(6T 7)4\=I>TP2IX W1[2=AC0U:A:
MKW\IV&/GO[\DN1]UQJ5!]KO#V>]!T!?@!7@[2U^ %^#M+'T!7H 7*1AX_5KY
M*Z M(BH:DQ?0!70[2EY %]#M*'D!74#WZ"D8X8F)F/3%9]$A!=.0K9\P"Q8Z
MZ5C!DZ-OIYT9W# P0Q/@U@C<3;'L3;CC8&8FL*P1EEM3U+9M\JD]TXL!0/>P
MT=VXU]+4Y)ZU?Q8=RM6ZZRN]2;*<)4N6PF>"LM)-6;4VFGW&70NS!H%MC;#=
M%,H.-TR,A 64-8)R:R-AC0FW/8 ;X-8(W VI/?7(]]\?V4)JJ;ONTG5G;7&Y
M$7$F,GA,T%;Z:*O63/&,3SV$+H%MC;#=%,I3;AI85 +*&D&Y+37M&=RR, (!
MV-8(VPVI/7&Y/=D?H^WLGJ''3]%%(6MS7PG4UZJR[X=Q >/3-=H"VV>&I,7D 7T.TH>0%=0+>CY 5T =W>M.56
M9 GC@)YY;CITZR/*3<4B=2=K[$Z]%S<>I^)OCTK]PGB1K+$U"NI,HRQ[:[N4
M'8-/#!OT[QZ^FRN/#N"[\:9[A]N69G"&KNZGKCBZKC9=EULV>O\ W1JANS&8
MK2EW[RE>'6)&"!,9#^<2@;8/2E5CA+1>', 4=8@ 1  %2Q !B "L $1 !Q&
MBS98Z8&+UKE046_4#M1"#VD+Z*+RJ:.T'4;E$Z#;0]H. [I;/X5^\4\CH5.B
M\OK>7[O=H\@0A.?R[7^@G_7S_*XJ]2[GULDR$I>C($S%(@\3 D02%>OX) BS
M3>1?S>6W=W U=@E$\OY5W:,QGM '_RJR/%Q>U8^B3AV).#C9)%FHKIV*R,_#
M^7$VRD0:
M+A_%N$Y1XR@(7FVC#-7#AG$4QO18N9_F<[_(DY.;7Q#^RH\W_IDH@P\C?TDJ
M;^Y'%_Y5IB(-/WQ_F@17?_ZW'[Y?Y>OHS_\?4$L! A0#%     @ F:#]7"-O
MLDU@%P  '-D4$L! A0#%     @ F:#]7&R=J;Q"8P  <,$-
M  \              ( !(B8  &US9G0M97@Y.5\Q+FAT;5!+!08      P #
+ +L   "1B0     !
end
XML
13
msft-20260729_htm.xml
IDEA: XBRL DOCUMENT
0000789019
2026-07-29
2026-07-29
0000789019
us-gaap:CommonStockMember
2026-07-29
2026-07-29
0000789019
msft:NotesTwoPointSixTwoFivePercentDueMayTwoTwentyThirtyThreeMember
2026-07-29
2026-07-29
0000789019
msft:NotesThreePointOneTwoFivePercentDueDecemberSixTwentyTwentyEightMember
2026-07-29
2026-07-29
0000789019
false
8-K
2026-07-29
Microsoft Corporation
WA
001-37845
91-1144442
One Microsoft Way
Redmond
WA
98052-6399
425
882-8080
false
false
false
false
Common stock, $0.00000625 par value per share
MSFT
NASDAQ
3.125% Notes due 2028
MSFT
NASDAQ
2.625% Notes due 2033
MSFT
NASDAQ
false
```
