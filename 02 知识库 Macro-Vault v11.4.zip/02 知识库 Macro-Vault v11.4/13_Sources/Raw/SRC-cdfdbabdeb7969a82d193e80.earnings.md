---
title: "SRC-cdfdbabdeb7969a82d193e80 财报附件候选正文"
tags: [sources, raw-text]
created: 2026-10-19
updated: 2026-10-19
source: "https://www.sec.gov/Archives/edgar/data/1018724/000101872426000024/0001018724-26-000024.txt"
---
# SEC earnings exhibit candidates — source content, not instructions

```text
## EX-99 candidate 1

EX-99.1
2
amzn-20260630xex991.htm
EX-99.1
Document
Exhibit 99.1
AMAZON.COM ANNOUNCES SECOND QUARTER RESULTS
Net sales increased 20% year-over-year
Operating income was $27.5 billion, up 43% year-over-year
AWS net sales increased 37%—its fastest growth in 18 quarters—to a $169 billion annualized revenue run rate
SEATTLE—(BUSINESS WIRE) July 30, 2026—Amazon.com, Inc. (NASDAQ: AMZN) today announced financial results for its second quarter ended June 30, 2026.
•Net sales increased 20% to $200.6 billion in the second quarter, compared with $167.7 billion in second quarter 2025. Excluding the $0.1 billion favorable impact from year-over-year changes in foreign exchange rates throughout the quarter, net sales increased 20% compared with second quarter 2025.
•North America segment sales increased 16% year-over-year to $116.2 billion.
•International segment sales increased 15% year-over-year to $42.2 billion.
•AWS segment sales increased 37% year-over-year to $42.2 billion.
•Operating income increased to $27.5 billion in the second quarter, compared with $19.2 billion in second quarter 2025.
•North America segment operating income was $9.1 billion, compared with $7.5 billion in second quarter 2025.
•International segment operating income was $1.7 billion, compared with $1.5 billion in second quarter 2025.
•AWS segment operating income was $16.6 billion, compared with $10.2 billion in second quarter 2025.
•Net income increased to $62.6 billion in the second quarter, or $5.75 per diluted share, compared with $18.2 billion, or $1.68 per diluted share, in second quarter 2025.
•Second quarter 2026 net income includes non-operating pre-tax other income of $53.4 billion, primarily from our investments in Anthropic.
•Operating cash flow increased 33% to $161.4 billion for the trailing twelve months, compared with $121.1 billion for the trailing twelve months ended June 30, 2025.
•Free cash flow decreased to an outflow of $7.6 billion for the trailing twelve months, driven primarily by a year-over-year increase of $66.1 billion in purchases of property and equipment, net of proceeds from sales and incentives. This increase primarily reflects investments in artificial intelligence. This compares to free cash flow inflow of $18.2 billion for the trailing twelve months ended June 30, 2025.
“AWS is booming, growing 36.7% year-over-year in Q2—our fastest growth in 18 quarters—and our AI and Chips businesses each eclipsed run rates of more than $25 billion,” said Andy Jassy, President and CEO, Amazon. “In Stores, we again set record delivery speeds for Prime members in the first half of the year—over 40% more items delivered same-day or overnight, with Grocery and Everyday Essentials growing meaningfully faster than the rest of the business. And, Advertising had another strong quarter with 26% year-over-year growth. There’s a lot to be excited about, and we have much more coming for customers in the second half of the year and beyond.”
Some other highlights since the company’s last earnings announcement include that Amazon:
•Exceeded a $25 billion annual revenue run rate for AWS’s AI business, growing triple-digit percentages year-over-year.
•Exceeded a $25 billion annual revenue run rate for its chips business, growing triple-digit percentages year-over-year.
•Continued gaining momentum with Trainium, with the two leading AI labs in the world, Anthropic and OpenAI, making multi-year, multi-gigawatt commitments; an increasing number of AI start-ups adopting Trainium, including unicorns like NEURA Robotics and Odyssey; and commitments from other startups like TwelveLabs, Decart, Poolside, Karakuri, Inc., Metagenomi Therapeutics, Inc., NetoAI, and Splash Music, as well as larger companies like Uber and Pinterest.
•Released Graviton5 into general availability. Graviton delivers up to 30 to 40% better price-performance than comparable instances, and Graviton5 delivers up to 25% better compute performance than Graviton4. Graviton is used by 98% of the top 1,000 EC2 customers, revenue commitments have increased nearly 3x quarter-over-quarter, and Graviton5 is growing nearly 2x faster than Graviton4 did.
•Added 10+ fully managed foundation models to Amazon Bedrock, including OpenAI’s GPT-5.6, Anthropic’s Claude Opus 5, Google DeepMind’s Gemma 4, and SpaceXAI’s Grok 4.3. Amazon Bedrock provides the best selection of leading models, at superior performance, and with the governance and security controls that companies need, and it’s continuing to grow quickly—hundreds of thousands of customers now use Bedrock, more customers were added in the last six months than in the first two years after launch, and customers spent more in Q2 than all prior quarters combined.
•Previewed AWS Continuum, which discovers, prioritizes, validates, and remediates code vulnerabilities. It starts by ingesting the backlog of vulnerabilities a team already has, and then leverages the new frontier models to run comprehensive scans. Continuum uses agents and each company’s own business context to prioritize what matters, then validates vulnerabilities in a sandbox and recommends the fix.
•Added new capabilities to Bedrock AgentCore, which provides the building blocks that companies need to quickly and securely deploy and operate agents at scale. New capabilities include Payments (so agents can execute transactions autonomously), Web Search (to ground agents’ knowledge without having to leave AWS), and Harness, which further speeds up how fast customers can stitch together all the infrastructure they need for their agents.
•Made Amazon Quick—an intelligent AI work companion that helps manage, search, and automate digital workloads across email, calendar, local or cloud files, and custom workflows—even more capable, adding autonomous agents that customers set up in plain language to run continuously in the background and carry out multi-step tasks; a personalized activity feed that pulls email, messages, calendar, and tasks into one prioritized view; and 16 new integrations, including Adobe, Moody’s, and Snowflake. Quick manages across leading SaaS tools like Slack, Salesforce, Jira, Teams, and ServiceNow; enforces a company’s existing access controls; and takes actions like scheduling meetings, drafting and sending email, updating a CRM record, building a dashboard, and more.
•Made its spec-drive coding agent, Kiro, available on iOS so developers can now kick off a new project, monitor progress, steer an agent, and interact with Kiro sessions from their phone, desktop, command line, and the web. Kiro is up to 50% more cost-effective than alternatives and tripled in usage quarter-over-quarter.
•Added new capabilities to AWS DevOps Agent, an always-available software operations teammate that helps developers ship software safely and reliably, including Release Management to perform readiness reviews of code changes and autonomously test releases to spot potential issues before they go live.
•Launched serverless infrastructure for agentic AI that scales on demand, including:
•Lambda MicroVMs, a new flavor of the popular AWS Lambda serverless compute service that not only offers instant start times with the ability to scale all the way up or down depending on demand, but also now provides a stateful runtime with sessions that can last up to 8 hours—ideal for long-running agent loops, multi-step pipelines, or persistent database engines.
•Next-generation OpenSearch Serverless, which gives agents fast access to search across massive volumes of data, scales capacity up to 20x faster than the previous generation, and offers up to 60% cost savings versus provisioning for peak.
•Purpose-built log analytics engine for Amazon OpenSearch Service, designed to keep pace with the vast increase in logs being produced by agentic workloads. It delivers up to 4x better price performance compared to the existing general-purpose engine, up to 2x higher data ingestion on the same hardware, and up to 2x faster analytical queries, while retaining up to 3x more data at the same cost—enabling teams to retain and analyze more observability data without choosing between insight and budget.
•Announced an investment of $1 billion to create AWS Forward Deployed Engineering, a team of AI engineers embedded directly with customers to co-develop and deploy agentic AI solutions in days rather than months. Early customers include Allen Institute, Cox Automotive, the NBA, the NFL, Ricoh, and Southwest Airlines.
•Announced general availability of AWS Secret Cloud for Industry, giving defense contractors a faster, more secure path to classified innovation, with Northrop Grumman first to run classified workloads on the platform, and committed up to $1 billion in cloud credits to accelerate U.S. Intelligence Community cloud migration and modernization.
•Announced its global data centers are over 7x more water-efficient than the industry average. Amazon also reached 75% progress toward its goal to be water positive across global data center operations by 2030, and achieved water-positive status across its direct operations in India ahead of its 2027 target.
•Announced new AWS agreements with Warner Bros. Discovery, Vodafone, Siemens Energy, Ryanair, Pinterest, Snowflake, Moody’s, Danske Bank, WNBA, Pennymac, Fiserv, WPP Enterprise Solutions, Vonage, Recursive, fal, Chai Discovery, Odyssey, TwelveLabs, Reactor, OpenRouter, Dash0, New York State Office of Information Technology Services, State of Iowa, University of South Florida, and The University of Utah.
•Continued to expand its ultra-fast delivery service, Amazon Now, which offers delivery in 30 minutes or less on thousands of everyday essentials—adding 80 new cities and towns across the U.S. and several major cities in Egypt. Amazon Now is available in nine countries and over 250 cities and towns globally, and customers love it, with over 80% growth in gross sales and units sold quarter-over-quarter and over 60% more customers served quarter-over-quarter.
•Added millions of new products to its selection, including over 700,000 from notable brands like ADT Blu, Bobbi Brown, BROWN GIRL Jane, CR7 Underwear, LeGer, Mamonde, OLIVA COSMETICS, Rabanne, and Ted Baker.
•Brought together Rufus and Alexa+ into Alexa for Shopping, an agentic AI shopping assistant that offers personalized recommendations, product comparisons, price history, and the ability to automate shopping through features like Price Alerts and Auto-Buy. Worldwide customer adoption and engagement accelerated in Q2, with active users close to doubling and interactions up over 5x year-over-year.
•Launched Amazon Supply Chain Services so any business can move, store, and deliver everything from raw materials to finished products using the same supply chain that supports Amazon, with Procter & Gamble, 3M, Lands’ End, and American Eagle Outfitters among the first customers.
•Reached $60 billion in annualized gross sales for Amazon Business and continued to expand selection—adding nearly 30% more items compared to last year, including Same-Day Delivery of fresh groceries for businesses in 2,300+ U.S. cities and towns.
•Introduced the next-generation of Proteus, an autonomous robot that assists Amazon fulfillment center employees by moving goods up to 1,300 pounds, reducing heavy lifting and further increasing safety. Using AI, employees can now direct Proteus with plain, conversational language.
•Grew the number of new customers for Amazon Pharmacy by more than 2x in the first six months of the year, and same-day prescription deliveries nearly 5x. Also saved customers nearly $250 million so far this year in out-of-pocket costs, up more than 400% year-over-year, through manufacturer discounts applied automatically on an expanded selection of widely prescribed medications.
•Expanded Ads Agent—an AI-powered tool that simplifies planning, launching, and managing advertising campaigns and turns hours of setup and targeting into minutes—to 11 new countries so far this year. Advertisers using Ads Agent see 8% lower cost-per-impression and 6% lower cost-per-acquisition than those that don’t use it.
•Expanded Alexa+ to Germany, Austria, France, and Brazil, with hundreds of millions of customers now using new Alexa experiences, and that number growing every month. Alexa continues to drive meaningful momentum for the business, including in the U.S., where customers who use Alexa for Shopping spend an average of over 40% more per order than those who don’t, and customers who have tried Alexa+ are signing up for Prime at a nearly 25% higher rate.
•Drew 36 million viewers globally for the series premiere of Off Campus on Prime Video in its first 12 days, becoming Prime Video’s No. 3 top-viewed series debut ever.
•Delivered strong viewership for inaugural season of NBA on Prime Video, with a peak of 6.5 million U.S. viewers for Game 7 of the Eastern Conference Semifinals (outperforming Game 7 on broadcast in 2025). In Europe, viewership of the NBA more than doubled year-over-year on Prime Video, with the highest average viewership on record.
•Averaged 2.3 million viewers during the second season of NASCAR on Prime Video and attracted the youngest audience the last two years among NASCAR broadcasters since 2017.
•Completed four additional launches for Amazon Leo, its low Earth orbit satellite network, bringing the total constellation to nearly 400 satellites in orbit—enough to begin initial satellite internet service this year.
•Received approval from the National Highway Traffic Safety Administration (Part 555 Exemption) for Zoox to charge for rides—the first purpose-built robotaxi to receive this exemption—paving the way for Zoox to begin offering paid commercial service to customers.
•Supported relief efforts following earthquakes in Venezuela with its Amazon Disaster Relief program, donating and delivering more than 650,000 emergency supplies to more than a dozen nonprofits and establishing weekly humanitarian relief flights to Caracas in a first-of-its-kind collaboration with Airlink, the U.S. State Department, and World Food Programme, delivering approximately 120 tons of supplies.
Financial Guidance
The following forward-looking statements reflect Amazon.com’s expectations as of July 30, 2026, and are subject to substantial uncertainty. Our results are inherently unpredictable and may be materially affected by many factors, such as fluctuations in foreign exchange rates and energy prices, changes in global economic and geopolitical conditions, tariff and trade policies, resource and supply volatility, including for memory chips, and customer demand and spending (including the impact of recessionary fears), inflation, interest rates, regional labor market constraints, world events, the rate of growth of the internet, online commerce, cloud services, and new and emerging technologies, and the various factors detailed below.
Third Quarter 2026 Guidance
•Net sales are expected to be between $197.0 billion and $202.0 billion, or to grow between 9% and 12% compared with third quarter 2025. Excluding the impact of Prime Day in both 2025 and 2026, third quarter 2026 year-over-year growth would be nearly 400 basis points higher. This guidance anticipates an unfavorable impact of approximately 80 basis points from foreign exchange rates.
•Operating income is expected to be between $22.5 billion and $26.5 billion, compared with $17.4 billion in third quarter 2025.
•This guidance assumes, among other things, no impact from energy derivative contract remeasurements, and that no additional business acquisitions, restructurings, or legal settlements are concluded.
Conference Call Information
A conference call will be webcast live today at 2:00 p.m. PT/5:00 p.m. ET, and will be available for at least three months at amazon.com/ir. This call will contain forward-looking statements and other material information regarding the Company’s financial and operating results.
Forward-Looking Statements
These forward-looking statements are inherently difficult to predict. Actual results and outcomes could differ materially for a variety of reasons, including, in addition to the factors discussed above, the amount that Amazon.com invests in new business opportunities and the timing of those investments, the mix of products and services sold to customers, the mix of net sales derived from products as compared with services, the extent to which we owe income or other taxes, competition, management of growth, potential fluctuations in operating results, international growth and expansion, the outcomes of claims, litigation, government investigations, and other proceedings, fulfillment, sortation, delivery, and data center optimization, risks of inventory management, variability in demand, the degree to which the Company enters into, maintains, and develops commercial agreements, proposed and completed acquisitions and strategic transactions, payments risks, and risks of fulfillment throughput and productivity. Other risks and uncertainties include, among others, risks related to new products, services, and technologies, security incidents, system interruptions, government regulation and taxation, and fraud. In addition, global economic and geopolitical conditions and additional or unforeseen circumstances, developments, or events may give rise to or amplify many of these risks. More information about factors that potentially could affect Amazon.com’s financial results is included in Amazon.com’s filings with the Securities and Exchange Commission (“SEC”), including its most recent Annual Report on Form 10-K and subsequent filings.
Additional Information
Our investor relations website is amazon.com/ir and we encourage investors to use it as a way of easily finding information about us. We promptly make available on this website, free of charge, the reports that we file or furnish with the SEC, corporate governance information (including our Code of Business Conduct and Ethics), and select press releases, which may contain material information about us, and you may subscribe to be notified of new information posted to this site.
About Amazon
Amazon is guided by four principles: customer obsession rather than competitor focus, passion for invention, commitment to operational excellence, and long-term thinking. Amazon strives to be Earth’s Most Customer-Centric Company, Earth’s Best Employer, and Earth’s Safest Place to Work. Customer reviews, 1-Click shopping, personalized recommendations, Prime, Fulfillment by Amazon, AWS, Kindle Direct Publishing, Kindle, Career Choice, Fire tablets, Fire TV, Amazon Echo, Alexa, Just Walk Out technology, Amazon Studios, and The Climate Pledge are some of the things pioneered by Amazon. For more information, visit amazon.com/about and follow @AmazonNews.
AMAZON.COM, INC.
Consolidated Statements of Cash Flows
(in millions)
(unaudited)
Three Months Ended
June 30,		Six Months Ended
June 30,		Twelve Months Ended
June 30,
2025		2026		2025		2026		2025		2026
CASH, CASH EQUIVALENTS, AND RESTRICTED CASH, BEGINNING OF PERIOD	$	69,893 			$	104,692 			$	82,312 			$	90,106 			$	71,673 			$	61,453
OPERATING ACTIVITIES:
Net income	18,164 			62,647 			35,291 			92,902 			70,623 			135,281
Adjustments to reconcile net income to net cash from operating activities:
Depreciation and amortization of property and equipment and capitalized content costs, operating lease assets, and other	15,227 			19,988 			29,489 			38,933 			58,562 			75,200
Stock-based compensation	6,534 			6,038 			10,223 			10,070 			20,551 			19,314
Non-operating expense (income), net	(1,258)			(53,381)			(4,075)			(69,013)			(4,702)			(79,818)
Deferred income taxes	11 			17,691 			518 			30,489 			(2,407)			41,441
Changes in operating assets and liabilities:
Inventories	(4,054)			(1,818)			(5,276)			(196)			(5,851)			2,078
Accounts receivable, net and other	(1,125)			(8,204)			122 			(13,954)			(4,602)			(21,409)
Other assets	(2,971)			(4,717)			(6,373)			(8,528)			(15,100)			(17,787)
Accounts payable	7,058 			9,442 			(1,985)			705 			6,264 			13,921
Accrued expenses and other	(4,952)			(2,018)			(9,013)			(10,063)			(4,842)			(6,069)
Unearned revenue	(119)			(281)			609 			74 			2,641 			(749)
Net cash provided by (used in) operating activities	32,515 			45,387 			49,530 			71,419 			121,137 			161,403
INVESTING ACTIVITIES:
Purchases of property and equipment	(32,183)			(54,208)			(57,202)			(98,411)			(107,656)			(173,028)
Proceeds from property and equipment sales and incentives	815 			1,132 			1,579 			2,101 			4,703 			4,021
Acquisitions, net of cash acquired, non-marketable investments, and other, net	(1,700)			(24,359)			(1,652)			(39,767)			(4,809)			(41,956)
Sales and maturities of marketable securities	11,441 			24,196 			19,178 			41,882 			30,924 			67,090
Purchases of marketable securities	(17,797)			(26,006)			(31,130)			(49,262)			(46,731)			(72,902)
Net cash provided by (used in) investing activities	(39,424)			(79,245)			(69,227)			(143,457)			(123,569)			(216,775)
FINANCING ACTIVITIES:
Proceeds from short-term debt, and other	2,093 			9,368 			3,908 			15,386 			8,187 			20,798
Repayments of short-term debt, and other	(1,392)			(9,573)			(3,474)			(15,682)			(7,901)			(20,634)
Proceeds from long-term debt	— 			13,557 			746 			66,998 			746 			81,925
Repayments of long-term debt	(2,751)			(2,752)			(2,751)			(2,752)			(7,434)			(5,022)
Principal repayments of finance leases	(411)			(395)			(821)			(863)			(1,556)			(1,599)
Principal repayments of financing obligations	(78)			(59)			(194)			(174)			(694)			(308)
Net cash provided by (used in) financing activities	(2,539)			10,146 			(2,586)			62,913 			(8,652)			75,160
Foreign currency effect on cash, cash equivalents, and restricted cash	1,008 			(53)			1,424 			(54)			864 			(314)
Net increase (decrease) in cash, cash equivalents, and restricted cash	(8,440)			(23,765)			(20,859)			(9,179)			(10,220)			19,474
CASH, CASH EQUIVALENTS, AND RESTRICTED CASH, END OF PERIOD	$	61,453 			$	80,927 			$	61,453 			$	80,927 			$	61,453 			$	80,927
SUPPLEMENTAL CASH FLOW INFORMATION:
Cash paid for interest on debt, net of capitalized interest	$	523 			$	736 			$	759 			$	1,010 			$	1,668 			$	1,709
Cash paid for operating leases	3,758 			3,489 			7,320 			7,804 			13,485 			15,522
Cash paid for interest on finance leases	72 			85 			143 			187 			284 			339
Cash paid for interest on financing obligations	52 			50 			107 			126 			212 			215
Cash paid for income taxes, net of refunds	4,761 			2,655 			5,638 			3,978 			11,788 			6,635
Assets acquired under operating leases	4,621 			7,670 			8,942 			13,909 			16,702 			24,897
Property and equipment acquired under finance leases, net of remeasurements and modifications	937 			563 			991 			2,128 			1,622 			4,048
Increase (decrease) in property and equipment acquired but not yet paid	(1,600)			10,700 			1,508 			20,620 			5,376 			29,267
AMAZON.COM, INC.
Consolidated Statements of Operations
(in millions, except per share data)
(unaudited)
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Net product sales	$	68,246 			$	77,602 			$	132,216 			$	148,906
Net service sales	99,456 			123,004 			191,153 			233,219
Total net sales	167,702 			200,606 			323,369 			382,125
Operating expenses:
Cost of sales	80,809 			95,778 			157,785 			183,241
Fulfillment	25,976 			29,633 			50,569 			56,922
Technology and infrastructure	27,166 			33,158 			50,160 			62,725
Sales and marketing	11,416 			11,698 			21,179 			22,012
General and administrative	2,965 			2,788 			5,593 			5,375
Other operating expense (income), net	199 			90 			507 			537
Total operating expenses	148,531 			173,145 			285,793 			330,812
Operating income	19,171 			27,461 			37,576 			51,313
Interest income	1,085 			1,295 			2,151 			2,430
Interest expense	(516)			(1,314)			(1,057)			(2,114)
Other income (expense), net	1,117 			53,415 			3,866 			69,062
Total non-operating income	1,686 			53,396 			4,960 			69,378
Income before income taxes	20,857 			80,857 			42,536 			120,691
Provision for income taxes	(2,678)			(18,199)			(7,231)			(27,759)
Equity-method investment activity, net of tax	(15)			(11)			(14)			(30)
Net income	$	18,164 			$	62,647 			$	35,291 			$	92,902
Basic earnings per share	$	1.71 			$	5.82 			$	3.32 			$	8.64
Diluted earnings per share	$	1.68 			$	5.75 			$	3.27 			$	8.53
Weighted-average shares used in computation of earnings per share:
Basic	10,637 			10,769 			10,620 			10,756
Diluted	10,806 			10,903 			10,800 			10,889
AMAZON.COM, INC.
Consolidated Statements of Comprehensive Income
(in millions)
(unaudited)
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
Net income	$	18,164 			$	62,647 			$	35,291 			$	92,902
Other comprehensive income (loss):
Foreign currency translation adjustments, net of tax of $(142), $(66), $(208), and $(79)	3,314 			(799)			4,849 			(1,563)
Unrealized gains (losses) on net investment hedging instruments, net of tax of $0, $(69), $0, and $(45)	— 			229 			— 			144
Available-for-sale debt securities:
Change in net unrealized gains (losses), net of tax of $(12), $(13,695), $(23), and $(14,035)	40 			41,988 			77 			42,814
Less: reclassification adjustment for net losses (gains) included in “Other income (expense), net,” net of tax of $5, $0, $814, and $1,142	(17)			— 			(2,471)			(3,337)
Net change	23 			41,988 			(2,394)			39,477
Other, net of tax of $(1), $1, $0, and $(1)	(3)			1 			(1)			(1)
Total other comprehensive income (loss)	3,334 			41,419 			2,454 			38,057
Comprehensive income	$	21,498 			$	104,066 			$	37,745 			$	130,959
AMAZON.COM, INC.
Segment Information
(in millions)
(unaudited)
Three Months Ended
June 30,		Six Months Ended
June 30,
2025		2026		2025		2026
North America
Net sales	$	100,068 			$	116,177 			$	192,955 			$	220,320
Operating expenses	92,551 			107,054 			179,597 			202,930
Operating income	$	7,517 			$	9,123 			$	13,358 			$	17,390
International
Net sales	$	36,761 			$	42,197 			$	70,274 			$	81,986
Operating expenses	35,267 			40,480 			67,763 			78,845
Operating income	$	1,494 			$	1,717 			$	2,511 			$	3,141
AWS
Net sales	$	30,873 			$	42,232 			$	60,140 			$	79,819
Operating expenses	20,713 			25,611 			38,433 			49,037
Operating income	$	10,160 			$	16,621 			$	21,707 			$	30,782
Consolidated
Net sales	$	167,702 			$	200,606 			$	323,369 			$	382,125
Operating expenses	148,531 			173,145 			285,793 			330,812
Operating income	19,171 			27,461 			37,576 			51,313
Total non-operating income	1,686 			53,396 			4,960 			69,378
Provision for income taxes	(2,678)			(18,199)			(7,231)			(27,759)
Equity-method investment activity, net of tax	(15)			(11)			(14)			(30)
Net income	$	18,164 			$	62,647 			$	35,291 			$	92,902
Segment Highlights:
Y/Y net sales growth:
North America	11 	%		16 	%		9 	%		14 	%
International	16 			15 			10 			17
AWS	17 			37 			17 			33
Consolidated	13 			20 			11 			18
Net sales mix:
North America	60 	%		58 	%		60 	%		58 	%
International	22 			21 			22 			21
AWS	18 			21 			18 			21
Consolidated	100 	%		100 	%		100 	%		100 	%
AMAZON.COM, INC.
Consolidated Balance Sheets
(in millions, except per share data)
December 31, 2025		June 30, 2026
(unaudited)
ASSETS
Current assets:
Cash and cash equivalents	$	86,810 			$	78,213
Marketable securities	36,219 			44,775
Inventories	38,325 			38,184
Accounts receivable, net and other	67,729 			88,092
Total current assets	229,083 			249,264
Property and equipment, net	357,025 			446,046
Operating leases	86,054 			92,743
Goodwill	23,273 			23,504
Other assets	122,607 			284,132
Total assets	$	818,042 			$	1,095,689
LIABILITIES AND STOCKHOLDERS’ EQUITY
Current liabilities:
Accounts payable	$	121,909 			$	147,440
Accrued expenses and other	75,520 			73,406
Unearned revenue	20,576 			20,428
Total current liabilities	218,005 			241,274
Long-term lease liabilities	87,339 			94,338
Long-term debt	65,648 			128,894
Other long-term liabilities	35,985 			79,563
Commitments and contingencies
Stockholders’ equity:
Preferred stock ($0.01 par value; 500 shares authorized; no shares issued or outstanding)	— 			—
Common stock ($0.01 par value; 100,000 shares authorized; 11,246 and 11,298 shares issued; 10,731 and 10,783 shares outstanding)	112 			113
Treasury stock, at cost	(7,837)			(7,837)
Additional paid-in capital	140,024 			149,619
Accumulated other comprehensive income (loss)	28,230 			66,287
Retained earnings	250,536 			343,438
Total stockholders’ equity	411,065 			551,620
Total liabilities and stockholders’ equity	$	818,042 			$	1,095,689
AMAZON.COM, INC.
Supplemental Financial Information and Business Metrics
(in millions, except per share data)
(unaudited)
Q1 2025	Q2 2025	Q3 2025	Q4 2025	Q1 2026	Q2 2026	Y/Y %
Change
Cash Flows and Shares
Operating cash flow -- trailing twelve months (TTM)	$	113,903 		$	121,137 		$	130,691 		$	139,514 		$	148,531 		$	161,403 		33 	%
Operating cash flow -- TTM Y/Y growth	15 	%	12 	%	16 	%	20 	%	30 	%	33 	%	N/A
Purchases of property and equipment, net of proceeds from sales and incentives -- TTM	$	87,978 		$	102,953 		$	115,903 		$	128,320 		$	147,299 		$	169,007 		64 	%
Free cash flow -- TTM (1)	$	25,925 		$	18,184 		$	14,788 		$	11,194 		$	1,232 		$	(7,604)		(142)	%
Common shares and stock-based awards outstanding	10,876 		10,952 		10,955 		10,953 		10,949 		11,027 		1 	%
Common shares outstanding	10,613 		10,660 		10,687 		10,731 		10,754 		10,783 		1 	%
Stock-based awards outstanding	263 		292 		268 		222 		195 		244 		(16)	%
Stock-based awards outstanding -- % of common shares outstanding	2.5 	%	2.7 	%	2.5 	%	2.1 	%	1.8 	%	2.3 	%	N/A
Results of Operations
Worldwide (WW) net sales	$	155,667 		$	167,702 		$	180,169 		$	213,386 		$	181,519 		$	200,606 		20 	%
WW net sales -- Y/Y growth, excluding F/X	10 	%	12 	%	12 	%	12 	%	15 	%	20 	%	N/A
WW net sales -- TTM	$	650,313 		$	670,038 		$	691,330 		$	716,924 		$	742,776 		$	775,680 		16 	%
WW net sales -- TTM Y/Y growth, excluding F/X	11 	%	11 	%	11 	%	12 	%	13 	%	15 	%	N/A
Operating income	$	18,405 		$	19,171 		$	17,422 		$	24,977 		$	23,852 		$	27,461 		43 	%
F/X impact -- favorable (unfavorable)	$	53 		$	153 		$	129 		$	23 		$	(33)		$	(105)		N/A
Operating income -- Y/Y growth (decline), excluding F/X	20 	%	30 	%	(1)	%	18 	%	30 	%	44 	%	N/A
Operating margin -- % of WW net sales	11.8 	%	11.4 	%	9.7 	%	11.7 	%	13.1 	%	13.7 	%	N/A
Operating income -- TTM	$	71,691 		$	76,190 		$	76,201 		$	79,975 		$	85,422 		$	93,712 		23 	%
Operating income -- TTM Y/Y growth, excluding F/X	51 	%	40 	%	25 	%	16 	%	19 	%	23 	%	N/A
Operating margin -- TTM % of WW net sales	11.0 	%	11.4 	%	11.0 	%	11.2 	%	11.5 	%	12.1 	%	N/A
Net income	$	17,127 		$	18,164 		$	21,187 		$	21,192 		$	30,255 		$	62,647 		245 	%
Net income per diluted share	$	1.59 		$	1.68 		$	1.95 		$	1.95 		$	2.78 		$	5.75 		242 	%
Net income -- TTM	$	65,944 		$	70,623 		$	76,482 		$	77,670 		$	90,798 		$	135,281 		92 	%
Net income per diluted share -- TTM	$	6.13 		$	6.55 		$	7.08 		$	7.17 		$	8.37 		$	12.44 		90 	%
______________________________
(1)Free cash flow is cash flow from operations reduced by “Purchases of property and equipment, net of proceeds from sales and incentives.”
AMAZON.COM, INC.
Supplemental Financial Information and Business Metrics
(in millions)
(unaudited)
Q1 2025	Q2 2025	Q3 2025	Q4 2025	Q1 2026	Q2 2026	Y/Y %
Change
Segments
North America Segment:
Net sales	$	92,887 		$	100,068 		$	106,267 		$	127,083 		$	104,143 		$	116,177 		16 	%
Net sales -- Y/Y growth, excluding F/X	8 	%	11 	%	11 	%	10 	%	12 	%	16 	%	N/A
Net sales -- TTM	$	394,043 		$	404,078 		$	414,808 		$	426,305 		$	437,561 		$	453,670 		12 	%
Operating income	$	5,841 		$	7,517 		$	4,789 		$	11,472 		$	8,267 		$	9,123 		21 	%
F/X impact -- unfavorable	$	(32)		$	(46)		$	(53)		$	(73)		$	(41)		$	(6)		N/A
Operating income -- Y/Y growth (decline), excluding F/X	18 	%	49 	%	(14)	%	25 	%	42 	%	21 	%	N/A
Operating margin -- % of North America net sales	6.3 	%	7.5 	%	4.5 	%	9.0 	%	7.9 	%	7.9 	%	N/A
Operating income -- TTM	$	25,825 		$	28,277 		$	27,403 		$	29,619 		$	32,045 		$	33,651 		19 	%
Operating margin -- TTM % of North America net sales	6.6 	%	7.0 	%	6.6 	%	6.9 	%	7.3 	%	7.4 	%	N/A
International Segment:
Net sales	$	33,513 		$	36,761 		$	40,896 		$	50,724 		$	39,789 		$	42,197 		15 	%
Net sales -- Y/Y growth, excluding F/X	8 	%	11 	%	10 	%	11 	%	11 	%	15 	%	N/A
Net sales -- TTM	$	144,484 		$	149,582 		$	154,590 		$	161,894 		$	168,170 		$	173,606 		16 	%
Operating income	$	1,017 		$	1,494 		$	1,199 		$	1,040 		$	1,424 		$	1,717 		15 	%
F/X impact -- favorable (unfavorable)	$	(56)		$	338 		$	302 		$	319 		$	347 		$	(43)		N/A
Operating income -- Y/Y growth (decline), excluding F/X	19 	%	324 	%	(31)	%	(45)	%	6 	%	18 	%	N/A
Operating margin -- % of International net sales	3.0 	%	4.1 	%	2.9 	%	2.1 	%	3.6 	%	4.1 	%	N/A
Operating income -- TTM	$	3,906 		$	5,127 		$	5,025 		$	4,750 		$	5,157 		$	5,380 		5 	%
Operating margin -- TTM % of International net sales	2.7 	%	3.4 	%	3.2 	%	2.9 	%	3.1 	%	3.1 	%	N/A
AWS Segment:
Net sales	$	29,267 		$	30,873 		$	33,006 		$	35,579 		$	37,587 		$	42,232 		37 	%
Net sales -- Y/Y growth, excluding F/X	17 	%	17 	%	20 	%	24 	%	28 	%	37 	%	N/A
Net sales -- TTM	$	111,786 		$	116,378 		$	121,932 		$	128,725 		$	137,045 		$	148,404 		28 	%
Operating income	$	11,547 		$	10,160 		$	11,434 		$	12,465 		$	14,161 		$	16,621 		64 	%
F/X impact -- favorable (unfavorable)	$	141 		$	(139)		$	(120)		$	(223)		$	(339)		$	(56)		N/A
Operating income -- Y/Y growth, excluding F/X	21 	%	10 	%	11 	%	19 	%	26 	%	64 	%	N/A
Operating margin -- % of AWS net sales	39.5 	%	32.9 	%	34.6 	%	35.0 	%	37.7 	%	39.4 	%	N/A
Operating income -- TTM	$	41,960 		$	42,786 		$	43,773 		$	45,606 		$	48,220 		$	54,681 		28 	%
Operating margin -- TTM % of AWS net sales	37.5 	%	36.8 	%	35.9 	%	35.4 	%	35.2 	%	36.8 	%	N/A
AMAZON.COM, INC.
Supplemental Financial Information and Business Metrics
(in millions, except employee data)
(unaudited)
Q1 2025	Q2 2025	Q3 2025	Q4 2025	Q1 2026	Q2 2026	Y/Y %
Change
Net Sales
Online stores (1)	$	57,407 		$	61,485 		$	67,407 		$	82,988 		$	64,254 		$	70,432 		15 	%
Online stores -- Y/Y growth, excluding F/X	6 	%	10 	%	8 	%	8 	%	9 	%	15 	%	N/A
Physical stores (2)	$	5,533 		$	5,595 		$	5,578 		$	5,855 		$	5,785 		$	5,794 		4 	%
Physical stores -- Y/Y growth, excluding F/X	6 	%	7 	%	7 	%	5 	%	4 	%	4 	%	N/A
Third-party seller services (3)	$	36,512 		$	40,348 		$	42,486 		$	52,816 		$	41,578 		$	46,780 		16 	%
Third-party seller services -- Y/Y growth, excluding F/X	7 	%	10 	%	11 	%	10 	%	12 	%	16 	%	N/A
Advertising services (4)	$	13,921 		$	15,694 		$	17,703 		$	21,317 		$	17,243 		$	19,809 		26 	%
Advertising services -- Y/Y growth, excluding F/X	19 	%	22 	%	22 	%	22 	%	22 	%	26 	%	N/A
Subscription services (5)	$	11,715 		$	12,208 		$	12,574 		$	13,122 		$	13,427 		$	13,730 		12 	%
Subscription services -- Y/Y growth, excluding F/X	11 	%	11 	%	10 	%	12 	%	12 	%	12 	%	N/A
AWS	$	29,267 		$	30,873 		$	33,006 		$	35,579 		$	37,587 		$	42,232 		37 	%
AWS -- Y/Y growth, excluding F/X	17 	%	17 	%	20 	%	24 	%	28 	%	37 	%	N/A
Other (6)	$	1,312 		$	1,499 		$	1,415 		$	1,709 		$	1,645 		$	1,829 		22 	%
Other -- Y/Y growth, excluding F/X	4 	%	18 	%	7 	%	7 	%	25 	%	23 	%	N/A
Stock-based Compensation Expense
Cost of sales	$	148 		$	250 		$	197 		$	182 		$	171 		$	208 		(17)	%
Fulfillment	$	497 		$	880 		$	685 		$	641 		$	601 		$	764 		(13)	%
Technology and infrastructure	$	2,060 		$	3,655 		$	2,697 		$	2,459 		$	2,286 		$	3,701 		1 	%
Sales and marketing	$	653 		$	1,207 		$	832 		$	753 		$	663 		$	845 		(30)	%
General and administrative	$	331 		$	542 		$	436 		$	362 		$	311 		$	520 		(4)	%
Total stock-based compensation expense	$	3,689 		$	6,534 		$	4,847 		$	4,397 		$	4,032 		$	6,038 		(8)	%
Other
WW shipping costs	$	22,495 		$	23,370 		$	25,384 		$	31,492 		$	25,709 		$	27,873 		19 	%
WW shipping costs -- Y/Y growth	3 	%	6 	%	8 	%	10 	%	14 	%	19 	%	N/A
WW paid units -- Y/Y growth (7)	8 	%	12 	%	11 	%	12 	%	15 	%	17 	%	N/A
WW seller unit mix -- % of WW paid units (7)	61 	%	62 	%	62 	%	61 	%	60 	%	61 	%	N/A
Employees (full-time and part-time; excludes contractors & temporary personnel)	1,560,000 		1,546,000 		1,578,000 		1,576,000 		1,575,000 		1,595,000 		3 	%
Employees (full-time and part-time; excludes contractors & temporary personnel) -- Y/Y growth	3 	%	1 	%	2 	%	1 	%	1 	%	3 	%	N/A
________________________
(1)Includes product sales and digital media content where we record revenue gross. We leverage our retail infrastructure to offer a wide selection of consumable and durable goods that includes media products available in both a physical and digital format, such as books, videos, games, music, and software. These product sales include digital products sold on a transactional basis. Digital media content subscriptions that provide unlimited viewing or usage rights are included in “Subscription services.”
(2)Includes product sales where our customers physically select items in a store. Sales to customers who order goods online for delivery or pickup at our physical stores are included in “Online stores.”
(3)Includes commissions and any related fulfillment and shipping fees, and other third-party seller services.
(4)Includes sales of advertising services to sellers, vendors, publishers, authors, and others, through programs such as sponsored ads, display, and video advertising.
(5)Includes annual and monthly fees associated with Amazon Prime memberships, as well as digital video, audiobook, digital music, e-book, and other non-AWS subscription services.
(6)Includes sales related to various other offerings (such as shipping services, healthcare services, and certain licensing and distribution of video content) and our co-branded credit card agreements.
(7)Excludes the impact of Whole Foods Market.
Amazon.com, Inc.
Certain Definitions
Customer Accounts
•References to customers mean customer accounts established when a customer places an order through one of our stores. Customer accounts exclude certain customers, including customers associated with certain of our acquisitions, Amazon Payments customers, AWS customers, and the customers of select companies with whom we have a technology alliance or marketing and promotional relationship. Customers are considered active when they have placed an order during the preceding twelve-month period.
Seller Accounts
•References to sellers means seller accounts, which are established when a seller receives an order from a customer account. Sellers are considered active when they have received an order from a customer during the preceding twelve-month period.
AWS Customers
•References to AWS customers mean unique AWS customer accounts, which are unique customer account IDs that are eligible to use AWS services. This includes AWS accounts in the AWS free tier. Multiple users accessing AWS services via one account ID are counted as a single account. Customers are considered active when they have had AWS usage activity during the preceding one-month period.
Units
•References to units mean physical and digital units sold (net of returns and cancellations) by us and sellers in our stores as well as Amazon-owned items sold in other stores. Units sold are paid units and do not include units associated with AWS, certain acquisitions, certain subscriptions, rental businesses, or advertising businesses, or Amazon gift cards.
Contacts:
Amazon Investor Relations	 	Amazon Public Relations
amazon-ir@amazon.com	 	amazon-pr@amazon.com
amazon.com/ir	 	amazon.com/pr

## EX-99 candidate 2

EX-99.2
3
amzn-20260630xex992.htm
EX-99.2
Document
Exhibit 99.2
Non-GAAP Financial Measures
Regulation G, Conditions for Use of Non-GAAP Financial Measures, and other SEC regulations define and prescribe the conditions for use of certain non-GAAP financial information. Free cash flow and the effect of foreign exchange rates on our consolidated statements of operations meet the definition of non-GAAP financial measures.
Our financial focus is on long-term, sustainable growth in free cash flow. We provide a free cash flow measure because we believe it provides additional perspective on the impact of acquiring property and equipment with cash.
Free cash flow is cash flow from operations reduced by “Purchases of property and equipment, net of proceeds from sales and incentives.”
Free cash flow has limitations as it omits certain components of the overall cash flow statement and does not represent the residual cash flow available for discretionary expenditures. For example, free cash flow does not incorporate the portion of payments representing principal reductions of debt or cash payments for business acquisitions. Additionally, our mix of property and equipment acquisitions with cash or other financing options may change over time. Therefore, we believe it is important to view free cash flow only as a complement to our entire consolidated statements of cash flows.
For a quantitative reconciliation of free cash flow to the most directly comparable amounts reported in accordance with GAAP, see “Supplemental Financial Information and Business Metrics” in Exhibit 99.1 to this Current Report on Form 8-K.
The effect on our consolidated statements of operations from changes in foreign exchange rates versus the U.S. Dollar is also a non-GAAP financial measure. Information regarding the effect of foreign exchange rates, versus the U.S. Dollar, on our consolidated statements of operations is provided to show reported period operating results had the foreign exchange rates remained the same as those in effect in the comparable prior year period. We include various measures on both an as-reported basis and a basis showing the effect of changes in foreign exchange rates versus the U.S. Dollar in “Supplemental Financial Information and Business Metrics” in Exhibit 99.1 to this Current Report on Form 8-K.
```
