---
title: "需要复核的事项"
tags: [system, review]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# 需要复核的事项

[[Today Dashboard|今日看板]] · [[14_Reports/Run History Index|运行历史]]

仅展示本次已运行公司的例外；旧结果保存在运行历史。点击证据 ID 可以定位具体数字及计算输入。

## NVDA

- 公司：[[04_Companies/NVDA/Latest Brief|NVDA]]
- 严重程度：section
- 问题：最新季度存在需核对的数据或跨申报计算
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/NVDA/Evidence#^OBS-7de808b2fc8e52e6f485|OBS-7de808b2fc8e52e6f485]]
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/NVDA/Evidence#^OBS-1c16ade3ce2cbeb75c2c|OBS-1c16ade3ce2cbeb75c2c]]
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/NVDA/Evidence#^OBS-b33ce79460f9f75cf216|OBS-b33ce79460f9f75cf216]]

## MSFT

- 公司：[[04_Companies/MSFT/Latest Brief|MSFT]]
- 严重程度：section
- 问题：最新季度存在需核对的数据或跨申报计算
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Evidence#^OBS-09a797e58b97899766e7|OBS-09a797e58b97899766e7]]
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Evidence#^OBS-dceda31853218f62fc73|OBS-dceda31853218f62fc73]]
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Evidence#^OBS-7a8e071b63eefa97d333|OBS-7a8e071b63eefa97d333]]
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Evidence#^OBS-d02f55f0ac12cfcf97b0|OBS-d02f55f0ac12cfcf97b0]]
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Evidence#^OBS-9c38cb4006d2d7bff028|OBS-9c38cb4006d2d7bff028]]
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Evidence#^OBS-afda1b8030465e20d35b|OBS-afda1b8030465e20d35b]]
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Evidence#^OBS-c571568e0d65b592fac6|OBS-c571568e0d65b592fac6]]
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Evidence#^OBS-4a87a14330dcbb9023bc|OBS-4a87a14330dcbb9023bc]]
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Evidence#^OBS-489c19285dd31b7a4df1|OBS-489c19285dd31b7a4df1]]

## GOOGL

- 公司：[[04_Companies/GOOGL/Latest Brief|GOOGL]]
- 严重程度：section
- 问题：最新季度存在需核对的数据或跨申报计算
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-c6abec8b8953a1ab0d29|OBS-c6abec8b8953a1ab0d29]]
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-b062e2a020a5835a7fb4|OBS-b062e2a020a5835a7fb4]]
- 待复核：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-9731ec6c948f3675befd|OBS-9731ec6c948f3675befd]]
