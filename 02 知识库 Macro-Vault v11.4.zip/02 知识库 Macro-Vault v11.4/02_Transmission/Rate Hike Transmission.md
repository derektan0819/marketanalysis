---
title: "Rate Hike Transmission 加息传导"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [加息传导]
tags: [transmission]
---
# Rate Hike Transmission 加息传导

1. Fed raises the federal funds target range 美联储上调联邦基金利率区间
2. Treasury yields rise, short end first 国债收益率上升，短端先动
3. Borrowing costs rise: mortgages, corporate loans, credit cards 借贷成本上升：房贷、企业贷款、信用卡
4. Spending and hiring slow; growth cools 消费和招聘放缓，增长降温
5. Higher discount rate can compress valuations; long-duration growth stocks tend to be more sensitive, but earnings and expectations also matter 折现率上升可能压缩估值；久期长的成长股通常更敏感，但盈利和预期同样重要
6. The dollar often strengthens if US rates rise relative to other countries, but this depends on expectations and on what foreign central banks do (see [[Global Central Banks]]) 如果美国利率相对其他国家上升，美元常常走强，但取决于预期以及外国央行的动作（见 [[Global Central Banks]]）
7. Banks: interest income may rise, but deposit costs and credit losses also rise 银行：利息收入可能上升，但存款成本和信贷损失也上升

## Check 检查
Was the hike expected? Markets mainly react to surprises versus expectations: in the decision itself, the wording, the projections and the signalled path (see [[Market-Implied Rate Expectations]]). 加息是否在预期内？市场主要对相对预期的意外做出反应：包括决定本身、措辞、预测和暗示的路径（见 [[Market-Implied Rate Expectations]]）。

Related: [[Fed and FOMC]], [[Federal Funds Rate]], [[Treasury Yield to Equity Valuation]], [[Yield Curve]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- For each link, identify an observable measure and a source; distinguish direct disclosure from inference.
- Record likely lag and possible offsets (pricing, substitution, inventory, policy, FX, valuation, positioning or capacity).
- Same-day co-movement alone does not prove causation. Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.
