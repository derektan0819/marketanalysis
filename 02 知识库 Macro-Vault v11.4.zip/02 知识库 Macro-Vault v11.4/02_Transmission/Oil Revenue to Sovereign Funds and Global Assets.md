---
title: "Oil Revenue to Sovereign Funds and Global Assets"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [石油收入与主权基金传导]
tags: [transmission, global]
as_of: 2026-10
---
# Oil Revenue to Sovereign Funds and Global Assets

## Chain 传导链
Higher oil price → larger export revenue for oil producers → more surplus invested by sovereign funds and central banks → demand for bonds, equities and property abroad.
油价上升 → 产油国出口收入增加 → 主权基金和央行投资更多盈余 → 对海外债券、股票和房地产的需求上升。

## Conditional mechanisms 条件性机制
- Governments may spend rather than save, so higher revenue does not always mean more foreign buying. 政府可能花掉而不是储蓄。
- Flows go through many channels and are hard to observe in real time. 资金渠道多，难以实时观察。
- Lower oil prices can reverse the effect and cause asset sales or less investment. 油价下跌可能反向。

## Test it 检验
Compare oil prices, producer budgets, announced fund deals and reserve changes over quarters, not days. 以季度而不是天为单位比较。

## Related 相关
[[Sovereign Wealth Funds]], [[Middle East and Oil Exporters]], [[WTI and Brent Crude]], [[Foreign Exchange Reserves and Reserve Currencies]], [[US Treasury Market]], [[Oil Price Transmission]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Transmission is conditional; same-day co-movement does not prove cause. Name an alternative explanation. as_of: 2026-10.
- Verify current policy and data against primary sources before relying on any link in this chain.

- Educational background, not investment advice.
