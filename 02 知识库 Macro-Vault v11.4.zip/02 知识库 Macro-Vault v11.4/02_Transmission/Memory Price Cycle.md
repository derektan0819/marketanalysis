---
title: "Memory Price Cycle 存储价格周期"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [存储价格周期]
tags: [transmission]
---
# Memory Price Cycle 存储价格周期

1. Demand rises or supply is cut, so contract prices rise 需求上升或供给削减，合约价上涨
2. Customer and supplier inventories fall 客户和供应商库存下降
3. Memory makers' margins expand sharply 存储厂商利润率大幅扩张
4. High profits lead to capex and capacity expansion 高利润带来资本开支和扩产
5. Supply catches up and prices fall; inventories build 供给追上来，价格下跌，库存堆积
6. Margins compress, capex is cut, and the cycle resets 利润率收缩，削减资本开支，周期重置

## Check 检查
HBM may behave differently from commodity DRAM because of qualification and longer contracts. HBM 因认证流程和较长合约，走势可能与普通 DRAM 不同。

Related: [[Memory Chips]], [[DRAM Contract Prices]], [[Inventory Cycle]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- For each link, identify an observable measure and a source; distinguish direct disclosure from inference.
- Record likely lag and possible offsets (pricing, substitution, inventory, policy, FX, valuation, positioning or capacity).
- Same-day co-movement alone does not prove causation. Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.


See also: [[Korea Memory Stocks and US Chip Stocks]], [[Korea Semiconductor Exports]]
