---
title: "Tariffs to Prices and Earnings"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [关税传导]
tags: [transmission, global]
as_of: 2026-10
---
# Tariffs to Prices and Earnings

## Chain 传导链
New tariff → import prices and costs change → company margins and consumer prices adjust → inflation expectations, rates and equity valuations react.
新关税 → 进口价格和成本变化 → 企业利润和消费价格调整 → 通胀预期、利率和股票估值做出反应。

## Conditional mechanisms 条件性机制
- Pass-through depends on pricing power, substitutes and inventories; some costs are absorbed in margins first. 传导取决于定价能力、替代品和库存。
- Exemptions and delays can make the effective rate lower than announced. 豁免和延期使实际税率低于公布税率。
- Currency moves and rerouted trade can offset part of the effect. 汇率和贸易转道可部分抵消。
- Retaliation can hit exporters. 报复措施可能冲击出口商。

## Test it 检验
Compare the effective tariff rate (customs data), import prices, company commentary on margins and core goods inflation over several months. 比较有效税率、进口价格、企业利润率说明和核心商品通胀。

## Related 相关
[[Trade Tariffs and Supply Chains]], [[Export Controls and Tariffs]], [[Inflation Surprise Transmission]], [[Exchange Rate]], [[Consumer Staples and Discretionary]], [[Industrials and Defense]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Transmission is conditional; same-day co-movement does not prove cause. Name an alternative explanation. as_of: 2026-10.
- Verify current policy and data against primary sources before relying on any link in this chain.

- Educational background, not investment advice.
