---
title: "Korea Memory Stocks and US Chip Stocks 韩国内存股与美国芯片股传导"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [韩国内存股与美国芯片股传导]
tags: [transmission]
as_of: 2026-10
---
# Korea Memory Stocks and US Chip Stocks 韩国内存股与美国芯片股传导

## US → Korea (next Korean session) 美国 → 韩国（下一个韩国交易时段）
1. A US event moves US memory or chip stocks (Micron results, Nvidia news, hyperscaler capex, SOX move) 美国事件推动美国内存或芯片股（美光业绩、英伟达消息、云厂商资本开支、SOX 波动）
2. The Korean market opens after the US close and prices that information into Samsung Electronics and SK Hynix 韩国市场在美股收盘后开盘，把这些信息反映到三星电子和 SK 海力士上
3. Because these stocks are heavy in KOSPI, the index moves with them 因为这两只股票在 KOSPI 中权重大，指数随之变动
4. Foreign flows and the won can amplify or offset the move 外资流向和韩元可能放大或抵消这个变动

## Korea → US (US session) 韩国 → 美国（美国交易时段）
1. A Korean event occurs: preliminary earnings, exports data, HBM or capacity news, shareholder-return announcement 韩国发生事件：初步业绩、出口数据、HBM 或产能消息、股东回报公告
2. Korean stocks react first, during the Asian session 韩国股票在亚洲时段先做出反应
3. US memory and chip stocks (Micron, SOX constituents, equipment makers) may react in the US session if the news changes expectations for memory prices, supply or demand 如果消息改变了对内存价格、供给或需求的预期，美国内存和芯片股（美光、SOX 成分股、设备商）可能在美股时段做出反应
4. Whether the news is new, or already priced in, decides the size of the reaction 消息是新的还是已经被定价，决定反应的大小

## Check 检查
Was the news a surprise against a named-provider consensus, and did the US stock already move on the same information before the Korean news? Compare timestamps in one time zone. 消息相对有来源的一致预期是否是意外？美股是否在韩国消息之前就已经因同样的信息波动？把时间统一换算到同一时区比较。

Related: [[Korea Market and KOSPI]], [[Memory Chips]], [[Memory Price Cycle]], [[Hyperscaler Capex to Chip Chain]], [[Chip Earnings to AI Stocks]], [[Priced In]], [[Consensus and Expectations]], [[Case Study Samsung Q3 2026 Preliminary Earnings]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- Korean and US sessions do not overlap; same-day co-movement across the two can reflect separate drivers (the won, oil, US rates, regional flows).
- Samsung and SK Hynix also have non-memory businesses and company-specific issues (shareholder returns, consumer electronics); do not attribute every move to memory prices.
- Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.
