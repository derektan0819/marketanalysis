---
title: "Dollar and Real Yields to Gold and Crypto 美元与实际收益率到黄金和加密"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [美元与实际收益率传导, Dollar real yield gold crypto]
tags: [transmission, cross-asset]
as_of: 2026-10
---
# Dollar and Real Yields to Gold and Crypto 美元与实际收益率到黄金和加密

## Chain 传导链
Fed path or inflation news → real yields and the dollar move → gold and crypto reprice → equities and credit react to the same shift.
美联储路径或通胀消息 → 实际收益率和美元变动 → 黄金与加密重新定价 → 股票和信用对同一变化做出反应。

## Conditional mechanisms 条件性机制
- **Higher real yields** raise the opportunity cost of holding assets that pay no income, which tends to pressure gold and crypto. 实际收益率上升提高持有无收益资产的机会成本。
- **A stronger dollar** makes dollar-priced assets more expensive for non-US buyers. 美元走强使美元计价资产对非美国买家更贵。
- **Offsets.** Safe-haven demand, central-bank buying (gold) or ETF inflows and crypto-specific news can outweigh the rate effect. 避险需求、央行购金、ETF 流入等可抵消。
- **Different drivers.** Gold and crypto often move on different drivers; the same day's rise in both does not mean one story explains both. 黄金与加密的驱动因素常不同。

## Test it 检验
Check whether real yields, DXY, gold and Bitcoin moved in the expected directions over the same window and whether any single announcement explains it. Treat the answer as a hypothesis. Related: [[Real Interest Rates]], [[Gold]], [[DXY]], [[Bitcoin and Ether Price]], [[Gold Price]], [[Crypto and Macro Linkages]], [[Fed Decision to Markets]].

## Evidence and limitations / 证据与限制
- Correlations between these assets change over time and can reverse; use recent dated data, not memory.
- Same-day co-movement does not prove cause. Name the alternative explanation in the report.
- Educational background, not investment advice.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Real Yields and Breakevens|实际利率、盈亏平衡通胀和期限溢价]]：同样是 10 年收益率上涨，背后的原因可能完全不同。
- [[21_US_Treasuries/Treasury Cross Asset Transmission|美债怎样影响股票、银行、房产、美元和黄金]]：先找收益率变化的来源，再分别解释估值、经营与融资。
