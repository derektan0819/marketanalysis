---
title: "Earnings to Market Transmission 财报传导"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [财报传导]
tags: [transmission]
---
# Earnings to Market Transmission 财报传导

1. Company reports vs analyst expectations 公司财报对比分析师预期
2. Guidance and margin trends often matter more than the headline 指引和利润率趋势往往比表面数字重要
3. Stock reprices; peers and the sector reprice on read-across 股价重估；同行和板块因关联而重估
4. Large banks or index heavyweights can move the index 大型银行或权重股可影响指数
5. Credit view shifts: debt capacity, spreads, provisions 信用判断变化：偿债能力、利差、拨备

Use template: [[Company Earnings Analysis]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- For each link, identify an observable measure and a source; distinguish direct disclosure from inference.
- Record likely lag and possible offsets (pricing, substitution, inventory, policy, FX, valuation, positioning or capacity).
- Same-day co-movement alone does not prove causation. Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.
