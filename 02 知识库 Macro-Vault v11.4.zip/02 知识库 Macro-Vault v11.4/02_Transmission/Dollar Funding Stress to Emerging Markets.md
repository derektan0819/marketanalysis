---
title: "Dollar Funding Stress to Emerging Markets"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [美元融资压力传导]
tags: [transmission, global]
as_of: 2026-10
---
# Dollar Funding Stress to Emerging Markets

## Chain 传导链
Dollar rises and US rates rise → debt in dollars becomes more expensive to service → capital leaves emerging markets → local currencies and bonds fall, which raises stress further.
美元走强、美国利率上升 → 美元债务偿还成本上升 → 资本流出新兴市场 → 本币和债券下跌，压力进一步加大。

## Conditional mechanisms 条件性机制
- Exposure differs: countries with large dollar debt, small reserves or big current-account deficits are more vulnerable. 美元债多、储备少、经常账户赤字大的国家更脆弱。
- Local factors can protect or worsen the effect, such as credible central banks or political risk. 本地因素可能缓冲或加剧。
- Central banks may raise rates or use reserves to defend their currencies ([[FX Intervention and Currency Regimes]]). 央行可能加息或动用储备。

## Test it 检验
Compare DXY, US yields, EM currency indices, reserves, and spreads on EM dollar bonds over the same window. 比较美元指数、美债收益率、新兴市场货币、储备和美元债利差。

## Related 相关
[[Emerging Markets Overview]], [[DXY]], [[Foreign Exchange Reserves and Reserve Currencies]], [[Exchange Rate]], [[Strong USD to US Multinationals]], [[Global Central Banks]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Transmission is conditional; same-day co-movement does not prove cause. Name an alternative explanation. as_of: 2026-10.
- Verify current policy and data against primary sources before relying on any link in this chain.

- Educational background, not investment advice.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Cross Asset Transmission|美债怎样影响股票、银行、房产、美元和黄金]]：先找收益率变化的来源，再分别解释估值、经营与融资。
