---
title: "Bank Capital Rules to Bank Earnings 银行资本规则传导"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [银行资本规则传导到银行盈利]
tags: [transmission]
as_of: 2026-10
---
# Bank Capital Rules to Bank Earnings 银行资本规则传导

1. Regulators set minimum capital and liquidity requirements (see [[Basel III and Capital Ratios]], [[Liquidity Rules LCR and NSFR]]) 监管机构设定最低资本和流动性要求
2. Stress tests set a bank-specific buffer on top of the minimum (see [[Stress Tests and Capital Buffers]]) 压力测试在最低要求之上设定银行专属缓冲
3. Higher requirements mean banks hold more capital per dollar of risk, which can lower returns on equity or reduce lending to riskier borrowers 要求提高意味着每单位风险需持有更多资本，可能降低股本回报或减少对高风险借款人的放贷
4. Surplus capital above requirements can fund dividends and buybacks (see [[Share Buybacks and Dividends]]) 超过要求的盈余资本可用于股息和回购
5. Rule changes (tighter or looser) change how much a bank can return to shareholders and how it prices loans 规则变化（收紧或放松）会改变银行能向股东回馈多少，以及如何给贷款定价
6. Market reaction depends on the surprise versus what was expected (see [[Consensus and Expectations]]) 市场反应取决于相对预期的意外程度

## Check 检查
Compare reported CET1 against the bank's requirement, not only against the headline minimum. Check the bank's own disclosure of its buffer and capital plans.
将报告的 CET1 与该银行自身的要求对比，而不只是与最低标准对比。查看银行自己披露的缓冲和资本计划。

Related: [[Bank Metrics]], [[US Banks]], [[Bank Earnings to Market]], [[Dodd-Frank and Volcker Rule]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- Rule proposals, final rules and effective dates differ; record which stage a rule is at and its source.
- Same-day co-movement alone does not prove causation. Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.
