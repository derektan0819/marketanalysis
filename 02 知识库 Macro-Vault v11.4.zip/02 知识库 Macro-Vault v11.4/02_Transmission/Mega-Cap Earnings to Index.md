---
title: "Mega-Cap Earnings to Index 超大市值传导"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [超大市值财报传导到指数]
tags: [transmission]
---
# Mega-Cap Earnings to Index 超大市值传导

1. A mega-cap reports; the stock moves after hours 超大市值公司公布财报；盘后股价变动
2. Contribution to the index is roughly weight times return 对指数的贡献约等于权重乘以涨跌幅
3. Passive funds and ETFs amplify moves in the largest names 被动资金和 ETF 放大最大公司的波动
4. Sector peers and suppliers reprice on read-across 同行和供应商因关联传导而重估
5. Sentiment spills into the Nasdaq and related ETFs 情绪扩散到纳斯达克和相关 ETF
6. If breadth is narrow, the index becomes fragile to the next mega-cap miss 若市场广度很窄，下一次超大市值公司业绩不及预期时指数会很脆弱

## Check 检查
Hypothetical arithmetic: a stock with a 10% index weight rising 3% adds roughly 0.3 points to the index, other things equal. 假设性算术：权重 10% 的股票上涨 3%，在其他条件不变时约为指数贡献 0.3 个百分点。

Related: [[Index Weighting and Concentration]], [[Passive Flows and ETFs]], [[Market Breadth]], [[US Big Tech]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- For each link, identify an observable measure and a source; distinguish direct disclosure from inference.
- Record likely lag and possible offsets (pricing, substitution, inventory, policy, FX, valuation, positioning or capacity).
- Same-day co-movement alone does not prove causation. Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.
