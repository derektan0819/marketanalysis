---
title: "Fed Decision to Markets 联储决议传导"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [联储决议传导到市场]
tags: [transmission]
---
# Fed Decision to Markets 联储决议传导

1. Before: market pricing (fed funds futures) sets the baseline 决议前：市场定价（联邦基金期货）是基准
2. Statement: wording changes versus the last statement 声明：与上次相比的措辞变化
3. Dot plot and projections (quarterly) 点阵图和预测（每季度）
4. Press conference tone 记者会语气
5. Repricing: 2-year yield reacts most, then 10-year, dollar, equities, credit 重新定价：2 年期收益率反应最大，然后是 10 年期、美元、股票和信用债
6. Sectors: banks, housing, growth tech respond differently 板块：银行、房地产、成长科技反应各不相同

## Check 检查
Hawkish or dovish is always relative to expectations. 偏鹰或偏鸽永远是相对预期而言。

Related: [[Fed and FOMC]], [[Fed Day Playbook]], [[US Treasury Market]], [[Federal Funds Rate]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- For each link, identify an observable measure and a source; distinguish direct disclosure from inference.
- Record likely lag and possible offsets (pricing, substitution, inventory, policy, FX, valuation, positioning or capacity).
- Same-day co-movement alone does not prove causation. Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.
