---
title: "Yen Carry Unwind to Global Risk Assets 日元套利交易平仓到全球风险资产"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [日元套利平仓传导, Carry unwind]
tags: [transmission, fx]
as_of: 2026-10
---
# Yen Carry Unwind to Global Risk Assets 日元套利交易平仓到全球风险资产

## Chain 传导链
Japanese policy tightening, narrower rate gap or a risk shock → yen strengthens fast → investors who borrowed yen to buy higher-yielding assets close positions → selling in equities, crypto and emerging-market currencies.
日本政策收紧、利差收窄或风险冲击 → 日元快速走强 → 借日元买高收益资产的投资者平仓 → 股票、加密货币和新兴市场货币被抛售。

## Conditional mechanisms 条件性机制
- Size and speed matter: a slow yen rise is usually absorbed; a sharp one can force liquidation. 幅度和速度很重要。
- Crypto trades 24/7 and uses leverage, so it can show stress while other markets are closed ([[Crypto Leverage and Liquidations]]). 加密市场全天候交易，压力可能先出现。
- Authorities may intervene; this can cause a sudden yen move without any change in fundamentals ([[FX Intervention and Currency Regimes]]). 干预可能造成突发的日元波动。

## Test it 检验
Compare USD/JPY, Nikkei, US index futures and Bitcoin over the same UTC window; check whether the yen move came first. Related: [[Yen and Carry Trade]], [[USD-JPY]], [[Global Equity Indices]], [[Risk-On Risk-Off]], [[Global Rates Spillover to US Markets]].

## Evidence and limitations / 证据与限制
- Size of carry positions is not directly observable; positioning data (for example [[Source Registry]] CFTC) is delayed and partial.
- A yen rise does not by itself prove a carry unwind. Name the alternative explanation.
- Educational background, not investment advice.
