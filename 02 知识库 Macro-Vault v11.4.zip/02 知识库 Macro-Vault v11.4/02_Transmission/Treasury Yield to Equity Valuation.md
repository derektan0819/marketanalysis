---
title: "Treasury Yield to Equity Valuation 国债收益率传导到估值"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [国债收益率传导到股票估值]
tags: [transmission]
---
# Treasury Yield to Equity Valuation 国债收益率传导到估值

## 为什么会影响估值

当投资者要求的无风险回报上升、公司未来现金流预期不变时，需要用更高折现率把远期收入换算成今天的价值，因此愿意支付的估值可能降低。较远期的现金流通常更敏感，但实际结果也取决于股权风险溢价。

如果利率上升同时反映增长改善，盈利上调可能抵消估值压力。先查实际收益率、通胀补偿和盈利预期；不能直接把“增长驱动”判为总是良性，也不能把所有涨息都当成同一种冲击。

## 后续怎样影响经营

新发债或需要续借的公司可能遇到更高融资成本，利息费用随后增加，影响利润与现金；存量长期固定票息、现金充足或有对冲的公司，短期影响可能较小。房贷还取决于 MBS 与贷款利差；REITs 还要看租金与再融资日期。

银行所持旧债可能出现市值损失，但新贷款收益、存款成本和信用损失也同时变化。评估净影响应读取资产负债数据，不把单一债券浮亏等同于整体盈利结果。

Related: [[US 10-Year Treasury Yield]], [[Valuation Multiples]], [[US Treasury Market]], [[Sector Rotation]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- For each link, identify an observable measure and a source; distinguish direct disclosure from inference.
- Record likely lag and possible offsets (pricing, substitution, inventory, policy, FX, valuation, positioning or capacity).
- Same-day co-movement alone does not prove causation. Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Cross Asset Transmission|美债怎样影响股票、银行、房产、美元和黄金]]：先找收益率变化的来源，再分别解释估值、经营与融资。
