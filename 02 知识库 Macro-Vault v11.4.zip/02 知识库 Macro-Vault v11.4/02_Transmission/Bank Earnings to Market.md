---
title: "Bank Earnings to Market 银行财报传导"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [银行财报传导到市场]
tags: [transmission]
---
# Bank Earnings to Market 银行财报传导

1. Net interest income and margin follow the Fed path and deposit costs 净利息收入和息差随美联储路径和存款成本变化
2. Loan growth shows credit demand 贷款增长反映信贷需求
3. Charge-offs and provisions signal consumer and corporate health 核销和拨备反映消费者和企业状况
4. Investment banking and trading revenue show market activity 投行和交易收入反映市场活跃度
5. Capital (CET1), buybacks and dividends, helped by Fed stress tests 资本充足率、回购和股息，受美联储压力测试影响
6. Big banks report first in earnings season, so their commentary sets the tone for the economy 大银行在财报季最先公布，其评论为经济定下基调

## Check 检查
Compare NII guidance, credit costs and loan growth against expectations. 将净利息收入指引、信贷成本和贷款增长与预期比较。

Related: [[Bank Metrics]], [[US Banks]], [[Fed Decision to Markets]], [[Earnings Season]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- For each link, identify an observable measure and a source; distinguish direct disclosure from inference.
- Record likely lag and possible offsets (pricing, substitution, inventory, policy, FX, valuation, positioning or capacity).
- Same-day co-movement alone does not prove causation. Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.
