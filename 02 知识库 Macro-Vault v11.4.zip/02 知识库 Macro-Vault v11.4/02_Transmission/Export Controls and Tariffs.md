---
title: "Export Controls and Tariffs 出口管制与关税传导"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [出口管制与关税传导]
tags: [transmission]
---
# Export Controls and Tariffs 出口管制与关税传导

1. Government announces controls or tariffs 政府宣布管制或关税
2. Immediate: affected firms lose addressable market or face higher costs; stocks reprice 即时：受影响公司失去部分市场或成本上升，股价重估
3. Customers pre-buy or reroute supply chains 客户提前采购或重新规划供应链
4. Relocation creates winners and losers across Asian supply-chain hubs and US customers 产业转移在亚洲供应链枢纽和美国客户之间产生赢家和输家
5. Retaliation risk; currency and risk sentiment shift 报复风险；汇率和风险情绪变化

## Check 检查
Scope, exemptions and effective dates decide the real impact. 范围、豁免和生效日期决定真实影响。

Related: [[Geopolitics and Export Controls]], [[Semiconductor Equipment]], [[AI Value Chain]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- For each link, identify an observable measure and a source; distinguish direct disclosure from inference.
- Record likely lag and possible offsets (pricing, substitution, inventory, policy, FX, valuation, positioning or capacity).
- Same-day co-movement alone does not prove causation. Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.
