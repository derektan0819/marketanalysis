---
title: "China Policy to Commodities and Asia"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [中国政策传导]
tags: [transmission, global]
as_of: 2026-10
---
# China Policy to Commodities and Asia

## Chain 传导链
China stimulus or easing → expected domestic demand rises → copper, iron ore and oil demand expectations → Asian exports, currencies and equities.
中国刺激或放松 → 国内需求预期上升 → 铜、铁矿石和石油需求预期 → 亚洲出口、货币和股票。

## Conditional mechanisms 条件性机制
- The size and type of stimulus matter: property support, infrastructure and consumer support affect different commodities. 刺激的规模和类型不同，影响的商品不同。
- Announcements can lift prices before real demand shows. 公告可能先推升价格，实际需求未必跟上。
- The renminbi and regional currencies react to policy and capital flows ([[USD-CNH]]). 人民币和区域货币对政策和资本流动做出反应。

## Test it 检验
Check official activity data, credit growth and physical indicators such as inventories against the price move. 对照官方活动数据、信贷增长和库存。

## Related 相关
[[China Economy and Policy]], [[China Official PMI and Activity Data]], [[Copper Price]], [[Commodity Prices]], [[Emerging Markets Overview]], [[Global Equity Indices]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Transmission is conditional; same-day co-movement does not prove cause. Name an alternative explanation. as_of: 2026-10.
- Verify current policy and data against primary sources before relying on any link in this chain.

- Educational background, not investment advice.
