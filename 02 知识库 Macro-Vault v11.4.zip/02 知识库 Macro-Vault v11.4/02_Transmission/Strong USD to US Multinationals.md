---
title: "Strong USD to US Multinationals 强美元传导"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [强美元对美国跨国公司的传导]
tags: [transmission]
---
# Strong USD to US Multinationals 强美元传导

1. Dollar strengthens (higher US rates or risk-off) 美元走强（美国利率较高或避险）
2. Overseas revenue translates into fewer dollars 海外收入折算成美元后减少
3. US exporters become less competitive 美国出口商竞争力下降
4. USD-priced commodities come under pressure 以美元计价的大宗商品承压
5. Emerging markets with USD debt are strained, tightening global conditions 持有美元债务的新兴市场承压，全球金融环境收紧
6. Companies flag currency headwinds in guidance 公司在指引中提示汇率逆风

## Check 检查
Check how much of each company's sales is outside the US. 检查每家公司有多少销售来自美国以外。

Related: [[DXY]], [[Exchange Rate]], [[Guidance]], [[Federal Funds Rate]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- For each link, identify an observable measure and a source; distinguish direct disclosure from inference.
- Record likely lag and possible offsets (pricing, substitution, inventory, policy, FX, valuation, positioning or capacity).
- Same-day co-movement alone does not prove causation. Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.
