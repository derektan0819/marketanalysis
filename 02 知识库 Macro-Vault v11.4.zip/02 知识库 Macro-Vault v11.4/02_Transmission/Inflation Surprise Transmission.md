---
title: "Inflation Surprise Transmission 通胀超预期传导"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [通胀超预期传导]
tags: [transmission]
---
# Inflation Surprise Transmission 通胀超预期传导

1. CPI comes in above forecast CPI 高于预期
2. Markets raise expected rate path 市场上调利率预期
3. Short-term yields jump; curve may flatten or invert 短端收益率跳升，曲线可能变平或倒挂
4. Bond prices fall; growth and long-duration stocks fall 债券下跌，成长股和长久期资产下跌
5. Currency tends to strengthen on rate expectations 货币因利率预期走强
6. Companies: input costs up, margins squeezed unless prices passed on 企业：成本上升，除非转嫁否则利润率受压

Related: [[CPI]], [[Inflation]], [[Monetary Policy]], [[Yield Curve]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- For each link, identify an observable measure and a source; distinguish direct disclosure from inference.
- Record likely lag and possible offsets (pricing, substitution, inventory, policy, FX, valuation, positioning or capacity).
- Same-day co-movement alone does not prove causation. Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.
