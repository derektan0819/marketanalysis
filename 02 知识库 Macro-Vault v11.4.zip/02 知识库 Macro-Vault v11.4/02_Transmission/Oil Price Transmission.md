---
title: "Oil Price Transmission 油价传导"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [油价传导]
tags: [transmission]
---
# Oil Price Transmission 油价传导

1. Oil price rises (supply cuts, geopolitics or demand) 油价上涨（减产、地缘政治或需求）
2. Gasoline prices and headline CPI rise 汽油价格和整体 CPI 上升
3. Consumers have less to spend elsewhere 消费者其他支出减少
4. Energy producers' earnings rise; airlines and transport costs rise 能源生产商盈利上升；航空和运输成本上升
5. Inflation expectations and rate expectations shift 通胀预期和利率预期变化

## Check 检查
Check whether the rise is demand-driven (growth positive) or supply-driven (growth negative). 判断上涨是需求驱动（利好增长）还是供给驱动（利空增长）。

Related: [[Commodity Prices]], [[CPI]], [[Inflation]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- For each link, identify an observable measure and a source; distinguish direct disclosure from inference.
- Record likely lag and possible offsets (pricing, substitution, inventory, policy, FX, valuation, positioning or capacity).
- Same-day co-movement alone does not prove causation. Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.
