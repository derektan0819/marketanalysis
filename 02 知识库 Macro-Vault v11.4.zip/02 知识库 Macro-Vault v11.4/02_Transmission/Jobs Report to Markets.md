---
title: "Jobs Report to Markets 就业报告传导"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [就业报告传导到市场]
tags: [transmission]
---
# Jobs Report to Markets 就业报告传导

1. Nonfarm payrolls, unemployment and wages come out versus consensus 非农、失业率和工资数据对比一致预期公布
2. Rate expectations reprice 利率预期重新定价
3. Treasury yields and the dollar move 国债收益率和美元变动
4. Equities react depending on the regime: if inflation is the worry, strong jobs can mean higher yields and falling stocks; if growth is the worry, strong jobs can lift stocks 股市反应取决于当前主题：若担心通胀，强劲就业可能意味着收益率上升、股市下跌；若担心增长，强劲就业可能提振股市
5. Sector effects: consumer, housing and banks respond to the growth and rate message 板块影响：消费、房地产和银行对增长与利率信号反应不同

## Check 检查
Check revisions to prior months and wage growth, not only the headline. 要看前几个月的修正值和工资增速，不只是总数。

Related: [[Nonfarm Payrolls]], [[Unemployment Rate]], [[Jobless Claims]], [[Fed Decision to Markets]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- For each link, identify an observable measure and a source; distinguish direct disclosure from inference.
- Record likely lag and possible offsets (pricing, substitution, inventory, policy, FX, valuation, positioning or capacity).
- Same-day co-movement alone does not prove causation. Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.
