---
title: "Global Rates Spillover to US Markets 全球利率外溢"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [全球利率外溢到美国市场]
tags: [transmission]
as_of: 2026-10
---
# Global Rates Spillover to US Markets 全球利率外溢

1. A foreign central bank changes policy or signals a change (for example the BOJ or ECB) 外国央行改变政策或释放信号（如日本央行或欧洲央行）
2. Foreign government bond yields move 外国国债收益率变动
3. Rate gaps versus the US change, moving currencies (yen, euro, dollar) 与美国的利差变化，推动汇率（日元、欧元、美元）
4. Foreign investors may shift money between local bonds and US Treasuries 外国投资者可能在本国债券与美国国债之间调整
5. US Treasury yields and the dollar move; valuations and risk appetite follow 美国国债收益率和美元变动，估值和风险偏好随之变化
6. If leveraged carry positions are unwound, equities, credit and volatility can move together 如果杠杆套息仓位被平仓，股票、信用和波动率可能同时变动

## Check 检查
Did US yields move because of US data or because foreign yields moved first? Compare timing across markets. 美国收益率的变动是因为美国数据，还是海外收益率先动？比较各市场的时间先后。

Related: [[Global Central Banks]], [[Yen and Carry Trade]], [[Exchange Rate]], [[US Treasury Market]], [[DXY]], [[Risk-On Risk-Off]]

## Evidence, lag and failure conditions / 证据、时滞与失效条件
- Treat the chain as a hypothesis to test, not an automatic causal law.
- Same-day co-movement across markets can come from a common driver; do not assume foreign yields caused the US move.
- Include at least one alternative explanation and one invalidation signal in a live report.
- Use [[Citation and Evidence Standard]] for current factual claims.
