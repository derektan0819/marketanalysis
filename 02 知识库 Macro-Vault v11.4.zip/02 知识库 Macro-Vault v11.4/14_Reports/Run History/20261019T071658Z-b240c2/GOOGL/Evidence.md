---
title: "GOOGL — 本次数据与原文证据（运行 20261019T071658Z-b240c2）"
tags: [reports, run-history, evidence]
created: 2026-10-19
updated: 2026-10-19
source: "引擎运行 20261019T071658Z-b240c2 的数据快照 12_Data/Companies/GOOGL/20261019T071658Z-b240c2.json"
---
# GOOGL — 本次数据与原文证据

资料截止：2026-10-19T07:16:58+00:00。

[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Brief|本次简报]] · [[04_Companies/GOOGL/Company Profile|GOOGL 档案]] · [[04_Companies/GOOGL/Latest Brief|最新简报]] · [[04_Companies/GOOGL/GOOGL - Data History|八季数据]] · [[04_Companies/GOOGL/Evidence Index|证据索引]] · [[04_Companies/GOOGL/Current Thesis|当前判断]] · [[04_Companies/GOOGL/Thesis History|判断历史]]

本页是保存快照的阅读视图；链接表示引用或计算依赖，不表示独立验证或因果关系。
包含最近八季的观察值，以及计算所需的较早输入。后续运行各自生成证据页，旧简报不会跳到新快照。

## 原始快照
[[12_Data/Companies/GOOGL/20261019T071658Z-b240c2.json|JSON 快照（外部编辑器）]]

## 财报原文
- [[13_Sources/Records/SRC-76097bd5d0676a2af912246a|10-Q]]；期间／事件日：2026-06-30
  提取正文：[[13_Sources/Raw/SRC-76097bd5d0676a2af912246a|SRC-76097bd5d0676a2af912246a 正文]]
- [[13_Sources/Records/SRC-a7294589a5aaa86bbd9cc776|10-K]]；期间／事件日：2025-12-31
  提取正文：[[13_Sources/Raw/SRC-a7294589a5aaa86bbd9cc776|SRC-a7294589a5aaa86bbd9cc776 正文]]
- [[13_Sources/Records/SRC-989578e077b325a53283a75a|earnings_release_8K]]；期间／事件日：2026-07-22
  提取正文：[[13_Sources/Raw/SRC-989578e077b325a53283a75a.earnings|SRC-989578e077b325a53283a75a 正文]]

## 数字与计算依赖

### capex_cash · 2024-06-30 · ytd

**25.198 B USD**；状态：source_recorded。证据 ID：OBS-bf29f5007b08ee5b4214。

^OBS-bf29f5007b08ee5b4214

期间：2024-01-01 → 2024-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000062。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2025-07-24。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000062/0001652044-25-000062-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### operating_cash_flow · 2024-06-30 · ytd

**55.488 B USD**；状态：source_recorded。证据 ID：OBS-2dd024115abf11e67742。

^OBS-2dd024115abf11e67742

期间：2024-01-01 → 2024-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000062。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-07-24。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000062/0001652044-25-000062-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### assets · 2024-09-30 · instant

**430.266 B USD**；状态：source_recorded。证据 ID：OBS-92f7e37d75844d517578。

^OBS-92f7e37d75844d517578

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-24-000118。
字段：`Assets`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204424000118/0001652044-24-000118-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2024-09-30 · quarter

**13.061 B USD**；状态：needs_review。证据 ID：OBS-8993c095a3d851216a06。

^OBS-8993c095a3d851216a06

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-0ddd7cbb64e771ba8f98|OBS-0ddd7cbb64e771ba8f98]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-bf29f5007b08ee5b4214|OBS-bf29f5007b08ee5b4214]]

### capex_cash · 2024-09-30 · ytd

**38.259 B USD**；状态：source_recorded。证据 ID：OBS-0ddd7cbb64e771ba8f98。

^OBS-0ddd7cbb64e771ba8f98

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### cash · 2024-09-30 · instant

**19.959 B USD**；状态：source_recorded。证据 ID：OBS-a837083995c4f71a46fc。

^OBS-a837083995c4f71a46fc

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-24-000118。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204424000118/0001652044-24-000118-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2024-09-30 · quarter

**2.120 USD/shares**；状态：source_recorded。证据 ID：OBS-f2f34eb22a3367faf0cb。

^OBS-f2f34eb22a3367faf0cb

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`EarningsPerShareDiluted`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2024-09-30 · quarter

**12,419.00 M shares**；状态：source_recorded。证据 ID：OBS-e635bc3f78e571fff4ad。

^OBS-e635bc3f78e571fff4ad

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2024-09-30 · instant

**314.119 B USD**；状态：source_recorded。证据 ID：OBS-1e3e98bc53a6ef3f13a3。

^OBS-1e3e98bc53a6ef3f13a3

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`StockholdersEquity`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2024-09-30 · quarter

**17.637 B USD**；状态：needs_review。证据 ID：OBS-87d96f3486fe4c8ec49a。

^OBS-87d96f3486fe4c8ec49a

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-8a75025929a835ecf586|OBS-8a75025929a835ecf586]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-8993c095a3d851216a06|OBS-8993c095a3d851216a06]]

### liabilities · 2024-09-30 · instant

**116.147 B USD**；状态：source_recorded。证据 ID：OBS-fc4e5160431ce83d7131。

^OBS-fc4e5160431ce83d7131

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-24-000118。
字段：`Liabilities`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204424000118/0001652044-24-000118-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2024-09-30 · quarter

**26.301 B USD**；状态：source_recorded。证据 ID：OBS-f6e50ede25089eb02669。

^OBS-f6e50ede25089eb02669

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2024-09-30 · ytd

**73.582 B USD**；状态：source_recorded。证据 ID：OBS-87836629f714207d06e2。

^OBS-87836629f714207d06e2

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2024-09-30 · quarter

**30.698 B USD**；状态：needs_review。证据 ID：OBS-8a75025929a835ecf586。

^OBS-8a75025929a835ecf586

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-cc294492ae3545f9926c|OBS-cc294492ae3545f9926c]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-2dd024115abf11e67742|OBS-2dd024115abf11e67742]]

### operating_cash_flow · 2024-09-30 · ytd

**86.186 B USD**；状态：source_recorded。证据 ID：OBS-cc294492ae3545f9926c。

^OBS-cc294492ae3545f9926c

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2024-09-30 · quarter

**28.521 B USD**；状态：source_recorded。证据 ID：OBS-cf137eb8086fa267a076。

^OBS-cf137eb8086fa267a076

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`OperatingIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2024-09-30 · ytd

**81.418 B USD**；状态：source_recorded。证据 ID：OBS-7ea66fdcd58bb5d29625。

^OBS-7ea66fdcd58bb5d29625

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`OperatingIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2024-09-30 · quarter

**32.31%**；状态：calculation_checked。证据 ID：OBS-0ed3199a201cb3aa726a。

^OBS-0ed3199a201cb3aa726a

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`OperatingIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-cf137eb8086fa267a076|OBS-cf137eb8086fa267a076]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-9ec3aa509631636edcb5|OBS-9ec3aa509631636edcb5]]

### receivables · 2024-09-30 · instant

**49.104 B USD**；状态：source_recorded。证据 ID：OBS-078d9c24fb8b754407f4。

^OBS-078d9c24fb8b754407f4

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-24-000118。
字段：`AccountsReceivableNetCurrent`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204424000118/0001652044-24-000118-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2024-09-30 · quarter

**88.268 B USD**；状态：source_recorded。证据 ID：OBS-9ec3aa509631636edcb5。

^OBS-9ec3aa509631636edcb5

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`Revenues`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### revenue · 2024-09-30 · ytd

**253.549 B USD**；状态：source_recorded。证据 ID：OBS-924f841f14c245efaf82。

^OBS-924f841f14c245efaf82

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`Revenues`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### assets · 2024-12-31 · instant

**450.256 B USD**；状态：source_recorded。证据 ID：OBS-48e4ac3350233ed63cb3。

^OBS-48e4ac3350233ed63cb3

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`Assets`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2024-12-31 · annual

**52.535 B USD**；状态：source_recorded。证据 ID：OBS-4b44c0a231757c61fc79。

^OBS-4b44c0a231757c61fc79

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### capex_cash · 2024-12-31 · quarter

**14.276 B USD**；状态：needs_review。证据 ID：OBS-8d0a9664682cdb878161。

^OBS-8d0a9664682cdb878161

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-4b44c0a231757c61fc79|OBS-4b44c0a231757c61fc79]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-0ddd7cbb64e771ba8f98|OBS-0ddd7cbb64e771ba8f98]]

### cash · 2024-12-31 · instant

**23.466 B USD**；状态：source_recorded。证据 ID：OBS-462305b69c7a773fa543。

^OBS-462305b69c7a773fa543

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### equity · 2024-12-31 · instant

**325.084 B USD**；状态：source_recorded。证据 ID：OBS-caaa0397ed07b0f933ac。

^OBS-caaa0397ed07b0f933ac

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`StockholdersEquity`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2024-12-31 · quarter

**24.837 B USD**；状态：needs_review。证据 ID：OBS-53fc35823dd0b762dcee。

^OBS-53fc35823dd0b762dcee

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-39e61a82560921bb1b6e|OBS-39e61a82560921bb1b6e]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-8d0a9664682cdb878161|OBS-8d0a9664682cdb878161]]

### liabilities · 2024-12-31 · instant

**125.172 B USD**；状态：source_recorded。证据 ID：OBS-3aa3f1a0c5bc7c9fba98。

^OBS-3aa3f1a0c5bc7c9fba98

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`Liabilities`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2024-12-31 · annual

**100.118 B USD**；状态：source_recorded。证据 ID：OBS-ab11645e60b49279f676。

^OBS-ab11645e60b49279f676

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2024-12-31 · quarter

**26.536 B USD**；状态：needs_review。证据 ID：OBS-563d5a37aed87c5fd8e0。

^OBS-563d5a37aed87c5fd8e0

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-ab11645e60b49279f676|OBS-ab11645e60b49279f676]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-87836629f714207d06e2|OBS-87836629f714207d06e2]]

### operating_cash_flow · 2024-12-31 · annual

**125.299 B USD**；状态：source_recorded。证据 ID：OBS-61d0bc5b17bc4bfa971e。

^OBS-61d0bc5b17bc4bfa971e

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_cash_flow · 2024-12-31 · quarter

**39.113 B USD**；状态：needs_review。证据 ID：OBS-39e61a82560921bb1b6e。

^OBS-39e61a82560921bb1b6e

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-61d0bc5b17bc4bfa971e|OBS-61d0bc5b17bc4bfa971e]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-cc294492ae3545f9926c|OBS-cc294492ae3545f9926c]]

### operating_income · 2024-12-31 · annual

**112.390 B USD**；状态：source_recorded。证据 ID：OBS-f9ff5a2f4eb732c785df。

^OBS-f9ff5a2f4eb732c785df

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`OperatingIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2024-12-31 · quarter

**30.972 B USD**；状态：needs_review。证据 ID：OBS-df7f97ed49d3acca2bce。

^OBS-df7f97ed49d3acca2bce

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`OperatingIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-f9ff5a2f4eb732c785df|OBS-f9ff5a2f4eb732c785df]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-7ea66fdcd58bb5d29625|OBS-7ea66fdcd58bb5d29625]]

### operating_margin_pct · 2024-12-31 · quarter

**32.11%**；状态：needs_review。证据 ID：OBS-16f6fc3f89cd141e92e3。

^OBS-16f6fc3f89cd141e92e3

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`OperatingIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-df7f97ed49d3acca2bce|OBS-df7f97ed49d3acca2bce]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-ac366bf56feb0b621aef|OBS-ac366bf56feb0b621aef]]

### receivables · 2024-12-31 · instant

**52.340 B USD**；状态：source_recorded。证据 ID：OBS-4034085a4050b1d63768。

^OBS-4034085a4050b1d63768

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2024-12-31 · annual

**350.018 B USD**；状态：source_recorded。证据 ID：OBS-b364b123148716e609b5。

^OBS-b364b123148716e609b5

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`Revenues`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### revenue · 2024-12-31 · quarter

**96.469 B USD**；状态：needs_review。证据 ID：OBS-ac366bf56feb0b621aef。

^OBS-ac366bf56feb0b621aef

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`Revenues`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-b364b123148716e609b5|OBS-b364b123148716e609b5]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-924f841f14c245efaf82|OBS-924f841f14c245efaf82]]

### assets · 2025-03-31 · instant

**475.374 B USD**；状态：source_recorded。证据 ID：OBS-d028befefb5d0b461a46。

^OBS-d028befefb5d0b461a46

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000043。
字段：`Assets`；申报日期：2025-04-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000043/0001652044-25-000043-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2025-03-31 · quarter

**17.197 B USD**；状态：source_recorded。证据 ID：OBS-965113c92db3a8456310。

^OBS-965113c92db3a8456310

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### cash · 2025-03-31 · instant

**23.264 B USD**；状态：source_recorded。证据 ID：OBS-676f7036132ecb3841b3。

^OBS-676f7036132ecb3841b3

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000043。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-04-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000043/0001652044-25-000043-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2025-03-31 · quarter

**2.810 USD/shares**；状态：source_recorded。证据 ID：OBS-95c291faafbd8b64c5aa。

^OBS-95c291faafbd8b64c5aa

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`EarningsPerShareDiluted`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-03-31 · quarter

**12,291.00 M shares**；状态：source_recorded。证据 ID：OBS-3a6d584a0aa90706f8bf。

^OBS-3a6d584a0aa90706f8bf

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-03-31 · instant

**345.267 B USD**；状态：source_recorded。证据 ID：OBS-301ba6367cc8ef02e5cc。

^OBS-301ba6367cc8ef02e5cc

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`StockholdersEquity`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2025-03-31 · quarter

**18.953 B USD**；状态：calculation_checked。证据 ID：OBS-2e95aff5d4ee14905ad1。

^OBS-2e95aff5d4ee14905ad1

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-94228e329b2e8d3cbc39|OBS-94228e329b2e8d3cbc39]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-965113c92db3a8456310|OBS-965113c92db3a8456310]]

### liabilities · 2025-03-31 · instant

**130.107 B USD**；状态：source_recorded。证据 ID：OBS-f0213755e1d8e4d8289a。

^OBS-f0213755e1d8e4d8289a

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000043。
字段：`Liabilities`；申报日期：2025-04-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000043/0001652044-25-000043-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-03-31 · quarter

**34.540 B USD**；状态：source_recorded。证据 ID：OBS-2c82c542f5ff61f47796。

^OBS-2c82c542f5ff61f47796

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`NetIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2025-03-31 · quarter

**36.150 B USD**；状态：source_recorded。证据 ID：OBS-94228e329b2e8d3cbc39。

^OBS-94228e329b2e8d3cbc39

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2025-03-31 · quarter

**30.606 B USD**；状态：source_recorded。证据 ID：OBS-6880949f9a13ca3d5966。

^OBS-6880949f9a13ca3d5966

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2025-03-31 · quarter

**33.92%**；状态：calculation_checked。证据 ID：OBS-fcb11d44079408d44471。

^OBS-fcb11d44079408d44471

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-6880949f9a13ca3d5966|OBS-6880949f9a13ca3d5966]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-9d40399dddfc1205648d|OBS-9d40399dddfc1205648d]]

### receivables · 2025-03-31 · instant

**51.000 B USD**；状态：source_recorded。证据 ID：OBS-061f3e17dba3ab3b4b56。

^OBS-061f3e17dba3ab3b4b56

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000043。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-04-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000043/0001652044-25-000043-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-03-31 · quarter

**90.234 B USD**；状态：source_recorded。证据 ID：OBS-9d40399dddfc1205648d。

^OBS-9d40399dddfc1205648d

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`Revenues`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### assets · 2025-06-30 · instant

**502.053 B USD**；状态：source_recorded。证据 ID：OBS-420cb36239458a03b14e。

^OBS-420cb36239458a03b14e

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000062。
字段：`Assets`；申报日期：2025-07-24。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000062/0001652044-25-000062-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2025-06-30 · quarter

**22.446 B USD**；状态：needs_review。证据 ID：OBS-356e734c31381aef8b64。

^OBS-356e734c31381aef8b64

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-f6b0d65f943cbafcb3ff|OBS-f6b0d65f943cbafcb3ff]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-965113c92db3a8456310|OBS-965113c92db3a8456310]]

### capex_cash · 2025-06-30 · ytd

**39.643 B USD**；状态：source_recorded。证据 ID：OBS-f6b0d65f943cbafcb3ff。

^OBS-f6b0d65f943cbafcb3ff

期间：2025-01-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### cash · 2025-06-30 · instant

**21.036 B USD**；状态：source_recorded。证据 ID：OBS-804ae8edd4498e3c02f2。

^OBS-804ae8edd4498e3c02f2

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000062。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-07-24。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000062/0001652044-25-000062-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2025-06-30 · quarter

**2.310 USD/shares**；状态：source_recorded。证据 ID：OBS-c4c54cbdddb6e4acaa04。

^OBS-c4c54cbdddb6e4acaa04

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`EarningsPerShareDiluted`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-06-30 · quarter

**12,198.00 M shares**；状态：source_recorded。证据 ID：OBS-21811ac7a17473bd1775。

^OBS-21811ac7a17473bd1775

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-06-30 · instant

**362.916 B USD**；状态：source_recorded。证据 ID：OBS-106bbc256c0bff527339。

^OBS-106bbc256c0bff527339

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`StockholdersEquity`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2025-06-30 · quarter

**5.301 B USD**；状态：needs_review。证据 ID：OBS-6c09de0e5d703f0b0f8e。

^OBS-6c09de0e5d703f0b0f8e

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-bc7232851fb32dbecd61|OBS-bc7232851fb32dbecd61]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-356e734c31381aef8b64|OBS-356e734c31381aef8b64]]

### liabilities · 2025-06-30 · instant

**139.137 B USD**；状态：source_recorded。证据 ID：OBS-93f6d1bb8a76f4cee58e。

^OBS-93f6d1bb8a76f4cee58e

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000062。
字段：`Liabilities`；申报日期：2025-07-24。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000062/0001652044-25-000062-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-06-30 · quarter

**28.196 B USD**；状态：source_recorded。证据 ID：OBS-2b4b959be48be16fd863。

^OBS-2b4b959be48be16fd863

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetIncomeLoss`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2025-06-30 · quarter

**27.747 B USD**；状态：needs_review。证据 ID：OBS-bc7232851fb32dbecd61。

^OBS-bc7232851fb32dbecd61

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-c6f5c97a1ab3464b29d4|OBS-c6f5c97a1ab3464b29d4]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-94228e329b2e8d3cbc39|OBS-94228e329b2e8d3cbc39]]

### operating_cash_flow · 2025-06-30 · ytd

**63.897 B USD**；状态：source_recorded。证据 ID：OBS-c6f5c97a1ab3464b29d4。

^OBS-c6f5c97a1ab3464b29d4

期间：2025-01-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2025-06-30 · quarter

**31.271 B USD**；状态：source_recorded。证据 ID：OBS-c029198f54691e93d75c。

^OBS-c029198f54691e93d75c

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`OperatingIncomeLoss`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2025-06-30 · quarter

**32.43%**；状态：calculation_checked。证据 ID：OBS-ad50243bc9a0933dc461。

^OBS-ad50243bc9a0933dc461

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`OperatingIncomeLoss`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-c029198f54691e93d75c|OBS-c029198f54691e93d75c]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-ad44a0387ed4520b9763|OBS-ad44a0387ed4520b9763]]

### receivables · 2025-06-30 · instant

**55.048 B USD**；状态：source_recorded。证据 ID：OBS-a8f8cc158a2c8fcd23fe。

^OBS-a8f8cc158a2c8fcd23fe

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000062。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-07-24。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000062/0001652044-25-000062-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-06-30 · quarter

**96.428 B USD**；状态：source_recorded。证据 ID：OBS-ad44a0387ed4520b9763。

^OBS-ad44a0387ed4520b9763

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`Revenues`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### assets · 2025-09-30 · instant

**536.469 B USD**；状态：source_recorded。证据 ID：OBS-00c0cd9ef211698b9840。

^OBS-00c0cd9ef211698b9840

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`Assets`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2025-09-30 · quarter

**23.953 B USD**；状态：needs_review。证据 ID：OBS-56e6a7e06392a135ea24。

^OBS-56e6a7e06392a135ea24

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-aa5c37fbd6ff09a1c274|OBS-aa5c37fbd6ff09a1c274]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-f6b0d65f943cbafcb3ff|OBS-f6b0d65f943cbafcb3ff]]

### capex_cash · 2025-09-30 · ytd

**63.596 B USD**；状态：source_recorded。证据 ID：OBS-aa5c37fbd6ff09a1c274。

^OBS-aa5c37fbd6ff09a1c274

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### cash · 2025-09-30 · instant

**23.090 B USD**；状态：source_recorded。证据 ID：OBS-3d833eb7480ae4ff88f3。

^OBS-3d833eb7480ae4ff88f3

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2025-09-30 · quarter

**2.870 USD/shares**；状态：source_recorded。证据 ID：OBS-a2627b36472c2a97c37b。

^OBS-a2627b36472c2a97c37b

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`EarningsPerShareDiluted`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-09-30 · quarter

**12,203.00 M shares**；状态：source_recorded。证据 ID：OBS-90f3c8a3b67684a2abfa。

^OBS-90f3c8a3b67684a2abfa

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-09-30 · instant

**386.867 B USD**；状态：source_recorded。证据 ID：OBS-ae4ea20ab00365fefb72。

^OBS-ae4ea20ab00365fefb72

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`StockholdersEquity`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2025-09-30 · quarter

**24.461 B USD**；状态：needs_review。证据 ID：OBS-fd61c43cb9cb5665e1df。

^OBS-fd61c43cb9cb5665e1df

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-b78e5e9eaaf032bb88df|OBS-b78e5e9eaaf032bb88df]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-56e6a7e06392a135ea24|OBS-56e6a7e06392a135ea24]]

### liabilities · 2025-09-30 · instant

**149.602 B USD**；状态：source_recorded。证据 ID：OBS-17fefaf707be6785bcd7。

^OBS-17fefaf707be6785bcd7

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`Liabilities`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-09-30 · quarter

**34.979 B USD**；状态：source_recorded。证据 ID：OBS-aaa505355594ed2073fe。

^OBS-aaa505355594ed2073fe

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2025-09-30 · ytd

**97.715 B USD**；状态：source_recorded。证据 ID：OBS-9ad8dc9ec063dc5e450a。

^OBS-9ad8dc9ec063dc5e450a

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2025-09-30 · quarter

**48.414 B USD**；状态：needs_review。证据 ID：OBS-b78e5e9eaaf032bb88df。

^OBS-b78e5e9eaaf032bb88df

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-be6d3a9c7e359b3c9ad9|OBS-be6d3a9c7e359b3c9ad9]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-c6f5c97a1ab3464b29d4|OBS-c6f5c97a1ab3464b29d4]]

### operating_cash_flow · 2025-09-30 · ytd

**112.311 B USD**；状态：source_recorded。证据 ID：OBS-be6d3a9c7e359b3c9ad9。

^OBS-be6d3a9c7e359b3c9ad9

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2025-09-30 · quarter

**31.228 B USD**；状态：source_recorded。证据 ID：OBS-6a2204ab50f1c499146a。

^OBS-6a2204ab50f1c499146a

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`OperatingIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2025-09-30 · ytd

**93.105 B USD**；状态：source_recorded。证据 ID：OBS-3d61adf517c798cf1016。

^OBS-3d61adf517c798cf1016

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`OperatingIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2025-09-30 · quarter

**30.51%**；状态：calculation_checked。证据 ID：OBS-48b3b1b22d2532b2b619。

^OBS-48b3b1b22d2532b2b619

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`OperatingIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-6a2204ab50f1c499146a|OBS-6a2204ab50f1c499146a]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-fcc88207add8f0b03330|OBS-fcc88207add8f0b03330]]

### receivables · 2025-09-30 · instant

**57.148 B USD**；状态：source_recorded。证据 ID：OBS-f8f54ff6ead11fde4cba。

^OBS-f8f54ff6ead11fde4cba

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-09-30 · quarter

**102.346 B USD**；状态：source_recorded。证据 ID：OBS-fcc88207add8f0b03330。

^OBS-fcc88207add8f0b03330

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`Revenues`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### revenue · 2025-09-30 · ytd

**289.007 B USD**；状态：source_recorded。证据 ID：OBS-711ab1661b01eb24c466。

^OBS-711ab1661b01eb24c466

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`Revenues`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### assets · 2025-12-31 · instant

**595.281 B USD**；状态：source_recorded。证据 ID：OBS-bf61805f820b0e6e2897。

^OBS-bf61805f820b0e6e2897

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`Assets`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2025-12-31 · annual

**91.447 B USD**；状态：source_recorded。证据 ID：OBS-e8c8974428d9d88577ab。

^OBS-e8c8974428d9d88577ab

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### capex_cash · 2025-12-31 · quarter

**27.851 B USD**；状态：needs_review。证据 ID：OBS-4acded9aa7475c3f7c4d。

^OBS-4acded9aa7475c3f7c4d

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-e8c8974428d9d88577ab|OBS-e8c8974428d9d88577ab]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-aa5c37fbd6ff09a1c274|OBS-aa5c37fbd6ff09a1c274]]

### cash · 2025-12-31 · instant

**30.708 B USD**；状态：source_recorded。证据 ID：OBS-bc743b02cfc609a78e42。

^OBS-bc743b02cfc609a78e42

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### equity · 2025-12-31 · instant

**415.265 B USD**；状态：source_recorded。证据 ID：OBS-6e705edc18cb1abb2767。

^OBS-6e705edc18cb1abb2767

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`StockholdersEquity`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2025-12-31 · quarter

**24.551 B USD**；状态：needs_review。证据 ID：OBS-76bf1e4073dc81d0da89。

^OBS-76bf1e4073dc81d0da89

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-589e9de1e5b48b6800fe|OBS-589e9de1e5b48b6800fe]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-4acded9aa7475c3f7c4d|OBS-4acded9aa7475c3f7c4d]]

### inventory · 2025-12-31 · instant

**2.439 B USD**；状态：source_recorded。证据 ID：OBS-69644a37dc3680e05816。

^OBS-69644a37dc3680e05816

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`InventoryNet`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2025-12-31 · instant

**180.016 B USD**；状态：source_recorded。证据 ID：OBS-60d83908ebf1430a455c。

^OBS-60d83908ebf1430a455c

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`Liabilities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-12-31 · annual

**132.170 B USD**；状态：source_recorded。证据 ID：OBS-982ec24a9024e29b471b。

^OBS-982ec24a9024e29b471b

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2025-12-31 · quarter

**34.455 B USD**；状态：needs_review。证据 ID：OBS-b492e161f47cbb6d6b10。

^OBS-b492e161f47cbb6d6b10

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-982ec24a9024e29b471b|OBS-982ec24a9024e29b471b]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-9ad8dc9ec063dc5e450a|OBS-9ad8dc9ec063dc5e450a]]

### operating_cash_flow · 2025-12-31 · annual

**164.713 B USD**；状态：source_recorded。证据 ID：OBS-5054078595bd8024d0e3。

^OBS-5054078595bd8024d0e3

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_cash_flow · 2025-12-31 · quarter

**52.402 B USD**；状态：needs_review。证据 ID：OBS-589e9de1e5b48b6800fe。

^OBS-589e9de1e5b48b6800fe

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-5054078595bd8024d0e3|OBS-5054078595bd8024d0e3]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-be6d3a9c7e359b3c9ad9|OBS-be6d3a9c7e359b3c9ad9]]

### operating_income · 2025-12-31 · annual

**129.039 B USD**；状态：source_recorded。证据 ID：OBS-69b043db6244603732d3。

^OBS-69b043db6244603732d3

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`OperatingIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2025-12-31 · quarter

**35.934 B USD**；状态：needs_review。证据 ID：OBS-11bd59b913975cf76058。

^OBS-11bd59b913975cf76058

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`OperatingIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-69b043db6244603732d3|OBS-69b043db6244603732d3]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-3d61adf517c798cf1016|OBS-3d61adf517c798cf1016]]

### operating_margin_pct · 2025-12-31 · quarter

**31.57%**；状态：needs_review。证据 ID：OBS-29b374f7a9f2f726f38d。

^OBS-29b374f7a9f2f726f38d

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`OperatingIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-11bd59b913975cf76058|OBS-11bd59b913975cf76058]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-8f4dc4b6e9aacdc485c7|OBS-8f4dc4b6e9aacdc485c7]]

### receivables · 2025-12-31 · instant

**62.886 B USD**；状态：source_recorded。证据 ID：OBS-de62fba08a1cf93b88bd。

^OBS-de62fba08a1cf93b88bd

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-12-31 · annual

**402.836 B USD**；状态：source_recorded。证据 ID：OBS-e634a66193d1fbcfecd2。

^OBS-e634a66193d1fbcfecd2

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`Revenues`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### revenue · 2025-12-31 · quarter

**113.829 B USD**；状态：needs_review。证据 ID：OBS-8f4dc4b6e9aacdc485c7。

^OBS-8f4dc4b6e9aacdc485c7

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`Revenues`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-e634a66193d1fbcfecd2|OBS-e634a66193d1fbcfecd2]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-711ab1661b01eb24c466|OBS-711ab1661b01eb24c466]]

### assets · 2026-03-31 · instant

**703.919 B USD**；状态：source_recorded。证据 ID：OBS-19d9de92a3f04ef04f24。

^OBS-19d9de92a3f04ef04f24

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`Assets`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2026-03-31 · quarter

**35.674 B USD**；状态：source_recorded。证据 ID：OBS-721c3b0776570f40e5de。

^OBS-721c3b0776570f40e5de

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### cash · 2026-03-31 · instant

**38.063 B USD**；状态：source_recorded。证据 ID：OBS-2429666cd2fb4b305aae。

^OBS-2429666cd2fb4b305aae

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2026-03-31 · quarter

**5.110 USD/shares**；状态：source_recorded。证据 ID：OBS-4c8ca89113ec25b20d24。

^OBS-4c8ca89113ec25b20d24

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`EarningsPerShareDiluted`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2026-03-31 · quarter

**12,238.00 M shares**；状态：source_recorded。证据 ID：OBS-9179a6ce0547698f7d45。

^OBS-9179a6ce0547698f7d45

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2026-03-31 · instant

**478.746 B USD**；状态：source_recorded。证据 ID：OBS-dc6e5ed61c6e0582512e。

^OBS-dc6e5ed61c6e0582512e

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`StockholdersEquity`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2026-03-31 · quarter

**10.116 B USD**；状态：calculation_checked。证据 ID：OBS-33e4cbd60f6ca499d059。

^OBS-33e4cbd60f6ca499d059

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-d2d64065bbbe739932e3|OBS-d2d64065bbbe739932e3]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-721c3b0776570f40e5de|OBS-721c3b0776570f40e5de]]

### liabilities · 2026-03-31 · instant

**225.173 B USD**；状态：source_recorded。证据 ID：OBS-442190bd55b9f35743cb。

^OBS-442190bd55b9f35743cb

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`Liabilities`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2026-03-31 · quarter

**62.578 B USD**；状态：source_recorded。证据 ID：OBS-39384a00cd0aa963a22b。

^OBS-39384a00cd0aa963a22b

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`NetIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2026-03-31 · quarter

**45.790 B USD**；状态：source_recorded。证据 ID：OBS-d2d64065bbbe739932e3。

^OBS-d2d64065bbbe739932e3

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2026-03-31 · quarter

**39.696 B USD**；状态：source_recorded。证据 ID：OBS-c47b89c35244f7378456。

^OBS-c47b89c35244f7378456

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2026-03-31 · quarter

**36.12%**；状态：calculation_checked。证据 ID：OBS-2f1a20b76188197df3fa。

^OBS-2f1a20b76188197df3fa

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-c47b89c35244f7378456|OBS-c47b89c35244f7378456]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-2f583cb58cb2646aa759|OBS-2f583cb58cb2646aa759]]

### receivables · 2026-03-31 · instant

**62.999 B USD**；状态：source_recorded。证据 ID：OBS-b17c8b11513ce5e52c0c。

^OBS-b17c8b11513ce5e52c0c

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2026-03-31 · quarter

**109.896 B USD**；状态：source_recorded。证据 ID：OBS-2f583cb58cb2646aa759。

^OBS-2f583cb58cb2646aa759

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`Revenues`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### assets · 2026-06-30 · instant

**921.983 B USD**；状态：source_recorded。证据 ID：OBS-f17893e2f7033c4ba40d。

^OBS-f17893e2f7033c4ba40d

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`Assets`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2026-06-30 · quarter

**44.924 B USD**；状态：needs_review。证据 ID：OBS-b062e2a020a5835a7fb4。

^OBS-b062e2a020a5835a7fb4

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-45b5c2a72f5fbbab5048|OBS-45b5c2a72f5fbbab5048]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-721c3b0776570f40e5de|OBS-721c3b0776570f40e5de]]

### capex_cash · 2026-06-30 · ytd

**80.598 B USD**；状态：source_recorded。证据 ID：OBS-45b5c2a72f5fbbab5048。

^OBS-45b5c2a72f5fbbab5048

期间：2026-01-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### cash · 2026-06-30 · instant

**55.911 B USD**；状态：source_recorded。证据 ID：OBS-660eb4d83dbfcb2dba09。

^OBS-660eb4d83dbfcb2dba09

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2026-06-30 · quarter

**9.110 USD/shares**；状态：source_recorded。证据 ID：OBS-703f6a5c74ac9d38e7b2。

^OBS-703f6a5c74ac9d38e7b2

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`EarningsPerShareDiluted`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2026-06-30 · quarter

**12,309.00 M shares**；状态：source_recorded。证据 ID：OBS-f7040517a02e3c02b471。

^OBS-f7040517a02e3c02b471

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2026-06-30 · instant

**640.480 B USD**；状态：source_recorded。证据 ID：OBS-11dc1ff75eb74fa6f1a9。

^OBS-11dc1ff75eb74fa6f1a9

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`StockholdersEquity`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2026-06-30 · quarter

**-5.855 B USD**；状态：needs_review。证据 ID：OBS-9731ec6c948f3675befd。

^OBS-9731ec6c948f3675befd

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-c6abec8b8953a1ab0d29|OBS-c6abec8b8953a1ab0d29]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-b062e2a020a5835a7fb4|OBS-b062e2a020a5835a7fb4]]

### inventory · 2026-06-30 · instant

**9.991 B USD**；状态：source_recorded。证据 ID：OBS-8e2004c8ef34f8227e1d。

^OBS-8e2004c8ef34f8227e1d

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`InventoryNet`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2026-06-30 · instant

**281.503 B USD**；状态：source_recorded。证据 ID：OBS-b9b7b935bed799d403f3。

^OBS-b9b7b935bed799d403f3

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`Liabilities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2026-06-30 · quarter

**112.193 B USD**；状态：source_recorded。证据 ID：OBS-f15ae7ee6f6201d96c51。

^OBS-f15ae7ee6f6201d96c51

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetIncomeLoss`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2026-06-30 · quarter

**39.069 B USD**；状态：needs_review。证据 ID：OBS-c6abec8b8953a1ab0d29。

^OBS-c6abec8b8953a1ab0d29

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-b49f555740168ca603b0|OBS-b49f555740168ca603b0]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-d2d64065bbbe739932e3|OBS-d2d64065bbbe739932e3]]

### operating_cash_flow · 2026-06-30 · ytd

**84.859 B USD**；状态：source_recorded。证据 ID：OBS-b49f555740168ca603b0。

^OBS-b49f555740168ca603b0

期间：2026-01-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2026-06-30 · quarter

**40.770 B USD**；状态：source_recorded。证据 ID：OBS-c86a3d182854081a5d39。

^OBS-c86a3d182854081a5d39

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`OperatingIncomeLoss`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2026-06-30 · quarter

**34.03%**；状态：calculation_checked。证据 ID：OBS-69599ddb797a31fc9301。

^OBS-69599ddb797a31fc9301

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`OperatingIncomeLoss`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-c86a3d182854081a5d39|OBS-c86a3d182854081a5d39]]、[[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence#^OBS-5449a7fd130bcbbfe847|OBS-5449a7fd130bcbbfe847]]

### receivables · 2026-06-30 · instant

**69.175 B USD**；状态：source_recorded。证据 ID：OBS-82306c4084bb1dbeb6b2。

^OBS-82306c4084bb1dbeb6b2

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2026-06-30 · quarter

**119.796 B USD**；状态：source_recorded。证据 ID：OBS-5449a7fd130bcbbfe847。

^OBS-5449a7fd130bcbbfe847

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`Revenues`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).
