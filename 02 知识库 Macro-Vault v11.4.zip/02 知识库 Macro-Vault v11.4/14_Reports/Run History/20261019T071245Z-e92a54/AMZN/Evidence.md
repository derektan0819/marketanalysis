---
title: "AMZN — 本次数据与原文证据（运行 20261019T071245Z-e92a54）"
tags: [reports, run-history, evidence]
created: 2026-10-19
updated: 2026-10-19
source: "引擎运行 20261019T071245Z-e92a54 的数据快照 12_Data/Companies/AMZN/20261019T071245Z-e92a54.json"
---
# AMZN — 本次数据与原文证据

资料截止：2026-10-19T07:12:45+00:00。

[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Brief|本次简报]] · [[04_Companies/AMZN/Company Profile|AMZN 档案]] · [[04_Companies/AMZN/Latest Brief|最新简报]] · [[04_Companies/AMZN/AMZN - Data History|八季数据]] · [[04_Companies/AMZN/Evidence Index|证据索引]] · [[04_Companies/AMZN/Current Thesis|当前判断]] · [[04_Companies/AMZN/Thesis History|判断历史]]

本页是保存快照的阅读视图；链接表示引用或计算依赖，不表示独立验证或因果关系。
包含最近八季的观察值，以及计算所需的较早输入。后续运行各自生成证据页，旧简报不会跳到新快照。

## 原始快照
[[12_Data/Companies/AMZN/20261019T071245Z-e92a54.json|JSON 快照（外部编辑器）]]

## 财报原文
- [[13_Sources/Records/SRC-c1ec319cd0b030514ec1e7fd|10-Q]]；期间／事件日：2026-06-30
  提取正文：[[13_Sources/Raw/SRC-c1ec319cd0b030514ec1e7fd|SRC-c1ec319cd0b030514ec1e7fd 正文]]
- [[13_Sources/Records/SRC-eb223ffcdc5663a094a6b31e|10-K]]；期间／事件日：2025-12-31
  提取正文：[[13_Sources/Raw/SRC-eb223ffcdc5663a094a6b31e|SRC-eb223ffcdc5663a094a6b31e 正文]]
- [[13_Sources/Records/SRC-cdfdbabdeb7969a82d193e80|earnings_release_8K]]；期间／事件日：2026-07-30
  提取正文：[[13_Sources/Raw/SRC-cdfdbabdeb7969a82d193e80.earnings|SRC-cdfdbabdeb7969a82d193e80 正文]]

## 数字与计算依赖

### assets · 2024-09-30 · instant

**584.626 B USD**；状态：source_recorded。证据 ID：OBS-d79a78b0d97681491364。

^OBS-d79a78b0d97681491364

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-24-000161。
字段：`Assets`；申报日期：2024-11-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872424000161/0001018724-24-000161-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### cash · 2024-09-30 · instant

**75.091 B USD**；状态：source_recorded。证据 ID：OBS-262ca05ce31db25d1971。

^OBS-262ca05ce31db25d1971

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-24-000161。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2024-11-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872424000161/0001018724-24-000161-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2024-09-30 · quarter

**1.430 USD/shares**；状态：source_recorded。证据 ID：OBS-9542e0a0591f52d9f10d。

^OBS-9542e0a0591f52d9f10d

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`EarningsPerShareDiluted`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2024-09-30 · quarter

**10,735.00 M shares**；状态：source_recorded。证据 ID：OBS-5c29edc5fee84d4ebabc。

^OBS-5c29edc5fee84d4ebabc

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2024-09-30 · instant

**259.151 B USD**；状态：source_recorded。证据 ID：OBS-7cd965837fea84129414。

^OBS-7cd965837fea84129414

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`StockholdersEquity`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### inventory · 2024-09-30 · instant

**36.103 B USD**；状态：source_recorded。证据 ID：OBS-b47c60c56091319daf6b。

^OBS-b47c60c56091319daf6b

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-24-000161。
字段：`InventoryNet`；申报日期：2024-11-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872424000161/0001018724-24-000161-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### net_income · 2024-09-30 · quarter

**15.328 B USD**；状态：source_recorded。证据 ID：OBS-17c8a4e66120bc6439d8。

^OBS-17c8a4e66120bc6439d8

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2024-09-30 · ytd

**39.244 B USD**；状态：source_recorded。证据 ID：OBS-62374ea45d04b6822445。

^OBS-62374ea45d04b6822445

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2024-09-30 · quarter

**25.971 B USD**；状态：source_recorded。证据 ID：OBS-19d23907ad9bdf69b048。

^OBS-19d23907ad9bdf69b048

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_cash_flow · 2024-09-30 · ytd

**70.241 B USD**；状态：source_recorded。证据 ID：OBS-4cfe323e265d3cb948bc。

^OBS-4cfe323e265d3cb948bc

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2024-09-30 · quarter

**17.411 B USD**；状态：source_recorded。证据 ID：OBS-75de442682df858a2699。

^OBS-75de442682df858a2699

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`OperatingIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2024-09-30 · ytd

**47.390 B USD**；状态：source_recorded。证据 ID：OBS-dcb87e35835f8f38cfd6。

^OBS-dcb87e35835f8f38cfd6

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`OperatingIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2024-09-30 · quarter

**10.96%**；状态：calculation_checked。证据 ID：OBS-237fbee3b83480593bc3。

^OBS-237fbee3b83480593bc3

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`OperatingIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-75de442682df858a2699|OBS-75de442682df858a2699]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-a53b7a3e94db03e39e74|OBS-a53b7a3e94db03e39e74]]

### receivables · 2024-09-30 · instant

**51.638 B USD**；状态：source_recorded。证据 ID：OBS-3a1a17892bb54b56490e。

^OBS-3a1a17892bb54b56490e

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-24-000161。
字段：`AccountsReceivableNetCurrent`；申报日期：2024-11-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872424000161/0001018724-24-000161-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2024-09-30 · quarter

**158.877 B USD**；状态：source_recorded。证据 ID：OBS-a53b7a3e94db03e39e74。

^OBS-a53b7a3e94db03e39e74

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### revenue · 2024-09-30 · ytd

**450.167 B USD**；状态：source_recorded。证据 ID：OBS-7abe7df691cdb108bf03。

^OBS-7abe7df691cdb108bf03

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### assets · 2024-12-31 · instant

**624.894 B USD**；状态：source_recorded。证据 ID：OBS-b2120a170bdafc69c582。

^OBS-b2120a170bdafc69c582

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`Assets`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### cash · 2024-12-31 · instant

**78.779 B USD**；状态：source_recorded。证据 ID：OBS-bd485e34fdae2e52a6a7。

^OBS-bd485e34fdae2e52a6a7

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### equity · 2024-12-31 · instant

**285.970 B USD**；状态：source_recorded。证据 ID：OBS-743222230fd67ccf830a。

^OBS-743222230fd67ccf830a

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`StockholdersEquity`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### inventory · 2024-12-31 · instant

**34.214 B USD**；状态：source_recorded。证据 ID：OBS-9155b5ecce6ed886a69a。

^OBS-9155b5ecce6ed886a69a

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`InventoryNet`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### net_income · 2024-12-31 · annual

**59.248 B USD**；状态：source_recorded。证据 ID：OBS-356714dca10b56caa35b。

^OBS-356714dca10b56caa35b

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2024-12-31 · quarter

**20.004 B USD**；状态：needs_review。证据 ID：OBS-0c036223c820d85d24dd。

^OBS-0c036223c820d85d24dd

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-356714dca10b56caa35b|OBS-356714dca10b56caa35b]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-62374ea45d04b6822445|OBS-62374ea45d04b6822445]]

### operating_cash_flow · 2024-12-31 · annual

**115.877 B USD**；状态：source_recorded。证据 ID：OBS-b144ba41e88f9e5a01ce。

^OBS-b144ba41e88f9e5a01ce

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_cash_flow · 2024-12-31 · quarter

**45.636 B USD**；状态：needs_review。证据 ID：OBS-605f4fc63f48e18bae8a。

^OBS-605f4fc63f48e18bae8a

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-b144ba41e88f9e5a01ce|OBS-b144ba41e88f9e5a01ce]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-4cfe323e265d3cb948bc|OBS-4cfe323e265d3cb948bc]]

### operating_income · 2024-12-31 · annual

**68.593 B USD**；状态：source_recorded。证据 ID：OBS-363e9c7645a3a486d77a。

^OBS-363e9c7645a3a486d77a

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`OperatingIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2024-12-31 · quarter

**21.203 B USD**；状态：needs_review。证据 ID：OBS-43345022dd7df4c0b991。

^OBS-43345022dd7df4c0b991

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`OperatingIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-363e9c7645a3a486d77a|OBS-363e9c7645a3a486d77a]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-dcb87e35835f8f38cfd6|OBS-dcb87e35835f8f38cfd6]]

### operating_margin_pct · 2024-12-31 · quarter

**11.29%**；状态：needs_review。证据 ID：OBS-58f90367d36ef3d49fc7。

^OBS-58f90367d36ef3d49fc7

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`OperatingIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-43345022dd7df4c0b991|OBS-43345022dd7df4c0b991]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-ce44107bba2c7e9889b1|OBS-ce44107bba2c7e9889b1]]

### receivables · 2024-12-31 · instant

**55.451 B USD**；状态：source_recorded。证据 ID：OBS-c05407f1013bbd6ebebe。

^OBS-c05407f1013bbd6ebebe

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2024-12-31 · annual

**637.959 B USD**；状态：source_recorded。证据 ID：OBS-df77e8b11eabac3c8383。

^OBS-df77e8b11eabac3c8383

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### revenue · 2024-12-31 · quarter

**187.792 B USD**；状态：needs_review。证据 ID：OBS-ce44107bba2c7e9889b1。

^OBS-ce44107bba2c7e9889b1

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-df77e8b11eabac3c8383|OBS-df77e8b11eabac3c8383]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-7abe7df691cdb108bf03|OBS-7abe7df691cdb108bf03]]

### assets · 2025-03-31 · instant

**643.256 B USD**；状态：source_recorded。证据 ID：OBS-18631c14f5b067435b95。

^OBS-18631c14f5b067435b95

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000036。
字段：`Assets`；申报日期：2025-05-02。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000036/0001018724-25-000036-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### cash · 2025-03-31 · instant

**66.207 B USD**；状态：source_recorded。证据 ID：OBS-28931e8639d61cff23ae。

^OBS-28931e8639d61cff23ae

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000036。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-05-02。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000036/0001018724-25-000036-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2025-03-31 · quarter

**1.590 USD/shares**；状态：source_recorded。证据 ID：OBS-e8c2bf07732859a25d7b。

^OBS-e8c2bf07732859a25d7b

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`EarningsPerShareDiluted`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-03-31 · quarter

**10,793.00 M shares**；状态：source_recorded。证据 ID：OBS-875aa3a8e270cd09f5ba。

^OBS-875aa3a8e270cd09f5ba

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-03-31 · instant

**305.867 B USD**；状态：source_recorded。证据 ID：OBS-32f2c00d602fc69cc668。

^OBS-32f2c00d602fc69cc668

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`StockholdersEquity`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### inventory · 2025-03-31 · instant

**35.864 B USD**；状态：source_recorded。证据 ID：OBS-5d45333b11e27560c371。

^OBS-5d45333b11e27560c371

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000036。
字段：`InventoryNet`；申报日期：2025-05-02。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000036/0001018724-25-000036-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### net_income · 2025-03-31 · quarter

**17.127 B USD**；状态：source_recorded。证据 ID：OBS-205dfd8ffb758893f931。

^OBS-205dfd8ffb758893f931

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`NetIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2025-03-31 · quarter

**17.015 B USD**；状态：source_recorded。证据 ID：OBS-f202355d56c31882f10a。

^OBS-f202355d56c31882f10a

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2025-03-31 · quarter

**18.405 B USD**；状态：source_recorded。证据 ID：OBS-312d2c53ccb20d247519。

^OBS-312d2c53ccb20d247519

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2025-03-31 · quarter

**11.82%**；状态：calculation_checked。证据 ID：OBS-ce2f4a9da5cb165b550d。

^OBS-ce2f4a9da5cb165b550d

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-312d2c53ccb20d247519|OBS-312d2c53ccb20d247519]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-1f83544386c3ef04bbcb|OBS-1f83544386c3ef04bbcb]]

### receivables · 2025-03-31 · instant

**54.216 B USD**；状态：source_recorded。证据 ID：OBS-b271b9efdc3b84f7ec27。

^OBS-b271b9efdc3b84f7ec27

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000036。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-05-02。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000036/0001018724-25-000036-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-03-31 · quarter

**155.667 B USD**；状态：source_recorded。证据 ID：OBS-1f83544386c3ef04bbcb。

^OBS-1f83544386c3ef04bbcb

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### assets · 2025-06-30 · instant

**682.170 B USD**；状态：source_recorded。证据 ID：OBS-f954a9d9d62d22fee2f6。

^OBS-f954a9d9d62d22fee2f6

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000086。
字段：`Assets`；申报日期：2025-08-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000086/0001018724-25-000086-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### cash · 2025-06-30 · instant

**57.741 B USD**；状态：source_recorded。证据 ID：OBS-3f9d0ae26918135a0019。

^OBS-3f9d0ae26918135a0019

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000086。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-08-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000086/0001018724-25-000086-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2025-06-30 · quarter

**1.680 USD/shares**；状态：source_recorded。证据 ID：OBS-93e2394e9947278f4aa7。

^OBS-93e2394e9947278f4aa7

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`EarningsPerShareDiluted`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-06-30 · quarter

**10,806.00 M shares**；状态：source_recorded。证据 ID：OBS-c59489a229c36329345b。

^OBS-c59489a229c36329345b

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-06-30 · instant

**333.775 B USD**；状态：source_recorded。证据 ID：OBS-8a0ce92789a37d4314bd。

^OBS-8a0ce92789a37d4314bd

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`StockholdersEquity`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### inventory · 2025-06-30 · instant

**40.825 B USD**；状态：source_recorded。证据 ID：OBS-125841e5837cadeb4e94。

^OBS-125841e5837cadeb4e94

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000086。
字段：`InventoryNet`；申报日期：2025-08-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000086/0001018724-25-000086-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### net_income · 2025-06-30 · quarter

**18.164 B USD**；状态：source_recorded。证据 ID：OBS-386b62e35503761a12d6。

^OBS-386b62e35503761a12d6

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`NetIncomeLoss`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2025-06-30 · quarter

**32.515 B USD**；状态：source_recorded。证据 ID：OBS-7403b7ab1b9390ad8f6c。

^OBS-7403b7ab1b9390ad8f6c

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2025-06-30 · quarter

**19.171 B USD**；状态：source_recorded。证据 ID：OBS-f2b8e3c18583b15bde89。

^OBS-f2b8e3c18583b15bde89

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`OperatingIncomeLoss`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2025-06-30 · quarter

**11.43%**；状态：calculation_checked。证据 ID：OBS-bc9575b9bc59e25702c9。

^OBS-bc9575b9bc59e25702c9

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`OperatingIncomeLoss`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-f2b8e3c18583b15bde89|OBS-f2b8e3c18583b15bde89]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-73491c052b4372554c87|OBS-73491c052b4372554c87]]

### receivables · 2025-06-30 · instant

**57.415 B USD**；状态：source_recorded。证据 ID：OBS-01cda88645f1c0bf25c2。

^OBS-01cda88645f1c0bf25c2

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000086。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-08-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000086/0001018724-25-000086-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-06-30 · quarter

**167.702 B USD**；状态：source_recorded。证据 ID：OBS-73491c052b4372554c87。

^OBS-73491c052b4372554c87

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### assets · 2025-09-30 · instant

**727.921 B USD**；状态：source_recorded。证据 ID：OBS-174b9f28a849ee88fd46。

^OBS-174b9f28a849ee88fd46

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`Assets`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### cash · 2025-09-30 · instant

**66.922 B USD**；状态：source_recorded。证据 ID：OBS-498d8e1af4e27aedf6b3。

^OBS-498d8e1af4e27aedf6b3

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2025-09-30 · quarter

**1.950 USD/shares**；状态：source_recorded。证据 ID：OBS-515d52c829fa690f431b。

^OBS-515d52c829fa690f431b

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`EarningsPerShareDiluted`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-09-30 · quarter

**10,845.00 M shares**；状态：source_recorded。证据 ID：OBS-646a1ecf1aaa1edd6659。

^OBS-646a1ecf1aaa1edd6659

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-09-30 · instant

**369.631 B USD**；状态：source_recorded。证据 ID：OBS-8b4a0d48124a399d0e60。

^OBS-8b4a0d48124a399d0e60

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`StockholdersEquity`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### inventory · 2025-09-30 · instant

**41.494 B USD**；状态：source_recorded。证据 ID：OBS-f069565487bd8b126823。

^OBS-f069565487bd8b126823

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`InventoryNet`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### net_income · 2025-09-30 · quarter

**21.187 B USD**；状态：source_recorded。证据 ID：OBS-6b00fb6d8f702133e227。

^OBS-6b00fb6d8f702133e227

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2025-09-30 · ytd

**56.478 B USD**；状态：source_recorded。证据 ID：OBS-9fed8ac88c343d92609f。

^OBS-9fed8ac88c343d92609f

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2025-09-30 · quarter

**35.525 B USD**；状态：source_recorded。证据 ID：OBS-839d39ed8a3612740bdc。

^OBS-839d39ed8a3612740bdc

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_cash_flow · 2025-09-30 · ytd

**85.055 B USD**；状态：source_recorded。证据 ID：OBS-43642367e5d324f6096a。

^OBS-43642367e5d324f6096a

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2025-09-30 · quarter

**17.422 B USD**；状态：source_recorded。证据 ID：OBS-41195c61d091f1c794e0。

^OBS-41195c61d091f1c794e0

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`OperatingIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2025-09-30 · ytd

**54.998 B USD**；状态：source_recorded。证据 ID：OBS-758925674977747b7cbf。

^OBS-758925674977747b7cbf

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`OperatingIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2025-09-30 · quarter

**9.67%**；状态：calculation_checked。证据 ID：OBS-f2900a4ab5a1e05a82ba。

^OBS-f2900a4ab5a1e05a82ba

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`OperatingIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-41195c61d091f1c794e0|OBS-41195c61d091f1c794e0]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-de56d0d879ad0d83f77e|OBS-de56d0d879ad0d83f77e]]

### receivables · 2025-09-30 · instant

**61.175 B USD**；状态：source_recorded。证据 ID：OBS-64bd95ca6e47cb7b9e33。

^OBS-64bd95ca6e47cb7b9e33

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-09-30 · quarter

**180.169 B USD**；状态：source_recorded。证据 ID：OBS-de56d0d879ad0d83f77e。

^OBS-de56d0d879ad0d83f77e

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### revenue · 2025-09-30 · ytd

**503.538 B USD**；状态：source_recorded。证据 ID：OBS-f7d641c119d2abe3df94。

^OBS-f7d641c119d2abe3df94

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### assets · 2025-12-31 · instant

**818.042 B USD**；状态：source_recorded。证据 ID：OBS-e0aee0bb91c2880930d4。

^OBS-e0aee0bb91c2880930d4

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`Assets`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### cash · 2025-12-31 · instant

**86.810 B USD**；状态：source_recorded。证据 ID：OBS-ffa4f87ba9eed06b6b95。

^OBS-ffa4f87ba9eed06b6b95

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### equity · 2025-12-31 · instant

**411.065 B USD**；状态：source_recorded。证据 ID：OBS-b858e98ec818c7d346e6。

^OBS-b858e98ec818c7d346e6

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`StockholdersEquity`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### inventory · 2025-12-31 · instant

**38.325 B USD**；状态：source_recorded。证据 ID：OBS-facf00788c1d8769a671。

^OBS-facf00788c1d8769a671

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`InventoryNet`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### net_income · 2025-12-31 · annual

**77.670 B USD**；状态：source_recorded。证据 ID：OBS-4afb4b40af2bd511f75c。

^OBS-4afb4b40af2bd511f75c

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2025-12-31 · quarter

**21.192 B USD**；状态：needs_review。证据 ID：OBS-785ca2ae426f57e8cd26。

^OBS-785ca2ae426f57e8cd26

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-4afb4b40af2bd511f75c|OBS-4afb4b40af2bd511f75c]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-9fed8ac88c343d92609f|OBS-9fed8ac88c343d92609f]]

### operating_cash_flow · 2025-12-31 · annual

**139.514 B USD**；状态：source_recorded。证据 ID：OBS-efc25b3383602e497bc5。

^OBS-efc25b3383602e497bc5

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_cash_flow · 2025-12-31 · quarter

**54.459 B USD**；状态：needs_review。证据 ID：OBS-d284f0402d614523a56f。

^OBS-d284f0402d614523a56f

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-efc25b3383602e497bc5|OBS-efc25b3383602e497bc5]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-43642367e5d324f6096a|OBS-43642367e5d324f6096a]]

### operating_income · 2025-12-31 · annual

**79.975 B USD**；状态：source_recorded。证据 ID：OBS-cbb2e3a04da0041a4f9a。

^OBS-cbb2e3a04da0041a4f9a

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`OperatingIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2025-12-31 · quarter

**24.977 B USD**；状态：needs_review。证据 ID：OBS-c497d1ab953646ccc34f。

^OBS-c497d1ab953646ccc34f

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`OperatingIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-cbb2e3a04da0041a4f9a|OBS-cbb2e3a04da0041a4f9a]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-758925674977747b7cbf|OBS-758925674977747b7cbf]]

### operating_margin_pct · 2025-12-31 · quarter

**11.71%**；状态：needs_review。证据 ID：OBS-0dc13721720cbbec8977。

^OBS-0dc13721720cbbec8977

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`OperatingIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-c497d1ab953646ccc34f|OBS-c497d1ab953646ccc34f]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-49a441297dacea5bd226|OBS-49a441297dacea5bd226]]

### receivables · 2025-12-31 · instant

**67.729 B USD**；状态：source_recorded。证据 ID：OBS-792a57c0db79716d5ca5。

^OBS-792a57c0db79716d5ca5

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-12-31 · annual

**716.924 B USD**；状态：source_recorded。证据 ID：OBS-83ad3234814bd4b36085。

^OBS-83ad3234814bd4b36085

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### revenue · 2025-12-31 · quarter

**213.386 B USD**；状态：needs_review。证据 ID：OBS-49a441297dacea5bd226。

^OBS-49a441297dacea5bd226

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-83ad3234814bd4b36085|OBS-83ad3234814bd4b36085]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-f7d641c119d2abe3df94|OBS-f7d641c119d2abe3df94]]

### assets · 2026-03-31 · instant

**916.630 B USD**；状态：source_recorded。证据 ID：OBS-250747e7fc2df19ab1d6。

^OBS-250747e7fc2df19ab1d6

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`Assets`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### cash · 2026-03-31 · instant

**101.816 B USD**；状态：source_recorded。证据 ID：OBS-af0517ff4b46ac97e109。

^OBS-af0517ff4b46ac97e109

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2026-03-31 · quarter

**2.780 USD/shares**；状态：source_recorded。证据 ID：OBS-e0d0b3c9380a38195569。

^OBS-e0d0b3c9380a38195569

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`EarningsPerShareDiluted`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2026-03-31 · quarter

**10,874.00 M shares**；状态：source_recorded。证据 ID：OBS-41cc7db8abf5135ac006。

^OBS-41cc7db8abf5135ac006

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2026-03-31 · instant

**441.914 B USD**；状态：source_recorded。证据 ID：OBS-c57455bfc85340ee10d0。

^OBS-c57455bfc85340ee10d0

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`StockholdersEquity`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### inventory · 2026-03-31 · instant

**36.534 B USD**；状态：source_recorded。证据 ID：OBS-21f3d98b972cfb3ffcd0。

^OBS-21f3d98b972cfb3ffcd0

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`InventoryNet`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### net_income · 2026-03-31 · quarter

**30.255 B USD**；状态：source_recorded。证据 ID：OBS-a4c3a9ae4d90b6fe9132。

^OBS-a4c3a9ae4d90b6fe9132

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`NetIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2026-03-31 · quarter

**26.032 B USD**；状态：source_recorded。证据 ID：OBS-7952d7d254f23ddb7461。

^OBS-7952d7d254f23ddb7461

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2026-03-31 · quarter

**23.852 B USD**；状态：source_recorded。证据 ID：OBS-3c7175be45778531df46。

^OBS-3c7175be45778531df46

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2026-03-31 · quarter

**13.14%**；状态：calculation_checked。证据 ID：OBS-03b332ca1a062c16add7。

^OBS-03b332ca1a062c16add7

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-3c7175be45778531df46|OBS-3c7175be45778531df46]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-3c517968c3d0417185c2|OBS-3c517968c3d0417185c2]]

### receivables · 2026-03-31 · instant

**75.532 B USD**；状态：source_recorded。证据 ID：OBS-86dbb2ecca8423944db0。

^OBS-86dbb2ecca8423944db0

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2026-03-31 · quarter

**181.519 B USD**；状态：source_recorded。证据 ID：OBS-3c517968c3d0417185c2。

^OBS-3c517968c3d0417185c2

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### assets · 2026-06-30 · instant

**1,095.689 B USD**；状态：source_recorded。证据 ID：OBS-74118ec433ed1c181d6e。

^OBS-74118ec433ed1c181d6e

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`Assets`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### cash · 2026-06-30 · instant

**78.213 B USD**；状态：source_recorded。证据 ID：OBS-aa4ab887bf530eeec51d。

^OBS-aa4ab887bf530eeec51d

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2026-06-30 · quarter

**5.750 USD/shares**；状态：source_recorded。证据 ID：OBS-c5bc62eec66f9db63281。

^OBS-c5bc62eec66f9db63281

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`EarningsPerShareDiluted`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2026-06-30 · quarter

**10,903.00 M shares**；状态：source_recorded。证据 ID：OBS-aa13dda89106c0688577。

^OBS-aa13dda89106c0688577

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2026-06-30 · instant

**551.620 B USD**；状态：source_recorded。证据 ID：OBS-937cf804db3ac14ff64c。

^OBS-937cf804db3ac14ff64c

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`StockholdersEquity`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### inventory · 2026-06-30 · instant

**38.184 B USD**；状态：source_recorded。证据 ID：OBS-e4b77c6e81203c4dd9f7。

^OBS-e4b77c6e81203c4dd9f7

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`InventoryNet`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### net_income · 2026-06-30 · quarter

**62.647 B USD**；状态：source_recorded。证据 ID：OBS-08cfedbf74741d1baffb。

^OBS-08cfedbf74741d1baffb

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`NetIncomeLoss`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2026-06-30 · quarter

**45.387 B USD**；状态：source_recorded。证据 ID：OBS-14b892ffb8793bd8635b。

^OBS-14b892ffb8793bd8635b

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2026-06-30 · quarter

**27.461 B USD**；状态：source_recorded。证据 ID：OBS-987fadd2fb7d4f85746d。

^OBS-987fadd2fb7d4f85746d

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`OperatingIncomeLoss`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2026-06-30 · quarter

**13.69%**；状态：calculation_checked。证据 ID：OBS-3f580c6ef9e211fabf78。

^OBS-3f580c6ef9e211fabf78

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`OperatingIncomeLoss`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-987fadd2fb7d4f85746d|OBS-987fadd2fb7d4f85746d]]、[[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence#^OBS-10a59770303c1fda7901|OBS-10a59770303c1fda7901]]

### receivables · 2026-06-30 · instant

**88.092 B USD**；状态：source_recorded。证据 ID：OBS-dd1eb3b0ed96858721df。

^OBS-dd1eb3b0ed96858721df

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2026-06-30 · quarter

**200.606 B USD**；状态：source_recorded。证据 ID：OBS-10a59770303c1fda7901。

^OBS-10a59770303c1fda7901

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.
