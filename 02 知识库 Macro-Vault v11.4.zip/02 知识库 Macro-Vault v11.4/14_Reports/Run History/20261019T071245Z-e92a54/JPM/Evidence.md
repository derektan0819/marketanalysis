---
title: "JPM — 本次数据与原文证据（运行 20261019T071245Z-e92a54）"
tags: [reports, run-history, evidence]
created: 2026-10-19
updated: 2026-10-19
source: "引擎运行 20261019T071245Z-e92a54 的数据快照 12_Data/Companies/JPM/20261019T071245Z-e92a54.json"
---
# JPM — 本次数据与原文证据

资料截止：2026-10-19T07:12:45+00:00。

[[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Brief|本次简报]] · [[04_Companies/JPM/Company Profile|JPM 档案]] · [[04_Companies/JPM/Latest Brief|最新简报]] · [[04_Companies/JPM/JPM - Data History|八季数据]] · [[04_Companies/JPM/Evidence Index|证据索引]] · [[04_Companies/JPM/Current Thesis|当前判断]] · [[04_Companies/JPM/Thesis History|判断历史]]

本页是保存快照的阅读视图；链接表示引用或计算依赖，不表示独立验证或因果关系。
包含最近八季的观察值，以及计算所需的较早输入。后续运行各自生成证据页，旧简报不会跳到新快照。

## 原始快照
[[12_Data/Companies/JPM/20261019T071245Z-e92a54.json|JSON 快照（外部编辑器）]]

## 财报原文
- [[13_Sources/Records/SRC-9c13f4e336126491246ce357|10-Q]]；期间／事件日：2026-06-30
  提取正文：[[13_Sources/Raw/SRC-9c13f4e336126491246ce357|SRC-9c13f4e336126491246ce357 正文]]
- [[13_Sources/Records/SRC-821ba21da94c21df60d729fd|10-K]]；期间／事件日：2025-12-31
  提取正文：[[13_Sources/Raw/SRC-821ba21da94c21df60d729fd|SRC-821ba21da94c21df60d729fd 正文]]
- [[13_Sources/Records/SRC-0d22ae2e56e5e9209f93b78c|earnings_release_8K]]；期间／事件日：2026-10-13
  提取正文：[[13_Sources/Raw/SRC-0d22ae2e56e5e9209f93b78c.earnings|SRC-0d22ae2e56e5e9209f93b78c 正文]]

## 数字与计算依赖

### assets · 2024-09-30 · instant

**4,210.048 B USD**；状态：source_recorded。证据 ID：OBS-9783a19924a063eea8b4。

^OBS-9783a19924a063eea8b4

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`Assets`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### bank_net_interest_income · 2024-09-30 · quarter

**23.405 B USD**；状态：source_recorded。证据 ID：OBS-023145e3ce112c2bac44。

^OBS-023145e3ce112c2bac44

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`InterestIncomeExpenseNet`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：The net amount of operating interest income (expense).

### bank_net_interest_income · 2024-09-30 · ytd

**69.233 B USD**；状态：source_recorded。证据 ID：OBS-b479cef6f6a6c7ce78cc。

^OBS-b479cef6f6a6c7ce78cc

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`InterestIncomeExpenseNet`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：The net amount of operating interest income (expense).

### diluted_eps · 2024-09-30 · quarter

**4.370 USD/shares**；状态：source_recorded。证据 ID：OBS-f86f34c8408a57028b52。

^OBS-f86f34c8408a57028b52

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`EarningsPerShareDiluted`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2024-09-30 · quarter

**2,865.90 M shares**；状态：source_recorded。证据 ID：OBS-46883c6744aacf52cf15。

^OBS-46883c6744aacf52cf15

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2024-09-30 · instant

**345.836 B USD**；状态：source_recorded。证据 ID：OBS-3563583ce8fded98fac9。

^OBS-3563583ce8fded98fac9

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`StockholdersEquity`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### liabilities · 2024-09-30 · instant

**3,864.212 B USD**；状态：source_recorded。证据 ID：OBS-577f2f897e31dc5e9290。

^OBS-577f2f897e31dc5e9290

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0000019617-24-000611。
字段：`Liabilities`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000001961724000611/0000019617-24-000611-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2024-09-30 · quarter

**12.898 B USD**；状态：source_recorded。证据 ID：OBS-9a15780927bbae993955。

^OBS-9a15780927bbae993955

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`NetIncomeLoss`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2024-09-30 · ytd

**44.466 B USD**；状态：source_recorded。证据 ID：OBS-f1745d41b20ab169e068。

^OBS-f1745d41b20ab169e068

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`NetIncomeLoss`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### assets · 2024-12-31 · instant

**4,002.814 B USD**；状态：source_recorded。证据 ID：OBS-6ca767e3115dc1d139d8。

^OBS-6ca767e3115dc1d139d8

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`Assets`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### bank_net_interest_income · 2024-12-31 · annual

**92.583 B USD**；状态：source_recorded。证据 ID：OBS-aeb492dd87af4629ebfa。

^OBS-aeb492dd87af4629ebfa

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`InterestIncomeExpenseNet`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
定义：The net amount of operating interest income (expense).

### bank_net_interest_income · 2024-12-31 · quarter

**23.350 B USD**；状态：needs_review。证据 ID：OBS-d0943232e84bff827760。

^OBS-d0943232e84bff827760

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`InterestIncomeExpenseNet`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
定义：The net amount of operating interest income (expense).
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Evidence#^OBS-aeb492dd87af4629ebfa|OBS-aeb492dd87af4629ebfa]]、[[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Evidence#^OBS-b479cef6f6a6c7ce78cc|OBS-b479cef6f6a6c7ce78cc]]

### equity · 2024-12-31 · instant

**344.758 B USD**；状态：source_recorded。证据 ID：OBS-bf413cd123def84207c1。

^OBS-bf413cd123def84207c1

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`StockholdersEquity`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### liabilities · 2024-12-31 · instant

**3,658.056 B USD**；状态：source_recorded。证据 ID：OBS-0553041de803fca6c2f3。

^OBS-0553041de803fca6c2f3

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`Liabilities`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2024-12-31 · annual

**58.471 B USD**；状态：source_recorded。证据 ID：OBS-f5ca43d485e3ab7fc4c6。

^OBS-f5ca43d485e3ab7fc4c6

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`NetIncomeLoss`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2024-12-31 · quarter

**14.005 B USD**；状态：needs_review。证据 ID：OBS-6274dbf272c1865f3fa0。

^OBS-6274dbf272c1865f3fa0

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`NetIncomeLoss`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Evidence#^OBS-f5ca43d485e3ab7fc4c6|OBS-f5ca43d485e3ab7fc4c6]]、[[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Evidence#^OBS-f1745d41b20ab169e068|OBS-f1745d41b20ab169e068]]

### assets · 2025-03-31 · instant

**4,357.856 B USD**；状态：source_recorded。证据 ID：OBS-a7ab6560bb971506d2f9。

^OBS-a7ab6560bb971506d2f9

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`Assets`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### bank_net_interest_income · 2025-03-31 · quarter

**23.273 B USD**；状态：source_recorded。证据 ID：OBS-2b09c4952a5404070613。

^OBS-2b09c4952a5404070613

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`InterestIncomeExpenseNet`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html
定义：The net amount of operating interest income (expense).

### diluted_eps · 2025-03-31 · quarter

**5.070 USD/shares**；状态：source_recorded。证据 ID：OBS-33008aa656aa35d99c73。

^OBS-33008aa656aa35d99c73

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`EarningsPerShareDiluted`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-03-31 · quarter

**2,824.30 M shares**；状态：source_recorded。证据 ID：OBS-2d2560941b62cd315650。

^OBS-2d2560941b62cd315650

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-03-31 · instant

**351.420 B USD**；状态：source_recorded。证据 ID：OBS-9cf909b264044955b556。

^OBS-9cf909b264044955b556

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`StockholdersEquity`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### liabilities · 2025-03-31 · instant

**4,006.436 B USD**；状态：source_recorded。证据 ID：OBS-61fff2df8d58f6180824。

^OBS-61fff2df8d58f6180824

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0000019617-25-000421。
字段：`Liabilities`；申报日期：2025-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000001961725000421/0000019617-25-000421-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-03-31 · quarter

**14.643 B USD**；状态：source_recorded。证据 ID：OBS-bfbd05640a46a6fbed91。

^OBS-bfbd05640a46a6fbed91

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`NetIncomeLoss`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### assets · 2025-06-30 · instant

**4,552.482 B USD**；状态：source_recorded。证据 ID：OBS-f4d069f3a50debbfe371。

^OBS-f4d069f3a50debbfe371

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`Assets`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### bank_net_interest_income · 2025-06-30 · quarter

**23.209 B USD**；状态：source_recorded。证据 ID：OBS-452fbc81a59ed1871d67。

^OBS-452fbc81a59ed1871d67

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`InterestIncomeExpenseNet`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：The net amount of operating interest income (expense).

### diluted_eps · 2025-06-30 · quarter

**5.240 USD/shares**；状态：source_recorded。证据 ID：OBS-2917aecceb9489e5e36e。

^OBS-2917aecceb9489e5e36e

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`EarningsPerShareDiluted`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-06-30 · quarter

**2,793.70 M shares**；状态：source_recorded。证据 ID：OBS-8a1de71fb0d1495ef37e。

^OBS-8a1de71fb0d1495ef37e

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-06-30 · instant

**356.924 B USD**；状态：source_recorded。证据 ID：OBS-592889f39f9dfac46813。

^OBS-592889f39f9dfac46813

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`StockholdersEquity`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### liabilities · 2025-06-30 · instant

**4,195.558 B USD**；状态：source_recorded。证据 ID：OBS-04e7a0814dfc7aed1771。

^OBS-04e7a0814dfc7aed1771

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0000019617-25-000615。
字段：`Liabilities`；申报日期：2025-08-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000001961725000615/0000019617-25-000615-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-06-30 · quarter

**14.987 B USD**；状态：source_recorded。证据 ID：OBS-ceda7ca40fbe21b5c560。

^OBS-ceda7ca40fbe21b5c560

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`NetIncomeLoss`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### assets · 2025-09-30 · instant

**4,560.205 B USD**；状态：source_recorded。证据 ID：OBS-eb6ddb2ee4bc51e0aec2。

^OBS-eb6ddb2ee4bc51e0aec2

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`Assets`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### bank_net_interest_income · 2025-09-30 · quarter

**23.966 B USD**；状态：source_recorded。证据 ID：OBS-71d98d3d41a3edc6037e。

^OBS-71d98d3d41a3edc6037e

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`InterestIncomeExpenseNet`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：The net amount of operating interest income (expense).

### bank_net_interest_income · 2025-09-30 · ytd

**70.448 B USD**；状态：source_recorded。证据 ID：OBS-ff4697884bdbd77f89f9。

^OBS-ff4697884bdbd77f89f9

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`InterestIncomeExpenseNet`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：The net amount of operating interest income (expense).

### diluted_eps · 2025-09-30 · quarter

**5.070 USD/shares**；状态：source_recorded。证据 ID：OBS-2d3a787fac6c92fa5c55。

^OBS-2d3a787fac6c92fa5c55

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`EarningsPerShareDiluted`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-09-30 · quarter

**2,767.60 M shares**；状态：source_recorded。证据 ID：OBS-4113c729469f3832bf4b。

^OBS-4113c729469f3832bf4b

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-09-30 · instant

**360.212 B USD**；状态：source_recorded。证据 ID：OBS-4d1919c265601c053623。

^OBS-4d1919c265601c053623

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`StockholdersEquity`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### liabilities · 2025-09-30 · instant

**4,199.993 B USD**；状态：source_recorded。证据 ID：OBS-08f74c7f22d56edf71eb。

^OBS-08f74c7f22d56edf71eb

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`Liabilities`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-09-30 · quarter

**14.393 B USD**；状态：source_recorded。证据 ID：OBS-75b9c83f298d73fc4b28。

^OBS-75b9c83f298d73fc4b28

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`NetIncomeLoss`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2025-09-30 · ytd

**44.023 B USD**；状态：source_recorded。证据 ID：OBS-bffe9a95cc1016ba54ce。

^OBS-bffe9a95cc1016ba54ce

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`NetIncomeLoss`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### assets · 2025-12-31 · instant

**4,424.900 B USD**；状态：source_recorded。证据 ID：OBS-bf06548d34cc2032c46e。

^OBS-bf06548d34cc2032c46e

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`Assets`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### bank_net_interest_income · 2025-12-31 · annual

**95.443 B USD**；状态：source_recorded。证据 ID：OBS-ed4e5fc0e5ac650cbc01。

^OBS-ed4e5fc0e5ac650cbc01

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`InterestIncomeExpenseNet`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
定义：The net amount of operating interest income (expense).

### bank_net_interest_income · 2025-12-31 · quarter

**24.995 B USD**；状态：needs_review。证据 ID：OBS-6b9f2fbceeb99e4da6d2。

^OBS-6b9f2fbceeb99e4da6d2

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`InterestIncomeExpenseNet`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
定义：The net amount of operating interest income (expense).
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Evidence#^OBS-ed4e5fc0e5ac650cbc01|OBS-ed4e5fc0e5ac650cbc01]]、[[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Evidence#^OBS-ff4697884bdbd77f89f9|OBS-ff4697884bdbd77f89f9]]

### equity · 2025-12-31 · instant

**362.438 B USD**；状态：source_recorded。证据 ID：OBS-9f62297ab10cdc3de86b。

^OBS-9f62297ab10cdc3de86b

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`StockholdersEquity`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### liabilities · 2025-12-31 · instant

**4,062.462 B USD**；状态：source_recorded。证据 ID：OBS-2a0c8b57158d565ff0d0。

^OBS-2a0c8b57158d565ff0d0

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`Liabilities`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-12-31 · annual

**57.048 B USD**；状态：source_recorded。证据 ID：OBS-97048a226b6cf9cb8c38。

^OBS-97048a226b6cf9cb8c38

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`NetIncomeLoss`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2025-12-31 · quarter

**13.025 B USD**；状态：needs_review。证据 ID：OBS-fddc1fc45021e0da2a7e。

^OBS-fddc1fc45021e0da2a7e

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`NetIncomeLoss`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Evidence#^OBS-97048a226b6cf9cb8c38|OBS-97048a226b6cf9cb8c38]]、[[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Evidence#^OBS-bffe9a95cc1016ba54ce|OBS-bffe9a95cc1016ba54ce]]

### assets · 2026-03-31 · instant

**4,900.475 B USD**；状态：source_recorded。证据 ID：OBS-7498be4a14efd7b7029a。

^OBS-7498be4a14efd7b7029a

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`Assets`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### bank_net_interest_income · 2026-03-31 · quarter

**25.366 B USD**；状态：source_recorded。证据 ID：OBS-84391522e7a9904b3240。

^OBS-84391522e7a9904b3240

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`InterestIncomeExpenseNet`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html
定义：The net amount of operating interest income (expense).

### diluted_eps · 2026-03-31 · quarter

**5.940 USD/shares**；状态：source_recorded。证据 ID：OBS-ad07f325ee06b46272ed。

^OBS-ad07f325ee06b46272ed

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`EarningsPerShareDiluted`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2026-03-31 · quarter

**2,720.20 M shares**；状态：source_recorded。证据 ID：OBS-5fb26bb46148be22f77a。

^OBS-5fb26bb46148be22f77a

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2026-03-31 · instant

**364.038 B USD**；状态：source_recorded。证据 ID：OBS-aff4e97346004038f258。

^OBS-aff4e97346004038f258

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`StockholdersEquity`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### liabilities · 2026-03-31 · instant

**4,536.437 B USD**；状态：source_recorded。证据 ID：OBS-3f455b4f37a65dadc4b6。

^OBS-3f455b4f37a65dadc4b6

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`Liabilities`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2026-03-31 · quarter

**16.494 B USD**；状态：source_recorded。证据 ID：OBS-50fc03bc7224201686cc。

^OBS-50fc03bc7224201686cc

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`NetIncomeLoss`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### assets · 2026-06-30 · instant

**5,015.069 B USD**；状态：source_recorded。证据 ID：OBS-c08d0c20a869014f2601。

^OBS-c08d0c20a869014f2601

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`Assets`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### bank_net_interest_income · 2026-06-30 · quarter

**25.511 B USD**；状态：source_recorded。证据 ID：OBS-cace38884027e5fe460a。

^OBS-cace38884027e5fe460a

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`InterestIncomeExpenseNet`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：The net amount of operating interest income (expense).

### diluted_eps · 2026-06-30 · quarter

**7.700 USD/shares**；状态：source_recorded。证据 ID：OBS-cbb1600e835415b7042f。

^OBS-cbb1600e835415b7042f

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`EarningsPerShareDiluted`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2026-06-30 · quarter

**2,694.20 M shares**；状态：source_recorded。证据 ID：OBS-ef06785e621d4b925dbc。

^OBS-ef06785e621d4b925dbc

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2026-06-30 · instant

**374.598 B USD**；状态：source_recorded。证据 ID：OBS-63a9552216b98af1ffaa。

^OBS-63a9552216b98af1ffaa

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`StockholdersEquity`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### liabilities · 2026-06-30 · instant

**4,640.471 B USD**；状态：source_recorded。证据 ID：OBS-ff57528913badeb68dcc。

^OBS-ff57528913badeb68dcc

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`Liabilities`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2026-06-30 · quarter

**21.155 B USD**；状态：source_recorded。证据 ID：OBS-e61cd9b72c1afddff718。

^OBS-e61cd9b72c1afddff718

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`NetIncomeLoss`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.
