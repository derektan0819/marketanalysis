---
title: "JPM — 一页研究简报"
created: 2026-10-19
updated: 2026-10-19
source: "引擎运行 20261019T071245Z-e92a54 的数据快照 12_Data/Companies/JPM/20261019T071245Z-e92a54.json"
company: JPM
created_at: "2026-10-19T07:12:48+00:00"
data_cutoff: "2026-10-19T07:12:45+00:00"
status: Draft
---
# JPM — 一页研究简报

**资料状态：** Data Ready / Analysis Incomplete。**AI 状态：** not_configured。
**最新可用季度：** 2026-06-30。**观察范围：** 8 个季度；详情见 [[JPM - Data History]]。

**经营判断：** 已生成数据包，等待 AI 完成原文阅读与解释；不把数据变化自动解释为投资结论。

**预期与估值：** 未连接发布前共识和行情／估值数据；不能据此认定超预期、低估或股价方向。

## 本次关键数字
| 指标 | 数值 | 证据 ID | 状态 |
|---|---|---|---|
| net_income | 21.155 B USD | [[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Evidence#^OBS-e61cd9b72c1afddff718\|OBS-e61cd9b72c1afddff718]] | source_recorded |
| bank_net_interest_income | 25.511 B USD | [[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Evidence#^OBS-cace38884027e5fe460a\|OBS-cace38884027e5fe460a]] | source_recorded |

## 阅读覆盖与例外
| 文件／项目 | 取得 | 人工／AI 内容阅读 |
|---|---|---|
| [[13_Sources/Records/SRC-9c13f4e336126491246ce357\|10-Q]] / 2026-06-30 | 是 | 未独立验证；见 AI 覆盖记录 |
| [[13_Sources/Records/SRC-821ba21da94c21df60d729fd\|10-K]] / 2025-12-31 | 是 | 未独立验证；见 AI 覆盖记录 |
| [[13_Sources/Records/SRC-0d22ae2e56e5e9209f93b78c\|earnings_release_8K]] / 事件日 2026-10-13 | 是 | 未独立验证；见 AI 覆盖记录 |
| 电话会 Q&A、分部完整性、脚注变化 | 不能由 Company Facts 接口保证 | 待补齐 |

财报 8-K 的事件日不是业绩期间结束日。新闻稿可能比结构化季度数据更新；需读取 EX-99 后确认期间与新增数字，不能只看八季表认定没有新业绩。

## 原判断与未来验证
原判断保存在 [[04_Companies/JPM/Current Thesis]]。新判断需说明证据、期限、反例及失效条件。
无可靠新证据时维持原判断；缺失资料时写“尚不能判断”。完整且通过引用检查的候选仅在 auto_register_forecasts 已开启时登记；登记不代表预测正确。

## 来源与计算
本次数字与计算输入：[[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Evidence|证据页]]；结构化快照：[[12_Data/Companies/JPM/20261019T071245Z-e92a54.json|JSON 文件（外部编辑器）]]。
[[04_Companies/JPM/Company Profile|JPM 档案]] · [[04_Companies/JPM/Latest Brief|最新简报]] · [[04_Companies/JPM/JPM - Data History|八季数据]] · [[04_Companies/JPM/Evidence Index|证据索引]] · [[04_Companies/JPM/Current Thesis|当前判断]] · [[04_Companies/JPM/Thesis History|判断历史]]
每条数字带来源、口径、申报日期、原始标签及计算输入。下载成功和算术通过不构成完整核验。

## 需要你处理
配置 AI 接口后可自动阅读；仅将会改变核心判断的未解决问题交给用户。当前尚未完成语义阅读。
