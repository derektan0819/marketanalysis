---
title: "MSFT — 本次数据与原文证据（运行 20261019T071245Z-e92a54）"
tags: [reports, run-history, evidence]
created: 2026-10-19
updated: 2026-10-19
source: "引擎运行 20261019T071245Z-e92a54 的数据快照 12_Data/Companies/MSFT/20261019T071245Z-e92a54.json"
---
# MSFT — 本次数据与原文证据

资料截止：2026-10-19T07:12:45+00:00。

[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Brief|本次简报]] · [[04_Companies/MSFT/Company Profile|MSFT 档案]] · [[04_Companies/MSFT/Latest Brief|最新简报]] · [[04_Companies/MSFT/MSFT - Data History|八季数据]] · [[04_Companies/MSFT/Evidence Index|证据索引]] · [[04_Companies/MSFT/Current Thesis|当前判断]] · [[04_Companies/MSFT/Thesis History|判断历史]]

本页是保存快照的阅读视图；链接表示引用或计算依赖，不表示独立验证或因果关系。
包含最近八季的观察值，以及计算所需的较早输入。后续运行各自生成证据页，旧简报不会跳到新快照。

## 原始快照
[[12_Data/Companies/MSFT/20261019T071245Z-e92a54.json|JSON 快照（外部编辑器）]]

## 财报原文
- [[13_Sources/Records/SRC-2b259bd14aae3c6cda610019|10-Q]]；期间／事件日：2026-03-31
  提取正文：[[13_Sources/Raw/SRC-2b259bd14aae3c6cda610019|SRC-2b259bd14aae3c6cda610019 正文]]
- [[13_Sources/Records/SRC-ee4a8840d145293adfaac731|10-K]]；期间／事件日：2026-06-30
  提取正文：[[13_Sources/Raw/SRC-ee4a8840d145293adfaac731|SRC-ee4a8840d145293adfaac731 正文]]
- [[13_Sources/Records/SRC-fd41fbb8d4e31433b10eee67|earnings_release_8K]]；期间／事件日：2026-07-29
  提取正文：[[13_Sources/Raw/SRC-fd41fbb8d4e31433b10eee67.earnings|SRC-fd41fbb8d4e31433b10eee67 正文]]

## 数字与计算依赖

### assets · 2024-09-30 · instant

**523.013 B USD**；状态：source_recorded。证据 ID：OBS-86aa51cb240380c9f84e。

^OBS-86aa51cb240380c9f84e

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-24-118967。
字段：`Assets`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017024118967/0000950170-24-118967-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2024-09-30 · quarter

**14.923 B USD**；状态：source_recorded。证据 ID：OBS-6d776f85af34cbb59085。

^OBS-6d776f85af34cbb59085

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### cash · 2024-09-30 · instant

**20.840 B USD**；状态：source_recorded。证据 ID：OBS-ee9bb07d17e51c56a782。

^OBS-ee9bb07d17e51c56a782

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-24-118967。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017024118967/0000950170-24-118967-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2024-09-30 · quarter

**3.300 USD/shares**；状态：source_recorded。证据 ID：OBS-2c575b466d563c086631。

^OBS-2c575b466d563c086631

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`EarningsPerShareDiluted`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2024-09-30 · quarter

**7,470.00 M shares**；状态：source_recorded。证据 ID：OBS-d73dd6e2d6dfc9bb57cd。

^OBS-d73dd6e2d6dfc9bb57cd

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2024-09-30 · instant

**287.723 B USD**；状态：source_recorded。证据 ID：OBS-841976e27b5774695fd9。

^OBS-841976e27b5774695fd9

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`StockholdersEquity`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2024-09-30 · quarter

**19.257 B USD**；状态：calculation_checked。证据 ID：OBS-3928f2d7204ea8e4e6eb。

^OBS-3928f2d7204ea8e4e6eb

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-88055476b9e3db5ee93c|OBS-88055476b9e3db5ee93c]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-6d776f85af34cbb59085|OBS-6d776f85af34cbb59085]]

### gross_margin_pct · 2024-09-30 · quarter

**69.35%**；状态：calculation_checked。证据 ID：OBS-f5f6286a1055b2c01b35。

^OBS-f5f6286a1055b2c01b35

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`GrossProfit`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-f7d4e4a5889ff7a3fd68|OBS-f7d4e4a5889ff7a3fd68]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-94113ab08168b734d92b|OBS-94113ab08168b734d92b]]

### gross_profit · 2024-09-30 · quarter

**45.486 B USD**；状态：source_recorded。证据 ID：OBS-f7d4e4a5889ff7a3fd68。

^OBS-f7d4e4a5889ff7a3fd68

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`GrossProfit`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### inventory · 2024-09-30 · instant

**1.626 B USD**；状态：source_recorded。证据 ID：OBS-8d71b40b5b6be221f0b2。

^OBS-8d71b40b5b6be221f0b2

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-24-118967。
字段：`InventoryNet`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017024118967/0000950170-24-118967-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2024-09-30 · instant

**235.290 B USD**；状态：source_recorded。证据 ID：OBS-93ea91ba90304f660440。

^OBS-93ea91ba90304f660440

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-24-118967。
字段：`Liabilities`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017024118967/0000950170-24-118967-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2024-09-30 · quarter

**24.667 B USD**；状态：source_recorded。证据 ID：OBS-c41ffc294d1b86db810a。

^OBS-c41ffc294d1b86db810a

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`NetIncomeLoss`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2024-09-30 · quarter

**34.180 B USD**；状态：source_recorded。证据 ID：OBS-88055476b9e3db5ee93c。

^OBS-88055476b9e3db5ee93c

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2024-09-30 · quarter

**30.552 B USD**；状态：source_recorded。证据 ID：OBS-84b982e60d5b599ac1ee。

^OBS-84b982e60d5b599ac1ee

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`OperatingIncomeLoss`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2024-09-30 · quarter

**46.58%**；状态：calculation_checked。证据 ID：OBS-c7922cd00eecff8efa8e。

^OBS-c7922cd00eecff8efa8e

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`OperatingIncomeLoss`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-84b982e60d5b599ac1ee|OBS-84b982e60d5b599ac1ee]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-94113ab08168b734d92b|OBS-94113ab08168b734d92b]]

### receivables · 2024-09-30 · instant

**44.148 B USD**；状态：source_recorded。证据 ID：OBS-1bbf63b1c0ccd7851b1b。

^OBS-1bbf63b1c0ccd7851b1b

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-24-118967。
字段：`AccountsReceivableNetCurrent`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017024118967/0000950170-24-118967-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2024-09-30 · quarter

**65.585 B USD**；状态：source_recorded。证据 ID：OBS-94113ab08168b734d92b。

^OBS-94113ab08168b734d92b

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### assets · 2024-12-31 · instant

**533.898 B USD**；状态：source_recorded。证据 ID：OBS-f0bf6265cd261cf4a747。

^OBS-f0bf6265cd261cf4a747

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-010491。
字段：`Assets`；申报日期：2025-01-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025010491/0000950170-25-010491-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2024-12-31 · quarter

**15.804 B USD**；状态：source_recorded。证据 ID：OBS-0e955cb6df5b698d74e6。

^OBS-0e955cb6df5b698d74e6

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### cash · 2024-12-31 · instant

**17.482 B USD**；状态：source_recorded。证据 ID：OBS-01b194c05a7f88b4dcde。

^OBS-01b194c05a7f88b4dcde

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-010491。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-01-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025010491/0000950170-25-010491-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2024-12-31 · quarter

**3.230 USD/shares**；状态：source_recorded。证据 ID：OBS-34fdbe54f58a3bae9744。

^OBS-34fdbe54f58a3bae9744

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`EarningsPerShareDiluted`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2024-12-31 · quarter

**7,468.00 M shares**；状态：source_recorded。证据 ID：OBS-bc9702d6d331b18db692。

^OBS-bc9702d6d331b18db692

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2024-12-31 · instant

**302.695 B USD**；状态：source_recorded。证据 ID：OBS-62dd19a5d0cb6c3ddb0a。

^OBS-62dd19a5d0cb6c3ddb0a

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`StockholdersEquity`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2024-12-31 · quarter

**6.487 B USD**；状态：calculation_checked。证据 ID：OBS-e74513dc3d05bfc1d4c7。

^OBS-e74513dc3d05bfc1d4c7

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-4263def46673da572786|OBS-4263def46673da572786]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-0e955cb6df5b698d74e6|OBS-0e955cb6df5b698d74e6]]

### gross_margin_pct · 2024-12-31 · quarter

**68.69%**；状态：calculation_checked。证据 ID：OBS-8901ec58f7d63fe22fab。

^OBS-8901ec58f7d63fe22fab

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`GrossProfit`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-2a1e9eb7b82a39899467|OBS-2a1e9eb7b82a39899467]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-4540e5554099ba3e8859|OBS-4540e5554099ba3e8859]]

### gross_profit · 2024-12-31 · quarter

**47.833 B USD**；状态：source_recorded。证据 ID：OBS-2a1e9eb7b82a39899467。

^OBS-2a1e9eb7b82a39899467

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`GrossProfit`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### inventory · 2024-12-31 · instant

**0.909 B USD**；状态：source_recorded。证据 ID：OBS-8ba4e91e57c43161f508。

^OBS-8ba4e91e57c43161f508

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-010491。
字段：`InventoryNet`；申报日期：2025-01-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025010491/0000950170-25-010491-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2024-12-31 · instant

**231.203 B USD**；状态：source_recorded。证据 ID：OBS-bfea65ca4720b1ec1966。

^OBS-bfea65ca4720b1ec1966

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-010491。
字段：`Liabilities`；申报日期：2025-01-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025010491/0000950170-25-010491-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2024-12-31 · quarter

**24.108 B USD**；状态：source_recorded。证据 ID：OBS-e1c4da2c061beda7df16。

^OBS-e1c4da2c061beda7df16

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`NetIncomeLoss`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2024-12-31 · quarter

**22.291 B USD**；状态：source_recorded。证据 ID：OBS-4263def46673da572786。

^OBS-4263def46673da572786

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2024-12-31 · quarter

**31.653 B USD**；状态：source_recorded。证据 ID：OBS-5baa1c64218cecba114b。

^OBS-5baa1c64218cecba114b

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`OperatingIncomeLoss`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2024-12-31 · quarter

**45.46%**；状态：calculation_checked。证据 ID：OBS-3cc01d32ac3514def1c2。

^OBS-3cc01d32ac3514def1c2

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`OperatingIncomeLoss`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-5baa1c64218cecba114b|OBS-5baa1c64218cecba114b]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-4540e5554099ba3e8859|OBS-4540e5554099ba3e8859]]

### receivables · 2024-12-31 · instant

**48.188 B USD**；状态：source_recorded。证据 ID：OBS-ff314be3e319abbcf9eb。

^OBS-ff314be3e319abbcf9eb

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-010491。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-01-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025010491/0000950170-25-010491-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2024-12-31 · quarter

**69.632 B USD**；状态：source_recorded。证据 ID：OBS-4540e5554099ba3e8859。

^OBS-4540e5554099ba3e8859

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### assets · 2025-03-31 · instant

**562.624 B USD**；状态：source_recorded。证据 ID：OBS-069312099810698c712f。

^OBS-069312099810698c712f

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-061046。
字段：`Assets`；申报日期：2025-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025061046/0000950170-25-061046-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2025-03-31 · quarter

**16.745 B USD**；状态：source_recorded。证据 ID：OBS-170c892b9339ac825a1e。

^OBS-170c892b9339ac825a1e

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### capex_cash · 2025-03-31 · ytd

**47.472 B USD**；状态：source_recorded。证据 ID：OBS-aa389db8b0b745e388a3。

^OBS-aa389db8b0b745e388a3

期间：2024-07-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### cash · 2025-03-31 · instant

**28.828 B USD**；状态：source_recorded。证据 ID：OBS-4902c08064119a7aea40。

^OBS-4902c08064119a7aea40

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-061046。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025061046/0000950170-25-061046-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2025-03-31 · quarter

**3.460 USD/shares**；状态：source_recorded。证据 ID：OBS-f3ac9406ac02f00bed6d。

^OBS-f3ac9406ac02f00bed6d

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`EarningsPerShareDiluted`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-03-31 · quarter

**7,461.00 M shares**；状态：source_recorded。证据 ID：OBS-301bf887b6253edb0141。

^OBS-301bf887b6253edb0141

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-03-31 · instant

**321.891 B USD**；状态：source_recorded。证据 ID：OBS-dc15242687ee4c28c786。

^OBS-dc15242687ee4c28c786

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`StockholdersEquity`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2025-03-31 · quarter

**20.299 B USD**；状态：calculation_checked。证据 ID：OBS-29c8acea692fd7e4257b。

^OBS-29c8acea692fd7e4257b

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-efb0847c6d41bbfd95b3|OBS-efb0847c6d41bbfd95b3]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-170c892b9339ac825a1e|OBS-170c892b9339ac825a1e]]

### gross_margin_pct · 2025-03-31 · quarter

**68.72%**；状态：calculation_checked。证据 ID：OBS-c8216eed20d5f3f4a62e。

^OBS-c8216eed20d5f3f4a62e

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`GrossProfit`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-a71d5a4c949906b31b87|OBS-a71d5a4c949906b31b87]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-9e923215dad4eac98783|OBS-9e923215dad4eac98783]]

### gross_profit · 2025-03-31 · quarter

**48.147 B USD**；状态：source_recorded。证据 ID：OBS-a71d5a4c949906b31b87。

^OBS-a71d5a4c949906b31b87

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`GrossProfit`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### gross_profit · 2025-03-31 · ytd

**141.466 B USD**；状态：source_recorded。证据 ID：OBS-15e747bc67a1504b80b7。

^OBS-15e747bc67a1504b80b7

期间：2024-07-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`GrossProfit`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### inventory · 2025-03-31 · instant

**0.848 B USD**；状态：source_recorded。证据 ID：OBS-a889aa469c102bf47b2d。

^OBS-a889aa469c102bf47b2d

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-061046。
字段：`InventoryNet`；申报日期：2025-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025061046/0000950170-25-061046-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2025-03-31 · instant

**240.733 B USD**；状态：source_recorded。证据 ID：OBS-4272fe663437861996ff。

^OBS-4272fe663437861996ff

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-061046。
字段：`Liabilities`；申报日期：2025-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025061046/0000950170-25-061046-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-03-31 · quarter

**25.824 B USD**；状态：source_recorded。证据 ID：OBS-29d73d0dcfb1a4e293d2。

^OBS-29d73d0dcfb1a4e293d2

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2025-03-31 · ytd

**74.599 B USD**；状态：source_recorded。证据 ID：OBS-5004efc4b99f52e36b70。

^OBS-5004efc4b99f52e36b70

期间：2024-07-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2025-03-31 · quarter

**37.044 B USD**；状态：source_recorded。证据 ID：OBS-efb0847c6d41bbfd95b3。

^OBS-efb0847c6d41bbfd95b3

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_cash_flow · 2025-03-31 · ytd

**93.515 B USD**；状态：source_recorded。证据 ID：OBS-587e0c62ceb504d1b677。

^OBS-587e0c62ceb504d1b677

期间：2024-07-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2025-03-31 · quarter

**32.000 B USD**；状态：source_recorded。证据 ID：OBS-814185c8ea1a3b9b5b7a。

^OBS-814185c8ea1a3b9b5b7a

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`OperatingIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2025-03-31 · ytd

**94.205 B USD**；状态：source_recorded。证据 ID：OBS-2c1cb767556aa9508111。

^OBS-2c1cb767556aa9508111

期间：2024-07-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`OperatingIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2025-03-31 · quarter

**45.67%**；状态：calculation_checked。证据 ID：OBS-d803e88d099614854cad。

^OBS-d803e88d099614854cad

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`OperatingIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-814185c8ea1a3b9b5b7a|OBS-814185c8ea1a3b9b5b7a]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-9e923215dad4eac98783|OBS-9e923215dad4eac98783]]

### receivables · 2025-03-31 · instant

**51.700 B USD**；状态：source_recorded。证据 ID：OBS-baf05dcfc8764a077e66。

^OBS-baf05dcfc8764a077e66

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-061046。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025061046/0000950170-25-061046-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-03-31 · quarter

**70.066 B USD**；状态：source_recorded。证据 ID：OBS-9e923215dad4eac98783。

^OBS-9e923215dad4eac98783

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### revenue · 2025-03-31 · ytd

**205.283 B USD**；状态：source_recorded。证据 ID：OBS-589e5890c1a8c18c1bfe。

^OBS-589e5890c1a8c18c1bfe

期间：2024-07-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### assets · 2025-06-30 · instant

**619.003 B USD**；状态：source_recorded。证据 ID：OBS-ceb8a64d266ba4bee529。

^OBS-ceb8a64d266ba4bee529

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`Assets`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2025-06-30 · annual

**64.551 B USD**；状态：source_recorded。证据 ID：OBS-4b826d0204b05e15d302。

^OBS-4b826d0204b05e15d302

期间：2024-07-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### capex_cash · 2025-06-30 · quarter

**17.079 B USD**；状态：needs_review。证据 ID：OBS-20388641402fa87d7283。

^OBS-20388641402fa87d7283

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-4b826d0204b05e15d302|OBS-4b826d0204b05e15d302]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-aa389db8b0b745e388a3|OBS-aa389db8b0b745e388a3]]

### cash · 2025-06-30 · instant

**30.242 B USD**；状态：source_recorded。证据 ID：OBS-e99552b138c089249c84。

^OBS-e99552b138c089249c84

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### equity · 2025-06-30 · instant

**343.479 B USD**；状态：source_recorded。证据 ID：OBS-df11f03ac9cb60214176。

^OBS-df11f03ac9cb60214176

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`StockholdersEquity`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2025-06-30 · quarter

**25.568 B USD**；状态：needs_review。证据 ID：OBS-4831163e7b6f176fe07c。

^OBS-4831163e7b6f176fe07c

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-ae0117b1133bd4d2d449|OBS-ae0117b1133bd4d2d449]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-20388641402fa87d7283|OBS-20388641402fa87d7283]]

### gross_margin_pct · 2025-06-30 · quarter

**68.58%**；状态：needs_review。证据 ID：OBS-22a5c5519c797d69c301。

^OBS-22a5c5519c797d69c301

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`GrossProfit`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-e8ee4af7ab1bb21a874b|OBS-e8ee4af7ab1bb21a874b]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-0b871bd953bd58d3817e|OBS-0b871bd953bd58d3817e]]

### gross_profit · 2025-06-30 · annual

**193.893 B USD**；状态：source_recorded。证据 ID：OBS-3e1f3e99631e3300f3f0。

^OBS-3e1f3e99631e3300f3f0

期间：2024-07-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`GrossProfit`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### gross_profit · 2025-06-30 · quarter

**52.427 B USD**；状态：needs_review。证据 ID：OBS-e8ee4af7ab1bb21a874b。

^OBS-e8ee4af7ab1bb21a874b

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`GrossProfit`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-3e1f3e99631e3300f3f0|OBS-3e1f3e99631e3300f3f0]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-15e747bc67a1504b80b7|OBS-15e747bc67a1504b80b7]]

### inventory · 2025-06-30 · instant

**0.938 B USD**；状态：source_recorded。证据 ID：OBS-20e599a7fb49e095fb13。

^OBS-20e599a7fb49e095fb13

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`InventoryNet`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2025-06-30 · instant

**275.524 B USD**；状态：source_recorded。证据 ID：OBS-bc4ad930c9cce9318af0。

^OBS-bc4ad930c9cce9318af0

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`Liabilities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-06-30 · annual

**101.832 B USD**；状态：source_recorded。证据 ID：OBS-974b77ba9386bf7b2fa8。

^OBS-974b77ba9386bf7b2fa8

期间：2024-07-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2025-06-30 · quarter

**27.233 B USD**；状态：needs_review。证据 ID：OBS-968146db87e204e236ad。

^OBS-968146db87e204e236ad

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-974b77ba9386bf7b2fa8|OBS-974b77ba9386bf7b2fa8]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-5004efc4b99f52e36b70|OBS-5004efc4b99f52e36b70]]

### operating_cash_flow · 2025-06-30 · annual

**136.162 B USD**；状态：source_recorded。证据 ID：OBS-9dc71aa81c84f32adf25。

^OBS-9dc71aa81c84f32adf25

期间：2024-07-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_cash_flow · 2025-06-30 · quarter

**42.647 B USD**；状态：needs_review。证据 ID：OBS-ae0117b1133bd4d2d449。

^OBS-ae0117b1133bd4d2d449

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-9dc71aa81c84f32adf25|OBS-9dc71aa81c84f32adf25]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-587e0c62ceb504d1b677|OBS-587e0c62ceb504d1b677]]

### operating_income · 2025-06-30 · annual

**128.528 B USD**；状态：source_recorded。证据 ID：OBS-417a5019dfd89c2db402。

^OBS-417a5019dfd89c2db402

期间：2024-07-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`OperatingIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2025-06-30 · quarter

**34.323 B USD**；状态：needs_review。证据 ID：OBS-d623cd861a3e247f03b1。

^OBS-d623cd861a3e247f03b1

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`OperatingIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-417a5019dfd89c2db402|OBS-417a5019dfd89c2db402]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-2c1cb767556aa9508111|OBS-2c1cb767556aa9508111]]

### operating_margin_pct · 2025-06-30 · quarter

**44.90%**；状态：needs_review。证据 ID：OBS-dff3cbb9a13fd70357ec。

^OBS-dff3cbb9a13fd70357ec

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`OperatingIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-d623cd861a3e247f03b1|OBS-d623cd861a3e247f03b1]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-0b871bd953bd58d3817e|OBS-0b871bd953bd58d3817e]]

### receivables · 2025-06-30 · instant

**69.905 B USD**；状态：source_recorded。证据 ID：OBS-c26ed606b74070062238。

^OBS-c26ed606b74070062238

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-06-30 · annual

**281.724 B USD**；状态：source_recorded。证据 ID：OBS-40ba94e890eac9669b50。

^OBS-40ba94e890eac9669b50

期间：2024-07-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### revenue · 2025-06-30 · quarter

**76.441 B USD**；状态：needs_review。证据 ID：OBS-0b871bd953bd58d3817e。

^OBS-0b871bd953bd58d3817e

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-40ba94e890eac9669b50|OBS-40ba94e890eac9669b50]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-589e5890c1a8c18c1bfe|OBS-589e5890c1a8c18c1bfe]]

### assets · 2025-09-30 · instant

**636.351 B USD**；状态：source_recorded。证据 ID：OBS-67c15aa08370be016f43。

^OBS-67c15aa08370be016f43

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`Assets`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2025-09-30 · quarter

**19.394 B USD**；状态：source_recorded。证据 ID：OBS-10fcf0a115e7def342d0。

^OBS-10fcf0a115e7def342d0

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### cash · 2025-09-30 · instant

**28.849 B USD**；状态：source_recorded。证据 ID：OBS-f419233c3d721baa2bf2。

^OBS-f419233c3d721baa2bf2

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2025-09-30 · quarter

**3.720 USD/shares**；状态：source_recorded。证据 ID：OBS-f6a2bb46946692490b7d。

^OBS-f6a2bb46946692490b7d

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`EarningsPerShareDiluted`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-09-30 · quarter

**7,466.00 M shares**；状态：source_recorded。证据 ID：OBS-83b1d6e0aa110283e47d。

^OBS-83b1d6e0aa110283e47d

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-09-30 · instant

**363.076 B USD**；状态：source_recorded。证据 ID：OBS-26aa3bbffc2df55df6f2。

^OBS-26aa3bbffc2df55df6f2

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`StockholdersEquity`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2025-09-30 · quarter

**25.663 B USD**；状态：calculation_checked。证据 ID：OBS-be7e4012fc1bbc6c0c0c。

^OBS-be7e4012fc1bbc6c0c0c

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-b1c287cab5cf6f6b148f|OBS-b1c287cab5cf6f6b148f]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-10fcf0a115e7def342d0|OBS-10fcf0a115e7def342d0]]

### gross_margin_pct · 2025-09-30 · quarter

**69.05%**；状态：calculation_checked。证据 ID：OBS-357740dcac166228770d。

^OBS-357740dcac166228770d

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`GrossProfit`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-58e5e6c3cbcfc97f3013|OBS-58e5e6c3cbcfc97f3013]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-eeb58b8f03941c55fcc0|OBS-eeb58b8f03941c55fcc0]]

### gross_profit · 2025-09-30 · quarter

**53.630 B USD**；状态：source_recorded。证据 ID：OBS-58e5e6c3cbcfc97f3013。

^OBS-58e5e6c3cbcfc97f3013

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`GrossProfit`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### inventory · 2025-09-30 · instant

**1.130 B USD**；状态：source_recorded。证据 ID：OBS-9d7e8f636cac9467ad34。

^OBS-9d7e8f636cac9467ad34

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`InventoryNet`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2025-09-30 · instant

**273.275 B USD**；状态：source_recorded。证据 ID：OBS-bb96376a420d9ee9f807。

^OBS-bb96376a420d9ee9f807

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`Liabilities`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-09-30 · quarter

**27.747 B USD**；状态：source_recorded。证据 ID：OBS-e1c278b640dddc465eb4。

^OBS-e1c278b640dddc465eb4

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`NetIncomeLoss`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2025-09-30 · quarter

**45.057 B USD**；状态：source_recorded。证据 ID：OBS-b1c287cab5cf6f6b148f。

^OBS-b1c287cab5cf6f6b148f

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2025-09-30 · quarter

**37.961 B USD**；状态：source_recorded。证据 ID：OBS-2842a58ec5307e42424e。

^OBS-2842a58ec5307e42424e

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`OperatingIncomeLoss`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2025-09-30 · quarter

**48.87%**；状态：calculation_checked。证据 ID：OBS-65d57790dac1306d7d72。

^OBS-65d57790dac1306d7d72

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`OperatingIncomeLoss`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-2842a58ec5307e42424e|OBS-2842a58ec5307e42424e]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-eeb58b8f03941c55fcc0|OBS-eeb58b8f03941c55fcc0]]

### receivables · 2025-09-30 · instant

**52.894 B USD**；状态：source_recorded。证据 ID：OBS-952fdebc7f2bbc4c73aa。

^OBS-952fdebc7f2bbc4c73aa

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-09-30 · quarter

**77.673 B USD**；状态：source_recorded。证据 ID：OBS-eeb58b8f03941c55fcc0。

^OBS-eeb58b8f03941c55fcc0

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### assets · 2025-12-31 · instant

**665.302 B USD**；状态：source_recorded。证据 ID：OBS-731fd1c2400d12a00c54。

^OBS-731fd1c2400d12a00c54

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`Assets`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2025-12-31 · quarter

**29.876 B USD**；状态：source_recorded。证据 ID：OBS-fb79df4063bfa7b876a3。

^OBS-fb79df4063bfa7b876a3

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### cash · 2025-12-31 · instant

**24.296 B USD**；状态：source_recorded。证据 ID：OBS-f26099fdaa7ef9e4ed7c。

^OBS-f26099fdaa7ef9e4ed7c

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2025-12-31 · quarter

**5.160 USD/shares**；状态：source_recorded。证据 ID：OBS-9eb21fb66765665f8637。

^OBS-9eb21fb66765665f8637

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`EarningsPerShareDiluted`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-12-31 · quarter

**7,460.00 M shares**；状态：source_recorded。证据 ID：OBS-1eba8e22ede018ca339e。

^OBS-1eba8e22ede018ca339e

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-12-31 · instant

**390.875 B USD**；状态：source_recorded。证据 ID：OBS-41d656442388abf7dbf9。

^OBS-41d656442388abf7dbf9

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`StockholdersEquity`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2025-12-31 · quarter

**5.882 B USD**；状态：calculation_checked。证据 ID：OBS-b98706202e025d425a3e。

^OBS-b98706202e025d425a3e

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-c33afcb4372ad7cc3b64|OBS-c33afcb4372ad7cc3b64]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-fb79df4063bfa7b876a3|OBS-fb79df4063bfa7b876a3]]

### gross_margin_pct · 2025-12-31 · quarter

**68.04%**；状态：calculation_checked。证据 ID：OBS-22c14029e89260145aa4。

^OBS-22c14029e89260145aa4

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`GrossProfit`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-75fb273ae7bbeb195e43|OBS-75fb273ae7bbeb195e43]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-8aae2a3deb4856b93210|OBS-8aae2a3deb4856b93210]]

### gross_profit · 2025-12-31 · quarter

**55.295 B USD**；状态：source_recorded。证据 ID：OBS-75fb273ae7bbeb195e43。

^OBS-75fb273ae7bbeb195e43

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`GrossProfit`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### inventory · 2025-12-31 · instant

**1.059 B USD**；状态：source_recorded。证据 ID：OBS-710257a94918047d0cad。

^OBS-710257a94918047d0cad

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`InventoryNet`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2025-12-31 · instant

**274.427 B USD**；状态：source_recorded。证据 ID：OBS-4b347762edf44a4d74ad。

^OBS-4b347762edf44a4d74ad

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`Liabilities`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-12-31 · quarter

**38.458 B USD**；状态：source_recorded。证据 ID：OBS-f36f97fda038dc93a6fb。

^OBS-f36f97fda038dc93a6fb

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`NetIncomeLoss`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2025-12-31 · quarter

**35.758 B USD**；状态：source_recorded。证据 ID：OBS-c33afcb4372ad7cc3b64。

^OBS-c33afcb4372ad7cc3b64

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2025-12-31 · quarter

**38.275 B USD**；状态：source_recorded。证据 ID：OBS-da21bd00447f72db36cc。

^OBS-da21bd00447f72db36cc

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`OperatingIncomeLoss`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2025-12-31 · quarter

**47.09%**；状态：calculation_checked。证据 ID：OBS-1e9d7ca12662c107b74c。

^OBS-1e9d7ca12662c107b74c

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`OperatingIncomeLoss`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-da21bd00447f72db36cc|OBS-da21bd00447f72db36cc]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-8aae2a3deb4856b93210|OBS-8aae2a3deb4856b93210]]

### receivables · 2025-12-31 · instant

**56.535 B USD**；状态：source_recorded。证据 ID：OBS-17e63d926082118e4ec5。

^OBS-17e63d926082118e4ec5

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-12-31 · quarter

**81.273 B USD**；状态：source_recorded。证据 ID：OBS-8aae2a3deb4856b93210。

^OBS-8aae2a3deb4856b93210

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### assets · 2026-03-31 · instant

**694.228 B USD**；状态：source_recorded。证据 ID：OBS-ad6bbfe2d301f1bdff29。

^OBS-ad6bbfe2d301f1bdff29

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`Assets`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2026-03-31 · quarter

**30.876 B USD**；状态：source_recorded。证据 ID：OBS-f577fdc4f4cf49a98cbd。

^OBS-f577fdc4f4cf49a98cbd

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### capex_cash · 2026-03-31 · ytd

**80.146 B USD**；状态：source_recorded。证据 ID：OBS-9dfcb20268c924fbe0b8。

^OBS-9dfcb20268c924fbe0b8

期间：2025-07-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### cash · 2026-03-31 · instant

**32.105 B USD**；状态：source_recorded。证据 ID：OBS-ca433f7854bfeb0503f2。

^OBS-ca433f7854bfeb0503f2

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2026-03-31 · quarter

**4.270 USD/shares**；状态：source_recorded。证据 ID：OBS-bd14ba8812eddc912f3c。

^OBS-bd14ba8812eddc912f3c

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`EarningsPerShareDiluted`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2026-03-31 · quarter

**7,445.00 M shares**；状态：source_recorded。证据 ID：OBS-6788f07e7c6968e59623。

^OBS-6788f07e7c6968e59623

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2026-03-31 · instant

**414.367 B USD**；状态：source_recorded。证据 ID：OBS-5ef8b3a6acc5511558e5。

^OBS-5ef8b3a6acc5511558e5

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`StockholdersEquity`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2026-03-31 · quarter

**15.803 B USD**；状态：calculation_checked。证据 ID：OBS-6fa1914dbfd694d279e6。

^OBS-6fa1914dbfd694d279e6

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-48183e545d885e1dfb55|OBS-48183e545d885e1dfb55]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-f577fdc4f4cf49a98cbd|OBS-f577fdc4f4cf49a98cbd]]

### gross_margin_pct · 2026-03-31 · quarter

**67.63%**；状态：calculation_checked。证据 ID：OBS-6697cf0734605e534925。

^OBS-6697cf0734605e534925

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`GrossProfit`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-a6bf2dcff8c1b5b6114d|OBS-a6bf2dcff8c1b5b6114d]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-c439239562fd908ce7c3|OBS-c439239562fd908ce7c3]]

### gross_profit · 2026-03-31 · quarter

**56.058 B USD**；状态：source_recorded。证据 ID：OBS-a6bf2dcff8c1b5b6114d。

^OBS-a6bf2dcff8c1b5b6114d

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`GrossProfit`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### gross_profit · 2026-03-31 · ytd

**164.983 B USD**；状态：source_recorded。证据 ID：OBS-d41e3e0c2af9ce502563。

^OBS-d41e3e0c2af9ce502563

期间：2025-07-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`GrossProfit`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### inventory · 2026-03-31 · instant

**1.219 B USD**；状态：source_recorded。证据 ID：OBS-b67f428677c9cfa349af。

^OBS-b67f428677c9cfa349af

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`InventoryNet`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2026-03-31 · instant

**279.861 B USD**；状态：source_recorded。证据 ID：OBS-8f32df64e6b6dbcff306。

^OBS-8f32df64e6b6dbcff306

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`Liabilities`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2026-03-31 · quarter

**31.778 B USD**；状态：source_recorded。证据 ID：OBS-247bf785c36d43a79404。

^OBS-247bf785c36d43a79404

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2026-03-31 · ytd

**97.983 B USD**；状态：source_recorded。证据 ID：OBS-0dd562a24eed4efa8ccc。

^OBS-0dd562a24eed4efa8ccc

期间：2025-07-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2026-03-31 · quarter

**46.679 B USD**；状态：source_recorded。证据 ID：OBS-48183e545d885e1dfb55。

^OBS-48183e545d885e1dfb55

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_cash_flow · 2026-03-31 · ytd

**127.494 B USD**；状态：source_recorded。证据 ID：OBS-2760ea15f34dc9343c2c。

^OBS-2760ea15f34dc9343c2c

期间：2025-07-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2026-03-31 · quarter

**38.398 B USD**；状态：source_recorded。证据 ID：OBS-5da89e950371d733a694。

^OBS-5da89e950371d733a694

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`OperatingIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2026-03-31 · ytd

**114.634 B USD**；状态：source_recorded。证据 ID：OBS-c163cac47e9b78ba136e。

^OBS-c163cac47e9b78ba136e

期间：2025-07-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`OperatingIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2026-03-31 · quarter

**46.33%**；状态：calculation_checked。证据 ID：OBS-2df91fb1fa59fedd5f98。

^OBS-2df91fb1fa59fedd5f98

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`OperatingIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-5da89e950371d733a694|OBS-5da89e950371d733a694]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-c439239562fd908ce7c3|OBS-c439239562fd908ce7c3]]

### receivables · 2026-03-31 · instant

**60.041 B USD**；状态：source_recorded。证据 ID：OBS-6360ae637019c295f489。

^OBS-6360ae637019c295f489

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2026-03-31 · quarter

**82.886 B USD**；状态：source_recorded。证据 ID：OBS-c439239562fd908ce7c3。

^OBS-c439239562fd908ce7c3

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### revenue · 2026-03-31 · ytd

**241.832 B USD**；状态：source_recorded。证据 ID：OBS-314e79e78818b60280d9。

^OBS-314e79e78818b60280d9

期间：2025-07-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### assets · 2026-06-30 · instant

**758.376 B USD**；状态：source_recorded。证据 ID：OBS-5476da7e320f84acccd4。

^OBS-5476da7e320f84acccd4

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`Assets`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2026-06-30 · annual

**115.948 B USD**；状态：source_recorded。证据 ID：OBS-bac21b1b68b158c2c26d。

^OBS-bac21b1b68b158c2c26d

期间：2025-07-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.

### capex_cash · 2026-06-30 · quarter

**35.802 B USD**；状态：needs_review。证据 ID：OBS-afda1b8030465e20d35b。

^OBS-afda1b8030465e20d35b

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：The cash outflow associated with the acquisition of long-lived, physical assets that are used in the normal conduct of business to produce goods and services and not intended for resale; includes cash outflows to pay for construction of self-constructed assets.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-bac21b1b68b158c2c26d|OBS-bac21b1b68b158c2c26d]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-9dfcb20268c924fbe0b8|OBS-9dfcb20268c924fbe0b8]]

### cash · 2026-06-30 · instant

**20.935 B USD**；状态：source_recorded。证据 ID：OBS-e1dc87958eebefdbe3d2。

^OBS-e1dc87958eebefdbe3d2

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### equity · 2026-06-30 · instant

**442.387 B USD**；状态：source_recorded。证据 ID：OBS-14d5493cf3ba89ef9cbf。

^OBS-14d5493cf3ba89ef9cbf

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`StockholdersEquity`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2026-06-30 · quarter

**19.639 B USD**；状态：needs_review。证据 ID：OBS-489c19285dd31b7a4df1。

^OBS-489c19285dd31b7a4df1

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-9c38cb4006d2d7bff028|OBS-9c38cb4006d2d7bff028]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-afda1b8030465e20d35b|OBS-afda1b8030465e20d35b]]

### gross_margin_pct · 2026-06-30 · quarter

**67.20%**；状态：needs_review。证据 ID：OBS-c571568e0d65b592fac6。

^OBS-c571568e0d65b592fac6

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`GrossProfit`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-dceda31853218f62fc73|OBS-dceda31853218f62fc73]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-09a797e58b97899766e7|OBS-09a797e58b97899766e7]]

### gross_profit · 2026-06-30 · annual

**225.465 B USD**；状态：source_recorded。证据 ID：OBS-0cbfa236e0bc93a8e490。

^OBS-0cbfa236e0bc93a8e490

期间：2025-07-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`GrossProfit`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### gross_profit · 2026-06-30 · quarter

**60.482 B USD**；状态：needs_review。证据 ID：OBS-dceda31853218f62fc73。

^OBS-dceda31853218f62fc73

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`GrossProfit`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-0cbfa236e0bc93a8e490|OBS-0cbfa236e0bc93a8e490]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-d41e3e0c2af9ce502563|OBS-d41e3e0c2af9ce502563]]

### inventory · 2026-06-30 · instant

**1.397 B USD**；状态：source_recorded。证据 ID：OBS-0b8b4ba84f2d8c94f11d。

^OBS-0b8b4ba84f2d8c94f11d

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`InventoryNet`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2026-06-30 · instant

**315.989 B USD**；状态：source_recorded。证据 ID：OBS-e2346107f8325aade70c。

^OBS-e2346107f8325aade70c

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`Liabilities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2026-06-30 · annual

**133.749 B USD**；状态：source_recorded。证据 ID：OBS-6fac94fc15e7f98fbd35。

^OBS-6fac94fc15e7f98fbd35

期间：2025-07-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2026-06-30 · quarter

**35.766 B USD**；状态：needs_review。证据 ID：OBS-d02f55f0ac12cfcf97b0。

^OBS-d02f55f0ac12cfcf97b0

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-6fac94fc15e7f98fbd35|OBS-6fac94fc15e7f98fbd35]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-0dd562a24eed4efa8ccc|OBS-0dd562a24eed4efa8ccc]]

### operating_cash_flow · 2026-06-30 · annual

**182.935 B USD**；状态：source_recorded。证据 ID：OBS-921d78c0b3eed263b9e5。

^OBS-921d78c0b3eed263b9e5

期间：2025-07-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_cash_flow · 2026-06-30 · quarter

**55.441 B USD**；状态：needs_review。证据 ID：OBS-9c38cb4006d2d7bff028。

^OBS-9c38cb4006d2d7bff028

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-921d78c0b3eed263b9e5|OBS-921d78c0b3eed263b9e5]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-2760ea15f34dc9343c2c|OBS-2760ea15f34dc9343c2c]]

### operating_income · 2026-06-30 · annual

**155.237 B USD**；状态：source_recorded。证据 ID：OBS-1e3bd5e1abcadc91d12d。

^OBS-1e3bd5e1abcadc91d12d

期间：2025-07-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`OperatingIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2026-06-30 · quarter

**40.603 B USD**；状态：needs_review。证据 ID：OBS-7a8e071b63eefa97d333。

^OBS-7a8e071b63eefa97d333

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`OperatingIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-1e3bd5e1abcadc91d12d|OBS-1e3bd5e1abcadc91d12d]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-c163cac47e9b78ba136e|OBS-c163cac47e9b78ba136e]]

### operating_margin_pct · 2026-06-30 · quarter

**45.11%**；状态：needs_review。证据 ID：OBS-4a87a14330dcbb9023bc。

^OBS-4a87a14330dcbb9023bc

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`OperatingIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-7a8e071b63eefa97d333|OBS-7a8e071b63eefa97d333]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-09a797e58b97899766e7|OBS-09a797e58b97899766e7]]

### receivables · 2026-06-30 · instant

**80.876 B USD**；状态：source_recorded。证据 ID：OBS-35105e3698150d6db814。

^OBS-35105e3698150d6db814

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2026-06-30 · annual

**331.839 B USD**；状态：source_recorded。证据 ID：OBS-65951dfa62d4e2330d3a。

^OBS-65951dfa62d4e2330d3a

期间：2025-07-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.

### revenue · 2026-06-30 · quarter

**90.007 B USD**；状态：needs_review。证据 ID：OBS-09a797e58b97899766e7。

^OBS-09a797e58b97899766e7

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
定义：Amount, excluding tax collected from customer, of revenue from satisfaction of performance obligation by transferring promised good or service to customer. Tax collected from customer is tax assessed by governmental authority that is both imposed on and concurrent with specific revenue-producing transaction, including, but not limited to, sales, use, value added and excise.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-65951dfa62d4e2330d3a|OBS-65951dfa62d4e2330d3a]]、[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence#^OBS-314e79e78818b60280d9|OBS-314e79e78818b60280d9]]
