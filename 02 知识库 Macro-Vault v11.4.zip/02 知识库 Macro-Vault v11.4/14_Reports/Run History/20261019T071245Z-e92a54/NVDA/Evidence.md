---
title: "NVDA — 本次数据与原文证据（运行 20261019T071245Z-e92a54）"
tags: [reports, run-history, evidence]
created: 2026-10-19
updated: 2026-10-19
source: "引擎运行 20261019T071245Z-e92a54 的数据快照 12_Data/Companies/NVDA/20261019T071245Z-e92a54.json"
---
# NVDA — 本次数据与原文证据

资料截止：2026-10-19T07:12:45+00:00。

[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Brief|本次简报]] · [[04_Companies/NVDA/Company Profile|NVDA 档案]] · [[04_Companies/NVDA/Latest Brief|最新简报]] · [[04_Companies/NVDA/NVDA - Data History|八季数据]] · [[04_Companies/NVDA/Evidence Index|证据索引]] · [[04_Companies/NVDA/Current Thesis|当前判断]] · [[04_Companies/NVDA/Thesis History|判断历史]]

本页是保存快照的阅读视图；链接表示引用或计算依赖，不表示独立验证或因果关系。
包含最近八季的观察值，以及计算所需的较早输入。后续运行各自生成证据页，旧简报不会跳到新快照。

## 原始快照
[[12_Data/Companies/NVDA/20261019T071245Z-e92a54.json|JSON 快照（外部编辑器）]]

## 财报原文
- [[13_Sources/Records/SRC-37b983f4389f983f2f7b570c|10-Q]]；期间／事件日：2026-07-26
  提取正文：[[13_Sources/Raw/SRC-37b983f4389f983f2f7b570c|SRC-37b983f4389f983f2f7b570c 正文]]
- [[13_Sources/Records/SRC-1db8a6c89a58e018e4171fc7|10-K]]；期间／事件日：2026-01-25
  提取正文：[[13_Sources/Raw/SRC-1db8a6c89a58e018e4171fc7|SRC-1db8a6c89a58e018e4171fc7 正文]]
- [[13_Sources/Records/SRC-1cf41a59f7a0f9bd19d142ef|earnings_release_8K]]；期间／事件日：2026-08-26
  提取正文：[[13_Sources/Raw/SRC-1cf41a59f7a0f9bd19d142ef.earnings|SRC-1cf41a59f7a0f9bd19d142ef 正文]]

## 数字与计算依赖

### capex_cash · 2024-07-28 · ytd

**1.346 B USD**；状态：source_recorded。证据 ID：OBS-1241e5711bd7f862199d。

^OBS-1241e5711bd7f862199d

期间：2024-01-29 → 2024-07-28；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000209。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2025-08-27。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000209/0001045810-25-000209-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.

### operating_cash_flow · 2024-07-28 · ytd

**29.833 B USD**；状态：source_recorded。证据 ID：OBS-92f37841aca43c65cbba。

^OBS-92f37841aca43c65cbba

期间：2024-01-29 → 2024-07-28；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000209。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-08-27。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000209/0001045810-25-000209-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### assets · 2024-10-27 · instant

**96.013 B USD**；状态：source_recorded。证据 ID：OBS-1ca4c4ecfc15ffdea2aa。

^OBS-1ca4c4ecfc15ffdea2aa

期间：时点 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-24-000316。
字段：`Assets`；申报日期：2024-11-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581024000316/0001045810-24-000316-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2024-10-27 · quarter

**0.813 B USD**；状态：needs_review。证据 ID：OBS-76384e3604a949e1cc57。

^OBS-76384e3604a949e1cc57

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-4777bf48f0ffc67b49a3|OBS-4777bf48f0ffc67b49a3]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-1241e5711bd7f862199d|OBS-1241e5711bd7f862199d]]

### capex_cash · 2024-10-27 · ytd

**2.159 B USD**；状态：source_recorded。证据 ID：OBS-4777bf48f0ffc67b49a3。

^OBS-4777bf48f0ffc67b49a3

期间：2024-01-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.

### cash · 2024-10-27 · instant

**9.107 B USD**；状态：source_recorded。证据 ID：OBS-4d3298de4ff82dced4d2。

^OBS-4d3298de4ff82dced4d2

期间：时点 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-24-000316。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2024-11-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581024000316/0001045810-24-000316-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2024-10-27 · quarter

**0.780 USD/shares**；状态：source_recorded。证据 ID：OBS-ddcb88af4eb1e8bfac54。

^OBS-ddcb88af4eb1e8bfac54

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`EarningsPerShareDiluted`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2024-10-27 · quarter

**24,774.00 M shares**；状态：source_recorded。证据 ID：OBS-dce26cfa7ab6eb655380。

^OBS-dce26cfa7ab6eb655380

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2024-10-27 · instant

**65.899 B USD**；状态：source_recorded。证据 ID：OBS-0b23fb713170b69f6245。

^OBS-0b23fb713170b69f6245

期间：时点 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`StockholdersEquity`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2024-10-27 · quarter

**16.814 B USD**；状态：needs_review。证据 ID：OBS-aa4765157159bd3ffe52。

^OBS-aa4765157159bd3ffe52

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-dec4847cabe0e9819857|OBS-dec4847cabe0e9819857]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-76384e3604a949e1cc57|OBS-76384e3604a949e1cc57]]

### gross_margin_pct · 2024-10-27 · quarter

**74.56%**；状态：calculation_checked。证据 ID：OBS-9b5ccdac2678a02c3fc8。

^OBS-9b5ccdac2678a02c3fc8

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`GrossProfit`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-5d58dc3d188135a4e3b1|OBS-5d58dc3d188135a4e3b1]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-c0c723e9bbcd58b3d754|OBS-c0c723e9bbcd58b3d754]]

### gross_profit · 2024-10-27 · quarter

**26.156 B USD**；状态：source_recorded。证据 ID：OBS-5d58dc3d188135a4e3b1。

^OBS-5d58dc3d188135a4e3b1

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`GrossProfit`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### gross_profit · 2024-10-27 · ytd

**69.135 B USD**；状态：source_recorded。证据 ID：OBS-5e7a17409fc8e3add2ea。

^OBS-5e7a17409fc8e3add2ea

期间：2024-01-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`GrossProfit`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### inventory · 2024-10-27 · instant

**7.654 B USD**；状态：source_recorded。证据 ID：OBS-116c573fc3c70d885f10。

^OBS-116c573fc3c70d885f10

期间：时点 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-24-000316。
字段：`InventoryNet`；申报日期：2024-11-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581024000316/0001045810-24-000316-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2024-10-27 · instant

**30.114 B USD**；状态：source_recorded。证据 ID：OBS-ce05303761228a46ada9。

^OBS-ce05303761228a46ada9

期间：时点 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-24-000316。
字段：`Liabilities`；申报日期：2024-11-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581024000316/0001045810-24-000316-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2024-10-27 · quarter

**19.309 B USD**；状态：source_recorded。证据 ID：OBS-83625e3b3ba768c9d563。

^OBS-83625e3b3ba768c9d563

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2024-10-27 · ytd

**50.789 B USD**；状态：source_recorded。证据 ID：OBS-f4a768ea957c4a1ea112。

^OBS-f4a768ea957c4a1ea112

期间：2024-01-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2024-10-27 · quarter

**17.627 B USD**；状态：needs_review。证据 ID：OBS-dec4847cabe0e9819857。

^OBS-dec4847cabe0e9819857

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-3634ed2a9a80e3612b84|OBS-3634ed2a9a80e3612b84]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-92f37841aca43c65cbba|OBS-92f37841aca43c65cbba]]

### operating_cash_flow · 2024-10-27 · ytd

**47.460 B USD**；状态：source_recorded。证据 ID：OBS-3634ed2a9a80e3612b84。

^OBS-3634ed2a9a80e3612b84

期间：2024-01-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2024-10-27 · quarter

**21.869 B USD**；状态：source_recorded。证据 ID：OBS-ac9a458d066f4a474491。

^OBS-ac9a458d066f4a474491

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`OperatingIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2024-10-27 · ytd

**57.419 B USD**；状态：source_recorded。证据 ID：OBS-0447c043dd46a6c741a6。

^OBS-0447c043dd46a6c741a6

期间：2024-01-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`OperatingIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2024-10-27 · quarter

**62.34%**；状态：calculation_checked。证据 ID：OBS-c77ec412f906f2e3b58c。

^OBS-c77ec412f906f2e3b58c

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`OperatingIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-ac9a458d066f4a474491|OBS-ac9a458d066f4a474491]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-c0c723e9bbcd58b3d754|OBS-c0c723e9bbcd58b3d754]]

### receivables · 2024-10-27 · instant

**17.693 B USD**；状态：source_recorded。证据 ID：OBS-40c91134ca2e0c9e5a04。

^OBS-40c91134ca2e0c9e5a04

期间：时点 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-24-000316。
字段：`AccountsReceivableNetCurrent`；申报日期：2024-11-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581024000316/0001045810-24-000316-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2024-10-27 · quarter

**35.082 B USD**；状态：source_recorded。证据 ID：OBS-c0c723e9bbcd58b3d754。

^OBS-c0c723e9bbcd58b3d754

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`Revenues`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### revenue · 2024-10-27 · ytd

**91.166 B USD**；状态：source_recorded。证据 ID：OBS-d81aef7d88f478e454d7。

^OBS-d81aef7d88f478e454d7

期间：2024-01-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`Revenues`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### assets · 2025-01-26 · instant

**111.601 B USD**；状态：source_recorded。证据 ID：OBS-9c03f80b7e56bb41f540。

^OBS-9c03f80b7e56bb41f540

期间：时点 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`Assets`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2025-01-26 · annual

**3.236 B USD**；状态：source_recorded。证据 ID：OBS-58c41be4bd3136c90881。

^OBS-58c41be4bd3136c90881

期间：2024-01-29 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.

### capex_cash · 2025-01-26 · quarter

**1.077 B USD**；状态：needs_review。证据 ID：OBS-4867906cb8028d6916d4。

^OBS-4867906cb8028d6916d4

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-58c41be4bd3136c90881|OBS-58c41be4bd3136c90881]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-4777bf48f0ffc67b49a3|OBS-4777bf48f0ffc67b49a3]]

### cash · 2025-01-26 · instant

**8.589 B USD**；状态：source_recorded。证据 ID：OBS-0371975f62a8c66c47bc。

^OBS-0371975f62a8c66c47bc

期间：时点 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### equity · 2025-01-26 · instant

**79.327 B USD**；状态：source_recorded。证据 ID：OBS-cfa59b1deeb9bddc2e8a。

^OBS-cfa59b1deeb9bddc2e8a

期间：时点 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`StockholdersEquity`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2025-01-26 · quarter

**15.552 B USD**；状态：needs_review。证据 ID：OBS-b6c97ffd346fceb2439d。

^OBS-b6c97ffd346fceb2439d

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-0afcf8f4063ee9877f9d|OBS-0afcf8f4063ee9877f9d]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-4867906cb8028d6916d4|OBS-4867906cb8028d6916d4]]

### gross_margin_pct · 2025-01-26 · quarter

**73.03%**；状态：needs_review。证据 ID：OBS-67e18520f499293c3413。

^OBS-67e18520f499293c3413

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`GrossProfit`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-0ffd77a4e1caa760c6a2|OBS-0ffd77a4e1caa760c6a2]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-50f94b20ebd3cfe47ec7|OBS-50f94b20ebd3cfe47ec7]]

### gross_profit · 2025-01-26 · annual

**97.858 B USD**；状态：source_recorded。证据 ID：OBS-60205426a5ea4f041a38。

^OBS-60205426a5ea4f041a38

期间：2024-01-29 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`GrossProfit`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### gross_profit · 2025-01-26 · quarter

**28.723 B USD**；状态：needs_review。证据 ID：OBS-0ffd77a4e1caa760c6a2。

^OBS-0ffd77a4e1caa760c6a2

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`GrossProfit`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-60205426a5ea4f041a38|OBS-60205426a5ea4f041a38]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-5e7a17409fc8e3add2ea|OBS-5e7a17409fc8e3add2ea]]

### inventory · 2025-01-26 · instant

**10.080 B USD**；状态：source_recorded。证据 ID：OBS-d6f5a6014f5325a81d74。

^OBS-d6f5a6014f5325a81d74

期间：时点 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`InventoryNet`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2025-01-26 · instant

**32.274 B USD**；状态：source_recorded。证据 ID：OBS-44d24cfb9411dc690693。

^OBS-44d24cfb9411dc690693

期间：时点 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`Liabilities`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-01-26 · annual

**72.880 B USD**；状态：source_recorded。证据 ID：OBS-2289a517f6b82d7464bc。

^OBS-2289a517f6b82d7464bc

期间：2024-01-29 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2025-01-26 · quarter

**22.091 B USD**；状态：needs_review。证据 ID：OBS-15e9c5748cd0d44072b0。

^OBS-15e9c5748cd0d44072b0

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-2289a517f6b82d7464bc|OBS-2289a517f6b82d7464bc]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-f4a768ea957c4a1ea112|OBS-f4a768ea957c4a1ea112]]

### operating_cash_flow · 2025-01-26 · annual

**64.089 B USD**；状态：source_recorded。证据 ID：OBS-e7583450a3b28791319f。

^OBS-e7583450a3b28791319f

期间：2024-01-29 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_cash_flow · 2025-01-26 · quarter

**16.629 B USD**；状态：needs_review。证据 ID：OBS-0afcf8f4063ee9877f9d。

^OBS-0afcf8f4063ee9877f9d

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-e7583450a3b28791319f|OBS-e7583450a3b28791319f]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-3634ed2a9a80e3612b84|OBS-3634ed2a9a80e3612b84]]

### operating_income · 2025-01-26 · annual

**81.453 B USD**；状态：source_recorded。证据 ID：OBS-82ae450768dbb939ed51。

^OBS-82ae450768dbb939ed51

期间：2024-01-29 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`OperatingIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2025-01-26 · quarter

**24.034 B USD**；状态：needs_review。证据 ID：OBS-cfaa37b56b4c94e6272a。

^OBS-cfaa37b56b4c94e6272a

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`OperatingIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-82ae450768dbb939ed51|OBS-82ae450768dbb939ed51]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-0447c043dd46a6c741a6|OBS-0447c043dd46a6c741a6]]

### operating_margin_pct · 2025-01-26 · quarter

**61.11%**；状态：needs_review。证据 ID：OBS-5c3248cd046b080b7895。

^OBS-5c3248cd046b080b7895

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`OperatingIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-cfaa37b56b4c94e6272a|OBS-cfaa37b56b4c94e6272a]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-50f94b20ebd3cfe47ec7|OBS-50f94b20ebd3cfe47ec7]]

### receivables · 2025-01-26 · instant

**23.065 B USD**；状态：source_recorded。证据 ID：OBS-0dbcbfcfa873ae85e56b。

^OBS-0dbcbfcfa873ae85e56b

期间：时点 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-01-26 · annual

**130.497 B USD**；状态：source_recorded。证据 ID：OBS-860b26d5f8dae5e1884b。

^OBS-860b26d5f8dae5e1884b

期间：2024-01-29 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`Revenues`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### revenue · 2025-01-26 · quarter

**39.331 B USD**；状态：needs_review。证据 ID：OBS-50f94b20ebd3cfe47ec7。

^OBS-50f94b20ebd3cfe47ec7

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`Revenues`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-860b26d5f8dae5e1884b|OBS-860b26d5f8dae5e1884b]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-d81aef7d88f478e454d7|OBS-d81aef7d88f478e454d7]]

### assets · 2025-04-27 · instant

**125.254 B USD**；状态：source_recorded。证据 ID：OBS-ea4f5c7324dbae0697c2。

^OBS-ea4f5c7324dbae0697c2

期间：时点 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000116。
字段：`Assets`；申报日期：2025-05-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000116/0001045810-25-000116-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2025-04-27 · quarter

**1.227 B USD**；状态：source_recorded。证据 ID：OBS-8cddb1772dad8c42108c。

^OBS-8cddb1772dad8c42108c

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.

### cash · 2025-04-27 · instant

**15.234 B USD**；状态：source_recorded。证据 ID：OBS-9cba32269bf301993945。

^OBS-9cba32269bf301993945

期间：时点 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000116。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-05-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000116/0001045810-25-000116-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2025-04-27 · quarter

**0.760 USD/shares**；状态：source_recorded。证据 ID：OBS-f744e1003ba2064712a1。

^OBS-f744e1003ba2064712a1

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`EarningsPerShareDiluted`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-04-27 · quarter

**24,611.00 M shares**；状态：source_recorded。证据 ID：OBS-8771a9c685a8955f7d1e。

^OBS-8771a9c685a8955f7d1e

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-04-27 · instant

**83.843 B USD**；状态：source_recorded。证据 ID：OBS-c50bb414395805f69687。

^OBS-c50bb414395805f69687

期间：时点 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`StockholdersEquity`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2025-04-27 · quarter

**26.187 B USD**；状态：calculation_checked。证据 ID：OBS-145fd3bb2a1466a749f1。

^OBS-145fd3bb2a1466a749f1

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-6caf4cfef1f5ad6b574a|OBS-6caf4cfef1f5ad6b574a]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-8cddb1772dad8c42108c|OBS-8cddb1772dad8c42108c]]

### gross_margin_pct · 2025-04-27 · quarter

**60.52%**；状态：calculation_checked。证据 ID：OBS-714e9420961361a8e22c。

^OBS-714e9420961361a8e22c

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`GrossProfit`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-ef82a5143fd01e69cd05|OBS-ef82a5143fd01e69cd05]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-fafd58de4b5b0e39b292|OBS-fafd58de4b5b0e39b292]]

### gross_profit · 2025-04-27 · quarter

**26.668 B USD**；状态：source_recorded。证据 ID：OBS-ef82a5143fd01e69cd05。

^OBS-ef82a5143fd01e69cd05

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`GrossProfit`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### inventory · 2025-04-27 · instant

**11.333 B USD**；状态：source_recorded。证据 ID：OBS-87f0674bea746197861c。

^OBS-87f0674bea746197861c

期间：时点 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000116。
字段：`InventoryNet`；申报日期：2025-05-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000116/0001045810-25-000116-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2025-04-27 · instant

**41.411 B USD**；状态：source_recorded。证据 ID：OBS-43224f384d1172309649。

^OBS-43224f384d1172309649

期间：时点 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000116。
字段：`Liabilities`；申报日期：2025-05-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000116/0001045810-25-000116-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-04-27 · quarter

**18.775 B USD**；状态：source_recorded。证据 ID：OBS-22fdeed5cec57499bafb。

^OBS-22fdeed5cec57499bafb

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`NetIncomeLoss`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2025-04-27 · quarter

**27.414 B USD**；状态：source_recorded。证据 ID：OBS-6caf4cfef1f5ad6b574a。

^OBS-6caf4cfef1f5ad6b574a

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2025-04-27 · quarter

**21.638 B USD**；状态：source_recorded。证据 ID：OBS-3db5f48548b67137ea03。

^OBS-3db5f48548b67137ea03

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`OperatingIncomeLoss`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2025-04-27 · quarter

**49.11%**；状态：calculation_checked。证据 ID：OBS-3578744773065ad75708。

^OBS-3578744773065ad75708

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`OperatingIncomeLoss`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-3db5f48548b67137ea03|OBS-3db5f48548b67137ea03]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-fafd58de4b5b0e39b292|OBS-fafd58de4b5b0e39b292]]

### receivables · 2025-04-27 · instant

**22.132 B USD**；状态：source_recorded。证据 ID：OBS-e1ed461a28a6625cff69。

^OBS-e1ed461a28a6625cff69

期间：时点 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000116。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-05-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000116/0001045810-25-000116-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-04-27 · quarter

**44.062 B USD**；状态：source_recorded。证据 ID：OBS-fafd58de4b5b0e39b292。

^OBS-fafd58de4b5b0e39b292

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`Revenues`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### assets · 2025-07-27 · instant

**140.740 B USD**；状态：source_recorded。证据 ID：OBS-71bf4f1c027eeeb16458。

^OBS-71bf4f1c027eeeb16458

期间：时点 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000209。
字段：`Assets`；申报日期：2025-08-27。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000209/0001045810-25-000209-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2025-07-27 · quarter

**1.895 B USD**；状态：needs_review。证据 ID：OBS-672ad5c9cfde29af318d。

^OBS-672ad5c9cfde29af318d

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-bd7ccf8618c3f36bb584|OBS-bd7ccf8618c3f36bb584]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-8cddb1772dad8c42108c|OBS-8cddb1772dad8c42108c]]

### capex_cash · 2025-07-27 · ytd

**3.122 B USD**；状态：source_recorded。证据 ID：OBS-bd7ccf8618c3f36bb584。

^OBS-bd7ccf8618c3f36bb584

期间：2025-01-27 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.

### cash · 2025-07-27 · instant

**11.639 B USD**；状态：source_recorded。证据 ID：OBS-5621aa477a23cc41b682。

^OBS-5621aa477a23cc41b682

期间：时点 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000209。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-08-27。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000209/0001045810-25-000209-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2025-07-27 · quarter

**1.080 USD/shares**；状态：source_recorded。证据 ID：OBS-914ed9b4eb6aa24fa342。

^OBS-914ed9b4eb6aa24fa342

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`EarningsPerShareDiluted`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-07-27 · quarter

**24,532.00 M shares**；状态：source_recorded。证据 ID：OBS-c8af4db0bfbab0d6f6ae。

^OBS-c8af4db0bfbab0d6f6ae

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-07-27 · instant

**100.131 B USD**；状态：source_recorded。证据 ID：OBS-7932e0bf44bfa4df0216。

^OBS-7932e0bf44bfa4df0216

期间：时点 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`StockholdersEquity`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2025-07-27 · quarter

**13.470 B USD**；状态：needs_review。证据 ID：OBS-39c11e1f512be2bbbd4a。

^OBS-39c11e1f512be2bbbd4a

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-607624a9d6c413921a16|OBS-607624a9d6c413921a16]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-672ad5c9cfde29af318d|OBS-672ad5c9cfde29af318d]]

### gross_margin_pct · 2025-07-27 · quarter

**72.42%**；状态：calculation_checked。证据 ID：OBS-fa9f49c332f386fef007。

^OBS-fa9f49c332f386fef007

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`GrossProfit`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-24123204e70a2c0dbb38|OBS-24123204e70a2c0dbb38]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-8d71b092b586921d8938|OBS-8d71b092b586921d8938]]

### gross_profit · 2025-07-27 · quarter

**33.853 B USD**；状态：source_recorded。证据 ID：OBS-24123204e70a2c0dbb38。

^OBS-24123204e70a2c0dbb38

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`GrossProfit`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### inventory · 2025-07-27 · instant

**14.962 B USD**；状态：source_recorded。证据 ID：OBS-c579625d5cbbc6a63039。

^OBS-c579625d5cbbc6a63039

期间：时点 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000209。
字段：`InventoryNet`；申报日期：2025-08-27。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000209/0001045810-25-000209-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2025-07-27 · instant

**40.609 B USD**；状态：source_recorded。证据 ID：OBS-7a6ce31f8a2534f205a7。

^OBS-7a6ce31f8a2534f205a7

期间：时点 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000209。
字段：`Liabilities`；申报日期：2025-08-27。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000209/0001045810-25-000209-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-07-27 · quarter

**26.422 B USD**；状态：source_recorded。证据 ID：OBS-250407eb8fd220eef88a。

^OBS-250407eb8fd220eef88a

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`NetIncomeLoss`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2025-07-27 · quarter

**15.365 B USD**；状态：needs_review。证据 ID：OBS-607624a9d6c413921a16。

^OBS-607624a9d6c413921a16

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-c74ff40c4722f065ff69|OBS-c74ff40c4722f065ff69]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-6caf4cfef1f5ad6b574a|OBS-6caf4cfef1f5ad6b574a]]

### operating_cash_flow · 2025-07-27 · ytd

**42.779 B USD**；状态：source_recorded。证据 ID：OBS-c74ff40c4722f065ff69。

^OBS-c74ff40c4722f065ff69

期间：2025-01-27 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2025-07-27 · quarter

**28.440 B USD**；状态：source_recorded。证据 ID：OBS-73f8bad472fe48715f4b。

^OBS-73f8bad472fe48715f4b

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`OperatingIncomeLoss`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2025-07-27 · quarter

**60.84%**；状态：calculation_checked。证据 ID：OBS-1d4a18e3c754b5582f19。

^OBS-1d4a18e3c754b5582f19

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`OperatingIncomeLoss`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-73f8bad472fe48715f4b|OBS-73f8bad472fe48715f4b]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-8d71b092b586921d8938|OBS-8d71b092b586921d8938]]

### receivables · 2025-07-27 · instant

**27.808 B USD**；状态：source_recorded。证据 ID：OBS-aa6db51b7a7659d9923f。

^OBS-aa6db51b7a7659d9923f

期间：时点 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000209。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-08-27。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000209/0001045810-25-000209-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-07-27 · quarter

**46.743 B USD**；状态：source_recorded。证据 ID：OBS-8d71b092b586921d8938。

^OBS-8d71b092b586921d8938

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`Revenues`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### assets · 2025-10-26 · instant

**161.148 B USD**；状态：source_recorded。证据 ID：OBS-a8d0391c2972bc1ac5f0。

^OBS-a8d0391c2972bc1ac5f0

期间：时点 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`Assets`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2025-10-26 · quarter

**1.636 B USD**；状态：needs_review。证据 ID：OBS-fa9245aeb0bb99cdb28d。

^OBS-fa9245aeb0bb99cdb28d

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-4f411a3852706c59fbf9|OBS-4f411a3852706c59fbf9]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-bd7ccf8618c3f36bb584|OBS-bd7ccf8618c3f36bb584]]

### capex_cash · 2025-10-26 · ytd

**4.758 B USD**；状态：source_recorded。证据 ID：OBS-4f411a3852706c59fbf9。

^OBS-4f411a3852706c59fbf9

期间：2025-01-27 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.

### cash · 2025-10-26 · instant

**11.486 B USD**；状态：source_recorded。证据 ID：OBS-94efc153c7c597c2e722。

^OBS-94efc153c7c597c2e722

期间：时点 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2025-10-26 · quarter

**1.300 USD/shares**；状态：source_recorded。证据 ID：OBS-89a92e09288ba62c6213。

^OBS-89a92e09288ba62c6213

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`EarningsPerShareDiluted`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2025-10-26 · quarter

**24,483.00 M shares**；状态：source_recorded。证据 ID：OBS-2932e86b9d99758386dc。

^OBS-2932e86b9d99758386dc

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2025-10-26 · instant

**118.897 B USD**；状态：source_recorded。证据 ID：OBS-d7b322291a93435afb06。

^OBS-d7b322291a93435afb06

期间：时点 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`StockholdersEquity`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2025-10-26 · quarter

**22.115 B USD**；状态：needs_review。证据 ID：OBS-d072a534021da3648804。

^OBS-d072a534021da3648804

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-634d5eb65b41263185cc|OBS-634d5eb65b41263185cc]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-fa9245aeb0bb99cdb28d|OBS-fa9245aeb0bb99cdb28d]]

### gross_margin_pct · 2025-10-26 · quarter

**73.41%**；状态：calculation_checked。证据 ID：OBS-79efdce46d264c8e99a2。

^OBS-79efdce46d264c8e99a2

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`GrossProfit`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-acd72edc6665f58d5e17|OBS-acd72edc6665f58d5e17]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-59e57c86cea54bf0eb37|OBS-59e57c86cea54bf0eb37]]

### gross_profit · 2025-10-26 · quarter

**41.849 B USD**；状态：source_recorded。证据 ID：OBS-acd72edc6665f58d5e17。

^OBS-acd72edc6665f58d5e17

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`GrossProfit`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### gross_profit · 2025-10-26 · ytd

**102.370 B USD**；状态：source_recorded。证据 ID：OBS-0e50def68d4acca3b0d5。

^OBS-0e50def68d4acca3b0d5

期间：2025-01-27 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`GrossProfit`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### inventory · 2025-10-26 · instant

**19.784 B USD**；状态：source_recorded。证据 ID：OBS-331fa91a267be551ec0e。

^OBS-331fa91a267be551ec0e

期间：时点 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`InventoryNet`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2025-10-26 · instant

**42.251 B USD**；状态：source_recorded。证据 ID：OBS-5d71894eea8efa2ac698。

^OBS-5d71894eea8efa2ac698

期间：时点 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`Liabilities`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2025-10-26 · quarter

**31.910 B USD**；状态：source_recorded。证据 ID：OBS-54cf31897b3d1b84d7bd。

^OBS-54cf31897b3d1b84d7bd

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2025-10-26 · ytd

**77.107 B USD**；状态：source_recorded。证据 ID：OBS-c60d1c572e83e2ae691f。

^OBS-c60d1c572e83e2ae691f

期间：2025-01-27 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2025-10-26 · quarter

**23.751 B USD**；状态：needs_review。证据 ID：OBS-634d5eb65b41263185cc。

^OBS-634d5eb65b41263185cc

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-0cf41b5e12edea93722e|OBS-0cf41b5e12edea93722e]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-c74ff40c4722f065ff69|OBS-c74ff40c4722f065ff69]]

### operating_cash_flow · 2025-10-26 · ytd

**66.530 B USD**；状态：source_recorded。证据 ID：OBS-0cf41b5e12edea93722e。

^OBS-0cf41b5e12edea93722e

期间：2025-01-27 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2025-10-26 · quarter

**36.010 B USD**；状态：source_recorded。证据 ID：OBS-58f6e9556a397addd864。

^OBS-58f6e9556a397addd864

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`OperatingIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2025-10-26 · ytd

**86.088 B USD**；状态：source_recorded。证据 ID：OBS-f481963eea0ef2813da8。

^OBS-f481963eea0ef2813da8

期间：2025-01-27 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`OperatingIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2025-10-26 · quarter

**63.17%**；状态：calculation_checked。证据 ID：OBS-b76871c81fe226f5b472。

^OBS-b76871c81fe226f5b472

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`OperatingIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-58f6e9556a397addd864|OBS-58f6e9556a397addd864]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-59e57c86cea54bf0eb37|OBS-59e57c86cea54bf0eb37]]

### receivables · 2025-10-26 · instant

**33.391 B USD**；状态：source_recorded。证据 ID：OBS-958a37140f520b68f10e。

^OBS-958a37140f520b68f10e

期间：时点 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2025-10-26 · quarter

**57.006 B USD**；状态：source_recorded。证据 ID：OBS-59e57c86cea54bf0eb37。

^OBS-59e57c86cea54bf0eb37

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`Revenues`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### revenue · 2025-10-26 · ytd

**147.811 B USD**；状态：source_recorded。证据 ID：OBS-fb9f7e345a393adb6004。

^OBS-fb9f7e345a393adb6004

期间：2025-01-27 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`Revenues`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### assets · 2026-01-25 · instant

**206.803 B USD**；状态：source_recorded。证据 ID：OBS-a04c4f16056c3bc36c25。

^OBS-a04c4f16056c3bc36c25

期间：时点 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`Assets`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2026-01-25 · annual

**6.042 B USD**；状态：source_recorded。证据 ID：OBS-7a6bf82f892b56ad2cec。

^OBS-7a6bf82f892b56ad2cec

期间：2025-01-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.

### capex_cash · 2026-01-25 · quarter

**1.284 B USD**；状态：needs_review。证据 ID：OBS-29f750d9d9ea2cf57106。

^OBS-29f750d9d9ea2cf57106

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-7a6bf82f892b56ad2cec|OBS-7a6bf82f892b56ad2cec]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-4f411a3852706c59fbf9|OBS-4f411a3852706c59fbf9]]

### cash · 2026-01-25 · instant

**10.605 B USD**；状态：source_recorded。证据 ID：OBS-b22c9be75a477a469b81。

^OBS-b22c9be75a477a469b81

期间：时点 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### equity · 2026-01-25 · instant

**157.293 B USD**；状态：source_recorded。证据 ID：OBS-d18835900d59d6c1c815。

^OBS-d18835900d59d6c1c815

期间：时点 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`StockholdersEquity`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2026-01-25 · quarter

**34.904 B USD**；状态：needs_review。证据 ID：OBS-f0d53bf71ed70d5267f7。

^OBS-f0d53bf71ed70d5267f7

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-6741462d5e48988a7b90|OBS-6741462d5e48988a7b90]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-29f750d9d9ea2cf57106|OBS-29f750d9d9ea2cf57106]]

### gross_margin_pct · 2026-01-25 · quarter

**75.00%**；状态：needs_review。证据 ID：OBS-1e615b6b77f9ed7dae66。

^OBS-1e615b6b77f9ed7dae66

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`GrossProfit`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-73f355fa3044b22097ea|OBS-73f355fa3044b22097ea]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-45413b3999edff481b74|OBS-45413b3999edff481b74]]

### gross_profit · 2026-01-25 · annual

**153.463 B USD**；状态：source_recorded。证据 ID：OBS-1aee827253462e16a76c。

^OBS-1aee827253462e16a76c

期间：2025-01-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`GrossProfit`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### gross_profit · 2026-01-25 · quarter

**51.093 B USD**；状态：needs_review。证据 ID：OBS-73f355fa3044b22097ea。

^OBS-73f355fa3044b22097ea

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`GrossProfit`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-1aee827253462e16a76c|OBS-1aee827253462e16a76c]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-0e50def68d4acca3b0d5|OBS-0e50def68d4acca3b0d5]]

### inventory · 2026-01-25 · instant

**21.403 B USD**；状态：source_recorded。证据 ID：OBS-34f53bcdcd3f431cec39。

^OBS-34f53bcdcd3f431cec39

期间：时点 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`InventoryNet`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2026-01-25 · instant

**49.510 B USD**；状态：source_recorded。证据 ID：OBS-68f9cd1bc76f85ab41c5。

^OBS-68f9cd1bc76f85ab41c5

期间：时点 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`Liabilities`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2026-01-25 · annual

**120.067 B USD**；状态：source_recorded。证据 ID：OBS-ca6d0df33b7df344259b。

^OBS-ca6d0df33b7df344259b

期间：2025-01-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### net_income · 2026-01-25 · quarter

**42.960 B USD**；状态：needs_review。证据 ID：OBS-319a3c9fe0439b8ba723。

^OBS-319a3c9fe0439b8ba723

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-ca6d0df33b7df344259b|OBS-ca6d0df33b7df344259b]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-c60d1c572e83e2ae691f|OBS-c60d1c572e83e2ae691f]]

### operating_cash_flow · 2026-01-25 · annual

**102.718 B USD**；状态：source_recorded。证据 ID：OBS-31f41fa7fcec2fc893ee。

^OBS-31f41fa7fcec2fc893ee

期间：2025-01-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_cash_flow · 2026-01-25 · quarter

**36.188 B USD**；状态：needs_review。证据 ID：OBS-6741462d5e48988a7b90。

^OBS-6741462d5e48988a7b90

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-31f41fa7fcec2fc893ee|OBS-31f41fa7fcec2fc893ee]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-0cf41b5e12edea93722e|OBS-0cf41b5e12edea93722e]]

### operating_income · 2026-01-25 · annual

**130.387 B USD**；状态：source_recorded。证据 ID：OBS-4e0c36e48f500ccc9c82。

^OBS-4e0c36e48f500ccc9c82

期间：2025-01-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`OperatingIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_income · 2026-01-25 · quarter

**44.299 B USD**；状态：needs_review。证据 ID：OBS-168aa6cd2bff8310f316。

^OBS-168aa6cd2bff8310f316

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`OperatingIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-4e0c36e48f500ccc9c82|OBS-4e0c36e48f500ccc9c82]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-f481963eea0ef2813da8|OBS-f481963eea0ef2813da8]]

### operating_margin_pct · 2026-01-25 · quarter

**65.02%**；状态：needs_review。证据 ID：OBS-d2ed388e4f29445a7795。

^OBS-d2ed388e4f29445a7795

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`OperatingIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-168aa6cd2bff8310f316|OBS-168aa6cd2bff8310f316]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-45413b3999edff481b74|OBS-45413b3999edff481b74]]

### receivables · 2026-01-25 · instant

**38.466 B USD**；状态：source_recorded。证据 ID：OBS-2d1f4c8e822cb8dddd33。

^OBS-2d1f4c8e822cb8dddd33

期间：时点 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2026-01-25 · annual

**215.938 B USD**；状态：source_recorded。证据 ID：OBS-e6ccb68053fd63840602。

^OBS-e6ccb68053fd63840602

期间：2025-01-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`Revenues`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### revenue · 2026-01-25 · quarter

**68.127 B USD**；状态：needs_review。证据 ID：OBS-45413b3999edff481b74。

^OBS-45413b3999edff481b74

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`Revenues`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-e6ccb68053fd63840602|OBS-e6ccb68053fd63840602]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-fb9f7e345a393adb6004|OBS-fb9f7e345a393adb6004]]

### assets · 2026-04-26 · instant

**259.474 B USD**；状态：source_recorded。证据 ID：OBS-7d225cb784a058b05415。

^OBS-7d225cb784a058b05415

期间：时点 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`Assets`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2026-04-26 · quarter

**1.757 B USD**；状态：source_recorded。证据 ID：OBS-c0d7a6e93f56af88c96c。

^OBS-c0d7a6e93f56af88c96c

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.

### cash · 2026-04-26 · instant

**13.237 B USD**；状态：source_recorded。证据 ID：OBS-a1671f7862b379ee91a8。

^OBS-a1671f7862b379ee91a8

期间：时点 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2026-04-26 · quarter

**2.390 USD/shares**；状态：source_recorded。证据 ID：OBS-067d0165877fef6b196c。

^OBS-067d0165877fef6b196c

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`EarningsPerShareDiluted`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2026-04-26 · quarter

**24,391.00 M shares**；状态：source_recorded。证据 ID：OBS-83c6f4ef83a017dfc374。

^OBS-83c6f4ef83a017dfc374

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2026-04-26 · instant

**195.474 B USD**；状态：source_recorded。证据 ID：OBS-c81ec52588f5a13f1375。

^OBS-c81ec52588f5a13f1375

期间：时点 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`StockholdersEquity`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2026-04-26 · quarter

**48.587 B USD**；状态：calculation_checked。证据 ID：OBS-441ee66a3239f1f97438。

^OBS-441ee66a3239f1f97438

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-a7e3c53f1523600cf73f|OBS-a7e3c53f1523600cf73f]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-c0d7a6e93f56af88c96c|OBS-c0d7a6e93f56af88c96c]]

### gross_margin_pct · 2026-04-26 · quarter

**74.93%**；状态：calculation_checked。证据 ID：OBS-0bf57fa8e937c2f59902。

^OBS-0bf57fa8e937c2f59902

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`GrossProfit`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-3fbaabf5a0ab0045222c|OBS-3fbaabf5a0ab0045222c]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-27d44b475aa9231cd192|OBS-27d44b475aa9231cd192]]

### gross_profit · 2026-04-26 · quarter

**61.157 B USD**；状态：source_recorded。证据 ID：OBS-3fbaabf5a0ab0045222c。

^OBS-3fbaabf5a0ab0045222c

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`GrossProfit`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### inventory · 2026-04-26 · instant

**25.797 B USD**；状态：source_recorded。证据 ID：OBS-8a2dbf0c55d2e6a30c3f。

^OBS-8a2dbf0c55d2e6a30c3f

期间：时点 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`InventoryNet`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2026-04-26 · instant

**64.000 B USD**；状态：source_recorded。证据 ID：OBS-cece6b696ae52ccb618e。

^OBS-cece6b696ae52ccb618e

期间：时点 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`Liabilities`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2026-04-26 · quarter

**58.321 B USD**；状态：source_recorded。证据 ID：OBS-ee467065a4a02f3278b5。

^OBS-ee467065a4a02f3278b5

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`NetIncomeLoss`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2026-04-26 · quarter

**50.344 B USD**；状态：source_recorded。证据 ID：OBS-a7e3c53f1523600cf73f。

^OBS-a7e3c53f1523600cf73f

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2026-04-26 · quarter

**53.536 B USD**；状态：source_recorded。证据 ID：OBS-4f260b7244b681d33e20。

^OBS-4f260b7244b681d33e20

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`OperatingIncomeLoss`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2026-04-26 · quarter

**65.60%**；状态：calculation_checked。证据 ID：OBS-57a66ed571903b8c0d65。

^OBS-57a66ed571903b8c0d65

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`OperatingIncomeLoss`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-4f260b7244b681d33e20|OBS-4f260b7244b681d33e20]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-27d44b475aa9231cd192|OBS-27d44b475aa9231cd192]]

### receivables · 2026-04-26 · instant

**40.710 B USD**；状态：source_recorded。证据 ID：OBS-9970545d9b629a057c76。

^OBS-9970545d9b629a057c76

期间：时点 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2026-04-26 · quarter

**81.615 B USD**；状态：source_recorded。证据 ID：OBS-27d44b475aa9231cd192。

^OBS-27d44b475aa9231cd192

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`Revenues`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).

### assets · 2026-07-26 · instant

**320.272 B USD**；状态：source_recorded。证据 ID：OBS-ea20dee3e956eb189684。

^OBS-ea20dee3e956eb189684

期间：时点 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`Assets`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all assets that are recognized. Assets are probable future economic benefits obtained or controlled by an entity as a result of past transactions or events.

### capex_cash · 2026-07-26 · quarter

**2.677 B USD**；状态：needs_review。证据 ID：OBS-1c16ade3ce2cbeb75c2c。

^OBS-1c16ade3ce2cbeb75c2c

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-cadddd849e72adb2b547|OBS-cadddd849e72adb2b547]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-c0d7a6e93f56af88c96c|OBS-c0d7a6e93f56af88c96c]]

### capex_cash · 2026-07-26 · ytd

**4.434 B USD**；状态：source_recorded。证据 ID：OBS-cadddd849e72adb2b547。

^OBS-cadddd849e72adb2b547

期间：2026-01-26 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`PaymentsToAcquireProductiveAssets`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：The cash outflow for purchases of and capital improvements on property, plant and equipment (capital expenditures), software, and other intangible assets.

### cash · 2026-07-26 · instant

**22.443 B USD**；状态：source_recorded。证据 ID：OBS-0df83d38cd43a8520369。

^OBS-0df83d38cd43a8520369

期间：时点 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Amount of currency on hand as well as demand deposits with banks or financial institutions. Includes other kinds of accounts that have the general characteristics of demand deposits. Also includes short-term, highly liquid investments that are both readily convertible to known amounts of cash and so near their maturity that they present insignificant risk of changes in value because of changes in interest rates. Excludes cash and cash equivalents within disposal group and discontinued operation.

### diluted_eps · 2026-07-26 · quarter

**2.460 USD/shares**；状态：source_recorded。证据 ID：OBS-81566b085b626a395d6b。

^OBS-81566b085b626a395d6b

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`EarningsPerShareDiluted`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：The amount of net income (loss) for the period available to each share of common stock or common unit outstanding during the reporting period and to each share or unit that would have been outstanding assuming the issuance of common shares or units for all dilutive potential common shares or units outstanding during the reporting period.

### diluted_shares · 2026-07-26 · quarter

**24,285.00 M shares**；状态：source_recorded。证据 ID：OBS-6b44a7ebfc3d3d6e77cc。

^OBS-6b44a7ebfc3d3d6e77cc

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：The average number of shares or units issued and outstanding that are used in calculating diluted EPS or earnings per unit (EPU), determined based on the timing of issuance of shares or units in the period.

### equity · 2026-07-26 · instant

**228.984 B USD**；状态：source_recorded。证据 ID：OBS-e216514dc0e174a45801。

^OBS-e216514dc0e174a45801

期间：时点 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`StockholdersEquity`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Total of all stockholders' equity (deficit) items, net of receivables from officers, directors, owners, and affiliates of the entity which are attributable to the parent. The amount of the economic entity's stockholders' equity attributable to the parent excludes the amount of stockholders' equity which is allocable to that ownership interest in subsidiary equity which is not attributable to the parent (noncontrolling interest, minority interest). This excludes temporary equity and is sometimes called permanent equity.

### fcf_cash · 2026-07-26 · quarter

**21.400 B USD**；状态：needs_review。证据 ID：OBS-b33ce79460f9f75cf216。

^OBS-b33ce79460f9f75cf216

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-7de808b2fc8e52e6f485|OBS-7de808b2fc8e52e6f485]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-1c16ade3ce2cbeb75c2c|OBS-1c16ade3ce2cbeb75c2c]]

### gross_margin_pct · 2026-07-26 · quarter

**74.98%**；状态：calculation_checked。证据 ID：OBS-f70b279076daa2eed19a。

^OBS-f70b279076daa2eed19a

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`GrossProfit`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-7b0fdbe15e3e6e02aa4a|OBS-7b0fdbe15e3e6e02aa4a]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-68635686609a3bdc7e47|OBS-68635686609a3bdc7e47]]

### gross_profit · 2026-07-26 · quarter

**72.142 B USD**；状态：source_recorded。证据 ID：OBS-7b0fdbe15e3e6e02aa4a。

^OBS-7b0fdbe15e3e6e02aa4a

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`GrossProfit`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Aggregate revenue less cost of goods and services sold or operating expenses directly attributable to the revenue generation activity.

### inventory · 2026-07-26 · instant

**31.575 B USD**；状态：source_recorded。证据 ID：OBS-84585c4b780743fcdd7d。

^OBS-84585c4b780743fcdd7d

期间：时点 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`InventoryNet`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Amount after valuation and LIFO reserves of inventory expected to be sold, or consumed within one year or operating cycle, if longer.

### liabilities · 2026-07-26 · instant

**91.288 B USD**；状态：source_recorded。证据 ID：OBS-b93096c305b05edb1990。

^OBS-b93096c305b05edb1990

期间：时点 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`Liabilities`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Sum of the carrying amounts as of the balance sheet date of all liabilities that are recognized. Liabilities are probable future sacrifices of economic benefits arising from present obligations of an entity to transfer assets or provide services to other entities in the future.

### net_income · 2026-07-26 · quarter

**59.688 B USD**；状态：source_recorded。证据 ID：OBS-33854243656551a23318。

^OBS-33854243656551a23318

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`NetIncomeLoss`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：The portion of profit or loss for the period, net of income taxes, which is attributable to the parent.

### operating_cash_flow · 2026-07-26 · quarter

**24.077 B USD**；状态：needs_review。证据 ID：OBS-7de808b2fc8e52e6f485。

^OBS-7de808b2fc8e52e6f485

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-bccf8fc67ed344d0fcf3|OBS-bccf8fc67ed344d0fcf3]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-a7e3c53f1523600cf73f|OBS-a7e3c53f1523600cf73f]]

### operating_cash_flow · 2026-07-26 · ytd

**74.421 B USD**；状态：source_recorded。证据 ID：OBS-bccf8fc67ed344d0fcf3。

^OBS-bccf8fc67ed344d0fcf3

期间：2026-01-26 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Amount of cash inflow (outflow) from operating activities, including discontinued operations. Operating activity cash flows include transactions, adjustments, and changes in value not defined as investing or financing activities.

### operating_income · 2026-07-26 · quarter

**63.734 B USD**；状态：source_recorded。证据 ID：OBS-d0ddc4dcce29b5d4bba5。

^OBS-d0ddc4dcce29b5d4bba5

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`OperatingIncomeLoss`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.

### operating_margin_pct · 2026-07-26 · quarter

**66.24%**；状态：calculation_checked。证据 ID：OBS-44e1f238ee680a5dbe83。

^OBS-44e1f238ee680a5dbe83

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`OperatingIncomeLoss`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：The net result for the period of deducting operating expenses from operating revenues.
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-d0ddc4dcce29b5d4bba5|OBS-d0ddc4dcce29b5d4bba5]]、[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence#^OBS-68635686609a3bdc7e47|OBS-68635686609a3bdc7e47]]

### receivables · 2026-07-26 · instant

**63.059 B USD**；状态：source_recorded。证据 ID：OBS-e4d02453092a36997ffb。

^OBS-e4d02453092a36997ffb

期间：时点 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Amount, after allowance for credit loss, of right to consideration from customer for product sold and service rendered in normal course of business, classified as current.

### revenue · 2026-07-26 · quarter

**96.221 B USD**；状态：source_recorded。证据 ID：OBS-68635686609a3bdc7e47。

^OBS-68635686609a3bdc7e47

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`Revenues`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
定义：Amount of revenue recognized from goods sold, services rendered, insurance premiums, or other activities that constitute an earning process. Includes, but is not limited to, investment and interest income before deduction of interest expense when recognized as a component of revenue, and sales and trading gain (loss).
