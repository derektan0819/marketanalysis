---
title: "NVDA — 本次数据与原文证据（运行 20261019T070744Z-4e0381）"
tags: [reports, run-history, evidence]
created: 2026-10-19
updated: 2026-10-19
source: "引擎运行 20261019T070744Z-4e0381 的数据快照 12_Data/Companies/NVDA/20261019T070744Z-4e0381.json"
---
# NVDA — 本次数据与原文证据

资料截止：2026-10-19T07:07:44+00:00。

[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Brief|本次简报]] · [[04_Companies/NVDA/Company Profile|NVDA 档案]] · [[04_Companies/NVDA/Latest Brief|最新简报]] · [[04_Companies/NVDA/NVDA - Data History|八季数据]] · [[04_Companies/NVDA/Evidence Index|证据索引]] · [[04_Companies/NVDA/Current Thesis|当前判断]] · [[04_Companies/NVDA/Thesis History|判断历史]]

本页是保存快照的阅读视图；链接表示引用或计算依赖，不表示独立验证或因果关系。
包含最近八季的观察值，以及计算所需的较早输入。后续运行各自生成证据页，旧简报不会跳到新快照。

## 原始快照
[[12_Data/Companies/NVDA/20261019T070744Z-4e0381.json|JSON 快照（外部编辑器）]]

## 财报原文
- [[13_Sources/Records/SRC-37b983f4389f983f2f7b570c|10-Q]]；期间／事件日：2026-07-26
  提取正文：[[13_Sources/Raw/SRC-37b983f4389f983f2f7b570c|SRC-37b983f4389f983f2f7b570c 正文]]
- [[13_Sources/Records/SRC-1db8a6c89a58e018e4171fc7|10-K]]；期间／事件日：2026-01-25
  提取正文：[[13_Sources/Raw/SRC-1db8a6c89a58e018e4171fc7|SRC-1db8a6c89a58e018e4171fc7 正文]]
- [[13_Sources/Records/SRC-1cf41a59f7a0f9bd19d142ef|earnings_release_8K]]；期间／事件日：2026-08-26
  提取正文：[[13_Sources/Raw/SRC-1cf41a59f7a0f9bd19d142ef|SRC-1cf41a59f7a0f9bd19d142ef 正文]]

## 数字与计算依赖

### operating_cash_flow · 2024-07-28 · ytd

**29.833 B USD**；状态：source_recorded。证据 ID：OBS-2ce56fcad162a17da26a。

^OBS-2ce56fcad162a17da26a

期间：2024-01-29 → 2024-07-28；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000209。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-08-27。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000209/0001045810-25-000209-index.html

### assets · 2024-10-27 · instant

**96.013 B USD**；状态：source_recorded。证据 ID：OBS-01e6b98ba9b95f2fe344。

^OBS-01e6b98ba9b95f2fe344

期间：时点 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-24-000316。
字段：`Assets`；申报日期：2024-11-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581024000316/0001045810-24-000316-index.html

### cash · 2024-10-27 · instant

**9.107 B USD**；状态：source_recorded。证据 ID：OBS-b9ab0614a42e75e01f3c。

^OBS-b9ab0614a42e75e01f3c

期间：时点 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-24-000316。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2024-11-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581024000316/0001045810-24-000316-index.html

### diluted_eps · 2024-10-27 · quarter

**0.780 USD/shares**；状态：source_recorded。证据 ID：OBS-3d740980683255e38615。

^OBS-3d740980683255e38615

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`EarningsPerShareDiluted`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### diluted_shares · 2024-10-27 · quarter

**24,774.00 M shares**；状态：source_recorded。证据 ID：OBS-76e943a1a0e5bc7bf906。

^OBS-76e943a1a0e5bc7bf906

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### equity · 2024-10-27 · instant

**65.899 B USD**；状态：source_recorded。证据 ID：OBS-62af7ca29de5461ecf0a。

^OBS-62af7ca29de5461ecf0a

期间：时点 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`StockholdersEquity`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### gross_margin_pct · 2024-10-27 · quarter

**74.56%**；状态：calculation_checked。证据 ID：OBS-94eb165f4dee3ed44440。

^OBS-94eb165f4dee3ed44440

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`GrossProfit`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-dfa615a427ccf4fe77c8|OBS-dfa615a427ccf4fe77c8]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-fb4c64b60c16d0278264|OBS-fb4c64b60c16d0278264]]

### gross_profit · 2024-10-27 · quarter

**26.156 B USD**；状态：source_recorded。证据 ID：OBS-dfa615a427ccf4fe77c8。

^OBS-dfa615a427ccf4fe77c8

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`GrossProfit`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### gross_profit · 2024-10-27 · ytd

**69.135 B USD**；状态：source_recorded。证据 ID：OBS-48927f6d3a25e66fc583。

^OBS-48927f6d3a25e66fc583

期间：2024-01-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`GrossProfit`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### inventory · 2024-10-27 · instant

**7.654 B USD**；状态：source_recorded。证据 ID：OBS-3e8ca9c46a8ae7852364。

^OBS-3e8ca9c46a8ae7852364

期间：时点 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-24-000316。
字段：`InventoryNet`；申报日期：2024-11-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581024000316/0001045810-24-000316-index.html

### liabilities · 2024-10-27 · instant

**30.114 B USD**；状态：source_recorded。证据 ID：OBS-e593cd4a26efb8f94dbb。

^OBS-e593cd4a26efb8f94dbb

期间：时点 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-24-000316。
字段：`Liabilities`；申报日期：2024-11-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581024000316/0001045810-24-000316-index.html

### net_income · 2024-10-27 · quarter

**19.309 B USD**；状态：source_recorded。证据 ID：OBS-901a32567f449f8f7efa。

^OBS-901a32567f449f8f7efa

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### net_income · 2024-10-27 · ytd

**50.789 B USD**；状态：source_recorded。证据 ID：OBS-a9574fc65ec00e4597c5。

^OBS-a9574fc65ec00e4597c5

期间：2024-01-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### operating_cash_flow · 2024-10-27 · quarter

**17.627 B USD**；状态：needs_review。证据 ID：OBS-c5b3e764c868d528fee3。

^OBS-c5b3e764c868d528fee3

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-107ccc1b65c897879ad7|OBS-107ccc1b65c897879ad7]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-2ce56fcad162a17da26a|OBS-2ce56fcad162a17da26a]]

### operating_cash_flow · 2024-10-27 · ytd

**47.460 B USD**；状态：source_recorded。证据 ID：OBS-107ccc1b65c897879ad7。

^OBS-107ccc1b65c897879ad7

期间：2024-01-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### operating_income · 2024-10-27 · quarter

**21.869 B USD**；状态：source_recorded。证据 ID：OBS-daaa6e812d5b485e8283。

^OBS-daaa6e812d5b485e8283

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`OperatingIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### operating_income · 2024-10-27 · ytd

**57.419 B USD**；状态：source_recorded。证据 ID：OBS-c931eb088c96aac12189。

^OBS-c931eb088c96aac12189

期间：2024-01-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`OperatingIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### operating_margin_pct · 2024-10-27 · quarter

**62.34%**；状态：calculation_checked。证据 ID：OBS-e9a1d7cd55f14b29d7e2。

^OBS-e9a1d7cd55f14b29d7e2

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`OperatingIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-daaa6e812d5b485e8283|OBS-daaa6e812d5b485e8283]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-fb4c64b60c16d0278264|OBS-fb4c64b60c16d0278264]]

### receivables · 2024-10-27 · instant

**17.693 B USD**；状态：source_recorded。证据 ID：OBS-1e2cea1501c835c8db2e。

^OBS-1e2cea1501c835c8db2e

期间：时点 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-24-000316。
字段：`AccountsReceivableNetCurrent`；申报日期：2024-11-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581024000316/0001045810-24-000316-index.html

### revenue · 2024-10-27 · quarter

**35.082 B USD**；状态：source_recorded。证据 ID：OBS-fb4c64b60c16d0278264。

^OBS-fb4c64b60c16d0278264

期间：2024-07-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`Revenues`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### revenue · 2024-10-27 · ytd

**91.166 B USD**；状态：source_recorded。证据 ID：OBS-aec963f153116cac219e。

^OBS-aec963f153116cac219e

期间：2024-01-29 → 2024-10-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`Revenues`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### assets · 2025-01-26 · instant

**111.601 B USD**；状态：source_recorded。证据 ID：OBS-261bb14657a915674bc0。

^OBS-261bb14657a915674bc0

期间：时点 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`Assets`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### cash · 2025-01-26 · instant

**8.589 B USD**；状态：source_recorded。证据 ID：OBS-36495becbf8010e645e0。

^OBS-36495becbf8010e645e0

期间：时点 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### equity · 2025-01-26 · instant

**79.327 B USD**；状态：source_recorded。证据 ID：OBS-a0c10303b7c67cf85ed1。

^OBS-a0c10303b7c67cf85ed1

期间：时点 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`StockholdersEquity`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### gross_margin_pct · 2025-01-26 · quarter

**73.03%**；状态：needs_review。证据 ID：OBS-d41fba7689758a7f8260。

^OBS-d41fba7689758a7f8260

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`GrossProfit`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-a73018dcb991c8f28ac8|OBS-a73018dcb991c8f28ac8]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-de52085b82cf26c08101|OBS-de52085b82cf26c08101]]

### gross_profit · 2025-01-26 · annual

**97.858 B USD**；状态：source_recorded。证据 ID：OBS-f73a126e7043506cc1bc。

^OBS-f73a126e7043506cc1bc

期间：2024-01-29 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`GrossProfit`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### gross_profit · 2025-01-26 · quarter

**28.723 B USD**；状态：needs_review。证据 ID：OBS-a73018dcb991c8f28ac8。

^OBS-a73018dcb991c8f28ac8

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`GrossProfit`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-f73a126e7043506cc1bc|OBS-f73a126e7043506cc1bc]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-48927f6d3a25e66fc583|OBS-48927f6d3a25e66fc583]]

### inventory · 2025-01-26 · instant

**10.080 B USD**；状态：source_recorded。证据 ID：OBS-7add7905ffe3e753baf1。

^OBS-7add7905ffe3e753baf1

期间：时点 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`InventoryNet`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### liabilities · 2025-01-26 · instant

**32.274 B USD**；状态：source_recorded。证据 ID：OBS-be8cd53cd065e4353594。

^OBS-be8cd53cd065e4353594

期间：时点 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`Liabilities`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### net_income · 2025-01-26 · annual

**72.880 B USD**；状态：source_recorded。证据 ID：OBS-9bfe99ace99923ae4ad5。

^OBS-9bfe99ace99923ae4ad5

期间：2024-01-29 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### net_income · 2025-01-26 · quarter

**22.091 B USD**；状态：needs_review。证据 ID：OBS-af134b2b4015f28977d3。

^OBS-af134b2b4015f28977d3

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-9bfe99ace99923ae4ad5|OBS-9bfe99ace99923ae4ad5]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-a9574fc65ec00e4597c5|OBS-a9574fc65ec00e4597c5]]

### operating_cash_flow · 2025-01-26 · annual

**64.089 B USD**；状态：source_recorded。证据 ID：OBS-a67fd24bb5654c2a9525。

^OBS-a67fd24bb5654c2a9525

期间：2024-01-29 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### operating_cash_flow · 2025-01-26 · quarter

**16.629 B USD**；状态：needs_review。证据 ID：OBS-f6f2729c39752fe6bd70。

^OBS-f6f2729c39752fe6bd70

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-a67fd24bb5654c2a9525|OBS-a67fd24bb5654c2a9525]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-107ccc1b65c897879ad7|OBS-107ccc1b65c897879ad7]]

### operating_income · 2025-01-26 · annual

**81.453 B USD**；状态：source_recorded。证据 ID：OBS-9180affd1f5ed5a52ef3。

^OBS-9180affd1f5ed5a52ef3

期间：2024-01-29 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`OperatingIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### operating_income · 2025-01-26 · quarter

**24.034 B USD**；状态：needs_review。证据 ID：OBS-e740f350a09c30cde15c。

^OBS-e740f350a09c30cde15c

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`OperatingIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-9180affd1f5ed5a52ef3|OBS-9180affd1f5ed5a52ef3]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-c931eb088c96aac12189|OBS-c931eb088c96aac12189]]

### operating_margin_pct · 2025-01-26 · quarter

**61.11%**；状态：needs_review。证据 ID：OBS-c7cb3c7a68470ddafe5c。

^OBS-c7cb3c7a68470ddafe5c

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`OperatingIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-e740f350a09c30cde15c|OBS-e740f350a09c30cde15c]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-de52085b82cf26c08101|OBS-de52085b82cf26c08101]]

### receivables · 2025-01-26 · instant

**23.065 B USD**；状态：source_recorded。证据 ID：OBS-0fd256e1e600536b1409。

^OBS-0fd256e1e600536b1409

期间：时点 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### revenue · 2025-01-26 · annual

**130.497 B USD**；状态：source_recorded。证据 ID：OBS-731f20d49c0c9da29be3。

^OBS-731f20d49c0c9da29be3

期间：2024-01-29 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`Revenues`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### revenue · 2025-01-26 · quarter

**39.331 B USD**；状态：needs_review。证据 ID：OBS-de52085b82cf26c08101。

^OBS-de52085b82cf26c08101

期间：2024-10-28 → 2025-01-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`Revenues`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-731f20d49c0c9da29be3|OBS-731f20d49c0c9da29be3]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-aec963f153116cac219e|OBS-aec963f153116cac219e]]

### assets · 2025-04-27 · instant

**125.254 B USD**；状态：source_recorded。证据 ID：OBS-261fe67fa8179f5320f8。

^OBS-261fe67fa8179f5320f8

期间：时点 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000116。
字段：`Assets`；申报日期：2025-05-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000116/0001045810-25-000116-index.html

### cash · 2025-04-27 · instant

**15.234 B USD**；状态：source_recorded。证据 ID：OBS-a7f6e7365ef053e816cd。

^OBS-a7f6e7365ef053e816cd

期间：时点 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000116。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-05-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000116/0001045810-25-000116-index.html

### diluted_eps · 2025-04-27 · quarter

**0.760 USD/shares**；状态：source_recorded。证据 ID：OBS-45fc94aec9ee822f0813。

^OBS-45fc94aec9ee822f0813

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`EarningsPerShareDiluted`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### diluted_shares · 2025-04-27 · quarter

**24,611.00 M shares**；状态：source_recorded。证据 ID：OBS-c626f340773257ab376e。

^OBS-c626f340773257ab376e

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### equity · 2025-04-27 · instant

**83.843 B USD**；状态：source_recorded。证据 ID：OBS-0a0c68a394b9b8b6592c。

^OBS-0a0c68a394b9b8b6592c

期间：时点 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`StockholdersEquity`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### gross_margin_pct · 2025-04-27 · quarter

**60.52%**；状态：calculation_checked。证据 ID：OBS-84d61e4e42ea22ddb028。

^OBS-84d61e4e42ea22ddb028

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`GrossProfit`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-fbbd77968ba424b70f99|OBS-fbbd77968ba424b70f99]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-99eaafa142bd4fea35f8|OBS-99eaafa142bd4fea35f8]]

### gross_profit · 2025-04-27 · quarter

**26.668 B USD**；状态：source_recorded。证据 ID：OBS-fbbd77968ba424b70f99。

^OBS-fbbd77968ba424b70f99

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`GrossProfit`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### inventory · 2025-04-27 · instant

**11.333 B USD**；状态：source_recorded。证据 ID：OBS-601b3d6f911b8d922441。

^OBS-601b3d6f911b8d922441

期间：时点 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000116。
字段：`InventoryNet`；申报日期：2025-05-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000116/0001045810-25-000116-index.html

### liabilities · 2025-04-27 · instant

**41.411 B USD**；状态：source_recorded。证据 ID：OBS-c1729ef5fc451597c5fd。

^OBS-c1729ef5fc451597c5fd

期间：时点 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000116。
字段：`Liabilities`；申报日期：2025-05-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000116/0001045810-25-000116-index.html

### net_income · 2025-04-27 · quarter

**18.775 B USD**；状态：source_recorded。证据 ID：OBS-e261c2f9936b0365dece。

^OBS-e261c2f9936b0365dece

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`NetIncomeLoss`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### operating_cash_flow · 2025-04-27 · quarter

**27.414 B USD**；状态：source_recorded。证据 ID：OBS-6a44d98c9a1e9774276a。

^OBS-6a44d98c9a1e9774276a

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### operating_income · 2025-04-27 · quarter

**21.638 B USD**；状态：source_recorded。证据 ID：OBS-51d971595990b64ee0d0。

^OBS-51d971595990b64ee0d0

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`OperatingIncomeLoss`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### operating_margin_pct · 2025-04-27 · quarter

**49.11%**；状态：calculation_checked。证据 ID：OBS-cd0b195021aeb99b3cfe。

^OBS-cd0b195021aeb99b3cfe

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`OperatingIncomeLoss`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-51d971595990b64ee0d0|OBS-51d971595990b64ee0d0]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-99eaafa142bd4fea35f8|OBS-99eaafa142bd4fea35f8]]

### receivables · 2025-04-27 · instant

**22.132 B USD**；状态：source_recorded。证据 ID：OBS-b734a58fb6082d13bbe0。

^OBS-b734a58fb6082d13bbe0

期间：时点 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000116。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-05-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000116/0001045810-25-000116-index.html

### revenue · 2025-04-27 · quarter

**44.062 B USD**；状态：source_recorded。证据 ID：OBS-99eaafa142bd4fea35f8。

^OBS-99eaafa142bd4fea35f8

期间：2025-01-27 → 2025-04-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`Revenues`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### assets · 2025-07-27 · instant

**140.740 B USD**；状态：source_recorded。证据 ID：OBS-8f280ac9317b17e8db08。

^OBS-8f280ac9317b17e8db08

期间：时点 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000209。
字段：`Assets`；申报日期：2025-08-27。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000209/0001045810-25-000209-index.html

### cash · 2025-07-27 · instant

**11.639 B USD**；状态：source_recorded。证据 ID：OBS-0c1d666d3fa59198a4e3。

^OBS-0c1d666d3fa59198a4e3

期间：时点 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000209。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-08-27。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000209/0001045810-25-000209-index.html

### diluted_eps · 2025-07-27 · quarter

**1.080 USD/shares**；状态：source_recorded。证据 ID：OBS-4f6c1d7acb4eb6542491。

^OBS-4f6c1d7acb4eb6542491

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`EarningsPerShareDiluted`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### diluted_shares · 2025-07-27 · quarter

**24,532.00 M shares**；状态：source_recorded。证据 ID：OBS-cb6d09f2034f5fdd2a54。

^OBS-cb6d09f2034f5fdd2a54

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### equity · 2025-07-27 · instant

**100.131 B USD**；状态：source_recorded。证据 ID：OBS-9d2252d8c84102f86a03。

^OBS-9d2252d8c84102f86a03

期间：时点 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`StockholdersEquity`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### gross_margin_pct · 2025-07-27 · quarter

**72.42%**；状态：calculation_checked。证据 ID：OBS-143bf6233fdcc2ba68d2。

^OBS-143bf6233fdcc2ba68d2

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`GrossProfit`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-a1d8d868117fde240408|OBS-a1d8d868117fde240408]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-2103fad86778a7a3df3c|OBS-2103fad86778a7a3df3c]]

### gross_profit · 2025-07-27 · quarter

**33.853 B USD**；状态：source_recorded。证据 ID：OBS-a1d8d868117fde240408。

^OBS-a1d8d868117fde240408

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`GrossProfit`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### inventory · 2025-07-27 · instant

**14.962 B USD**；状态：source_recorded。证据 ID：OBS-1b841e840ba2dbb90db8。

^OBS-1b841e840ba2dbb90db8

期间：时点 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000209。
字段：`InventoryNet`；申报日期：2025-08-27。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000209/0001045810-25-000209-index.html

### liabilities · 2025-07-27 · instant

**40.609 B USD**；状态：source_recorded。证据 ID：OBS-d86fb4580e28bc783d84。

^OBS-d86fb4580e28bc783d84

期间：时点 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000209。
字段：`Liabilities`；申报日期：2025-08-27。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000209/0001045810-25-000209-index.html

### net_income · 2025-07-27 · quarter

**26.422 B USD**；状态：source_recorded。证据 ID：OBS-c57d313b907db3d03836。

^OBS-c57d313b907db3d03836

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`NetIncomeLoss`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### operating_cash_flow · 2025-07-27 · quarter

**15.365 B USD**；状态：needs_review。证据 ID：OBS-b72e72f72a4c0c3cfd68。

^OBS-b72e72f72a4c0c3cfd68

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-ad55528f5b7e9c5753ef|OBS-ad55528f5b7e9c5753ef]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-6a44d98c9a1e9774276a|OBS-6a44d98c9a1e9774276a]]

### operating_cash_flow · 2025-07-27 · ytd

**42.779 B USD**；状态：source_recorded。证据 ID：OBS-ad55528f5b7e9c5753ef。

^OBS-ad55528f5b7e9c5753ef

期间：2025-01-27 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### operating_income · 2025-07-27 · quarter

**28.440 B USD**；状态：source_recorded。证据 ID：OBS-24139a3920cae19a55f1。

^OBS-24139a3920cae19a55f1

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`OperatingIncomeLoss`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### operating_margin_pct · 2025-07-27 · quarter

**60.84%**；状态：calculation_checked。证据 ID：OBS-5e1138059bd92aaa17af。

^OBS-5e1138059bd92aaa17af

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`OperatingIncomeLoss`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-24139a3920cae19a55f1|OBS-24139a3920cae19a55f1]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-2103fad86778a7a3df3c|OBS-2103fad86778a7a3df3c]]

### receivables · 2025-07-27 · instant

**27.808 B USD**；状态：source_recorded。证据 ID：OBS-a0b34d0715a50591e8ed。

^OBS-a0b34d0715a50591e8ed

期间：时点 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000209。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-08-27。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000209/0001045810-25-000209-index.html

### revenue · 2025-07-27 · quarter

**46.743 B USD**；状态：source_recorded。证据 ID：OBS-2103fad86778a7a3df3c。

^OBS-2103fad86778a7a3df3c

期间：2025-04-28 → 2025-07-27；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`Revenues`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### assets · 2025-10-26 · instant

**161.148 B USD**；状态：source_recorded。证据 ID：OBS-02acccada2ee989bedde。

^OBS-02acccada2ee989bedde

期间：时点 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`Assets`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### cash · 2025-10-26 · instant

**11.486 B USD**；状态：source_recorded。证据 ID：OBS-a165919ce4e8049753c5。

^OBS-a165919ce4e8049753c5

期间：时点 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### diluted_eps · 2025-10-26 · quarter

**1.300 USD/shares**；状态：source_recorded。证据 ID：OBS-3b7d4fc168ba26cc494f。

^OBS-3b7d4fc168ba26cc494f

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`EarningsPerShareDiluted`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### diluted_shares · 2025-10-26 · quarter

**24,483.00 M shares**；状态：source_recorded。证据 ID：OBS-1d2721a6761169acf307。

^OBS-1d2721a6761169acf307

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### equity · 2025-10-26 · instant

**118.897 B USD**；状态：source_recorded。证据 ID：OBS-fd5ff7ecf9342913ec02。

^OBS-fd5ff7ecf9342913ec02

期间：时点 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`StockholdersEquity`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### gross_margin_pct · 2025-10-26 · quarter

**73.41%**；状态：calculation_checked。证据 ID：OBS-9abca86a8e18e39741b1。

^OBS-9abca86a8e18e39741b1

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`GrossProfit`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-f7e74dc5826f7f7f4f12|OBS-f7e74dc5826f7f7f4f12]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-211c381cd64fac3e8ed7|OBS-211c381cd64fac3e8ed7]]

### gross_profit · 2025-10-26 · quarter

**41.849 B USD**；状态：source_recorded。证据 ID：OBS-f7e74dc5826f7f7f4f12。

^OBS-f7e74dc5826f7f7f4f12

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`GrossProfit`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### gross_profit · 2025-10-26 · ytd

**102.370 B USD**；状态：source_recorded。证据 ID：OBS-b2c35fd8120901aeffd0。

^OBS-b2c35fd8120901aeffd0

期间：2025-01-27 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`GrossProfit`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### inventory · 2025-10-26 · instant

**19.784 B USD**；状态：source_recorded。证据 ID：OBS-935d9dff8a0e8af02171。

^OBS-935d9dff8a0e8af02171

期间：时点 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`InventoryNet`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### liabilities · 2025-10-26 · instant

**42.251 B USD**；状态：source_recorded。证据 ID：OBS-1348f163a2801223cf91。

^OBS-1348f163a2801223cf91

期间：时点 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`Liabilities`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### net_income · 2025-10-26 · quarter

**31.910 B USD**；状态：source_recorded。证据 ID：OBS-ce538e5075385311c576。

^OBS-ce538e5075385311c576

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### net_income · 2025-10-26 · ytd

**77.107 B USD**；状态：source_recorded。证据 ID：OBS-fa20d735fbfbe7c5c5e7。

^OBS-fa20d735fbfbe7c5c5e7

期间：2025-01-27 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### operating_cash_flow · 2025-10-26 · quarter

**23.751 B USD**；状态：needs_review。证据 ID：OBS-a78cd28d3923f2b1d084。

^OBS-a78cd28d3923f2b1d084

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-5b7b77907696f45c6a3d|OBS-5b7b77907696f45c6a3d]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-ad55528f5b7e9c5753ef|OBS-ad55528f5b7e9c5753ef]]

### operating_cash_flow · 2025-10-26 · ytd

**66.530 B USD**；状态：source_recorded。证据 ID：OBS-5b7b77907696f45c6a3d。

^OBS-5b7b77907696f45c6a3d

期间：2025-01-27 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### operating_income · 2025-10-26 · quarter

**36.010 B USD**；状态：source_recorded。证据 ID：OBS-3e040492d2468f803f54。

^OBS-3e040492d2468f803f54

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`OperatingIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### operating_income · 2025-10-26 · ytd

**86.088 B USD**；状态：source_recorded。证据 ID：OBS-ffa8d3f7573352fcac32。

^OBS-ffa8d3f7573352fcac32

期间：2025-01-27 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`OperatingIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### operating_margin_pct · 2025-10-26 · quarter

**63.17%**；状态：calculation_checked。证据 ID：OBS-6b1adf61b69958dfef95。

^OBS-6b1adf61b69958dfef95

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`OperatingIncomeLoss`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-3e040492d2468f803f54|OBS-3e040492d2468f803f54]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-211c381cd64fac3e8ed7|OBS-211c381cd64fac3e8ed7]]

### receivables · 2025-10-26 · instant

**33.391 B USD**；状态：source_recorded。证据 ID：OBS-dbfe18679a3c9b7b3f63。

^OBS-dbfe18679a3c9b7b3f63

期间：时点 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### revenue · 2025-10-26 · quarter

**57.006 B USD**；状态：source_recorded。证据 ID：OBS-211c381cd64fac3e8ed7。

^OBS-211c381cd64fac3e8ed7

期间：2025-07-28 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`Revenues`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### revenue · 2025-10-26 · ytd

**147.811 B USD**；状态：source_recorded。证据 ID：OBS-92647026b2b6684ca73e。

^OBS-92647026b2b6684ca73e

期间：2025-01-27 → 2025-10-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-25-000230。
字段：`Revenues`；申报日期：2025-11-19。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581025000230/0001045810-25-000230-index.html

### assets · 2026-01-25 · instant

**206.803 B USD**；状态：source_recorded。证据 ID：OBS-c1262a4044d3a41b28e4。

^OBS-c1262a4044d3a41b28e4

期间：时点 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`Assets`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### cash · 2026-01-25 · instant

**10.605 B USD**；状态：source_recorded。证据 ID：OBS-3f041a59a17b9a946ad4。

^OBS-3f041a59a17b9a946ad4

期间：时点 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### equity · 2026-01-25 · instant

**157.293 B USD**；状态：source_recorded。证据 ID：OBS-ebb8ce4d05a3da84cafe。

^OBS-ebb8ce4d05a3da84cafe

期间：时点 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`StockholdersEquity`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### gross_margin_pct · 2026-01-25 · quarter

**75.00%**；状态：needs_review。证据 ID：OBS-1407f560ca1cd946c92c。

^OBS-1407f560ca1cd946c92c

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`GrossProfit`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-e558f616bb38ec1b2bdb|OBS-e558f616bb38ec1b2bdb]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-d8e9c7bbf4a50ea4fdee|OBS-d8e9c7bbf4a50ea4fdee]]

### gross_profit · 2026-01-25 · annual

**153.463 B USD**；状态：source_recorded。证据 ID：OBS-4c8c5a0b31d0915c6978。

^OBS-4c8c5a0b31d0915c6978

期间：2025-01-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`GrossProfit`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### gross_profit · 2026-01-25 · quarter

**51.093 B USD**；状态：needs_review。证据 ID：OBS-e558f616bb38ec1b2bdb。

^OBS-e558f616bb38ec1b2bdb

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`GrossProfit`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-4c8c5a0b31d0915c6978|OBS-4c8c5a0b31d0915c6978]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-b2c35fd8120901aeffd0|OBS-b2c35fd8120901aeffd0]]

### inventory · 2026-01-25 · instant

**21.403 B USD**；状态：source_recorded。证据 ID：OBS-b2c80bcdd8cb0db6dd38。

^OBS-b2c80bcdd8cb0db6dd38

期间：时点 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`InventoryNet`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### liabilities · 2026-01-25 · instant

**49.510 B USD**；状态：source_recorded。证据 ID：OBS-95e6f96d776a238ec915。

^OBS-95e6f96d776a238ec915

期间：时点 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`Liabilities`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### net_income · 2026-01-25 · annual

**120.067 B USD**；状态：source_recorded。证据 ID：OBS-8dd1d57c65d814f3c024。

^OBS-8dd1d57c65d814f3c024

期间：2025-01-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### net_income · 2026-01-25 · quarter

**42.960 B USD**；状态：needs_review。证据 ID：OBS-4f1e849d3748d45ccc8f。

^OBS-4f1e849d3748d45ccc8f

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-8dd1d57c65d814f3c024|OBS-8dd1d57c65d814f3c024]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-fa20d735fbfbe7c5c5e7|OBS-fa20d735fbfbe7c5c5e7]]

### operating_cash_flow · 2026-01-25 · annual

**102.718 B USD**；状态：source_recorded。证据 ID：OBS-10279f37049a84f4a2ac。

^OBS-10279f37049a84f4a2ac

期间：2025-01-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### operating_cash_flow · 2026-01-25 · quarter

**36.188 B USD**；状态：needs_review。证据 ID：OBS-73e5dae9e173dedc8cca。

^OBS-73e5dae9e173dedc8cca

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-10279f37049a84f4a2ac|OBS-10279f37049a84f4a2ac]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-5b7b77907696f45c6a3d|OBS-5b7b77907696f45c6a3d]]

### operating_income · 2026-01-25 · annual

**130.387 B USD**；状态：source_recorded。证据 ID：OBS-50612c157e697675bf30。

^OBS-50612c157e697675bf30

期间：2025-01-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`OperatingIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### operating_income · 2026-01-25 · quarter

**44.299 B USD**；状态：needs_review。证据 ID：OBS-4b571b6f39c56a804885。

^OBS-4b571b6f39c56a804885

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`OperatingIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-50612c157e697675bf30|OBS-50612c157e697675bf30]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-ffa8d3f7573352fcac32|OBS-ffa8d3f7573352fcac32]]

### operating_margin_pct · 2026-01-25 · quarter

**65.02%**；状态：needs_review。证据 ID：OBS-e7e49eaa05d5cf158683。

^OBS-e7e49eaa05d5cf158683

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`OperatingIncomeLoss`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-4b571b6f39c56a804885|OBS-4b571b6f39c56a804885]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-d8e9c7bbf4a50ea4fdee|OBS-d8e9c7bbf4a50ea4fdee]]

### receivables · 2026-01-25 · instant

**38.466 B USD**；状态：source_recorded。证据 ID：OBS-5eea9505cb771a1fc96f。

^OBS-5eea9505cb771a1fc96f

期间：时点 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### revenue · 2026-01-25 · annual

**215.938 B USD**；状态：source_recorded。证据 ID：OBS-b0e9859c263f265a32c0。

^OBS-b0e9859c263f265a32c0

期间：2025-01-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`Revenues`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html

### revenue · 2026-01-25 · quarter

**68.127 B USD**；状态：needs_review。证据 ID：OBS-d8e9c7bbf4a50ea4fdee。

^OBS-d8e9c7bbf4a50ea4fdee

期间：2025-10-27 → 2026-01-25；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000021。
字段：`Revenues`；申报日期：2026-02-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/0001045810-26-000021-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-b0e9859c263f265a32c0|OBS-b0e9859c263f265a32c0]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-92647026b2b6684ca73e|OBS-92647026b2b6684ca73e]]

### assets · 2026-04-26 · instant

**259.474 B USD**；状态：source_recorded。证据 ID：OBS-0c7e79eee7b543cfbafc。

^OBS-0c7e79eee7b543cfbafc

期间：时点 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`Assets`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### cash · 2026-04-26 · instant

**13.237 B USD**；状态：source_recorded。证据 ID：OBS-054de63770265bd6d7c8。

^OBS-054de63770265bd6d7c8

期间：时点 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### diluted_eps · 2026-04-26 · quarter

**2.390 USD/shares**；状态：source_recorded。证据 ID：OBS-829f8e990da0d5dc5177。

^OBS-829f8e990da0d5dc5177

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`EarningsPerShareDiluted`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### diluted_shares · 2026-04-26 · quarter

**24,391.00 M shares**；状态：source_recorded。证据 ID：OBS-25b52d326a992082e6f0。

^OBS-25b52d326a992082e6f0

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### equity · 2026-04-26 · instant

**195.474 B USD**；状态：source_recorded。证据 ID：OBS-20b7aac1b178d759e5c5。

^OBS-20b7aac1b178d759e5c5

期间：时点 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`StockholdersEquity`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### gross_margin_pct · 2026-04-26 · quarter

**74.93%**；状态：calculation_checked。证据 ID：OBS-3530db4fd7c9929ac7c6。

^OBS-3530db4fd7c9929ac7c6

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`GrossProfit`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-34c3a322a561dafd49df|OBS-34c3a322a561dafd49df]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-d51ba65add6514df6b49|OBS-d51ba65add6514df6b49]]

### gross_profit · 2026-04-26 · quarter

**61.157 B USD**；状态：source_recorded。证据 ID：OBS-34c3a322a561dafd49df。

^OBS-34c3a322a561dafd49df

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`GrossProfit`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### inventory · 2026-04-26 · instant

**25.797 B USD**；状态：source_recorded。证据 ID：OBS-70cbf49e2e3ffdc38805。

^OBS-70cbf49e2e3ffdc38805

期间：时点 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`InventoryNet`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### liabilities · 2026-04-26 · instant

**64.000 B USD**；状态：source_recorded。证据 ID：OBS-cb69eb67007c1ef9b91b。

^OBS-cb69eb67007c1ef9b91b

期间：时点 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`Liabilities`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### net_income · 2026-04-26 · quarter

**58.321 B USD**；状态：source_recorded。证据 ID：OBS-369e393dab1fabd63846。

^OBS-369e393dab1fabd63846

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`NetIncomeLoss`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### operating_cash_flow · 2026-04-26 · quarter

**50.344 B USD**；状态：source_recorded。证据 ID：OBS-96b981cc942db6512abb。

^OBS-96b981cc942db6512abb

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### operating_income · 2026-04-26 · quarter

**53.536 B USD**；状态：source_recorded。证据 ID：OBS-044777c9a41f80a71c3c。

^OBS-044777c9a41f80a71c3c

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`OperatingIncomeLoss`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### operating_margin_pct · 2026-04-26 · quarter

**65.60%**；状态：calculation_checked。证据 ID：OBS-7a7f24a9ae3fde5d4888。

^OBS-7a7f24a9ae3fde5d4888

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`OperatingIncomeLoss`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-044777c9a41f80a71c3c|OBS-044777c9a41f80a71c3c]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-d51ba65add6514df6b49|OBS-d51ba65add6514df6b49]]

### receivables · 2026-04-26 · instant

**40.710 B USD**；状态：source_recorded。证据 ID：OBS-b8c1cd47884f5f9b2c02。

^OBS-b8c1cd47884f5f9b2c02

期间：时点 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### revenue · 2026-04-26 · quarter

**81.615 B USD**；状态：source_recorded。证据 ID：OBS-d51ba65add6514df6b49。

^OBS-d51ba65add6514df6b49

期间：2026-01-26 → 2026-04-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000052。
字段：`Revenues`；申报日期：2026-05-20。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000052/0001045810-26-000052-index.html

### assets · 2026-07-26 · instant

**320.272 B USD**；状态：source_recorded。证据 ID：OBS-eab1aee1f4d66023e76b。

^OBS-eab1aee1f4d66023e76b

期间：时点 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`Assets`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### cash · 2026-07-26 · instant

**22.443 B USD**；状态：source_recorded。证据 ID：OBS-f6db55961e7a1a1f3bb5。

^OBS-f6db55961e7a1a1f3bb5

期间：时点 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### diluted_eps · 2026-07-26 · quarter

**2.460 USD/shares**；状态：source_recorded。证据 ID：OBS-a2aeeeadd7060c515687。

^OBS-a2aeeeadd7060c515687

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`EarningsPerShareDiluted`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### diluted_shares · 2026-07-26 · quarter

**24,285.00 M shares**；状态：source_recorded。证据 ID：OBS-223aacc5262251226d62。

^OBS-223aacc5262251226d62

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### equity · 2026-07-26 · instant

**228.984 B USD**；状态：source_recorded。证据 ID：OBS-9aed265d12203b6866cf。

^OBS-9aed265d12203b6866cf

期间：时点 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`StockholdersEquity`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### gross_margin_pct · 2026-07-26 · quarter

**74.98%**；状态：calculation_checked。证据 ID：OBS-8ea8d9f0bb4d9428dc61。

^OBS-8ea8d9f0bb4d9428dc61

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`GrossProfit`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-3ef9b4395e98b7527014|OBS-3ef9b4395e98b7527014]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-2dbf9d93979411ce8302|OBS-2dbf9d93979411ce8302]]

### gross_profit · 2026-07-26 · quarter

**72.142 B USD**；状态：source_recorded。证据 ID：OBS-3ef9b4395e98b7527014。

^OBS-3ef9b4395e98b7527014

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`GrossProfit`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### inventory · 2026-07-26 · instant

**31.575 B USD**；状态：source_recorded。证据 ID：OBS-f607b7c0fd915915bed1。

^OBS-f607b7c0fd915915bed1

期间：时点 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`InventoryNet`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### liabilities · 2026-07-26 · instant

**91.288 B USD**；状态：source_recorded。证据 ID：OBS-b1e8011978edd639179b。

^OBS-b1e8011978edd639179b

期间：时点 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`Liabilities`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### net_income · 2026-07-26 · quarter

**59.688 B USD**；状态：source_recorded。证据 ID：OBS-d6495cac255ad044256d。

^OBS-d6495cac255ad044256d

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`NetIncomeLoss`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### operating_cash_flow · 2026-07-26 · quarter

**24.077 B USD**；状态：needs_review。证据 ID：OBS-5eccc9b0597608139777。

^OBS-5eccc9b0597608139777

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-1c55353269084b8da9a4|OBS-1c55353269084b8da9a4]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-96b981cc942db6512abb|OBS-96b981cc942db6512abb]]

### operating_cash_flow · 2026-07-26 · ytd

**74.421 B USD**；状态：source_recorded。证据 ID：OBS-1c55353269084b8da9a4。

^OBS-1c55353269084b8da9a4

期间：2026-01-26 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### operating_income · 2026-07-26 · quarter

**63.734 B USD**；状态：source_recorded。证据 ID：OBS-5a7a504399063349ad3d。

^OBS-5a7a504399063349ad3d

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`OperatingIncomeLoss`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### operating_margin_pct · 2026-07-26 · quarter

**66.24%**；状态：calculation_checked。证据 ID：OBS-d3b10edc21fd50e4f1d9。

^OBS-d3b10edc21fd50e4f1d9

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`OperatingIncomeLoss`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-5a7a504399063349ad3d|OBS-5a7a504399063349ad3d]]、[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence#^OBS-2dbf9d93979411ce8302|OBS-2dbf9d93979411ce8302]]

### receivables · 2026-07-26 · instant

**63.059 B USD**；状态：source_recorded。证据 ID：OBS-4803ba117e859f604091。

^OBS-4803ba117e859f604091

期间：时点 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html

### revenue · 2026-07-26 · quarter

**96.221 B USD**；状态：source_recorded。证据 ID：OBS-2dbf9d93979411ce8302。

^OBS-2dbf9d93979411ce8302

期间：2026-04-27 → 2026-07-26；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-df4f13151968a6aacad9041d|SRC-df4f13151968a6aacad9041d]]；申报编号：0001045810-26-000075。
字段：`Revenues`；申报日期：2026-08-26。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/0001045810-26-000075-index.html
