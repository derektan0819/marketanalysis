---
title: "AMZN — 本次数据与原文证据（运行 20261019T070744Z-4e0381）"
tags: [reports, run-history, evidence]
created: 2026-10-19
updated: 2026-10-19
source: "引擎运行 20261019T070744Z-4e0381 的数据快照 12_Data/Companies/AMZN/20261019T070744Z-4e0381.json"
---
# AMZN — 本次数据与原文证据

资料截止：2026-10-19T07:07:44+00:00。

[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Brief|本次简报]] · [[04_Companies/AMZN/Company Profile|AMZN 档案]] · [[04_Companies/AMZN/Latest Brief|最新简报]] · [[04_Companies/AMZN/AMZN - Data History|八季数据]] · [[04_Companies/AMZN/Evidence Index|证据索引]] · [[04_Companies/AMZN/Current Thesis|当前判断]] · [[04_Companies/AMZN/Thesis History|判断历史]]

本页是保存快照的阅读视图；链接表示引用或计算依赖，不表示独立验证或因果关系。
包含最近八季的观察值，以及计算所需的较早输入。后续运行各自生成证据页，旧简报不会跳到新快照。

## 原始快照
[[12_Data/Companies/AMZN/20261019T070744Z-4e0381.json|JSON 快照（外部编辑器）]]

## 财报原文
- [[13_Sources/Records/SRC-c1ec319cd0b030514ec1e7fd|10-Q]]；期间／事件日：2026-06-30
  提取正文：[[13_Sources/Raw/SRC-c1ec319cd0b030514ec1e7fd|SRC-c1ec319cd0b030514ec1e7fd 正文]]
- [[13_Sources/Records/SRC-eb223ffcdc5663a094a6b31e|10-K]]；期间／事件日：2025-12-31
  提取正文：[[13_Sources/Raw/SRC-eb223ffcdc5663a094a6b31e|SRC-eb223ffcdc5663a094a6b31e 正文]]
- [[13_Sources/Records/SRC-cdfdbabdeb7969a82d193e80|earnings_release_8K]]；期间／事件日：2026-07-30
  提取正文：[[13_Sources/Raw/SRC-cdfdbabdeb7969a82d193e80|SRC-cdfdbabdeb7969a82d193e80 正文]]

## 数字与计算依赖

### assets · 2024-09-30 · instant

**584.626 B USD**；状态：source_recorded。证据 ID：OBS-c4ccabf7a9fd4d72f575。

^OBS-c4ccabf7a9fd4d72f575

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-24-000161。
字段：`Assets`；申报日期：2024-11-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872424000161/0001018724-24-000161-index.html

### cash · 2024-09-30 · instant

**75.091 B USD**；状态：source_recorded。证据 ID：OBS-057bfa220c85e9aefae0。

^OBS-057bfa220c85e9aefae0

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-24-000161。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2024-11-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872424000161/0001018724-24-000161-index.html

### diluted_eps · 2024-09-30 · quarter

**1.430 USD/shares**；状态：source_recorded。证据 ID：OBS-ffd747560fb62a79fb9c。

^OBS-ffd747560fb62a79fb9c

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`EarningsPerShareDiluted`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### diluted_shares · 2024-09-30 · quarter

**10,735.00 M shares**；状态：source_recorded。证据 ID：OBS-7fe649f9ad893ef41fbb。

^OBS-7fe649f9ad893ef41fbb

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### equity · 2024-09-30 · instant

**259.151 B USD**；状态：source_recorded。证据 ID：OBS-18ba14a8ca166c13567b。

^OBS-18ba14a8ca166c13567b

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`StockholdersEquity`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### inventory · 2024-09-30 · instant

**36.103 B USD**；状态：source_recorded。证据 ID：OBS-f801419e38a2e3ba20c1。

^OBS-f801419e38a2e3ba20c1

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-24-000161。
字段：`InventoryNet`；申报日期：2024-11-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872424000161/0001018724-24-000161-index.html

### net_income · 2024-09-30 · quarter

**15.328 B USD**；状态：source_recorded。证据 ID：OBS-69b21360412b97f2d81e。

^OBS-69b21360412b97f2d81e

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### net_income · 2024-09-30 · ytd

**39.244 B USD**；状态：source_recorded。证据 ID：OBS-ef384ac548ccdcc2a599。

^OBS-ef384ac548ccdcc2a599

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### operating_cash_flow · 2024-09-30 · quarter

**25.971 B USD**；状态：source_recorded。证据 ID：OBS-a622b543663ea298e527。

^OBS-a622b543663ea298e527

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### operating_cash_flow · 2024-09-30 · ytd

**70.241 B USD**；状态：source_recorded。证据 ID：OBS-e95cd8ae7fae7338d381。

^OBS-e95cd8ae7fae7338d381

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### operating_income · 2024-09-30 · quarter

**17.411 B USD**；状态：source_recorded。证据 ID：OBS-1ca541bab32d6878e799。

^OBS-1ca541bab32d6878e799

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`OperatingIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### operating_income · 2024-09-30 · ytd

**47.390 B USD**；状态：source_recorded。证据 ID：OBS-f9b217cc0990a9d0e786。

^OBS-f9b217cc0990a9d0e786

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`OperatingIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### operating_margin_pct · 2024-09-30 · quarter

**10.96%**；状态：calculation_checked。证据 ID：OBS-8e730f86f3eed2e36891。

^OBS-8e730f86f3eed2e36891

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`OperatingIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-1ca541bab32d6878e799|OBS-1ca541bab32d6878e799]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-b6d96181ddde3167b886|OBS-b6d96181ddde3167b886]]

### receivables · 2024-09-30 · instant

**51.638 B USD**；状态：source_recorded。证据 ID：OBS-1dae6f919e5e24fd05bb。

^OBS-1dae6f919e5e24fd05bb

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-24-000161。
字段：`AccountsReceivableNetCurrent`；申报日期：2024-11-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872424000161/0001018724-24-000161-index.html

### revenue · 2024-09-30 · quarter

**158.877 B USD**；状态：source_recorded。证据 ID：OBS-b6d96181ddde3167b886。

^OBS-b6d96181ddde3167b886

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### revenue · 2024-09-30 · ytd

**450.167 B USD**；状态：source_recorded。证据 ID：OBS-970bcb22a8954dab5615。

^OBS-970bcb22a8954dab5615

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### assets · 2024-12-31 · instant

**624.894 B USD**；状态：source_recorded。证据 ID：OBS-447781d3080cedb0a21a。

^OBS-447781d3080cedb0a21a

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`Assets`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html

### cash · 2024-12-31 · instant

**78.779 B USD**；状态：source_recorded。证据 ID：OBS-730f9aea721206be50b3。

^OBS-730f9aea721206be50b3

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html

### equity · 2024-12-31 · instant

**285.970 B USD**；状态：source_recorded。证据 ID：OBS-528c148e106812c10242。

^OBS-528c148e106812c10242

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`StockholdersEquity`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### inventory · 2024-12-31 · instant

**34.214 B USD**；状态：source_recorded。证据 ID：OBS-4ff9c634d9387d45e073。

^OBS-4ff9c634d9387d45e073

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`InventoryNet`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html

### net_income · 2024-12-31 · annual

**59.248 B USD**；状态：source_recorded。证据 ID：OBS-9eef5b67d2b782c45511。

^OBS-9eef5b67d2b782c45511

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html

### net_income · 2024-12-31 · quarter

**20.004 B USD**；状态：needs_review。证据 ID：OBS-8ea9efb0951cc2049063。

^OBS-8ea9efb0951cc2049063

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-9eef5b67d2b782c45511|OBS-9eef5b67d2b782c45511]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-ef384ac548ccdcc2a599|OBS-ef384ac548ccdcc2a599]]

### operating_cash_flow · 2024-12-31 · annual

**115.877 B USD**；状态：source_recorded。证据 ID：OBS-5040bd0a67c8d9a1bcbb。

^OBS-5040bd0a67c8d9a1bcbb

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html

### operating_cash_flow · 2024-12-31 · quarter

**45.636 B USD**；状态：needs_review。证据 ID：OBS-d81a5a8819ebc80f96fe。

^OBS-d81a5a8819ebc80f96fe

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-5040bd0a67c8d9a1bcbb|OBS-5040bd0a67c8d9a1bcbb]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-e95cd8ae7fae7338d381|OBS-e95cd8ae7fae7338d381]]

### operating_income · 2024-12-31 · annual

**68.593 B USD**；状态：source_recorded。证据 ID：OBS-f1508338a018adc3612a。

^OBS-f1508338a018adc3612a

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`OperatingIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html

### operating_income · 2024-12-31 · quarter

**21.203 B USD**；状态：needs_review。证据 ID：OBS-055c9b11e2051572550b。

^OBS-055c9b11e2051572550b

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`OperatingIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-f1508338a018adc3612a|OBS-f1508338a018adc3612a]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-f9b217cc0990a9d0e786|OBS-f9b217cc0990a9d0e786]]

### operating_margin_pct · 2024-12-31 · quarter

**11.29%**；状态：needs_review。证据 ID：OBS-0a19c1c8be30e4e7c9a8。

^OBS-0a19c1c8be30e4e7c9a8

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`OperatingIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-055c9b11e2051572550b|OBS-055c9b11e2051572550b]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-8d4adb37e6aeac716432|OBS-8d4adb37e6aeac716432]]

### receivables · 2024-12-31 · instant

**55.451 B USD**；状态：source_recorded。证据 ID：OBS-9c66c55738fa9da7cdb8。

^OBS-9c66c55738fa9da7cdb8

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html

### revenue · 2024-12-31 · annual

**637.959 B USD**；状态：source_recorded。证据 ID：OBS-2d9424490d050d03a24c。

^OBS-2d9424490d050d03a24c

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html

### revenue · 2024-12-31 · quarter

**187.792 B USD**；状态：needs_review。证据 ID：OBS-8d4adb37e6aeac716432。

^OBS-8d4adb37e6aeac716432

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-2d9424490d050d03a24c|OBS-2d9424490d050d03a24c]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-970bcb22a8954dab5615|OBS-970bcb22a8954dab5615]]

### assets · 2025-03-31 · instant

**643.256 B USD**；状态：source_recorded。证据 ID：OBS-f575addbb95ff4847c74。

^OBS-f575addbb95ff4847c74

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000036。
字段：`Assets`；申报日期：2025-05-02。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000036/0001018724-25-000036-index.html

### cash · 2025-03-31 · instant

**66.207 B USD**；状态：source_recorded。证据 ID：OBS-31cd90112dece626e4be。

^OBS-31cd90112dece626e4be

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000036。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-05-02。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000036/0001018724-25-000036-index.html

### diluted_eps · 2025-03-31 · quarter

**1.590 USD/shares**；状态：source_recorded。证据 ID：OBS-5e623eb581d0f0f628cd。

^OBS-5e623eb581d0f0f628cd

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`EarningsPerShareDiluted`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### diluted_shares · 2025-03-31 · quarter

**10,793.00 M shares**；状态：source_recorded。证据 ID：OBS-1b936f5fd5925ef9fb8e。

^OBS-1b936f5fd5925ef9fb8e

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### equity · 2025-03-31 · instant

**305.867 B USD**；状态：source_recorded。证据 ID：OBS-9fdfa64bbcf92dc3dc0d。

^OBS-9fdfa64bbcf92dc3dc0d

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`StockholdersEquity`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### inventory · 2025-03-31 · instant

**35.864 B USD**；状态：source_recorded。证据 ID：OBS-067d5e4efd349f1fb50f。

^OBS-067d5e4efd349f1fb50f

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000036。
字段：`InventoryNet`；申报日期：2025-05-02。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000036/0001018724-25-000036-index.html

### net_income · 2025-03-31 · quarter

**17.127 B USD**；状态：source_recorded。证据 ID：OBS-2e868c5a35608eba3547。

^OBS-2e868c5a35608eba3547

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`NetIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### operating_cash_flow · 2025-03-31 · quarter

**17.015 B USD**；状态：source_recorded。证据 ID：OBS-5b34e180adddea506299。

^OBS-5b34e180adddea506299

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### operating_income · 2025-03-31 · quarter

**18.405 B USD**；状态：source_recorded。证据 ID：OBS-cb15926e732997e6c84c。

^OBS-cb15926e732997e6c84c

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### operating_margin_pct · 2025-03-31 · quarter

**11.82%**；状态：calculation_checked。证据 ID：OBS-37ad1ced8e0a27349d1a。

^OBS-37ad1ced8e0a27349d1a

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-cb15926e732997e6c84c|OBS-cb15926e732997e6c84c]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-ca1ecc73cd3b11c6c13f|OBS-ca1ecc73cd3b11c6c13f]]

### receivables · 2025-03-31 · instant

**54.216 B USD**；状态：source_recorded。证据 ID：OBS-36c18b1279590c627b89。

^OBS-36c18b1279590c627b89

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000036。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-05-02。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000036/0001018724-25-000036-index.html

### revenue · 2025-03-31 · quarter

**155.667 B USD**；状态：source_recorded。证据 ID：OBS-ca1ecc73cd3b11c6c13f。

^OBS-ca1ecc73cd3b11c6c13f

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### assets · 2025-06-30 · instant

**682.170 B USD**；状态：source_recorded。证据 ID：OBS-6ffd203b246f88f0de0b。

^OBS-6ffd203b246f88f0de0b

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000086。
字段：`Assets`；申报日期：2025-08-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000086/0001018724-25-000086-index.html

### cash · 2025-06-30 · instant

**57.741 B USD**；状态：source_recorded。证据 ID：OBS-033ce15aea56caf828f2。

^OBS-033ce15aea56caf828f2

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000086。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-08-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000086/0001018724-25-000086-index.html

### diluted_eps · 2025-06-30 · quarter

**1.680 USD/shares**；状态：source_recorded。证据 ID：OBS-324428c901781b665a4f。

^OBS-324428c901781b665a4f

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`EarningsPerShareDiluted`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### diluted_shares · 2025-06-30 · quarter

**10,806.00 M shares**；状态：source_recorded。证据 ID：OBS-3c11f863b36487284802。

^OBS-3c11f863b36487284802

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### equity · 2025-06-30 · instant

**333.775 B USD**；状态：source_recorded。证据 ID：OBS-40c8324e712286dee9e4。

^OBS-40c8324e712286dee9e4

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`StockholdersEquity`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### inventory · 2025-06-30 · instant

**40.825 B USD**；状态：source_recorded。证据 ID：OBS-4c2c77c71a02367f3068。

^OBS-4c2c77c71a02367f3068

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000086。
字段：`InventoryNet`；申报日期：2025-08-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000086/0001018724-25-000086-index.html

### net_income · 2025-06-30 · quarter

**18.164 B USD**；状态：source_recorded。证据 ID：OBS-edbc9f16a2bfaa8b1ba4。

^OBS-edbc9f16a2bfaa8b1ba4

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`NetIncomeLoss`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### operating_cash_flow · 2025-06-30 · quarter

**32.515 B USD**；状态：source_recorded。证据 ID：OBS-99d984b6eba26c73c617。

^OBS-99d984b6eba26c73c617

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### operating_income · 2025-06-30 · quarter

**19.171 B USD**；状态：source_recorded。证据 ID：OBS-d93ef5a566740c1deaa8。

^OBS-d93ef5a566740c1deaa8

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`OperatingIncomeLoss`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### operating_margin_pct · 2025-06-30 · quarter

**11.43%**；状态：calculation_checked。证据 ID：OBS-258250d08acd736784be。

^OBS-258250d08acd736784be

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`OperatingIncomeLoss`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-d93ef5a566740c1deaa8|OBS-d93ef5a566740c1deaa8]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-fd1b681cecd6bbc3fe3e|OBS-fd1b681cecd6bbc3fe3e]]

### receivables · 2025-06-30 · instant

**57.415 B USD**；状态：source_recorded。证据 ID：OBS-d8d38d051f3a824b00ab。

^OBS-d8d38d051f3a824b00ab

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000086。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-08-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000086/0001018724-25-000086-index.html

### revenue · 2025-06-30 · quarter

**167.702 B USD**；状态：source_recorded。证据 ID：OBS-fd1b681cecd6bbc3fe3e。

^OBS-fd1b681cecd6bbc3fe3e

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### assets · 2025-09-30 · instant

**727.921 B USD**；状态：source_recorded。证据 ID：OBS-a6413d9320617b79c84f。

^OBS-a6413d9320617b79c84f

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`Assets`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### cash · 2025-09-30 · instant

**66.922 B USD**；状态：source_recorded。证据 ID：OBS-2f502cd3023adf3fb3c4。

^OBS-2f502cd3023adf3fb3c4

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### diluted_eps · 2025-09-30 · quarter

**1.950 USD/shares**；状态：source_recorded。证据 ID：OBS-42d0024f28660a9d8141。

^OBS-42d0024f28660a9d8141

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`EarningsPerShareDiluted`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### diluted_shares · 2025-09-30 · quarter

**10,845.00 M shares**；状态：source_recorded。证据 ID：OBS-1be2065de3c29c54fc26。

^OBS-1be2065de3c29c54fc26

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### equity · 2025-09-30 · instant

**369.631 B USD**；状态：source_recorded。证据 ID：OBS-6257bb0ead687a8806cf。

^OBS-6257bb0ead687a8806cf

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`StockholdersEquity`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### inventory · 2025-09-30 · instant

**41.494 B USD**；状态：source_recorded。证据 ID：OBS-4351cb90fe215af28a33。

^OBS-4351cb90fe215af28a33

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`InventoryNet`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### net_income · 2025-09-30 · quarter

**21.187 B USD**；状态：source_recorded。证据 ID：OBS-3dbf2145cf6251da6852。

^OBS-3dbf2145cf6251da6852

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### net_income · 2025-09-30 · ytd

**56.478 B USD**；状态：source_recorded。证据 ID：OBS-b791ca539f8f4bd52291。

^OBS-b791ca539f8f4bd52291

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### operating_cash_flow · 2025-09-30 · quarter

**35.525 B USD**；状态：source_recorded。证据 ID：OBS-edec829102c4c9ec9f75。

^OBS-edec829102c4c9ec9f75

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### operating_cash_flow · 2025-09-30 · ytd

**85.055 B USD**；状态：source_recorded。证据 ID：OBS-d4bce88eaf8cfefd236f。

^OBS-d4bce88eaf8cfefd236f

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### operating_income · 2025-09-30 · quarter

**17.422 B USD**；状态：source_recorded。证据 ID：OBS-5494d13acdedc8fcb883。

^OBS-5494d13acdedc8fcb883

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`OperatingIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### operating_income · 2025-09-30 · ytd

**54.998 B USD**；状态：source_recorded。证据 ID：OBS-61e6641f5b45ec2d8138。

^OBS-61e6641f5b45ec2d8138

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`OperatingIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### operating_margin_pct · 2025-09-30 · quarter

**9.67%**；状态：calculation_checked。证据 ID：OBS-e4ab5665dddca47e7d60。

^OBS-e4ab5665dddca47e7d60

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`OperatingIncomeLoss`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-5494d13acdedc8fcb883|OBS-5494d13acdedc8fcb883]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-f3f118f1b2b6ff27f765|OBS-f3f118f1b2b6ff27f765]]

### receivables · 2025-09-30 · instant

**61.175 B USD**；状态：source_recorded。证据 ID：OBS-6abf7e6a44eb9a81c844。

^OBS-6abf7e6a44eb9a81c844

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### revenue · 2025-09-30 · quarter

**180.169 B USD**；状态：source_recorded。证据 ID：OBS-f3f118f1b2b6ff27f765。

^OBS-f3f118f1b2b6ff27f765

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### revenue · 2025-09-30 · ytd

**503.538 B USD**；状态：source_recorded。证据 ID：OBS-a02d03a142cbed05c85d。

^OBS-a02d03a142cbed05c85d

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-25-000123。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2025-10-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872425000123/0001018724-25-000123-index.html

### assets · 2025-12-31 · instant

**818.042 B USD**；状态：source_recorded。证据 ID：OBS-b3f68ca1893e22ac5095。

^OBS-b3f68ca1893e22ac5095

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`Assets`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### cash · 2025-12-31 · instant

**86.810 B USD**；状态：source_recorded。证据 ID：OBS-32b0cd6f30e9a281542c。

^OBS-32b0cd6f30e9a281542c

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### equity · 2025-12-31 · instant

**411.065 B USD**；状态：source_recorded。证据 ID：OBS-d7795261ae0936b832df。

^OBS-d7795261ae0936b832df

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`StockholdersEquity`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### inventory · 2025-12-31 · instant

**38.325 B USD**；状态：source_recorded。证据 ID：OBS-80518f5371c97fc3d731。

^OBS-80518f5371c97fc3d731

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`InventoryNet`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### net_income · 2025-12-31 · annual

**77.670 B USD**；状态：source_recorded。证据 ID：OBS-a6c15dbf2090b65e472c。

^OBS-a6c15dbf2090b65e472c

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html

### net_income · 2025-12-31 · quarter

**21.192 B USD**；状态：needs_review。证据 ID：OBS-47c09d6fd5eb6a052b55。

^OBS-47c09d6fd5eb6a052b55

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-a6c15dbf2090b65e472c|OBS-a6c15dbf2090b65e472c]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-b791ca539f8f4bd52291|OBS-b791ca539f8f4bd52291]]

### operating_cash_flow · 2025-12-31 · annual

**139.514 B USD**；状态：source_recorded。证据 ID：OBS-e65a6b54578b65a804ad。

^OBS-e65a6b54578b65a804ad

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html

### operating_cash_flow · 2025-12-31 · quarter

**54.459 B USD**；状态：needs_review。证据 ID：OBS-f7f84da326c4de62048f。

^OBS-f7f84da326c4de62048f

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-e65a6b54578b65a804ad|OBS-e65a6b54578b65a804ad]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-d4bce88eaf8cfefd236f|OBS-d4bce88eaf8cfefd236f]]

### operating_income · 2025-12-31 · annual

**79.975 B USD**；状态：source_recorded。证据 ID：OBS-373c7287f4eb6be2b6e3。

^OBS-373c7287f4eb6be2b6e3

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`OperatingIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html

### operating_income · 2025-12-31 · quarter

**24.977 B USD**；状态：needs_review。证据 ID：OBS-f8bc3536716e6dac4e97。

^OBS-f8bc3536716e6dac4e97

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`OperatingIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-373c7287f4eb6be2b6e3|OBS-373c7287f4eb6be2b6e3]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-61e6641f5b45ec2d8138|OBS-61e6641f5b45ec2d8138]]

### operating_margin_pct · 2025-12-31 · quarter

**11.71%**；状态：needs_review。证据 ID：OBS-b751611f4058e20373aa。

^OBS-b751611f4058e20373aa

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`OperatingIncomeLoss`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-f8bc3536716e6dac4e97|OBS-f8bc3536716e6dac4e97]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-937b592457174ef96910|OBS-937b592457174ef96910]]

### receivables · 2025-12-31 · instant

**67.729 B USD**；状态：source_recorded。证据 ID：OBS-9ce65738ea81dc5fa0d6。

^OBS-9ce65738ea81dc5fa0d6

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### revenue · 2025-12-31 · annual

**716.924 B USD**；状态：source_recorded。证据 ID：OBS-b55e99bd78a62939d89d。

^OBS-b55e99bd78a62939d89d

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html

### revenue · 2025-12-31 · quarter

**213.386 B USD**；状态：needs_review。证据 ID：OBS-937b592457174ef96910。

^OBS-937b592457174ef96910

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000004。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-02-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/0001018724-26-000004-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-b55e99bd78a62939d89d|OBS-b55e99bd78a62939d89d]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-a02d03a142cbed05c85d|OBS-a02d03a142cbed05c85d]]

### assets · 2026-03-31 · instant

**916.630 B USD**；状态：source_recorded。证据 ID：OBS-5be00968ab5e768574e4。

^OBS-5be00968ab5e768574e4

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`Assets`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### cash · 2026-03-31 · instant

**101.816 B USD**；状态：source_recorded。证据 ID：OBS-38a9b2a8ee5861f53e55。

^OBS-38a9b2a8ee5861f53e55

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### diluted_eps · 2026-03-31 · quarter

**2.780 USD/shares**；状态：source_recorded。证据 ID：OBS-2d31ecd179b4bbb65785。

^OBS-2d31ecd179b4bbb65785

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`EarningsPerShareDiluted`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### diluted_shares · 2026-03-31 · quarter

**10,874.00 M shares**；状态：source_recorded。证据 ID：OBS-0b4167aafeefdb798f85。

^OBS-0b4167aafeefdb798f85

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### equity · 2026-03-31 · instant

**441.914 B USD**；状态：source_recorded。证据 ID：OBS-112d39415b5aa3abb351。

^OBS-112d39415b5aa3abb351

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`StockholdersEquity`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### inventory · 2026-03-31 · instant

**36.534 B USD**；状态：source_recorded。证据 ID：OBS-7c397da133fb0d735010。

^OBS-7c397da133fb0d735010

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`InventoryNet`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### net_income · 2026-03-31 · quarter

**30.255 B USD**；状态：source_recorded。证据 ID：OBS-5c9472de6e387497e229。

^OBS-5c9472de6e387497e229

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`NetIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### operating_cash_flow · 2026-03-31 · quarter

**26.032 B USD**；状态：source_recorded。证据 ID：OBS-aa391ecee2245e9e8c72。

^OBS-aa391ecee2245e9e8c72

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### operating_income · 2026-03-31 · quarter

**23.852 B USD**；状态：source_recorded。证据 ID：OBS-257c55e2b31f703a9f8c。

^OBS-257c55e2b31f703a9f8c

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### operating_margin_pct · 2026-03-31 · quarter

**13.14%**；状态：calculation_checked。证据 ID：OBS-d1198b8abd27016a4e21。

^OBS-d1198b8abd27016a4e21

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-257c55e2b31f703a9f8c|OBS-257c55e2b31f703a9f8c]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-20f53927e119348e572b|OBS-20f53927e119348e572b]]

### receivables · 2026-03-31 · instant

**75.532 B USD**；状态：source_recorded。证据 ID：OBS-cbcb6129a49d4e338f10。

^OBS-cbcb6129a49d4e338f10

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### revenue · 2026-03-31 · quarter

**181.519 B USD**；状态：source_recorded。证据 ID：OBS-20f53927e119348e572b。

^OBS-20f53927e119348e572b

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000014。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000014/0001018724-26-000014-index.html

### assets · 2026-06-30 · instant

**1,095.689 B USD**；状态：source_recorded。证据 ID：OBS-5bf3f9f660169ea741a3。

^OBS-5bf3f9f660169ea741a3

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`Assets`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### cash · 2026-06-30 · instant

**78.213 B USD**；状态：source_recorded。证据 ID：OBS-c6606de5ff6c810d2e1d。

^OBS-c6606de5ff6c810d2e1d

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### diluted_eps · 2026-06-30 · quarter

**5.750 USD/shares**；状态：source_recorded。证据 ID：OBS-f562e41005a2eeb3e93d。

^OBS-f562e41005a2eeb3e93d

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`EarningsPerShareDiluted`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### diluted_shares · 2026-06-30 · quarter

**10,903.00 M shares**；状态：source_recorded。证据 ID：OBS-2b16055b75f569866f79。

^OBS-2b16055b75f569866f79

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### equity · 2026-06-30 · instant

**551.620 B USD**；状态：source_recorded。证据 ID：OBS-61388b76d7a81843a802。

^OBS-61388b76d7a81843a802

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`StockholdersEquity`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### inventory · 2026-06-30 · instant

**38.184 B USD**；状态：source_recorded。证据 ID：OBS-8f8f55ed21e50a05dd01。

^OBS-8f8f55ed21e50a05dd01

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`InventoryNet`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### net_income · 2026-06-30 · quarter

**62.647 B USD**；状态：source_recorded。证据 ID：OBS-d4182228903958d45f18。

^OBS-d4182228903958d45f18

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`NetIncomeLoss`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### operating_cash_flow · 2026-06-30 · quarter

**45.387 B USD**；状态：source_recorded。证据 ID：OBS-335f58cbf3ae4abb1df1。

^OBS-335f58cbf3ae4abb1df1

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### operating_income · 2026-06-30 · quarter

**27.461 B USD**；状态：source_recorded。证据 ID：OBS-adf623c36e0faede0d84。

^OBS-adf623c36e0faede0d84

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`OperatingIncomeLoss`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### operating_margin_pct · 2026-06-30 · quarter

**13.69%**；状态：calculation_checked。证据 ID：OBS-6a56f0125d07199ed62e。

^OBS-6a56f0125d07199ed62e

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`OperatingIncomeLoss`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-adf623c36e0faede0d84|OBS-adf623c36e0faede0d84]]、[[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence#^OBS-cdef896e19ab7c5ff7b6|OBS-cdef896e19ab7c5ff7b6]]

### receivables · 2026-06-30 · instant

**88.092 B USD**；状态：source_recorded。证据 ID：OBS-b6733febf809503916ad。

^OBS-b6733febf809503916ad

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html

### revenue · 2026-06-30 · quarter

**200.606 B USD**；状态：source_recorded。证据 ID：OBS-cdef896e19ab7c5ff7b6。

^OBS-cdef896e19ab7c5ff7b6

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-174f3bdf69743dba0ce516d7|SRC-174f3bdf69743dba0ce516d7]]；申报编号：0001018724-26-000026。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-07-31。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1018724/000101872426000026/0001018724-26-000026-index.html
