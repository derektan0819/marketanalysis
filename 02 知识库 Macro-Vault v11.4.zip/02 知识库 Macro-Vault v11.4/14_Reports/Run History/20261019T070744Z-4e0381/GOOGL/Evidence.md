---
title: "GOOGL — 本次数据与原文证据（运行 20261019T070744Z-4e0381）"
tags: [reports, run-history, evidence]
created: 2026-10-19
updated: 2026-10-19
source: "引擎运行 20261019T070744Z-4e0381 的数据快照 12_Data/Companies/GOOGL/20261019T070744Z-4e0381.json"
---
# GOOGL — 本次数据与原文证据

资料截止：2026-10-19T07:07:44+00:00。

[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Brief|本次简报]] · [[04_Companies/GOOGL/Company Profile|GOOGL 档案]] · [[04_Companies/GOOGL/Latest Brief|最新简报]] · [[04_Companies/GOOGL/GOOGL - Data History|八季数据]] · [[04_Companies/GOOGL/Evidence Index|证据索引]] · [[04_Companies/GOOGL/Current Thesis|当前判断]] · [[04_Companies/GOOGL/Thesis History|判断历史]]

本页是保存快照的阅读视图；链接表示引用或计算依赖，不表示独立验证或因果关系。
包含最近八季的观察值，以及计算所需的较早输入。后续运行各自生成证据页，旧简报不会跳到新快照。

## 原始快照
[[12_Data/Companies/GOOGL/20261019T070744Z-4e0381.json|JSON 快照（外部编辑器）]]

## 财报原文
- [[13_Sources/Records/SRC-76097bd5d0676a2af912246a|10-Q]]；期间／事件日：2026-06-30
  提取正文：[[13_Sources/Raw/SRC-76097bd5d0676a2af912246a|SRC-76097bd5d0676a2af912246a 正文]]
- [[13_Sources/Records/SRC-a7294589a5aaa86bbd9cc776|10-K]]；期间／事件日：2025-12-31
  提取正文：[[13_Sources/Raw/SRC-a7294589a5aaa86bbd9cc776|SRC-a7294589a5aaa86bbd9cc776 正文]]
- [[13_Sources/Records/SRC-989578e077b325a53283a75a|earnings_release_8K]]；期间／事件日：2026-07-22
  提取正文：[[13_Sources/Raw/SRC-989578e077b325a53283a75a|SRC-989578e077b325a53283a75a 正文]]

## 数字与计算依赖

### capex_cash · 2024-06-30 · ytd

**25.198 B USD**；状态：source_recorded。证据 ID：OBS-6140e4ad227c480acfe0。

^OBS-6140e4ad227c480acfe0

期间：2024-01-01 → 2024-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000062。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2025-07-24。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000062/0001652044-25-000062-index.html

### operating_cash_flow · 2024-06-30 · ytd

**55.488 B USD**；状态：source_recorded。证据 ID：OBS-6ea35dd4eeef5daa7d8c。

^OBS-6ea35dd4eeef5daa7d8c

期间：2024-01-01 → 2024-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000062。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-07-24。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000062/0001652044-25-000062-index.html

### assets · 2024-09-30 · instant

**430.266 B USD**；状态：source_recorded。证据 ID：OBS-4c303b6e6218dbac4fbf。

^OBS-4c303b6e6218dbac4fbf

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-24-000118。
字段：`Assets`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204424000118/0001652044-24-000118-index.html

### capex_cash · 2024-09-30 · quarter

**13.061 B USD**；状态：needs_review。证据 ID：OBS-54c758df7e2aac30958b。

^OBS-54c758df7e2aac30958b

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-8136a126e890dc33b661|OBS-8136a126e890dc33b661]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-6140e4ad227c480acfe0|OBS-6140e4ad227c480acfe0]]

### capex_cash · 2024-09-30 · ytd

**38.259 B USD**；状态：source_recorded。证据 ID：OBS-8136a126e890dc33b661。

^OBS-8136a126e890dc33b661

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### cash · 2024-09-30 · instant

**19.959 B USD**；状态：source_recorded。证据 ID：OBS-462f018771766438d0c9。

^OBS-462f018771766438d0c9

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-24-000118。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204424000118/0001652044-24-000118-index.html

### diluted_eps · 2024-09-30 · quarter

**2.120 USD/shares**；状态：source_recorded。证据 ID：OBS-86e80f5b426899d01c0f。

^OBS-86e80f5b426899d01c0f

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`EarningsPerShareDiluted`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### diluted_shares · 2024-09-30 · quarter

**12,419.00 M shares**；状态：source_recorded。证据 ID：OBS-44d061506b89c5c4ce30。

^OBS-44d061506b89c5c4ce30

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### equity · 2024-09-30 · instant

**314.119 B USD**；状态：source_recorded。证据 ID：OBS-ca382779341caf2178fd。

^OBS-ca382779341caf2178fd

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`StockholdersEquity`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### fcf_cash · 2024-09-30 · quarter

**17.637 B USD**；状态：needs_review。证据 ID：OBS-68ef3ffd8f95d4bb5534。

^OBS-68ef3ffd8f95d4bb5534

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-5b4cea239d83e0d982cd|OBS-5b4cea239d83e0d982cd]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-54c758df7e2aac30958b|OBS-54c758df7e2aac30958b]]

### liabilities · 2024-09-30 · instant

**116.147 B USD**；状态：source_recorded。证据 ID：OBS-9cc3566278e20be849af。

^OBS-9cc3566278e20be849af

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-24-000118。
字段：`Liabilities`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204424000118/0001652044-24-000118-index.html

### net_income · 2024-09-30 · quarter

**26.301 B USD**；状态：source_recorded。证据 ID：OBS-20e61b9bb70204283352。

^OBS-20e61b9bb70204283352

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### net_income · 2024-09-30 · ytd

**73.582 B USD**；状态：source_recorded。证据 ID：OBS-dbd1e8eea5aa8197c697。

^OBS-dbd1e8eea5aa8197c697

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### operating_cash_flow · 2024-09-30 · quarter

**30.698 B USD**；状态：needs_review。证据 ID：OBS-5b4cea239d83e0d982cd。

^OBS-5b4cea239d83e0d982cd

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-20f291708bf3a45320a2|OBS-20f291708bf3a45320a2]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-6ea35dd4eeef5daa7d8c|OBS-6ea35dd4eeef5daa7d8c]]

### operating_cash_flow · 2024-09-30 · ytd

**86.186 B USD**；状态：source_recorded。证据 ID：OBS-20f291708bf3a45320a2。

^OBS-20f291708bf3a45320a2

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### operating_income · 2024-09-30 · quarter

**28.521 B USD**；状态：source_recorded。证据 ID：OBS-b80ba3fc20c7dd2681ed。

^OBS-b80ba3fc20c7dd2681ed

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`OperatingIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### operating_income · 2024-09-30 · ytd

**81.418 B USD**；状态：source_recorded。证据 ID：OBS-172c42d7a59b88cda2bc。

^OBS-172c42d7a59b88cda2bc

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`OperatingIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### operating_margin_pct · 2024-09-30 · quarter

**32.31%**；状态：calculation_checked。证据 ID：OBS-5436665d056ec862ec2b。

^OBS-5436665d056ec862ec2b

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`OperatingIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-b80ba3fc20c7dd2681ed|OBS-b80ba3fc20c7dd2681ed]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-3bc221b413192e5383e5|OBS-3bc221b413192e5383e5]]

### receivables · 2024-09-30 · instant

**49.104 B USD**；状态：source_recorded。证据 ID：OBS-8cf40c019f1e879898b8。

^OBS-8cf40c019f1e879898b8

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-24-000118。
字段：`AccountsReceivableNetCurrent`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204424000118/0001652044-24-000118-index.html

### revenue · 2024-09-30 · quarter

**88.268 B USD**；状态：source_recorded。证据 ID：OBS-3bc221b413192e5383e5。

^OBS-3bc221b413192e5383e5

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`Revenues`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### revenue · 2024-09-30 · ytd

**253.549 B USD**；状态：source_recorded。证据 ID：OBS-32908a13b1685144bb66。

^OBS-32908a13b1685144bb66

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`Revenues`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### assets · 2024-12-31 · instant

**450.256 B USD**；状态：source_recorded。证据 ID：OBS-56ebf2cd94a3783878a4。

^OBS-56ebf2cd94a3783878a4

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`Assets`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html

### capex_cash · 2024-12-31 · annual

**52.535 B USD**；状态：source_recorded。证据 ID：OBS-972fb853614f95e79ac1。

^OBS-972fb853614f95e79ac1

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html

### capex_cash · 2024-12-31 · quarter

**14.276 B USD**；状态：needs_review。证据 ID：OBS-5a978587f1e23d262788。

^OBS-5a978587f1e23d262788

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-972fb853614f95e79ac1|OBS-972fb853614f95e79ac1]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-8136a126e890dc33b661|OBS-8136a126e890dc33b661]]

### cash · 2024-12-31 · instant

**23.466 B USD**；状态：source_recorded。证据 ID：OBS-1ee392dd807bd705ac8a。

^OBS-1ee392dd807bd705ac8a

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html

### equity · 2024-12-31 · instant

**325.084 B USD**；状态：source_recorded。证据 ID：OBS-9f7db82c5723193c73b2。

^OBS-9f7db82c5723193c73b2

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`StockholdersEquity`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### fcf_cash · 2024-12-31 · quarter

**24.837 B USD**；状态：needs_review。证据 ID：OBS-46d3a1d535abe5afbb1d。

^OBS-46d3a1d535abe5afbb1d

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-89dd204ae8ad90660a58|OBS-89dd204ae8ad90660a58]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-5a978587f1e23d262788|OBS-5a978587f1e23d262788]]

### liabilities · 2024-12-31 · instant

**125.172 B USD**；状态：source_recorded。证据 ID：OBS-72c1dc8c39c0343034da。

^OBS-72c1dc8c39c0343034da

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`Liabilities`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html

### net_income · 2024-12-31 · annual

**100.118 B USD**；状态：source_recorded。证据 ID：OBS-d7acae2dbeda6d52a441。

^OBS-d7acae2dbeda6d52a441

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html

### net_income · 2024-12-31 · quarter

**26.536 B USD**；状态：needs_review。证据 ID：OBS-5cbc336f6dd8223bbb96。

^OBS-5cbc336f6dd8223bbb96

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-d7acae2dbeda6d52a441|OBS-d7acae2dbeda6d52a441]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-dbd1e8eea5aa8197c697|OBS-dbd1e8eea5aa8197c697]]

### operating_cash_flow · 2024-12-31 · annual

**125.299 B USD**；状态：source_recorded。证据 ID：OBS-27f14f88c840780f2d85。

^OBS-27f14f88c840780f2d85

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html

### operating_cash_flow · 2024-12-31 · quarter

**39.113 B USD**；状态：needs_review。证据 ID：OBS-89dd204ae8ad90660a58。

^OBS-89dd204ae8ad90660a58

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-27f14f88c840780f2d85|OBS-27f14f88c840780f2d85]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-20f291708bf3a45320a2|OBS-20f291708bf3a45320a2]]

### operating_income · 2024-12-31 · annual

**112.390 B USD**；状态：source_recorded。证据 ID：OBS-8bc84921ec90a3f58a24。

^OBS-8bc84921ec90a3f58a24

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`OperatingIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html

### operating_income · 2024-12-31 · quarter

**30.972 B USD**；状态：needs_review。证据 ID：OBS-867e0cc839a7ee6eedf2。

^OBS-867e0cc839a7ee6eedf2

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`OperatingIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-8bc84921ec90a3f58a24|OBS-8bc84921ec90a3f58a24]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-172c42d7a59b88cda2bc|OBS-172c42d7a59b88cda2bc]]

### operating_margin_pct · 2024-12-31 · quarter

**32.11%**；状态：needs_review。证据 ID：OBS-e5a23a9edd21ff899139。

^OBS-e5a23a9edd21ff899139

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`OperatingIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-867e0cc839a7ee6eedf2|OBS-867e0cc839a7ee6eedf2]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-65d854aedb008366ab28|OBS-65d854aedb008366ab28]]

### receivables · 2024-12-31 · instant

**52.340 B USD**；状态：source_recorded。证据 ID：OBS-121ce34435d0b9c098ab。

^OBS-121ce34435d0b9c098ab

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html

### revenue · 2024-12-31 · annual

**350.018 B USD**；状态：source_recorded。证据 ID：OBS-ffb4687169bcaf86e891。

^OBS-ffb4687169bcaf86e891

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`Revenues`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html

### revenue · 2024-12-31 · quarter

**96.469 B USD**；状态：needs_review。证据 ID：OBS-65d854aedb008366ab28。

^OBS-65d854aedb008366ab28

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`Revenues`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-ffb4687169bcaf86e891|OBS-ffb4687169bcaf86e891]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-32908a13b1685144bb66|OBS-32908a13b1685144bb66]]

### assets · 2025-03-31 · instant

**475.374 B USD**；状态：source_recorded。证据 ID：OBS-ecc9782022843d7627f6。

^OBS-ecc9782022843d7627f6

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000043。
字段：`Assets`；申报日期：2025-04-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000043/0001652044-25-000043-index.html

### capex_cash · 2025-03-31 · quarter

**17.197 B USD**；状态：source_recorded。证据 ID：OBS-0748172bf81fc5746aab。

^OBS-0748172bf81fc5746aab

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### cash · 2025-03-31 · instant

**23.264 B USD**；状态：source_recorded。证据 ID：OBS-13c5b3621dcfd7a82056。

^OBS-13c5b3621dcfd7a82056

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000043。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-04-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000043/0001652044-25-000043-index.html

### diluted_eps · 2025-03-31 · quarter

**2.810 USD/shares**；状态：source_recorded。证据 ID：OBS-0b0672ec4379d5a7a8da。

^OBS-0b0672ec4379d5a7a8da

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`EarningsPerShareDiluted`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### diluted_shares · 2025-03-31 · quarter

**12,291.00 M shares**；状态：source_recorded。证据 ID：OBS-1283007e200e3222b815。

^OBS-1283007e200e3222b815

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### equity · 2025-03-31 · instant

**345.267 B USD**；状态：source_recorded。证据 ID：OBS-c745f02975ec8d605f14。

^OBS-c745f02975ec8d605f14

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`StockholdersEquity`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### fcf_cash · 2025-03-31 · quarter

**18.953 B USD**；状态：calculation_checked。证据 ID：OBS-cf887fdc7b650ac0f2a1。

^OBS-cf887fdc7b650ac0f2a1

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-dd6e6cdd0c9d96c3a6ee|OBS-dd6e6cdd0c9d96c3a6ee]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-0748172bf81fc5746aab|OBS-0748172bf81fc5746aab]]

### liabilities · 2025-03-31 · instant

**130.107 B USD**；状态：source_recorded。证据 ID：OBS-dafdcc3ba580beea17cc。

^OBS-dafdcc3ba580beea17cc

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000043。
字段：`Liabilities`；申报日期：2025-04-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000043/0001652044-25-000043-index.html

### net_income · 2025-03-31 · quarter

**34.540 B USD**；状态：source_recorded。证据 ID：OBS-973dd41b235e65e7f213。

^OBS-973dd41b235e65e7f213

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`NetIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### operating_cash_flow · 2025-03-31 · quarter

**36.150 B USD**；状态：source_recorded。证据 ID：OBS-dd6e6cdd0c9d96c3a6ee。

^OBS-dd6e6cdd0c9d96c3a6ee

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### operating_income · 2025-03-31 · quarter

**30.606 B USD**；状态：source_recorded。证据 ID：OBS-1f525a5e0b11a6f162b3。

^OBS-1f525a5e0b11a6f162b3

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### operating_margin_pct · 2025-03-31 · quarter

**33.92%**；状态：calculation_checked。证据 ID：OBS-d1fb05db8fa16c978a64。

^OBS-d1fb05db8fa16c978a64

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-1f525a5e0b11a6f162b3|OBS-1f525a5e0b11a6f162b3]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-ce6e1351210a70fb00df|OBS-ce6e1351210a70fb00df]]

### receivables · 2025-03-31 · instant

**51.000 B USD**；状态：source_recorded。证据 ID：OBS-9ec1bff5d6de8e168131。

^OBS-9ec1bff5d6de8e168131

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000043。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-04-25。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000043/0001652044-25-000043-index.html

### revenue · 2025-03-31 · quarter

**90.234 B USD**；状态：source_recorded。证据 ID：OBS-ce6e1351210a70fb00df。

^OBS-ce6e1351210a70fb00df

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`Revenues`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### assets · 2025-06-30 · instant

**502.053 B USD**；状态：source_recorded。证据 ID：OBS-e723597623830c5cf834。

^OBS-e723597623830c5cf834

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000062。
字段：`Assets`；申报日期：2025-07-24。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000062/0001652044-25-000062-index.html

### capex_cash · 2025-06-30 · quarter

**22.446 B USD**；状态：needs_review。证据 ID：OBS-794e8726825ba7c15bf1。

^OBS-794e8726825ba7c15bf1

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-afa2387babb9473ee6d1|OBS-afa2387babb9473ee6d1]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-0748172bf81fc5746aab|OBS-0748172bf81fc5746aab]]

### capex_cash · 2025-06-30 · ytd

**39.643 B USD**；状态：source_recorded。证据 ID：OBS-afa2387babb9473ee6d1。

^OBS-afa2387babb9473ee6d1

期间：2025-01-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### cash · 2025-06-30 · instant

**21.036 B USD**；状态：source_recorded。证据 ID：OBS-324029a9324f0ed066ec。

^OBS-324029a9324f0ed066ec

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000062。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-07-24。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000062/0001652044-25-000062-index.html

### diluted_eps · 2025-06-30 · quarter

**2.310 USD/shares**；状态：source_recorded。证据 ID：OBS-c16e7969839780c465a0。

^OBS-c16e7969839780c465a0

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`EarningsPerShareDiluted`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### diluted_shares · 2025-06-30 · quarter

**12,198.00 M shares**；状态：source_recorded。证据 ID：OBS-1b1cc7efb461527e2238。

^OBS-1b1cc7efb461527e2238

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### equity · 2025-06-30 · instant

**362.916 B USD**；状态：source_recorded。证据 ID：OBS-573861778d2d2ea9c5f7。

^OBS-573861778d2d2ea9c5f7

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`StockholdersEquity`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### fcf_cash · 2025-06-30 · quarter

**5.301 B USD**；状态：needs_review。证据 ID：OBS-d95075753fe293f94d00。

^OBS-d95075753fe293f94d00

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-5bf0cbe95ef60168ec5f|OBS-5bf0cbe95ef60168ec5f]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-794e8726825ba7c15bf1|OBS-794e8726825ba7c15bf1]]

### liabilities · 2025-06-30 · instant

**139.137 B USD**；状态：source_recorded。证据 ID：OBS-f27267f7e29e3f9fa5e0。

^OBS-f27267f7e29e3f9fa5e0

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000062。
字段：`Liabilities`；申报日期：2025-07-24。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000062/0001652044-25-000062-index.html

### net_income · 2025-06-30 · quarter

**28.196 B USD**；状态：source_recorded。证据 ID：OBS-ae380bf4515af23f4c48。

^OBS-ae380bf4515af23f4c48

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetIncomeLoss`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### operating_cash_flow · 2025-06-30 · quarter

**27.747 B USD**；状态：needs_review。证据 ID：OBS-5bf0cbe95ef60168ec5f。

^OBS-5bf0cbe95ef60168ec5f

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-fd4b487044ff87ba7867|OBS-fd4b487044ff87ba7867]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-dd6e6cdd0c9d96c3a6ee|OBS-dd6e6cdd0c9d96c3a6ee]]

### operating_cash_flow · 2025-06-30 · ytd

**63.897 B USD**；状态：source_recorded。证据 ID：OBS-fd4b487044ff87ba7867。

^OBS-fd4b487044ff87ba7867

期间：2025-01-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### operating_income · 2025-06-30 · quarter

**31.271 B USD**；状态：source_recorded。证据 ID：OBS-8c1b4808283a03e5b7c9。

^OBS-8c1b4808283a03e5b7c9

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`OperatingIncomeLoss`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### operating_margin_pct · 2025-06-30 · quarter

**32.43%**；状态：calculation_checked。证据 ID：OBS-414de44aec017d16d980。

^OBS-414de44aec017d16d980

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`OperatingIncomeLoss`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-8c1b4808283a03e5b7c9|OBS-8c1b4808283a03e5b7c9]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-61ba6589155fad3c0615|OBS-61ba6589155fad3c0615]]

### receivables · 2025-06-30 · instant

**55.048 B USD**；状态：source_recorded。证据 ID：OBS-2396a23e6bd13bdb0b26。

^OBS-2396a23e6bd13bdb0b26

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000062。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-07-24。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000062/0001652044-25-000062-index.html

### revenue · 2025-06-30 · quarter

**96.428 B USD**；状态：source_recorded。证据 ID：OBS-61ba6589155fad3c0615。

^OBS-61ba6589155fad3c0615

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`Revenues`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### assets · 2025-09-30 · instant

**536.469 B USD**；状态：source_recorded。证据 ID：OBS-67f407268f4503d22ed9。

^OBS-67f407268f4503d22ed9

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`Assets`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### capex_cash · 2025-09-30 · quarter

**23.953 B USD**；状态：needs_review。证据 ID：OBS-efd0236fd649a4af9a3e。

^OBS-efd0236fd649a4af9a3e

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-db78fc3464c216b5d3ff|OBS-db78fc3464c216b5d3ff]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-afa2387babb9473ee6d1|OBS-afa2387babb9473ee6d1]]

### capex_cash · 2025-09-30 · ytd

**63.596 B USD**；状态：source_recorded。证据 ID：OBS-db78fc3464c216b5d3ff。

^OBS-db78fc3464c216b5d3ff

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### cash · 2025-09-30 · instant

**23.090 B USD**；状态：source_recorded。证据 ID：OBS-160278c64e647228a5c9。

^OBS-160278c64e647228a5c9

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### diluted_eps · 2025-09-30 · quarter

**2.870 USD/shares**；状态：source_recorded。证据 ID：OBS-c84af4e756ad7c29231c。

^OBS-c84af4e756ad7c29231c

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`EarningsPerShareDiluted`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### diluted_shares · 2025-09-30 · quarter

**12,203.00 M shares**；状态：source_recorded。证据 ID：OBS-466977042729bbd8a01f。

^OBS-466977042729bbd8a01f

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### equity · 2025-09-30 · instant

**386.867 B USD**；状态：source_recorded。证据 ID：OBS-be35b09d5bc2805ece01。

^OBS-be35b09d5bc2805ece01

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`StockholdersEquity`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### fcf_cash · 2025-09-30 · quarter

**24.461 B USD**；状态：needs_review。证据 ID：OBS-e9fc08a74cc9181aaf8b。

^OBS-e9fc08a74cc9181aaf8b

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-7e8082ee84223cf90e2f|OBS-7e8082ee84223cf90e2f]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-efd0236fd649a4af9a3e|OBS-efd0236fd649a4af9a3e]]

### liabilities · 2025-09-30 · instant

**149.602 B USD**；状态：source_recorded。证据 ID：OBS-52bca47e4ccfe136d8b4。

^OBS-52bca47e4ccfe136d8b4

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`Liabilities`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### net_income · 2025-09-30 · quarter

**34.979 B USD**；状态：source_recorded。证据 ID：OBS-b1131b42be1e3a7eb467。

^OBS-b1131b42be1e3a7eb467

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### net_income · 2025-09-30 · ytd

**97.715 B USD**；状态：source_recorded。证据 ID：OBS-2afbf75c56cac231a098。

^OBS-2afbf75c56cac231a098

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### operating_cash_flow · 2025-09-30 · quarter

**48.414 B USD**；状态：needs_review。证据 ID：OBS-7e8082ee84223cf90e2f。

^OBS-7e8082ee84223cf90e2f

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-b8c7af9c397ca4203214|OBS-b8c7af9c397ca4203214]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-fd4b487044ff87ba7867|OBS-fd4b487044ff87ba7867]]

### operating_cash_flow · 2025-09-30 · ytd

**112.311 B USD**；状态：source_recorded。证据 ID：OBS-b8c7af9c397ca4203214。

^OBS-b8c7af9c397ca4203214

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### operating_income · 2025-09-30 · quarter

**31.228 B USD**；状态：source_recorded。证据 ID：OBS-4da86b4eac100be7bb13。

^OBS-4da86b4eac100be7bb13

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`OperatingIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### operating_income · 2025-09-30 · ytd

**93.105 B USD**；状态：source_recorded。证据 ID：OBS-ae28ff25e244406882d6。

^OBS-ae28ff25e244406882d6

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`OperatingIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### operating_margin_pct · 2025-09-30 · quarter

**30.51%**；状态：calculation_checked。证据 ID：OBS-13618d7baa035fa05669。

^OBS-13618d7baa035fa05669

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`OperatingIncomeLoss`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-4da86b4eac100be7bb13|OBS-4da86b4eac100be7bb13]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-da5c223de70cb2864cca|OBS-da5c223de70cb2864cca]]

### receivables · 2025-09-30 · instant

**57.148 B USD**；状态：source_recorded。证据 ID：OBS-7cb6a71365694ca583ad。

^OBS-7cb6a71365694ca583ad

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### revenue · 2025-09-30 · quarter

**102.346 B USD**；状态：source_recorded。证据 ID：OBS-da5c223de70cb2864cca。

^OBS-da5c223de70cb2864cca

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`Revenues`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### revenue · 2025-09-30 · ytd

**289.007 B USD**；状态：source_recorded。证据 ID：OBS-313c34a25b7ac75621e0。

^OBS-313c34a25b7ac75621e0

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-25-000091。
字段：`Revenues`；申报日期：2025-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204425000091/0001652044-25-000091-index.html

### assets · 2025-12-31 · instant

**595.281 B USD**；状态：source_recorded。证据 ID：OBS-4761e8ffb1908db45aa5。

^OBS-4761e8ffb1908db45aa5

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`Assets`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### capex_cash · 2025-12-31 · annual

**91.447 B USD**；状态：source_recorded。证据 ID：OBS-d79f094ac951017a07b1。

^OBS-d79f094ac951017a07b1

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html

### capex_cash · 2025-12-31 · quarter

**27.851 B USD**；状态：needs_review。证据 ID：OBS-7c9a41833e970fa74a2a。

^OBS-7c9a41833e970fa74a2a

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-d79f094ac951017a07b1|OBS-d79f094ac951017a07b1]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-db78fc3464c216b5d3ff|OBS-db78fc3464c216b5d3ff]]

### cash · 2025-12-31 · instant

**30.708 B USD**；状态：source_recorded。证据 ID：OBS-7613040aa7d6643dec74。

^OBS-7613040aa7d6643dec74

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### equity · 2025-12-31 · instant

**415.265 B USD**；状态：source_recorded。证据 ID：OBS-23fe75130d2f746a74af。

^OBS-23fe75130d2f746a74af

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`StockholdersEquity`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### fcf_cash · 2025-12-31 · quarter

**24.551 B USD**；状态：needs_review。证据 ID：OBS-b06527c685bcf74bc5cd。

^OBS-b06527c685bcf74bc5cd

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-ec56ecc6708db8cdea0f|OBS-ec56ecc6708db8cdea0f]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-7c9a41833e970fa74a2a|OBS-7c9a41833e970fa74a2a]]

### inventory · 2025-12-31 · instant

**2.439 B USD**；状态：source_recorded。证据 ID：OBS-2b06fe634eba92b8a408。

^OBS-2b06fe634eba92b8a408

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`InventoryNet`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### liabilities · 2025-12-31 · instant

**180.016 B USD**；状态：source_recorded。证据 ID：OBS-c90af09e480996b739f5。

^OBS-c90af09e480996b739f5

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`Liabilities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### net_income · 2025-12-31 · annual

**132.170 B USD**；状态：source_recorded。证据 ID：OBS-5b8509de67ee0d1b22fa。

^OBS-5b8509de67ee0d1b22fa

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html

### net_income · 2025-12-31 · quarter

**34.455 B USD**；状态：needs_review。证据 ID：OBS-cf13b3986caf361d3041。

^OBS-cf13b3986caf361d3041

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-5b8509de67ee0d1b22fa|OBS-5b8509de67ee0d1b22fa]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-2afbf75c56cac231a098|OBS-2afbf75c56cac231a098]]

### operating_cash_flow · 2025-12-31 · annual

**164.713 B USD**；状态：source_recorded。证据 ID：OBS-abd6d2ed8b6f1b543259。

^OBS-abd6d2ed8b6f1b543259

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html

### operating_cash_flow · 2025-12-31 · quarter

**52.402 B USD**；状态：needs_review。证据 ID：OBS-ec56ecc6708db8cdea0f。

^OBS-ec56ecc6708db8cdea0f

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-abd6d2ed8b6f1b543259|OBS-abd6d2ed8b6f1b543259]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-b8c7af9c397ca4203214|OBS-b8c7af9c397ca4203214]]

### operating_income · 2025-12-31 · annual

**129.039 B USD**；状态：source_recorded。证据 ID：OBS-048ac065088583a601f5。

^OBS-048ac065088583a601f5

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`OperatingIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html

### operating_income · 2025-12-31 · quarter

**35.934 B USD**；状态：needs_review。证据 ID：OBS-61894fbd98ff9598c301。

^OBS-61894fbd98ff9598c301

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`OperatingIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-048ac065088583a601f5|OBS-048ac065088583a601f5]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-ae28ff25e244406882d6|OBS-ae28ff25e244406882d6]]

### operating_margin_pct · 2025-12-31 · quarter

**31.57%**；状态：needs_review。证据 ID：OBS-f3518916d947b887986f。

^OBS-f3518916d947b887986f

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`OperatingIncomeLoss`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-61894fbd98ff9598c301|OBS-61894fbd98ff9598c301]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-affd2f8282f938602cc2|OBS-affd2f8282f938602cc2]]

### receivables · 2025-12-31 · instant

**62.886 B USD**；状态：source_recorded。证据 ID：OBS-643146e989c9037c219e。

^OBS-643146e989c9037c219e

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### revenue · 2025-12-31 · annual

**402.836 B USD**；状态：source_recorded。证据 ID：OBS-df0dad35ee4465493dbe。

^OBS-df0dad35ee4465493dbe

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`Revenues`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html

### revenue · 2025-12-31 · quarter

**113.829 B USD**；状态：needs_review。证据 ID：OBS-affd2f8282f938602cc2。

^OBS-affd2f8282f938602cc2

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000018。
字段：`Revenues`；申报日期：2026-02-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/0001652044-26-000018-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-df0dad35ee4465493dbe|OBS-df0dad35ee4465493dbe]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-313c34a25b7ac75621e0|OBS-313c34a25b7ac75621e0]]

### assets · 2026-03-31 · instant

**703.919 B USD**；状态：source_recorded。证据 ID：OBS-42fd8ac6092f94c9779c。

^OBS-42fd8ac6092f94c9779c

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`Assets`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### capex_cash · 2026-03-31 · quarter

**35.674 B USD**；状态：source_recorded。证据 ID：OBS-aa6a146183accd9b9d6c。

^OBS-aa6a146183accd9b9d6c

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### cash · 2026-03-31 · instant

**38.063 B USD**；状态：source_recorded。证据 ID：OBS-e62259ccaba79333846f。

^OBS-e62259ccaba79333846f

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### diluted_eps · 2026-03-31 · quarter

**5.110 USD/shares**；状态：source_recorded。证据 ID：OBS-6266bb0326c16fe4af3d。

^OBS-6266bb0326c16fe4af3d

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`EarningsPerShareDiluted`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### diluted_shares · 2026-03-31 · quarter

**12,238.00 M shares**；状态：source_recorded。证据 ID：OBS-751e9d60208c2b68703b。

^OBS-751e9d60208c2b68703b

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### equity · 2026-03-31 · instant

**478.746 B USD**；状态：source_recorded。证据 ID：OBS-e055e9c2c2d391e3eede。

^OBS-e055e9c2c2d391e3eede

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`StockholdersEquity`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### fcf_cash · 2026-03-31 · quarter

**10.116 B USD**；状态：calculation_checked。证据 ID：OBS-aef0fed33ac6c2d0cd5b。

^OBS-aef0fed33ac6c2d0cd5b

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-92a66d7ba9e18b4fa130|OBS-92a66d7ba9e18b4fa130]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-aa6a146183accd9b9d6c|OBS-aa6a146183accd9b9d6c]]

### liabilities · 2026-03-31 · instant

**225.173 B USD**；状态：source_recorded。证据 ID：OBS-f7c468f7489079c295dc。

^OBS-f7c468f7489079c295dc

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`Liabilities`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### net_income · 2026-03-31 · quarter

**62.578 B USD**；状态：source_recorded。证据 ID：OBS-e60aa3a740840cd4b045。

^OBS-e60aa3a740840cd4b045

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`NetIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### operating_cash_flow · 2026-03-31 · quarter

**45.790 B USD**；状态：source_recorded。证据 ID：OBS-92a66d7ba9e18b4fa130。

^OBS-92a66d7ba9e18b4fa130

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### operating_income · 2026-03-31 · quarter

**39.696 B USD**；状态：source_recorded。证据 ID：OBS-bee73de92f6e95647554。

^OBS-bee73de92f6e95647554

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### operating_margin_pct · 2026-03-31 · quarter

**36.12%**；状态：calculation_checked。证据 ID：OBS-42f84167d7af0323e3dc。

^OBS-42f84167d7af0323e3dc

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`OperatingIncomeLoss`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-bee73de92f6e95647554|OBS-bee73de92f6e95647554]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-6175dd8846efbeedee01|OBS-6175dd8846efbeedee01]]

### receivables · 2026-03-31 · instant

**62.999 B USD**；状态：source_recorded。证据 ID：OBS-6b470ac0e66bbc84a7bb。

^OBS-6b470ac0e66bbc84a7bb

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### revenue · 2026-03-31 · quarter

**109.896 B USD**；状态：source_recorded。证据 ID：OBS-6175dd8846efbeedee01。

^OBS-6175dd8846efbeedee01

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000048。
字段：`Revenues`；申报日期：2026-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000048/0001652044-26-000048-index.html

### assets · 2026-06-30 · instant

**921.983 B USD**；状态：source_recorded。证据 ID：OBS-02b115ada482b15e1c44。

^OBS-02b115ada482b15e1c44

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`Assets`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### capex_cash · 2026-06-30 · quarter

**44.924 B USD**；状态：needs_review。证据 ID：OBS-e9655451791dc83c5e60。

^OBS-e9655451791dc83c5e60

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-2cb3a50e08876066d717|OBS-2cb3a50e08876066d717]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-aa6a146183accd9b9d6c|OBS-aa6a146183accd9b9d6c]]

### capex_cash · 2026-06-30 · ytd

**80.598 B USD**；状态：source_recorded。证据 ID：OBS-2cb3a50e08876066d717。

^OBS-2cb3a50e08876066d717

期间：2026-01-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### cash · 2026-06-30 · instant

**55.911 B USD**；状态：source_recorded。证据 ID：OBS-472fb2b987b3c12672b1。

^OBS-472fb2b987b3c12672b1

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### diluted_eps · 2026-06-30 · quarter

**9.110 USD/shares**；状态：source_recorded。证据 ID：OBS-01944df88c9566a88dcd。

^OBS-01944df88c9566a88dcd

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`EarningsPerShareDiluted`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### diluted_shares · 2026-06-30 · quarter

**12,309.00 M shares**；状态：source_recorded。证据 ID：OBS-6625613a6f9a8330e620。

^OBS-6625613a6f9a8330e620

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### equity · 2026-06-30 · instant

**640.480 B USD**；状态：source_recorded。证据 ID：OBS-324fb327cca31d8197d0。

^OBS-324fb327cca31d8197d0

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`StockholdersEquity`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### fcf_cash · 2026-06-30 · quarter

**-5.855 B USD**；状态：needs_review。证据 ID：OBS-19825abb43d7bd5c2078。

^OBS-19825abb43d7bd5c2078

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-fe9c50dfbf04b02b1816|OBS-fe9c50dfbf04b02b1816]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-e9655451791dc83c5e60|OBS-e9655451791dc83c5e60]]

### inventory · 2026-06-30 · instant

**9.991 B USD**；状态：source_recorded。证据 ID：OBS-947d54a188a22e5d7961。

^OBS-947d54a188a22e5d7961

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`InventoryNet`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### liabilities · 2026-06-30 · instant

**281.503 B USD**；状态：source_recorded。证据 ID：OBS-2af84e3a69eba3de8fc9。

^OBS-2af84e3a69eba3de8fc9

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`Liabilities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### net_income · 2026-06-30 · quarter

**112.193 B USD**；状态：source_recorded。证据 ID：OBS-31824a3fcfa0a0377b3e。

^OBS-31824a3fcfa0a0377b3e

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetIncomeLoss`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### operating_cash_flow · 2026-06-30 · quarter

**39.069 B USD**；状态：needs_review。证据 ID：OBS-fe9c50dfbf04b02b1816。

^OBS-fe9c50dfbf04b02b1816

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-984901d737fc9e5b4078|OBS-984901d737fc9e5b4078]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-92a66d7ba9e18b4fa130|OBS-92a66d7ba9e18b4fa130]]

### operating_cash_flow · 2026-06-30 · ytd

**84.859 B USD**；状态：source_recorded。证据 ID：OBS-984901d737fc9e5b4078。

^OBS-984901d737fc9e5b4078

期间：2026-01-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### operating_income · 2026-06-30 · quarter

**40.770 B USD**；状态：source_recorded。证据 ID：OBS-646de5e9804e7d593093。

^OBS-646de5e9804e7d593093

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`OperatingIncomeLoss`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### operating_margin_pct · 2026-06-30 · quarter

**34.03%**；状态：calculation_checked。证据 ID：OBS-0c992b6d220eb1323766。

^OBS-0c992b6d220eb1323766

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`OperatingIncomeLoss`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-646de5e9804e7d593093|OBS-646de5e9804e7d593093]]、[[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence#^OBS-ebb2de814558cbc194c6|OBS-ebb2de814558cbc194c6]]

### receivables · 2026-06-30 · instant

**69.175 B USD**；状态：source_recorded。证据 ID：OBS-3c9585b76f9810ecf159。

^OBS-3c9585b76f9810ecf159

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html

### revenue · 2026-06-30 · quarter

**119.796 B USD**；状态：source_recorded。证据 ID：OBS-ebb2de814558cbc194c6。

^OBS-ebb2de814558cbc194c6

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-1d3f9e9e2a262c50d415f466|SRC-1d3f9e9e2a262c50d415f466]]；申报编号：0001652044-26-000071。
字段：`Revenues`；申报日期：2026-07-23。
原始申报链接：https://www.sec.gov/Archives/edgar/data/1652044/000165204426000071/0001652044-26-000071-index.html
