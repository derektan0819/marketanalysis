---
title: "MSFT — 本次数据与原文证据（运行 20261019T070744Z-4e0381）"
tags: [reports, run-history, evidence]
created: 2026-10-19
updated: 2026-10-19
source: "引擎运行 20261019T070744Z-4e0381 的数据快照 12_Data/Companies/MSFT/20261019T070744Z-4e0381.json"
---
# MSFT — 本次数据与原文证据

资料截止：2026-10-19T07:07:44+00:00。

[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Brief|本次简报]] · [[04_Companies/MSFT/Company Profile|MSFT 档案]] · [[04_Companies/MSFT/Latest Brief|最新简报]] · [[04_Companies/MSFT/MSFT - Data History|八季数据]] · [[04_Companies/MSFT/Evidence Index|证据索引]] · [[04_Companies/MSFT/Current Thesis|当前判断]] · [[04_Companies/MSFT/Thesis History|判断历史]]

本页是保存快照的阅读视图；链接表示引用或计算依赖，不表示独立验证或因果关系。
包含最近八季的观察值，以及计算所需的较早输入。后续运行各自生成证据页，旧简报不会跳到新快照。

## 原始快照
[[12_Data/Companies/MSFT/20261019T070744Z-4e0381.json|JSON 快照（外部编辑器）]]

## 财报原文
- [[13_Sources/Records/SRC-2b259bd14aae3c6cda610019|10-Q]]；期间／事件日：2026-03-31
  提取正文：[[13_Sources/Raw/SRC-2b259bd14aae3c6cda610019|SRC-2b259bd14aae3c6cda610019 正文]]
- [[13_Sources/Records/SRC-ee4a8840d145293adfaac731|10-K]]；期间／事件日：2026-06-30
  提取正文：[[13_Sources/Raw/SRC-ee4a8840d145293adfaac731|SRC-ee4a8840d145293adfaac731 正文]]
- [[13_Sources/Records/SRC-fd41fbb8d4e31433b10eee67|earnings_release_8K]]；期间／事件日：2026-07-29
  提取正文：[[13_Sources/Raw/SRC-fd41fbb8d4e31433b10eee67|SRC-fd41fbb8d4e31433b10eee67 正文]]

## 数字与计算依赖

### assets · 2024-09-30 · instant

**523.013 B USD**；状态：source_recorded。证据 ID：OBS-422dcd9065f2a7654da7。

^OBS-422dcd9065f2a7654da7

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-24-118967。
字段：`Assets`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017024118967/0000950170-24-118967-index.html

### capex_cash · 2024-09-30 · quarter

**14.923 B USD**；状态：source_recorded。证据 ID：OBS-77cacdb9731aa0895f7c。

^OBS-77cacdb9731aa0895f7c

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### cash · 2024-09-30 · instant

**20.840 B USD**；状态：source_recorded。证据 ID：OBS-291f7954a9fd0b489a6b。

^OBS-291f7954a9fd0b489a6b

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-24-118967。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017024118967/0000950170-24-118967-index.html

### diluted_eps · 2024-09-30 · quarter

**3.300 USD/shares**；状态：source_recorded。证据 ID：OBS-10b90d843dc751060f81。

^OBS-10b90d843dc751060f81

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`EarningsPerShareDiluted`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### diluted_shares · 2024-09-30 · quarter

**7,470.00 M shares**；状态：source_recorded。证据 ID：OBS-0e44aeec3a846b8927a2。

^OBS-0e44aeec3a846b8927a2

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### equity · 2024-09-30 · instant

**287.723 B USD**；状态：source_recorded。证据 ID：OBS-5328df61e65c5d05c853。

^OBS-5328df61e65c5d05c853

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`StockholdersEquity`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### fcf_cash · 2024-09-30 · quarter

**19.257 B USD**；状态：calculation_checked。证据 ID：OBS-e66d9fab8726dfa1ee50。

^OBS-e66d9fab8726dfa1ee50

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-59d918278b0c2104fae4|OBS-59d918278b0c2104fae4]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-77cacdb9731aa0895f7c|OBS-77cacdb9731aa0895f7c]]

### gross_margin_pct · 2024-09-30 · quarter

**69.35%**；状态：calculation_checked。证据 ID：OBS-afc304663b3daa70dc56。

^OBS-afc304663b3daa70dc56

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`GrossProfit`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-639d10cd788ab9b6992c|OBS-639d10cd788ab9b6992c]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-92f99df14b8746a9d90f|OBS-92f99df14b8746a9d90f]]

### gross_profit · 2024-09-30 · quarter

**45.486 B USD**；状态：source_recorded。证据 ID：OBS-639d10cd788ab9b6992c。

^OBS-639d10cd788ab9b6992c

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`GrossProfit`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### inventory · 2024-09-30 · instant

**1.626 B USD**；状态：source_recorded。证据 ID：OBS-5d06e936dbb96967d5b9。

^OBS-5d06e936dbb96967d5b9

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-24-118967。
字段：`InventoryNet`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017024118967/0000950170-24-118967-index.html

### liabilities · 2024-09-30 · instant

**235.290 B USD**；状态：source_recorded。证据 ID：OBS-0d7a51d15c1749caa412。

^OBS-0d7a51d15c1749caa412

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-24-118967。
字段：`Liabilities`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017024118967/0000950170-24-118967-index.html

### net_income · 2024-09-30 · quarter

**24.667 B USD**；状态：source_recorded。证据 ID：OBS-aef3dd2d0963808c3997。

^OBS-aef3dd2d0963808c3997

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`NetIncomeLoss`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### operating_cash_flow · 2024-09-30 · quarter

**34.180 B USD**；状态：source_recorded。证据 ID：OBS-59d918278b0c2104fae4。

^OBS-59d918278b0c2104fae4

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### operating_income · 2024-09-30 · quarter

**30.552 B USD**；状态：source_recorded。证据 ID：OBS-36f87c22927a9aea54e2。

^OBS-36f87c22927a9aea54e2

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`OperatingIncomeLoss`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### operating_margin_pct · 2024-09-30 · quarter

**46.58%**；状态：calculation_checked。证据 ID：OBS-b5d8efff4c890d261b1d。

^OBS-b5d8efff4c890d261b1d

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`OperatingIncomeLoss`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-36f87c22927a9aea54e2|OBS-36f87c22927a9aea54e2]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-92f99df14b8746a9d90f|OBS-92f99df14b8746a9d90f]]

### receivables · 2024-09-30 · instant

**44.148 B USD**；状态：source_recorded。证据 ID：OBS-9403244e427b39088345。

^OBS-9403244e427b39088345

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-24-118967。
字段：`AccountsReceivableNetCurrent`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017024118967/0000950170-24-118967-index.html

### revenue · 2024-09-30 · quarter

**65.585 B USD**；状态：source_recorded。证据 ID：OBS-92f99df14b8746a9d90f。

^OBS-92f99df14b8746a9d90f

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### assets · 2024-12-31 · instant

**533.898 B USD**；状态：source_recorded。证据 ID：OBS-9ce643a22e3f55f284fc。

^OBS-9ce643a22e3f55f284fc

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-010491。
字段：`Assets`；申报日期：2025-01-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025010491/0000950170-25-010491-index.html

### capex_cash · 2024-12-31 · quarter

**15.804 B USD**；状态：source_recorded。证据 ID：OBS-906f5b957ce9dde5dff1。

^OBS-906f5b957ce9dde5dff1

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### cash · 2024-12-31 · instant

**17.482 B USD**；状态：source_recorded。证据 ID：OBS-c72b874129304fae5363。

^OBS-c72b874129304fae5363

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-010491。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-01-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025010491/0000950170-25-010491-index.html

### diluted_eps · 2024-12-31 · quarter

**3.230 USD/shares**；状态：source_recorded。证据 ID：OBS-eee805897c3a8e7fc216。

^OBS-eee805897c3a8e7fc216

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`EarningsPerShareDiluted`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### diluted_shares · 2024-12-31 · quarter

**7,468.00 M shares**；状态：source_recorded。证据 ID：OBS-f26b330539fb835a6b88。

^OBS-f26b330539fb835a6b88

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### equity · 2024-12-31 · instant

**302.695 B USD**；状态：source_recorded。证据 ID：OBS-a5294b334dac38199f7e。

^OBS-a5294b334dac38199f7e

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`StockholdersEquity`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### fcf_cash · 2024-12-31 · quarter

**6.487 B USD**；状态：calculation_checked。证据 ID：OBS-a7d8521c5838eb21061f。

^OBS-a7d8521c5838eb21061f

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-3c8445433d014d43d2a7|OBS-3c8445433d014d43d2a7]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-906f5b957ce9dde5dff1|OBS-906f5b957ce9dde5dff1]]

### gross_margin_pct · 2024-12-31 · quarter

**68.69%**；状态：calculation_checked。证据 ID：OBS-ec358e2aafd58173bc4d。

^OBS-ec358e2aafd58173bc4d

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`GrossProfit`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-2e67d689ca0097cf2917|OBS-2e67d689ca0097cf2917]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-ae7eb3161e7ca5d89632|OBS-ae7eb3161e7ca5d89632]]

### gross_profit · 2024-12-31 · quarter

**47.833 B USD**；状态：source_recorded。证据 ID：OBS-2e67d689ca0097cf2917。

^OBS-2e67d689ca0097cf2917

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`GrossProfit`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### inventory · 2024-12-31 · instant

**0.909 B USD**；状态：source_recorded。证据 ID：OBS-3ace459e94afb89c14b5。

^OBS-3ace459e94afb89c14b5

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-010491。
字段：`InventoryNet`；申报日期：2025-01-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025010491/0000950170-25-010491-index.html

### liabilities · 2024-12-31 · instant

**231.203 B USD**；状态：source_recorded。证据 ID：OBS-7c89f4db1946ecf10de1。

^OBS-7c89f4db1946ecf10de1

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-010491。
字段：`Liabilities`；申报日期：2025-01-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025010491/0000950170-25-010491-index.html

### net_income · 2024-12-31 · quarter

**24.108 B USD**；状态：source_recorded。证据 ID：OBS-c006d1b358fdafbffbb7。

^OBS-c006d1b358fdafbffbb7

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`NetIncomeLoss`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### operating_cash_flow · 2024-12-31 · quarter

**22.291 B USD**；状态：source_recorded。证据 ID：OBS-3c8445433d014d43d2a7。

^OBS-3c8445433d014d43d2a7

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### operating_income · 2024-12-31 · quarter

**31.653 B USD**；状态：source_recorded。证据 ID：OBS-d6ee47f3af64ee64af71。

^OBS-d6ee47f3af64ee64af71

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`OperatingIncomeLoss`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### operating_margin_pct · 2024-12-31 · quarter

**45.46%**；状态：calculation_checked。证据 ID：OBS-926b52b5bb7d7796e07d。

^OBS-926b52b5bb7d7796e07d

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`OperatingIncomeLoss`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-d6ee47f3af64ee64af71|OBS-d6ee47f3af64ee64af71]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-ae7eb3161e7ca5d89632|OBS-ae7eb3161e7ca5d89632]]

### receivables · 2024-12-31 · instant

**48.188 B USD**；状态：source_recorded。证据 ID：OBS-b30abbf77b4b9cc45d41。

^OBS-b30abbf77b4b9cc45d41

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-010491。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-01-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025010491/0000950170-25-010491-index.html

### revenue · 2024-12-31 · quarter

**69.632 B USD**；状态：source_recorded。证据 ID：OBS-ae7eb3161e7ca5d89632。

^OBS-ae7eb3161e7ca5d89632

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### assets · 2025-03-31 · instant

**562.624 B USD**；状态：source_recorded。证据 ID：OBS-3c2f249f8a1e8ba27a68。

^OBS-3c2f249f8a1e8ba27a68

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-061046。
字段：`Assets`；申报日期：2025-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025061046/0000950170-25-061046-index.html

### capex_cash · 2025-03-31 · quarter

**16.745 B USD**；状态：source_recorded。证据 ID：OBS-ba9592afe16834c0e56d。

^OBS-ba9592afe16834c0e56d

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### capex_cash · 2025-03-31 · ytd

**47.472 B USD**；状态：source_recorded。证据 ID：OBS-479a3cda4849e48aac94。

^OBS-479a3cda4849e48aac94

期间：2024-07-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### cash · 2025-03-31 · instant

**28.828 B USD**；状态：source_recorded。证据 ID：OBS-e126f9f827d136716b7e。

^OBS-e126f9f827d136716b7e

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-061046。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025061046/0000950170-25-061046-index.html

### diluted_eps · 2025-03-31 · quarter

**3.460 USD/shares**；状态：source_recorded。证据 ID：OBS-a7e8e68e2983189ea9f1。

^OBS-a7e8e68e2983189ea9f1

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`EarningsPerShareDiluted`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### diluted_shares · 2025-03-31 · quarter

**7,461.00 M shares**；状态：source_recorded。证据 ID：OBS-568c88dbc0f90a1921fc。

^OBS-568c88dbc0f90a1921fc

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### equity · 2025-03-31 · instant

**321.891 B USD**；状态：source_recorded。证据 ID：OBS-188ec1482445d83db389。

^OBS-188ec1482445d83db389

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`StockholdersEquity`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### fcf_cash · 2025-03-31 · quarter

**20.299 B USD**；状态：calculation_checked。证据 ID：OBS-84bbd75db59bb59b21b4。

^OBS-84bbd75db59bb59b21b4

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-0e547d4cafb564ff089a|OBS-0e547d4cafb564ff089a]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-ba9592afe16834c0e56d|OBS-ba9592afe16834c0e56d]]

### gross_margin_pct · 2025-03-31 · quarter

**68.72%**；状态：calculation_checked。证据 ID：OBS-8404147868eb548e30ea。

^OBS-8404147868eb548e30ea

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`GrossProfit`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-61a1147699cb53363009|OBS-61a1147699cb53363009]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-3b7d49a48f9a0e5d0603|OBS-3b7d49a48f9a0e5d0603]]

### gross_profit · 2025-03-31 · quarter

**48.147 B USD**；状态：source_recorded。证据 ID：OBS-61a1147699cb53363009。

^OBS-61a1147699cb53363009

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`GrossProfit`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### gross_profit · 2025-03-31 · ytd

**141.466 B USD**；状态：source_recorded。证据 ID：OBS-9351cbc216ed6e93f53d。

^OBS-9351cbc216ed6e93f53d

期间：2024-07-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`GrossProfit`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### inventory · 2025-03-31 · instant

**0.848 B USD**；状态：source_recorded。证据 ID：OBS-2f05d282f2ab6c6d42fd。

^OBS-2f05d282f2ab6c6d42fd

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-061046。
字段：`InventoryNet`；申报日期：2025-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025061046/0000950170-25-061046-index.html

### liabilities · 2025-03-31 · instant

**240.733 B USD**；状态：source_recorded。证据 ID：OBS-c255432ef310fed10574。

^OBS-c255432ef310fed10574

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-061046。
字段：`Liabilities`；申报日期：2025-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025061046/0000950170-25-061046-index.html

### net_income · 2025-03-31 · quarter

**25.824 B USD**；状态：source_recorded。证据 ID：OBS-3a2694f585f5139a0b00。

^OBS-3a2694f585f5139a0b00

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### net_income · 2025-03-31 · ytd

**74.599 B USD**；状态：source_recorded。证据 ID：OBS-2eb0dd41f550505826df。

^OBS-2eb0dd41f550505826df

期间：2024-07-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### operating_cash_flow · 2025-03-31 · quarter

**37.044 B USD**；状态：source_recorded。证据 ID：OBS-0e547d4cafb564ff089a。

^OBS-0e547d4cafb564ff089a

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### operating_cash_flow · 2025-03-31 · ytd

**93.515 B USD**；状态：source_recorded。证据 ID：OBS-8d0bb3b51b8cf94fe2fe。

^OBS-8d0bb3b51b8cf94fe2fe

期间：2024-07-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### operating_income · 2025-03-31 · quarter

**32.000 B USD**；状态：source_recorded。证据 ID：OBS-f77dff736a14769c6b62。

^OBS-f77dff736a14769c6b62

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`OperatingIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### operating_income · 2025-03-31 · ytd

**94.205 B USD**；状态：source_recorded。证据 ID：OBS-33bda684ee134b3fcb38。

^OBS-33bda684ee134b3fcb38

期间：2024-07-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`OperatingIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### operating_margin_pct · 2025-03-31 · quarter

**45.67%**；状态：calculation_checked。证据 ID：OBS-02d8906064c9f10d8a5e。

^OBS-02d8906064c9f10d8a5e

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`OperatingIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-f77dff736a14769c6b62|OBS-f77dff736a14769c6b62]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-3b7d49a48f9a0e5d0603|OBS-3b7d49a48f9a0e5d0603]]

### receivables · 2025-03-31 · instant

**51.700 B USD**；状态：source_recorded。证据 ID：OBS-7527d14f6d63abf0ba93。

^OBS-7527d14f6d63abf0ba93

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0000950170-25-061046。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-04-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000095017025061046/0000950170-25-061046-index.html

### revenue · 2025-03-31 · quarter

**70.066 B USD**；状态：source_recorded。证据 ID：OBS-3b7d49a48f9a0e5d0603。

^OBS-3b7d49a48f9a0e5d0603

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### revenue · 2025-03-31 · ytd

**205.283 B USD**；状态：source_recorded。证据 ID：OBS-7fda54e18de1f3e95490。

^OBS-7fda54e18de1f3e95490

期间：2024-07-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### assets · 2025-06-30 · instant

**619.003 B USD**；状态：source_recorded。证据 ID：OBS-a90c8791a6a28d82bece。

^OBS-a90c8791a6a28d82bece

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`Assets`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### capex_cash · 2025-06-30 · annual

**64.551 B USD**；状态：source_recorded。证据 ID：OBS-1ca5a4912dae74bc0d33。

^OBS-1ca5a4912dae74bc0d33

期间：2024-07-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### capex_cash · 2025-06-30 · quarter

**17.079 B USD**；状态：needs_review。证据 ID：OBS-8722fa70152fabc9f527。

^OBS-8722fa70152fabc9f527

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-1ca5a4912dae74bc0d33|OBS-1ca5a4912dae74bc0d33]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-479a3cda4849e48aac94|OBS-479a3cda4849e48aac94]]

### cash · 2025-06-30 · instant

**30.242 B USD**；状态：source_recorded。证据 ID：OBS-f9e9c6f603560f97a77d。

^OBS-f9e9c6f603560f97a77d

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### equity · 2025-06-30 · instant

**343.479 B USD**；状态：source_recorded。证据 ID：OBS-c55342112effad01dd27。

^OBS-c55342112effad01dd27

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`StockholdersEquity`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### fcf_cash · 2025-06-30 · quarter

**25.568 B USD**；状态：needs_review。证据 ID：OBS-20a8473c31a69e9fef74。

^OBS-20a8473c31a69e9fef74

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-a9fd57cfb49b649aafb3|OBS-a9fd57cfb49b649aafb3]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-8722fa70152fabc9f527|OBS-8722fa70152fabc9f527]]

### gross_margin_pct · 2025-06-30 · quarter

**68.58%**；状态：needs_review。证据 ID：OBS-fc527fabdfce3f32116f。

^OBS-fc527fabdfce3f32116f

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`GrossProfit`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-217cf8710d6e6be5cc0a|OBS-217cf8710d6e6be5cc0a]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-096c990c8799869651d1|OBS-096c990c8799869651d1]]

### gross_profit · 2025-06-30 · annual

**193.893 B USD**；状态：source_recorded。证据 ID：OBS-f96412654b887274c823。

^OBS-f96412654b887274c823

期间：2024-07-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`GrossProfit`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### gross_profit · 2025-06-30 · quarter

**52.427 B USD**；状态：needs_review。证据 ID：OBS-217cf8710d6e6be5cc0a。

^OBS-217cf8710d6e6be5cc0a

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`GrossProfit`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-f96412654b887274c823|OBS-f96412654b887274c823]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-9351cbc216ed6e93f53d|OBS-9351cbc216ed6e93f53d]]

### inventory · 2025-06-30 · instant

**0.938 B USD**；状态：source_recorded。证据 ID：OBS-8f6609d1ebd3d2c000d0。

^OBS-8f6609d1ebd3d2c000d0

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`InventoryNet`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### liabilities · 2025-06-30 · instant

**275.524 B USD**；状态：source_recorded。证据 ID：OBS-011f8e2ddc762734da39。

^OBS-011f8e2ddc762734da39

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`Liabilities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### net_income · 2025-06-30 · annual

**101.832 B USD**；状态：source_recorded。证据 ID：OBS-d729ce9b472840557efd。

^OBS-d729ce9b472840557efd

期间：2024-07-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### net_income · 2025-06-30 · quarter

**27.233 B USD**；状态：needs_review。证据 ID：OBS-315fef2e0683a4cf8c5b。

^OBS-315fef2e0683a4cf8c5b

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-d729ce9b472840557efd|OBS-d729ce9b472840557efd]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-2eb0dd41f550505826df|OBS-2eb0dd41f550505826df]]

### operating_cash_flow · 2025-06-30 · annual

**136.162 B USD**；状态：source_recorded。证据 ID：OBS-5281dbf3da319b545d55。

^OBS-5281dbf3da319b545d55

期间：2024-07-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### operating_cash_flow · 2025-06-30 · quarter

**42.647 B USD**；状态：needs_review。证据 ID：OBS-a9fd57cfb49b649aafb3。

^OBS-a9fd57cfb49b649aafb3

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-5281dbf3da319b545d55|OBS-5281dbf3da319b545d55]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-8d0bb3b51b8cf94fe2fe|OBS-8d0bb3b51b8cf94fe2fe]]

### operating_income · 2025-06-30 · annual

**128.528 B USD**；状态：source_recorded。证据 ID：OBS-b0eb610a609f56d95046。

^OBS-b0eb610a609f56d95046

期间：2024-07-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`OperatingIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### operating_income · 2025-06-30 · quarter

**34.323 B USD**；状态：needs_review。证据 ID：OBS-018e014211dee4a8c64d。

^OBS-018e014211dee4a8c64d

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`OperatingIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-b0eb610a609f56d95046|OBS-b0eb610a609f56d95046]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-33bda684ee134b3fcb38|OBS-33bda684ee134b3fcb38]]

### operating_margin_pct · 2025-06-30 · quarter

**44.90%**；状态：needs_review。证据 ID：OBS-5ae853287bc6bde1165e。

^OBS-5ae853287bc6bde1165e

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`OperatingIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-018e014211dee4a8c64d|OBS-018e014211dee4a8c64d]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-096c990c8799869651d1|OBS-096c990c8799869651d1]]

### receivables · 2025-06-30 · instant

**69.905 B USD**；状态：source_recorded。证据 ID：OBS-c2c542a42e5e37089a03。

^OBS-c2c542a42e5e37089a03

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### revenue · 2025-06-30 · annual

**281.724 B USD**；状态：source_recorded。证据 ID：OBS-ffbb3b5b783c905dbd95。

^OBS-ffbb3b5b783c905dbd95

期间：2024-07-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### revenue · 2025-06-30 · quarter

**76.441 B USD**；状态：needs_review。证据 ID：OBS-096c990c8799869651d1。

^OBS-096c990c8799869651d1

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-ffbb3b5b783c905dbd95|OBS-ffbb3b5b783c905dbd95]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-7fda54e18de1f3e95490|OBS-7fda54e18de1f3e95490]]

### assets · 2025-09-30 · instant

**636.351 B USD**；状态：source_recorded。证据 ID：OBS-671bc1a116e5fbcdf94b。

^OBS-671bc1a116e5fbcdf94b

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`Assets`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### capex_cash · 2025-09-30 · quarter

**19.394 B USD**；状态：source_recorded。证据 ID：OBS-d87810abe25e989f3c39。

^OBS-d87810abe25e989f3c39

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### cash · 2025-09-30 · instant

**28.849 B USD**；状态：source_recorded。证据 ID：OBS-1383e50e9486218a9c1b。

^OBS-1383e50e9486218a9c1b

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### diluted_eps · 2025-09-30 · quarter

**3.720 USD/shares**；状态：source_recorded。证据 ID：OBS-414eed458d811f86517f。

^OBS-414eed458d811f86517f

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`EarningsPerShareDiluted`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### diluted_shares · 2025-09-30 · quarter

**7,466.00 M shares**；状态：source_recorded。证据 ID：OBS-5d0ce80907a62441a8fc。

^OBS-5d0ce80907a62441a8fc

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### equity · 2025-09-30 · instant

**363.076 B USD**；状态：source_recorded。证据 ID：OBS-79ae2f1471705bbfff0c。

^OBS-79ae2f1471705bbfff0c

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`StockholdersEquity`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### fcf_cash · 2025-09-30 · quarter

**25.663 B USD**；状态：calculation_checked。证据 ID：OBS-0781819490c3b66a5678。

^OBS-0781819490c3b66a5678

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-cd7ef6c53be0e05a2129|OBS-cd7ef6c53be0e05a2129]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-d87810abe25e989f3c39|OBS-d87810abe25e989f3c39]]

### gross_margin_pct · 2025-09-30 · quarter

**69.05%**；状态：calculation_checked。证据 ID：OBS-6c9da1f7fef3c689b50b。

^OBS-6c9da1f7fef3c689b50b

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`GrossProfit`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-99d6f63c6bbe3d10b064|OBS-99d6f63c6bbe3d10b064]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-e5b7995fdef7088b6a2f|OBS-e5b7995fdef7088b6a2f]]

### gross_profit · 2025-09-30 · quarter

**53.630 B USD**；状态：source_recorded。证据 ID：OBS-99d6f63c6bbe3d10b064。

^OBS-99d6f63c6bbe3d10b064

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`GrossProfit`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### inventory · 2025-09-30 · instant

**1.130 B USD**；状态：source_recorded。证据 ID：OBS-6f301797c1e4b6a6643f。

^OBS-6f301797c1e4b6a6643f

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`InventoryNet`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### liabilities · 2025-09-30 · instant

**273.275 B USD**；状态：source_recorded。证据 ID：OBS-ab038937f7398aba7371。

^OBS-ab038937f7398aba7371

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`Liabilities`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### net_income · 2025-09-30 · quarter

**27.747 B USD**；状态：source_recorded。证据 ID：OBS-f5a9b990df1dd7108f04。

^OBS-f5a9b990df1dd7108f04

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`NetIncomeLoss`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### operating_cash_flow · 2025-09-30 · quarter

**45.057 B USD**；状态：source_recorded。证据 ID：OBS-cd7ef6c53be0e05a2129。

^OBS-cd7ef6c53be0e05a2129

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### operating_income · 2025-09-30 · quarter

**37.961 B USD**；状态：source_recorded。证据 ID：OBS-7363b88fb841f2b440cb。

^OBS-7363b88fb841f2b440cb

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`OperatingIncomeLoss`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### operating_margin_pct · 2025-09-30 · quarter

**48.87%**；状态：calculation_checked。证据 ID：OBS-4f2ddc2e0c09cf7545ff。

^OBS-4f2ddc2e0c09cf7545ff

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`OperatingIncomeLoss`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-7363b88fb841f2b440cb|OBS-7363b88fb841f2b440cb]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-e5b7995fdef7088b6a2f|OBS-e5b7995fdef7088b6a2f]]

### receivables · 2025-09-30 · instant

**52.894 B USD**；状态：source_recorded。证据 ID：OBS-f605f9d11197ba0ddf1f。

^OBS-f605f9d11197ba0ddf1f

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`AccountsReceivableNetCurrent`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### revenue · 2025-09-30 · quarter

**77.673 B USD**；状态：source_recorded。证据 ID：OBS-e5b7995fdef7088b6a2f。

^OBS-e5b7995fdef7088b6a2f

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-25-256321。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2025-10-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312525256321/0001193125-25-256321-index.html

### assets · 2025-12-31 · instant

**665.302 B USD**；状态：source_recorded。证据 ID：OBS-0b0e90471b8ebe0fa3de。

^OBS-0b0e90471b8ebe0fa3de

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`Assets`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### capex_cash · 2025-12-31 · quarter

**29.876 B USD**；状态：source_recorded。证据 ID：OBS-c9ac8d7f8f3f8e37114b。

^OBS-c9ac8d7f8f3f8e37114b

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### cash · 2025-12-31 · instant

**24.296 B USD**；状态：source_recorded。证据 ID：OBS-57790134e034d99b0633。

^OBS-57790134e034d99b0633

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### diluted_eps · 2025-12-31 · quarter

**5.160 USD/shares**；状态：source_recorded。证据 ID：OBS-f4f54fff640b7d2eae0b。

^OBS-f4f54fff640b7d2eae0b

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`EarningsPerShareDiluted`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### diluted_shares · 2025-12-31 · quarter

**7,460.00 M shares**；状态：source_recorded。证据 ID：OBS-ef02877e46d45c36a782。

^OBS-ef02877e46d45c36a782

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### equity · 2025-12-31 · instant

**390.875 B USD**；状态：source_recorded。证据 ID：OBS-808534af7c099fe78364。

^OBS-808534af7c099fe78364

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`StockholdersEquity`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### fcf_cash · 2025-12-31 · quarter

**5.882 B USD**；状态：calculation_checked。证据 ID：OBS-8fd7c862242fc8b871e1。

^OBS-8fd7c862242fc8b871e1

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-c0dd61c76586474a4225|OBS-c0dd61c76586474a4225]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-c9ac8d7f8f3f8e37114b|OBS-c9ac8d7f8f3f8e37114b]]

### gross_margin_pct · 2025-12-31 · quarter

**68.04%**；状态：calculation_checked。证据 ID：OBS-bff6c3b380f01da6367a。

^OBS-bff6c3b380f01da6367a

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`GrossProfit`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-31b7db44bb97a887abcf|OBS-31b7db44bb97a887abcf]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-64464cfb7b846e4a3486|OBS-64464cfb7b846e4a3486]]

### gross_profit · 2025-12-31 · quarter

**55.295 B USD**；状态：source_recorded。证据 ID：OBS-31b7db44bb97a887abcf。

^OBS-31b7db44bb97a887abcf

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`GrossProfit`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### inventory · 2025-12-31 · instant

**1.059 B USD**；状态：source_recorded。证据 ID：OBS-51648ec38a33ec651386。

^OBS-51648ec38a33ec651386

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`InventoryNet`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### liabilities · 2025-12-31 · instant

**274.427 B USD**；状态：source_recorded。证据 ID：OBS-a85f2b2ccc1d778b8e71。

^OBS-a85f2b2ccc1d778b8e71

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`Liabilities`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### net_income · 2025-12-31 · quarter

**38.458 B USD**；状态：source_recorded。证据 ID：OBS-b5c3c26e9b071201a583。

^OBS-b5c3c26e9b071201a583

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`NetIncomeLoss`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### operating_cash_flow · 2025-12-31 · quarter

**35.758 B USD**；状态：source_recorded。证据 ID：OBS-c0dd61c76586474a4225。

^OBS-c0dd61c76586474a4225

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### operating_income · 2025-12-31 · quarter

**38.275 B USD**；状态：source_recorded。证据 ID：OBS-16c298876b19a5ccf9d4。

^OBS-16c298876b19a5ccf9d4

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`OperatingIncomeLoss`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### operating_margin_pct · 2025-12-31 · quarter

**47.09%**；状态：calculation_checked。证据 ID：OBS-8cce6b99429b0b928255。

^OBS-8cce6b99429b0b928255

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`OperatingIncomeLoss`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-16c298876b19a5ccf9d4|OBS-16c298876b19a5ccf9d4]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-64464cfb7b846e4a3486|OBS-64464cfb7b846e4a3486]]

### receivables · 2025-12-31 · instant

**56.535 B USD**；状态：source_recorded。证据 ID：OBS-f602a61733619299dcda。

^OBS-f602a61733619299dcda

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### revenue · 2025-12-31 · quarter

**81.273 B USD**；状态：source_recorded。证据 ID：OBS-64464cfb7b846e4a3486。

^OBS-64464cfb7b846e4a3486

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-027207。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-01-28。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526027207/0001193125-26-027207-index.html

### assets · 2026-03-31 · instant

**694.228 B USD**；状态：source_recorded。证据 ID：OBS-c4a7557f4a6f0e2c5c26。

^OBS-c4a7557f4a6f0e2c5c26

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`Assets`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### capex_cash · 2026-03-31 · quarter

**30.876 B USD**；状态：source_recorded。证据 ID：OBS-b825510cb96304c5a3b7。

^OBS-b825510cb96304c5a3b7

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### capex_cash · 2026-03-31 · ytd

**80.146 B USD**；状态：source_recorded。证据 ID：OBS-fd986fe0670d7a879bfd。

^OBS-fd986fe0670d7a879bfd

期间：2025-07-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### cash · 2026-03-31 · instant

**32.105 B USD**；状态：source_recorded。证据 ID：OBS-adf459f292af435bebb9。

^OBS-adf459f292af435bebb9

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### diluted_eps · 2026-03-31 · quarter

**4.270 USD/shares**；状态：source_recorded。证据 ID：OBS-355b0e040c20034bc046。

^OBS-355b0e040c20034bc046

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`EarningsPerShareDiluted`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### diluted_shares · 2026-03-31 · quarter

**7,445.00 M shares**；状态：source_recorded。证据 ID：OBS-7638faf8ab3e1bb27a31。

^OBS-7638faf8ab3e1bb27a31

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### equity · 2026-03-31 · instant

**414.367 B USD**；状态：source_recorded。证据 ID：OBS-22ec8f203ecc1c0c9430。

^OBS-22ec8f203ecc1c0c9430

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`StockholdersEquity`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### fcf_cash · 2026-03-31 · quarter

**15.803 B USD**；状态：calculation_checked。证据 ID：OBS-c3d0f54d9fadffd394da。

^OBS-c3d0f54d9fadffd394da

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-859ffa02de02ef75a2dd|OBS-859ffa02de02ef75a2dd]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-b825510cb96304c5a3b7|OBS-b825510cb96304c5a3b7]]

### gross_margin_pct · 2026-03-31 · quarter

**67.63%**；状态：calculation_checked。证据 ID：OBS-b6339d28edeed67ca169。

^OBS-b6339d28edeed67ca169

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`GrossProfit`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-a4873b6b2f702ebebb41|OBS-a4873b6b2f702ebebb41]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-219289191051d43411fa|OBS-219289191051d43411fa]]

### gross_profit · 2026-03-31 · quarter

**56.058 B USD**；状态：source_recorded。证据 ID：OBS-a4873b6b2f702ebebb41。

^OBS-a4873b6b2f702ebebb41

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`GrossProfit`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### gross_profit · 2026-03-31 · ytd

**164.983 B USD**；状态：source_recorded。证据 ID：OBS-a7014d34a2423817cfe4。

^OBS-a7014d34a2423817cfe4

期间：2025-07-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`GrossProfit`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### inventory · 2026-03-31 · instant

**1.219 B USD**；状态：source_recorded。证据 ID：OBS-90fa9b5c32dd20cecf83。

^OBS-90fa9b5c32dd20cecf83

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`InventoryNet`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### liabilities · 2026-03-31 · instant

**279.861 B USD**；状态：source_recorded。证据 ID：OBS-ef14a52778035b81e102。

^OBS-ef14a52778035b81e102

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`Liabilities`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### net_income · 2026-03-31 · quarter

**31.778 B USD**；状态：source_recorded。证据 ID：OBS-8a2b5d0816b594c99393。

^OBS-8a2b5d0816b594c99393

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### net_income · 2026-03-31 · ytd

**97.983 B USD**；状态：source_recorded。证据 ID：OBS-6825a90e962fda040dcb。

^OBS-6825a90e962fda040dcb

期间：2025-07-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### operating_cash_flow · 2026-03-31 · quarter

**46.679 B USD**；状态：source_recorded。证据 ID：OBS-859ffa02de02ef75a2dd。

^OBS-859ffa02de02ef75a2dd

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### operating_cash_flow · 2026-03-31 · ytd

**127.494 B USD**；状态：source_recorded。证据 ID：OBS-6ad591972ae51ad4f864。

^OBS-6ad591972ae51ad4f864

期间：2025-07-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### operating_income · 2026-03-31 · quarter

**38.398 B USD**；状态：source_recorded。证据 ID：OBS-ec5c702cebef4fa716ed。

^OBS-ec5c702cebef4fa716ed

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`OperatingIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### operating_income · 2026-03-31 · ytd

**114.634 B USD**；状态：source_recorded。证据 ID：OBS-34d5d31689ef9108c13d。

^OBS-34d5d31689ef9108c13d

期间：2025-07-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`OperatingIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### operating_margin_pct · 2026-03-31 · quarter

**46.33%**；状态：calculation_checked。证据 ID：OBS-bef7e5523f7685c20f05。

^OBS-bef7e5523f7685c20f05

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`OperatingIncomeLoss`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-ec5c702cebef4fa716ed|OBS-ec5c702cebef4fa716ed]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-219289191051d43411fa|OBS-219289191051d43411fa]]

### receivables · 2026-03-31 · instant

**60.041 B USD**；状态：source_recorded。证据 ID：OBS-6a9bb3400442f72b5545。

^OBS-6a9bb3400442f72b5545

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### revenue · 2026-03-31 · quarter

**82.886 B USD**；状态：source_recorded。证据 ID：OBS-219289191051d43411fa。

^OBS-219289191051d43411fa

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### revenue · 2026-03-31 · ytd

**241.832 B USD**；状态：source_recorded。证据 ID：OBS-ffbb300aadd9c39fa026。

^OBS-ffbb300aadd9c39fa026

期间：2025-07-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-191507。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-04-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526191507/0001193125-26-191507-index.html

### assets · 2026-06-30 · instant

**758.376 B USD**；状态：source_recorded。证据 ID：OBS-ddf311fc796739b1056b。

^OBS-ddf311fc796739b1056b

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`Assets`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### capex_cash · 2026-06-30 · annual

**115.948 B USD**；状态：source_recorded。证据 ID：OBS-943c26b87f45de2060b0。

^OBS-943c26b87f45de2060b0

期间：2025-07-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### capex_cash · 2026-06-30 · quarter

**35.802 B USD**；状态：needs_review。证据 ID：OBS-3a244b711852c27cf3c7。

^OBS-3a244b711852c27cf3c7

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`PaymentsToAcquirePropertyPlantAndEquipment`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-943c26b87f45de2060b0|OBS-943c26b87f45de2060b0]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-fd986fe0670d7a879bfd|OBS-fd986fe0670d7a879bfd]]

### cash · 2026-06-30 · instant

**20.935 B USD**；状态：source_recorded。证据 ID：OBS-6d47d72edf5708f3672b。

^OBS-6d47d72edf5708f3672b

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`CashAndCashEquivalentsAtCarryingValue`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### equity · 2026-06-30 · instant

**442.387 B USD**；状态：source_recorded。证据 ID：OBS-2eee0441c84b89139010。

^OBS-2eee0441c84b89139010

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`StockholdersEquity`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### fcf_cash · 2026-06-30 · quarter

**19.639 B USD**；状态：needs_review。证据 ID：OBS-7cfb0623c428e06a3aa9。

^OBS-7cfb0623c428e06a3aa9

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`operating_cash_flow - capex_cash`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-458a650cacd334b8d295|OBS-458a650cacd334b8d295]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-3a244b711852c27cf3c7|OBS-3a244b711852c27cf3c7]]

### gross_margin_pct · 2026-06-30 · quarter

**67.20%**；状态：needs_review。证据 ID：OBS-7b19b336660bdb684632。

^OBS-7b19b336660bdb684632

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`GrossProfit`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`gross_profit / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-450ce0c5dfe38360bd0a|OBS-450ce0c5dfe38360bd0a]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-a13d17e6136d567b853e|OBS-a13d17e6136d567b853e]]

### gross_profit · 2026-06-30 · annual

**225.465 B USD**；状态：source_recorded。证据 ID：OBS-060bb4115e6fe696bb74。

^OBS-060bb4115e6fe696bb74

期间：2025-07-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`GrossProfit`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### gross_profit · 2026-06-30 · quarter

**60.482 B USD**；状态：needs_review。证据 ID：OBS-450ce0c5dfe38360bd0a。

^OBS-450ce0c5dfe38360bd0a

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`GrossProfit`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-060bb4115e6fe696bb74|OBS-060bb4115e6fe696bb74]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-a7014d34a2423817cfe4|OBS-a7014d34a2423817cfe4]]

### inventory · 2026-06-30 · instant

**1.397 B USD**；状态：source_recorded。证据 ID：OBS-2df2cce2b299f80aca49。

^OBS-2df2cce2b299f80aca49

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`InventoryNet`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### liabilities · 2026-06-30 · instant

**315.989 B USD**；状态：source_recorded。证据 ID：OBS-31f5accb03af79441413。

^OBS-31f5accb03af79441413

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`Liabilities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### net_income · 2026-06-30 · annual

**133.749 B USD**；状态：source_recorded。证据 ID：OBS-e02ae17b203ef757e41b。

^OBS-e02ae17b203ef757e41b

期间：2025-07-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### net_income · 2026-06-30 · quarter

**35.766 B USD**；状态：needs_review。证据 ID：OBS-df7e3b543aec3c679560。

^OBS-df7e3b543aec3c679560

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-e02ae17b203ef757e41b|OBS-e02ae17b203ef757e41b]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-6825a90e962fda040dcb|OBS-6825a90e962fda040dcb]]

### operating_cash_flow · 2026-06-30 · annual

**182.935 B USD**；状态：source_recorded。证据 ID：OBS-4d5b27f066e8624abe03。

^OBS-4d5b27f066e8624abe03

期间：2025-07-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### operating_cash_flow · 2026-06-30 · quarter

**55.441 B USD**；状态：needs_review。证据 ID：OBS-458a650cacd334b8d295。

^OBS-458a650cacd334b8d295

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`NetCashProvidedByUsedInOperatingActivities`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-4d5b27f066e8624abe03|OBS-4d5b27f066e8624abe03]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-6ad591972ae51ad4f864|OBS-6ad591972ae51ad4f864]]

### operating_income · 2026-06-30 · annual

**155.237 B USD**；状态：source_recorded。证据 ID：OBS-2b5de543ec7079072c02。

^OBS-2b5de543ec7079072c02

期间：2025-07-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`OperatingIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### operating_income · 2026-06-30 · quarter

**40.603 B USD**；状态：needs_review。证据 ID：OBS-e9751ebea1090907674b。

^OBS-e9751ebea1090907674b

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`OperatingIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-2b5de543ec7079072c02|OBS-2b5de543ec7079072c02]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-34d5d31689ef9108c13d|OBS-34d5d31689ef9108c13d]]

### operating_margin_pct · 2026-06-30 · quarter

**45.11%**；状态：needs_review。证据 ID：OBS-ec3df9fc3d520ddc2982。

^OBS-ec3df9fc3d520ddc2982

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`OperatingIncomeLoss`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`operating_income / revenue * 100`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-e9751ebea1090907674b|OBS-e9751ebea1090907674b]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-a13d17e6136d567b853e|OBS-a13d17e6136d567b853e]]

### receivables · 2026-06-30 · instant

**80.876 B USD**；状态：source_recorded。证据 ID：OBS-c4c136af31ae20cead8d。

^OBS-c4c136af31ae20cead8d

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`AccountsReceivableNetCurrent`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### revenue · 2026-06-30 · annual

**331.839 B USD**；状态：source_recorded。证据 ID：OBS-8c56589a315d8e6f96c5。

^OBS-8c56589a315d8e6f96c5

期间：2025-07-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html

### revenue · 2026-06-30 · quarter

**90.007 B USD**；状态：needs_review。证据 ID：OBS-a13d17e6136d567b853e。

^OBS-a13d17e6136d567b853e

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-e518cf203523282fcc91b24d|SRC-e518cf203523282fcc91b24d]]；申报编号：0001193125-26-323660。
字段：`RevenueFromContractWithCustomerExcludingAssessedTax`；申报日期：2026-07-29。
原始申报链接：https://www.sec.gov/Archives/edgar/data/789019/000119312526323660/0001193125-26-323660-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-8c56589a315d8e6f96c5|OBS-8c56589a315d8e6f96c5]]、[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence#^OBS-ffbb300aadd9c39fa026|OBS-ffbb300aadd9c39fa026]]
