---
title: "JPM — 本次数据与原文证据（运行 20261019T070744Z-4e0381）"
tags: [reports, run-history, evidence]
created: 2026-10-19
updated: 2026-10-19
source: "引擎运行 20261019T070744Z-4e0381 的数据快照 12_Data/Companies/JPM/20261019T070744Z-4e0381.json"
---
# JPM — 本次数据与原文证据

资料截止：2026-10-19T07:07:44+00:00。

[[14_Reports/Run History/20261019T070744Z-4e0381/JPM/Brief|本次简报]] · [[04_Companies/JPM/Company Profile|JPM 档案]] · [[04_Companies/JPM/Latest Brief|最新简报]] · [[04_Companies/JPM/JPM - Data History|八季数据]] · [[04_Companies/JPM/Evidence Index|证据索引]] · [[04_Companies/JPM/Current Thesis|当前判断]] · [[04_Companies/JPM/Thesis History|判断历史]]

本页是保存快照的阅读视图；链接表示引用或计算依赖，不表示独立验证或因果关系。
包含最近八季的观察值，以及计算所需的较早输入。后续运行各自生成证据页，旧简报不会跳到新快照。

## 原始快照
[[12_Data/Companies/JPM/20261019T070744Z-4e0381.json|JSON 快照（外部编辑器）]]

## 财报原文
- [[13_Sources/Records/SRC-9c13f4e336126491246ce357|10-Q]]；期间／事件日：2026-06-30
  提取正文：[[13_Sources/Raw/SRC-9c13f4e336126491246ce357|SRC-9c13f4e336126491246ce357 正文]]
- [[13_Sources/Records/SRC-821ba21da94c21df60d729fd|10-K]]；期间／事件日：2025-12-31
  提取正文：[[13_Sources/Raw/SRC-821ba21da94c21df60d729fd|SRC-821ba21da94c21df60d729fd 正文]]
- [[13_Sources/Records/SRC-0d22ae2e56e5e9209f93b78c|earnings_release_8K]]；期间／事件日：2026-10-13
  提取正文：[[13_Sources/Raw/SRC-0d22ae2e56e5e9209f93b78c|SRC-0d22ae2e56e5e9209f93b78c 正文]]

## 数字与计算依赖

### assets · 2024-09-30 · instant

**4,210.048 B USD**；状态：source_recorded。证据 ID：OBS-d2cce7de76c25a75910b。

^OBS-d2cce7de76c25a75910b

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`Assets`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### bank_net_interest_income · 2024-09-30 · quarter

**23.405 B USD**；状态：source_recorded。证据 ID：OBS-b3e5239d27564696100d。

^OBS-b3e5239d27564696100d

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`InterestIncomeExpenseNet`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### bank_net_interest_income · 2024-09-30 · ytd

**69.233 B USD**；状态：source_recorded。证据 ID：OBS-29bd81396c9595a55a94。

^OBS-29bd81396c9595a55a94

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`InterestIncomeExpenseNet`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### diluted_eps · 2024-09-30 · quarter

**4.370 USD/shares**；状态：source_recorded。证据 ID：OBS-80c31152aa7c8fa909fb。

^OBS-80c31152aa7c8fa909fb

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`EarningsPerShareDiluted`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### diluted_shares · 2024-09-30 · quarter

**2,865.90 M shares**；状态：source_recorded。证据 ID：OBS-c086448da05a9062003c。

^OBS-c086448da05a9062003c

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### equity · 2024-09-30 · instant

**345.836 B USD**；状态：source_recorded。证据 ID：OBS-32ceb9e03a005ab4409f。

^OBS-32ceb9e03a005ab4409f

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`StockholdersEquity`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### liabilities · 2024-09-30 · instant

**3,864.212 B USD**；状态：source_recorded。证据 ID：OBS-67fe7f92a133cd5095d7。

^OBS-67fe7f92a133cd5095d7

期间：时点 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0000019617-24-000611。
字段：`Liabilities`；申报日期：2024-10-30。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000001961724000611/0000019617-24-000611-index.html

### net_income · 2024-09-30 · quarter

**12.898 B USD**；状态：source_recorded。证据 ID：OBS-30c61d796da724ffb911。

^OBS-30c61d796da724ffb911

期间：2024-07-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`NetIncomeLoss`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### net_income · 2024-09-30 · ytd

**44.466 B USD**；状态：source_recorded。证据 ID：OBS-0f4139a136998d9852b7。

^OBS-0f4139a136998d9852b7

期间：2024-01-01 → 2024-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`NetIncomeLoss`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### assets · 2024-12-31 · instant

**4,002.814 B USD**；状态：source_recorded。证据 ID：OBS-c896d403158e801a503a。

^OBS-c896d403158e801a503a

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`Assets`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html

### bank_net_interest_income · 2024-12-31 · annual

**92.583 B USD**；状态：source_recorded。证据 ID：OBS-b23e95d8e62656e836e7。

^OBS-b23e95d8e62656e836e7

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`InterestIncomeExpenseNet`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html

### bank_net_interest_income · 2024-12-31 · quarter

**23.350 B USD**；状态：needs_review。证据 ID：OBS-e085b39f8a8fbbb433f8。

^OBS-e085b39f8a8fbbb433f8

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`InterestIncomeExpenseNet`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/JPM/Evidence#^OBS-b23e95d8e62656e836e7|OBS-b23e95d8e62656e836e7]]、[[14_Reports/Run History/20261019T070744Z-4e0381/JPM/Evidence#^OBS-29bd81396c9595a55a94|OBS-29bd81396c9595a55a94]]

### equity · 2024-12-31 · instant

**344.758 B USD**；状态：source_recorded。证据 ID：OBS-5114d50406148b3c0070。

^OBS-5114d50406148b3c0070

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`StockholdersEquity`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html

### liabilities · 2024-12-31 · instant

**3,658.056 B USD**；状态：source_recorded。证据 ID：OBS-3f7da6cb660d5ad5b25d。

^OBS-3f7da6cb660d5ad5b25d

期间：时点 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`Liabilities`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html

### net_income · 2024-12-31 · annual

**58.471 B USD**；状态：source_recorded。证据 ID：OBS-d94b12208d6c741791db。

^OBS-d94b12208d6c741791db

期间：2024-01-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`NetIncomeLoss`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html

### net_income · 2024-12-31 · quarter

**14.005 B USD**；状态：needs_review。证据 ID：OBS-af2b95f7e0ae452e85d6。

^OBS-af2b95f7e0ae452e85d6

期间：2024-10-01 → 2024-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`NetIncomeLoss`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/JPM/Evidence#^OBS-d94b12208d6c741791db|OBS-d94b12208d6c741791db]]、[[14_Reports/Run History/20261019T070744Z-4e0381/JPM/Evidence#^OBS-0f4139a136998d9852b7|OBS-0f4139a136998d9852b7]]

### assets · 2025-03-31 · instant

**4,357.856 B USD**；状态：source_recorded。证据 ID：OBS-bca049a79a2c772f0da7。

^OBS-bca049a79a2c772f0da7

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`Assets`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html

### bank_net_interest_income · 2025-03-31 · quarter

**23.273 B USD**；状态：source_recorded。证据 ID：OBS-649b0ed6ac7a9248597b。

^OBS-649b0ed6ac7a9248597b

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`InterestIncomeExpenseNet`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html

### diluted_eps · 2025-03-31 · quarter

**5.070 USD/shares**；状态：source_recorded。证据 ID：OBS-9d07c65676faff31b605。

^OBS-9d07c65676faff31b605

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`EarningsPerShareDiluted`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html

### diluted_shares · 2025-03-31 · quarter

**2,824.30 M shares**；状态：source_recorded。证据 ID：OBS-7bdf7f7586e53de00042。

^OBS-7bdf7f7586e53de00042

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html

### equity · 2025-03-31 · instant

**351.420 B USD**；状态：source_recorded。证据 ID：OBS-51e2607983002c1dce3c。

^OBS-51e2607983002c1dce3c

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`StockholdersEquity`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html

### liabilities · 2025-03-31 · instant

**4,006.436 B USD**；状态：source_recorded。证据 ID：OBS-4ea67c0182d8931a58c5。

^OBS-4ea67c0182d8931a58c5

期间：时点 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0000019617-25-000421。
字段：`Liabilities`；申报日期：2025-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000001961725000421/0000019617-25-000421-index.html

### net_income · 2025-03-31 · quarter

**14.643 B USD**；状态：source_recorded。证据 ID：OBS-ea41510413968105ebde。

^OBS-ea41510413968105ebde

期间：2025-01-01 → 2025-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`NetIncomeLoss`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html

### assets · 2025-06-30 · instant

**4,552.482 B USD**；状态：source_recorded。证据 ID：OBS-8080dd2088d2ac3fbe88。

^OBS-8080dd2088d2ac3fbe88

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`Assets`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### bank_net_interest_income · 2025-06-30 · quarter

**23.209 B USD**；状态：source_recorded。证据 ID：OBS-06584d4737d348164e15。

^OBS-06584d4737d348164e15

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`InterestIncomeExpenseNet`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### diluted_eps · 2025-06-30 · quarter

**5.240 USD/shares**；状态：source_recorded。证据 ID：OBS-ef47c8d850c6af909e32。

^OBS-ef47c8d850c6af909e32

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`EarningsPerShareDiluted`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### diluted_shares · 2025-06-30 · quarter

**2,793.70 M shares**；状态：source_recorded。证据 ID：OBS-7a1f6c01dcb3e8bb5f24。

^OBS-7a1f6c01dcb3e8bb5f24

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### equity · 2025-06-30 · instant

**356.924 B USD**；状态：source_recorded。证据 ID：OBS-ef2faf32031d9ad3946b。

^OBS-ef2faf32031d9ad3946b

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`StockholdersEquity`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### liabilities · 2025-06-30 · instant

**4,195.558 B USD**；状态：source_recorded。证据 ID：OBS-7517f62161f3d3ae9bd5。

^OBS-7517f62161f3d3ae9bd5

期间：时点 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0000019617-25-000615。
字段：`Liabilities`；申报日期：2025-08-05。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000001961725000615/0000019617-25-000615-index.html

### net_income · 2025-06-30 · quarter

**14.987 B USD**；状态：source_recorded。证据 ID：OBS-bd93dcac364951f5ec95。

^OBS-bd93dcac364951f5ec95

期间：2025-04-01 → 2025-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`NetIncomeLoss`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### assets · 2025-09-30 · instant

**4,560.205 B USD**；状态：source_recorded。证据 ID：OBS-e34ea28b429deeeb63cd。

^OBS-e34ea28b429deeeb63cd

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`Assets`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### bank_net_interest_income · 2025-09-30 · quarter

**23.966 B USD**；状态：source_recorded。证据 ID：OBS-31e043458b5e9e166fd7。

^OBS-31e043458b5e9e166fd7

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`InterestIncomeExpenseNet`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### bank_net_interest_income · 2025-09-30 · ytd

**70.448 B USD**；状态：source_recorded。证据 ID：OBS-341fd6a1b61328855d14。

^OBS-341fd6a1b61328855d14

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`InterestIncomeExpenseNet`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### diluted_eps · 2025-09-30 · quarter

**5.070 USD/shares**；状态：source_recorded。证据 ID：OBS-8667cb74eeba4b38f668。

^OBS-8667cb74eeba4b38f668

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`EarningsPerShareDiluted`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### diluted_shares · 2025-09-30 · quarter

**2,767.60 M shares**；状态：source_recorded。证据 ID：OBS-23b75046e18836c77921。

^OBS-23b75046e18836c77921

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### equity · 2025-09-30 · instant

**360.212 B USD**；状态：source_recorded。证据 ID：OBS-989727197a51ffc7b393。

^OBS-989727197a51ffc7b393

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`StockholdersEquity`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### liabilities · 2025-09-30 · instant

**4,199.993 B USD**；状态：source_recorded。证据 ID：OBS-4b4917a735aa2f2f39be。

^OBS-4b4917a735aa2f2f39be

期间：时点 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`Liabilities`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### net_income · 2025-09-30 · quarter

**14.393 B USD**；状态：source_recorded。证据 ID：OBS-85d8f2f5c74c5b0ccd09。

^OBS-85d8f2f5c74c5b0ccd09

期间：2025-07-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`NetIncomeLoss`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### net_income · 2025-09-30 · ytd

**44.023 B USD**；状态：source_recorded。证据 ID：OBS-af7128df0a0e92f05015。

^OBS-af7128df0a0e92f05015

期间：2025-01-01 → 2025-09-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-25-048859。
字段：`NetIncomeLoss`；申报日期：2025-11-04。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828025048859/0001628280-25-048859-index.html

### assets · 2025-12-31 · instant

**4,424.900 B USD**；状态：source_recorded。证据 ID：OBS-86e0a60e6e542795482e。

^OBS-86e0a60e6e542795482e

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`Assets`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### bank_net_interest_income · 2025-12-31 · annual

**95.443 B USD**；状态：source_recorded。证据 ID：OBS-f8d93899972f01a9a08b。

^OBS-f8d93899972f01a9a08b

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`InterestIncomeExpenseNet`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html

### bank_net_interest_income · 2025-12-31 · quarter

**24.995 B USD**；状态：needs_review。证据 ID：OBS-a649c52aa5d6dadd646e。

^OBS-a649c52aa5d6dadd646e

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`InterestIncomeExpenseNet`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/JPM/Evidence#^OBS-f8d93899972f01a9a08b|OBS-f8d93899972f01a9a08b]]、[[14_Reports/Run History/20261019T070744Z-4e0381/JPM/Evidence#^OBS-341fd6a1b61328855d14|OBS-341fd6a1b61328855d14]]

### equity · 2025-12-31 · instant

**362.438 B USD**；状态：source_recorded。证据 ID：OBS-d0660bfce3a7afdf06f9。

^OBS-d0660bfce3a7afdf06f9

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`StockholdersEquity`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### liabilities · 2025-12-31 · instant

**4,062.462 B USD**；状态：source_recorded。证据 ID：OBS-90d15c6ffaeaeeacd8c0。

^OBS-90d15c6ffaeaeeacd8c0

期间：时点 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`Liabilities`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### net_income · 2025-12-31 · annual

**57.048 B USD**；状态：source_recorded。证据 ID：OBS-12921d5bfe66f164ea06。

^OBS-12921d5bfe66f164ea06

期间：2025-01-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`NetIncomeLoss`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html

### net_income · 2025-12-31 · quarter

**13.025 B USD**；状态：needs_review。证据 ID：OBS-890d1bee9f91d603f803。

^OBS-890d1bee9f91d603f803

期间：2025-10-01 → 2025-12-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-008131。
字段：`NetIncomeLoss`；申报日期：2026-02-13。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026008131/0001628280-26-008131-index.html
计算：`current_ytd - previous_ytd`；输入：[[14_Reports/Run History/20261019T070744Z-4e0381/JPM/Evidence#^OBS-12921d5bfe66f164ea06|OBS-12921d5bfe66f164ea06]]、[[14_Reports/Run History/20261019T070744Z-4e0381/JPM/Evidence#^OBS-af7128df0a0e92f05015|OBS-af7128df0a0e92f05015]]

### assets · 2026-03-31 · instant

**4,900.475 B USD**；状态：source_recorded。证据 ID：OBS-09087d488474cab9b787。

^OBS-09087d488474cab9b787

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`Assets`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html

### bank_net_interest_income · 2026-03-31 · quarter

**25.366 B USD**；状态：source_recorded。证据 ID：OBS-44cce072815678523dab。

^OBS-44cce072815678523dab

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`InterestIncomeExpenseNet`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html

### diluted_eps · 2026-03-31 · quarter

**5.940 USD/shares**；状态：source_recorded。证据 ID：OBS-d7b3ef2c3d2191ec2539。

^OBS-d7b3ef2c3d2191ec2539

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`EarningsPerShareDiluted`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html

### diluted_shares · 2026-03-31 · quarter

**2,720.20 M shares**；状态：source_recorded。证据 ID：OBS-c494f1a7106f23559d66。

^OBS-c494f1a7106f23559d66

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html

### equity · 2026-03-31 · instant

**364.038 B USD**；状态：source_recorded。证据 ID：OBS-fd5f98e34534d6a1a86a。

^OBS-fd5f98e34534d6a1a86a

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`StockholdersEquity`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html

### liabilities · 2026-03-31 · instant

**4,536.437 B USD**；状态：source_recorded。证据 ID：OBS-298e9eb124aa11fe03f9。

^OBS-298e9eb124aa11fe03f9

期间：时点 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`Liabilities`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html

### net_income · 2026-03-31 · quarter

**16.494 B USD**；状态：source_recorded。证据 ID：OBS-5ece213e7e292cb1ba59。

^OBS-5ece213e7e292cb1ba59

期间：2026-01-01 → 2026-03-31；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-029344。
字段：`NetIncomeLoss`；申报日期：2026-05-01。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026029344/0001628280-26-029344-index.html

### assets · 2026-06-30 · instant

**5,015.069 B USD**；状态：source_recorded。证据 ID：OBS-99836d208994e24cf3f6。

^OBS-99836d208994e24cf3f6

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`Assets`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### bank_net_interest_income · 2026-06-30 · quarter

**25.511 B USD**；状态：source_recorded。证据 ID：OBS-0833dfd44f48b9337be2。

^OBS-0833dfd44f48b9337be2

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`InterestIncomeExpenseNet`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### diluted_eps · 2026-06-30 · quarter

**7.700 USD/shares**；状态：source_recorded。证据 ID：OBS-d62d1d7cc61a2fcea761。

^OBS-d62d1d7cc61a2fcea761

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`EarningsPerShareDiluted`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### diluted_shares · 2026-06-30 · quarter

**2,694.20 M shares**；状态：source_recorded。证据 ID：OBS-30a08f6b88498131036b。

^OBS-30a08f6b88498131036b

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`WeightedAverageNumberOfDilutedSharesOutstanding`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### equity · 2026-06-30 · instant

**374.598 B USD**；状态：source_recorded。证据 ID：OBS-0b66e0414b93077d9516。

^OBS-0b66e0414b93077d9516

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`StockholdersEquity`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### liabilities · 2026-06-30 · instant

**4,640.471 B USD**；状态：source_recorded。证据 ID：OBS-815744ab0454a6225d3f。

^OBS-815744ab0454a6225d3f

期间：时点 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`Liabilities`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html

### net_income · 2026-06-30 · quarter

**21.155 B USD**；状态：source_recorded。证据 ID：OBS-f5dd626f34939c6cabce。

^OBS-f5dd626f34939c6cabce

期间：2026-04-01 → 2026-06-30；口径：US-GAAP。
来源：[[13_Sources/Records/SRC-7f583d5afbbe74d9038418ff|SRC-7f583d5afbbe74d9038418ff]]；申报编号：0001628280-26-054343。
字段：`NetIncomeLoss`；申报日期：2026-08-06。
原始申报链接：https://www.sec.gov/Archives/edgar/data/19617/000162828026054343/0001628280-26-054343-index.html
