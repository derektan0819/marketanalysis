---
title: "Reports MOC — 报告与运行记录"
tags: [index, moc]
created: 2026-10-27
updated: 2026-10-27
source: "自动整理：完整列出 14_Reports 的全部文件（2026-10-27）"
---

# Reports MOC — 报告与运行记录

[[00_Index/Master Index|总索引]] · [[HOME|首页]]

本文件夹共 32 个文件，其中笔记 32 篇。以下按路径完整列出，笔记显示标题。

## 先读

- [[14_Reports/Reports Guide|Report Archive]]
- [[14_Reports/Run History Index|运行与报告历史]]

## 笔记

- [[14_Reports/Reports Guide|Report Archive]]
- [[14_Reports/Run History Index|运行与报告历史]]

## Run History/20261019T070744Z-4e0381/AMZN

- [[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Brief|AMZN — 一页研究简报]]
- [[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence|AMZN — 本次数据与原文证据（运行 20261019T070744Z-4e0381）]]

## Run History/20261019T070744Z-4e0381/GOOGL

- [[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Brief|GOOGL — 一页研究简报]]
- [[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence|GOOGL — 本次数据与原文证据（运行 20261019T070744Z-4e0381）]]

## Run History/20261019T070744Z-4e0381/JPM

- [[14_Reports/Run History/20261019T070744Z-4e0381/JPM/Brief|JPM — 一页研究简报]]
- [[14_Reports/Run History/20261019T070744Z-4e0381/JPM/Evidence|JPM — 本次数据与原文证据（运行 20261019T070744Z-4e0381）]]

## Run History/20261019T070744Z-4e0381/MSFT

- [[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Brief|MSFT — 一页研究简报]]
- [[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence|MSFT — 本次数据与原文证据（运行 20261019T070744Z-4e0381）]]

## Run History/20261019T070744Z-4e0381/NVDA

- [[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Brief|NVDA — 一页研究简报]]
- [[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence|NVDA — 本次数据与原文证据（运行 20261019T070744Z-4e0381）]]

## Run History/20261019T071245Z-e92a54/AMZN

- [[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Brief|AMZN — 一页研究简报]]
- [[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence|AMZN — 本次数据与原文证据（运行 20261019T071245Z-e92a54）]]

## Run History/20261019T071245Z-e92a54/GOOGL

- [[14_Reports/Run History/20261019T071245Z-e92a54/GOOGL/Brief|GOOGL — 一页研究简报]]
- [[14_Reports/Run History/20261019T071245Z-e92a54/GOOGL/Evidence|GOOGL — 本次数据与原文证据（运行 20261019T071245Z-e92a54）]]

## Run History/20261019T071245Z-e92a54/JPM

- [[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Brief|JPM — 一页研究简报]]
- [[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Evidence|JPM — 本次数据与原文证据（运行 20261019T071245Z-e92a54）]]

## Run History/20261019T071245Z-e92a54/MSFT

- [[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Brief|MSFT — 一页研究简报]]
- [[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence|MSFT — 本次数据与原文证据（运行 20261019T071245Z-e92a54）]]

## Run History/20261019T071245Z-e92a54/NVDA

- [[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Brief|NVDA — 一页研究简报]]
- [[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence|NVDA — 本次数据与原文证据（运行 20261019T071245Z-e92a54）]]

## Run History/20261019T071658Z-b240c2/AMZN

- [[14_Reports/Run History/20261019T071658Z-b240c2/AMZN/Brief|AMZN — 一页研究简报]]
- [[14_Reports/Run History/20261019T071658Z-b240c2/AMZN/Evidence|AMZN — 本次数据与原文证据（运行 20261019T071658Z-b240c2）]]

## Run History/20261019T071658Z-b240c2/GOOGL

- [[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Brief|GOOGL — 一页研究简报]]
- [[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence|GOOGL — 本次数据与原文证据（运行 20261019T071658Z-b240c2）]]

## Run History/20261019T071658Z-b240c2/JPM

- [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Brief|JPM — 一页研究简报]]
- [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence|JPM — 本次数据与原文证据（运行 20261019T071658Z-b240c2）]]

## Run History/20261019T071658Z-b240c2/MSFT

- [[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Brief|MSFT — 一页研究简报]]
- [[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Evidence|MSFT — 本次数据与原文证据（运行 20261019T071658Z-b240c2）]]

## Run History/20261019T071658Z-b240c2/NVDA

- [[14_Reports/Run History/20261019T071658Z-b240c2/NVDA/Brief|NVDA — 一页研究简报]]
- [[14_Reports/Run History/20261019T071658Z-b240c2/NVDA/Evidence|NVDA — 本次数据与原文证据（运行 20261019T071658Z-b240c2）]]
