---
title: "运行与报告历史"
tags: [reports, index]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# 运行与报告历史

[[Today Dashboard|今日看板]] · [[04_Companies/Company Research Index|公司索引]]

每次简报的证据固定指向同一次快照。这里只补充导航，没有重新抓取数据，也没有补写历史预测。

## 20261019T071658Z-b240c2

资料截止：2026-10-19T07:16:58+00:00

- [[14_Reports/Run History/20261019T071658Z-b240c2/NVDA/Brief|NVDA 简报]] · [[14_Reports/Run History/20261019T071658Z-b240c2/NVDA/Evidence|本次证据]]
- [[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Brief|MSFT 简报]] · [[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Evidence|本次证据]]
- [[14_Reports/Run History/20261019T071658Z-b240c2/AMZN/Brief|AMZN 简报]] · [[14_Reports/Run History/20261019T071658Z-b240c2/AMZN/Evidence|本次证据]]
- [[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Brief|GOOGL 简报]] · [[14_Reports/Run History/20261019T071658Z-b240c2/GOOGL/Evidence|本次证据]]
- [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Brief|JPM 简报]] · [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence|本次证据]]

[[12_Data/Runs/20261019T071658Z-b240c2.json|运行状态与异常 JSON]]

## 20261019T071245Z-e92a54

资料截止：2026-10-19T07:12:45+00:00

- [[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Brief|NVDA 简报]] · [[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence|本次证据]]
- [[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Brief|MSFT 简报]] · [[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence|本次证据]]
- [[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Brief|AMZN 简报]] · [[14_Reports/Run History/20261019T071245Z-e92a54/AMZN/Evidence|本次证据]]
- [[14_Reports/Run History/20261019T071245Z-e92a54/GOOGL/Brief|GOOGL 简报]] · [[14_Reports/Run History/20261019T071245Z-e92a54/GOOGL/Evidence|本次证据]]
- [[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Brief|JPM 简报]] · [[14_Reports/Run History/20261019T071245Z-e92a54/JPM/Evidence|本次证据]]

[[12_Data/Runs/20261019T071245Z-e92a54.json|运行状态与异常 JSON]]

## 20261019T070744Z-4e0381

资料截止：2026-10-19T07:07:44+00:00

- [[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Brief|NVDA 简报]] · [[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence|本次证据]]
- [[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Brief|MSFT 简报]] · [[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence|本次证据]]
- [[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Brief|AMZN 简报]] · [[14_Reports/Run History/20261019T070744Z-4e0381/AMZN/Evidence|本次证据]]
- [[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Brief|GOOGL 简报]] · [[14_Reports/Run History/20261019T070744Z-4e0381/GOOGL/Evidence|本次证据]]
- [[14_Reports/Run History/20261019T070744Z-4e0381/JPM/Brief|JPM 简报]] · [[14_Reports/Run History/20261019T070744Z-4e0381/JPM/Evidence|本次证据]]

[[12_Data/Runs/20261019T070744Z-4e0381.json|运行状态与异常 JSON]]
