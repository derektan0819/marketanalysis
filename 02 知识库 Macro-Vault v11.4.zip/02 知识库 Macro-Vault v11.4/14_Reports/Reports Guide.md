---
title: "Report Archive"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [reports, archive]
---
# Report Archive

Store generated reports here only if that is the chosen archive convention; alternatively keep company-specific reports in `04_Companies`. Pick one canonical location and do not duplicate silently.

Recommended lifecycle:
1. Draft generated under `Drafts/`.
2. Evidence and calculations attached or linked.
3. Run [[Publication Gate]].
4. Human review if any material check fails.
5. Move/copy to the approved archive while preserving report ID and version.
6. Mark older versions `Superseded`, never silently delete them.

Every report should include a manifest based on [[Report Manifest Template]].

<!-- BEGIN GENERATED NAVIGATION -->
[[HOME|首页]] · [[13_Sources/Source Index|来源索引]] · [[14_Reports/Run History Index|运行历史]]
<!-- END GENERATED NAVIGATION -->
