---
title: "今日研究看板"
created: 2026-10-19
updated: 2026-10-19
source: "MacroVault 自动化引擎生成（99_Automation/engine）"
tags: [dashboard, generated]
---
# 今日研究看板

数据运行时间：2026-10-19T07:17:03+00:00。资料截止：2026-10-19T07:16:58+00:00。

入口：[[HOME|首页]] · [[04_Companies/Company Research Index|公司索引]] · [[14_Reports/Run History Index|运行历史]] · [[Obsidian Navigation Guide|链接与图谱说明]]

**未接入 AI 的公司显示资料状态，不显示虚构的前瞻判断。**

| 公司 | 最新季度 | 季度数量 | 数据检查 | AI 阅读 | 本次变化 |
|---|---|---:|---|---|---|
| [[04_Companies/NVDA/Latest Brief\|NVDA]] | 2026-07-26 | 8 | Data Ready / Analysis Incomplete | not_configured | 已抓取范围内数值未变 |
| [[04_Companies/MSFT/Latest Brief\|MSFT]] | 2026-06-30 | 8 | Data Ready / Analysis Incomplete | not_configured | 已抓取范围内数值未变 |
| [[04_Companies/AMZN/Latest Brief\|AMZN]] | 2026-06-30 | 8 | Data Ready / Analysis Incomplete | not_configured | 已抓取范围内数值未变 |
| [[04_Companies/GOOGL/Latest Brief\|GOOGL]] | 2026-06-30 | 8 | Data Ready / Analysis Incomplete | not_configured | 已抓取范围内数值未变 |
| [[04_Companies/JPM/Latest Brief\|JPM]] | 2026-06-30 | 8 | Data Ready / Analysis Incomplete | not_configured | 已抓取范围内数值未变 |

## 今天需要关注
只有新的季度、数字修订、指引或论点改变才升级研究优先级。新抓取成功本身不代表有新事件。
跨资产、共识、价格和宏观连接尚未启用时显示“未取得”，不能显示“没有重要变化”。

## 下一步
- 点击公司名称打开一页简报，再点击证据 ID 或八季表中的数字追溯来源。
- 查看 [[Review Queue]] 中影响核心判断的例外。
- AI 未配置时，可把公司 AI Research Packet.json 连同 [[AI Analysis Prompt]] 提供给支持文件的 AI。
- 到期预测使用本地 review 命令检查；没有可靠结果数据的条目保持 pending_data。
