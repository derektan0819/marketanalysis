---
title: ""
created: ""
updated: ""
source: ""
tags: [template, earnings-calendar]
week_start: ""
week_end: ""
updated_at: ""
status: Draft
---
# Weekly Earnings Calendar / 每周财报日历

> Calendar data can change. Verify each event against the issuer or a named calendar provider. State timezone and whether the timing is confirmed or estimated.

| Date | Time + timezone | Company / ticker | Fiscal period | Confirmed or estimated | Source | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |

## Highest-impact reports
- Why relevant:
- Sector/index exposure and dated source:
- Key reported metrics to monitor:

## Data quality
- Last refreshed:
- Missing/uncertain timings:
- Duplicate or rescheduled events:
- Status: Draft / Needs Review / Verified
