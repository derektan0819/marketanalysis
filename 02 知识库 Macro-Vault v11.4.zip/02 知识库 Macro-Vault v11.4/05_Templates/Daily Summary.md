---
title: ""
created: ""
updated: ""
source: ""
tags: [template, daily]
report_date: ""
data_cutoff: ""
status: Draft
---
# US Market Daily Summary / 美国市场每日总结

## 1. Executive summary
- Main market driver(s):
- Cross-asset line 跨资产 (FX, crypto, commodities, global indices; write 'no material move' if so):
- What is confirmed versus inferred:
- Data cutoff and timezone:

## 2. Index and cross-asset snapshot
| Asset | Close / value | Change | Session / timestamp | Source |
|---|---:|---:|---|---|
| S&P 500 | | | | |
| Nasdaq Composite / 100 (specify) | | | | |
| Russell 2000 | | | | |
| 2Y / 10Y Treasury yield | | | | |
| DXY / USD proxy | | | | |
| EUR/USD, USD/JPY | | | | |
| USD/CNH, USD/MYR | | | | |
| VIX | | | | |
| Gold, WTI / Brent (name contract) | | | | |
| Bitcoin, Ether (provider, UTC time) | | | | |
| Spot BTC ETF net flow (provider) | | | | |
| Nikkei, Hang Seng, KOSPI, FBM KLCI (local close) | | | | |

## 3. What moved markets?
For each material move: observed fact → plausible mechanism → evidence → alternative explanation. Do not state causality based only on same-day co-movement.

## 4. Economic releases and policy
| Release | Actual | Consensus/provider/time | Prior/revision | Market reaction | Source |
|---|---:|---:|---:|---|---|
| | | | | | |

## 5. Earnings and sector read-through
- Company result and direct evidence:
- Sector / supplier / customer implications:
- Distinguish disclosed exposure from thematic inference:

## 6. Tomorrow / upcoming week
- Confirmed releases and events, with official calendar source:
- Earnings calendar source and timezone:
- Key questions to monitor:

## 7. Risks and uncertainty
- Conflicting evidence:
- Data not available:
- Alternative interpretation:

## 8. Sources and Vault notes
- External sources:
- Vault notes used:
- Status: Draft / Needs Review / Verified


## v11 override / 当前执行补充
以 [[CLAUDE]] v11 和 [[Daily Update Workflow]] 为准。前台最多三个重要变化；不强制每个期限都有方向。经营判断加入未来 1–4 季度。跨资产只报告有来源的情况，缺资料不得写无变化。观点分歧与事实冲突分开，实际能力取决于连接；时间和条件不得在登记中丢失。样本量与事件相关性需要披露，20 条不是可信阈值。
