---
title: ""
created: ""
updated: ""
source: ""
tags: [template, macro]
status: Draft
event: ""
release_datetime: ""
data_cutoff: ""
---
# Macro Event Analysis / 宏观事件分析

## 1. Event and source
- Indicator / event:
- Official release URL:
- Release timestamp and timezone:
- Reference period:
- First estimate / revision / final reading:
- Report cutoff:

## 2. Actual versus expectations
| Metric | Actual | Consensus (provider/time) | Prior | Revised prior | Unit / adjustment | Source |
|---|---:|---:|---:|---:|---|---|
| Headline | | | | | | |
| Core / key subcomponent | | | | | | |

If no valid consensus snapshot exists, do not claim a surprise versus consensus.

## 3. What changed economically?
- Headline result:
- Underlying components:
- Trend versus previous releases:
- Seasonal adjustment, base effects and revisions:
- What the release does **not** establish:

## 4. Transmission chain
`Data surprise → expected policy path → Treasury yields/real yields → USD/credit → equity sectors → index/market`

For each arrow, explain the mechanism and what could interrupt it.

## 5. Cross-asset reaction
| Asset | Move and timestamp | Source | Plausible mechanism | Alternative explanation |
|---|---|---|---|---|
| 2Y yield | | | | |
| 10Y nominal / real yield | | | | |
| USD | | | | |
| Equities / sectors | | | | |
| Credit / commodities | | | | |

## 6. Scenarios and next confirmation
- Hawkish / tighter-policy interpretation:
- Dovish / easier-policy interpretation:
- Neutral / mixed interpretation:
- Next data point that can confirm or invalidate each view:

## 7. Sources, calculations and status
- Source ledger:
- Formula(s):
- Unresolved issues:
- Status: Draft / Needs Review / Verified
