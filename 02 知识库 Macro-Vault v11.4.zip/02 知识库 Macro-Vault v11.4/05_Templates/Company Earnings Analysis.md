---
title: ""
created: ""
updated: ""
source: ""
tags: [template, earnings]
version: "11.0"
company: ""
report_period: ""
created_at: ""
report_cutoff: ""
disclosure_stage: preliminary
status: Draft
---
# Company Earnings Analysis

## 1. 一页结论
用 [[One Page Research Brief]]。资料质量和前瞻置信度分别呈现。

## 2. 阅读覆盖
按 [[Financial Reading Coverage]] 记录每份文档、章节、位置、阅读状态、截断、缺口对结论的影响。

## 3. 八季数据
| metric | quarter_end | actual | unit/basis | prior_year | prior_quarter | formula | source_id/location | status |
|---|---|---|---|---|---|---|---|---|
优先核对收入、分部、利润率、现金流、Capex、应收、存货、债务、股数。EPS 不作年度减累计推导。银行使用专用 KPI。

## 4. 预期与指引兑现
| 指标 | 本期实际 | 前次指引/假设 | 发布前共识及时间 | 结果 | 可比性 |
|---|---|---|---|---|---|
未取得共识不影响同比比较，但不能说 beat/miss。新增指引与旧指引、共识分别比较。

## 5. 质量与增长来源
价格/数量/组合/汇率/并购；经常与一次性收益；现金回收；SBC与稀释；会计估计、租赁、承诺和其他重大义务。按 [[Industry KPI Checklist]] 扩充。

## 6. 管理层变化
前次说法、本次说法、原文位置、实际兑现、Q&A追问和未回答问题。措辞变化只是线索，不能自动作为欺骗证据。

## 7. 原判断与新判断
| 原判断 | 新证据 | 支持/削弱 | 更新 | 失效条件 |
|---|---|---|---|---|
写入公司变更日志，保留历史。没有足够新信息则维持。

## 8. 经营、预期、估值分别判断
经营未来 1–4 季度；短期市场判断仅有依据时提供。估值需要价格时点、模型输入和敏感性；公司好不等于股票便宜。

## 9. 情景和验证
| 情景 | 条件 | 经营结果 | 市场影响（若有依据） | 验证指标/时间 | 反例 |
|---|---|---|---|---|---|
概率可留空；如填写，注明主观/已校准及依据。把可验证候选提交 [[Prediction Log]]，保留全部条件。

## 10. 证据与发布
来源、计算输入、反面解释、更新版本、[[Publication Gate]] 各项结果。关键未核实输入导致相关结论降级。
