---
title: ""
created: ""
updated: ""
source: ""
tags: [template, daily, impact]
report_date: ""
data_cutoff: ""
status: Draft
scope: US index, AI and semiconductors, banks, rates, FX, crypto, commodities
---
# Daily Impact Update 每日更新与影响判断

> Draft until [[Publication Gate]] passes. Forward-looking statements are `[INFERENCE]` or `[SCENARIO]`, conditional forecasts, not guarantees, and always have an invalidation signal. Workflow: [[Daily Update Workflow]]. 前瞻性表述只能标 `[INFERENCE]` 或 `[SCENARIO]`，必须附失效信号。

## 1. Conclusion first 结论先行
- What changed today 今日变化:
- Biggest implication 1–3 days / 1–4 weeks / 1–3 months:
- Cross-asset 跨资产 (FX, crypto, commodities, global indices: what moved, whether for one reason or separately, confidence; write 'no material move' if so):
- Evidence strength 证据强度 (Strong / Moderate / Weak) and why:
- Data cutoff (date, time, timezone):

## 2. What is new 今日新增
| # | Item | Type | Published at (tz) | Retrieved at | Source | Source status |
|---|---|---|---|---|---|---|
| 1 | | macro / Fed / earnings / regulation / market | | | | verified_primary / verified_secondary / unverified |

## 3. Market snapshot 行情快照
| Asset | Close / value | Change | Session / timestamp | Source |
|---|---:|---:|---|---|
| S&P 500 | | | | |
| Nasdaq Composite | | | | |
| S&P 500 equal-weight | | | | |
| SOX (semiconductors) | | | | |
| 2Y / 10Y Treasury yield | | | | |
| DXY | | | | |
| VIX | | | | |
| Oil (WTI / Brent) | | | | |
| Gold | | | | |
| EUR/USD | | | | |
| USD/JPY | | | | |
| USD/CNH, USD/MYR (optional) | | | | |
| Bitcoin (state price provider, UTC time) | | | | |
| Ethereum | | | | |
| US spot BTC / ETH ETF net flow (provider) | | | | |
| Crypto liquidations 24h (provider) | | | | |
| KOSPI / Nikkei / Hang Seng (optional) | | | | |

## 4. Impact judgments 影响判断
Repeat this block for each material item. If the item touches FX, crypto or commodities, add a row for each affected market in the horizon table or in a short cross-asset table; see [[Cross-Asset Daily Coverage]]. 每个重要事件重复一次；涉及外汇、加密、大宗商品时，为每个受影响市场补一行。

### Item N: title
- `[FACT]` what was reported (period, unit, basis, source):
- Versus expectations 相对预期: provider + timestamp, or `Not verified`
- Priced-in test 是否已计价: proxy used and its limits ([[Priced In]])
- Mechanism 传导机制: link a transmission note, e.g. [[Fed Decision to Markets]], [[Treasury Yield to Equity Valuation]], [[Hyperscaler Capex to Chip Chain]], [[Chip Earnings to AI Stocks]], [[Bank Earnings to Market]], [[Oil Price Transmission]]

| Horizon 时间段 | Hypothesis `[INFERENCE]` | Mechanism | Lag | Confidence and why | Confirmed by | Invalidated by |
|---|---|---|---|---|---|---|
| 1–3 days 1–3天 | | | | | | |
| 1–4 weeks 1–4周 | | | | | | |
| 1–3 months 1–3个月 | | | | | | |

- Read-across 关联 (label each: direct disclosed / strongly supported / indirect inference / speculative) ([[Read-Across]]):
- Alternative explanation 另一种解释:
- Logged in [[Prediction Log]] as 记录编号:

## 5. Cross-signal check 信号交叉检查
- Items that agree:
- Items that conflict and possible reasons:
- Is a single story being stretched over everything? 是否用一个故事解释了所有事情？
- Cross-asset chain (oil, yields, dollar, equities, crypto): did they move for one reason or separately? 各市场是出于同一原因还是各自独立？

## 6. Next watch list 接下来要看
| Date / time + timezone | Event | Why it matters | Official source |
|---|---|---|---|

## 7. Unknowns and conflicts 未知项与冲突
- `[UNKNOWN]`:
- Conflicting figures across sources (mark `Needs Review`):

## 8. Sources and status 来源与状态
- Sources used (inline links above; list here too):
- Vault notes used:
- Status: Draft / Needs Review / Verified


## v11 override / 当前执行补充
以 [[CLAUDE]] v11 和 [[Daily Update Workflow]] 为准。前台最多三个重要变化；不强制每个期限都有方向。经营判断加入未来 1–4 季度。跨资产只报告有来源的情况，缺资料不得写无变化。观点分歧与事实冲突分开，实际能力取决于连接；时间和条件不得在登记中丢失。样本量与事件相关性需要披露，20 条不是可信阈值。
