---
title: ""
created: ""
updated: ""
source: ""
tags: [template, earnings, read-across]
status: Draft
company: ""
ticker: ""
report_period: ""
report_cutoff: ""
---
# Earnings Read-Across Analysis / 财报关联传导分析

## 0. Executive answer
- What was reported?
- What surprised the market, if a valid consensus snapshot exists?
- Which read-across is directly evidenced, and which is only a hypothesis?
- Overall evidence strength: Strong / Moderate / Weak.

## 1. Evidence base and cutoff
- Official release / filing:
- Call transcript / presentation:
- Data cutoff with timezone:
- Consensus provider and timestamp:
- Market data provider and timestamp:
- Unresolved gaps:

## 2. Reported facts versus expectations
| Metric | Actual | Pre-release consensus | Prior period | Surprise / change | Basis | Source |
|---|---:|---:|---:|---:|---|---|
| Revenue | | | | | | |
| EPS (state basis) | | | | | | |
| Guidance | | | | | | |
| Relevant segment KPI | | | | | | |

## 3. What actually drove the result?
- Demand, price, volume, mix, utilization, backlog, cancellations or inventory:
- Margin and cost drivers:
- Cash conversion and balance-sheet signals:
- Management's explicit statements (quote only if exact and sourced):

## 4. Value-chain position
- Company role and relevant product/service:
- Direct customer/supplier evidence:
- Exposure is confirmed / disclosed / inferred / unknown:
- Potential bottlenecks and substitution options:

## 5. Transmission map
| Step | Mechanism | Evidence | Typical lag | Conditions / failure modes |
|---|---|---|---|---|
| Customer spend | | | | |
| Company orders/revenue | | | | |
| Supplier/peer impact | | | | |
| Sector / index impact | | | | |

## 6. Winners, losers and second-order effects
| Entity / segment | Directional implication | Direct or indirect exposure | Evidence strength | What could offset it? |
|---|---|---|---|---|
| | | | | |

## 7. Market reaction and priced-in test
- Price move and exact time/session:
- Benchmark-relative move:
- Options-implied move methodology/source, if available:
- Recent price run-up / valuation / positioning evidence:
- What cannot be inferred from price action alone:

## 8. Macro overlay
- Rates / yields:
- USD / FX:
- Credit conditions:
- Policy, tariffs or export controls:

## 9. Scenarios
| Scenario | Required conditions | Potential beneficiaries | Potential losers | Invalidation signal |
|---|---|---|---|---|
| Bull | | | | |
| Base | | | | |
| Bear | | | | |

## 10. Monitoring list
- Next company disclosure:
- Industry data:
- Macro data:
- Confirmation / disconfirmation thresholds (with source):

## 11. Citation and quality ledger
| Claim | Label | Evidence / calculation | Source URL | Status |
|---|---|---|---|---|
| | | | | |

## Vault notes used
- [[Earnings Read-Across Playbook]]
- [[AI Value Chain]]
- [[Read-Across]]
- [[Priced In]]
