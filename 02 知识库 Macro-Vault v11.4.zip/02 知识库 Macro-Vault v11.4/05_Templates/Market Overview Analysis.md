---
title: ""
created: ""
updated: ""
source: ""
tags: [template, market-overview]
report_date: ""
data_cutoff: ""
status: Draft
---
# US Market Overview / 美国市场整体分析

Method: [[Market Overview Checklist]]

## 1. Conclusion first 结论先行
- Regime hypothesis 市场状态假设 (risk-on / mixed / risk-off):
- Confidence 置信度 (low / medium / high) and why:
- Data cutoff and timezone:

## 2. Signal table 信号表
| Block | Reading | Source / timestamp | Points to | Notes |
|---|---|---|---|---|
| Policy and rate expectations | | | | |
| 2Y / 10Y yield, real yield | | | | |
| Dollar (DXY), yen | | | | |
| IG / HY credit spreads | | | | |
| VIX | | | | |
| Breadth / concentration | | | | |
| Earnings revisions / guidance | | | | |
| Inflation, labor, growth data | | | | |

"Points to": risk-on / risk-off / conflicting / not verified.

## 3. Agreement and conflict 一致与矛盾
- Signals that agree:
- Signals that conflict, and possible reasons:

## 4. Alternative explanation 另一种解释
- What else could explain the same readings?

## 5. What would change the view 失效信号
- 

## 6. Scenarios 情景 `[SCENARIO]`
- Base:
- Upside:
- Downside:

## 7. Unknowns and sources 未知项与来源
- `[UNKNOWN]` items:
- Sources and notes used:
