---
created: ""
updated: ""
source: ""
type: video
title: ""
speaker_or_channel: ""
url: ""
published_at: ""
watched_at: ""
markets: []
topics: []
source_quality: secondary
status: raw
related: []
tags: [video]
---
# Video: (title) 视频笔记

> Copy this template into `18_Videos/` and name the file `YYYY-MM-DD Speaker - Short title`. Fill `related` with quoted wikilinks, for example `related: ["[[DXY]]", "[[Yen and Carry Trade]]"]`. Method: [[Video Linking Playbook]]. 复制到 `18_Videos/`，`related` 里的链接要加引号。

## 1. Summary in my own words 我的摘要
(3–5 sentences. Say what the video argues, not just its topic. 写它的观点，不只是主题。)

## 2. Claims 视频里的说法
| # | Time 时间戳 | Claim 说法（用自己的话） | Type 类型 | Linked Vault note 对应库笔记 | Relation 关系 | Checked against 已核对来源 |
|---|---|---|---|---|---|---|
| 1 | | | fact / number / opinion / forecast | 待选关联笔记 | agrees / conflicts / extends / new | primary link, or `Not verified` |

Type 类型: a number or date the speaker states is a `[VIDEO-FACT]`; a view or prediction is a `[VIDEO-OPINION]`. Until checked against a primary source, both stay secondary and `unverified`. 数字和观点都先当作二手、未验证。

## 3. Links into the Vault 连接到库里的笔记
- Concepts 概念: 待选关联笔记
- Indicators 指标: 待选关联笔记
- Transmission 传导链: 待选关联笔记
- Sectors / companies 行业与公司: 待选关联笔记
- Playbook or template it could feed 可用于的流程: 待选关联笔记

## 4. Where the video and the Vault differ 两边的差异
- Agrees with the Vault 一致:
- Adds something the Vault lacks 库里没有的新内容:
- Conflicts with the Vault 冲突 (mark `Needs Review`, do not pick a side silently):

## 5. To verify 待核对
- [ ] Numbers and dates checked against a primary source ([[Source Registry]])
- [ ] Added a link from the relevant Vault note back to this one, if useful

## 6. My notes 我的笔记
