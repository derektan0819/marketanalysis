---
title: ""
created: ""
updated: ""
source: ""
tags: [template, weekly]
week: ""
data_cutoff: ""
status: Draft
---
# US Market Weekly Summary / 美国市场每周总结

## 1. Weekly conclusion
- Dominant themes:
- Cross-asset line 跨资产 (FX, crypto, commodities, global indices):
- What changed versus the previous week:
- Evidence strength and uncertainty:

## 2. Weekly market performance
| Asset / index | Weekly change | Period definition | Source |
|---|---:|---|---|
| S&P 500 | | | |
| Nasdaq (specify index) | | | |
| Russell 2000 | | | |
| Treasury yields | | | |
| USD / DXY | | | |
| EUR/USD, USD/JPY, USD/CNH, USD/MYR | | | |
| VIX | | | |
| Gold, WTI / Brent | | | |
| Bitcoin, Ether (UTC definition of the week) | | | |
| Global indices (Nikkei, Hang Seng, KOSPI, FBM KLCI) | | | |

## 3. Macro developments
- Data surprises and revisions:
- Fed / policy communication:
- Rates, USD and credit transmission:

## 4. Earnings and sector developments
- Major reported results versus valid expectations:
- Guidance changes:
- Read-across with evidence strength:

## 5. What was confirmed / not confirmed?
| Prior hypothesis | New evidence | Result | What changes next? |
|---|---|---|---|
| | | | |

## 6. Next week calendar
| Date/time + timezone | Event/company | Expected relevance | Official/provider source |
|---|---|---|---|
| | | | |

## 7. Scenarios and risks
- Bull / base / bear:
- Main invalidation signals:

## 8. Sources and status
- Sources:
- Vault notes used:
- Status: Draft / Needs Review / Verified


## v11 override / 当前执行补充
以 [[CLAUDE]] v11 和 [[Daily Update Workflow]] 为准。前台最多三个重要变化；不强制每个期限都有方向。经营判断加入未来 1–4 季度。跨资产只报告有来源的情况，缺资料不得写无变化。观点分歧与事实冲突分开，实际能力取决于连接；时间和条件不得在登记中丢失。样本量与事件相关性需要披露，20 条不是可信阈值。
