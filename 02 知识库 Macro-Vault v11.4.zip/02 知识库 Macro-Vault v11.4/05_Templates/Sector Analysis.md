---
title: ""
created: ""
updated: ""
source: ""
tags: [template, sector]
status: Draft
sector: ""
as_of: ""
---
# Sector Analysis / 板块分析

## 1. Scope and cutoff
- Sector definition and included subsectors:
- Geography:
- Data cutoff:
- Sector/index proxy and dated source:

## 2. Industry structure
- Value chain:
- Main revenue pools:
- Concentration and competitive dynamics:
- Capacity constraints / inventory / substitution:

## 3. Demand and supply indicators
| Indicator | Latest value | Period | Trend | Source | Limitations |
|---|---:|---|---|---|---|
| | | | | | |

## 4. Company comparison
| Company | Relevant segment | Growth | Margin | Guidance | Balance-sheet / cash flow | Source status |
|---|---|---:|---:|---|---|---|
| | | | | | | |

## 5. Profit pool and sensitivity
- Price vs volume:
- Fixed vs variable costs:
- Utilization and operating leverage:
- FX / rates / commodity / policy exposure:
- Customer concentration and bargaining power:

## 6. Valuation and expectations
- Valuation metrics, period and source:
- Consensus estimate revisions (provider and timestamp):
- Recent performance and benchmark:
- What may be priced in and evidence limitations:

## 7. Catalysts and risks
| Driver | Potential direction | Evidence | Timing | What would invalidate the view? |
|---|---|---|---|---|
| | | | | |

## 8. Scenarios
- Bull:
- Base:
- Bear:

## 9. Sources and status
- Source ledger:
- Missing / conflicting data:
- Status: Draft / Needs Review / Verified
