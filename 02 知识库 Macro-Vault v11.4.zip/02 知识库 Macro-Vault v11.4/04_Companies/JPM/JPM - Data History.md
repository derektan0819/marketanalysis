---
title: "JPM — 最近八个季度"
created: 2026-10-19
updated: 2026-10-19
source: "MacroVault 自动化引擎生成（99_Automation/engine）"
tags: [company, history, generated]
status: data_only
as_of: "2026-10-19T07:16:58+00:00"
---
# JPM — 最近八个季度

只展示已取得的季度；缺失值不是零。历史值为本次截止时已知版本，不能直接用于无前视偏差回测。
`†` 表示需要核对（例如跨申报文件推导现金流）；其他数字也仅通过结构与计算检查，不等于完整财报阅读。

| 季度结束 | bank_net_interest_income | net_income | diluted_eps | assets | liabilities | equity |
|---|---|---|---|---|---|---|
| 2024-09-30 | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-023145e3ce112c2bac44\|23.405 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-9a15780927bbae993955\|12.898 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-f86f34c8408a57028b52\|4.370 USD/shares]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-9783a19924a063eea8b4\|4,210.048 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-577f2f897e31dc5e9290\|3,864.212 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-3563583ce8fded98fac9\|345.836 B USD]] |
| 2024-12-31 | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-d0943232e84bff827760\|23.350 B USD †]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-6274dbf272c1865f3fa0\|14.005 B USD †]] | 缺失 | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-6ca767e3115dc1d139d8\|4,002.814 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-0553041de803fca6c2f3\|3,658.056 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-bf413cd123def84207c1\|344.758 B USD]] |
| 2025-03-31 | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-2b09c4952a5404070613\|23.273 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-bfbd05640a46a6fbed91\|14.643 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-33008aa656aa35d99c73\|5.070 USD/shares]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-a7ab6560bb971506d2f9\|4,357.856 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-61fff2df8d58f6180824\|4,006.436 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-9cf909b264044955b556\|351.420 B USD]] |
| 2025-06-30 | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-452fbc81a59ed1871d67\|23.209 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-ceda7ca40fbe21b5c560\|14.987 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-2917aecceb9489e5e36e\|5.240 USD/shares]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-f4d069f3a50debbfe371\|4,552.482 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-04e7a0814dfc7aed1771\|4,195.558 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-592889f39f9dfac46813\|356.924 B USD]] |
| 2025-09-30 | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-71d98d3d41a3edc6037e\|23.966 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-75b9c83f298d73fc4b28\|14.393 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-2d3a787fac6c92fa5c55\|5.070 USD/shares]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-eb6ddb2ee4bc51e0aec2\|4,560.205 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-08f74c7f22d56edf71eb\|4,199.993 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-4d1919c265601c053623\|360.212 B USD]] |
| 2025-12-31 | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-6b9f2fbceeb99e4da6d2\|24.995 B USD †]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-fddc1fc45021e0da2a7e\|13.025 B USD †]] | 缺失 | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-bf06548d34cc2032c46e\|4,424.900 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-2a0c8b57158d565ff0d0\|4,062.462 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-9f62297ab10cdc3de86b\|362.438 B USD]] |
| 2026-03-31 | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-84391522e7a9904b3240\|25.366 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-50fc03bc7224201686cc\|16.494 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-ad07f325ee06b46272ed\|5.940 USD/shares]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-7498be4a14efd7b7029a\|4,900.475 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-3f455b4f37a65dadc4b6\|4,536.437 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-aff4e97346004038f258\|364.038 B USD]] |
| 2026-06-30 | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-cace38884027e5fe460a\|25.511 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-e61cd9b72c1afddff718\|21.155 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-cbb1600e835415b7042f\|7.700 USD/shares]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-c08d0c20a869014f2601\|5,015.069 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-ff57528913badeb68dcc\|4,640.471 B USD]] | [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence#^OBS-63a9552216b98af1ffaa\|374.598 B USD]] |

## 可追溯记录
点击表格中的数字即可定位到 [[14_Reports/Run History/20261019T071658Z-b240c2/JPM/Evidence|本次证据页]] 的对应记录。
原始快照：[[12_Data/Companies/JPM/20261019T071658Z-b240c2.json|JSON 文件（外部编辑器）]]。
每条 observation 包含 source_id、tag、期间、单位、申报 accession 和计算输入 ID。

[[04_Companies/JPM/Company Profile|JPM 档案]] · [[04_Companies/JPM/Latest Brief|最新简报]] · [[04_Companies/JPM/JPM - Data History|八季数据]] · [[04_Companies/JPM/Evidence Index|证据索引]] · [[04_Companies/JPM/Current Thesis|当前判断]] · [[04_Companies/JPM/Thesis History|判断历史]]

## 限制
EPS／加权股数不使用全年减前三季推导。分部、公司自定义标签、管理层指引、共识、估值及脚注尚需独立获取。银行不套用工业公司的 FCF。
