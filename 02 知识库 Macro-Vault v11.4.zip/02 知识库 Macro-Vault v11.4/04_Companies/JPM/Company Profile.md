---
title: "JPMorgan Chase — 公司研究档案"
tags: [company, jpm]
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
---
# JPMorgan Chase — 公司研究档案

Ticker: JPM。SEC CIK: 0000019617。行业分类用于模板选择：banks。
身份会在每次 run 与 SEC submissions 的 CIK 和 ticker 核对。财政季度以原文 period_end 为准，不套用日历季度。

当前研究理由：用户尚未指定个别投资论点；作为 v11 流程试点。
研究重点：按 [[Industry KPI Checklist]] 检查本公司披露的关键指标。
下面的入口分别连接本公司的简报、数据、证据和判断历史。


## 分析框架

这些关联用于选择分析方法，不代表本期事实、已证实因果或投资建议。

[[US Banks]] · [[Interest Rates]] · [[Yield Curve]] · [[Credit Spread]]

## 2026-10-27 补充：最新季度数据

库内最新结构化季度是 2026-06-30；JPMorgan Chase 已于 2026-10-13 发布第三季度财报。下表保留旧值，新值来自公司新闻稿。两列是不同季度，不是同一季度的修正；第二季度可能含一次性项目，未核对，不要直接相减解读。

| 指标 | 旧值（2026-06-30，库内结构化数据） | 新值（2026 年第三季度） |
|---|---|---|
| 净利润 | 211.55 亿美元 | 153 亿美元（同比 +6%）；剔除重大项目后 158 亿美元 |
| 稀释每股收益 | 7.70 美元 | 5.57 美元；剔除重大项目后 5.75 美元 |
| 净利息收入 | 255.11 亿美元 | 271 亿美元（同比 +13%） |

来源：[JPMorgan Chase 3Q26 Earnings Press Release](https://www.jpmorganchase.com/content/dam/jpmc/jpmorgan-chase-and-co/investor-relations/documents/quarterly-earnings/2026/3rd-quarter/6c1f8114-1be4-4174-8292-f75bbb59bc21.pdf)；数据日期 2026-09-30（季度末），发布 2026-10-13；写入 2026-10-27。完整对照见 [[12_Data/US Macro Snapshot 2026-10-27|数据快照]] 第 8 节。

<!-- BEGIN GENERATED NAVIGATION -->
## 相关入口

[[04_Companies/JPM/Company Profile|JPM 档案]] · [[04_Companies/JPM/Latest Brief|最新简报]] · [[04_Companies/JPM/JPM - Data History|八季数据]] · [[04_Companies/JPM/Evidence Index|证据索引]] · [[04_Companies/JPM/Current Thesis|当前判断]] · [[04_Companies/JPM/Thesis History|判断历史]]

[[04_Companies/Company Research Index|所有公司]]
<!-- END GENERATED NAVIGATION -->
