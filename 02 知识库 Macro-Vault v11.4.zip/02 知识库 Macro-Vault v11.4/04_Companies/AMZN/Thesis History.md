---
title: "AMZN — 判断版本历史"
tags: [company, amzn]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# AMZN — 判断版本历史

尚无正式论点变更。格式见 [[Thesis Change Log]]。

<!-- BEGIN GENERATED NAVIGATION -->
## 相关入口

[[04_Companies/AMZN/Company Profile|AMZN 档案]] · [[04_Companies/AMZN/Latest Brief|最新简报]] · [[04_Companies/AMZN/AMZN - Data History|八季数据]] · [[04_Companies/AMZN/Evidence Index|证据索引]] · [[04_Companies/AMZN/Current Thesis|当前判断]] · [[04_Companies/AMZN/Thesis History|判断历史]]

[[04_Companies/Company Research Index|所有公司]]
<!-- END GENERATED NAVIGATION -->
