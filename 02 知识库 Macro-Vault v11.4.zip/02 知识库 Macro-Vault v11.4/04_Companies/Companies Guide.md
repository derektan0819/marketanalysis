---
title: "Company Research"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [guide, companies]
---
# Company Research

Create one folder or consistent filename scheme per ticker. Keep the issuer's fiscal calendar explicit.

Recommended files:
- `Company Profile.md` — business segments, official IR/SEC links, fiscal year end and source date.
- `YYYY-Qn Earnings Analysis.md` — based on [[Company Earnings Analysis]].
- `YYYY-Qn Read-Across.md` — based on [[Earnings Read-Across Analysis]].
- `Source Register.md` — official documents, timestamps and source IDs.

Rules:
- Do not assume a company example in a sector note is still a leader, supplier or index constituent without checking.
- Keep reported actuals, consensus, guidance and estimates separate.
- Do not overwrite historical reports; mark older versions superseded.
- See [[Report Manifest Template]], [[Data Dictionary and Schema]] and [[Publication Gate]].
