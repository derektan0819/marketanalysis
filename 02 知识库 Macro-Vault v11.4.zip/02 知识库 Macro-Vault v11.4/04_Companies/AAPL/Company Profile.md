---
title: "Apple — 公司研究档案"
aliases: [Apple, 苹果, AAPL]
tags: [company, aapl]
created: 2026-10-27
updated: 2026-10-27
source: "Apple 2026 财年第三季度新闻稿、SEC 8-K 附件 99.1 与 10-Q；逐项网址见正文"
verified: 2026-10-27
---
# Apple — 公司研究档案

Ticker: AAPL。SEC CIK: 0000320193。
财年：“The Company’s fiscal year is the 52- or 53-week period that ends on the last Saturday of September.”（[2026 财年第三季度 10-Q](https://www.sec.gov/Archives/edgar/data/0000320193/000032019326000020/aapl-20260627.htm) 附注 1）。财政季度以原文 period_end 为准，不套用日历季度。

本档案于 2026-10-27 新增，尚未纳入库内自动化（`99_Automation/config/settings.json` 的公司名单只有 5 家），所以没有一页简报、八季数据和证据索引。下面的数字只来自公司官方文件；没有个别投资论点，不是买入推荐。

## 业务构成
- **产品与服务类别：** iPhone；Mac；iPad；Wearables, Home and Accessories（可穿戴、家居及配件）；Services（服务）。
- **报告分部（按地区）：** Americas、Europe、Greater China、Japan、Rest of Asia Pacific。

来源：[2026 财年第三季度 8-K 附件 99.1](https://www.sec.gov/Archives/edgar/data/0000320193/000032019326000018/a8-kex991q3202606272026.htm) 的营收分类表。

## 最新季度：2026 财年第三季度（截至 2026-06-27）

单位：百万美元（每股收益除外），与原文一致。

| 指标 | 本季（截至 2026-06-27） | 上年同期（截至 2025-06-28） |
|---|---:|---:|
| 营收合计 | 109,417 | 94,036 |
| iPhone | 54,252 | 44,582 |
| Mac | 10,352 | 8,046 |
| iPad | 6,191 | 6,581 |
| 可穿戴、家居及配件 | 7,883 | 7,404 |
| 服务 | 30,739 | 27,423 |
| 营业利润 | 35,695 | 28,202 |
| 净利润 | 29,789 | 23,434 |
| 稀释每股收益（美元） | 2.02 | 1.57 |
| 大中华区营收 | 18,816 | 15,369 |
| 美洲营收 | 45,781 | 41,198 |
| 欧洲营收 | 29,395 | 24,014 |

- 新闻稿原话：营收“up 16 percent year over year”，稀释每股收益“up 29 percent year over year”。
- **一次性因素：** 毛利率 50.1%，“including a favorable impact of approximately 2 percentage points from tariff refunds”；每股收益“included a favorable impact of $0.11 from tariff refunds”。同比比较要先扣除这部分。
- 季度股息每股 0.27 美元，2026-08-13 派发，登记日 2026-08-10。

来源：[Apple 新闻稿](https://www.apple.com/newsroom/2026/07/apple-reports-third-quarter-results/)（发布 2026-07-30）；[8-K 附件 99.1](https://www.sec.gov/Archives/edgar/data/0000320193/000032019326000018/a8-kex991q3202606272026.htm)。数据日期 2026-06-27（季度末）；写入 2026-10-27。

## 下一次披露
2026 财年第四季度业绩：2026-11-02，2:00 p.m. PT（5:00 p.m. ET）——[Apple Investor Relations](https://investor.apple.com/investor-relations/event-details/2026/FY-26-Fourth-Quarter-Results/default.aspx)。见 [[12_Data/US Release Calendar 2026-10-27|发布日历]]。

## 分析框架

这些关联用于选择分析方法，不代表本期事实、已证实因果或投资建议。

[[US Big Tech]] · [[Consumer Staples and Discretionary]] · [[China Linkages to US Markets]] · [[Trade Tariffs and Supply Chains]] · [[Tariffs to Prices and Earnings]] · [[Share Buybacks and Dividends]] · [[Mega-Cap Earnings to Index]] · [[Index Weighting and Concentration]]

## 相关入口
[[04_Companies/Companies MOC|全部公司档案]] · [[04_Companies/Company Research Index|已纳入自动化的公司]] · [[05_Templates/Company Earnings Analysis|财报分析模板]] · [[10_Playbooks/Financial Reading Coverage|财报阅读覆盖清单]]
