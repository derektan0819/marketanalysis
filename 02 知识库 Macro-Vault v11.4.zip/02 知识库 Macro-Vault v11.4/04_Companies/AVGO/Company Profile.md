---
title: "Broadcom — 公司研究档案"
aliases: [Broadcom, 博通, AVGO]
tags: [company, avgo]
created: 2026-10-27
updated: 2026-10-27
source: "Broadcom 2026 财年第三季度新闻稿（SEC 8-K 附件 99）与 10-Q；逐项网址见正文"
verified: 2026-10-27
---
# Broadcom — 公司研究档案

Ticker: AVGO。SEC CIK: 0001730168。
财年：“We operate on a 52- or 53-week fiscal year ending on the Sunday closest to October 31.”（[2026 财年第三季度 10-Q](https://www.sec.gov/Archives/edgar/data/0001730168/000173016826000080/avgo-20260802.htm)）。财政季度以原文 period_end 为准，不套用日历季度。

本档案于 2026-10-27 新增，尚未纳入库内自动化（`99_Automation/config/settings.json` 的公司名单只有 5 家），所以没有一页简报、八季数据和证据索引。下面的数字只来自公司官方文件；没有个别投资论点，不是买入推荐。

## 业务构成
两个报告分部：**Semiconductor solutions**（半导体解决方案，包括 AI 相关芯片）和 **Infrastructure software**（基础设施软件）。

## 最新季度：2026 财年第三季度（截至 2026-08-02）

单位：百万美元（每股收益除外），与原文一致。

| 指标 | 本季 | 上年同期 |
|---|---:|---:|
| 营收合计 | 约 29,600（原文“$29.6 billion”） | 15,952 |
| 半导体解决方案 | 20,839 | 9,166 |
| 基础设施软件 | 8,752 | 6,786 |
| GAAP 净利润 | 13,088 | — |
| GAAP 稀释每股收益（美元） | 2.68 | — |
| 非 GAAP 净利润 | 16,372 | — |
| 非 GAAP 稀释每股收益（美元） | 3.32 | — |

- 营收同比 +86%。AI 半导体营收 167 亿美元，同比 +221%（新闻稿原话：“Q3 AI semiconductor revenue of $16.7 billion grew 221% year-over-year”）。
- 非 GAAP 营业利润约 201 亿美元；经营现金流 142 亿美元；自由现金流 137 亿美元。
- 非 GAAP 与 GAAP 口径差异较大，阅读前先看 [[GAAP vs Non-GAAP]]。上年同期的利润数据本档案没有逐项核对，表中用“—”表示。

**公司指引（2026-09-02 发布）：**
- 第四季度营收约 348 亿美元。
- 非 GAAP 营业利润约为预计营收的 66%。

**股息：** 季度普通股股息每股 0.65 美元，2026-09-30 派发，登记日 2026-09-21。

来源：[Broadcom 新闻稿（SEC 8-K 附件 99）](https://www.sec.gov/Archives/edgar/data/0001730168/000173016826000076/avgo-08022026x8kxex99.htm)，发布 2026-09-02。同一新闻稿在 [Broadcom 投资者关系网站](https://investors.broadcom.com/news-releases/news-release-details/broadcom-inc-announces-third-quarter-fiscal-year-2026-financial)，但 2026-10-27 访问被拒（HTTP 403），数字按 SEC 文件。数据日期 2026-08-02（季度末）；写入 2026-10-27。

## 下一次披露
2026 财年第四季度业绩日期尚未在官方页面查到（待核实）。

## 分析框架

这些关联用于选择分析方法，不代表本期事实、已证实因果或投资建议。

[[Semiconductors]] · [[AI Value Chain]] · [[Hyperscaler Capex]] · [[Hyperscaler Capex to Chip Chain]] · [[Chip Earnings to AI Stocks]] · [[Cloud and Software]] · [[SOX Index]] · [[GAAP vs Non-GAAP]] · [[Index Weighting and Concentration]]

## 相关入口
[[04_Companies/Companies MOC|全部公司档案]] · [[04_Companies/Company Research Index|已纳入自动化的公司]] · [[05_Templates/Company Earnings Analysis|财报分析模板]] · [[10_Playbooks/Financial Reading Coverage|财报阅读覆盖清单]]
