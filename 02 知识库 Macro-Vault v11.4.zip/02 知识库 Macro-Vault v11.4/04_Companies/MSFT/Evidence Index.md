---
title: "MSFT — 证据与历次报告"
tags: [company, msft]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# MSFT — 证据与历次报告

[[04_Companies/MSFT/Company Profile|MSFT 档案]] · [[04_Companies/MSFT/Latest Brief|最新简报]] · [[04_Companies/MSFT/MSFT - Data History|八季数据]] · [[04_Companies/MSFT/Evidence Index|证据索引]] · [[04_Companies/MSFT/Current Thesis|当前判断]] · [[04_Companies/MSFT/Thesis History|判断历史]]

最新证据：[[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Evidence|最新八季数据及计算输入]]

## 历次快照
- 2026-10-19T07:16:58+00:00：[[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Brief|简报]] · [[14_Reports/Run History/20261019T071658Z-b240c2/MSFT/Evidence|证据]]
- 2026-10-19T07:12:45+00:00：[[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Brief|简报]] · [[14_Reports/Run History/20261019T071245Z-e92a54/MSFT/Evidence|证据]]
- 2026-10-19T07:07:44+00:00：[[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Brief|简报]] · [[14_Reports/Run History/20261019T070744Z-4e0381/MSFT/Evidence|证据]]

## 机器可读文件
- [[04_Companies/MSFT/Financial Observations.csv|数值索引 CSV]]
- [[04_Companies/MSFT/AI Research Packet.json|AI 阅读包 JSON]]
