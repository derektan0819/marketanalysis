---
title: "Tesla — 公司研究档案"
aliases: [Tesla, 特斯拉, TSLA]
tags: [company, tsla]
created: 2026-10-27
updated: 2026-10-27
source: "Tesla 2026 年第三季度更新（SEC 8-K 附件 99.1）；逐项网址见正文"
verified: 2026-10-27
---
# Tesla — 公司研究档案

Ticker: TSLA。SEC CIK: 0001318605。财年与日历年一致（第三季度截至 9 月 30 日）。

本档案于 2026-10-27 新增，尚未纳入库内自动化（`99_Automation/config/settings.json` 的公司名单只有 5 家），所以没有一页简报、八季数据和证据索引。下面的数字只来自公司官方文件；没有个别投资论点，不是买入推荐。

## 业务构成
收入表中的主要类别：**汽车**（Total automotive revenues）和**能源发电与储能**（Energy generation and storage）。运营指标包括汽车产量、交付量和储能部署量（GWh）。

## 最新季度：2026 年第三季度（截至 2026-09-30）

单位：百万美元（每股收益、汽车台数、GWh 除外），与原文一致。

| 指标 | 2026 年第三季度 | 2025 年第三季度 |
|---|---:|---:|
| 营收合计 | 28,046 | 28,095 |
| 汽车营收 | 20,560 | 21,205 |
| 能源发电与储能营收 | 2,881 | 3,415 |
| 营业利润 | 718 | 1,624 |
| 归属普通股股东净利润（GAAP） | 787 | 1,373 |
| 稀释每股收益（GAAP，美元） | 0.22 | 0.39 |
| 归属普通股股东净利润（非 GAAP） | 1,697 | 1,770 |
| 稀释每股收益（非 GAAP，美元） | 0.48 | 0.50 |
| 经营现金流 | 6,263 | 6,238 |
| 资本开支 | (4,732) | (2,248) |
| 自由现金流 | 1,531 | 3,990 |
| 现金、现金等价物及短期投资 | 45,447 | 41,647 |
| 汽车产量（辆） | 464,391 | 447,450 |
| 汽车交付量（辆） | 486,532 | 497,099 |
| 储能部署（GWh） | 13.7 | 12.5 |

- 营业利润率约 2.6%（718 ÷ 28,046，自行计算），原文写同比“-322 bp”。
- 自由现金流 = 经营现金流 − 资本开支（6,263 − 4,732 = 1,531），与原文一致。资本开支翻倍是现金流下降的主因。
- 展望部分没有数字指引，只有定性表述，例如“We are focused on maximum capacity utilization at our factories.”

来源：[Tesla 2026 年第三季度更新（SEC 8-K 附件 99.1）](https://www.sec.gov/Archives/edgar/data/0001318605/000162828026066738/exhibit9914.htm)；[8-K 主文件](https://www.sec.gov/Archives/edgar/data/0001318605/000162828026066738/tsla-20261021.htm)。发布 2026-10-21（同日 4:30 p.m. CT 网络直播）；数据日期 2026-09-30（季度末）；写入 2026-10-27。

## 下一次披露
2026 年第四季度业绩日期尚未在官方页面查到（待核实）。

## 分析框架

这些关联用于选择分析方法，不代表本期事实、已证实因果或投资建议。

[[US Big Tech]] · [[Consumer Staples and Discretionary]] · [[US Consumer and Housing]] · [[Interest Rates]] · [[China Linkages to US Markets]] · [[Trade Tariffs and Supply Chains]] · [[Data Centers and Power]] · [[GAAP vs Non-GAAP]] · [[Mega-Cap Earnings to Index]]

## 相关入口
[[04_Companies/Companies MOC|全部公司档案]] · [[04_Companies/Company Research Index|已纳入自动化的公司]] · [[05_Templates/Company Earnings Analysis|财报分析模板]] · [[10_Playbooks/Financial Reading Coverage|财报阅读覆盖清单]]
