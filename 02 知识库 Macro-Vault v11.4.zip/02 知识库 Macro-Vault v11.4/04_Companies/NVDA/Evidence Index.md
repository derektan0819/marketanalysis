---
title: "NVDA — 证据与历次报告"
tags: [company, nvda]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# NVDA — 证据与历次报告

[[04_Companies/NVDA/Company Profile|NVDA 档案]] · [[04_Companies/NVDA/Latest Brief|最新简报]] · [[04_Companies/NVDA/NVDA - Data History|八季数据]] · [[04_Companies/NVDA/Evidence Index|证据索引]] · [[04_Companies/NVDA/Current Thesis|当前判断]] · [[04_Companies/NVDA/Thesis History|判断历史]]

最新证据：[[14_Reports/Run History/20261019T071658Z-b240c2/NVDA/Evidence|最新八季数据及计算输入]]

## 历次快照
- 2026-10-19T07:16:58+00:00：[[14_Reports/Run History/20261019T071658Z-b240c2/NVDA/Brief|简报]] · [[14_Reports/Run History/20261019T071658Z-b240c2/NVDA/Evidence|证据]]
- 2026-10-19T07:12:45+00:00：[[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Brief|简报]] · [[14_Reports/Run History/20261019T071245Z-e92a54/NVDA/Evidence|证据]]
- 2026-10-19T07:07:44+00:00：[[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Brief|简报]] · [[14_Reports/Run History/20261019T070744Z-4e0381/NVDA/Evidence|证据]]

## 机器可读文件
- [[04_Companies/NVDA/Financial Observations.csv|数值索引 CSV]]
- [[04_Companies/NVDA/AI Research Packet.json|AI 阅读包 JSON]]
