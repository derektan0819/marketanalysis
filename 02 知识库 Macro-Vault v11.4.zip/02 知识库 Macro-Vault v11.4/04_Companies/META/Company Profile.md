---
title: "Meta Platforms — 公司研究档案"
aliases: [Meta, Meta Platforms, META]
tags: [company, meta]
created: 2026-10-27
updated: 2026-10-27
source: "Meta 2026 年第三季度新闻稿与 SEC 8-K 附件 99.1；逐项网址见正文"
verified: 2026-10-27
---
# Meta Platforms — 公司研究档案

Ticker: META。SEC CIK: 0001326801。财年与日历年一致（第三季度截至 9 月 30 日）。

本档案于 2026-10-27 新增，尚未纳入库内自动化（`99_Automation/config/settings.json` 的公司名单只有 5 家），所以没有一页简报、八季数据和证据索引。下面的数字只来自公司官方文件；没有个别投资论点，不是买入推荐。

## 业务构成
两个报告分部：**Family of Apps**（Facebook、Instagram、Messenger、WhatsApp 等应用，收入以广告为主）和 **Reality Labs**（虚拟/增强现实硬件与相关业务）。

## 最新季度：2026 年第三季度（截至 2026-09-30）

单位：百万美元（每股收益除外），与原文一致。

| 指标 | 2026 年第三季度 | 2025 年第三季度 |
|---|---:|---:|
| 营收 | 64,601 | 51,242 |
| 成本费用合计 | 51,613 | 30,707 |
| 营业利润 | 12,988 | 20,535 |
| 净利润 | 9,860 | 2,709 |
| 稀释每股收益（美元） | 3.83 | 1.05 |
| Family of Apps 营收 | 64,158 | 50,772 |
| Family of Apps 营业利润 | 17,117 | 24,967 |
| Reality Labs 营收 | 443 | 470 |
| Reality Labs 营业亏损 | (4,129) | (4,432) |

- 营收同比 +26%；营业利润率 20%，上年同期 40%。
- **一次性因素：** “Third quarter 2026 costs and expenses includes a $9.89 billion charge related to this agreement.” 这里的协议是 2026 年 8 月宣布的、与 52 个州总检察长就青少年心理健康和社交媒体诉讼达成的和解。
- **净利润大增主要是税率造成的：** 有效税率 24%，上年同期 87%。不要把净利润增速当成经营改善。
- 资本开支（含融资租赁本金）349.1 亿美元。截至 9 月 30 日员工 66,775 人，同比 −15%。
- 运营指标：2026 年 9 月 Family 日活跃人数（DAP）平均 36.4 亿，同比 +3%；广告展示量 +10%；单条广告平均价格 +14%。

**公司指引（2026-10-21 发布）：**
- 第四季度营收 730–760 亿美元。
- 2026 全年总费用 1,750–1,790 亿美元。
- 2026 全年资本开支 1,350–1,450 亿美元，此前为 1,300–1,450 亿美元。
- Reality Labs 2026 全年亏损 180–190 亿美元。

**股本变动：** 董事会批准新设公开上市、无投票权的 C 类普通股，以一次性股票股息方式向 A 类、B 类股东发放。修订后的公司章程预计 2027-01-19 生效。公司预计派息后 A 类股价会体现为“一拆二”。

来源：[Meta 新闻稿](https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-Reports-Third-Quarter-2026-Results/default.aspx)（发布 2026-10-21）；[8-K 附件 99.1](https://www.sec.gov/Archives/edgar/data/0001326801/000162828026066700/meta-09302026xexhibit991.htm)。数据日期 2026-09-30（季度末）；写入 2026-10-27。

## 下一次披露
2026 年第四季度业绩日期尚未在官方页面查到（待核实）。

## 分析框架

这些关联用于选择分析方法，不代表本期事实、已证实因果或投资建议。

[[US Big Tech]] · [[Hyperscaler Capex]] · [[Hyperscaler Capex to Chip Chain]] · [[AI Value Chain]] · [[Data Centers and Power]] · [[Capex Cycle]] · [[Earnings Quality]] · [[Mega-Cap Earnings to Index]] · [[Index Weighting and Concentration]]

## 相关入口
[[04_Companies/Companies MOC|全部公司档案]] · [[04_Companies/Company Research Index|已纳入自动化的公司]] · [[05_Templates/Company Earnings Analysis|财报分析模板]] · [[10_Playbooks/Financial Reading Coverage|财报阅读覆盖清单]]
