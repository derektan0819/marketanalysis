---
title: "Companies MOC — 公司"
tags: [index, moc]
created: 2026-10-27
updated: 2026-10-27
source: "自动整理：完整列出 04_Companies 的全部文件（2026-10-27）"
---

# Companies MOC — 公司

[[00_Index/Master Index|总索引]] · [[HOME|首页]]

本文件夹共 46 个文件，其中笔记 36 篇。以下按路径完整列出，笔记显示标题。

## 先读

- [[04_Companies/Companies Guide|Company Research]]
- [[04_Companies/Company Research Index|Company Research Index]]

## 笔记

- [[04_Companies/Companies Guide|Company Research]]
- [[04_Companies/Company Research Index|Company Research Index]]

## AAPL

- [[04_Companies/AAPL/Company Profile|Apple — 公司研究档案]]

## AMZN

- [[04_Companies/AMZN/AMZN - Data History|AMZN — 最近八个季度]]
- [[04_Companies/AMZN/Company Profile|Amazon — 公司研究档案]]
- [[04_Companies/AMZN/Current Thesis|AMZN — 当前研究判断]]
- [[04_Companies/AMZN/Evidence Index|AMZN — 证据与历次报告]]
- [[04_Companies/AMZN/Latest Brief|AMZN — 发生了什么，接下来怎么看]]
- [[04_Companies/AMZN/Thesis History|AMZN — 判断版本历史]]

## AVGO

- [[04_Companies/AVGO/Company Profile|Broadcom — 公司研究档案]]

## GOOGL

- [[04_Companies/GOOGL/Company Profile|Alphabet — 公司研究档案]]
- [[04_Companies/GOOGL/Current Thesis|GOOGL — 当前研究判断]]
- [[04_Companies/GOOGL/Evidence Index|GOOGL — 证据与历次报告]]
- [[04_Companies/GOOGL/GOOGL - Data History|GOOGL — 最近八个季度]]
- [[04_Companies/GOOGL/Latest Brief|GOOGL — 发生了什么，接下来怎么看]]
- [[04_Companies/GOOGL/Thesis History|GOOGL — 判断版本历史]]

## JPM

- [[04_Companies/JPM/Company Profile|JPMorgan Chase — 公司研究档案]]
- [[04_Companies/JPM/Current Thesis|JPM — 当前研究判断]]
- [[04_Companies/JPM/Evidence Index|JPM — 证据与历次报告]]
- [[04_Companies/JPM/JPM - Data History|JPM — 最近八个季度]]
- [[04_Companies/JPM/Latest Brief|JPM — 发生了什么，接下来怎么看]]
- [[04_Companies/JPM/Thesis History|JPM — 判断版本历史]]

## META

- [[04_Companies/META/Company Profile|Meta Platforms — 公司研究档案]]

## MSFT

- [[04_Companies/MSFT/Company Profile|Microsoft — 公司研究档案]]
- [[04_Companies/MSFT/Current Thesis|MSFT — 当前研究判断]]
- [[04_Companies/MSFT/Evidence Index|MSFT — 证据与历次报告]]
- [[04_Companies/MSFT/Latest Brief|MSFT — 发生了什么，接下来怎么看]]
- [[04_Companies/MSFT/MSFT - Data History|MSFT — 最近八个季度]]
- [[04_Companies/MSFT/Thesis History|MSFT — 判断版本历史]]

## NVDA

- [[04_Companies/NVDA/Company Profile|NVIDIA — 公司研究档案]]
- [[04_Companies/NVDA/Current Thesis|NVDA — 当前研究判断]]
- [[04_Companies/NVDA/Evidence Index|NVDA — 证据与历次报告]]
- [[04_Companies/NVDA/Latest Brief|NVDA — 发生了什么，接下来怎么看]]
- [[04_Companies/NVDA/NVDA - Data History|NVDA — 最近八个季度]]
- [[04_Companies/NVDA/Thesis History|NVDA — 判断版本历史]]

## TSLA

- [[04_Companies/TSLA/Company Profile|Tesla — 公司研究档案]]

## 机器可读文件

JSON、CSV、HTML、TXT、PY 等文件，可在 Obsidian 中打开或用外部编辑器查看。

- [[04_Companies/AMZN/AI Research Packet.json|AMZN/AI Research Packet.json]]
- [[04_Companies/AMZN/Financial Observations.csv|AMZN/Financial Observations.csv]]
- [[04_Companies/GOOGL/AI Research Packet.json|GOOGL/AI Research Packet.json]]
- [[04_Companies/GOOGL/Financial Observations.csv|GOOGL/Financial Observations.csv]]
- [[04_Companies/JPM/AI Research Packet.json|JPM/AI Research Packet.json]]
- [[04_Companies/JPM/Financial Observations.csv|JPM/Financial Observations.csv]]
- [[04_Companies/MSFT/AI Research Packet.json|MSFT/AI Research Packet.json]]
- [[04_Companies/MSFT/Financial Observations.csv|MSFT/Financial Observations.csv]]
- [[04_Companies/NVDA/AI Research Packet.json|NVDA/AI Research Packet.json]]
- [[04_Companies/NVDA/Financial Observations.csv|NVDA/Financial Observations.csv]]
