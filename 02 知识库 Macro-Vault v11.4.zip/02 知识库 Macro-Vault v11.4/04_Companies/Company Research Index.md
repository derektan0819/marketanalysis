---
title: "Company Research Index"
tags: [company, index, generated]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# Company Research Index

[[Today Dashboard|今日看板]] · [[HOME|首页]]

这是已建立档案的研究名单，不是买入推荐。每个入口均使用公司完整路径，避免同名笔记混连。

| 公司 | 一页简报 | 八季数据 | 当前判断 | 历史判断 | 证据与报告 |
|---|---|---|---|---|---|
| [[04_Companies/AMZN/Company Profile\|AMZN]] | [[04_Companies/AMZN/Latest Brief\|简报]] | [[04_Companies/AMZN/AMZN - Data History\|数据]] | [[04_Companies/AMZN/Current Thesis\|判断]] | [[04_Companies/AMZN/Thesis History\|历史]] | [[04_Companies/AMZN/Evidence Index\|证据]] |
| [[04_Companies/GOOGL/Company Profile\|GOOGL]] | [[04_Companies/GOOGL/Latest Brief\|简报]] | [[04_Companies/GOOGL/GOOGL - Data History\|数据]] | [[04_Companies/GOOGL/Current Thesis\|判断]] | [[04_Companies/GOOGL/Thesis History\|历史]] | [[04_Companies/GOOGL/Evidence Index\|证据]] |
| [[04_Companies/JPM/Company Profile\|JPM]] | [[04_Companies/JPM/Latest Brief\|简报]] | [[04_Companies/JPM/JPM - Data History\|数据]] | [[04_Companies/JPM/Current Thesis\|判断]] | [[04_Companies/JPM/Thesis History\|历史]] | [[04_Companies/JPM/Evidence Index\|证据]] |
| [[04_Companies/MSFT/Company Profile\|MSFT]] | [[04_Companies/MSFT/Latest Brief\|简报]] | [[04_Companies/MSFT/MSFT - Data History\|数据]] | [[04_Companies/MSFT/Current Thesis\|判断]] | [[04_Companies/MSFT/Thesis History\|历史]] | [[04_Companies/MSFT/Evidence Index\|证据]] |
| [[04_Companies/NVDA/Company Profile\|NVDA]] | [[04_Companies/NVDA/Latest Brief\|简报]] | [[04_Companies/NVDA/NVDA - Data History\|数据]] | [[04_Companies/NVDA/Current Thesis\|判断]] | [[04_Companies/NVDA/Thesis History\|历史]] | [[04_Companies/NVDA/Evidence Index\|证据]] |
