---
title: "给 AI 的统一入口"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [ai, entry]
---
# 给 AI 的统一入口

[[HOME|首页]] · [[Research Protocol|唯一研究流程]] · [[One Page Research Brief|固定输出格式]] · [[Readable Report Example|虚构格式示例]]

## 用户每次复制这一段

> 请先实际读取这个仓库的 AI START HERE.md，再读取 15_System/Research Protocol.md、05_Templates/One Page Research Brief.md，以及本次对象的 Current Thesis、Current Research State（如有）和上一份简报。遵守 MV-11.3 流程：核实事件与时间 → 区分事实和解释 → 逐段说明影响谁、如何一步步传导、何时体现、什么会阻断、看什么验证，必要时给明确标注的假设例子 → 给出有条件的未来情景和失效信号 → 对照旧判断解释变化。使用固定的七段格式；“为什么”和“后续影响”用连贯短段落详细解释，不只写“利空／承压”等结论。用中文把原因、影响和未来走向讲清楚。相同资料不得无理由翻转判断；发现旧判断错误可以修正，但要写出错误和证据。优先免费公开资料，不开通收费服务。没有行情、共识或因果证据时明确限制，不编造跌幅、超预期或概率。先确认你实际能读取哪些文件；没有读取原文的内容不得声称已核验。涉及美债、收益率、曲线、拍卖或利率传导时，还须实际读取 10_Playbooks/US Treasury Research Playbook.md，并从 21_US_Treasuries/US Treasury Knowledge Map.md 选读相关笔记；区分债价与收益率、政策短率与长端、美元回报与 MYR 回报。分析对象和问题：〔填公司／事件／问题〕。

方括号提示是普通文字，复制时换成具体问题。若只上传 ZIP，请 AI 先解压并确认读到了正文；仅看到文件名不算读取成功。

## AI 的读取顺序

1. 本入口和 [[Research Protocol]]。
2. [[One Page Research Brief]]；首次使用可读 [[Readable Report Example]]，示例全部虚构，不能当成真实行情。
3. 目标公司的 Current Thesis、Current Research State.json（存在时）、Latest Brief 和八季数据；从 [[Company Research Index]] 找到完整路径。
4. 行业检查表、财报原文、计算输入及本次事件资料。只检索与问题有关的主题，不把全库塞入一次上下文。
5. 输出前按 [[Research Protocol#发布前核对]] 检查，再输出固定报告；不要先写结论再寻找支持。

## 开始时用一句话确认

“本次按 MV-11.3；对象为……；资料截止……；读取了……；行情／共识／宏观可用情况为……；与……版本比较。”

不能读取文件时，说明缺少哪些文件；不能联网时，用明确截止的旧资料做回顾，不冒充今天的研究。新对话要带上最新仓库或上一份研究记录，不能依赖 AI 跨会话记得过去。

## 手动分析后的保存

若有写入权限：把本次报告保存成新的日期／版本文件，先保存旧判断，再更新 Current Thesis；保留相同对象、期限、资料截止、主要结论、变更原因和来源。

若没有写入权限：明确“尚未写入 Obsidian”，提供可保存的 Markdown 报告和一段更新记录。自动程序使用的 Current Research State.json 由程序在输出通过检查后生成，不要求用户手填。下次手动分析时，直接提供这次报告也能比较旧判断。

普通聊天只能通过指令和记录约束行为；无法保证任意 AI 每次都服从。随包程序另有格式、引用和一致性检查，也不能证明全部因果解释正确。

## 美债主题读取

[[21_US_Treasuries/US Treasury Knowledge Map|美债总览]] → [[10_Playbooks/US Treasury Research Playbook|研究步骤]] → 对应债种／驱动笔记 → 当次真实来源。知识页不是今日数据；来源无法访问时明确限制。公司 packet 内嵌总览与研究流程，但不会内嵌整个专题；只能读取 packet 的 AI 不得声称已经读完链接目标。

仓库版本 v11.4；研究协议继续使用 MV-11.3。美债新增模块不要求你改变没有新证据的旧判断。
