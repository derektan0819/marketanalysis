---
title: "Financial Statements 三大财务报表"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [三大财务报表]
tags: [fundamentals]
---
# Financial Statements 三大财务报表

## Definition 定义
The income statement shows profit over a period; the balance sheet shows assets, liabilities and equity at a point in time; the cash flow statement shows cash from operating, investing and financing activities.
利润表显示一段时期的盈利；资产负债表显示某一时点的资产、负债和权益；现金流量表显示经营、投资和融资活动的现金。

## Market impact 市场影响
Markets react to changes in growth, margins, cash and balance-sheet strength. Read all three together, not only the headline profit.
市场反应的是增长、利润率、现金和资产负债表实力的变化。三张表要一起看，不能只看盈利数字。

## Related 相关
[[Profitability Ratios]], [[Cash Flow and FCF]], [[Leverage and Coverage]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Calculation and evidence discipline / 计算与证据规范
- Define the metric, formula, unit, reporting period and accounting basis before comparing companies or quarters.
- Prefer the issuer's official filing/release and reconcile derived values to reported values where possible.
- Keep GAAP and adjusted figures separate; identify adjustments and do not assume adjusted metrics are comparable across issuers.
- Use like-for-like periods and disclose restatements, acquisitions/disposals, discontinued operations and material one-offs.
- Cite inputs to all calculated ratios and record formula in the report's calculation ledger. See [[Data Dictionary and Schema]] and [[Publication Gate]].
