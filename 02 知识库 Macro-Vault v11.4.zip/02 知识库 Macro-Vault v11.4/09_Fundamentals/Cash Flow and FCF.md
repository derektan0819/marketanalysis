---
title: "Cash Flow and FCF 现金流与自由现金流"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [现金流与自由现金流]
tags: [fundamentals]
---
# Cash Flow and FCF 现金流与自由现金流

## Definition 定义
Free cash flow (FCF) = operating cash flow − capital expenditure.
自由现金流（FCF）= 经营现金流 − 资本开支。

## Market impact 市场影响
Profit without cash is a warning. Capex-heavy businesses (chips, data centres) need strong FCF or rely on debt to grow.
有利润没现金是警示信号。资本开支重的行业（芯片、数据中心）需要强劲的自由现金流，否则要靠借债增长。

## Related 相关
[[Financial Statements]], [[Capex Cycle]], [[Leverage and Coverage]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Calculation and evidence discipline / 计算与证据规范
- Define the metric, formula, unit, reporting period and accounting basis before comparing companies or quarters.
- Prefer the issuer's official filing/release and reconcile derived values to reported values where possible.
- Keep GAAP and adjusted figures separate; identify adjustments and do not assume adjusted metrics are comparable across issuers.
- Use like-for-like periods and disclose restatements, acquisitions/disposals, discontinued operations and material one-offs.
- Cite inputs to all calculated ratios and record formula in the report's calculation ledger. See [[Data Dictionary and Schema]] and [[Publication Gate]].
