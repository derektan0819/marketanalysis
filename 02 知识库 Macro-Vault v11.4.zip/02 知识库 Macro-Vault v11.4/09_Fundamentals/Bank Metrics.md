---
title: "Bank Metrics 银行关键指标"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [银行关键指标]
tags: [fundamentals]
---
# Bank Metrics 银行关键指标

## Definition 定义
NIM (net interest margin), NPL ratio (non-performing loans), loan loss coverage, CET1 (core capital ratio), CASA ratio (current and savings deposits), cost-to-income ratio and ROE.
NIM（净息差）、NPL 比率（不良贷款）、贷款损失覆盖率、CET1（核心资本充足率）、CASA 比率（活期和储蓄存款）、成本收入比和 ROE。

## Market impact 市场影响
NIM follows the rate path, NPL and provisions reveal the health of borrowers, and CET1 limits dividends and growth. These are what move bank stocks on results.
NIM 随利率路径变化，NPL 和拨备反映借款人健康状况，CET1 限制派息和增长。这些是财报时推动银行股的关键。

## Related 相关
[[US Banks]], [[Bank Earnings to Market]], [[Federal Funds Rate]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Calculation and evidence discipline / 计算与证据规范
- Define the metric, formula, unit, reporting period and accounting basis before comparing companies or quarters.
- Prefer the issuer's official filing/release and reconcile derived values to reported values where possible.
- Keep GAAP and adjusted figures separate; identify adjustments and do not assume adjusted metrics are comparable across issuers.
- Use like-for-like periods and disclose restatements, acquisitions/disposals, discontinued operations and material one-offs.
- Cite inputs to all calculated ratios and record formula in the report's calculation ledger. See [[Data Dictionary and Schema]] and [[Publication Gate]].
