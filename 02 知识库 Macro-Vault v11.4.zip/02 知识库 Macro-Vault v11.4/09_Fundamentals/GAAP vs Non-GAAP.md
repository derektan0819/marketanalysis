---
title: "GAAP vs Non-GAAP GAAP与非GAAP"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [GAAP与非GAAP]
tags: [fundamentals]
---
# GAAP vs Non-GAAP GAAP与非GAAP

## Definition 定义
GAAP follows US accounting standards. Non-GAAP (adjusted) figures exclude items such as stock-based compensation, restructuring or one-off charges; companies must reconcile the two.
GAAP 遵循美国会计准则。非 GAAP（调整后）数字会剔除股权激励、重组或一次性费用等项目；公司必须对两者进行调节说明。

## Market impact 市场影响
Headlines and consensus usually use adjusted figures. Large gaps between GAAP and adjusted profit deserve scrutiny.
新闻标题和一致预期通常使用调整后数字。GAAP 与调整后利润差距很大时需要仔细审视。

## Related 相关
[[Earnings Quality]], [[SEC Filings and Earnings Release]], [[Consensus and Expectations]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Calculation and evidence discipline / 计算与证据规范
- Define the metric, formula, unit, reporting period and accounting basis before comparing companies or quarters.
- Prefer the issuer's official filing/release and reconcile derived values to reported values where possible.
- Keep GAAP and adjusted figures separate; identify adjustments and do not assume adjusted metrics are comparable across issuers.
- Use like-for-like periods and disclose restatements, acquisitions/disposals, discontinued operations and material one-offs.
- Cite inputs to all calculated ratios and record formula in the report's calculation ledger. See [[Data Dictionary and Schema]] and [[Publication Gate]].
