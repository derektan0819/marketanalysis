---
title: "SEC Filings and Earnings Release SEC文件与财报发布"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [SEC文件与财报发布]
tags: [fundamentals]
---
# SEC Filings and Earnings Release SEC文件与财报发布

## Definition 定义
US companies file annual reports (10-K), quarterly reports (10-Q) and event reports (8-K, which carries the earnings press release) on the SEC's EDGAR system. Earnings call transcripts add management commentary.
美国公司在 SEC 的 EDGAR 系统提交年报（10-K）、季报（10-Q）和事件报告（8-K，财报新闻稿即通过它提交）。业绩电话会记录补充了管理层的说明。

## Market impact 市场影响
Read the press release first for numbers and guidance, then the call for tone and the Q&A, then the 10-Q or 10-K for detail on risks, segments and cash flow.
先看新闻稿了解数字和指引，再看电话会了解语气和问答，最后看 10-Q 或 10-K 了解风险、分部和现金流细节。

## Related 相关
[[Earnings Day Mechanics]], [[GAAP vs Non-GAAP]], [[Financial Statements]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Calculation and evidence discipline / 计算与证据规范
- Define the metric, formula, unit, reporting period and accounting basis before comparing companies or quarters.
- Prefer the issuer's official filing/release and reconcile derived values to reported values where possible.
- Keep GAAP and adjusted figures separate; identify adjustments and do not assume adjusted metrics are comparable across issuers.
- Use like-for-like periods and disclose restatements, acquisitions/disposals, discontinued operations and material one-offs.
- Cite inputs to all calculated ratios and record formula in the report's calculation ledger. See [[Data Dictionary and Schema]] and [[Publication Gate]].

## Evidence handling checklist
- Record the exact form, filing date, accession/document and relevant Item/table.
- For 8-K earnings releases, check the attached exhibit; do not assume every 8-K is an earnings release.
- Compare the press release with the 10-Q/10-K when available; explain differences in presentation or later amendments.
- Use XBRL/company facts as a structured aid, not as an unquestioned answer: verify concept, unit, duration/instant context, dimensions, period and filing accession.
- Investor presentations and call transcripts can contain non-GAAP metrics and forward-looking statements; label them accordingly.
- Source: [SEC EDGAR Search](https://www.sec.gov/edgar/search/) · [SEC API Documentation](https://www.sec.gov/edgar/sec-api-documentation).
- Related: [[Source Registry]], [[Citation and Evidence Standard]], [[Publication Gate]].
