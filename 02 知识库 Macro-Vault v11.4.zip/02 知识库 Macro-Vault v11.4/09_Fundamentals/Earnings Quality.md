---
title: "Earnings Quality 盈利质量"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [盈利质量]
tags: [fundamentals]
---
# Earnings Quality 盈利质量

## Definition 定义
Assesses whether profit comes from repeatable core operations or from one-offs, accounting changes, stock-based compensation, or timing of revenue and working capital.
判断盈利来自可持续的核心业务，还是来自一次性项目、会计变更、股权激励或收入与营运资金的时间差。

## Market impact 市场影响
Clean beats from core operations move stocks more durably than beats driven by one-offs.
来自核心业务的“干净”超预期，比靠一次性项目的超预期更能持久推动股价。

## Related 相关
[[Profitability Ratios]], [[Cash Flow and FCF]], [[GAAP vs Non-GAAP]], [[Consensus and Expectations]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Calculation and evidence discipline / 计算与证据规范
- Define the metric, formula, unit, reporting period and accounting basis before comparing companies or quarters.
- Prefer the issuer's official filing/release and reconcile derived values to reported values where possible.
- Keep GAAP and adjusted figures separate; identify adjustments and do not assume adjusted metrics are comparable across issuers.
- Use like-for-like periods and disclose restatements, acquisitions/disposals, discontinued operations and material one-offs.
- Cite inputs to all calculated ratios and record formula in the report's calculation ledger. See [[Data Dictionary and Schema]] and [[Publication Gate]].
