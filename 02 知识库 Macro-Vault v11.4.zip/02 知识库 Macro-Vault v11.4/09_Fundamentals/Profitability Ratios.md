---
title: "Profitability Ratios 盈利能力指标"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [盈利能力指标]
tags: [fundamentals]
---
# Profitability Ratios 盈利能力指标

## Definition 定义
Gross margin = (revenue − cost of sales) / revenue; operating margin = operating profit / revenue; net margin = net profit / revenue; ROE = net profit / shareholders' equity.
毛利率 =（收入 − 销货成本）/ 收入；营业利润率 = 营业利润 / 收入；净利率 = 净利润 / 收入；ROE = 净利润 / 股东权益。

## Market impact 市场影响
Margin trends show pricing power and cost control. Rising revenue with falling margins is a warning sign.
利润率趋势反映定价能力和成本控制。收入上升但利润率下降是警示信号。

## Related 相关
[[Financial Statements]], [[Earnings Quality]], [[Valuation Multiples]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Calculation and evidence discipline / 计算与证据规范
- Define the metric, formula, unit, reporting period and accounting basis before comparing companies or quarters.
- Prefer the issuer's official filing/release and reconcile derived values to reported values where possible.
- Keep GAAP and adjusted figures separate; identify adjustments and do not assume adjusted metrics are comparable across issuers.
- Use like-for-like periods and disclose restatements, acquisitions/disposals, discontinued operations and material one-offs.
- Cite inputs to all calculated ratios and record formula in the report's calculation ledger. See [[Data Dictionary and Schema]] and [[Publication Gate]].
