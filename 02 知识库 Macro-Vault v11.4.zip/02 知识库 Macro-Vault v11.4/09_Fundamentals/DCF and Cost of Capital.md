---
title: "DCF and Cost of Capital 现金流折现与资本成本"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [现金流折现, DCF, WACC, 资本成本]
tags: [fundamentals, valuation]
as_of: 2026-10
---
# DCF and Cost of Capital 现金流折现与资本成本

## Definition 定义
A discounted cash flow (DCF) model values a business as the present value of its forecast free cash flows plus a terminal value. The discount rate is usually the weighted average cost of capital (WACC).
现金流折现（DCF）模型把企业价值看作预测自由现金流加终值的现值，折现率通常是加权平均资本成本（WACC）。

## Mechanism and market impact 机制与市场影响
- Steps: forecast free cash flow ([[Cash Flow and FCF]]), choose a discount rate, estimate terminal value, then discount and sum. 步骤：预测自由现金流、选折现率、估终值、折现求和。
- WACC = E/V × cost of equity + D/V × cost of debt × (1 − tax rate). Cost of equity can come from CAPM: risk-free rate + beta × equity risk premium ([[Equity Risk Premium]]). WACC 与 CAPM 公式见左。
- Terminal value often makes up most of the value, so small changes in the growth or discount rate move the result a lot; always show a sensitivity table. 终值常占大部分价值，必须做敏感性分析。
- Rate link: higher risk-free rates raise discount rates and lower present values, especially for long-duration growth firms ([[Duration and Convexity]], [[Treasury Yield to Equity Valuation]]). 无风险利率上升会压低现值。
- Cross-check with multiples ([[Valuation Multiples]]) and check that forecasts match the company's reported results ([[Earnings Quality]]). 与估值倍数交叉验证。

## Related 相关
[[Valuation Multiples]], [[Cash Flow and FCF]], [[Equity Risk Premium]], [[Duration and Convexity]], [[Profitability Ratios]], [[Leverage and Coverage]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).
- A DCF is only as good as its inputs; label forecasts `[INFERENCE]` and the arithmetic `[CALC]`, with formulas and inputs shown.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Spot Forward and Par Yields|平价、零息和远期收益率]]：官方 10 年收益率不等于某一张债的成交收益率。
- [[21_US_Treasuries/Treasury Cross Asset Transmission|美债怎样影响股票、银行、房产、美元和黄金]]：先找收益率变化的来源，再分别解释估值、经营与融资。
