---
title: "Leverage and Coverage 杠杆与偿债能力"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [杠杆与偿债能力]
tags: [fundamentals]
---
# Leverage and Coverage 杠杆与偿债能力

## Definition 定义
Net debt / EBITDA measures debt burden; interest coverage = EBIT / interest expense; debt-to-equity compares debt to equity.
净债务 / EBITDA 衡量债务负担；利息覆盖率 = EBIT / 利息支出；负债权益比比较债务与权益。

## Market impact 市场影响
Higher rates hurt highly leveraged firms most. Falling coverage signals stress and tends to widen credit spreads.
利率上升对高杠杆企业伤害最大。覆盖率下降代表压力，往往使信用利差扩大。

## Related 相关
[[Credit Spread]], [[Interest Rates]], [[Cash Flow and FCF]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Calculation and evidence discipline / 计算与证据规范
- Define the metric, formula, unit, reporting period and accounting basis before comparing companies or quarters.
- Prefer the issuer's official filing/release and reconcile derived values to reported values where possible.
- Keep GAAP and adjusted figures separate; identify adjustments and do not assume adjusted metrics are comparable across issuers.
- Use like-for-like periods and disclose restatements, acquisitions/disposals, discontinued operations and material one-offs.
- Cite inputs to all calculated ratios and record formula in the report's calculation ledger. See [[Data Dictionary and Schema]] and [[Publication Gate]].
