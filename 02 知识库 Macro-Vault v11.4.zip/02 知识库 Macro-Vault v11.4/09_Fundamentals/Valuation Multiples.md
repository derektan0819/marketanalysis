---
title: "Valuation Multiples 估值倍数"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [估值倍数]
tags: [fundamentals]
---
# Valuation Multiples 估值倍数

## Definition 定义
P/E = price / earnings per share; EV/EBITDA compares enterprise value to operating earnings; P/B = price / book value (common for banks); PEG adjusts P/E for growth.
P/E = 股价 / 每股盈利；EV/EBITDA 比较企业价值与经营盈利；P/B = 股价 / 每股净资产（银行常用）；PEG 用增长率调整 P/E。

## Market impact 市场影响
Multiples rise when growth expectations rise or rates fall. High-multiple stocks fall more on disappointment.
增长预期上升或利率下降时，估值倍数会上升。高估值股票在令人失望时跌得更多。

## Related 相关
[[Priced In]], [[US 10-Year Treasury Yield]], [[Sector Rotation]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Calculation and evidence discipline / 计算与证据规范
- Define the metric, formula, unit, reporting period and accounting basis before comparing companies or quarters.
- Prefer the issuer's official filing/release and reconcile derived values to reported values where possible.
- Keep GAAP and adjusted figures separate; identify adjustments and do not assume adjusted metrics are comparable across issuers.
- Use like-for-like periods and disclose restatements, acquisitions/disposals, discontinued operations and material one-offs.
- Cite inputs to all calculated ratios and record formula in the report's calculation ledger. See [[Data Dictionary and Schema]] and [[Publication Gate]].

See also [[DCF and Cost of Capital]] for the cash-flow approach.
