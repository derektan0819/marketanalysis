---
title: "Videos 视频资料"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [视频资料, Video Guide, 视频索引]
tags: [guide, video]
---
# Videos 视频资料

Your own video notes live here. Make each one from [[Video Note]] and connect it using [[Video Linking Playbook]]. Raw captures can wait in [[Inbox Guide]] first. 你自己加的视频笔记放这里，按模板建，按流程连接。

## Rules 规则
- Every video note needs a source URL, a date and at least three links into the Vault.
- Video claims are secondary and `unverified` until checked ([[Citation and Evidence Standard]]).
- Conflicts between a video and the Vault are marked `Needs Review`.
- Use `status`: `raw`, `linked`, `verified`, `superseded`.

## Index 索引 (add one row per video 每个视频加一行)
| Date | Speaker / channel | Video note | Markets | Status |
|---|---|---|---|---|
| | | | | |

## Optional: automatic list with Dataview 可选
If you use the Dataview plugin, this query lists every video note. Without the plugin, keep the table above by hand.
```
TABLE speaker_or_channel, published_at, status FROM "18_Videos" WHERE type = "video" SORT published_at DESC
```
