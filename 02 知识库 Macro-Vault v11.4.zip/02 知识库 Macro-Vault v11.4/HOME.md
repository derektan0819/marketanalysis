---
title: "Macro-Vault — 每日研究入口"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
tags: [home]
version: "11.4"
---
# Macro-Vault — 每日研究入口

交给 AI 使用先读 [[AI START HERE]]，效果示例见 [[Readable Report Example]]。

先看 [[Today Dashboard]]：今天发生什么、哪些判断改变、哪里需要复核。

| 我想做什么 | 打开哪里 |
|---|---|
| 按主题浏览全部笔记 | [[00_Index/Master Index\|总索引]] |
| 第一次使用 | [[START HERE]] |
| 让 AI 按固定规则分析 | [[AI START HERE]] · [[Research Protocol]] |
| 看今天研究结果 | [[Today Dashboard]] |
| 看关键疑点 | [[Review Queue]] |
| 看五家重点公司 | [[Company Research Index]] |
| 看未来判断与到期结果 | [[Prediction Log]] |
| 查美债知识与传导 | [[21_US_Treasuries/US Treasury Knowledge Map\|美债知识总览]] |
| 查阅读有没有漏项 | [[Financial Reading Coverage]] |
| 设置 AI 自动分析 | [[AI Adapter Setup]] |
| 设置本地定时运行 | [[Local Scheduling]] |
| 看这版实际验证了什么 | [[Build Verification]] |

研究输出固定为：发生什么、为什么、后续影响、未来情景、观察信号、相对前次变化、证据缺口。允许“维持原判断”和“证据不足”。

[[CLAUDE]] 指向统一的 [[Research Protocol|MV-11.3 规则]]；旧知识用于解释机制，不能充当今天的数据。[[Knowledge Index]] 保存原来的主题索引和版本历史。[[V11 Release Notes]] 记录升级内容。


预测结果汇总：[[Prediction Scorecard]]。

## 链接、证据与历史

[[Obsidian Navigation Guide|如何使用图谱]] · [[Obsidian Link Audit|本次全库检查]] · [[13_Sources/Source Index|原始来源]] · [[14_Reports/Run History Index|历次报告]] · [[V11.1 Release Notes|v11.1 更新]]

本版更新：[[V11.4 Release Notes]] · [[V11.4 Verification]]。

“为什么”和“后续影响”现在逐步解释过程、时间、条件和验证方式，见 [[Readable Report Example]]。

美债专题按“债种 → 定价与久期 → 曲线与供需 → 资金市场 → 跨资产与 MYR 回报”连接；可以从 [[21_US_Treasuries/US Treasury Knowledge Map|总览]] 进入，也可以从原有美债、银行、估值和马币笔记进入。
