---
title: "Prediction Scorecard"
tags: [system, predictions]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# Prediction Scorecard

更新：2026-10-19T07:19:07+00:00。正式前瞻条目：0。已解决：0。
历史 v10 样本不计入；同一预测只取最新结果版本，所有旧结果仍保留。

| 状态 | 数量 |
|---|---:|
| hit | 0 |
| miss | 0 |
| condition_not_met | 0 |
| pending_data | 0 |
| unresolvable | 0 |

命中率：尚无已解决样本
平均 Brier：没有事前概率样本

## 分组记录
| 预测 ID | 领域 | 期限 | 置信度 | 事件群 | 最新结果 |
|---|---|---|---|---|---|

结果是否正确与机制是否得到支持分开；同一事件下的预测相关，不能当独立样本。没有固定的“20条就可靠”门槛。
基准 Brier 只在条目事前保存基准概率与来源时计算，见各 Outcome JSON。尚未计算统计置信区间，不能据此声称预测能力显著优于基准。

<!-- BEGIN GENERATED NAVIGATION -->
[[HOME|首页]] · [[13_Sources/Source Index|来源索引]] · [[14_Reports/Run History Index|运行历史]]
<!-- END GENERATED NAVIGATION -->
