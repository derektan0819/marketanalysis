---
title: "发行、季度再融资与财政部回购"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["发行、季度再融资与财政部回购"]
reviewed_on: 2026-10-19
---
# 发行、季度再融资与财政部回购

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 先分清三件事

财政部发行国债既用于弥补现金赤字，也用于偿还到期债务等融资需要。总发行量包含大量滚动续借，不等于当期新增赤字；净发行量还需扣除到期等项目。季度再融资文件说明融资安排、期限结构和相关计划，不能只读一个总额。

## 为什么长债供给可能影响收益率

假如市场需要吸收更多长期固定利率债，就要承担更多久期风险。如果现有买家不愿按原价接盘，价格需要下降、收益率提高，才能吸引新的承接者。实际反应取决于增量是否已经被预期、养老金等长期需求以及中介承接能力；发行多不等于必然大跌。

发行短债和长债对市场的影响也不同：前者更涉及货币市场资金安排，后者通常向私人部门提供更多久期。新闻写“创纪录发债”时，要分别核对规模、期限和净额。

## 回购为什么不是 QE

财政部 buyback 是债务与现金管理工具，可购买旧券以改善某些券的流动性或调整现金安排。购回证券会被注销，但资金可能来自新发行，所以不等于净债务必定减少。

QE 是美联储改变自身资产负债表的货币政策操作。两者执行主体、资金机制与目的不同；“财政部买债”不能直接改写成“央行放水”。

## 后续观察

把发行日、拍卖日、结算日和到期日分开；观察净久期供给、拍卖结果、TGA 变化与买家结构。长期融资成本变化会逐步进入企业新债和再融资，不会让所有存量固定利率债利息当天一起上涨。

## 关联笔记

[[03_Indicators/Treasury Auctions]] · [[01_Concepts/Fiscal Policy]] · [[01_Concepts/Sovereign Debt and Fiscal Sustainability]] · [[01_Concepts/Term Premium]] · [[01_Concepts/QE and QT]] · [[21_US_Treasuries/Treasury TGA Reserves and RRP]]

## 来源与使用边界

- [TreasuryDirect：拍卖流程](https://www.treasurydirect.gov/auctions/how-auctions-work/)
- [财政部：季度再融资文件](https://home.treasury.gov/policy-issues/financing-the-government/quarterly-refunding/most-recent-quarterly-refunding-documents/)
- [TreasuryDirect：回购 FAQ](https://treasurydirect.gov/help-center/faqs/buyback-faqs/)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Holders and TIC|谁持有美债：TIC 与买家结构]]：持仓减少未必等于抛售，间接投标者也不等于外国政府。
- [[21_US_Treasuries/Treasury TGA Reserves and RRP|TGA、银行准备金与 ON RRP]]：发行美债怎样移动现金，取决于钱原来在哪里。
- [[21_US_Treasuries/Treasury Liquidity and Market Structure|美债流动性、交易商与新旧券]]：低信用风险不保证任何时候都能以理想价格成交。
- [[21_US_Treasuries/Treasury Debt Ceiling and Payment Risk|债务上限、支付风险与财政可持续性]]：把政治支付约束、利率负担和市场价格分开。
- [[21_US_Treasuries/Treasury Misconceptions|美债常见误区检查表]]：生成结论前，先排除这些看似合理的错误。
