---
title: "美债数据源、单位与时间口径"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["美债数据源、单位与时间口径"]
reviewed_on: 2026-10-19
---
# 美债数据源、单位与时间口径

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 先检查数据能不能回答问题

| 要解释的问题 | 首选资料 | 必须留意 |
|---|---|---|
| 收益率与曲线变动 | 财政部利率数据；需要盘中时使用有时间戳的行情来源 | 日度 par curve 不等于盘中某只债成交 |
| 实际利率与通胀补偿 | 财政部实际收益率；Fed TIPS 研究数据 | 期限匹配、拟合方法、修订和流动性影响 |
| 政策路径与期限溢价 | Fed 政策发布、市场隐含路径、NY Fed 模型 | 模型估计不是直接观测；期货不是无条件预测 |
| 拍卖与供给 | TreasuryDirect 结果、季度再融资文件 | 同类期限、发行量、WI 时点；不要凭空编 tail |
| 抵押融资与现金流 | NY Fed SOFR；Fed 负债数据 | 隔夜利率不是长债收益率；日期和频率一致 |
| 外国持仓 | TIC | 滞后、托管偏差、价格变动、修订 |
| ETF 回报 | 发行人文件、净值、分配与成交数据 | 总回报与价格回报分开；费用及汇率对冲 |

下方来源是定义与数据入口，**没有自动安装数据连接，也没有在本页填入“今日行情”**。FRED 可作为分发和核对入口，但采用某个 series 前必须确认该 series 的原始来源、频率、单位与更新时间。免费网页、付费实时报价和官方日度数据不是同一服务。

## 每个观测的最小记录

保存 instrument / CUSIP 或 series_id、tenor、value、unit、currency、observation_time、时区、publication_time、retrieved_at、source_url、price_basis、frequency、是否修订。事件前后比较使用可对齐的时间窗口，不把美国收盘与亚洲次日盘中混成同一时刻。

收益率 4.00% → 4.25% 是 +25 bp，即 +0.25 个百分点；不是上涨 25%。债券价格百分比变化与收益率 bp 变化必须分别写。TIPS 和名义债同期限的比较，也不应把不同数据拟合口径的残差当成精准通胀预期。

## AI 读取失败怎么办

明确列出缺项：比如只有日度曲线，缺少公告前分钟行情，便不能判断某新闻是否造成盘中跳动；只有拍卖结果，没有当时 WI，就不能计算 tail。保留“机制分析”和有条件情景，但不补造事实、时间戳或概率。

## 关联笔记

[[13_Sources/Source Registry]] · [[03_Indicators/US 10-Year Treasury Yield]] · [[03_Indicators/Treasury Auctions]] · [[03_Indicators/MOVE Index]] · [[21_US_Treasuries/Treasury Real Yields and Breakevens]] · [[21_US_Treasuries/Treasury Holders and TIC]]

## 来源与使用边界

- [财政部：利率数据入口](https://home.treasury.gov/resource-center/data-chart-center/interest-rates)
- [财政部：收益率曲线方法](https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology)
- [美联储：TIPS 曲线与通胀补偿](https://www.federalreserve.gov/data/tips-yield-curve-and-inflation-compensation.htm)
- [纽约联储：SOFR 定义](https://www.newyorkfed.org/markets/reference-rates/sofr)
- [美联储：资产负债表负债端](https://www.federalreserve.gov/monetarypolicy/bst_frliabilities.htm)
- [TreasuryDirect：拍卖流程](https://www.treasurydirect.gov/auctions/how-auctions-work/)
- [财政部：季度再融资文件](https://home.treasury.gov/policy-issues/financing-the-government/quarterly-refunding/most-recent-quarterly-refunding-documents/)
- [财政部：TIC 持仓估算与限制](https://home.treasury.gov/data/treasury-international-capital-tic-system-home-page/help-files/estimating-holdings-of-treasury-securities)
- [纽约联储：拆解国债市场信号](https://www.newyorkfed.org/newsevents/speeches/2023/per231116)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。
