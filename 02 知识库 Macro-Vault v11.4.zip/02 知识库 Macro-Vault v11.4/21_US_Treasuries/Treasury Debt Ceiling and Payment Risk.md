---
title: "债务上限、支付风险与财政可持续性"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["债务上限、支付风险与财政可持续性"]
reviewed_on: 2026-10-19
---
# 债务上限、支付风险与财政可持续性

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 三个不同问题

赤字是某段时间支出与收入的差额；债务存量是累积的负债；债务上限是法律对相关举债规模的限制。提高上限不是当场批准一笔等额新支出。政府停摆涉及拨款授权，也不能直接等同于国债已违约。

## 为什么短债也可能出现特殊风险溢价

若市场担忧某段日期的付款或现金安排，接近该窗口到期的 Bill 可能需要更高收益率才有人愿意持有。这是特定日期的支付与流动性风险，不能仅凭它推断所有长期债会同方向变动。X-date 之类估计必须来自当时官方资料，不能沿用旧新闻日期。

## 财政压力怎样逐步传导

新增债务或到期债再融资遇上较高利率，会逐步增加财政利息支出；存量固定票息不会全部立即重定价。若投资者进一步担忧通胀、长期供给或政策不确定性，可能要求更高期限补偿，增加后续融资压力。

但债务规模大不等于某天必然违约；增长、税收、支出政策、平均期限和资金需求都影响结果。“能发行本币”也不消除法律、政治、通胀和延迟付款风险。

## 分析与失效条件

先核对官方现金与债务文件，再看相关期限价格。若法律约束解除或现金安排变化，先前对特定付款窗口的担忧可能失效；长期财政论点则需另外更新。不要混成一句“美国没钱了”。

## 关联笔记

[[01_Concepts/Sovereign Debt and Fiscal Sustainability]] · [[01_Concepts/Fiscal Policy]] · [[21_US_Treasuries/Treasury Supply Refunding and Buybacks]] · [[21_US_Treasuries/Treasury Bills and Discount Yield]] · [[21_US_Treasuries/Treasury TGA Reserves and RRP]]

## 来源与使用边界

- [财政部：债务上限](https://home.treasury.gov/policy-issues/financial-markets-financial-institutions-and-fiscal-service/debt-limit)
- [财政部：季度再融资文件](https://home.treasury.gov/policy-issues/financing-the-government/quarterly-refunding/most-recent-quarterly-refunding-documents/)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Misconceptions|美债常见误区检查表]]：生成结论前，先排除这些看似合理的错误。
