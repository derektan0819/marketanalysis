---
title: "美债怎样影响股票、银行、房产、美元和黄金"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["美债怎样影响股票、银行、房产、美元和黄金"]
reviewed_on: 2026-10-19
---
# 美债怎样影响股票、银行、房产、美元和黄金

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 为什么收益率上涨不是统一的“利空”

同样上升 20 bp，可能来自更好的增长、通胀担忧、政策路径变化或期限补偿增加。增长改善可能同时上调企业盈利；纯粹折现率上升却未必有盈利补偿。因此必须先拆驱动，再看谁受影响。

### 股票：估值与经营分两条

如果实际折现率上升而未来现金流预期没变，投资者会降低今天愿付的价格，较远期现金流通常更敏感。但若同期订单和盈利预期上调，可能抵消这一影响。应分别核对收益率、盈利预期和估值，而不是用“科技股怕加息”解释所有跌幅。

借款成本则通过新融资和到期再融资逐步影响利润；固定利率、现金充裕的公司与短债集中到期的公司不同。查看债务期限、浮息比例、对冲及现金利息收入。

### 银行、保险与 REITs：资产负债一起看

银行持有债券的市值可能下降，新贷款收益可能提高，存款付息也可能上涨；存款外流若迫使卖债，原本的市值损失可能转成已实现损失。会计分类影响呈现，但不消除经济风险。最终还要看信用损失和对冲。

保险机构的资产收益与长期负债折现会同时变化，不能只盯债券资产账面亏损。REITs 要看续借成本、资本化率、租金和到期分布；长期固定债务可能暂缓利息压力。

### 房贷、美元、黄金与新兴市场

房贷利率不仅受国债基准影响，还含 MBS 与贷款利差；基准下降时，利差扩大可能抵消部分降幅。美元更受相对利差、增长和避险资金共同影响，美债收益率升不保证美元一定升。

黄金没有票息，实际利率提高会增加持有它的机会成本；但避险、通胀或其他需求可能抵消。美元融资变贵还可能压迫部分新兴市场借款人，影响要结合美元负债、储备和本币收入。

## 什么时候能作未来判断

市场价格可先反应，利息费用和需求可能数季后才体现。每条路径注明哪一步有证据、哪一步只是推断、何时观察、什么会阻断。缺少同窗口行情时，只分析机制，不声称已解释当天涨跌。

## 关联笔记

[[02_Transmission/Treasury Yield to Equity Valuation]] · [[09_Fundamentals/DCF and Cost of Capital]] · [[08_Sectors/US Banks]] · [[08_Sectors/Real Estate and REITs]] · [[08_Sectors/Insurance and Asset Managers]] · [[08_Sectors/US Big Tech]] · [[01_Concepts/US Consumer and Housing]] · [[02_Transmission/Dollar and Real Yields to Gold and Crypto]] · [[02_Transmission/Dollar Funding Stress to Emerging Markets]] · [[21_US_Treasuries/Treasury Real Yields and Breakevens]]

## 来源与使用边界

- [纽约联储：拆解国债市场信号](https://www.newyorkfed.org/newsevents/speeches/2023/per231116)
- [FINRA：久期与利率敏感度](https://syndication.finra.org/content/duration-what-interest-rate-hike-could-do-your-bond-portfolio)
- [美联储：TIPS 曲线与通胀补偿](https://www.federalreserve.gov/data/tips-yield-curve-and-inflation-compensation.htm)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Scenario Worked Examples|美债因果解释示例：怎样写得看懂]]：示范逐步解释与条件判断，所有事件和数字均为虚构。
