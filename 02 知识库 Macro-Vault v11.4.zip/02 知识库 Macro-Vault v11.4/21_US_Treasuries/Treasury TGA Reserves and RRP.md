---
title: "TGA、银行准备金与 ON RRP"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["TGA、银行准备金与 ON RRP"]
reviewed_on: 2026-10-19
---
# TGA、银行准备金与 ON RRP

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 三种余额先分开

TGA 是财政部在美联储的账户；银行准备金是银行在美联储的余额；ON RRP 是美联储隔夜逆回购安排相关的负债。它们不是同一笔“市场现金”的三个名字。

## 为什么 TGA 补库可能抽走准备金

在其他项目不变时，投资者用银行存款付款买新债，资金最终进入 TGA，相关银行准备金减少。财政部之后向私人部门支出，TGA 减少，收款银行的准备金又增加。这里关键是收付款与结算的路径，不是公告发出的一瞬间。

如果货币基金原先把钱放在 ON RRP，后来转去买短债，资金来源不同，准备金的净变化可能与单纯从银行存款付款不同。因此“新发 1 美元国债＝抽走 1 美元银行准备金”不是普遍公式。

## 后续影响为什么不确定

准备金变化可能影响融资市场，但银行是否愿意扩张信用还受资本、负债稳定性、需求和风险限制。股票价格还受盈利与估值影响；不能把 TGA、RRP 与美联储总资产机械相减后，直接称作必然流入股市的资金。

## 应核对什么

同时记录美联储资产、TGA、RRP、准备金和流通现金的变化，保持频率和日期一致。QT 的到期不续作与主动卖债要分开；财政支出、税期、债券结算和其他负债变化会共同决定准备金结果。

## 关联笔记

[[01_Concepts/Fed Balance Sheet]] · [[01_Concepts/QE and QT]] · [[01_Concepts/Liquidity]] · [[21_US_Treasuries/Treasury Repo SOFR and Collateral]] · [[21_US_Treasuries/Treasury Supply Refunding and Buybacks]]

## 来源与使用边界

- [美联储：资产负债表负债端](https://www.federalreserve.gov/monetarypolicy/bst_frliabilities.htm)
- [纽约联储：SOFR 定义](https://www.newyorkfed.org/markets/reference-rates/sofr)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Supply Refunding and Buybacks|发行、季度再融资与财政部回购]]：不仅看发多少债，还要看期限、到期偿还与谁来承接。
- [[21_US_Treasuries/Treasury Repo SOFR and Collateral|Repo、SOFR 与美债抵押品]]：美债既是投资品，也是借美元时常用的抵押品。
- [[21_US_Treasuries/Treasury Debt Ceiling and Payment Risk|债务上限、支付风险与财政可持续性]]：把政治支付约束、利率负担和市场价格分开。
