---
title: "马来西亚投资者：美元美债与 MYR 回报"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["马来西亚投资者：美元美债与 MYR 回报"]
reviewed_on: 2026-10-19
---
# 马来西亚投资者：美元美债与 MYR 回报

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 先统一汇率方向

这里 S 定义为“1 美元能兑换多少 MYR”，与 USD/MYR 报价方向一致。在期初全部换汇、期末全部换回、期间现金按同一美元回报口径计入的简化情况下：

$$1+R_{MYR}=(1+R_{USD})\times S_1/S_0$$

**假设示例：**美元总回报 +5%，美元对 MYR 贬值 8%，则 MYR 总回报为 1.05 × 0.92 − 1 = −3.4%，未计换汇价差、税与费用。若中途多次换汇或支取，必须按实际现金流日期计算，不能只套期初期末公式。

## 为什么汇率对冲也不是免费消除风险

对冲合约价格会反映利差等因素，还涉及展期、成本与敞口匹配。基金写着某币种份额不一定已经对冲；要查 hedged 标识、对冲目标与实际政策。用融资买债还会增加借款利率与强平风险。

## 工具、账户与税分别查

TreasuryDirect 的开户资格不代表对所有海外投资者开放；券商是否提供美债、最低金额、托管方式和出入金条件须按身份与所在地确认。本笔记没有替用户开户或购买。

美国税务不能只按“我是马来西亚人”判断，要看是否属于美国税务居民、收入类型、账户文件和相关例外。IRS 对符合条件的非居民 portfolio interest 有排除规定，但不能扩展成“所有美债 ETF 分红都免税”。直接债券利息、基金分配、资本损益和遗产税问题应分别核实。

马来西亚端则核对税务居民身份、所得性质、是否汇入以及届时适用规则；本文不预设所有境外收入免税，也不替用户填入税率。做实际税后比较时，从 IRS、LHDN 和产品税务文件取得当期依据，缺少就标记未计算。

## 分析结论应同时给出

美元资产本身的收益驱动、MYR 汇率影响、净费用与税务缺口。若未来支出本来就是美元，汇率对目标的影响与必须换回 MYR 的投资者不同。

## 关联笔记

[[11_Malaysia/Strong USD to Ringgit]] · [[03_Indicators/USD-MYR]] · [[01_Concepts/Exchange Rate]] · [[21_US_Treasuries/Treasury Funds and Direct Bonds]] · [[21_US_Treasuries/Treasury Return Drivers and Portfolio Roles]]

## 来源与使用边界

- [IRS：非居民收入排除条件](https://www.irs.gov/individuals/international-taxpayers/nonresident-aliens-exclusions-from-income)
- [SEC Investor.gov：ETF](https://www.investor.gov/introduction-investing/investing-basics/investment-products/mutual-funds-and-exchange-traded-2)
- [TreasuryDirect：可交易国债种类](https://www.treasurydirect.gov/marketable-securities/)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury TIPS Mechanics|TIPS 怎样抗通胀，又为什么会亏损]]：保护本金的通胀调整，与二级市场价格变化是两回事。
- [[21_US_Treasuries/Treasury Funds and Direct Bonds|单只美债、美债 ETF 与现金工具]]：“持有到期”不能原封不动套在普通债券基金上。
- [[21_US_Treasuries/Treasury Return Drivers and Portfolio Roles|美债回报来源、期限匹配与组合用途]]：利息、价格、再投资与汇率都要进入总回报。
- [[21_US_Treasuries/Treasury Scenario Worked Examples|美债因果解释示例：怎样写得看懂]]：示范逐步解释与条件判断，所有事件和数字均为虚构。
