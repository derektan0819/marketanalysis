---
title: "美债知识总览"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [index, treasuries]
aliases: [美债, 美债知识总览, 美国国债知识地图]
---
# 美债知识总览

[[HOME|首页]] · [[Knowledge Index|全库索引]] · [[01_Concepts/US Treasury Market|已有美债基础]] · [[10_Playbooks/US Treasury Research Playbook|AI 分析流程]] · [[05_Templates/US Treasury Research Sheet|研究记录表]]

## 先走这条阅读路线

先认清债种，再理解价格与收益率；接着看久期和曲线，最后把供需、资金市场与股票／汇率影响连起来。不需要每次读完全部笔记，AI 按问题选择相关路径。

原库已有美债市场、10 年收益率、曲线、久期与凸性、实际利率、期限溢价、拍卖和 MOVE；本版保留并连接这些入口，补齐现金流、工具、市场运作与研究方法。这里覆盖核心与常用进阶主题，不声称穷尽所有交易、法律和税务细节。

## 按主题查找

### 基础与定价

| 笔记 | 解决什么问题 |
|---|---|
| [[21_US_Treasuries/Treasury Security Types\|美债有哪些种类]] | 先认清买的是什么，避免把短债、长债和 TIPS 当成同一种资产。 |
| [[21_US_Treasuries/Treasury Cash Flows and Bond Pricing\|票息、价格、收益率与真实回报]] | 解释为什么票息固定，市场价格却每天改变。 |
| [[21_US_Treasuries/Treasury Bills and Discount Yield\|短债 Bill 的折价收益率怎么算]] | 同一张短债可能显示不同年化收益率，先检查分母和日数。 |
| [[21_US_Treasuries/Treasury Clean Price and Settlement\|净价、全价、应计利息与结算]] | 报价不是最终扣款，先把价格和利息拆开。 |
| [[21_US_Treasuries/Treasury DV01 and Key Rate Duration\|久期进阶：DV01 与不同期限的风险]] | 把利率变动换成大致金额，并识别曲线并非一起移动。 |

### 利率与曲线

| 笔记 | 解决什么问题 |
|---|---|
| [[21_US_Treasuries/Treasury Yield Curve Scenarios\|曲线变化：牛陡、熊陡、牛平、熊平]] | 先看哪一端在动，再解释增长、通胀与供给。 |
| [[21_US_Treasuries/Treasury Spot Forward and Par Yields\|平价、零息和远期收益率]] | 官方 10 年收益率不等于某一张债的成交收益率。 |
| [[21_US_Treasuries/Treasury Real Yields and Breakevens\|实际利率、盈亏平衡通胀和期限溢价]] | 同样是 10 年收益率上涨，背后的原因可能完全不同。 |

### 债种细节

| 笔记 | 解决什么问题 |
|---|---|
| [[21_US_Treasuries/Treasury TIPS Mechanics\|TIPS 怎样抗通胀，又为什么会亏损]] | 保护本金的通胀调整，与二级市场价格变化是两回事。 |
| [[21_US_Treasuries/Treasury Floating Rate Notes\|FRN 浮息美债：利率风险较低，收入会变]] | FRN 跟随短债参考利率，不是固定锁住今天的收益。 |
| [[21_US_Treasuries/Treasury STRIPS\|STRIPS 零息拆分债]] | 把每笔未来付款拆成独立证券，会改变现金流与利率敏感度。 |

### 供需与财政

| 笔记 | 解决什么问题 |
|---|---|
| [[21_US_Treasuries/Treasury Supply Refunding and Buybacks\|发行、季度再融资与财政部回购]] | 不仅看发多少债，还要看期限、到期偿还与谁来承接。 |
| [[21_US_Treasuries/Treasury Holders and TIC\|谁持有美债：TIC 与买家结构]] | 持仓减少未必等于抛售，间接投标者也不等于外国政府。 |
| [[21_US_Treasuries/Treasury Debt Ceiling and Payment Risk\|债务上限、支付风险与财政可持续性]] | 把政治支付约束、利率负担和市场价格分开。 |

### 市场运作与资金

| 笔记 | 解决什么问题 |
|---|---|
| [[21_US_Treasuries/Treasury Repo SOFR and Collateral\|Repo、SOFR 与美债抵押品]] | 美债既是投资品，也是借美元时常用的抵押品。 |
| [[21_US_Treasuries/Treasury TGA Reserves and RRP\|TGA、银行准备金与 ON RRP]] | 发行美债怎样移动现金，取决于钱原来在哪里。 |
| [[21_US_Treasuries/Treasury Liquidity and Market Structure\|美债流动性、交易商与新旧券]] | 低信用风险不保证任何时候都能以理想价格成交。 |
| [[21_US_Treasuries/Treasury Futures and Basis Trade\|美债期货、基差交易与杠杆风险]] | 理解市场结构，不把基差收敛当成无风险收益。 |

### 投资工具与本币回报

| 笔记 | 解决什么问题 |
|---|---|
| [[21_US_Treasuries/Treasury Funds and Direct Bonds\|单只美债、美债 ETF 与现金工具]] | “持有到期”不能原封不动套在普通债券基金上。 |
| [[21_US_Treasuries/Treasury Return Drivers and Portfolio Roles\|美债回报来源、期限匹配与组合用途]] | 利息、价格、再投资与汇率都要进入总回报。 |
| [[21_US_Treasuries/Treasury Investing from Malaysia\|马来西亚投资者：美元美债与 MYR 回报]] | 美元赚了利息，换回马币仍可能亏损。 |

### 跨资产与研究

| 笔记 | 解决什么问题 |
|---|---|
| [[21_US_Treasuries/Treasury Cross Asset Transmission\|美债怎样影响股票、银行、房产、美元和黄金]] | 先找收益率变化的来源，再分别解释估值、经营与融资。 |
| [[21_US_Treasuries/Treasury Data Sources and Definitions\|美债数据源、单位与时间口径]] | 知识库告诉 AI 去哪里取数，不等于已经接入行情。 |
| [[21_US_Treasuries/Treasury Misconceptions\|美债常见误区检查表]] | 生成结论前，先排除这些看似合理的错误。 |
| [[21_US_Treasuries/Treasury Scenario Worked Examples\|美债因果解释示例：怎样写得看懂]] | 示范逐步解释与条件判断，所有事件和数字均为虚构。 |

## 已有核心笔记

[[01_Concepts/US Treasury Market]] · [[03_Indicators/US 10-Year Treasury Yield]] · [[01_Concepts/Yield Curve]] · [[01_Concepts/Duration and Convexity]] · [[01_Concepts/Term Premium]] · [[01_Concepts/Real Interest Rates]] · [[03_Indicators/Treasury Auctions]] · [[03_Indicators/MOVE Index]]

## AI 必须保持的边界

实际读取 [[15_System/Research Protocol|MV-11.3 研究协议]]，沿用七段输出。“为什么”和“后续影响”解释中间步骤、对象、时滞、阻断条件和验证指标。把债券价格与收益率、政策短率与长期收益率、公司经营与资产价格分开。

知识模块版本是 v11.4，研究输出协议仍是 MV-11.3；两者职责不同。没有新增实时报价、共识或宏观数据连接。来源入口不是已获取的数据；联网 AI 需自行读取并引用，不能联网则说明截止和缺口。普通聊天不能保证任意模型绝对服从。
