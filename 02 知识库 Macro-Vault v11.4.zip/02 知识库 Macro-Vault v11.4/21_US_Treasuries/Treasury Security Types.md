---
title: "美债有哪些种类"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["美债有哪些种类"]
reviewed_on: 2026-10-19
---
# 美债有哪些种类

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 先懂这一点

美国财政部借美元，承诺按发行条款支付现金。名称中的“安全”不表示价格稳定；不同债种把利率、通胀和现金流风险分配得很不一样。

| 类型 | 现金流特点 | 主要观察点 |
|---|---|---|
| Bills（短期国库券） | 不付定期票息，到期收面值，通常折价买入；原始期限不超过一年 | 买入价格、到期日、到期后的再投资利率 |
| Notes（中期国债） | 固定票息，半年付息；原始期限 2、3、5、7、10 年 | 市场收益率与久期 |
| Bonds（长期国债） | 固定票息，半年付息；原始期限 20、30 年 | 对长期收益率变化的敏感程度 |
| TIPS（抗通胀国债） | 本金随美国 CPI 调整，票息率固定 | 实际收益率、通胀补偿和购买价格 |
| FRN（浮息国债） | 利率定期重设，季度付息；原始期限 2 年 | 短端利率下降后收入也会下降 |
| STRIPS（拆分债） | 把合资格国债的本金、利息分拆为单独到期付款 | 零息、长久期、期间没有现金收入 |

I Bonds / EE Bonds 是储蓄债，不是上述在二级市场流通的国债，也不是 TIPS ETF；不能直接套用交易美债的退出方式。机构债、MBS、市政债和企业美元债亦不等同于财政部国债。

## 为什么种类会影响后续判断

假设市场转向降息：旧固定票息债的现金流没有变，但新债可能提供更低回报，旧债价格因而可能上升。FRN 的现金利息却会随着参考短率下降；短期 Bill 到期后，也可能只能用更低利率再投。三者都叫“美债”，持有人实际得到的结果却不同。

## 使用时先记录

区分原始期限和剩余期限；记录 CUSIP、币种、到期日、票息、买入价格与报价口径。基金另记基金注册地、跟踪范围、久期和是否对冲汇率。没有这些信息，就不能只凭“美债涨了”推断用户持仓的回报。

## 关联笔记

[[01_Concepts/US Treasury Market]] · [[21_US_Treasuries/Treasury Cash Flows and Bond Pricing]] · [[21_US_Treasuries/Treasury Funds and Direct Bonds]] · [[21_US_Treasuries/Treasury TIPS Mechanics]] · [[21_US_Treasuries/Treasury Floating Rate Notes]] · [[21_US_Treasuries/Treasury STRIPS]]

## 来源与使用边界

- [TreasuryDirect：可交易国债种类](https://www.treasurydirect.gov/marketable-securities/)
- [TreasuryDirect：Notes](https://www.treasurydirect.gov/marketable-securities/treasury-notes/)
- [TreasuryDirect：Bonds](https://www.treasurydirect.gov/marketable-securities/treasury-bonds/)
- [TreasuryDirect：Bills](https://www.treasurydirect.gov/marketable-securities/treasury-bills/)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Bills and Discount Yield|短债 Bill 的折价收益率怎么算]]：同一张短债可能显示不同年化收益率，先检查分母和日数。
- [[21_US_Treasuries/Treasury Floating Rate Notes|FRN 浮息美债：利率风险较低，收入会变]]：FRN 跟随短债参考利率，不是固定锁住今天的收益。
- [[21_US_Treasuries/Treasury STRIPS|STRIPS 零息拆分债]]：把每笔未来付款拆成独立证券，会改变现金流与利率敏感度。
- [[21_US_Treasuries/Treasury Funds and Direct Bonds|单只美债、美债 ETF 与现金工具]]：“持有到期”不能原封不动套在普通债券基金上。
