---
title: "Repo、SOFR 与美债抵押品"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["Repo、SOFR 与美债抵押品"]
reviewed_on: 2026-10-19
---
# Repo、SOFR 与美债抵押品

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## Repo 是什么

回购交易（repo）在经济上类似短期抵押融资：交出证券获得现金，约定之后买回。交易对手看到的是同一笔融资的反方向。抵押品折扣 haircut 表示借到的钱少于抵押物价值，用来吸收风险，不是国债票息。

SOFR 是纽约联储根据以国债作抵押的隔夜融资交易计算的参考利率，采用成交量加权中位数等方法。它不是美联储目标区间，也不是 10 年收益率。

## 为什么融资紧张会冲击长债

持有人若借隔夜钱持有长期债，需要不断续借。现金成本突然升高、haircut 提高或对手不愿续作，会增加所需现金；若无法补足，可能出售债券，令价格承压。即使发行人信用没有变化，也能出现被动卖压。

某张券特别稀缺时，出借现金的一方可能愿意接受更低 repo 利率来取得该券，称为 special。不能把 special rate 很低误读成全市场现金都充裕。

## 验证与时间

同时看 SOFR、交易量、利率分布、政策操作和日历效应；季末或税期的短暂变化需与持续性资金压力分开。融资压力可在日内传导；实体经济借款的变化通常更慢。单日 SOFR 上升不足以直接宣判金融危机。

## 关联笔记

[[01_Concepts/Liquidity]] · [[17_Bank_Regulation/Secured Lending and Collateral]] · [[21_US_Treasuries/Treasury Futures and Basis Trade]] · [[21_US_Treasuries/Treasury TGA Reserves and RRP]] · [[03_Indicators/Federal Funds Rate]]

## 来源与使用边界

- [纽约联储：SOFR 定义](https://www.newyorkfed.org/markets/reference-rates/sofr)
- [美联储：对冲基金美债与基差交易](https://www.federalreserve.gov/econres/notes/feds-notes/sizing-hedge-funds-treasury-market-activities-and-holdings-20211006.html)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Floating Rate Notes|FRN 浮息美债：利率风险较低，收入会变]]：FRN 跟随短债参考利率，不是固定锁住今天的收益。
- [[21_US_Treasuries/Treasury TGA Reserves and RRP|TGA、银行准备金与 ON RRP]]：发行美债怎样移动现金，取决于钱原来在哪里。
- [[21_US_Treasuries/Treasury Liquidity and Market Structure|美债流动性、交易商与新旧券]]：低信用风险不保证任何时候都能以理想价格成交。
- [[21_US_Treasuries/Treasury Futures and Basis Trade|美债期货、基差交易与杠杆风险]]：理解市场结构，不把基差收敛当成无风险收益。
