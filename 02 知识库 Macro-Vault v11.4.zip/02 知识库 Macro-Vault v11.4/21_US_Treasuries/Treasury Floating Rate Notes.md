---
title: "FRN 浮息美债：利率风险较低，收入会变"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["FRN 浮息美债：利率风险较低，收入会变"]
reviewed_on: 2026-10-19
---
# FRN 浮息美债：利率风险较低，收入会变

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 浮息是怎样重设的

财政部 FRN 原始期限 2 年，季度付息。利率由近期 13 周 Bill 拍卖的最高接受贴现利率这一参考项，加上发行时确定的固定 spread 构成；参考项通常每周重设，利息逐日累计。它不是以 SOFR 为直接参考的企业浮息贷款。

## 为什么价格通常较稳定，收入却会降低

固定票息债遇到市场利率上涨，旧现金流无法提高，只能靠价格下降调整回报。FRN 的利息可较快随参考短率改变，所以纯利率久期通常较低。但降息后，新一期现金收入也会跟着减少，不能同时假设“价格稳定”又“永久保留高息”。

FRN 仍有买卖价差、流动性、参考利率重设时差和市场要求的贴现利差变化；浮息 ETF 还有费用与净值波动。观察实际参考指数、固定 spread、重设日与现金支付日期，不能只看基金最近一次分红年化。

## 关联笔记

[[21_US_Treasuries/Treasury Security Types]] · [[21_US_Treasuries/Treasury Bills and Discount Yield]] · [[01_Concepts/Duration and Convexity]] · [[21_US_Treasuries/Treasury Repo SOFR and Collateral]] · [[21_US_Treasuries/Treasury Funds and Direct Bonds]]

## 来源与使用边界

- [TreasuryDirect：FRN](https://www.treasurydirect.gov/marketable-securities/floating-rate-notes/)
- [FINRA：久期与利率敏感度](https://syndication.finra.org/content/duration-what-interest-rate-hike-could-do-your-bond-portfolio)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Security Types|美债有哪些种类]]：先认清买的是什么，避免把短债、长债和 TIPS 当成同一种资产。
- [[21_US_Treasuries/Treasury Bills and Discount Yield|短债 Bill 的折价收益率怎么算]]：同一张短债可能显示不同年化收益率，先检查分母和日数。
