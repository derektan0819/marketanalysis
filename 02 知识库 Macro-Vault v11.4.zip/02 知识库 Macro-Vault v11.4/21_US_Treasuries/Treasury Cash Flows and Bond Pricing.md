---
title: "票息、价格、收益率与真实回报"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["票息、价格、收益率与真实回报"]
reviewed_on: 2026-10-19
---
# 票息、价格、收益率与真实回报

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 四个数字不能混用

票息率决定按面值支付多少利息；当期收益率是年票息除以当前价格；到期收益率（YTM）是让未来约定现金流的现值等于买价的折现率；持有期总回报则把实际收到的利息、价格变化和费用一起计算。YTM 不是承诺的未来一年涨幅。

对刚付完息、半年付息、剩余 n 个半年期的固定利率债，简化定价为：

$$P=\sum_{t=1}^{n}\frac{F c/2}{(1+y/2)^t}+\frac{F}{(1+y/2)^n}$$

F 为面值，c 为年票息率，y 为同口径 YTM；不含应计利息、费用和税。真实结算需使用正确日数和付息日期。

## 为什么收益率升、旧债价格降

旧债每年付的钱不会因为市场利率上涨而增加。新买家现在可以在类似风险、期限的资产上获得更高回报，因此只有旧债价格降下来，他们才愿意买；价格降低后，同一组未来现金流对应的 YTM 才会上升。这是价格和现金流的数学关系，不能用来证明今天利率变化由哪条新闻引起。

**假设示例，非行情：**面值 100、票息 4%、剩余 5 年、半年付息的债券，若所需 YTM 为 5%，付息日价格约为 95.62。票息仍按每年 4 计算，不能把买入后每年现金收入说成 5。

## 后续影响与限制

提前出售时，卖价影响最终回报；持有到期且如约付款时，拿到的是条款规定的面值与利息，并非无条件退回当初买入价。若溢价买入，价格向面值收敛会抵消一部分票息。

YTM 是现金流内部收益率；要把它实现为全持有期的复合增长率，还涉及中途票息的再投资收益。实际回报还会受税费、通胀和本币汇率影响。读基金时，分红率、30 日 SEC yield、组合 YTM 与总回报也不能互换。

## 关联笔记

[[01_Concepts/US Treasury Market]] · [[01_Concepts/Interest Rates]] · [[01_Concepts/Duration and Convexity]] · [[21_US_Treasuries/Treasury Bills and Discount Yield]] · [[21_US_Treasuries/Treasury Clean Price and Settlement]] · [[21_US_Treasuries/Treasury Return Drivers and Portfolio Roles]]

## 来源与使用边界

- [TreasuryDirect：价格与利率](https://www.treasurydirect.gov/marketable-securities/understanding-pricing/)
- [FINRA：久期与利率敏感度](https://syndication.finra.org/content/duration-what-interest-rate-hike-could-do-your-bond-portfolio)
- [SEC Investor.gov：债券基金](https://www.investor.gov/introduction-investing/investing-basics/glossary/bond-funds-and-income-funds)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Security Types|美债有哪些种类]]：先认清买的是什么，避免把短债、长债和 TIPS 当成同一种资产。
- [[21_US_Treasuries/Treasury Bills and Discount Yield|短债 Bill 的折价收益率怎么算]]：同一张短债可能显示不同年化收益率，先检查分母和日数。
- [[21_US_Treasuries/Treasury Clean Price and Settlement|净价、全价、应计利息与结算]]：报价不是最终扣款，先把价格和利息拆开。
- [[21_US_Treasuries/Treasury Spot Forward and Par Yields|平价、零息和远期收益率]]：官方 10 年收益率不等于某一张债的成交收益率。
- [[21_US_Treasuries/Treasury Funds and Direct Bonds|单只美债、美债 ETF 与现金工具]]：“持有到期”不能原封不动套在普通债券基金上。
- [[21_US_Treasuries/Treasury Misconceptions|美债常见误区检查表]]：生成结论前，先排除这些看似合理的错误。
