---
title: "曲线变化：牛陡、熊陡、牛平、熊平"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["曲线变化：牛陡、熊陡、牛平、熊平"]
reviewed_on: 2026-10-19
---
# 曲线变化：牛陡、熊陡、牛平、熊平

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 两条轴一起看

“牛／熊”通常指债券价格方向，因此牛市对应收益率下降；“陡／平”指长短端利差变化。这里把斜率定义为 10 年收益率减 2 年收益率；换成 10 年减 3 个月，要明确标注，不能拼接。

| 情景 | 典型变化 | 可以检验的解释，不是自动结论 |
|---|---|---|
| 牛陡 | 短端下降更多，利差扩大 | 降息预期升温，可能伴随增长担忧 |
| 熊陡 | 长端上升更多，利差扩大 | 长期通胀补偿、期限溢价或供给压力增加 |
| 牛平 | 长端下降更多，利差收窄 | 长期增长／通胀预期降低，或长期债需求增强 |
| 熊平 | 短端上升更多，利差收窄 | 市场上调近期政策利率路径 |

两端反向移动时，直接写各自变动，别硬塞进单一标签。倒挂代表所选长端收益率低于短端；它是带条件的风险信号，不是衰退倒计时器。

## 为什么解除倒挂也未必利好

假设经济恶化使投资者预期央行更快降息，2 年收益率由 4.5% 降到 4.0%，10 年由 4.3% 降到 4.1%。利差从 −20 bp 变成 +10 bp，曲线变正常，但背景可能是就业和利润走弱。若只写“曲线正常＝经济改善”，就把驱动方向弄反了。

另一个假设是 2 年从 4.5% 到 4.6%，10 年从 4.3% 到 4.8%；利差也扩大，但这次长债价格跌、长期融资更贵。以上数字均为示例。

## 看什么验证

同一时间窗口核对政策路径、实际利率、通胀补偿、期限溢价估计及拍卖消息。银行利润还取决于存款成本、贷款重定价、对冲和信用损失，不能把“更陡”直接换成“银行一定赚更多”。

## 关联笔记

[[01_Concepts/Yield Curve]] · [[01_Concepts/Market-Implied Rate Expectations]] · [[01_Concepts/Term Premium]] · [[08_Sectors/US Banks]] · [[21_US_Treasuries/Treasury Real Yields and Breakevens]]

## 来源与使用边界

- [纽约联储：拆解国债市场信号](https://www.newyorkfed.org/newsevents/speeches/2023/per231116)
- [财政部：收益率曲线方法](https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury DV01 and Key Rate Duration|久期进阶：DV01 与不同期限的风险]]：把利率变动换成大致金额，并识别曲线并非一起移动。
- [[21_US_Treasuries/Treasury Return Drivers and Portfolio Roles|美债回报来源、期限匹配与组合用途]]：利息、价格、再投资与汇率都要进入总回报。
- [[21_US_Treasuries/Treasury Misconceptions|美债常见误区检查表]]：生成结论前，先排除这些看似合理的错误。
