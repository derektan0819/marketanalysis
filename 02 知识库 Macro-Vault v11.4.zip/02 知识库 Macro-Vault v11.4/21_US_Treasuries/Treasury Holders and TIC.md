---
title: "谁持有美债：TIC 与买家结构"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["谁持有美债：TIC 与买家结构"]
reviewed_on: 2026-10-19
---
# 谁持有美债：TIC 与买家结构

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 不同买家为何购买

货币基金重视短期现金管理；银行关注流动性、收益和监管；养老金与保险机构可能匹配长期负债；外国官方机构管理储备；私人机构可能做投资或对冲；美联储持仓还涉及政策操作。需求变化要结合买家的目标与期限。

## TIC 能告诉什么，不能告诉什么

TIC 提供跨境持仓和交易信息，但有发布滞后与修订。按国家列示的托管记录不总等于最终受益人的国籍；通过第三地保管的证券可能计入托管中心。长期债市值也会随价格改变，因此持仓金额下降不能直接全算为净卖出。

假设某类债持仓市值从 100 降为 95，可能包含债价下跌、到期、买卖、托管转移或统计修订。没有交易与估值拆分，就不能说“某国卖了 5，导致今天收益率上涨”。

## 为什么这会影响后续判断

如果原本稳定的买家持续减少新增需求，其他买家可能需要更高收益率才接盘；但单个国家的数据无法代表全球需求，也可能有国内基金接手。应把多期持仓、拍卖、净发行和价格变化交叉验证。

拍卖的 indirect bidders（间接投标者）分类是投标渠道概念，不能直接替代“外国央行”。看份额时也要看发行规模；份额降低不一定代表买入金额下降。

## 关联笔记

[[01_Concepts/Foreign Exchange Reserves and Reserve Currencies]] · [[03_Indicators/Treasury Auctions]] · [[01_Concepts/US Treasury Market]] · [[21_US_Treasuries/Treasury Supply Refunding and Buybacks]] · [[17_Bank_Regulation/Liquidity Rules LCR and NSFR]]

## 来源与使用边界

- [财政部：TIC 持仓估算与限制](https://home.treasury.gov/data/treasury-international-capital-tic-system-home-page/help-files/estimating-holdings-of-treasury-securities)
- [TreasuryDirect：拍卖流程](https://www.treasurydirect.gov/auctions/how-auctions-work/)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Data Sources and Definitions|美债数据源、单位与时间口径]]：知识库告诉 AI 去哪里取数，不等于已经接入行情。
- [[21_US_Treasuries/Treasury Misconceptions|美债常见误区检查表]]：生成结论前，先排除这些看似合理的错误。
