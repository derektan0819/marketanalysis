---
title: "美债流动性、交易商与新旧券"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["美债流动性、交易商与新旧券"]
reviewed_on: 2026-10-19
---
# 美债流动性、交易商与新旧券

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 流动性怎样判断

看 bid–ask spread（买卖价差）、market depth（某一价位可成交数量）和 price impact（交易对价格的冲击）。成交量很大可能同时伴随价格剧烈波动，不能单用成交量认定市场健康。

On-the-run 是某期限最新发行的基准券，off-the-run 是较旧的券；两者在交易活跃度、抵押品需求和融资条件上可能不同。相近到期日并不保证完全相同的收益率。

## 为什么“避险资产”也可能被卖

投资者遇到赎回或追加保证金时，需要的是现金，可能卖掉最容易变现的美债。交易商如果库存和资产负债表空间受限，接盘能力又下降，价格必须让步才能成交。这解释了信用风险没有明显改变时仍可能出现的流动性折价。

融资压力会进一步影响持有成本，出售又影响价格，可能形成反馈。观察到同时下跌只能提出这一假设，仍需融资、价差、深度和资金流证据支持。

## 交易与分析口径

区分交易所期货、场外国债现券和基金份额；集中清算也不意味着价格风险消失。清算范围、实施日期与客户安排是会变化的规则，实际使用时查监管和清算机构最新文件，本笔记不预设某项制度已经全面生效。

## 关联笔记

[[01_Concepts/Liquidity]] · [[03_Indicators/MOVE Index]] · [[21_US_Treasuries/Treasury Clean Price and Settlement]] · [[21_US_Treasuries/Treasury Repo SOFR and Collateral]] · [[21_US_Treasuries/Treasury Futures and Basis Trade]] · [[21_US_Treasuries/Treasury Supply Refunding and Buybacks]]

## 来源与使用边界

- [美联储：对冲基金美债与基差交易](https://www.federalreserve.gov/econres/notes/feds-notes/sizing-hedge-funds-treasury-market-activities-and-holdings-20211006.html)
- [TreasuryDirect：回购 FAQ](https://treasurydirect.gov/help-center/faqs/buyback-faqs/)
- [CME：国债报价](https://www.cmegroup.com/education/courses/introduction-to-treasuries/calculating-us-treasury-pricing)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Clean Price and Settlement|净价、全价、应计利息与结算]]：报价不是最终扣款，先把价格和利息拆开。
- [[21_US_Treasuries/Treasury Futures and Basis Trade|美债期货、基差交易与杠杆风险]]：理解市场结构，不把基差收敛当成无风险收益。
