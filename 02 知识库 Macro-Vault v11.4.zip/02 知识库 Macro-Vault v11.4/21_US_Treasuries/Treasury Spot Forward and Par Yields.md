---
title: "平价、零息和远期收益率"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["平价、零息和远期收益率"]
reviewed_on: 2026-10-19
---
# 平价、零息和远期收益率

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 三条曲线分别回答什么

Par yield（平价收益率）是让假设附息债按面值定价的票息率；spot / zero rate（即期／零息利率）用于折现某一日期的一笔现金流；forward rate（远期利率）是从当前不同期限贴现因子推导出的未来期间利率。

财政部 daily par curve 是根据市场报价拟合出来的曲线点。它提供统一期限比较，不能直接当作你那张剩余 9 年 8 个月债券的可成交价；日度固定期限序列也不等同于盘中行情。

## 为什么远期利率不是预言

用年复利、无摩擦的简化例子：若一年零息利率 3%，两年零息利率 4%，隐含第二年一年期远期利率为 (1.04²/1.03)−1 ≈ 5.010%。这说明今天不同期限价格之间的关系，并不保证一年后能按 5.010% 再投资，也不等于央行预测。

远期值含风险补偿和市场定价因素；不同复利、日数和曲线拟合方法会改变数值。不能拿两个附息债 YTM 直接套零息公式。对公司长期现金流估值时，需要考虑期限匹配和风险溢价，也不能把所有年份都机械使用同一个 10 年率。

## 分析记录

写清 par / spot / forward、名义或实际、期限、单位、数据时点、模型与是否修订。模型研究序列和官方统计发布是不同证据等级。

## 关联笔记

[[03_Indicators/US 10-Year Treasury Yield]] · [[01_Concepts/Yield Curve]] · [[09_Fundamentals/DCF and Cost of Capital]] · [[21_US_Treasuries/Treasury Cash Flows and Bond Pricing]]

## 来源与使用边界

- [财政部：收益率曲线方法](https://home.treasury.gov/policy-issues/financing-the-government/interest-rate-statistics/treasury-yield-curve-methodology)
- [纽约联储：拆解国债市场信号](https://www.newyorkfed.org/newsevents/speeches/2023/per231116)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。
