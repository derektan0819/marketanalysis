---
title: "短债 Bill 的折价收益率怎么算"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["短债 Bill 的折价收益率怎么算"]
reviewed_on: 2026-10-19
---
# 短债 Bill 的折价收益率怎么算

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 为什么屏幕上的收益率可能不同

Bill 通常低于面值买入，到期收回面值，收益来自差额。银行贴现收益率以面值为分母、采用 360 天年化；投资者实际占用的钱是买价，因此“报价 4%”不一定等于资金按买价得到的年化回报。

设面值 F、买价 P、剩余 d 天：贴现收益率为 (F−P)/F × 360/d；持有至到期的期间回报为 (F−P)/P。用 365 天简单年化则为期间回报 × 365/d。后者是便于理解的简单换算，不应冒充所有期限和闰年情形下官方 investment rate 的精确算法。

**假设示例：**182 天后收 1,000，现在付 980。期间赚 20，期间回报约 2.041%；贴现收益率约 3.956%；365 天简单年化约 4.093%。三个数字描述同一笔现金流，没有凭空多赚。

## 后续会怎样

短债价格通常对长端利率变动较不敏感，但到期很快，收入无法长期锁定。若之后降息，再买下一期的利率可能更低；不能把今天某一期的年化数字连续外推十年。到期前出售仍可能有价差和交易成本，现金需要日也必须与结算日匹配。

记录原始价格、面值、天数、年化口径、持有或滚动方式；比较基金时再加入费用与净值变化。

## 关联笔记

[[21_US_Treasuries/Treasury Security Types]] · [[21_US_Treasuries/Treasury Cash Flows and Bond Pricing]] · [[21_US_Treasuries/Treasury Floating Rate Notes]] · [[03_Indicators/Federal Funds Rate]] · [[21_US_Treasuries/Treasury Return Drivers and Portfolio Roles]]

## 来源与使用边界

- [TreasuryDirect：Bills](https://www.treasurydirect.gov/marketable-securities/treasury-bills/)
- [TreasuryDirect：价格与利率](https://www.treasurydirect.gov/marketable-securities/understanding-pricing/)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Cash Flows and Bond Pricing|票息、价格、收益率与真实回报]]：解释为什么票息固定，市场价格却每天改变。
- [[21_US_Treasuries/Treasury Floating Rate Notes|FRN 浮息美债：利率风险较低，收入会变]]：FRN 跟随短债参考利率，不是固定锁住今天的收益。
- [[21_US_Treasuries/Treasury Debt Ceiling and Payment Risk|债务上限、支付风险与财政可持续性]]：把政治支付约束、利率负担和市场价格分开。
