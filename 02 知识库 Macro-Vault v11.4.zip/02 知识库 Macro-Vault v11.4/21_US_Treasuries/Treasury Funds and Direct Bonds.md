---
title: "单只美债、美债 ETF 与现金工具"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["单只美债、美债 ETF 与现金工具"]
reviewed_on: 2026-10-19
---
# 单只美债、美债 ETF 与现金工具

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 先看持有的法律工具

直接持有某张债券，在发行人按约支付的前提下，可以知道到期日与条款现金流。普通美债 ETF 持有并滚动调整一组证券，基金份额通常没有一个统一的“到期返还面值日”。基金底层是国债，不代表基金净值不会下降。

| 工具类型 | 主要结果来自哪里 | 容易忽略的地方 |
|---|---|---|
| 单只固定利率国债 | 票息、买卖价格、到期面值 | 买价不一定等于面值；提前用钱可能须卖出 |
| 短债 ETF | 短端收入、净值与滚动再投资 | 降息后分配收入会逐步变化 |
| 中长债 ETF | 票息及较明显的久期价格变化 | 不能把高分红当本金稳定 |
| TIPS ETF | 通胀调整和实际收益率变化 | 高通胀期也可能因实际利率上升而亏损 |
| 浮息国债 ETF | 浮息收入及费用、价格变化 | 收入会重设，不是锁定固定利率 |
| 目标到期债券基金 | 逐步接近目标年份的组合现金流 | 需读清算安排；也不保证返还购买成本 |

## 为什么分红不等于赚到的全部钱

基金分配现金时，其他条件不变，净值会相应减少；若只看分红忽略价格，会重复计算财富。比较时看含分配的总回报，并核对收益率口径、费用、跟踪误差、买卖价差和折溢价。

基金注册地、上市交易币种、底层资产币种和对冲币种是四件不同的事；“用 MYR 买”不自动代表没有美元风险。货币市场基金、银行存款和超短债基金的条款与保障也不同，不能仅凭名称中的 cash 当成同一产品。

具体代码、费率、持仓和购买资格会变化，AI 给真实产品比较前必须读取发行人最新资料。本页提供分类，不列未经核验的推荐名单。

## 关联笔记

[[01_Concepts/Passive Flows and ETFs]] · [[21_US_Treasuries/Treasury Security Types]] · [[21_US_Treasuries/Treasury Cash Flows and Bond Pricing]] · [[21_US_Treasuries/Treasury Investing from Malaysia]] · [[01_Concepts/Asset Allocation and Diversification]]

## 来源与使用边界

- [SEC Investor.gov：债券基金](https://www.investor.gov/introduction-investing/investing-basics/glossary/bond-funds-and-income-funds)
- [SEC Investor.gov：ETF](https://www.investor.gov/introduction-investing/investing-basics/investment-products/mutual-funds-and-exchange-traded-2)
- [TreasuryDirect：可交易国债种类](https://www.treasurydirect.gov/marketable-securities/)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Security Types|美债有哪些种类]]：先认清买的是什么，避免把短债、长债和 TIPS 当成同一种资产。
- [[21_US_Treasuries/Treasury TIPS Mechanics|TIPS 怎样抗通胀，又为什么会亏损]]：保护本金的通胀调整，与二级市场价格变化是两回事。
- [[21_US_Treasuries/Treasury Floating Rate Notes|FRN 浮息美债：利率风险较低，收入会变]]：FRN 跟随短债参考利率，不是固定锁住今天的收益。
- [[21_US_Treasuries/Treasury Investing from Malaysia|马来西亚投资者：美元美债与 MYR 回报]]：美元赚了利息，换回马币仍可能亏损。
- [[21_US_Treasuries/Treasury Misconceptions|美债常见误区检查表]]：生成结论前，先排除这些看似合理的错误。
