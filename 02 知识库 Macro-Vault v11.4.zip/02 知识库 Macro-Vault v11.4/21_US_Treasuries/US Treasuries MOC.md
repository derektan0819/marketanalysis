---
title: "US Treasuries MOC — 美债"
tags: [index, moc]
created: 2026-10-27
updated: 2026-10-27
source: "自动整理：完整列出 21_US_Treasuries 的全部文件（2026-10-27）"
---

# US Treasuries MOC — 美债

[[00_Index/Master Index|总索引]] · [[HOME|首页]]

本文件夹共 26 个文件，其中笔记 26 篇。以下按路径完整列出，笔记显示标题。

## 先读

- [[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]]

## 笔记

- [[21_US_Treasuries/Treasury Bills and Discount Yield|短债 Bill 的折价收益率怎么算]]
- [[21_US_Treasuries/Treasury Cash Flows and Bond Pricing|票息、价格、收益率与真实回报]]
- [[21_US_Treasuries/Treasury Clean Price and Settlement|净价、全价、应计利息与结算]]
- [[21_US_Treasuries/Treasury Cross Asset Transmission|美债怎样影响股票、银行、房产、美元和黄金]]
- [[21_US_Treasuries/Treasury DV01 and Key Rate Duration|久期进阶：DV01 与不同期限的风险]]
- [[21_US_Treasuries/Treasury Data Sources and Definitions|美债数据源、单位与时间口径]]
- [[21_US_Treasuries/Treasury Debt Ceiling and Payment Risk|债务上限、支付风险与财政可持续性]]
- [[21_US_Treasuries/Treasury Floating Rate Notes|FRN 浮息美债：利率风险较低，收入会变]]
- [[21_US_Treasuries/Treasury Funds and Direct Bonds|单只美债、美债 ETF 与现金工具]]
- [[21_US_Treasuries/Treasury Futures and Basis Trade|美债期货、基差交易与杠杆风险]]
- [[21_US_Treasuries/Treasury Holders and TIC|谁持有美债：TIC 与买家结构]]
- [[21_US_Treasuries/Treasury Investing from Malaysia|马来西亚投资者：美元美债与 MYR 回报]]
- [[21_US_Treasuries/Treasury Liquidity and Market Structure|美债流动性、交易商与新旧券]]
- [[21_US_Treasuries/Treasury Misconceptions|美债常见误区检查表]]
- [[21_US_Treasuries/Treasury Real Yields and Breakevens|实际利率、盈亏平衡通胀和期限溢价]]
- [[21_US_Treasuries/Treasury Repo SOFR and Collateral|Repo、SOFR 与美债抵押品]]
- [[21_US_Treasuries/Treasury Return Drivers and Portfolio Roles|美债回报来源、期限匹配与组合用途]]
- [[21_US_Treasuries/Treasury STRIPS|STRIPS 零息拆分债]]
- [[21_US_Treasuries/Treasury Scenario Worked Examples|美债因果解释示例：怎样写得看懂]]
- [[21_US_Treasuries/Treasury Security Types|美债有哪些种类]]
- [[21_US_Treasuries/Treasury Spot Forward and Par Yields|平价、零息和远期收益率]]
- [[21_US_Treasuries/Treasury Supply Refunding and Buybacks|发行、季度再融资与财政部回购]]
- [[21_US_Treasuries/Treasury TGA Reserves and RRP|TGA、银行准备金与 ON RRP]]
- [[21_US_Treasuries/Treasury TIPS Mechanics|TIPS 怎样抗通胀，又为什么会亏损]]
- [[21_US_Treasuries/Treasury Yield Curve Scenarios|曲线变化：牛陡、熊陡、牛平、熊平]]
- [[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]]
