---
title: "美债回报来源、期限匹配与组合用途"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["美债回报来源、期限匹配与组合用途"]
reviewed_on: 2026-10-19
---
# 美债回报来源、期限匹配与组合用途

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 回报从哪里来

以现金流一致的方式计算：期间利息或分配，加上期末价值减期初价值，再扣费用与税。分析框架可以拆成 carry（持有收入／融资净额）、roll-down（沿收益率曲线移动的价格效应）、利率与曲线变化等；各项定义要避免把票息、价格向面值收敛重复计算。

若曲线保持向上倾斜，债券剩余期限缩短后可能适用较低收益率，从而产生正向 roll-down；但曲线会变、也可能倒挂，所以这不是白赚的确定收益。

## 为什么持有期限重要

利率上涨会压低旧债价格，却提高未来可再投资的收益。短期需要卖出的人更在意前者，长期持续再投资的人可能逐渐受益于后者；最终结果取决于现金流与持有期，不能只凭“利率涨”给所有投资者同一答案。

Ladder（阶梯）将到期日分散，减少一次性再投资集中度；barbell（两端配置）同时持有短端与长端，可能承担不同曲线风险；bullet（集中期限）围绕某个支付日期安排现金流。它们是设计方式，不是收益排名。

## 与股票组合的关系

增长下滑而通胀受控时，降息预期和避险需求可能使国债对冲股票损失；通胀冲击同时提高折现率时，股债却可能一起跌。分散效果取决于冲击类型和期限，不能预设相关性永久为负。

若未来支出是 MYR，应另算美元转换风险；若要在确定日期付美元，先匹配现金流。未取得用户负债、期限和风险承受资料时，不自动给出固定配置比例。

## 关联笔记

[[01_Concepts/Asset Allocation and Diversification]] · [[01_Concepts/Risk-On Risk-Off]] · [[21_US_Treasuries/Treasury DV01 and Key Rate Duration]] · [[21_US_Treasuries/Treasury Yield Curve Scenarios]] · [[21_US_Treasuries/Treasury Investing from Malaysia]]

## 来源与使用边界

- [FINRA：久期与利率敏感度](https://syndication.finra.org/content/duration-what-interest-rate-hike-could-do-your-bond-portfolio)
- [TreasuryDirect：价格与利率](https://www.treasurydirect.gov/marketable-securities/understanding-pricing/)
- [SEC Investor.gov：债券基金](https://www.investor.gov/introduction-investing/investing-basics/glossary/bond-funds-and-income-funds)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Cash Flows and Bond Pricing|票息、价格、收益率与真实回报]]：解释为什么票息固定，市场价格却每天改变。
- [[21_US_Treasuries/Treasury Bills and Discount Yield|短债 Bill 的折价收益率怎么算]]：同一张短债可能显示不同年化收益率，先检查分母和日数。
- [[21_US_Treasuries/Treasury STRIPS|STRIPS 零息拆分债]]：把每笔未来付款拆成独立证券，会改变现金流与利率敏感度。
- [[21_US_Treasuries/Treasury Investing from Malaysia|马来西亚投资者：美元美债与 MYR 回报]]：美元赚了利息，换回马币仍可能亏损。
