---
title: "美债因果解释示例：怎样写得看懂"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["美债因果解释示例：怎样写得看懂"]
reviewed_on: 2026-10-19
---
# 美债因果解释示例：怎样写得看懂

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

> 以下全部是假设教学情景，不是历史复盘、当前行情或投资信号。不能拿它们作为事实证据，也不能把示例中的机制直接套到今天。

## 例一：明明降息，长债为什么还跌

**发生了什么：**假设央行降息 25 bp，但 10 年收益率反而升 20 bp。先分清降的是隔夜政策利率，升的是长期市场收益率。

**为什么：**市场此前可能已预期降息，真正的新信息却是长期通胀或供给担忧。投资者要求更高长期回报，旧长债的票息不能跟着加，只能靠价格下降满足新买家。只有核对政策预期、TIPS、通胀补偿和供给消息后，才可说哪条解释较有支持；仅凭两项涨跌不能确认主因。

**后续影响：**准备再融资的企业可能要付更高新债成本，利润受到的影响随到期节奏出现。现金多、固定利率债期限长的公司可能暂时影响较小。若之后通胀补偿回落、拍卖承接稳定，长端压力可能缓和；若期限补偿继续扩大，降息也未必迅速带来长债反弹。盯同期限实际率与 BEI、融资利差及到期结构。

## 例二：收益率上涨，股票却上涨

**为什么：**假设订单数据改善，市场同时提高增长预期和债券收益率要求。更高折现率压低股票估值，但更高盈利预期把现金流往上推；后者若更强，股票仍可能上涨。不能因此说“利率对股票没影响”。

**后续影响：**若收入增长随后兑现且成本受控，盈利支持可能持续；若只是价格上涨而销量没有改善，利润支持会减弱。验证订单、销量、利润率和盈利预期，而不是只盯收益率方向。没有真实共识数据时，不声称分析师已经上调预测。

## 例三：通胀仍高，TIPS 基金亏损

**为什么：**假设基金期间受益于通胀本金调整，却遇到实际收益率明显上升。远期实际现金流的现值下降，久期损失可能大于通胀与票息收入。看到 CPI 高，只解释了其中一条路径。

**后续影响：**若实际收益率继续上升，净值仍可能承压；若实际利率稳定，之后的现金流表现会更受实现通胀和持有收入影响。比较要纳入基金分配、久期及费用；不能只看净值或套用单只 TIPS 的到期本金底线。

## 例四：美元赚 5%，马币反而亏

**为什么：**假设美元资产总回报 5%，但美元兑换 MYR 的价格下跌 8%。换回本币时每一美元能买到的 MYR 更少，合并回报是 −3.4%，不是简单相减后的 −3%。

**后续影响：**若必须在指定日期支付 MYR，应把汇率和付款时间一起纳入情景；若要支付美元费用，评价基准可能不同。美元、美债价格和汇率对冲成本须分别追踪，不把三种风险浓缩为“美债安全”。

## 关联笔记

[[21_US_Treasuries/Treasury Real Yields and Breakevens]] · [[21_US_Treasuries/Treasury Cross Asset Transmission]] · [[21_US_Treasuries/Treasury TIPS Mechanics]] · [[21_US_Treasuries/Treasury Investing from Malaysia]] · [[16_TestCases/Readable Report Example]]

## 来源与使用边界

- [TreasuryDirect：价格与利率](https://www.treasurydirect.gov/marketable-securities/understanding-pricing/)
- [美联储：TIPS 曲线与通胀补偿](https://www.federalreserve.gov/data/tips-yield-curve-and-inflation-compensation.htm)
- [FINRA：久期与利率敏感度](https://syndication.finra.org/content/duration-what-interest-rate-hike-could-do-your-bond-portfolio)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。
