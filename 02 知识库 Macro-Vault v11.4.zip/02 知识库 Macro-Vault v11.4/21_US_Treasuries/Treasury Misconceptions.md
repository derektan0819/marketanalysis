---
title: "美债常见误区检查表"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["美债常见误区检查表"]
reviewed_on: 2026-10-19
---
# 美债常见误区检查表

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

| 容易写错的句子 | 应改成的判断 |
|---|---|
| 美债跌了，所以收益率也跌了 | 先说明价格或收益率；固定现金流债两者通常反向 |
| Fed 降息，30 年债一定上涨 | 长端还反映未来路径、通胀和期限补偿；政策可能已被定价 |
| 票息 5%，我一年一定赚 5% | 买价、持有期、价格、再投资、税费与汇率共同决定回报 |
| 持有到期就保证退回买入本金 | 如约支付的是条款面值和利息；溢价、费用、购买力另算 |
| 美债 ETF 到期会回到面值 | 普通滚动基金没有统一的到期返还面值承诺 |
| CPI 越高，TIPS 价格一定越涨 | 实际收益率上升可压低 TIPS 市价 |
| BEI 就是纯通胀预测 | 还含风险补偿、流动性与测量差异 |
| 曲线解除倒挂就是经济好转 | 要看短端因降息担忧下行，还是长端因压力上行 |
| 投标倍数低就是拍卖失败 | 需比较同类历史、规模和官方结果 |
| 间接投标者都是外国央行 | 投标渠道分类不等于最终投资者身份 |
| 某国持仓下降就是当天抛售 | 持仓有估值、托管、期限和数据滞后问题 |
| Treasury buyback 就是 QE | 财政债务管理与中央银行资产操作不同 |
| TGA 上升必定导致股票跌 | 资金来源、RRP、准备金及其他驱动要一起看 |
| 期货净空头代表全部看空 | 可能与现券多头形成对冲或基差头寸 |
| 美债低信用风险＝没有风险 | 还存在价格、通胀、汇率、融资和特殊支付风险 |

本表用于自查，具体理由、条件与例子见下方相关笔记；不能用简短纠错表代替正式报告中“为什么”和“后续影响”的展开解释。

## 关联笔记

[[21_US_Treasuries/Treasury Cash Flows and Bond Pricing]] · [[21_US_Treasuries/Treasury Yield Curve Scenarios]] · [[21_US_Treasuries/Treasury TIPS Mechanics]] · [[21_US_Treasuries/Treasury Funds and Direct Bonds]] · [[03_Indicators/Treasury Auctions]] · [[21_US_Treasuries/Treasury Holders and TIC]] · [[21_US_Treasuries/Treasury Supply Refunding and Buybacks]] · [[21_US_Treasuries/Treasury Futures and Basis Trade]] · [[21_US_Treasuries/Treasury Debt Ceiling and Payment Risk]]

## 来源与使用边界

- [TreasuryDirect：价格与利率](https://www.treasurydirect.gov/marketable-securities/understanding-pricing/)
- [TreasuryDirect：TIPS](https://www.treasurydirect.gov/marketable-securities/tips/)
- [SEC Investor.gov：债券基金](https://www.investor.gov/introduction-investing/investing-basics/glossary/bond-funds-and-income-funds)
- [财政部：TIC 持仓估算与限制](https://home.treasury.gov/data/treasury-international-capital-tic-system-home-page/help-files/estimating-holdings-of-treasury-securities)
- [财政部：债务上限](https://home.treasury.gov/policy-issues/financial-markets-financial-institutions-and-fiscal-service/debt-limit)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。
