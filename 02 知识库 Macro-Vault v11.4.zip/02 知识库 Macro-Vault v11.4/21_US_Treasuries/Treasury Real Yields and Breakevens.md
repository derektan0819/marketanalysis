---
title: "实际利率、盈亏平衡通胀和期限溢价"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["实际利率、盈亏平衡通胀和期限溢价"]
reviewed_on: 2026-10-19
---
# 实际利率、盈亏平衡通胀和期限溢价

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 先拆开三个概念

名义利率补偿美元金额的等待；实际利率近似描述扣除预期通胀后的回报；breakeven inflation（盈亏平衡通胀）常用同期限名义美债收益率减 TIPS 收益率衡量。BEI 含通胀风险补偿和流动性差异，不能直接叫作“市场确定的未来 CPI”。

另一个分解是“未来短期名义利率的预期平均值＋期限溢价”。这与“实际利率＋通胀补偿”是不同视角，不能把两套完整分解再次相加，否则重复计算。期限溢价依赖模型，可能为负，也会修订。

## 为什么拆分会改变后续影响

如果名义收益率上涨主要伴随实际收益率上升，说明持有安全美元资产的实际回报门槛提高；在其他条件不变时，远期盈利的现值和不付息资产的相对吸引力可能承压。

如果主要是通胀补偿上升，市场可能担忧未来购买力：部分有定价能力的企业收入可以随价格上涨，成本却也可能上升。此时不能把所有股票和黄金一律判跌。

如果是期限溢价提高，投资者可能要求更多补偿来承受长期利率或供给不确定性；企业长期借款可能变贵，即使下次央行会议仍可能降息。以上是待检验机制，单靠一天两条收益率不能完成因果识别。

## 验证与失效

检查期限和时点是否匹配、TIPS 流动性是否异常、模型变动是否稳健，再对照政策预期与宏观发布。TIPS 名义价格仍会因实际收益率上涨而下降；它保护某类通胀现金流，不保护每天的市值。

## 关联笔记

[[01_Concepts/Real Interest Rates]] · [[01_Concepts/Term Premium]] · [[01_Concepts/Inflation]] · [[01_Concepts/Gold]] · [[21_US_Treasuries/Treasury TIPS Mechanics]] · [[02_Transmission/Dollar and Real Yields to Gold and Crypto]]

## 来源与使用边界

- [美联储：TIPS 曲线与通胀补偿](https://www.federalreserve.gov/data/tips-yield-curve-and-inflation-compensation.htm)
- [纽约联储：拆解国债市场信号](https://www.newyorkfed.org/newsevents/speeches/2023/per231116)
- [TreasuryDirect：TIPS](https://www.treasurydirect.gov/marketable-securities/tips/)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Yield Curve Scenarios|曲线变化：牛陡、熊陡、牛平、熊平]]：先看哪一端在动，再解释增长、通胀与供给。
- [[21_US_Treasuries/Treasury TIPS Mechanics|TIPS 怎样抗通胀，又为什么会亏损]]：保护本金的通胀调整，与二级市场价格变化是两回事。
- [[21_US_Treasuries/Treasury Cross Asset Transmission|美债怎样影响股票、银行、房产、美元和黄金]]：先找收益率变化的来源，再分别解释估值、经营与融资。
- [[21_US_Treasuries/Treasury Data Sources and Definitions|美债数据源、单位与时间口径]]：知识库告诉 AI 去哪里取数，不等于已经接入行情。
- [[21_US_Treasuries/Treasury Scenario Worked Examples|美债因果解释示例：怎样写得看懂]]：示范逐步解释与条件判断，所有事件和数字均为虚构。
