---
title: "久期进阶：DV01 与不同期限的风险"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["久期进阶：DV01 与不同期限的风险"]
reviewed_on: 2026-10-19
---
# 久期进阶：DV01 与不同期限的风险

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 久期不是剩余年数

修正久期描述收益率小幅变化时，价格的近似反向敏感度；Macaulay 久期是现金流时间的现值加权平均；有效久期用模型重新定价。读不同产品数字时先核对定义。

$$\Delta P/P\approx-D_{mod}\Delta y+\tfrac12 C(\Delta y)^2$$

收益率用小数：50 bp = 0.005；1 个百分点 = 100 bp。DV01 通常报告为收益率变动 1 bp 对应的金额敏感度，约等于市场价值 × 修正久期 × 0.0001；收益率上升时价格变动为负。

**假设示例：**市值 100,000 美元、久期 7，DV01 约 70 美元/bp；相关收益率平行上升 50 bp，线性价格损失约 3,500 美元。若久期 7、凸性 60，升 100 bp 的二阶近似是 −7% + 0.3% = −6.7%。这是近似，非损失上限。

## 为什么还需要关键期限久期

2 年收益率可能下降，30 年却上升。单一组合久期把这种差异压成一个数，会掩盖损失来自哪一段。Key rate duration 分别测量指定期限附近的曲线变化；两个总久期相同的组合，对陡峭化和扁平化仍可能反应不同。

债券与负债对冲应匹配币种、现金流和关键期限，而不是只匹配名义本金。期限越长、票息越低通常久期越高，是其他条件相同时的比较。大幅变动、曲线形状变化、流动性折价和含期权资产都可能使简单公式失准。

## 关联笔记

[[01_Concepts/Duration and Convexity]] · [[21_US_Treasuries/Treasury Yield Curve Scenarios]] · [[21_US_Treasuries/Treasury STRIPS]] · [[21_US_Treasuries/Treasury Futures and Basis Trade]] · [[01_Concepts/Asset Allocation and Diversification]]

## 来源与使用边界

- [FINRA：久期与利率敏感度](https://syndication.finra.org/content/duration-what-interest-rate-hike-could-do-your-bond-portfolio)
- [TreasuryDirect：价格与利率](https://www.treasurydirect.gov/marketable-securities/understanding-pricing/)
- [美联储：对冲基金美债与基差交易](https://www.federalreserve.gov/econres/notes/feds-notes/sizing-hedge-funds-treasury-market-activities-and-holdings-20211006.html)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury STRIPS|STRIPS 零息拆分债]]：把每笔未来付款拆成独立证券，会改变现金流与利率敏感度。
- [[21_US_Treasuries/Treasury Futures and Basis Trade|美债期货、基差交易与杠杆风险]]：理解市场结构，不把基差收敛当成无风险收益。
- [[21_US_Treasuries/Treasury Return Drivers and Portfolio Roles|美债回报来源、期限匹配与组合用途]]：利息、价格、再投资与汇率都要进入总回报。
