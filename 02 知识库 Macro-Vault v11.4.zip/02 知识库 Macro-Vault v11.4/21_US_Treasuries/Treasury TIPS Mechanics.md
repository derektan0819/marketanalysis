---
title: "TIPS 怎样抗通胀，又为什么会亏损"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["TIPS", "TIPS 怎样抗通胀，又为什么会亏损"]
reviewed_on: 2026-10-19
---
# TIPS 怎样抗通胀，又为什么会亏损

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 现金怎样变化

TIPS 原始期限为 5、10 或 30 年。其票息率固定，计算利息所用的本金随美国 CPI 指数比率调整；因此本金上调后，美元票息金额也会增加。它跟踪的是指定美国物价指数，不是马来西亚个人消费篮子。

**假设示例：**原始面值 1,000，指数比率 1.03，调整本金为 1,030；票息率 1%，一笔半年票息约 5.15。实际支付使用该期[官方指数比率](https://www.treasurydirect.gov/auctions/tips-cpi-data/)，不能简单拿最新同比 CPI 乘本金。指数反映有规定的滞后与按日插值。

到期时按调整本金与原始本金孰高支付。这个底线不是“任何价格买入都能回本”；例如二级市场溢价、已累积的通胀调整、费用和提前卖出的损益都要另外考虑。

## 为什么 CPI 高，TIPS 基金仍可能跌

市场可能已经预期高通胀，同时要求更高的实际收益率。旧 TIPS 的未来实际现金流需要用更高实际利率折现，价格会下降；当这一损失超过期间通胀调整和利息，市值总回报仍可为负。长久期 TIPS 或基金尤其要看实际利率敏感度。

## 与普通美债怎样比较

使用接近的期限和现金流，比较买入时 BEI 与之后实际实现的通胀，同时考虑持有期、税、流动性和再投资。短期内“实际通胀高于 BEI”并不自动等于 TIPS ETF 当期一定跑赢。不要把美债通胀保护解释成 MYR 本金保障。

## 关联笔记

[[01_Concepts/Real Interest Rates]] · [[21_US_Treasuries/Treasury Real Yields and Breakevens]] · [[21_US_Treasuries/Treasury Funds and Direct Bonds]] · [[21_US_Treasuries/Treasury Investing from Malaysia]] · [[21_US_Treasuries/Treasury STRIPS]]

## 来源与使用边界

- [TreasuryDirect：TIPS](https://www.treasurydirect.gov/marketable-securities/tips/)
- [美联储：TIPS 曲线与通胀补偿](https://www.federalreserve.gov/data/tips-yield-curve-and-inflation-compensation.htm)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Security Types|美债有哪些种类]]：先认清买的是什么，避免把短债、长债和 TIPS 当成同一种资产。
- [[21_US_Treasuries/Treasury Clean Price and Settlement|净价、全价、应计利息与结算]]：报价不是最终扣款，先把价格和利息拆开。
- [[21_US_Treasuries/Treasury Real Yields and Breakevens|实际利率、盈亏平衡通胀和期限溢价]]：同样是 10 年收益率上涨，背后的原因可能完全不同。
- [[21_US_Treasuries/Treasury STRIPS|STRIPS 零息拆分债]]：把每笔未来付款拆成独立证券，会改变现金流与利率敏感度。
- [[21_US_Treasuries/Treasury Misconceptions|美债常见误区检查表]]：生成结论前，先排除这些看似合理的错误。
- [[21_US_Treasuries/Treasury Scenario Worked Examples|美债因果解释示例：怎样写得看懂]]：示范逐步解释与条件判断，所有事件和数字均为虚构。
