---
title: "STRIPS 零息拆分债"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["STRIPS 零息拆分债"]
reviewed_on: 2026-10-19
---
# STRIPS 零息拆分债

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 拆的是什么

合资格 Notes、Bonds 和 TIPS 可以把本金和每一期利息拆开交易，各个组成部分只在各自到期日支付一次。Bills 和 FRN 不在这个拆分范围；STRIPS 通过金融机构的商业账簿系统持有，不能直接在 TreasuryDirect 买卖持有。

## 为什么波动可能更大

同一到期日、其他条件接近时，附息债会较早返还部分现金，零息债却把全部现金放在最后；因此零息债的利率敏感度通常更高。长期利率小幅变动，也可能造成明显价格波动。这是现金流时点差异，不是因为它突然变成高信用风险债。

如果目标是在指定未来日期取得某笔美元，可以用零息现金流理解期限匹配；但中途需要用钱时仍须按市场价格出售。期间没有现金票息也不表示没有税务确认事项，跨境持有须按实际身份和证券条款核对。

分析时确认是本金 STRIP 还是息票 STRIP、来自名义债还是 TIPS、到期日和报价流动性；不要把所有拆分证券视为完全相同。

## 关联笔记

[[21_US_Treasuries/Treasury Security Types]] · [[21_US_Treasuries/Treasury DV01 and Key Rate Duration]] · [[21_US_Treasuries/Treasury TIPS Mechanics]] · [[21_US_Treasuries/Treasury Return Drivers and Portfolio Roles]]

## 来源与使用边界

- [TreasuryDirect：STRIPS](https://www.treasurydirect.gov/marketable-securities/strips/)
- [FINRA：久期与利率敏感度](https://syndication.finra.org/content/duration-what-interest-rate-hike-could-do-your-bond-portfolio)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Security Types|美债有哪些种类]]：先认清买的是什么，避免把短债、长债和 TIPS 当成同一种资产。
- [[21_US_Treasuries/Treasury DV01 and Key Rate Duration|久期进阶：DV01 与不同期限的风险]]：把利率变动换成大致金额，并识别曲线并非一起移动。
- [[21_US_Treasuries/Treasury TIPS Mechanics|TIPS 怎样抗通胀，又为什么会亏损]]：保护本金的通胀调整，与二级市场价格变化是两回事。
