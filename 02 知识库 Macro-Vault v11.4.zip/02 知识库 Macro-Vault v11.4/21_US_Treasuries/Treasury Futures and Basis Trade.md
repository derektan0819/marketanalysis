---
title: "美债期货、基差交易与杠杆风险"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["美债期货、基差交易与杠杆风险"]
reviewed_on: 2026-10-19
---
# 美债期货、基差交易与杠杆风险

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 期货不是直接持有一张指定国债

美债期货与合约规定的可交割券篮子有关，交割时涉及转换因子和应计利息；最便宜可交割券（CTD）会影响合约风险。其价格敏感度与某个期限现券不能只按名义金额一比一对应。

## 基差交易的机制

常见现金—期货基差头寸是持有可交割现券，同时卖出相关期货，现券资金由 repo 提供，试图赚取相对价格与融资成本的差额。简化基差可表示为现券净价减期货价乘转换因子；真实回报还需考虑持有收益、融资、交割选择与交易成本。

## 为什么两边对冲仍可能出事

方向性利率风险减少，不代表现金需求消失。若期货保证金增加、repo 成本升高或 haircut 提高，策略需要额外现金；此时基差还可能先扩大。资金不足就可能被迫同时平仓，卖出现券并回补期货，推动相对价格进一步偏离。

高杠杆把很小的相对价格变动放大到自有资本损益。这是“融资与流动性风险”，不能用美债低信用风险替代评估。本文用于解释市场反馈，不提供杠杆开仓或保证获利方案。

## 研究时看什么

资金成本、保证金条件、现券流动性、相对定价和持仓数据要一起看。期货净空头也可能是现券多头的对冲，不能直接翻译成“机构都在看空美债”。

## 关联笔记

[[01_Concepts/Derivatives Basics]] · [[21_US_Treasuries/Treasury Repo SOFR and Collateral]] · [[21_US_Treasuries/Treasury DV01 and Key Rate Duration]] · [[21_US_Treasuries/Treasury Liquidity and Market Structure]] · [[03_Indicators/MOVE Index]]

## 来源与使用边界

- [美联储：对冲基金美债与基差交易](https://www.federalreserve.gov/econres/notes/feds-notes/sizing-hedge-funds-treasury-market-activities-and-holdings-20211006.html)
- [CME：国债报价](https://www.cmegroup.com/education/courses/introduction-to-treasuries/calculating-us-treasury-pricing)
- [CME：转换因子](https://www.cmegroup.com/trading/interest-rates/us-treasury-futures-conversion-factor-lookup-tables.html)
- [CME：现券与期货基差](https://www.cmegroup.com/education/courses/introduction-to-treasuries/the-basics-of-treasuries-basis)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury DV01 and Key Rate Duration|久期进阶：DV01 与不同期限的风险]]：把利率变动换成大致金额，并识别曲线并非一起移动。
- [[21_US_Treasuries/Treasury Repo SOFR and Collateral|Repo、SOFR 与美债抵押品]]：美债既是投资品，也是借美元时常用的抵押品。
- [[21_US_Treasuries/Treasury Liquidity and Market Structure|美债流动性、交易商与新旧券]]：低信用风险不保证任何时候都能以理想价格成交。
- [[21_US_Treasuries/Treasury Misconceptions|美债常见误区检查表]]：生成结论前，先排除这些看似合理的错误。
