---
title: "净价、全价、应计利息与结算"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
version: "11.4"
tags: [treasuries, knowledge]
aliases: ["净价、全价、应计利息与结算"]
reviewed_on: 2026-10-19
---
# 净价、全价、应计利息与结算

[[21_US_Treasuries/US Treasury Knowledge Map|美债知识总览]] · [[10_Playbooks/US Treasury Research Playbook|让 AI 分析美债]]

## 看懂账单

净价（clean price）不含本付息期已经累积的利息；全价（dirty price）等于净价加应计利息。买家通常补给卖家截至结算日已累积的利息，然后按条款领取下一次完整票息。这笔补偿不是凭空多付一次利息。

债券报价通常按每 100 面值表示。部分美债报价使用 32 分之一点，例如假设报价 99-16 表示 99 + 16/32 = 99.5；券商也可能直接显示小数。必须确认页面是在报价格、收益率还是基金每股价格。

**假设示例：**面值 10,000，净价每百元 99.5，对应净价金额 9,950。若应计利息是 80，费用 5，实际支出 10,035。不能拿 9,950 当全部成本计算回报。

## 为什么这会影响判断

临近付息时全价包含较多应计利息，付息后应计部分重置，账户同时收到现金；只看价格跳动可能误以为突然亏损。比较两日表现，应使用一致价格口径并纳入现金分配。

实际成交还要区分买价、卖价、最近成交和指示性报价，检查报价时间、数量、结算日及日数规则。重新发行（reopening）的国债可能带应计利息；不要把“新一次拍卖”理解为必定从零开始计息。TIPS 还涉及指数本金，按官方指数比率和券商结算明细计算。

## 关联笔记

[[21_US_Treasuries/Treasury Cash Flows and Bond Pricing]] · [[21_US_Treasuries/Treasury TIPS Mechanics]] · [[21_US_Treasuries/Treasury Liquidity and Market Structure]] · [[03_Indicators/Treasury Auctions]]

## 来源与使用边界

- [CME：国债报价](https://www.cmegroup.com/education/courses/introduction-to-treasuries/calculating-us-treasury-pricing)
- [TreasuryDirect：价格与利率](https://www.treasurydirect.gov/marketable-securities/understanding-pricing/)
- [TreasuryDirect：拍卖流程](https://www.treasurydirect.gov/auctions/how-auctions-work/)

以上来源用于核对产品定义与研究方法；本文的因果传导是有条件的分析框架，示例均非真实行情。对当日走势、政策、规则、税务及产品条款须重新取得带日期的证据。

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Cash Flows and Bond Pricing|票息、价格、收益率与真实回报]]：解释为什么票息固定，市场价格却每天改变。
- [[21_US_Treasuries/Treasury Liquidity and Market Structure|美债流动性、交易商与新旧券]]：低信用风险不保证任何时候都能以理想价格成交。
