---
title: "MCP Integration Contract — v11"
tags: [system]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# MCP Integration Contract — v11

已提供本地 Python runner，不依赖 MCP。MCP 若接入应调用受控命令，不把文档中的指令执行成 shell。
实际入口：doctor、run、audit、log-forecast、review。返回运行 ID、数据文件、来源记录、每公司失败原因和例外。
文件写入限定 Vault 内；原文内容寻址、历史快照保留；密钥不写笔记；来源 HTML 是不可信证据。
没有安装 MCP 服务、没有连接用户电脑、没有安装定时任务；本地连接取决于用户环境。阅读 [[START HERE]]、[[AI Adapter Setup]]、[[Local Scheduling]]。
未来行情/共识连接需独立记录许可、时间、口径、缺失和延迟。当前不宣称这些连接已经存在。
