---
title: ""
created: ""
updated: ""
source: ""
tags: [template, report, governance]
report_id: RPT-YYYYMMDD-ENTITY-PERIOD
entity: ""
report_period: ""
report_type: earnings
created_at: ""
data_cutoff: ""
status: Draft
version: 1
source_ids: []
model_or_author: ""
---
# Report Manifest

## Scope
- Question:
- Entity / event:
- Reporting period:
- Market and timezone:
- Data cutoff:

## Evidence package
- Source records:
- Structured data snapshot:
- Calculations:
- Relevant Vault notes:

## Quality gate
| Check | Result | Evidence / issue |
|---|---|---|
| Source integrity | Pending | |
| Data integrity | Pending | |
| Calculation integrity | Pending | |
| Citation integrity | Pending | |
| Analysis integrity | Pending | |
| Obsidian integrity | Pending | |

## Final status
- Status: `Draft` / `Needs Review` / `Verified` / `Superseded`
- Unresolved issues:
- Reviewer:
- Review timestamp:
- Supersedes report ID:


## v11 附加字段
source_capture_status、data_check_status、calculation_status、reading_coverage、semantic_review_status、forecast_confidence、missing_data_impact、disclosure_stage。资料核验与预测可靠度分开。
