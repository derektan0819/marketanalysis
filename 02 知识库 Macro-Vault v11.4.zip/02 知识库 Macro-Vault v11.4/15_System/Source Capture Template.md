---
created: ""
updated: ""
source: ""
tags: [template, sources]
source_id: SRC-YYYYMMDD-001
source_type: issuer_release
publisher: ""
title: ""
url: ""
publication_datetime: ""
timezone: ""
retrieved_datetime: ""
reporting_period: ""
source_location: ""
status: unverified
---
# Source Capture — {{title}}

## Why this source matters
- Claim(s) it supports:
- Primary or secondary:
- Relevant report(s):

## Data extracted
| Metric | Value | Unit | Period | Basis | Table / location | Status |
|---|---:|---|---|---|---|---|
| | | | | | | unverified |

## Limitations / caveats
- Revisions, restatements or later amendments:
- Definitions or non-GAAP adjustments:
- Missing fields:
- Cross-check required:

## Verification history
| Checked at | Checker/tool | Result | Issue / action |
|---|---|---|---|
| | | | |
