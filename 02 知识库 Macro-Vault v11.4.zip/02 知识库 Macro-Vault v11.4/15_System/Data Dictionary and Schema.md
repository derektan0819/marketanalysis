---
title: "Data Dictionary and Schema"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [system, data, schema]
version: 1.0
---
# Data Dictionary and Schema

## Canonical observation fields
| Field | Required? | Meaning |
|---|---|---|
| `observation_id` | Yes | Stable unique ID for this observation |
| `entity` | Yes | Company, indicator, index or instrument |
| `metric` | Yes | Canonical metric name |
| `value` | Yes unless missing | Numeric/string value as reported |
| `unit` | Yes | USD, USD millions, %, percentage points, shares, index points, etc. |
| `currency` | When applicable | ISO currency code, e.g. USD, TWD, MYR |
| `period_start` | When applicable | Start of reporting/observation period |
| `period_end` | Yes for period data | End date or observation date |
| `period_type` | Yes | Quarter, fiscal year, calendar year, month, week, daily observation, TTM |
| `fiscal_period_label` | For company results | Issuer's fiscal period label |
| `basis` | Yes for financial metrics | GAAP, Non-GAAP, adjusted, reported, seasonally adjusted, etc. |
| `data_type` | Yes | `reported_actual`, `company_guidance`, `consensus`, `market_price`, `official_series`, `calculation`, `estimate`, `inference` |
| `source_id` | Yes for external facts | Links to a record in the source register |
| `source_url` | Yes for external facts | Direct URL to source |
| `source_location` | Recommended | Page, table, item, tag, paragraph or series ID |
| `published_at` | Yes for time-sensitive data | Source publication timestamp with timezone |
| `retrieved_at` | Yes | When the system/person obtained it |
| `provider` | Yes for consensus/market data | Named data provider or publisher |
| `formula` | For derived values | Reproducible calculation expression |
| `input_observation_ids` | For derived values | IDs of the inputs used in calculation |
| `confidence_status` | Yes | `verified_primary`, `verified_secondary`, `needs_review`, `unverified`, `conflicting`, `not_available` |
| `notes` | Optional | Caveats, revisions, reconciliation explanation |

## Example observation (illustrative only)
```yaml
observation_id: EXAMPLE-001
entity: Example Corp
metric: revenue
value: null
unit: USD millions
currency: USD
period_start: null
period_end: null
period_type: fiscal_quarter
fiscal_period_label: null
basis: reported
data_type: reported_actual
source_id: null
source_url: null
source_location: null
published_at: null
retrieved_at: null
provider: issuer
formula: null
input_observation_ids: []
confidence_status: not_available
notes: "Template only; no actual financial data supplied."
```

The example is illustrative only; all keys must use consistent YAML indentation.

## Derived metric definitions
- `revenue_yoy_growth_pct = (current_period_revenue / comparable_prior_year_period_revenue - 1) * 100`
- `revenue_qoq_growth_pct = (current_period_revenue / immediately_prior_comparable_period_revenue - 1) * 100`; for seasonal businesses, label interpretation cautiously.
- `gross_margin_pct = gross_profit / revenue * 100`
- `operating_margin_pct = operating_income / revenue * 100`
- `free_cash_flow = operating_cash_flow - capital_expenditures`, only after confirming the capex sign convention and the chosen definition.
- `surprise_pct = (actual - consensus) / abs(consensus) * 100` may be used only where the consensus is non-zero and the ratio is meaningful. For zero/negative/near-zero consensus, show absolute difference and explain why percentage surprise is not meaningful.
- `percentage_point_change = current_percentage - prior_percentage`; do not label this as percent growth.

## Naming and units
- Preserve reported values separately from normalized values.
- Never silently convert currency. Record original value/unit and conversion source/rate/date if a conversion is required.
- Use full precision internally; round only for display.
- Keep raw source text/data separate from model-generated interpretation.


## v11 实现字段补充（优先于旧示例）
实际 JSON 是执行格式；Markdown 是显示格式。
observation_id、entity、metric、value、unit、period_start/end、period_type、basis、tag、source_id、source_location、accession、filed、published_at、publication_precision、data_type、formula、input_observation_ids、status、series_basis。
published_at 没有精确时间时为 null，filed 保存公开日期；同日且缺精确时间的记录保守排除。不能补造 00:00 作为发布时间。
period_type: quarter / ytd / annual / instant。status: source_recorded / calculation_checked / needs_review。以上都不自动代表语义核验。
source record 包括 raw_path、sha256、retrieved_at、fetch_status、text_path。每次抓取单独写 receipt。
时点说明：当前抓取的历史值使用最新已知版本，series_basis 明确标记；真实实时预测只用系统创建时间之后的事件。
