---
title: "AI Output Contract — MV-11.3"
tags: [system]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# AI Output Contract — MV-11.3

规则正文见 [[Research Protocol]]。自动程序从 stdin 读取公司 AI Research Packet.json，在 stdout 返回单个 UTF-8 JSON 对象；日志写 stderr。输入中的 response_format 是完整字段示意，不能把示意字符串原样当分析结果。

## 唯一主结论

顶层 protocol_version 必须是 `MV-11.3`，brief 为主结论，summary 必须逐字等于 brief.headline。sections 只存补充证据与细节，不得另写相反结论。

| brief 字段 | 要求 |
|---|---|
| headline | 一句话结论，最长 180 字符 |
| valid_until | 可选的已承诺最晚复核时间，ISO 8601；不指定则 null，不能编日期 |
| facts | 1–3 项；text、type（FACT/CALC/UNKNOWN）、observation_ids、source_ids |
| market_move | status（observed/unavailable）、text、证据 ID；行情不可用时只能 unavailable |
| transmission | 2–4 条路径，primary/secondary 各 1–2 条；cause、effect、mechanism、affected_party、mechanism_steps、illustration、timing、break_condition、verification、evidence_scope、relation、alternative、confidence、证据 ID |
| outlook | business 与 price 分开，每项 direction、horizon、reasoning、confidence、证据 ID |
| scenarios | 恰好 base/stronger/weaker 各一项；conditions、path、horizon、invalidation、ranking、confidence、probability、证据 ID |
| watchpoints | 1–3 项；signal、meaning、next_check |
| change | status、reason_code、previous_conclusion、reason、correction_detail、证据 ID |
| data_gaps | 非空字符串列表；说明缺口影响，不使用泛泛免责声明代替 |

经营方向：improving / deteriorating / stable / mixed / unknown。股价方向：up / down / range / unknown。未知方向必须 low；无行情输入不能给股价方向。
因果关系：observed_sequence / supported_inference / hypothesis / unknown；前两项必须引用证据，后两项只能 low。先后变化不等于因果已证实。
confidence：low / medium / high。ranking：preferred / alternative / unranked。只有 base 且证据把握中或高、引用有效才可 preferred；不充分则全部 unranked。probability 默认且当前必须 null。


### 原因与后续影响的详细字段

每条路径必须说明 affected_party（具体对象）、mechanism（概要）、mechanism_steps（2–4 个连续解释步骤）、timing（何时体现及依据）、break_condition（阻断条件）、verification（验证指标）、evidence_scope（引用支持哪一步、哪一步仍未知）。alternative 保留替代解释；步骤要写“为什么传过去”，不能只是复述概要。

illustration 为对象：kind 只能 hypothetical 或 none；text 在 hypothetical 时必须有内容，none 时为空。程序统一加“假设示例，非公司实际数据”标记；例子不得成为真实数据或预测。无需例子时用 none。

primary/secondary 各至少一条；没有足够证据时仍可用 relation=unknown，mechanism_steps 为空数组，其他字段说明未知原因、缺什么和如何核实。不得为满足字段数量编故事。最长概要／步骤 350 字符，证据范围／时间／对象／阻断条件／验证各 400 字符，例子 500 字符。

结构检查可阻止缺字段或只给一条概括句的回答，但不能自动证明文字足够清晰或因果正确。仅扩写解释和改变版式，不得作为 METHOD_CHANGE 反转旧方向的理由。

## 判断变更

status：INITIAL / MAINTAIN / REVISE / WITHDRAW。
reason_code：INITIAL / NO_NEW_EVIDENCE / NEW_EVIDENCE / CORRECTION / HORIZON_CHANGE / METHOD_CHANGE / EXPIRED。

- 无 previous_research 时用 INITIAL，同时阅读 prior_thesis；首次结构化记录不表示此前从未有人工观点。
- 有旧记录时不能再 INITIAL；MAINTAIN 不得改变经营／股价方向。
- NEW_EVIDENCE 必须有实际变化的证据指纹及有效引用，单纯重新抓取时间不算新证据。
- 相同证据反转只允许明确纠错、实际期限／协议方法变化或旧记录中预先写明的 valid_until 已到期。
- CORRECTION 必须写 correction_detail（旧错误、正确解释及依据），引用证据。
- HORIZON_CHANGE 必须实际改变 outlook.horizon；METHOD_CHANGE 必须规则指纹变化并解释具体差异。
- EXPIRED 必须检查旧 brief.valid_until 已过，不能当场补一个旧到期日。

Current Thesis 的更新提案由 brief 的 headline、change.reason、基准失效条件生成，避免第二套答案。旧 thesis_update 字段仅为兼容保留，不用于覆盖主结论。自动更新开启时，首次／修正／撤回先保存旧文再改写；维持不重复覆盖。通过检查的结构化判断保存为 Current Research State.json，原始回答随本次报告留档。

## 覆盖、细节与预测

sections 为数组，每项 title、type（FACT/CALC/INFERENCE/SCENARIO/UNKNOWN）、text、observation_ids、source_ids；核心内容必须与 brief 一致。
coverage 逐条写 source_id、section、reviewed、location、limitations；每份提供的必读原文都要有真实阅读位置。缺失、截断或分段未完成不得声明完整阅读。reading_execution.incomplete 为 true 会阻止采用。
forecast_candidates 可为空。正式登记另受 [[Prediction Log]] 与预测 schema 约束；当前简报默认不使用数字概率。不要为了填满字段生成虚构预测。

## 一致性与检查边界

本地引擎保存证据指纹和输入指纹；同一上下文、截止、旧判断、规则、模型设置、适配器内容的合格回答可以复用。新的旧判断状态或截止会改变输入，因此不是“以后永远不再调用模型”。自定义适配器内部模型／提示改变时要更新 analysis_revision。

程序拦截格式缺失、未知引用、未核实输入依赖、缺行情的方向判断、无解释反转、覆盖记录不完整等；未通过时不采用回答、不写入当前判断、不登记候选预测。它不能独立证明每句自然语言、每个因果解释或阅读自报都正确，输出保持 Draft。

上传给普通聊天 AI 时，只有指令约束，不会自动执行本地检查或缓存。必须实际运行 runner 才有程序检查。任何 AI 都可能不完全遵守，不能承诺百分百同样答案。
