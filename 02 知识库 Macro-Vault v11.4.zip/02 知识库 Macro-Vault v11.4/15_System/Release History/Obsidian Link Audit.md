---
title: "Obsidian 全库链接检查 — v11.1"
tags: [system, release-history]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# Obsidian 全库链接检查 — v11.1

当前交付为 v11.3，最新结果见 [[V11.3 Verification]]。下文是 v11.1 的历史检查记录。

[[HOME|首页]] · [[Obsidian Navigation Guide|使用说明]] · [[V11.1 Release Notes|修正记录]]

检查时间：2026-10-19T07:59:50+00:00。数据截止仍为 2026-10-19T07:16:58+00:00，本次没有刷新财报。

## 全库结果

| 检查项 | 结果 |
|---|---:|
| Markdown 笔记 | 364 |
| 内部链接出现次数 | 5937 |
| 标题／段落定位 | 1186 |
| 不存在、空白、目标有歧义或定位错误的链接 | 0 |
| 从 HOME 无法沿链接进入的笔记 | 0 |
| 孤立笔记 | 0 |
| 财务快照结构与计算 | 15 份通过 |
| JSON 中的本地文件引用 | 294 处通过 |
| 原始下载文件 SHA-256 | 26 份通过 |
| 自动测试 | 26 项通过 |

公司同名笔记采用完整路径。检查到的重复文件名保留分目录结构，没有依赖有歧义的裸名链接。报告中的证据块按运行 ID 固定到对应快照，未发现跨公司误连。

原 v11 有 6 个空链接，41 篇从首页不可达的笔记（其中 21 篇是孤立原文）；现已补齐。已检查表格列数和链接别名转义，YAML、JSON 及 Python 均能解析。

已在完整仓库的临时副本中，用保存的来源重新生成 NVDA 的八季数据与简报：新链接和证据定位通过，旧 15 份财务快照保持原样，重复重建导航不产生重复段落。

## 记录和复现

- [[16_TestCases/Obsidian Link Audit.json|机器检查记录（JSON）]]
- [[16_TestCases/V11.1 Automated Test Results.txt|自动测试输出]]
- [[16_TestCases/V11.1 Regeneration Check.txt|离线重新生成记录]]

```bash
python3 99_Automation/engine/vault.py audit
python3 -m unittest discover -s 99_Automation/tests -v
```

## 检查边界

本报告验证交付包中的路径、引用定位、导航可达性和文件完整性。没有连接用户电脑上的 Obsidian，没有验证本地主题、插件或具体界面；外部网址未逐条联网检查。

连线表示引用关系，不证明经济因果或预测有效。财报内容的语义核验、AI 账户和定时任务配置仍以 [[Build Verification]] 的说明为准。


本页保留原检查记录；v11.4 的当前全库结果见 [[V11.4 Verification]]。
