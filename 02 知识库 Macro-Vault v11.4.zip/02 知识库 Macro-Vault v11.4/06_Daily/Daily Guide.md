---
title: "Daily Reports"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [guide, daily]
---
# Daily Reports

Use `YYYY-MM-DD.md` in the selected timezone. State the timezone and data cutoff in frontmatter. Use [[Daily Summary]] and keep market values tied to source + timestamp. If live data access is unavailable, report the gap instead of filling it from memory. Save as Draft until [[Publication Gate]] passes.

## Daily update with impact judgment (v6)
Say `今日更新` to start. Follow [[Daily Update Workflow]] and use [[Daily Impact Update]]; log falsifiable judgments in [[Prediction Log]]. See [[2026-10-16]] for a worked example (Draft).

Coverage (v7): US index, AI/semiconductors, banks, rates, FX, crypto, commodities and major global indices. See [[Cross-Asset Daily Coverage]].
