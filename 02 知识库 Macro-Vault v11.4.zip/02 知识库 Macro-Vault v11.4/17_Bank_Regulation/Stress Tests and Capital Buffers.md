---
title: "Stress Tests and Capital Buffers 压力测试与资本缓冲"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [压力测试, CCAR, DFAST, 压力资本缓冲]
tags: [bank-regulation]
as_of: 2026-10
---
# Stress Tests and Capital Buffers 压力测试与资本缓冲

## Definition 定义
Stress tests estimate how a bank's capital would hold up under a hypothetical severe recession scenario set by the regulator. In the US, the Federal Reserve runs annual supervisory stress tests for large banks (under Dodd-Frank). The results feed a bank-specific stress capital buffer (SCB), which sits on top of minimum requirements and has a floor.
压力测试估算在监管机构设定的假设严重衰退情景下，银行资本能否承受。美国由美联储每年对大型银行进行监管压力测试（依据 Dodd-Frank）。结果会决定银行专属的压力资本缓冲（SCB），它叠加在最低要求之上，并设有下限。

## Why it matters for markets 对市场的意义
Results are published and watched. A bank with a larger required buffer has less room for dividends and buybacks, so test results can move bank shares and payout announcements, which usually follow the results.
结果会公布并受关注。要求缓冲较高的银行，股息和回购空间较小，所以测试结果会影响银行股和派息公告，后者通常紧随结果之后。

## Example 例子 (illustrative 示意)
Hypothetical: a bank's hypothetical losses in the test are larger than expected, so its buffer requirement rises. The market may expect lower buybacks.
假设：某银行在测试中的假设损失高于预期，缓冲要求上升。市场可能预期回购减少。

## Common misconceptions 常见误区
- A stress test is a scenario exercise, not a forecast.
- 压力测试是情景演练，不是预测。
- Passing the test does not mean a bank has no risk; the scenario may not match the next crisis.
- 通过测试不代表银行没有风险；情景可能与下一次危机不同。
- Details of the process change over time; verify with the Federal Reserve.
- 具体流程会随时间变化，请到美联储核实。

## Related 相关
[[Basel III and Capital Ratios]], [[Bank Regulation Map]], [[Bank Capital Rules to Bank Earnings]], [[Share Buybacks and Dividends]], [[Bank Metrics]], [[US Banks]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Regulatory thresholds, scope and effective dates change. Verify against the current rule text from the primary source (Federal Reserve, OCC, FDIC, SEC, BIS or Bank Negara Malaysia) before relying on any number here. as_of: 2026-10 (general background, not current-rule verification).
- This is educational background, not legal advice. For coursework, follow your own lecture slides and legal materials; where they differ, your course materials take priority.
- Describing a rule does not prove it caused a specific market move.
