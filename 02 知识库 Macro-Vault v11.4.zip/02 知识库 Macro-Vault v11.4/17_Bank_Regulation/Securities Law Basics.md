---
title: "Securities Law Basics 证券法基础"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [证券法, SEC, Reg FD, 内幕交易, 10-K, 8-K]
tags: [bank-regulation]
as_of: 2026-10
---
# Securities Law Basics 证券法基础

## Definition 定义
US securities law rests mainly on the Securities Act of 1933 (rules for offering securities, including registration and prospectuses) and the Securities Exchange Act of 1934 (ongoing reporting and market regulation, which created the SEC). Public companies file periodic reports: 10-K (annual), 10-Q (quarterly) and 8-K (report of specified material events, generally filed within a short deadline). Regulation FD limits selective disclosure of material non-public information (MNPI). Insider trading (trading on MNPI in breach of a duty) is prohibited, including under Rule 10b-5. The Sarbanes-Oxley Act (2002) strengthened financial reporting and internal-control requirements.
美国证券法主要基于1933年《证券法》（证券发行规则，含注册和招股说明书）和1934年《证券交易法》（持续报告和市场监管，并设立了 SEC）。上市公司需提交定期报告：10-K（年报）、10-Q（季报）和 8-K（特定重大事项报告，通常有较短的提交期限）。Regulation FD 限制选择性披露重大非公开信息（MNPI）。内幕交易（违反义务而利用 MNPI 交易）被禁止，包括依据 Rule 10b-5。2002年《萨班斯-奥克斯利法案》加强了财务报告和内部控制要求。

## Why it matters for markets 对市场的意义
These rules are why earnings releases, 10-K/10-Q filings and 8-K reports are the primary sources for company facts, and why information reaches the market at specific times. They also explain why this vault prefers filings over news articles.
这些规则解释了为什么财报、10-K/10-Q 和 8-K 是公司事实的一手来源，以及信息为何在特定时间进入市场。它们也解释了为什么本知识库优先使用文件而非新闻。

## Example 例子 (illustrative 示意)
Hypothetical: a company discloses a material event in an 8-K. Because the filing is public, all investors can see it at the same time.
假设：公司在 8-K 中披露重大事项。因为文件是公开的，所有投资者可以同时看到。

## Common misconceptions 常见误区
- Not every piece of non-public information is MNPI; materiality and duty matter.
- 并非所有非公开信息都是 MNPI；重大性和义务关系才是关键。
- A press article is not the primary source; the filing or release is.
- 新闻报道不是一手来源；文件或公告才是。

## Related 相关
[[SEC Filings and Earnings Release]], [[GAAP vs Non-GAAP]], [[Citation and Evidence Standard]], [[Source Registry]], [[Bank Regulation Map]], [[Earnings Season]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Regulatory thresholds, scope and effective dates change. Verify against the current rule text from the primary source (Federal Reserve, OCC, FDIC, SEC, BIS or Bank Negara Malaysia) before relying on any number here. as_of: 2026-10 (general background, not current-rule verification).
- This is educational background, not legal advice. For coursework, follow your own lecture slides and legal materials; where they differ, your course materials take priority.
- Describing a rule does not prove it caused a specific market move.
