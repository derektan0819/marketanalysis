---
title: "Basel III and Capital Ratios 巴塞尔协议III与资本充足率"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [巴塞尔协议, Basel III, CET1, 资本充足率]
tags: [bank-regulation]
as_of: 2026-10
---
# Basel III and Capital Ratios 巴塞尔协议III与资本充足率

## Definition 定义
Basel III is the international set of bank capital and liquidity standards developed by the Basel Committee on Banking Supervision (BCBS). Key ratios: CET1 (Common Equity Tier 1) ÷ risk-weighted assets (RWA); Tier 1 ÷ RWA; total capital ÷ RWA; and a leverage ratio (Tier 1 ÷ total exposure, not risk-weighted).
巴塞尔协议III是巴塞尔银行监管委员会（BCBS）制定的国际银行资本与流动性标准。主要比率：CET1（普通股一级资本）÷ 风险加权资产（RWA）；一级资本 ÷ RWA；总资本 ÷ RWA；以及杠杆率（一级资本 ÷ 总风险暴露，不做风险加权）。

## Why it matters for markets 对市场的意义
Capital absorbs losses. A bank with a thin cushion has less room to lend, buy back shares or pay dividends in a downturn. Reported CET1 ratio is a key figure in bank earnings. Global systemically important banks (G-SIBs) face extra capital surcharges.
资本用来吸收损失。缓冲薄的银行在下行期放贷、回购和派息的空间更小。CET1 比率是银行财报中的关键数字。全球系统重要性银行（G-SIB）还有额外的资本附加要求。

## Key facts and cases 要点与案例
Basel framework minimums (verify current text at BIS): CET1 4.5%, Tier 1 6%, total capital 8% of RWA, plus a capital conservation buffer of 2.5%. Individual national rules, and each bank's own requirement, can be higher. US implementation details and the status of later revisions differ and must be checked in current Federal Reserve, OCC and FDIC sources.
巴塞尔框架最低标准（请到 BIS 核实当前文本）：CET1 4.5%、一级资本 6%、总资本 8%（占风险加权资产），另加 2.5% 的资本留存缓冲。各国具体规则和每家银行自身的要求可能更高。美国的实施细节和后续修订的进展不同，必须到美联储、OCC、FDIC 的最新资料中核实。

Simple calculation 简单计算: CET1 ratio = CET1 capital ÷ RWA. Illustrative: capital 10 and RWA 100 gives 10%.
（示意：资本10，风险加权资产100，则比率为10%。）

## Example 例子 (illustrative 示意)
Hypothetical: a bank's CET1 ratio is 11% against a requirement of 9%. The 2-point surplus gives room for buybacks, but management may keep extra for safety.
假设：某银行 CET1 比率11%，要求为9%。多出的2个百分点给回购留出空间，但管理层可能为安全多留一些。

## Common misconceptions 常见误区
- A higher ratio is not always better for shareholders; excess capital can mean lower returns.
- 比率越高不一定对股东越好；过多资本可能意味着回报偏低。
- The risk-weighted ratio and the leverage ratio measure different things; a bank can pass one and be tight on the other.
- 风险加权比率与杠杆率衡量的内容不同；银行可能满足一个而在另一个上很紧。
- Do not use the Basel minimum as the bank's actual requirement.
- 不要把巴塞尔最低标准当作该银行的实际要求。

## Related 相关
[[Bank Regulation Map]], [[Stress Tests and Capital Buffers]], [[Bank Metrics]], [[Bank Capital Rules to Bank Earnings]], [[US Banks]], [[Malaysia Bank Regulation and Islamic Finance]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Regulatory thresholds, scope and effective dates change. Verify against the current rule text from the primary source (Federal Reserve, OCC, FDIC, SEC, BIS or Bank Negara Malaysia) before relying on any number here. as_of: 2026-10 (general background, not current-rule verification).
- This is educational background, not legal advice. For coursework, follow your own lecture slides and legal materials; where they differ, your course materials take priority.
- Describing a rule does not prove it caused a specific market move.
