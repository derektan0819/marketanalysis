---
title: "Bank Regulation Map 银行监管地图"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [银行监管, 监管框架]
tags: [bank-regulation]
as_of: 2026-10
---
# Bank Regulation Map 银行监管地图

## Definition 定义
A map of who regulates what in the US banking and securities system. Federal Reserve: bank holding companies and monetary policy. OCC: national banks. FDIC: deposit insurance and state non-member banks. SEC: securities markets and public company disclosure. CFPB: consumer financial protection. FSOC: monitors systemic risk.
美国银行与证券体系中“谁监管什么”的地图。美联储：银行控股公司与货币政策。OCC：国民银行。FDIC：存款保险及州立非会员银行。SEC：证券市场与上市公司披露。CFPB：消费者金融保护。FSOC：监测系统性风险。

## Why it matters for markets 对市场的意义
Rules decide how much capital banks hold, how much they can lend and how much they return to shareholders. Regulatory news (tighter or looser) can move bank shares and credit availability.
规则决定银行持有多少资本、能放多少贷款、能向股东回馈多少。监管消息（收紧或放松）会影响银行股和信贷可得性。

## Example 例子 (illustrative 示意)
Hypothetical: regulators propose looser capital rules for large banks. Banks may be able to buy back more shares, but the market also asks whether risk-taking will rise.
假设：监管机构提议放松大型银行的资本规则。银行可能可以回购更多股票，但市场也会问风险承担是否会上升。

## Common misconceptions 常见误区
- 'The Fed regulates all banks' is wrong: responsibility is split across several agencies and varies by bank charter.
- “美联储监管所有银行”是错的：责任分散在多个机构，并取决于银行的牌照类型。
- A proposal is not a final rule; check the stage and effective date.
- 提案不等于最终规则，要看所处阶段和生效日期。

## Related 相关
[[Basel III and Capital Ratios]], [[Stress Tests and Capital Buffers]], [[Liquidity Rules LCR and NSFR]], [[Bank Runs and Deposit Insurance]], [[Dodd-Frank and Volcker Rule]], [[Securities Law Basics]], [[US Banks]], [[Malaysia Bank Regulation and Islamic Finance]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Regulatory thresholds, scope and effective dates change. Verify against the current rule text from the primary source (Federal Reserve, OCC, FDIC, SEC, BIS or Bank Negara Malaysia) before relying on any number here. as_of: 2026-10 (general background, not current-rule verification).
- This is educational background, not legal advice. For coursework, follow your own lecture slides and legal materials; where they differ, your course materials take priority.
- Describing a rule does not prove it caused a specific market move.
