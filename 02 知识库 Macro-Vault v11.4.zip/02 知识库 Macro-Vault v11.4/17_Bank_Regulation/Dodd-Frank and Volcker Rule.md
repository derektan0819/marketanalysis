---
title: "Dodd-Frank and Volcker Rule 多德-弗兰克法案与沃尔克规则"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [多德-弗兰克, Dodd-Frank, 沃尔克规则, Volcker Rule]
tags: [bank-regulation]
as_of: 2026-10
---
# Dodd-Frank and Volcker Rule 多德-弗兰克法案与沃尔克规则

## Definition 定义
The Dodd-Frank Wall Street Reform and Consumer Protection Act (2010) was passed after the 2008 financial crisis. It created the CFPB and FSOC, introduced stress testing for large banks, and set up an orderly liquidation framework for failing large firms. The Volcker Rule (a part of Dodd-Frank) restricts banking entities from proprietary trading and from certain investments in hedge funds and private equity funds.
《多德-弗兰克华尔街改革与消费者保护法》（2010）在2008年金融危机后出台。它设立了 CFPB 和 FSOC，引入大型银行压力测试，并为大型机构破产设立有序清算框架。沃尔克规则（Dodd-Frank 的一部分）限制银行实体从事自营交易，以及对对冲基金和私募股权基金的某些投资。

## Why it matters for markets 对市场的意义
These rules affect which businesses big banks can run and how much capital they must hold. Changes to them (loosening or tightening) can shift expectations for trading revenue, risk-taking and shareholder returns.
这些规则影响大型银行可以经营哪些业务及必须持有多少资本。规则的变化（放松或收紧）会改变市场对交易收入、风险承担和股东回报的预期。

## Example 例子 (illustrative 示意)
Hypothetical: a proposal eases restrictions on certain bank trading activities. Analysts may raise trading revenue estimates, but also ask about risk.
假设：一项提案放松对银行某些交易活动的限制。分析师可能上调交易收入预期，同时也会问风险。

## Common misconceptions 常见误区
- Dodd-Frank is not one rule; it is a large law implemented through many regulations, which have been amended since.
- Dodd-Frank 不是单一规则，而是一部通过大量法规实施的大法，之后又被修订过。
- Market-making and hedging are generally allowed under the Volcker Rule; it targets proprietary trading.
- 沃尔克规则下做市和对冲通常是允许的；它针对的是自营交易。

## Related 相关
[[Bank Regulation Map]], [[Stress Tests and Capital Buffers]], [[Basel III and Capital Ratios]], [[Bank Capital Rules to Bank Earnings]], [[US Banks]], [[Bank Earnings to Market]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Regulatory thresholds, scope and effective dates change. Verify against the current rule text from the primary source (Federal Reserve, OCC, FDIC, SEC, BIS or Bank Negara Malaysia) before relying on any number here. as_of: 2026-10 (general background, not current-rule verification).
- This is educational background, not legal advice. For coursework, follow your own lecture slides and legal materials; where they differ, your course materials take priority.
- Describing a rule does not prove it caused a specific market move.
