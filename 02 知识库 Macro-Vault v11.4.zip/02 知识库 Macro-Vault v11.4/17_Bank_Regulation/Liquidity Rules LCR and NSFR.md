---
title: "Liquidity Rules LCR and NSFR 流动性监管：LCR与NSFR"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [流动性覆盖率, 净稳定资金比率, LCR, NSFR, HQLA]
tags: [bank-regulation]
as_of: 2026-10
---
# Liquidity Rules LCR and NSFR 流动性监管：LCR与NSFR

## Definition 定义
LCR (Liquidity Coverage Ratio): a bank must hold enough high-quality liquid assets (HQLA, such as cash and government bonds) to cover net cash outflows over a 30-day stress period. NSFR (Net Stable Funding Ratio): available stable funding must cover the stable funding required by the bank's assets over one year. Both are designed to be at least 100%.
LCR（流动性覆盖率）：银行必须持有足够的优质流动性资产（HQLA，如现金和政府债券），以覆盖30天压力期内的净现金流出。NSFR（净稳定资金比率）：可用稳定资金必须覆盖银行资产在一年内所需的稳定资金。两者的要求都是至少100%。

## Why it matters for markets 对市场的意义
Liquidity rules shape how much of a bank's balance sheet sits in low-yielding safe assets, which affects earnings, and how banks react to deposit outflows. They are also a source of demand for Treasuries.
流动性规则影响银行资产负债表中有多少放在低收益的安全资产上，从而影响盈利，也影响银行对存款流出的反应。它们也是国债需求的来源之一。

## Example 例子 (illustrative 示意)
Hypothetical: deposits flow out of a bank. Its HQLA buffer must be large enough to meet outflows without selling assets at a loss.
假设：某银行出现存款外流。它的 HQLA 缓冲必须足够大，才能在不亏本抛售资产的情况下应对外流。

## Common misconceptions 常见误区
- Meeting the LCR does not make a bank run-proof; the 30-day scenario may be too mild or too fast in a real run.
- 满足 LCR 不代表银行不会被挤兑；30天的情景在真实挤兑中可能太温和或来得太快。
- The rules apply to different bank sizes differently; check which banks are covered.
- 规则对不同规模银行的适用情况不同，要核实哪些银行适用。

## Related 相关
[[Bank Runs and Deposit Insurance]], [[Basel III and Capital Ratios]], [[Liquidity]], [[US Treasury Market]], [[Bank Metrics]], [[Bank Regulation Map]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Regulatory thresholds, scope and effective dates change. Verify against the current rule text from the primary source (Federal Reserve, OCC, FDIC, SEC, BIS or Bank Negara Malaysia) before relying on any number here. as_of: 2026-10 (general background, not current-rule verification).
- This is educational background, not legal advice. For coursework, follow your own lecture slides and legal materials; where they differ, your course materials take priority.
- Describing a rule does not prove it caused a specific market move.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Holders and TIC|谁持有美债：TIC 与买家结构]]：持仓减少未必等于抛售，间接投标者也不等于外国政府。
