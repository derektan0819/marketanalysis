---
title: "Secured Lending and Collateral 担保贷款与抵押品"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [担保贷款, 抵押品, UCC Article 9, 担保权益, 完善]
tags: [bank-regulation]
as_of: 2026-10
---
# Secured Lending and Collateral 担保贷款与抵押品

## Definition 定义
In secured lending, the borrower pledges assets as collateral. If the borrower defaults, the lender can enforce its security interest against the collateral. In the US, security interests in personal property are mostly governed by UCC Article 9. Core ideas: attachment (the security interest becomes enforceable against the borrower), perfection (steps such as filing a financing statement, taking possession or control, to protect priority against third parties) and priority (who is paid first when several creditors claim the same collateral). Real estate security is generally through a mortgage.
在担保贷款中，借款人以资产作为抵押品。借款人违约时，贷款人可以对抵押品行使担保权益。在美国，动产担保权益主要受 UCC 第9条规范。核心概念：设定（担保权益对借款人生效）、完善（如提交融资声明、占有或控制，以对抗第三人并保护优先顺位）、优先顺位（多个债权人主张同一抵押品时谁先受偿）。不动产担保通常通过抵押。

## Why it matters for markets 对市场的意义
Collateral quality, perfection and priority determine how much a lender recovers in default. This drives loan pricing, loan-loss provisions and credit spreads: secured and senior debt generally has lower expected loss than unsecured or subordinated debt.
抵押品质量、完善和优先顺位决定贷款人违约时能收回多少，进而影响贷款定价、损失拨备和信用利差：有担保的优先债务预期损失通常低于无担保或次级债务。

## Example 例子 (illustrative 示意)
Hypothetical: two lenders claim the same equipment. The one that perfected its security interest first generally has priority, which is why filing matters.
假设：两个贷款人对同一设备主张权利。通常先完善担保权益的一方有优先权，这就是提交登记很重要的原因。

## Common misconceptions 常见误区
- Having collateral does not guarantee full recovery; value can fall and priority can be disputed.
- 有抵押品不保证全额收回；价值可能下跌，优先顺位也可能有争议。
- US UCC rules are not the same as Malaysian law; compare with your own course materials.
- 美国 UCC 规则与马来西亚法律不同，请与你自己的课程资料对照。

## Related 相关
[[Credit Spread]], [[Credit Markets]], [[Bank Metrics]], [[Bank Regulation Map]], [[Malaysia Bank Regulation and Islamic Finance]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Regulatory thresholds, scope and effective dates change. Verify against the current rule text from the primary source (Federal Reserve, OCC, FDIC, SEC, BIS or Bank Negara Malaysia) before relying on any number here. as_of: 2026-10 (general background, not current-rule verification).
- This is educational background, not legal advice. For coursework, follow your own lecture slides and legal materials; where they differ, your course materials take priority.
- Describing a rule does not prove it caused a specific market move.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Repo SOFR and Collateral|Repo、SOFR 与美债抵押品]]：美债既是投资品，也是借美元时常用的抵押品。
