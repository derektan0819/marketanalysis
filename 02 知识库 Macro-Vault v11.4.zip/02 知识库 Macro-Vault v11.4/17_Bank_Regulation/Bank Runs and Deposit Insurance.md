---
title: "Bank Runs and Deposit Insurance 银行挤兑与存款保险"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [银行挤兑, 存款保险, FDIC, Bank Run, SVB]
tags: [bank-regulation]
as_of: 2026-10
---
# Bank Runs and Deposit Insurance 银行挤兑与存款保险

## Definition 定义
A bank run happens when many depositors withdraw funds at once because they fear the bank will fail. Because banks lend out part of deposits, they cannot repay everyone immediately. In the US, the FDIC insures deposits up to a limit (currently USD 250,000 per depositor, per insured bank, per ownership category; verify at FDIC). Deposits above the limit are uninsured.
当许多储户因担心银行倒闭而同时取款，就发生了银行挤兑。由于银行把部分存款贷了出去，无法立刻还给所有人。美国由 FDIC 为存款提供有上限的保险（目前为每位储户、每家参保银行、每种所有权类别25万美元，请到 FDIC 核实）。超过上限的存款不受保险保护。

## Why it matters for markets 对市场的意义
Deposit insurance reduces run risk for small depositors, but uninsured deposits can still run quickly. Rising rates can create unrealized losses on bank bond holdings; if funding then leaves, those losses can become real.
存款保险降低了小额储户的挤兑风险，但无保险的存款仍可能快速外逃。利率上升会使银行持有的债券出现未实现损失；如果资金随后流出，这些损失可能变成真实损失。

## Key facts and cases 要点与案例
Case: Silicon Valley Bank (March 2023). It held large long-dated securities with unrealized losses and a deposit base with a high share of uninsured deposits. A rapid deposit run followed, and authorities intervened to protect depositors. Use this as a case to study, and rely on primary sources (FDIC, Federal Reserve reports) for details.
案例：硅谷银行（2023年3月）。它持有大量带有未实现损失的长期证券，且存款中无保险存款占比很高。随后发生快速挤兑，监管机构出手保护储户。可作为研究案例，具体细节请以一手资料（FDIC、美联储报告）为准。

## Example 例子 (illustrative 示意)
Hypothetical: a bank has a large share of uninsured deposits and large unrealized bond losses. A negative headline can trigger rapid withdrawals.
假设：某银行无保险存款占比高，且债券未实现损失大。一条负面消息就可能引发快速取款。

## Common misconceptions 常见误区
- Deposit insurance does not cover everything: limits, ownership categories and uninsured balances matter.
- 存款保险不是全覆盖：上限、所有权类别和无保险余额都很重要。
- Unrealized losses are not losses until sold, but they matter if the bank is forced to sell.
- 未实现损失在出售前不是真实亏损，但如果银行被迫出售就会变得重要。

## Related 相关
[[Liquidity Rules LCR and NSFR]], [[Bank Regulation Map]], [[Liquidity]], [[Fed Balance Sheet]], [[US Banks]], [[Bank Metrics]], [[Interest Rates]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Regulatory thresholds, scope and effective dates change. Verify against the current rule text from the primary source (Federal Reserve, OCC, FDIC, SEC, BIS or Bank Negara Malaysia) before relying on any number here. as_of: 2026-10 (general background, not current-rule verification).
- This is educational background, not legal advice. For coursework, follow your own lecture slides and legal materials; where they differ, your course materials take priority.
- Describing a rule does not prove it caused a specific market move.
