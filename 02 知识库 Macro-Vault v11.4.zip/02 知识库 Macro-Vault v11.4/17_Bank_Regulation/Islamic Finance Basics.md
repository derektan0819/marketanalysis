---
title: "Islamic Finance Basics 伊斯兰金融基础"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [伊斯兰金融, Riba, Gharar, Murabahah, Sukuk, Takaful]
tags: [bank-regulation]
as_of: 2026-10
---
# Islamic Finance Basics 伊斯兰金融基础

## Definition 定义
Islamic finance operates under Shariah principles. Main prohibitions: riba (interest/usury), gharar (excessive uncertainty in contracts) and maysir (gambling). Common structures: Murabahah (cost-plus sale: the seller discloses cost and adds an agreed profit margin), Ijarah (leasing), Musharakah (joint partnership where partners share profit and loss), Mudarabah (one party provides capital, the other provides expertise; profits shared by agreement, financial losses borne by the capital provider), Sukuk (asset-backed or asset-based certificates, often compared with bonds) and Takaful (Islamic insurance based on mutual cooperation).
伊斯兰金融遵循伊斯兰教法（Shariah）原则。主要禁止：riba（利息/高利）、gharar（合同中过度的不确定性）和 maysir（赌博）。常见结构：Murabahah（成本加成买卖：卖方披露成本并加上约定利润）、Ijarah（租赁）、Musharakah（合伙，合伙人共享盈亏）、Mudarabah（一方出资、另一方出专业能力；利润按约定分配，资金损失由出资方承担）、Sukuk（资产支持或资产基础的证书，常与债券对比）、Takaful（基于互助的伊斯兰保险）。

## Why it matters for markets 对市场的意义
Islamic banks and Sukuk markets are a secondary topic for this US-focused vault, but they link to your coursework and to Malaysia's financial system. Sukuk and Islamic banking assets also appear in global debt and banking comparisons.
对这个以美国为主的知识库来说，伊斯兰银行和 Sukuk 市场属于次要主题，但与你的课程和马来西亚金融体系相关。Sukuk 和伊斯兰银行资产也会出现在全球债务和银行业的比较中。

## Example 例子 (illustrative 示意)
Hypothetical: instead of lending money at interest to buy equipment, an Islamic bank buys the equipment and sells it to the customer at a disclosed cost-plus price payable in installments (Murabahah).
假设：伊斯兰银行不是以利息放贷让客户买设备，而是自己买下设备，再以披露的成本加利润价格卖给客户，分期付款（Murabahah）。

## Common misconceptions 常见误区
- Islamic finance is not 'interest-free in name only'; structure, asset backing and risk sharing matter, although scholars and jurisdictions differ on some structures.
- 伊斯兰金融不只是“把利息换个名字”；结构、资产支持和风险分担很重要，不过学者和各司法辖区对某些结构有不同看法。
- Sukuk are not identical to conventional bonds.
- Sukuk 与传统债券并不相同。
- Follow your lecture slides for course definitions; this note is general background.
- 课程定义请以你的讲义为准；本笔记只是一般背景。

## Related 相关
[[Malaysia Bank Regulation and Islamic Finance]], [[Malaysia Banking Sector]], [[Secured Lending and Collateral]], [[Bank Regulation Map]], [[Credit Markets]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Regulatory thresholds, scope and effective dates change. Verify against the current rule text from the primary source (Federal Reserve, OCC, FDIC, SEC, BIS or Bank Negara Malaysia) before relying on any number here. as_of: 2026-10 (general background, not current-rule verification).
- This is educational background, not legal advice. For coursework, follow your own lecture slides and legal materials; where they differ, your course materials take priority.
- Describing a rule does not prove it caused a specific market move.
