---
title: "Malaysia Lens"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [guide, malaysia]
---
# Malaysia Lens

Malaysia is a secondary lens for this Vault. Use it when requested or when a direct exposure is relevant. Prefer BNM, DOSM, Bursa Malaysia and official company disclosures; see [[Source Registry]]. State whether an impact is direct, indirect or hypothetical. Do not assume US macro or AI demand translates one-for-one into Malaysian company earnings.
