---
title: "Malaysia Banking Sector 马来西亚银行业"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [马来西亚银行业]
tags: [malaysia]
---
# Malaysia Banking Sector 马来西亚银行业

## Role 角色
Banks are a large part of Bursa's benchmark index (verify current weights) and are the transmission channel for OPR changes.
银行在 Bursa 基准指数中占比较大（请核实最新权重），也是 OPR 变动的传导渠道。

## Earnings drivers 盈利驱动
NIM, loan growth, credit costs, fee income, CASA franchise, capital and dividends.
NIM、贷款增长、信贷成本、手续费收入、CASA 优势、资本和股息。

## Islamic banking 伊斯兰银行
Islamic financing is priced on profit rates and structured by contract (for example murabahah); rate changes still flow through benchmarks. Connect this to your Islamic finance course notes.
伊斯兰融资按利润率定价，并以合约结构（如 murabahah）安排；利率变动仍通过基准传导。可与你的伊斯兰金融课程笔记联系起来。

## Key numbers to watch 关键数字
NIM, NPL ratio, loan loss coverage, CET1, cost-to-income.
NIM、NPL 比率、贷款损失覆盖率、CET1、成本收入比。

## Related 相关
[[Bank Metrics]], [[Bank Earnings to Market]], [[OPR]], [[Monetary Policy]]

## My notes 我的笔记
(Company names are examples and change over time. Verify before relying on them. 公司名称仅为例子，会随时间变化，使用前请核实。)

## Evidence and limitations / 证据与限制
- Use current official Malaysian sources for policy and statistical claims: [[Source Registry]].
- Record the release date, reporting period, units, revisions and relevant jurisdiction. Do not use a US proxy as if it were Malaysian data.
- Treat market transmission to Malaysia as conditional on company exposure, currency, customer mix, export share and policy details.
- Company exposure and supply-chain relationships require current filings or direct evidence; thematic association is not proof.
