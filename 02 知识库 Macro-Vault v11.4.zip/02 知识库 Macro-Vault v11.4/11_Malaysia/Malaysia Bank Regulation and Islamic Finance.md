---
title: "Malaysia Bank Regulation and Islamic Finance 马来西亚银行监管与伊斯兰金融"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [马来西亚银行监管, BNM, FSA 2013, IFSA 2013, PIDM]
tags: [bank-regulation]
as_of: 2026-10
---
# Malaysia Bank Regulation and Islamic Finance 马来西亚银行监管与伊斯兰金融

## Definition 定义
Secondary note. Bank Negara Malaysia (BNM) is the central bank and the main financial regulator. Conventional banking is regulated under the Financial Services Act 2013 (FSA) and Islamic banking under the Islamic Financial Services Act 2013 (IFSA). Deposit insurance is provided by PIDM (Perbadanan Insurans Deposit Malaysia). BNM's Shariah Advisory Council is the highest Shariah authority for Islamic finance in Malaysia. Malaysian capital rules are based on Basel standards, implemented through BNM policy documents.
次要笔记。马来西亚国家银行（BNM）是中央银行，也是主要的金融监管机构。传统银行业受《2013年金融服务法》（FSA）监管，伊斯兰银行业受《2013年伊斯兰金融服务法》（IFSA）监管。存款保险由 PIDM（马来西亚存款保险公司）提供。BNM 的沙里亚咨询委员会是马来西亚伊斯兰金融的最高沙里亚权威。马来西亚的资本规则以巴塞尔标准为基础，通过 BNM 的政策文件实施。

## Why it matters for markets 对市场的意义
Use only when asked or when there is a direct link to the US topic being studied (for example, comparing US and Malaysian capital frameworks or deposit insurance). Verify all details with BNM primary sources and your course materials.
仅在被问到，或与所研究的美国主题有直接关联时使用（例如比较美国与马来西亚的资本框架或存款保险）。所有细节请以 BNM 一手资料和你的课程资料核实。

## Example 例子 (illustrative 示意)
Hypothetical comparison: both the US (FDIC) and Malaysia (PIDM) have deposit insurance, but coverage limits, scope and rules differ. Check each source.
假设性对比：美国（FDIC）和马来西亚（PIDM）都有存款保险，但保障上限、范围和规则不同，要分别查证。

## Common misconceptions 常见误区
- Do not assume US rules apply in Malaysia, or the reverse.
- 不要假设美国规则适用于马来西亚，反之亦然。
- Statute names and details should be confirmed against current official text; this note may be incomplete.
- 法规名称和细节应以最新官方文本为准；本笔记可能不完整。

## Related 相关
[[Malaysia Banking Sector]], [[OPR]], [[Islamic Finance Basics]], [[Bank Regulation Map]], [[Basel III and Capital Ratios]], [[Bank Runs and Deposit Insurance]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Regulatory thresholds, scope and effective dates change. Verify against the current rule text from the primary source (Federal Reserve, OCC, FDIC, SEC, BIS or Bank Negara Malaysia) before relying on any number here. as_of: 2026-10 (general background, not current-rule verification).
- This is educational background, not legal advice. For coursework, follow your own lecture slides and legal materials; where they differ, your course materials take priority.
- Describing a rule does not prove it caused a specific market move.
