---
title: "Malaysia Semiconductor Back-End 马来西亚半导体后段"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [马来西亚半导体后段]
tags: [malaysia]
---
# Malaysia Semiconductor Back-End 马来西亚半导体后段

## Position 定位
Malaysia is a significant hub for assembly, packaging and testing, with global multinationals and local firms (examples: Inari Amertron, Unisem, ViTrox, Greatech; verify).
马来西亚是重要的组装、封装和测试枢纽，有跨国公司和本地公司（例如 Inari Amertron、Unisem、ViTrox、Greatech；请核实）。

## What drives it 驱动因素
Global chip demand, big customers' orders, new capacity, USD/MYR.
全球芯片需求、大客户订单、新增产能、美元兑林吉特。

## Key numbers to watch 关键数字
E&E exports, order books, customer concentration, utilisation, USD/MYR.
E&E 出口、订单情况、客户集中度、产能利用率、美元兑林吉特。

## Risks 风险
Tariffs, export controls, customer concentration, currency swings.
关税、出口管制、客户集中、汇率波动。

## Related 相关
[[Malaysia EE Exports]], [[US Tech to Malaysia Semiconductor Stocks]], [[Geopolitics and Export Controls]]

## My notes 我的笔记
(Company names are examples and change over time. Verify before relying on them. 公司名称仅为例子，会随时间变化，使用前请核实。)

## Evidence and limitations / 证据与限制
- Use current official Malaysian sources for policy and statistical claims: [[Source Registry]].
- Record the release date, reporting period, units, revisions and relevant jurisdiction. Do not use a US proxy as if it were Malaysian data.
- Treat market transmission to Malaysia as conditional on company exposure, currency, customer mix, export share and policy details.
- Company exposure and supply-chain relationships require current filings or direct evidence; thematic association is not proof.
