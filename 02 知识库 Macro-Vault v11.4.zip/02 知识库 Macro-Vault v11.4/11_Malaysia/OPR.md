---
title: "OPR 隔夜政策利率"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [隔夜政策利率]
tags: [malaysia]
---
# OPR 隔夜政策利率

## Definition 定义
Overnight Policy Rate: BNM's main policy rate, decided by the Monetary Policy Committee at scheduled meetings.
隔夜政策利率：国家银行（BNM）的主要政策利率，由货币政策委员会在例行会议上决定。

## Market impact 市场影响
Feeds into banks' funding costs and floating-rate loan pricing; changes affect bank margins, borrowers and the ringgit.
影响银行融资成本和浮动利率贷款定价；变动会影响银行利润率、借款人和林吉特。

## Related 相关
[[Monetary Policy]], [[Interest Rates]], [[Federal Funds Rate]]
最新带日期数据（2026-10-27 新增）：[[12_Data/US Macro Snapshot 2026-10-27|美国宏观与市场数据快照 2026-10-27]]（第 9 节）

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Use current official Malaysian sources for policy and statistical claims: [[Source Registry]].
- Record the release date, reporting period, units, revisions and relevant jurisdiction. Do not use a US proxy as if it were Malaysian data.
- Treat market transmission to Malaysia as conditional on company exposure, currency, customer mix, export share and policy details.
- Company exposure and supply-chain relationships require current filings or direct evidence; thematic association is not proof.
