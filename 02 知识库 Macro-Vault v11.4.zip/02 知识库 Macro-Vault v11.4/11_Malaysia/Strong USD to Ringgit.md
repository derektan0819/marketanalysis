---
title: "Strong USD to Ringgit 强美元对林吉特的传导"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [强美元对林吉特的传导]
tags: [malaysia]
---
# Strong USD to Ringgit 强美元对林吉特的传导

1. Fed holds rates high or risk-off hits markets 联储维持高利率或市场避险
2. USD strengthens; capital flows out of emerging markets 美元走强，资金流出新兴市场
3. Ringgit weakens against USD 林吉特对美元贬值
4. Importers and USD-debt borrowers hurt; exporters benefit in ringgit terms 进口商和美元债务方受损，出口商以林吉特计算受益
5. Foreign selling can pressure Malaysian equities and bonds 外资卖出可能压制马来西亚股债

Related: [[Exchange Rate]], [[Federal Funds Rate]], [[Risk-On Risk-Off]], [[Trade Balance]]

## Evidence and limitations / 证据与限制
- Use current official Malaysian sources for policy and statistical claims: [[Source Registry]].
- Record the release date, reporting period, units, revisions and relevant jurisdiction. Do not use a US proxy as if it were Malaysian data.
- Treat market transmission to Malaysia as conditional on company exposure, currency, customer mix, export share and policy details.
- Company exposure and supply-chain relationships require current filings or direct evidence; thematic association is not proof.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Investing from Malaysia|马来西亚投资者：美元美债与 MYR 回报]]：美元赚了利息，换回马币仍可能亏损。
