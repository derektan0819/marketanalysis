---
title: "Inbox"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [guide, inbox]
---
# Inbox

Raw video links or transcripts can wait here until they are turned into a note in `18_Videos` ([[Video Guide]]). Capture raw links, questions and unverified claims here. Do not promote a claim to a research note until the source and date are recorded. Add a status (`unverified`, `triage`, `processed`) and move material sources into a source capture record using [[Source Capture Template]].
