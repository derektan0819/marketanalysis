---
title: "Daily Update Workflow — v11.3"
tags: [automation]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# Daily Update Workflow — v11.3

统一规则见 [[Research Protocol]]，交付见 [[One Page Research Brief]]。

本地执行入口：`python3 99_Automation/engine/vault.py run`。聊天触发“今日更新”只有在 AI 真正接入本地工具时才会执行。

1. 确定真实运行时间与资料截止，设置重点公司。
2. 查 SEC 新申报，保存原始响应和抓取记录；检查发行人身份。
3. 更新季度数据，区分 YTD/季度，计算并保存输入；同口径冲突进入例外。
4. 收集最新 10-Q、10-K 和财报 8-K（含 exhibit 候选），每次运行按可得申报更新。
5. 从相关笔记、历史、当前判断、可取得原文建立 AI 资料包；不得默认全部原文都适合一次上下文。
6. 若 AI 命令已设置，执行阅读并输出结构化分析。未设置则只输出数据状态与资料包。
7. 生成一页简报、保留运行历史、更新看板；单纯数据刷新不改变当前论点。
8. AI 输出通过格式、引用、覆盖与一致性检查后，按 auto_apply_thesis 与 auto_register_forecasts 设置对首次／修正／撤回保存论点旧版再更新，登记完整且有效的候选预测；也可手动使用 log-forecast。
9. 定期 review 到期项目；暂缺结果的继续保留。
10. 用户只处理核心例外；缺失电话会等明确列出；当前须在 extra_sources 配置可用来源，不宣称已实现自动发现所有电话会。

跨资产/共识/价格连接尚未配置时写未取得；不得把失败称为没有变化。宏观流程沿用原 playbook，但每份报告只分析与核心判断有关的事件。
