"""Contract tests use synthetic evidence and answers, never a live model or forecast."""
import copy, json, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'engine'))
from research import attach_context, validate_research, evidence_hash, decision_cache_key, thesis_from_brief
from vault import run_model
from reporting import readable_memo, HEADINGS


def fixture(root):
    snapshot={'company':{'ticker':'TEST','sector':'software_cloud'},'cutoff':'2026-10-19T00:00:00Z',
              'snapshot_relative_path':'12_Data/Companies/TEST/run.json',
              'observations':[{'observation_id':'O1','source_id':'S1','status':'source_recorded',
                               'metric':'revenue','value':100,'unit':'USD','period_type':'quarter',
                               'period_start':'2026-07-01','period_end':'2026-09-30'}],
              'sources':[{'source_id':'S1'}], 'documents':[{'source_id':'D1'}], 'issues':[], 'document_errors':[]}
    packet=attach_context(root,{'snapshot':snapshot,'knowledge_notes':{'rules':'MV-11.3'},'response_format':{}})
    refs={'observation_ids':['O1'],'source_ids':[]}
    unknown={'observation_ids':[],'source_ids':[]}
    brief={'headline':'经营暂稳，缺行情，股价尚不能判断。','valid_until':None,
           'facts':[dict(text='合成营收记录为 100，仅用于测试。',type='FACT',**refs)],
           'market_move':dict(status='unavailable',text='行情未取得。',**unknown),
           'transmission':[dict(stage=stage,cause='订单变化',effect='未来收入可能变化',mechanism='需要核对交付是否推迟',
                affected_party='公司交付部门与客户',mechanism_steps=['客户若延后收货，原定交付可能推迟。','若收入需要交付后确认，当季收入可能延后。'],
                illustration={'kind':'none','text':''},timing='可能在下一季度体现，须核对交付安排',
                break_condition='其他订单填补空缺会抵消影响',verification='对照实际交付和确认收入',
                evidence_scope='测试记录不能证明本次订单已推迟，整条路径待核实',
                relation='hypothesis',alternative='也可能为确认时间差',confidence='low',**unknown) for stage in ['primary','secondary']],
           'outlook':{'business':dict(direction='stable',horizon='未来1–4季度',reasoning='只用于测试结构',confidence='medium',**refs),
                      'price':dict(direction='unknown',horizon='未来1–4周',reasoning='未取得行情',confidence='low',**unknown)},
           'scenarios':[dict(name=name,conditions='条件待观察',path='条件成立后的假设路径',horizon='未来1–4季度',invalidation='条件未成立',ranking='unranked',confidence='low',probability=None,**unknown) for name in ['base','stronger','weaker']],
           'watchpoints':[{'signal':'订单','meaning':'交付是否改善','next_check':'下次披露，日期未核实'}],
           'change':dict(status='INITIAL',reason_code='INITIAL',previous_conclusion='尚无结构化记录',reason='首次建立记录',correction_detail='',**unknown),
           'data_gaps':['缺行情，不能判断股价方向。']}
    output={'protocol_version':'MV-11.3','summary':brief['headline'],'brief':brief,'sections':[],
            'coverage':[{'source_id':'D1','section':'测试章节','reviewed':True,'location':'line 1','limitations':'合成测试'}],
            'forecast_candidates':[]}
    return packet, output


def previous(packet, output):
    packet['previous_research']={'evidence_fingerprint':packet['evidence_fingerprint'],
        'protocol_fingerprint':packet['protocol_fingerprint'],'cutoff':packet['snapshot']['cutoff'],
        'brief':copy.deepcopy(output['brief'])}
    output['brief']['change'].update(status='MAINTAIN',reason_code='NO_NEW_EVIDENCE',previous_conclusion=output['brief']['headline'])


class ResearchTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.p,self.o=fixture(self.root)
    def errors(self): return validate_research(self.o,self.p)
    def test_valid_contract_and_missing_protocol(self):
        self.assertEqual(self.errors(),[])
        del self.o['protocol_version'];self.assertTrue(self.errors())
    def test_unknown_and_unresolved_evidence_rejected(self):
        self.o['brief']['facts'][0]['source_ids']=['invented'];self.assertTrue(self.errors())
        self.o['brief']['facts'][0]['source_ids']=[]
        self.p['snapshot']['observations'][0]['status']='needs_review'
        self.assertIn('fact 0: unresolved evidence',self.errors())
    def test_no_market_no_direction(self):
        self.o['brief']['outlook']['price'].update(direction='down',confidence='medium',observation_ids=['O1'])
        self.o['brief']['market_move'].update(status='observed',source_ids=['S1'])
        self.assertIn('market_move: prices unavailable',self.errors())
        self.assertIn('price: no direction allowed without market data',self.errors())
    def test_causal_hypothesis_cannot_be_high_confidence(self):
        self.o['brief']['transmission'][0]['confidence']='high'
        self.assertTrue(any('unverified mechanism' in e for e in self.errors()))
    def test_unfounded_probability_and_preferred_path(self):
        self.o['brief']['scenarios'][0].update(probability=0.9,ranking='preferred')
        self.assertTrue(any('numeric probabilities' in e for e in self.errors()))
        self.assertTrue(any('preferred path' in e for e in self.errors()))
    def test_same_evidence_reversal_blocked(self):
        previous(self.p,self.o);self.o['brief']['outlook']['business']['direction']='deteriorating'
        self.assertIn('change: MAINTAIN contradicts changed direction',self.errors())
        self.o['brief']['change']['status']='REVISE'
        self.assertIn('change: unsupported reversal on identical evidence',self.errors())
    def test_fake_new_evidence_blocked(self):
        previous(self.p,self.o)
        self.o['brief']['change'].update(reason_code='NEW_EVIDENCE',observation_ids=['O1'])
        self.assertIn('change: claimed new evidence but fingerprint unchanged',self.errors())
    def test_correction_allowed_and_explained(self):
        previous(self.p,self.o);self.o['brief']['outlook']['business']['direction']='mixed'
        self.o['brief']['change'].update(status='REVISE',reason_code='CORRECTION',observation_ids=['O1'])
        self.assertTrue(any('correction_detail' in e for e in self.errors()))
        self.o['brief']['change']['correction_detail']='旧报告把单季误当全年，现在按原文纠正。'
        self.assertEqual(self.errors(),[])
    def test_horizon_and_method_require_actual_change(self):
        previous(self.p,self.o);self.o['brief']['change']['reason_code']='HORIZON_CHANGE'
        self.assertIn('change: horizon did not change',self.errors())
        self.o['brief']['change']['reason_code']='METHOD_CHANGE'
        self.assertIn('change: protocol did not change',self.errors())
    def test_expiry_requires_precommitted_deadline(self):
        previous(self.p,self.o);self.o['brief']['change'].update(status='WITHDRAW',reason_code='EXPIRED')
        self.p['snapshot']['cutoff']='2026-12-01T00:00:00Z'
        self.assertIn('change: no previously recorded deadline has expired',self.errors())
        self.p['previous_research']['brief']['valid_until']='2026-11-01T00:00:00Z'
        self.assertEqual(self.errors(),[])
    def test_reading_coverage_required(self):
        self.o['coverage'][0]['reviewed']=False
        self.assertIn('coverage: required document reading not recorded',self.errors())
    def test_no_contradictory_second_summary(self):
        self.o['summary']='第二套不同的答案';self.assertTrue(self.errors())
        self.o['thesis_update']={'proposed':'不同的论点'}
        self.assertEqual(thesis_from_brief(self.o)['proposed'],self.o['brief']['headline'])
    def test_retrieval_metadata_not_new_evidence(self):
        snapshot=copy.deepcopy(self.p['snapshot']);before=evidence_hash(snapshot)
        snapshot['created_at']='later';snapshot['cutoff']='later';snapshot['sources'][0]['retrieved_at']='later'
        snapshot['snapshot_relative_path']='newrun.json'
        self.assertEqual(before,evidence_hash(snapshot))
        snapshot['observations'][0]['value']=101;self.assertNotEqual(before,evidence_hash(snapshot))
    def test_context_and_model_changes_invalidate_cache(self):
        first=decision_cache_key(self.p,['adapter'],{'model':'one'})
        self.assertNotEqual(first,decision_cache_key(self.p,['adapter'],{'model':'two'}))
        self.p['snapshot']['cutoff']='2026-10-20T00:00:00Z'
        self.assertNotEqual(first,decision_cache_key(self.p,['adapter'],{'model':'one'}))
    def test_exact_input_reuses_checked_answer(self):
        adapter=self.root/'adapter.py';adapter.write_text('import json\nprint('+repr(json.dumps(self.o,ensure_ascii=False))+')\n')
        config={'analysis_command':[sys.executable,str(adapter)]}
        first,status=run_model(self.root,config,self.p,self.root)
        self.assertFalse(first['machine_reference_check']['failures'])
        with patch('vault.subprocess.run',side_effect=AssertionError('Must use existing result')):
            second,status=run_model(self.root,config,self.p,self.root)
        self.assertTrue(second['consistency_record']['reused_identical_input'])
    def test_rejected_answer_never_cached(self):
        self.o['brief']['outlook']['price']['direction']='down'
        adapter=self.root/'adapter.py';adapter.write_text('print('+repr(json.dumps(self.o))+')\n')
        out,status=run_model(self.root,{'analysis_command':[sys.executable,str(adapter)]},self.p,self.root)
        self.assertEqual(status,'Needs Review');self.assertFalse(list(self.root.glob('12_Data/AI Decisions/*.json')))
    def test_rejected_ai_is_not_lead(self):
        self.o['brief']['headline']='REJECTED CLAIM';self.o['machine_reference_check']={'failures':['bad reference']}
        report=readable_memo(self.root,self.p['snapshot'],self.o,'Needs Review')
        self.assertNotIn('REJECTED CLAIM',report)
        self.assertTrue(all('## '+h in report for h in HEADINGS))
    def test_fixed_sections_and_safe_table(self):
        self.o['machine_reference_check']={'failures':[]}
        self.o['brief']['scenarios'][0]['path']='有条件 | 测试 [[不存在]]'
        report=readable_memo(self.root,self.p['snapshot'],self.o,'Draft')
        self.assertEqual([s[3:] for s in report.splitlines() if s.startswith('## ')],HEADINGS)
        self.assertIn('有条件 ／ 测试',report);self.assertNotIn('[[不存在]]',report)
    def test_malformed_previous_comparison_fails_closed(self):
        previous(self.p,self.o);self.o['brief']['outlook']['business']='invalid'
        self.assertTrue(self.errors())

    def test_generic_one_line_cause_is_rejected(self):
        step=self.o['brief']['transmission'][0]
        step['mechanism']='盈利承压，形成利空。'
        step.pop('mechanism_steps')
        self.assertTrue(any('explanatory steps' in e for e in self.errors()))
    def test_both_explanation_sections_required(self):
        self.o['brief']['transmission'][1]['stage']='primary'
        self.assertIn('transmission: require 1–2 paths in each stage',self.errors())
    def test_timing_conditions_and_verification_not_omitted(self):
        for field in ['affected_party','timing','break_condition','verification','evidence_scope']:
            with self.subTest(field=field):
                saved=self.o['brief']['transmission'][0].pop(field)
                self.assertTrue(any(field in e for e in self.errors()))
                self.o['brief']['transmission'][0][field]=saved
    def test_unknown_path_does_not_require_invented_steps(self):
        step=self.o['brief']['transmission'][0];step.update(relation='unknown',mechanism_steps=[])
        self.assertEqual(self.errors(),[])
        step['mechanism_steps']=['仅一句概括']
        self.assertTrue(any('explanatory steps' in e for e in self.errors()))
        step.update(relation='hypothesis',mechanism_steps=[])
        self.assertTrue(any('explanatory steps' in e for e in self.errors()))
    def test_example_requires_explicit_hypothetical_marker(self):
        step=self.o['brief']['transmission'][0]
        step['illustration']={'kind':'actual','text':'合成案例'}
        self.assertTrue(any('illustration' in e for e in self.errors()))
        step['illustration']['kind']='hypothetical';self.assertEqual(self.errors(),[])
        self.o['machine_reference_check']={'failures':[]}
        report=readable_memo(self.root,self.p['snapshot'],self.o,'Draft')
        self.assertIn('假设示例（非公司实际数据）',report)
    def test_details_survive_rendering_and_duplicates_fail(self):
        self.o['machine_reference_check']={'failures':[]}
        report=readable_memo(self.root,self.p['snapshot'],self.o,'Draft')
        step=self.o['brief']['transmission'][0]
        for field in ['affected_party','timing','break_condition','verification','evidence_scope']:
            self.assertIn(step[field],report)
        for value in step['mechanism_steps']:self.assertIn(value,report)
        step['mechanism_steps'][1]=step['mechanism_steps'][0]
        self.assertTrue(any('duplicated explanatory steps' in e for e in self.errors()))

if __name__=='__main__':unittest.main(verbosity=2)
