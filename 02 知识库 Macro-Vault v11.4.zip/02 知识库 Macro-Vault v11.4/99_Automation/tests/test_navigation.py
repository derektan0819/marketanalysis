import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'engine'))
from obsidian_audit import inspect_links
from network import source_markdown
from links import wiki, observation_link
from navigation import insert_navigation
from vault import dashboard


class NavigationTests(unittest.TestCase):
    def make(self, root, name, text):
        path = root/name; path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding='utf-8')

    def test_duplicate_short_name_is_not_silently_resolved(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.make(root, 'HOME.md', '[[Latest Brief]]\n[[NVDA/Latest Brief]]')
            self.make(root, 'NVDA/Latest Brief.md', 'NVDA')
            self.make(root, 'MSFT/Latest Brief.md', 'MSFT')
            result = inspect_links(root)
            self.assertEqual([x['kind'] for x in result['errors']], ['ambiguous_target'])
            self.assertEqual(result['unreachable_from_home'], ['MSFT/Latest Brief.md'])

    def test_real_anchors_and_escaped_table_aliases(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.make(root, 'HOME.md', '| 1 | [[Evidence#^OBS-a\\|证据]] |\n[[Evidence#Numbers]]\n[数字](Evidence.md#numbers)')
            self.make(root, 'Evidence.md', '# Numbers\n\nvalue\n\n^OBS-a\n')
            result = inspect_links(root)
            self.assertEqual(result['errors'], []); self.assertEqual(result['anchors_checked'], 3)
            self.make(root, 'Evidence.md', '# Other\n')
            kinds = [x['kind'] for x in inspect_links(root)['errors']]
            self.assertIn('missing_block', kinds); self.assertIn('missing_heading', kinds)

    def test_templates_code_comments_and_raw_sources_do_not_make_nodes(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.make(root, 'HOME.md', '[[Raw]]\n`[[example]]`\n```md\n[[fake]]\n```\n<!-- [[comment]] -->\n%% [[comment2]] %%')
            self.make(root, 'Raw.md', source_markdown('[[Injected node]]\n```\n[Fake](bogus.md)\n~~~'))
            result = inspect_links(root)
            self.assertEqual(result['errors'], []); self.assertEqual(result['internal_links_checked'], 1)

    def test_case_path_empty_table_and_attachment_errors_are_visible(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            self.make(root, 'HOME.md', '[[ ]]\n[[Folder/note]]\n| [[Folder/Note|Label]] |\n[[data.json]]\n[x](../outside.md)')
            self.make(root, 'Folder/Note.md', 'body')
            self.make(root, 'data.json', '{}')
            kinds = [x['kind'] for x in inspect_links(root)['errors']]
            self.assertCountEqual(kinds, ['empty_target','missing_target','unescaped_table_alias','outside_vault'])

    def test_history_citation_stays_on_its_own_run(self):
        old = {'snapshot_relative_path':'12_Data/Companies/NVDA/old.json','company':{'ticker':'NVDA'}}
        new = dict(old, snapshot_relative_path='12_Data/Companies/NVDA/new.json')
        self.assertIn('/old/NVDA/Evidence#^OBS-a', observation_link(old,'OBS-a'))
        self.assertIn('/new/NVDA/Evidence#^OBS-a', observation_link(new,'OBS-a'))
        self.assertNotEqual(observation_link(old,'OBS-a'), observation_link(new,'OBS-a'))

    def test_navigation_refresh_preserves_human_thesis_and_does_not_duplicate(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d)/'Current Thesis.md'; path.write_text('Human thesis\n')
            insert_navigation(path, 'old nav'); insert_navigation(path, 'new nav')
            text = path.read_text()
            self.assertTrue(text.startswith('Human thesis\n'))
            self.assertNotIn('old nav', text); self.assertEqual(text.count('BEGIN GENERATED'), 1)

    def test_dashboard_company_link_and_failed_company_handling(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); self.make(root,'04_Companies/NVDA/Latest Brief.md','NVDA')
            dashboard(root,[{'ticker':'NVDA'},{'ticker':'NEW'}],'2026-10-19T00:00:00Z',updated_at='original')
            text = (root/'Today Dashboard.md').read_text()
            self.assertIn('[[04_Companies/NVDA/Latest Brief\\|NVDA]]',text)
            self.assertNotIn('[[04_Companies/NEW/',text)
            self.assertIn('数据运行时间：original',text)


if __name__ == '__main__':
    unittest.main(verbosity=2)
