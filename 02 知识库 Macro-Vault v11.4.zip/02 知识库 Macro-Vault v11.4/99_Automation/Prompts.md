---
title: "常用指令 — MV-11.3"
tags: [automation]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# 常用指令 — MV-11.3

所有分析共用 [[AI START HERE]] 与 [[Research Protocol]]，输出共用 [[One Page Research Brief]]。以下仅改变任务，不改变证据纪律。

## 分析一家公司或事件
“按 MV-11.3 分析〔公司／事件〕。先读旧判断，解释发生什么、直接和后续影响，给出有条件的未来路径，最后说明维持或改变的依据。”

## 今日更新
“读取 Today Dashboard、Review Queue 与最新资料包，只突出实质变化。能运行且已授权的本地 runner 才执行 run；没有新资料不能说没有变化。”

## 更新判断
“比较 Current Thesis、Current Research State.json（若存在）、最近报告与新证据。记录 INITIAL／MAINTAIN／REVISE／WITHDRAW；修正要说明具体依据，保存旧版本后更新。”

## 记录预测与复盘
“按 [[Prediction Log]] 保存可核验的未来指标、条件、期限和真实创建时间。到期按 review 结果区分命中、未命中、条件未发生、待数据与不可判断。历史示例不计入实时成绩。”

## 宏观、行业与视频
“只采用与问题相关的 playbook。视频观点先追溯一手事实。跨资产资料缺失要说明影响；不同观点可以并存。默认不启用收费服务。”
