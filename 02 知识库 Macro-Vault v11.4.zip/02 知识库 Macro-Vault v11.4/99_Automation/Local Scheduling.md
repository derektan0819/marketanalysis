---
title: "Local Scheduling"
tags: [automation]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# Local Scheduling

ZIP 不会自行安装任何定时任务。先手动跑通，再决定运行时间。默认建议每个美股交易日后的马来西亚早上研究；节假日仍可检查新披露但不能假定市场开盘。

## Mac/Linux 简单方式
使用你熟悉的系统任务调度器运行以下命令，working directory 指向完整 Macro-Vault 路径：
```bash
/absolute/path/to/python3 /absolute/path/to/Macro-Vault/99_Automation/engine/vault.py run
```
在调度环境中配置 SEC_USER_AGENT，及需要的 AI 环境变量。设备需开机联网；终端里 export 的变量不会自动进入调度器。
程序有 run.lock 防止重叠、HTTP 缓存和每次运行记录。若进程意外中断留下锁，确认没有运行后才删除 12_Data/run.lock。

## 可选：常驻循环
```bash
python3 99_Automation/examples/scheduler.py --hour 8 --minute 0
```
该脚本按 Asia/Kuala_Lumpur 在工作日每天执行一次 run，再执行 review；保持终端和电脑运行。不会自动注册系统服务。启动时已过当天时间则从下一工作日开始。查看终端和 12_Data/Runs 判断结果。
不支持关机期间补跑或推送通知；要全天候运行，部署到你自己的常开设备。人工随时可单次 run。
