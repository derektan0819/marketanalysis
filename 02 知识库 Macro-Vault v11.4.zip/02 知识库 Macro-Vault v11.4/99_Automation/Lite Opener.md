---
title: "Lite Opener — MV-11.3"
tags: [automation]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# Lite Opener — MV-11.3

请先实际读取 [[AI START HERE]]、[[Research Protocol]]、[[One Page Research Brief]] 和本次对象的旧判断。按七段格式用中文解释：发生什么、为什么、后续影响、未来情景、观察信号、相对前次变化、缺口与证据。同一证据不得无理由反转；发现旧错误要具体纠正。原因与后续影响要详细展开：影响谁、2–4 步过程、何时体现、什么会阻断、看什么验证；必要时给明确标注的假设例子；经营与股价分开，不编造行情、共识或概率。没有文件读取或写入能力要如实说明。
