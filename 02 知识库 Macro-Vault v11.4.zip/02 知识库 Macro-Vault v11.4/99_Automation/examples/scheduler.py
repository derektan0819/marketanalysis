#!/usr/bin/env python3
"""Opt-in foreground weekday runner. Does not install a background service."""
import argparse, subprocess, sys, time
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

p=argparse.ArgumentParser();p.add_argument('--hour',type=int,default=8);p.add_argument('--minute',type=int,default=0)
args=p.parse_args()
if not (0<=args.hour<=23 and 0<=args.minute<=59): p.error('Invalid time')
root=Path(__file__).resolve().parents[2];runner=root/'99_Automation/engine/vault.py';zone=ZoneInfo('Asia/Kuala_Lumpur')
while True:
    current=datetime.now(zone);due=current.replace(hour=args.hour,minute=args.minute,second=0,microsecond=0)
    if due<=current: due+=timedelta(days=1)
    while due.weekday()>4: due+=timedelta(days=1)
    print('Next run:',due.isoformat(),flush=True)
    while datetime.now(zone)<due: time.sleep(min(30,max(0,(due-datetime.now(zone)).total_seconds())))
    for command in ['run','review']:
        result=subprocess.run([sys.executable,str(runner),command],cwd=root)
        print(command,'exit status',result.returncode,flush=True)
