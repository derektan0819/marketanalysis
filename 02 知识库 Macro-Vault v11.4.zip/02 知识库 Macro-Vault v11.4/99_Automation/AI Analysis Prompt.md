---
title: "AI Analysis Prompt — MV-11.3"
tags: [automation]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# AI Analysis Prompt — MV-11.3

请实际读取 [[AI START HERE]]、[[Research Protocol]] 与 [[One Page Research Brief]]，再分析提供的公司 AI Research Packet.json 和关联原文。不能访问整个仓库时，以资料包 knowledge_notes 内嵌的同版规则为准。

先确认公司／事件、资料截止、可读取的文件、旧判断与缺口，再提取最多三项事实。将“事件 → 直接影响 → 后续影响”拆开，每条路径先说明影响谁，再用 2–4 步讲清中间过程，并写证据支持范围、时间、阻断条件与验证信号。必要时用明确标注的假设例子解释术语。两段各选 1–2 条重要路径，不只写“利空／承压”。经营与股价分开，提供基准／较强／较弱三个条件情景，解释什么会推翻它们。没有充分证据就说尚不能判断，不为填表编造数字或概率。

先比较 previous_research。没有结构化旧记录时仍须阅读 prior_thesis，并说明本次首次建立新格式记录。相同证据不得无解释反转；改口要写新证据或具体纠错，不能只说“重新考虑”。

普通聊天：用中文输出模板的七段，正文目标 1,000–1,600 字，原因与后续影响约占一半，复杂问题可适量增加；把证据与记录放末尾。无法写文件时明确未保存，并提供可复制的后续记录。
自动 adapter：stdout 只返回符合 [[AI Output Contract]] 的 JSON 对象，protocol_version 为 MV-11.3；brief 是唯一主结论，summary 必须等于 brief.headline。完整格式以 packet.response_format 为准。不得输出 Markdown 围栏。

当前数据引擎没有行情、发布前共识和宏观接口，不得在 JSON 中假装这些输入存在。普通聊天如有搜索能力，可核实免费公开来源并标明时间与链接；这不表示已经替本地引擎接通数据。

## 美债相关问题补充

若利率、美债或资金市场与本次公司问题相关，实际阅读 packet 中的 [[10_Playbooks/US Treasury Research Playbook]] 和 [[21_US_Treasuries/US Treasury Knowledge Map]]。完整仓库可按链接检索专题；只有 packet 时只声明读过内嵌内容，缺少专题正文或市场证据须注明。该补充不更改 MV-11.3 JSON 格式，也不把 data_availability 的缺失状态改成可用。
