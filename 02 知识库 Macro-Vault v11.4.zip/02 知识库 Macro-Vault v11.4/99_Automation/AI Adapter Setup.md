---
title: "AI Adapter Setup"
tags: [automation]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# AI Adapter Setup

## 配置方式
程序通过 settings.json 的 analysis_command 调用你自己的 AI 适配程序。默认空数组，不会向任何 AI 供应商发送文件。

```json
"analysis_command": ["python3", "/absolute/path/to/your_ai_adapter.py"]
```
适配程序从 stdin 读取完整 JSON 请求，调用你有权限使用的模型/API，并在 stdout 返回单一 JSON 对象（格式见 [[AI Output Contract]]）。日志写 stderr，密钥只从环境变量读取。
程序使用 argv 数组，不通过 shell；不要把财报内容当命令执行。你填入的命令会在你电脑上运行，应使用你信任的适配器。

## 已附的可运行连接
examples/http_ai_adapter.py 支持常见的 Chat Completions JSON 接口形状；它不绑定任何供应商，也不保证所有模型服务兼容。先对照你供应商的接口文档。
环境变量：MV_AI_URL（完整 HTTPS 接口 URL）、MV_AI_MODEL、MV_AI_KEY。不要把 key 放入 Vault。
settings.json 可填写：
```json
"analysis_command": ["python3", "99_Automation/examples/http_ai_adapter.py"]
```
内置适配器从已保存原文分段阅读，再汇总。每段保留源文件行号和模型处理记录，已处理片段按内容和模型缓存。默认每次最多 24 个新的阅读请求，再做一次汇总；可用 MV_AI_MAX_CHUNKS（1–200）调整。超过预算会明确显示不完整，下一次可利用缓存继续。段落摘要不等于独立语义核验。此设置会影响模型调用次数和费用。

## 验证
先只跑一家 `run --tickers NVDA`。检查 Run History 下 ai-output.json、引用检查、覆盖和结论。传输成功不等于语义通过。
每个模型可能输出错误 JSON、遗漏章节或编造结论；程序会阻止未知 ID/明显未核实依赖，但自由文本仍需保留证据支持状态。
不要配置演示适配器作为实际 AI。测试仅验证协议与错误处理，不证明预测能力。


auto_apply_thesis 和 auto_register_forecasts 沿用默认开启：只在 MV-11.3 格式、引用、覆盖与一致性检查通过时执行。首次／修正／撤回先保存论点旧版本再更新；维持不重复覆盖。每条预测另受登记校验。若只想看草案，把这两个字段设为 false。

## v11.3 的一致性记录

配置文件在 99_Automation/config/settings.json。reuse_identical_analysis 为 true 时，对完全相同的研究输入复用已通过检查的回答；截止、旧判断、证据、规则或模型设置变化会重新分析。缓存不是供应商能力保证。自定义适配器更换内部模型或提示时，更新 analysis_revision；需要强制重新研究时可暂设 reuse_identical_analysis 为 false，但仍须解释判断变化。

Current Research State.json 保存最近通过检查的结构化观点；历史 ai-output.json 留在每次 Run History。不要手动删除旧状态来规避改口检查。上传文件给聊天 AI 不会自动使用本地缓存，须连同旧报告一起提供。

示例适配器采用 Chat Completions 形状，不能直接假设兼容 Claude Messages 等不同接口；按你已有服务接适配器。该升级没有开通任何新订阅或付费数据。
