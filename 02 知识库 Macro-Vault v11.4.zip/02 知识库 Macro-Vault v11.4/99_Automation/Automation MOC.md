---
title: "Automation MOC — 自动化"
tags: [index, moc]
created: 2026-10-27
updated: 2026-10-27
source: "自动整理：完整列出 99_Automation 的全部文件（2026-10-27）"
---

# Automation MOC — 自动化

[[00_Index/Master Index|总索引]] · [[HOME|首页]]

本文件夹共 22 个文件，其中笔记 6 篇。以下按路径完整列出，笔记显示标题。

## 笔记

- [[99_Automation/AI Adapter Setup|AI Adapter Setup]]
- [[99_Automation/AI Analysis Prompt|AI Analysis Prompt — MV-11.3]]
- [[99_Automation/Daily Update Workflow|Daily Update Workflow — v11.3]]
- [[99_Automation/Lite Opener|Lite Opener — MV-11.3]]
- [[99_Automation/Local Scheduling|Local Scheduling]]
- [[99_Automation/Prompts|常用指令 — MV-11.3]]

## 机器可读文件

JSON、CSV、HTML、TXT、PY 等文件，可在 Obsidian 中打开或用外部编辑器查看。

- [[99_Automation/config/settings.json|config/settings.json]]
- [[99_Automation/engine/data.py|engine/data.py]]
- [[99_Automation/engine/forecast.py|engine/forecast.py]]
- [[99_Automation/engine/links.py|engine/links.py]]
- [[99_Automation/engine/navigation.py|engine/navigation.py]]
- [[99_Automation/engine/network.py|engine/network.py]]
- [[99_Automation/engine/obsidian_audit.py|engine/obsidian_audit.py]]
- [[99_Automation/engine/reporting.py|engine/reporting.py]]
- [[99_Automation/engine/research.py|engine/research.py]]
- [[99_Automation/engine/vault.py|engine/vault.py]]
- [[99_Automation/examples/forecast.example.json|examples/forecast.example.json]]
- [[99_Automation/examples/http_ai_adapter.py|examples/http_ai_adapter.py]]
- [[99_Automation/examples/scheduler.py|examples/scheduler.py]]
- [[99_Automation/tests/test_navigation.py|tests/test_navigation.py]]
- [[99_Automation/tests/test_pipeline.py|tests/test_pipeline.py]]
- [[99_Automation/tests/test_research.py|tests/test_research.py]]
