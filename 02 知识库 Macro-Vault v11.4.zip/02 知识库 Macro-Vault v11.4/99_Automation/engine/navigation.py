"""Offline navigation/evidence views derived from saved snapshots, never new claims."""
import json
from pathlib import Path
from data import recent_quarters, number
from links import wiki, evidence_path, observation_link, source_link, company_navigation

START = '<!-- BEGIN GENERATED NAVIGATION -->'
END = '<!-- END GENERATED NAVIGATION -->'


def save(root, relative, text):
    p = Path(root) / relative
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text.rstrip() + '\n', encoding='utf-8')


def insert_navigation(path, text):
    path = Path(path)
    existing = path.read_text(encoding='utf-8') if path.exists() else '# ' + path.stem + '\n'
    block = START + '\n' + text.strip() + '\n' + END
    if START in existing and END in existing:
        a = existing.index(START); b = existing.index(END, a) + len(END)
        existing = existing[:a] + block + existing[b:]
    else:
        existing = existing.rstrip() + '\n\n' + block + '\n'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(existing, encoding='utf-8')


def selected_observations(snapshot):
    by_id = {o['observation_id']: o for o in snapshot['observations']}
    ends = set(recent_quarters(snapshot['observations']))
    selected = {oid for oid, o in by_id.items()
                if o['period_end'] in ends and o['period_type'] in {'quarter', 'instant'}}
    todo = list(selected)
    while todo:
        for oid in by_id[todo.pop()].get('input_observation_ids', []):
            if oid not in selected and oid in by_id:
                selected.add(oid); todo.append(oid)
    return sorted((by_id[oid] for oid in selected),
                  key=lambda o: (o['period_end'], o['metric'], o['period_type'], o['observation_id']))


def write_evidence(root, snapshot):
    ticker = snapshot['company']['ticker']
    rel = evidence_path(snapshot); report = str(Path(rel).with_name('Brief.md'))
    lines = [f'# {ticker} — 本次数据与原文证据', '',
             f"资料截止：{snapshot['cutoff']}。", '',
             wiki(report, '本次简报') + ' · ' + company_navigation(ticker), '',
             '本页是保存快照的阅读视图；链接表示引用或计算依赖，不表示独立验证或因果关系。',
             '包含最近八季的观察值，以及计算所需的较早输入。后续运行各自生成证据页，旧简报不会跳到新快照。', '',
             '## 原始快照', wiki(snapshot['snapshot_relative_path'], 'JSON 快照（外部编辑器）'), '',
             '## 财报原文']
    for d in snapshot.get('documents', []):
        lines.append('- ' + source_link(d['source_id'], d.get('document_role', '原文')) +
                     '；期间／事件日：' + str(d.get('period_end') or d.get('event_date') or '未标注'))
        if d.get('text_path'):
            lines.append('  提取正文：' + wiki(d['text_path'], d['source_id'] + ' 正文'))
    lines += ['', '## 数字与计算依赖']
    for o in selected_observations(snapshot):
        oid = o['observation_id']
        lines += ['', f"### {o['metric']} · {o['period_end']} · {o['period_type']}", '',
                  f"**{number(o['value'], o['unit'])}**；状态：{o['status']}。证据 ID：{oid}。", '',
                  '^' + oid, '',
                  f"期间：{o.get('period_start') or '时点'} → {o['period_end']}；口径：{o.get('basis', '未注明')}。",
                  '来源：' + source_link(o['source_id']) + '；申报编号：' + str(o.get('accession') or '见计算输入') + '。',
                  '字段：`' + str(o.get('tag') or '派生值') + '`；申报日期：' + str(o.get('filed') or '见计算输入') + '。']
        if o.get('source_url'):
            lines.append('原始申报链接：' + o['source_url'])
        if o.get('reported_definition'):
            lines.append('定义：' + str(o['reported_definition']))
        if o.get('formula'):
            lines.append('计算：`' + o['formula'] + '`；输入：' +
                         '、'.join(observation_link(snapshot, oid) for oid in o.get('input_observation_ids', [])))
        if o.get('review_reasons'):
            lines.append('复核原因：' + json.dumps(o['review_reasons'], ensure_ascii=False))
    save(root, rel, '\n'.join(lines))


def render_review_queue(root, queue, results):
    by_ticker = {r['ticker']: r for r in results}
    lines = ['# 需要复核的事项', '', wiki('Today Dashboard.md', '今日看板') + ' · ' + wiki('14_Reports/Run History Index.md', '运行历史'), '',
             '仅展示本次已运行公司的例外；旧结果保存在运行历史。点击证据 ID 可以定位具体数字及计算输入。', '']
    for q in queue:
        ticker = q['entity']; record = by_ticker.get(ticker, {})
        label = wiki(f'04_Companies/{ticker}/Latest Brief.md', ticker) if (Path(root)/f'04_Companies/{ticker}/Latest Brief.md').exists() else ticker
        issue = q['issue']
        if issue == 'Latest-quarter observations require reconciliation':
            issue = '最新季度存在需核对的数据或跨申报计算'
        lines += ['## ' + ticker, '', '- 公司：' + label, '- 严重程度：' + q['severity'],
                  '- 问题：' + (issue if isinstance(issue, str) else json.dumps(issue, ensure_ascii=False))]
        if record.get('snapshot'):
            snapshot = json.loads((Path(root)/record['snapshot']).read_text())
            for oid in q.get('observations', []):
                lines.append('- 待复核：' + observation_link(snapshot, oid))
        lines.append('')
    if not queue:
        lines.append('暂无抓取／结构检查例外。语义阅读状态请看各公司简报。')
    save(root, 'Review Queue.md', '\n'.join(lines))


def refresh_navigation(root):
    """Build indexes; preserve user prose outside explicit navigation markers."""
    root = Path(root)
    snapshots = [json.loads(p.read_text()) for p in sorted((root/'12_Data/Companies').glob('*/*.json'))]
    by_ticker = {}; source_refs = {}; source_texts = {}
    for snap in snapshots:
        ticker = snap['company']['ticker']
        by_ticker.setdefault(ticker, []).append(snap)
        write_evidence(root, snap)
        for rec in snap['sources'] + snap.get('documents', []):
            source_refs.setdefault(rec['source_id'], set()).add(ticker)
            if rec.get('text_path'):
                source_texts.setdefault(rec['source_id'], set()).add(rec['text_path'])
    source_index = ['# 原始来源索引', '', wiki('HOME.md', '首页') + ' · ' + wiki('13_Sources/Source Registry.md', '来源规则'), '',
                    '来源记录连接保存正文、官方下载地址和引用公司。抓取成功不表示已完成语义核验。', '']
    # Source Registry may live under another directory in older vaults.
    registry = next(root.rglob('Source Registry.md'), None)
    source_index[2] = wiki('HOME.md', '首页') + (' · ' + wiki(registry.relative_to(root).as_posix(), '来源规则') if registry else '')
    records = list(sorted((root/'13_Sources/Raw').glob('*.meta.json')))
    for p in records:
        rec = json.loads(p.read_text()); sid = rec['source_id']
        texts = source_texts.get(sid, set()).copy()
        if rec.get('text_path'):
            texts.add(rec['text_path'])
        # Include generic extraction and EX-99 extraction if both exist.
        texts.update(q.relative_to(root).as_posix() for q in (root/'13_Sources/Raw').glob(sid + '*.md'))
        label = sid + ' · ' + rec.get('source_type', 'source')
        source_index.append('- ' + source_link(sid, label))
        lines = ['# ' + label, '', wiki('13_Sources/Source Index.md', '所有来源'), '',
                 '官方下载地址：' + rec['source_url'], '',
                 '首次保存时间：' + str(rec.get('retrieved_at')) + '；发布时间：' + str(rec.get('published_at') or '未记录') + '。',
                 'SHA-256（下载原始文件）：`' + rec['sha256'] + '`。',
                 '内容核验状态：未由本索引认证。', '', '## 保存的正文']
        for text in sorted(texts):
            lines.append('- ' + wiki(text, 'EX-99 正文' if '.earnings.' in text else '完整提取文本'))
        if not texts:
            lines.append('这是结构化 API 数据，没有 Markdown 正文；数字与计算见公司证据索引。')
        lines += ['', '原始下载文件：' + wiki(rec['raw_path'], '原始文件（可能使用外部编辑器）'),
                  '元数据：' + wiki(p.relative_to(root).as_posix(), '来源元数据（JSON）'), '', '## 相关公司']
        for ticker in sorted(source_refs.get(sid, set())):
            lines.append('- ' + wiki(f'04_Companies/{ticker}/Evidence Index.md', ticker + ' 证据索引'))
        if rec.get('source_type') == 'issuer_preliminary_release' and 'samsung.com' in rec['source_url']:
            case = next(root.rglob('Case Study Samsung Q3 2026 Preliminary Earnings.md'), None)
            if case:
                lines.append('- ' + wiki(case.relative_to(root).as_posix(), 'Samsung 预告案例'))
        save(root, f'13_Sources/Records/{sid}.md', '\n'.join(lines))
    save(root, '13_Sources/Source Index.md', '\n'.join(source_index))
    run_index = ['# 运行与报告历史', '', wiki('Today Dashboard.md', '今日看板') + ' · ' + wiki('04_Companies/Company Research Index.md', '公司索引'), '',
                 '每次简报的证据固定指向同一次快照。这里只补充导航，没有重新抓取数据，也没有补写历史预测。', '']
    for path in sorted((root/'12_Data/Runs').glob('*.json'), reverse=True):
        run = json.loads(path.read_text()); run_index += ['## ' + run['run_id'], '', '资料截止：' + run['cutoff'], '']
        for item in run['results']:
            if item.get('report'):
                run_index.append('- ' + wiki(item['report'], item['ticker'] + ' 简报') + ' · ' +
                                 wiki(str(Path(item['report']).with_name('Evidence.md')), '本次证据'))
        run_index += ['', wiki(path.relative_to(root).as_posix(), '运行状态与异常 JSON'), '']
    save(root, '14_Reports/Run History Index.md', '\n'.join(run_index))
    for ticker, snaps in by_ticker.items():
        snaps.sort(key=lambda s: (s['created_at'], s['snapshot_relative_path']))
        latest = snaps[-1]; base = f'04_Companies/{ticker}'
        lines = [f'# {ticker} — 证据与历次报告', '', company_navigation(ticker), '',
                 '最新证据：' + wiki(evidence_path(latest), '最新八季数据及计算输入'), '',
                 '## 历次快照']
        for snap in reversed(snaps):
            ep = evidence_path(snap)
            lines.append('- ' + snap['cutoff'] + '：' + wiki(str(Path(ep).with_name('Brief.md')), '简报') + ' · ' + wiki(ep, '证据'))
        lines += ['', '## 机器可读文件', '- ' + wiki(base+'/Financial Observations.csv', '数值索引 CSV'),
                  '- ' + wiki(base+'/AI Research Packet.json', 'AI 阅读包 JSON')]
        save(root, base + '/Evidence Index.md', '\n'.join(lines))
        for filename in ['Company Profile.md', 'Current Thesis.md', 'Thesis History.md']:
            insert_navigation(root/base/filename, '## 相关入口\n\n' + company_navigation(ticker) + '\n\n' + wiki('04_Companies/Company Research Index.md', '所有公司'))
    index = ['# Company Research Index', '', wiki('Today Dashboard.md', '今日看板') + ' · ' + wiki('HOME.md', '首页'), '',
             '这是已建立档案的研究名单，不是买入推荐。每个入口均使用公司完整路径，避免同名笔记混连。', '',
             '| 公司 | 一页简报 | 八季数据 | 当前判断 | 历史判断 | 证据与报告 |', '|---|---|---|---|---|---|']
    for ticker in sorted(by_ticker):
        base = f'04_Companies/{ticker}'
        cells = [(base+'/Company Profile.md', ticker), (base+'/Latest Brief.md', '简报'),
                 (base+f'/{ticker} - Data History.md', '数据'), (base+'/Current Thesis.md', '判断'),
                 (base+'/Thesis History.md', '历史'), (base+'/Evidence Index.md', '证据')]
        index.append('| ' + ' | '.join(wiki(path, label, table=True) for path, label in cells) + ' |')
    save(root, '04_Companies/Company Research Index.md', '\n'.join(index))
    return {'snapshots': len(snapshots), 'source_records': len(records), 'companies': len(by_ticker)}
