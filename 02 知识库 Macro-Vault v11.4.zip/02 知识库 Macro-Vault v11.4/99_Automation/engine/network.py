"""Allowlisted source capture with immutable bodies and separate retrieval receipts."""
from datetime import datetime, timezone
from hashlib import sha256
from html.parser import HTMLParser
from pathlib import Path
import json, os, re, time, urllib.error, urllib.parse, urllib.request

def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')

def source_markdown(text, title='Source text — untrusted evidence'):
    # Source contents must not manufacture Obsidian links/headings or executable embeds.
    fence = '`' * max(3, 1 + max((len(m[0]) for m in re.finditer(r'`+', text)), default=0))
    return '# ' + title + '\n\n' + fence + 'text\n' + text.rstrip('\n') + '\n' + fence + '\n'

def write_json(path, payload):
    path=Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temp=path.with_name(path.name+'.tmp')
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    os.replace(temp,path)

class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts=[]; self.hidden=0
    def handle_starttag(self,tag,attrs):
        if tag in {'script','style','ix:hidden'}: self.hidden+=1
        if not self.hidden and tag in {'p','div','tr','h1','h2','h3','li','br'}: self.parts.append('\n')
        if not self.hidden and tag in {'td','th'}: self.parts.append('\t')
    def handle_endtag(self,tag):
        if tag in {'script','style','ix:hidden'}: self.hidden=max(0,self.hidden-1)
    def handle_data(self,data):
        if not self.hidden: self.parts.append(data)
    def text(self):
        return '\n'.join(line.strip() for line in ''.join(self.parts).splitlines() if line.strip())

class Capture:
    def __init__(self,root,config):
        self.root=Path(root); self.config=config
        self.allowed=set(config.get('allowed_hosts', ['data.sec.gov','www.sec.gov']))
        self.agent=os.environ.get('SEC_USER_AGENT') or config.get('sec_user_agent')
        self.last_request=0
    def validate(self,url):
        p=urllib.parse.urlsplit(url)
        if p.scheme!='https' or p.hostname not in self.allowed or p.username or p.password or p.port not in {None,443}:
            raise ValueError('URL must use HTTPS and an explicitly allowed host')
        return url
    def get(self,url,kind='api',published_at=None,cache_hours=6):
        self.validate(url)
        if not self.agent: raise ValueError('Set SEC_USER_AGENT to your application name and contact before live collection')
        cache=self.root/'12_Data/Cache'/ (sha256(url.encode()).hexdigest()+'.json')
        if cache.exists():
            rec=json.loads(cache.read_text())
            age=(datetime.now(timezone.utc)-datetime.fromisoformat(rec['retrieved_at'])).total_seconds()
            raw=self.root/rec['raw_path']
            if age<cache_hours*3600 and raw.is_file(): return raw.read_bytes(),rec
        owner=self
        class Redirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self,req,fp,code,msg,headers,newurl):
                owner.validate(newurl)
                return super().redirect_request(req,fp,code,msg,headers,newurl)
        opener=urllib.request.build_opener(Redirect())
        for attempt in range(3):
            time.sleep(max(0,0.25-(time.monotonic()-self.last_request)))
            self.last_request=time.monotonic()
            try:
                req=urllib.request.Request(url,headers={'User-Agent':self.agent,'Accept-Encoding':'identity'})
                with opener.open(req,timeout=30) as response:
                    self.validate(response.url)
                    body=response.read(40*1024*1024+1)
                    if len(body)>40*1024*1024: raise ValueError('Source too large; capture explicitly with a larger reviewed limit')
                    content_type=response.headers.get('Content-Type','')
                    final_url=response.url
                break
            except urllib.error.HTTPError as exc:
                if exc.code not in {429,500,502,503,504} or attempt==2: raise
                time.sleep(2**attempt)
            except (TimeoutError,urllib.error.URLError):
                if attempt==2: raise
                time.sleep(2**attempt)
        retrieved=now(); body_hash=sha256(body).hexdigest()
        sid='SRC-'+sha256((url+body_hash).encode()).hexdigest()[:24]
        extension='.json' if 'json' in content_type or url.endswith('.json') else '.pdf' if 'pdf' in content_type else '.html'
        rel=f'13_Sources/Raw/{sid}{extension}'; dest=self.root/rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        if not dest.exists(): dest.write_bytes(body)
        rec={'source_id':sid,'source_url':url,'final_url':final_url,'source_type':kind,
             'published_at':published_at,'retrieved_at':retrieved,'sha256':body_hash,
             'raw_path':rel,'content_type':content_type,'fetch_status':'success',
             'semantic_verified':False,'text_path':None}
        if extension=='.html':
            p=TextExtractor(); p.feed(body.decode('utf-8','replace'))
            textrel=f'13_Sources/Raw/{sid}.md'
            (self.root/textrel).write_text(source_markdown(p.text()), encoding='utf-8')
            rec['text_path']=textrel
        meta=self.root/f'13_Sources/Raw/{sid}.meta.json'
        if not meta.exists(): write_json(meta,rec)
        receipt=self.root/'12_Data/Fetch Receipts.jsonl';receipt.parent.mkdir(parents=True,exist_ok=True)
        with receipt.open('a',encoding='utf-8') as f: f.write(json.dumps(rec,ensure_ascii=False)+'\n')
        write_json(cache,rec)
        return body,rec
