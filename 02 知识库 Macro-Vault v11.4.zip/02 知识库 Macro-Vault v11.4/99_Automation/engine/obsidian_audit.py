"""Static link/anchor/graph audit; does not claim to emulate Obsidian's UI.

Deliberately requires unique short names. A qualified path avoids Obsidian's
location-dependent resolution when several companies use the same filename.
"""
import re
from collections import defaultdict
from pathlib import Path
from urllib.parse import unquote, urlsplit


def visible_markdown(text):
    """Blank comments and fenced/inline code, retaining source line numbers."""
    def blank(match):
        return '\n' * match.group(0).count('\n')
    text = re.sub(r'<!--.*?-->|%%.*?%%', blank, text, flags=re.S)
    lines = text.splitlines(keepends=True)
    fence = None
    out = []
    for line in lines:
        match = re.match(r'^\s{0,3}(`{3,}|~{3,})', line)
        if fence:
            if match and match[1][0] == fence[0] and len(match[1]) >= len(fence):
                fence = None
            out.append('\n' if line.endswith('\n') else '')
        elif match:
            fence = match[1]
            out.append('\n' if line.endswith('\n') else '')
        else:
            out.append(re.sub(r'(`+)(?!`).*?(?<!`)\1(?!`)', '', line))
    return ''.join(out)


def normalize_heading(value):
    value = re.sub(r'\[([^]]+)\]\([^)]+\)', r'\1', value)
    value = re.sub(r'[*_`=]', '', value).strip()
    return re.sub(r'\s+', ' ', value).casefold()


def inspect_links(root):
    root = Path(root).resolve()
    files = {p.relative_to(root).as_posix(): p for p in root.rglob('*')
             if p.is_file() and not any(part.startswith('.') for part in p.relative_to(root).parts)
             and '__pycache__' not in p.parts}
    notes = {name: p for name, p in files.items() if name.endswith('.md')}
    by_name = defaultdict(list)
    for name in files:
        by_name[Path(name).name].append(name)
        if name.endswith('.md'):
            by_name[Path(name).stem].append(name)
    texts = {name: visible_markdown(p.read_text(encoding='utf-8')) for name, p in notes.items()}
    anchors = {}
    for name, text in texts.items():
        headers = [normalize_heading(m[1].strip().rstrip('#').strip())
                   for m in re.finditer(r'^\s{0,3}#{1,6}\s+(.+)$', text, flags=re.M)]
        blocks = set(re.findall(r'(?:^|\s)\^([A-Za-z0-9-]+)\s*$', text, flags=re.M))
        anchors[name] = (headers, blocks)
    errors = []; edges = {name: set() for name in notes}; link_count = 0; anchor_count = 0
    external_count = 0

    def error(source, line, kind, target):
        errors.append({'file': source, 'line': line, 'kind': kind, 'target': target})

    def resolve(source, line, target, kind='wiki'):
        nonlocal link_count, anchor_count, external_count
        target = target.strip().strip('<>')
        if urlsplit(target).scheme or target.startswith('//'):
            external_count += 1
            return
        link_count += 1
        path, _, fragment = unquote(target).partition('#')
        if not path and not fragment:
            error(source, line, 'empty_target', target); return
        if path:
            if path.startswith(('./', '../')):
                absolute = (root / Path(source).parent / path).resolve()
                if not absolute.is_relative_to(root):
                    error(source, line, 'outside_vault', target); return
                path = absolute.relative_to(root).as_posix()
            path = path.lstrip('/')
            # Root-qualified references have exact, case-sensitive resolution.
            if '/' in path:
                found = [p for p in [path, path + '.md'] if p in files]
            else:
                found = list(dict.fromkeys(by_name.get(path, [])))
            if not found:
                error(source, line, 'missing_target', target); return
            if len(found) > 1:
                error(source, line, 'ambiguous_target', target); return
            destination = found[0]
        else:
            destination = source
        if destination in notes:
            edges[source].add(destination)
        if fragment and destination in notes:
            anchor_count += 1
            headers, blocks = anchors[destination]
            if fragment.startswith('^'):
                if fragment[1:] not in blocks:
                    error(source, line, 'missing_block', target)
            else:
                # Heading text (wikilink) and URL-style slugs (Markdown) both accepted.
                wanted = [normalize_heading(x) for x in fragment.split('#') if x]
                position = 0
                for heading in wanted:
                    choices = headers[position:]
                    matches = [i for i, h in enumerate(choices)
                               if h == heading or (kind == 'markdown' and
                               re.sub(r'[^\w\s-]', '', h).replace(' ', '-') == heading)]
                    if not matches:
                        error(source, line, 'missing_heading', target); break
                    position += matches[0] + 1

    for source, text in texts.items():
        definitions = {}
        for m in re.finditer(r'^\s{0,3}\[([^]\n]+)\]:\s*(<[^>]+>|\S+)', text, flags=re.M):
            definitions[m[1].casefold()] = m[2]
        for lineno, line in enumerate(text.splitlines(), 1):
            for m in re.finditer(r'(?<!\\)!?\[\[([^\n]*?)\]\]', line):
                raw = m[1]
                if line.lstrip().startswith('|') and re.search(r'(?<!\\)\|', raw):
                    error(source, lineno, 'unescaped_table_alias', raw)
                target = raw.replace('\\|', '|').split('|', 1)[0]
                resolve(source, lineno, target)
            # Ignore wikilinks when looking for conventional Markdown references.
            plain = re.sub(r'!?\[\[[^\n]*?\]\]', '', line)
            for m in re.finditer(r'(?<!\\)!?\[([^]\n]*)\]\((<[^>]+>|[^)\n]*)\)', plain):
                target = re.sub(r'\s+["\'][^"\']*["\']\s*$', '', m[2])
                resolve(source, lineno, target, 'markdown')
            if not re.match(r'^\s{0,3}\[[^]]+\]:', plain):
                for m in re.finditer(r'(?<!\\)!?\[([^]\n]+)\]\[([^]\n]*)\]', plain):
                    key = (m[2] or m[1]).casefold()
                    if key in definitions:
                        resolve(source, lineno, definitions[key], 'markdown')
                    else:
                        error(source, lineno, 'missing_reference_definition', key)
    reached = set(); pending = ['HOME.md'] if 'HOME.md' in notes else []
    while pending:
        node = pending.pop()
        if node in reached:
            continue
        reached.add(node); pending.extend(edges[node] - reached)
    incoming = set().union(*edges.values()) if edges else set()
    duplicates = {k: v for k, v in by_name.items()
                  if not k.endswith('.md') and len(v) > 1 and all(n.endswith('.md') for n in v)}
    return {'notes_scanned': len(notes), 'internal_links_checked': link_count,
            'anchors_checked': anchor_count, 'external_links_not_network_checked': external_count,
            'errors': errors, 'duplicate_note_names': duplicates,
            'unreachable_from_home': sorted(set(notes) - reached),
            'orphans': sorted(n for n in notes if not edges[n] and n not in incoming),
            'result': 'passed' if not errors else 'failed',
            'scope': 'Static paths, anchors and graph reachability; not a native Obsidian UI test or semantic fact check.'}
