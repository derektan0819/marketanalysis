"""Conservative SEC Company Facts normalization. Python 3.10+, standard library."""
from datetime import date, datetime, timezone, timedelta
from hashlib import sha256
import json

TAGS = {
    'revenue': ['RevenueFromContractWithCustomerExcludingAssessedTax', 'Revenues', 'SalesRevenueNet'],
    'gross_profit': ['GrossProfit'], 'operating_income': ['OperatingIncomeLoss'],
    'net_income': ['NetIncomeLoss'],
    'operating_cash_flow': ['NetCashProvidedByUsedInOperatingActivities'],
    'capex_cash': ['PaymentsToAcquirePropertyPlantAndEquipment'],
    'cash': ['CashAndCashEquivalentsAtCarryingValue'],
    'inventory': ['InventoryNet'], 'receivables': ['AccountsReceivableNetCurrent'],
    'assets': ['Assets'], 'liabilities': ['Liabilities'], 'equity': ['StockholdersEquity'],
    'diluted_eps': ['EarningsPerShareDiluted'],
    'diluted_shares': ['WeightedAverageNumberOfDilutedSharesOutstanding'],
    'bank_net_interest_income': ['InterestIncomeExpenseNet'],
}
INSTANT = {'cash', 'inventory', 'receivables', 'assets', 'liabilities', 'equity'}
ADDITIVE = {'revenue', 'gross_profit', 'operating_income', 'net_income', 'operating_cash_flow', 'capex_cash', 'bank_net_interest_income'}

def parse_time(value):
    d = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if d.tzinfo is None:
        raise ValueError('Timestamp requires timezone')
    return d.astimezone(timezone.utc)

def digest(value):
    return sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:20]

def accepted_before(row, cutoff, accepted):
    if row.get('accn') in accepted:
        return parse_time(accepted[row['accn']]) <= parse_time(cutoff)
    # A filing date alone has no intraday precision. Exclude the cutoff date.
    return row.get('filed', '9999') < parse_time(cutoff).date().isoformat()

def normalize(facts, company, source_id, cutoff, accepted):
    observations, issues = [], []
    taxonomy = facts.get('facts', {}).get('us-gaap', {})
    for metric, defaults in TAGS.items():
        if company.get('sector') == 'banks' and metric in {'revenue', 'gross_profit', 'operating_income', 'operating_cash_flow', 'capex_cash'}:
            continue
        unit = 'USD/shares' if metric == 'diluted_eps' else 'shares' if metric == 'diluted_shares' else 'USD'
        candidates = []
        for tag in company.get('tag_overrides', {}).get(metric, defaults):
            rows = [x for x in taxonomy.get(tag, {}).get('units', {}).get(unit, [])
                    if x.get('form') in {'10-K', '10-Q', '10-K/A', '10-Q/A'}
                    and x.get('end', '9999') <= parse_time(cutoff).date().isoformat()
                    and accepted_before(x, cutoff, accepted)]
            if rows:
                candidates.append((tag, rows))
        if not candidates:
            issues.append({'metric': metric, 'type': 'not_available', 'scope': 'metric'})
            continue
        # Use the most recently active tag, with configured priority as tie-breaker.
        tag, rows = max(candidates, key=lambda t: max(x['end'] for x in t[1]))
        groups = {}
        for row in rows:
            groups.setdefault((row.get('start'), row['end']), []).append(row)
        selected = {}
        for key, vals in groups.items():
            vals.sort(key=lambda x: (x.get('filed', ''), accepted.get(x.get('accn'), ''), x.get('accn', '')))
            latest = vals[-1]
            same = [x for x in vals if x.get('filed') == latest.get('filed') and x.get('accn') == latest.get('accn')]
            conflict = len({x['val'] for x in same}) > 1
            selected[key] = (latest, conflict)
            if conflict:
                issues.append({'metric': metric, 'period_end': key[1], 'type': 'conflicting_same_filing', 'scope': 'metric'})
            raw = {
                'entity': company['ticker'], 'metric': metric, 'value': latest['val'], 'unit': unit,
                'period_start': key[0], 'period_end': key[1], 'basis': 'US-GAAP',
                'tag': tag, 'source_id': source_id, 'source_location': f"facts.us-gaap.{tag}.units.{unit}",
                'reported_definition': taxonomy[tag].get('description'),
                'accession': latest.get('accn'), 'filed': latest.get('filed'),
                'published_at': accepted.get(latest.get('accn')), 'publication_precision': 'timestamp' if latest.get('accn') in accepted else 'date_only',
                'series_basis': 'latest_available_as_of_cutoff_not_historical_vintage',
                'data_type': 'reported_actual', 'status': 'needs_review' if conflict else 'source_recorded',
                'formula': None, 'input_observation_ids': [],
                'source_url': f"https://www.sec.gov/Archives/edgar/data/{int(company['cik'])}/{latest.get('accn', '').replace('-', '')}/{latest.get('accn', '')}-index.html",
            }
            if metric in INSTANT:
                raw['period_type'] = 'instant'
            elif key[0]:
                days = (date.fromisoformat(key[1]) - date.fromisoformat(key[0])).days + 1
                raw['period_type'] = 'quarter' if 70 <= days <= 110 else 'annual' if 330 <= days <= 385 else 'ytd'
            else:
                continue
            raw['observation_id'] = 'OBS-' + digest(raw)
            observations.append(raw)
        # Derive standalone quarters only from additive duration metrics. Never subtract EPS/shares.
        if metric not in ADDITIVE:
            continue
        raw_obs = [o for o in observations if o['metric'] == metric and o['data_type'] == 'reported_actual']
        direct_ends = {o['period_end'] for o in raw_obs if o['period_type'] == 'quarter'}
        for current in raw_obs:
            if current['period_type'] not in {'ytd', 'annual'} or current['period_end'] in direct_ends or current['status'] == 'needs_review':
                continue
            prior = [o for o in raw_obs if o['period_start'] == current['period_start']
                     and 70 <= (date.fromisoformat(current['period_end']) - date.fromisoformat(o['period_end'])).days <= 110
                     and o['status'] != 'needs_review']
            if not prior:
                continue
            previous = max(prior, key=lambda o: o['period_end'])
            result = dict(current)
            result.update(value=current['value']-previous['value'], period_type='quarter', data_type='calculation',
                period_start=(date.fromisoformat(previous['period_end'])+timedelta(days=1)).isoformat(),
                formula='current_ytd - previous_ytd',
                input_observation_ids=[current['observation_id'], previous['observation_id']],
                status='calculation_checked' if current['accession'] == previous['accession'] else 'needs_review',
                notes='Cross-filing YTD subtraction requires restatement/basis reconciliation.' if current['accession'] != previous['accession'] else 'Same-filing cumulative subtraction.')
            result['observation_id'] = 'OBS-' + digest(result)
            observations.append(result)
    # Derived metrics must use matching quarter start/end and non-conflicting inputs.
    defs = [('gross_margin_pct','gross_profit','revenue'), ('operating_margin_pct','operating_income','revenue'),
            ('fcf_cash','operating_cash_flow','capex_cash')]
    for metric, a, b in defs:
        for first in list(observations):
            if first['metric'] != a or first['period_type'] != 'quarter': continue
            other = next((o for o in observations if o['metric'] == b and o['period_type'] == 'quarter'
                          and (o['period_start'],o['period_end']) == (first['period_start'],first['period_end'])), None)
            if not other: continue
            if metric == 'fcf_cash':
                if other['value'] < 0: continue
                value, formula, unit = first['value']-other['value'], 'operating_cash_flow - capex_cash', 'USD'
            else:
                if other['value'] <= 0: continue
                value, formula, unit = first['value']/other['value']*100, f'{a} / revenue * 100', '%'
            item = dict(first)
            item.update(metric=metric, value=value, unit=unit, data_type='calculation', formula=formula,
                        input_observation_ids=[first['observation_id'],other['observation_id']],
                        status='needs_review' if any(o['status']=='needs_review' for o in [first,other]) else 'calculation_checked',
                        notes=('Cash outflow definition follows '+other.get('tag','')+'; inspect reported_definition. Noncash leases/acquisitions excluded. Not a GAAP measure.') if metric=='fcf_cash' else '')
            item['observation_id'] = 'OBS-' + digest(item)
            observations.append(item)
    return observations, issues

def recent_quarters(observations, count=8):
    preferred = [o['period_end'] for o in observations if o['period_type']=='quarter' and o['metric'] in {'revenue','net_income','bank_net_interest_income'}]
    return sorted(set(preferred))[-count:]

def number(value, unit):
    if unit == 'USD': return f'{value/1e9:,.3f} B USD'
    if unit == '%': return f'{value:,.2f}%'
    if unit == 'shares': return f'{value/1e6:,.2f} M shares'
    return f'{value:,.3f} {unit}'

def history_markdown(snapshot):
    from links import wiki, observation_link, evidence_path, company_navigation
    obs = snapshot['observations']; ends = recent_quarters(obs)
    metrics = ['bank_net_interest_income','net_income','diluted_eps','assets','liabilities','equity'] if snapshot['company']['sector']=='banks' else ['revenue','gross_margin_pct','operating_margin_pct','net_income','operating_cash_flow','capex_cash','fcf_cash','inventory','receivables','diluted_shares']
    out = ['---','tags: [company, history, generated]','status: data_only',f"as_of: \"{snapshot['cutoff']}\"",'---',f"# {snapshot['company']['ticker']} — 最近八个季度",'',
           '只展示已取得的季度；缺失值不是零。历史值为本次截止时已知版本，不能直接用于无前视偏差回测。',
           '`†` 表示需要核对（例如跨申报文件推导现金流）；其他数字也仅通过结构与计算检查，不等于完整财报阅读。','',
           '| 季度结束 | ' + ' | '.join(metrics) + ' |','|---|'+'---|'*len(metrics)]
    for end in ends:
        row=[]
        for metric in metrics:
            item=next((o for o in obs if o['metric']==metric and o['period_end']==end and o['period_type'] in {'quarter','instant'}),None)
            row.append(observation_link(snapshot,item['observation_id'],number(item['value'],item['unit'])+(' †' if item['status']=='needs_review' else ''),table=True) if item else '缺失')
        out.append('| '+end+' | '+' | '.join(row)+' |')
    out += ['', '## 可追溯记录', '点击表格中的数字即可定位到 '+wiki(evidence_path(snapshot),'本次证据页')+' 的对应记录。',
            '原始快照：'+wiki(snapshot['snapshot_relative_path'],'JSON 文件（外部编辑器）')+'。',
            '每条 observation 包含 source_id、tag、期间、单位、申报 accession 和计算输入 ID。','', company_navigation(snapshot['company']['ticker']), '', '## 限制',
            'EPS／加权股数不使用全年减前三季推导。分部、公司自定义标签、管理层指引、共识、估值及脚注尚需独立获取。银行不套用工业公司的 FCF。']
    return '\n'.join(out)+'\n'
