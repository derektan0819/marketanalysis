"""Versioned research contract, evidence identity, consistency checks and cache keys.

Checks enforce structure/provenance. They cannot certify natural-language causality.
"""
import hashlib
import json
import re
from pathlib import Path
from network import write_json
from data import parse_time

PROTOCOL = 'MV-11.3'
BUSINESS = {'improving', 'deteriorating', 'stable', 'mixed', 'unknown'}
PRICE = {'up', 'down', 'range', 'unknown'}
CONFIDENCE = {'low', 'medium', 'high'}
RELATIONS = {'observed_sequence', 'supported_inference', 'hypothesis', 'unknown'}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(',', ':')).encode()).hexdigest()


def stable_content(value):
    """Do not mistake a new fetch timestamp or run folder for new economic evidence."""
    omitted = {'created_at', 'retrieved_at', 'snapshot_relative_path', 'processed_at'}
    if isinstance(value, dict):
        return {k: stable_content(v) for k, v in value.items() if k not in omitted}
    if isinstance(value, list):
        return [stable_content(v) for v in value]
    return value


def evidence_hash(snapshot):
    # Cutoff matters for the decision request, but does not itself create new evidence.
    content = {k: snapshot.get(k) for k in ['company', 'observations', 'sources', 'documents', 'document_errors', 'issues']}
    return digest(stable_content(content))


def brief_schema():
    refs = {'observation_ids': [], 'source_ids': []}
    return {
        'headline': '一句话结论，缺少依据时说明不能判断',
        'valid_until': None,
        'facts': [dict(text='最多三项已发生变化或明确未知', type='FACT|CALC|UNKNOWN', **refs)],
        'market_move': dict(status='observed|unavailable', text='标的、交易时段、涨跌，或未取得行情', **refs),
        'transmission': [dict(stage=stage, cause='原因或事件', effect='影响', mechanism='用人话概括本条路径',
                              affected_party='谁先受影响，具体到角色或对象',
                              mechanism_steps=['第一步：具体行为如何改变业务或财务变量', '第二步：为什么继续影响下一环节；未知关系可用空数组'],
                              illustration={'kind':'none', 'text':''},
                              timing='何时可能体现及依据，未知则说明缺什么',
                              break_condition='什么条件会阻断或抵消这条路径',
                              verification='具体看什么指标或披露确认／推翻',
                              evidence_scope='证据直接支持哪一步，哪一步仍是推断或未知',
                              relation='observed_sequence|supported_inference|hypothesis|unknown',
                              alternative='至少一个替代解释或缺口', confidence='low|medium|high', **refs) for stage in ['primary','secondary']],
        'outlook': {
            'business': dict(direction='improving|deteriorating|stable|mixed|unknown', horizon='明确期限', reasoning='依据', confidence='low|medium|high', **refs),
            'price': dict(direction='up|down|range|unknown', horizon='明确期限', reasoning='依据或缺失资料', confidence='low|medium|high', **refs)},
        'scenarios': [dict(name=name, conditions='可观察条件', path='有条件的发展路径', horizon='明确期限',
                           invalidation='什么会推翻本情景', ranking='preferred|alternative|unranked',
                           confidence='low|medium|high', probability=None, **refs) for name in ['base', 'stronger', 'weaker']],
        'watchpoints': [{'signal': '最多三个可观察指标', 'meaning': '何种变化支持或推翻判断', 'next_check': '事件或已核实日期，未知则说明'}],
        'change': dict(status='INITIAL|MAINTAIN|REVISE|WITHDRAW',
                       reason_code='INITIAL|NO_NEW_EVIDENCE|NEW_EVIDENCE|CORRECTION|HORIZON_CHANGE|METHOD_CHANGE|EXPIRED',
                       previous_conclusion='先前观点或尚无记录', reason='为何维持或改变', correction_detail='纠错时写旧错误和修正依据，其余空字符串', **refs),
        'data_gaps': ['资料缺失与对结论的具体影响']}


def attach_context(root, packet):
    ticker = packet['snapshot']['company']['ticker']
    state = Path(root)/'04_Companies'/ticker/'Current Research State.json'
    previous = json.loads(state.read_text(encoding='utf-8')) if state.exists() else None
    packet.update(protocol_version=PROTOCOL, previous_research=previous,
                  evidence_fingerprint=evidence_hash(packet['snapshot']),
                  data_availability={'market_prices': False, 'pre_release_consensus': False, 'macro_observations': False},
                  analysis_policy={'language': 'zh-CN', 'business_horizon': '未来1–4季度',
                                   'price_horizon': '未来1–4周', 'numeric_probabilities': False,
                                   'paid_services': 'not_authorized', 'max_front_facts': 3,
                                   'explanation_depth':'step_by_step_plain_language',
                                   'front_length_target':'1000–1600 Chinese characters; clarity first',
                                   'illustrations':'hypothetical_and_clearly_labeled_only'})
    packet['response_format']['protocol_version'] = PROTOCOL
    packet['response_format']['brief'] = brief_schema()
    packet['protocol_fingerprint'] = digest(packet['knowledge_notes'])
    return packet


def validate_research(output, packet):
    errors = []
    if output.get('protocol_version') != PROTOCOL:
        errors.append('research: wrong or missing protocol_version')
    brief = output.get('brief')
    if not isinstance(brief, dict):
        return errors + ['research: missing structured brief']
    observations = {o['observation_id']: o for o in packet['snapshot'].get('observations', [])}
    sources = {s['source_id'] for s in packet['snapshot'].get('sources', []) + packet['snapshot'].get('documents', [])}

    def text(obj, field, label, maximum=600):
        value = obj.get(field)
        if not isinstance(value, str) or not value.strip() or len(value) > maximum:
            errors.append(label + ': missing/oversized ' + field)
        return value if isinstance(value, str) else ''

    def refs(obj, label, required=False, allow_unresolved=False):
        ids = obj.get('observation_ids', []); src = obj.get('source_ids', [])
        if not isinstance(ids, list) or not isinstance(src, list) or not all(isinstance(x,str) for x in ids + src):
            errors.append(label + ': invalid evidence list'); return
        if required and not ids and not src:
            errors.append(label + ': evidence required')
        if not set(ids) <= set(observations) or not set(src) <= sources:
            errors.append(label + ': unknown evidence ID')
        if not allow_unresolved and any(observations[x]['status']=='needs_review' for x in ids if x in observations):
            errors.append(label + ': unresolved evidence')

    def items(field, minimum, maximum):
        rows = brief.get(field)
        if not isinstance(rows, list) or not minimum <= len(rows) <= maximum or not all(isinstance(r,dict) for r in rows):
            errors.append('research: invalid ' + field); return []
        return rows

    text(brief, 'headline', 'brief', 180)
    if output.get('summary') != brief.get('headline'):
        errors.append('summary: must exactly repeat brief.headline')
    if brief.get('valid_until') is not None:
        try:
            if parse_time(brief['valid_until']) <= parse_time(packet['snapshot']['cutoff']):
                errors.append('brief: valid_until must follow report cutoff')
        except (ValueError, TypeError, AttributeError):
            errors.append('brief: invalid valid_until')
    for i, fact in enumerate(items('facts', 1, 3)):
        label=f'fact {i}'; text(fact,'text',label,350)
        if fact.get('type') not in {'FACT','CALC','UNKNOWN'}: errors.append(label+': invalid type')
        refs(fact,label,required=fact.get('type')!='UNKNOWN',allow_unresolved=fact.get('type')=='UNKNOWN')
    market=brief.get('market_move', {})
    if not isinstance(market,dict): market={};errors.append('market_move: invalid object')
    text(market,'text','market_move',300)
    if market.get('status') not in {'observed','unavailable'}: errors.append('market_move: invalid status')
    if market.get('status')=='observed' and not packet.get('data_availability',{}).get('market_prices'):
        errors.append('market_move: prices unavailable')
    refs(market,'market_move',required=market.get('status')=='observed')
    transmission=items('transmission',2,4)
    for stage in ['primary','secondary']:
        if not 1 <= sum(s.get('stage')==stage for s in transmission) <= 2:
            errors.append('transmission: require 1–2 paths in each stage')
    for i, step in enumerate(transmission):
        label=f'transmission {i}'
        for field in ['cause','effect','mechanism','alternative']: text(step,field,label,350)
        for field in ['affected_party','timing','break_condition','verification','evidence_scope']:
            text(step,field,label,400)
        sequence=step.get('mechanism_steps')
        unknown=step.get('relation')=='unknown'
        if not isinstance(sequence,list) or not (2<=len(sequence)<=4 or (unknown and len(sequence)==0)):
            errors.append(label+': require 2–4 explanatory steps, or no steps when unknown')
        else:
            for explanation in sequence:
                text({'step':explanation},'step',label,350)
            if all(isinstance(x,str) for x in sequence) and len({x.strip() for x in sequence})!=len(sequence):
                errors.append(label+': duplicated explanatory steps')
        illustration=step.get('illustration')
        if not isinstance(illustration,dict):
            errors.append(label+': illustration must state hypothetical or none')
        elif illustration.get('kind')=='hypothetical':
            text(illustration,'text',label+' illustration',500)
        elif illustration.get('kind')!='none' or illustration.get('text')!='':
            errors.append(label+': invalid illustration kind or unexpected example text')
        if step.get('stage') not in {'primary','secondary'}: errors.append(label+': invalid stage')
        if step.get('relation') not in RELATIONS: errors.append(label+': invalid causal classification')
        if step.get('confidence') not in CONFIDENCE: errors.append(label+': invalid confidence')
        refs(step,label,required=step.get('relation') in {'observed_sequence','supported_inference'},
             allow_unresolved=step.get('relation') in {'unknown','hypothesis'})
        if step.get('relation') in {'unknown','hypothesis'} and step.get('confidence')!='low':
            errors.append(label+': unverified mechanism must have low confidence')
    outlook=brief.get('outlook',{})
    if not isinstance(outlook,dict): outlook={};errors.append('outlook: invalid object')
    for scope, choices in [('business',BUSINESS),('price',PRICE)]:
        row=outlook.get(scope,{})
        if not isinstance(row,dict): row={};errors.append(scope+': invalid outlook')
        if row.get('direction') not in choices: errors.append(scope+': invalid direction')
        for field in ['horizon','reasoning']: text(row,field,scope,400)
        if row.get('confidence') not in CONFIDENCE: errors.append(scope+': invalid confidence')
        refs(row,scope,required=row.get('direction') not in {None,'unknown'})
        if row.get('direction')=='unknown' and row.get('confidence')!='low': errors.append(scope+': unknown requires low confidence')
        if scope=='price' and not packet.get('data_availability',{}).get('market_prices') and row.get('direction')!='unknown':
            errors.append('price: no direction allowed without market data')
    scenarios=items('scenarios',3,3)
    if {s.get('name') for s in scenarios}!={'base','stronger','weaker'}: errors.append('scenarios: require base/stronger/weaker')
    preferred=0
    for row in scenarios:
        label='scenario '+str(row.get('name'))
        for field in ['conditions','path','horizon','invalidation']: text(row,field,label,350)
        if row.get('ranking') not in {'preferred','alternative','unranked'}: errors.append(label+': invalid ranking')
        if row.get('confidence') not in CONFIDENCE: errors.append(label+': invalid confidence')
        if row.get('probability') is not None: errors.append(label+': numeric probabilities disabled')
        refs(row,label,required=row.get('ranking')=='preferred')
        if row.get('ranking')=='preferred':
            preferred+=1
            if row.get('name')!='base' or row.get('confidence') not in {'medium','high'}:
                errors.append(label+': preferred path requires base scenario and support')
    if preferred>1: errors.append('scenarios: only one preferred path allowed')
    for row in items('watchpoints',1,3):
        for field in ['signal','meaning','next_check']: text(row,field,'watchpoint',350)
    gaps=brief.get('data_gaps')
    if not isinstance(gaps,list) or not gaps or not all(isinstance(x,str) for x in gaps): errors.append('brief: explicit data_gaps required')
    change=brief.get('change',{})
    if not isinstance(change,dict): change={};errors.append('change: invalid object')
    for field in ['previous_conclusion','reason']: text(change,field,'change',600)
    if change.get('status') not in {'INITIAL','MAINTAIN','REVISE','WITHDRAW'}: errors.append('change: invalid status')
    codes={'INITIAL','NO_NEW_EVIDENCE','NEW_EVIDENCE','CORRECTION','HORIZON_CHANGE','METHOD_CHANGE','EXPIRED'}
    if change.get('reason_code') not in codes: errors.append('change: invalid reason_code')
    refs(change,'change',required=change.get('reason_code') in {'NEW_EVIDENCE','CORRECTION'})
    previous=packet.get('previous_research')
    if previous:
        same=previous.get('evidence_fingerprint')==packet.get('evidence_fingerprint')
        prior=previous.get('brief',{}).get('outlook',{})
        def field(rows, scope, key):
            row=rows.get(scope,{})
            return row.get(key) if isinstance(row,dict) else None
        changed=any(field(prior,k,'direction')!=field(outlook,k,'direction') for k in ['business','price'])
        if change.get('status')=='INITIAL': errors.append('change: previous research exists')
        if change.get('status')=='MAINTAIN' and changed: errors.append('change: MAINTAIN contradicts changed direction')
        if change.get('reason_code')=='NEW_EVIDENCE' and same: errors.append('change: claimed new evidence but fingerprint unchanged')
        if changed and same and change.get('reason_code') not in {'CORRECTION','HORIZON_CHANGE','METHOD_CHANGE','EXPIRED'}:
            errors.append('change: unsupported reversal on identical evidence')
        if change.get('reason_code')=='HORIZON_CHANGE' and all(field(prior,k,'horizon')==field(outlook,k,'horizon') for k in ['business','price']):
            errors.append('change: horizon did not change')
        if change.get('reason_code')=='METHOD_CHANGE' and previous.get('protocol_fingerprint')==packet.get('protocol_fingerprint'):
            errors.append('change: protocol did not change')
        if change.get('reason_code')=='EXPIRED':
            expiry=previous.get('brief',{}).get('valid_until')
            try:
                if not expiry or not parse_time(previous['cutoff']) < parse_time(expiry) <= parse_time(packet['snapshot']['cutoff']):
                    errors.append('change: no previously recorded deadline has expired')
            except (KeyError, ValueError, TypeError, AttributeError):
                errors.append('change: invalid previously recorded deadline')
    elif change.get('status')!='INITIAL' or change.get('reason_code')!='INITIAL':
        errors.append('change: no prior structured research; use INITIAL')
    if change.get('reason_code')=='CORRECTION': text(change,'correction_detail','change',800)
    # Mechanical coverage must cover every supplied document; self-report is still not semantic certification.
    covered={r.get('source_id') for r in output.get('coverage',[]) if isinstance(r,dict) and r.get('reviewed') is True and r.get('location')}
    required={d['source_id'] for d in packet['snapshot'].get('documents',[])}
    if not required or not required<=covered: errors.append('coverage: required document reading not recorded')
    serialized=json.dumps(brief,ensure_ascii=False)
    if re.search(r'(?:保证|必定|一定会)(?:上涨|下跌|盈利|赚钱)',serialized): errors.append('brief: guaranteed market outcome language')
    return errors


def thesis_from_brief(output):
    """Use a single canonical conclusion instead of accepting a contradictory second proposal."""
    brief=output['brief']
    base=next(s for s in brief['scenarios'] if s['name']=='base')
    return {'previous':brief['change']['previous_conclusion'], 'proposed':brief['headline'],
            'reason':brief['change']['reason'], 'invalidation':base['invalidation']}


def decision_cache_key(packet, command, model_identity):
    return digest({'protocol': PROTOCOL, 'packet': stable_content(packet), 'command': command, 'model': model_identity})


def remember_research(root, packet, output, report_relative):
    if output.get('machine_reference_check',{}).get('failures'):
        return
    ticker=packet['snapshot']['company']['ticker']
    state={'protocol_version':PROTOCOL, 'evidence_fingerprint':packet['evidence_fingerprint'],
           'protocol_fingerprint':packet['protocol_fingerprint'], 'cutoff':packet['snapshot']['cutoff'],
           'source_report':report_relative, 'brief':output['brief'],
           'semantic_support_verified':False}
    write_json(Path(root)/'04_Companies'/ticker/'Current Research State.json',state)
