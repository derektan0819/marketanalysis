"""A fixed readable report; unvalidated model prose never becomes the lead conclusion."""
from pathlib import Path
from data import recent_quarters, number
from links import wiki, observation_link, source_link, evidence_path, company_navigation

HEADINGS = ['1. 发生了什么', '2. 为什么会这样', '3. 还可能影响哪里',
            '4. 接下来更可能怎样走', '5. 接下来盯什么', '6. 和上次相比', '7. 资料缺口与证据']
DIRECTIONS = {'improving':'改善','deteriorating':'转弱','stable':'大致稳定','mixed':'好坏参半',
              'unknown':'尚不能判断','up':'偏向上涨','down':'偏向下跌','range':'偏向区间波动'}
CONFIDENCE = {'low':'低','medium':'中','high':'高'}
RELATIONS = {'observed_sequence':'已观察到先后变化，因果未证实','supported_inference':'有证据支持的解释，仍可被推翻',
             'hypothesis':'待验证假设','unknown':'尚不能归因'}
CHANGES = {'INITIAL':'首次记录','MAINTAIN':'维持','REVISE':'修正','WITHDRAW':'撤回'}
METRIC_LABELS = {'revenue':'营收','net_income':'净利润','gross_margin_pct':'毛利率',
                 'bank_net_interest_income':'净利息收入','diluted_eps':'稀释每股盈利',
                 'operating_cash_flow':'经营现金流','capex_cash':'资本支出','fcf_cash':'自由现金流',
                 'gross_profit':'毛利','operating_income':'营业利润'}


def front_number(value, unit):
    if unit=='USD':
        if abs(value)>=1e8: return f'{value/1e8:,.2f} 亿美元'
        if abs(value)>=1e4: return f'{value/1e4:,.2f} 万美元'
        return f'{value:,.2f} 美元'
    if unit=='USD/shares': return f'{value:,.2f} 美元／股'
    return number(value,unit)


def clean(value, table=False):
    text=str(value or '').replace('\r',' ').replace('\n',' ').replace('[','\\[').replace(']','\\]')
    return text.replace('|','／') if table else text


def readable_memo(root, snapshot, ai, ai_status):
    ticker=snapshot['company']['ticker'];ends=recent_quarters(snapshot['observations'])
    failures=ai.get('machine_reference_check',{}).get('failures',[]) if ai else []
    accepted=bool(ai and not failures and isinstance(ai.get('brief'),dict))
    brief=ai['brief'] if accepted else None
    observations={o['observation_id']:o for o in snapshot['observations']}
    source_ids={s['source_id'] for s in snapshot['sources']+snapshot.get('documents',[])}

    def evidence(row):
        links=[]
        for oid in row.get('observation_ids',[]):
            if oid in observations:
                o=observations[oid]
                links.append(observation_link(snapshot,oid,METRIC_LABELS.get(o['metric'],o['metric'])+' · '+o['period_end']))
        for sid in row.get('source_ids',[]):
            if sid in source_ids: links.append(source_link(sid,'原文'))
        return ('（'+ '、'.join(links)+'）') if links else ''

    status='Draft' if accepted else 'Needs Review' if ai or ai_status.startswith('adapter_failed') else 'Awaiting Analysis'
    headline=brief['headline'] if brief else ('这次 AI 输出未通过检查，暂不采用其结论。' if ai else '已备好财报资料，尚未完成 AI 阅读；变动原因与未来方向暂不能判断。')
    reading_status='未连接 AI 分析' if ai_status=='not_configured' else 'AI 调用失败' if ai_status.startswith('adapter_failed') else 'AI 输出待检查'
    out=['---',f'company: {ticker}',f'format_version: "11.3"',f'data_cutoff: "{snapshot["cutoff"]}"',f'status: {status}','---',
         f'# {ticker} — 发生了什么，接下来怎么看','', '**一句话：** '+clean(headline),'',
         f'资料截止：{snapshot["cutoff"]}。最新结构化季度：{ends[-1] if ends else "未取得"}。',
         '阅读状态：'+('AI 已提交覆盖记录，引用／格式检查通过，语义未独立核验。' if accepted else reading_status+'；数据保存成功不代表已读完原文。'),'',
         '## '+HEADINGS[0],'']
    if brief:
        for fact in brief['facts']: out.append('- '+('待核实：' if fact['type']=='UNKNOWN' else '')+clean(fact['text'])+evidence(fact))
        out+=['','**市场表现：** '+clean(brief['market_move']['text'])+evidence(brief['market_move'])]
    else:
        preferred=['bank_net_interest_income','net_income','diluted_eps'] if snapshot['company']['sector']=='banks' else ['revenue','net_income','gross_margin_pct']
        for metric in preferred:
            item=next((o for o in snapshot['observations'] if ends and o['period_end']==ends[-1] and o['period_type']=='quarter' and o['metric']==metric),None)
            if item:
                out.append('- '+METRIC_LABELS[metric]+'：'+front_number(item['value'],item['unit'])+('（需核对）' if item['status']=='needs_review' else '（结构化数据）')+'。'+evidence({'observation_ids':[item['observation_id']]}))
        out+=['','市场行情未取得，不能确认今天上涨／下跌多少，也不能解释尚未核实的跌幅。']
    for stage, heading in [('primary',HEADINGS[1]),('secondary',HEADINGS[2])]:
        out+=['','## '+heading,'']
        steps=[s for s in brief['transmission'] if s['stage']==stage] if brief else []
        if not steps:
            if stage=='primary':
                out += ['尚未完成可采用的 AI 阅读，暂时不能确定这次变化由什么造成。需要先核对具体事件、发生时间和原文，确认公司自己怎样解释。',
                        '阅读后会说明：谁做了什么，如何一步步影响收入、成本或投资者预期；每一步证据支持到哪里，以及哪些条件下解释不成立。仅有财务数字还不足以补上这段原因。']
            else:
                out += ['目前还不能把影响延伸到供应商、客户或其他资产，因为前一段机制尚未确认。',
                        '阅读后会沿最重要的 1–2 条路径，说明先影响谁、为什么继续传导、何时可能体现、什么会抵消，以及需要什么数据验证。此处不把一般经济逻辑当成本公司的已发生事实。']
        for s in steps:
            out += ['**'+clean(s['cause'])+' → '+clean(s['effect'])+'**','',
                    clean(s['mechanism']), '', '先影响谁：'+clean(s['affected_party'])]
            sequence=s['mechanism_steps']
            if sequence:
                out+=['','中间过程：','']
                out += [f'{i}. '+clean(value) for i,value in enumerate(sequence,1)]
            else: out+=['','中间关系尚未确认，不补写未经验证的过程。']
            if s['illustration']['kind']=='hypothetical':
                out+=['','**假设示例（非公司实际数据）：** '+clean(s['illustration']['text'])]
            out += ['', '**何时体现：** '+clean(s['timing']),
                    '**什么会阻断／抵消：** '+clean(s['break_condition']),
                    '**另一种解释：** '+clean(s['alternative']),
                    '**看什么验证：** '+clean(s['verification']),
                    '', '**证据支持到哪里：** '+clean(s['evidence_scope'])+evidence(s),
                    '性质：'+RELATIONS[s['relation']]+'；证据把握：'+CONFIDENCE[s['confidence']]+'。','']
    out+=['','## '+HEADINGS[3],'']
    if brief:
        for key,label in [('business','公司经营'),('price','股价')]:
            row=brief['outlook'][key]
            out.append('**'+label+'（'+clean(row['horizon'])+'）：'+DIRECTIONS[row['direction']]+'。** '+clean(row['reasoning'])+
                       ' 证据把握：'+CONFIDENCE[row['confidence']]+'。'+evidence(row))
        ranked=any(s['ranking']=='preferred' for s in brief['scenarios'])
        out+=['','基准情景是当前较有支持的工作判断，不是统计胜率或保证。' if ranked else '现有证据不足以选出更可能的路径，以下情景暂不排序。','',
              '| 情景 | 什么条件成立 | 可能怎样走 | 什么会推翻 |','|---|---|---|---|']
        names={'base':'基准','stronger':'较强','weaker':'较弱'}
        for s in sorted(brief['scenarios'],key=lambda s:['base','stronger','weaker'].index(s['name'])):
            label=names[s['name']]+('（较有支持）' if s['ranking']=='preferred' else '')
            out.append('| '+' | '.join(clean(x,table=True) for x in [label,s['conditions'],s['path']+'；'+s['horizon'],s['invalidation']])+' |')
        for s in brief['scenarios']:
            if evidence(s): out.append('\n'+names[s['name']]+'情景依据：'+evidence(s))
        if brief.get('valid_until'): out.append('\n本次判断最晚复核时间：'+clean(brief['valid_until'])+'。')
    else:
        out+=['- **公司经营：** 待完整阅读后判断，默认看未来 1–4 季度。',
              '- **股价：** 尚不能判断。缺少行情、市场预期和估值背景。',
              '- **基准／较强／较弱情景：** 暂不排序；不能为了填满模板编造“大概率”。']
    out+=['','## '+HEADINGS[4],'']
    if brief:
        for w in brief['watchpoints']:
            out.append('- **'+clean(w['signal'])+'：** '+clean(w['meaning'])+'；检查点：'+clean(w['next_check'])+'。')
    else:
        out+=['- 阅读最新财报原文与管理层指引，核对是否出现新的经营变化。',
              '- 处理会影响核心判断的数据口径冲突，具体见 [[Review Queue]]。',
              '- 下一次正式披露时再检查；未核实的发布日期不编造。']
    out+=['','## '+HEADINGS[5],'']
    if brief:
        c=brief['change'];out+=['**'+CHANGES[c['status']]+'。** '+clean(c['reason'])+evidence(c),
                              '先前观点：'+clean(c['previous_conclusion'])]
        if c.get('correction_detail'):out.append('纠错记录：'+clean(c['correction_detail']))
    else:out+=['本次只更新展示格式／资料状态，不形成新的研究判断。上一版观点保留在 '+wiki(f'04_Companies/{ticker}/Current Thesis.md','当前判断')+'。']
    out+=['','## '+HEADINGS[6],'']
    if brief:out+=['- '+clean(g) for g in brief['data_gaps']]
    else:out+=['- AI 尚未完成可采用的分析；电话会 Q&A、分部和脚注覆盖仍需核对。',
               '- 当前引擎未接行情、共识和宏观接口；不把缺失信息解释成“没有变化”。']
    if failures:out+=['- 本次输出检查未通过：'+clean('；'.join(failures[:4]))+'。原始回答保留供检查，不作为正式结论。']
    out+=['',wiki(evidence_path(snapshot),'数字、计算与财报原文')+' · '+wiki(f'04_Companies/{ticker}/{ticker} - Data History.md','八季数据'),
          company_navigation(ticker)]
    ai_path=str(Path(evidence_path(snapshot)).with_name('ai-output.json'))
    if ai and (Path(root)/ai_path).is_file():out.append(wiki(ai_path,'本次 AI 原始记录（JSON）'))
    return '\n'.join(out).rstrip()+'\n'
