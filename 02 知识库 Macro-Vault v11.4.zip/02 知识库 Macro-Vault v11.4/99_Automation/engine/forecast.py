"""Append-only forecast registry; conditional outcomes and provenance remain explicit."""
from pathlib import Path
from datetime import date
import json, operator, uuid
from data import parse_time
from network import now, write_json

OPS={'>':operator.gt,'>=':operator.ge,'<':operator.lt,'<=':operator.le,'==':operator.eq}

def predicate_check(p):
    for k in ['entity','metric','period_end','unit','basis','operator','threshold']:
        if k not in p: raise ValueError('Missing predicate field: '+k)
    if p['operator'] not in OPS or isinstance(p['threshold'],bool) or not isinstance(p['threshold'],(int,float)):
        raise ValueError('Invalid numeric predicate')
    date.fromisoformat(p['period_end'])

def log_forecast(root,claim):
    required=['claim','horizon','check_at','target','source_report','reason','evidence_observation_ids','evidence_source_ids','confidence']
    if any(k not in claim for k in required): raise ValueError('Forecast missing required fields')
    predicate_check(claim['target'])
    if claim.get('condition'): predicate_check(claim['condition'])
    created=now()
    if parse_time(claim['check_at'])<=parse_time(created): raise ValueError('Future check_at required; retrospective examples belong in archive')
    if claim['target']['period_end'] <= parse_time(created).date().isoformat(): raise ValueError('Target period must be future; use archive for retrospective examples')
    report=(Path(root)/claim['source_report']).resolve()
    if not report.is_relative_to(Path(root).resolve()) or not report.is_file(): raise ValueError('Source report must exist inside Vault')
    known_obs=set(); known_src=set(); unresolved=set()
    for p in (Path(root)/'12_Data/Companies').glob('*/*.json'):
        data=json.loads(p.read_text()); known_obs.update(x['observation_id'] for x in data.get('observations',[]))
        unresolved.update(x['observation_id'] for x in data.get('observations',[]) if x['status']=='needs_review')
    for p in (Path(root)/'13_Sources/Raw').glob('*.meta.json'): known_src.add(json.loads(p.read_text())['source_id'])
    if not claim['evidence_observation_ids'] and not claim['evidence_source_ids']: raise ValueError('At least one evidence ID required')
    if not set(claim['evidence_observation_ids'])<=known_obs or not set(claim['evidence_source_ids'])<=known_src: raise ValueError('Unknown evidence ID')
    if set(claim['evidence_observation_ids']) & unresolved: raise ValueError('Forecast depends on unresolved data; keep as candidate')
    if claim.get('probability') is not None:
        if isinstance(claim['probability'],bool) or not 0<=claim['probability']<=1 or not claim.get('probability_basis'): raise ValueError('Probability requires [0,1] and stated basis; do not invent calibration')
    for existing in (Path(root)/'12_Data/Predictions').glob('P-*.json'):
        prior=json.loads(existing.read_text())
        if not claim.get('supersedes') and prior['target']==claim['target'] and prior.get('condition')==claim.get('condition'):
            return dict(prior,registration_note='Existing predicate retained; use supersedes for an intentional new forecast version')
    # Caller cannot set creation time, outcome, or historical eligibility.
    item={k:claim[k] for k in required}
    item.update({k:claim.get(k) for k in ['condition','probability','probability_basis','baseline_probability','baseline_source','event_cluster','supersedes']})
    item.update(prediction_id='P-'+uuid.uuid4().hex[:16],created_at=created,record_type='prospective',status='pending')
    path=Path(root)/'12_Data/Predictions'/f"{item['prediction_id']}.json"
    write_json(path,item)
    return item

def evaluate(predicate, observations, cutoff):
    matches=[x for x in observations if all(x.get(k)==predicate[k] for k in ['entity','metric','period_end','unit','basis'])
             and x.get('period_type')=='quarter' and x.get('status')!='needs_review'
             and x.get('_snapshot_cutoff') and parse_time(x['_snapshot_cutoff'])<=parse_time(cutoff)]
    if not matches: return None,None
    newest=max(parse_time(x['_snapshot_cutoff']) for x in matches)
    matches=[x for x in matches if parse_time(x['_snapshot_cutoff'])==newest]
    if len({x['value'] for x in matches})!=1: return None,None
    chosen=matches[-1]
    return OPS[predicate['operator']](chosen['value'],predicate['threshold']),chosen

def review(root,cutoff):
    root=Path(root); observations=[]; results=[]
    for path in (root/'12_Data/Companies').glob('*/*.json'):
        snap=json.loads(path.read_text())
        if parse_time(snap['cutoff'])<=parse_time(cutoff):
            observations.extend(dict(o,_snapshot_cutoff=snap['cutoff']) for o in snap.get('observations',[]))
    for path in sorted((root/'12_Data/Predictions').glob('P-*.json')):
        claim=json.loads(path.read_text())
        if claim.get('record_type')!='prospective' or parse_time(claim['check_at'])>parse_time(cutoff): continue
        state='pending_data'; target=None; cond=None
        if claim.get('condition'):
            condition,cond=evaluate(claim['condition'],observations,cutoff)
        else: condition=True
        if condition is False: state='condition_not_met'
        elif condition is True:
            outcome,target=evaluate(claim['target'],observations,cutoff)
            if outcome is not None: state='hit' if outcome else 'miss'
        item={'prediction_id':claim['prediction_id'],'reviewed_at':now(),'cutoff':cutoff,'result':state,
              'target_observation_id':target['observation_id'] if target else None,
              'condition_observation_id':cond['observation_id'] if cond else None,
              'mechanism_status':'not_established_by_direction_alone',
              'basis':'latest_available_vintage_at_review; later revisions create a new outcome record'}
        if state in {'hit','miss'} and claim.get('probability') is not None:
            item['brier_score']=(claim['probability']-int(state=='hit'))**2
            base=claim.get('baseline_probability')
            if isinstance(base,(int,float)) and 0<=base<=1 and claim.get('baseline_source'):
                item['baseline_brier_score']=(base-int(state=='hit'))**2
        write_json(root/'12_Data/Outcomes'/f"{claim['prediction_id']}-{uuid.uuid4().hex[:8]}.json",item)
        results.append(item)
    latest={}
    for p in (root/'12_Data/Outcomes').glob('P-*.json'):
        outcome=json.loads(p.read_text());key=outcome['prediction_id']
        if key not in latest or parse_time(outcome['reviewed_at'])>parse_time(latest[key]['reviewed_at']): latest[key]=outcome
    claims=[json.loads(p.read_text()) for p in (root/'12_Data/Predictions').glob('P-*.json')]
    counts={state:sum(x['result']==state for x in latest.values()) for state in ['hit','miss','condition_not_met','pending_data','unresolvable']}
    resolved=counts['hit']+counts['miss'];bs=[x['brier_score'] for x in latest.values() if 'brier_score' in x]
    lines=['# Prediction Scorecard','',f'更新：{now()}。正式前瞻条目：{len(claims)}。已解决：{resolved}。',
           '历史 v10 样本不计入；同一预测只取最新结果版本，所有旧结果仍保留。','',
           '| 状态 | 数量 |','|---|---:|',*['| '+k+' | '+str(v)+' |' for k,v in counts.items()],
           '', '命中率：'+(f"{counts['hit']/resolved:.1%}（仅描述这批已解决样本）" if resolved else '尚无已解决样本'),
           '平均 Brier：'+(f'{sum(bs)/len(bs):.4f}；概率样本数 {len(bs)}' if bs else '没有事前概率样本'),
           '', '## 分组记录','| 预测 ID | 领域 | 期限 | 置信度 | 事件群 | 最新结果 |','|---|---|---|---|---|---|']
    for c in claims:
        lines.append('| '+' | '.join(str(x).replace('|','/') for x in [c['prediction_id'],c['target']['entity'],c['horizon'],c['confidence'],c.get('event_cluster') or '未分类',latest.get(c['prediction_id'],{}).get('result','not_due')])+' |')
    lines+=['','结果是否正确与机制是否得到支持分开；同一事件下的预测相关，不能当独立样本。没有固定的“20条就可靠”门槛。',
            '基准 Brier 只在条目事前保存基准概率与来源时计算，见各 Outcome JSON。尚未计算统计置信区间，不能据此声称预测能力显著优于基准。']
    (root/'Prediction Scorecard.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return results
