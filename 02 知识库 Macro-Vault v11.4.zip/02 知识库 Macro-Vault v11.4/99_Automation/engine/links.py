"""Obsidian-safe links shared by generated notes. All targets are vault-relative."""
from pathlib import PurePosixPath


def wiki(path, label=None, fragment=None, table=False):
    path = str(path).replace('\\', '/')
    if path.endswith('.md'):
        path = path[:-3]
    if any(c in path for c in ['[', ']', '|', '#', '\n']):
        raise ValueError('Unsafe internal link target')
    target = path + ('#' + fragment if fragment else '')
    if label is not None:
        label = str(label).replace('|', '/').replace('[', '').replace(']', '').replace('\n', ' ')
        target += ('\\|' if table else '|') + label
    return '[[' + target + ']]'


def evidence_path(snapshot):
    run_id = PurePosixPath(snapshot['snapshot_relative_path']).stem
    return f"14_Reports/Run History/{run_id}/{snapshot['company']['ticker']}/Evidence.md"


def observation_link(snapshot, observation_id, label=None, table=False):
    return wiki(evidence_path(snapshot), label or observation_id,
                fragment='^' + observation_id, table=table)


def source_link(source_id, label=None, table=False):
    return wiki(f'13_Sources/Records/{source_id}.md', label or source_id, table=table)


def company_navigation(ticker):
    base = f'04_Companies/{ticker}'
    return ' · '.join(wiki(base + '/' + filename, label) for filename, label in [
        ('Company Profile.md', ticker + ' 档案'), ('Latest Brief.md', '最新简报'),
        (ticker + ' - Data History.md', '八季数据'), ('Evidence Index.md', '证据索引'),
        ('Current Thesis.md', '当前判断'), ('Thesis History.md', '判断历史')])
