---
title: "Healthcare and Pharma"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [医疗保健, 制药, Healthcare]
tags: [sectors, global]
as_of: 2026-10
---
# Healthcare and Pharma

## Definition 定义
Healthcare includes drug makers, biotech, medical devices, hospitals and health insurers. It is often treated as more defensive, but policy and trial results can cause large moves.
医疗保健包括制药、生物科技、医疗器械、医院和健康保险。常被视为偏防御，但政策和临床结果可能引发大幅波动。

## Drivers and what to watch 驱动因素与观察点
- Drug makers: patent expiries, pipeline and clinical-trial results, regulatory approval (FDA). 专利到期、研发管线、临床结果与监管批准。
- Pricing policy: government drug-price rules affect revenue. 药价政策影响收入。
- Health insurers: medical cost ratios and government programme rules. 健康险：医疗成本率和政府计划规则。
- Devices: hospital spending and procedure volumes. 器械：医院支出与手术量。
- Rates: long-duration biotech valuations are sensitive to discount rates ([[Duration and Convexity]]). 生物科技估值对利率敏感。

## Related 相关
[[US Sectors Map]], [[Sector Rotation]], [[Valuation Multiples]], [[Earnings Season]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).

- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.
