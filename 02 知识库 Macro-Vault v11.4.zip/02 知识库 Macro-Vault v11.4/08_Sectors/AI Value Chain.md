---
title: "AI Value Chain AI产业链"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [AI产业链]
tags: [sectors]
---
# AI Value Chain AI产业链

## Demand: cloud and AI spenders 需求端：云厂商与 AI 投入方
Hyperscalers (for example Microsoft, Alphabet, Amazon, Meta, Oracle) and AI labs spend on data centres. Their capex guidance is the starting signal.
大型云厂商（如 Microsoft、Alphabet、Amazon、Meta、Oracle）和 AI 实验室投资数据中心。他们的资本开支指引是起点信号。

## Chip design 芯片设计
GPUs and accelerators (for example NVIDIA, AMD) and custom ASICs (for example Broadcom, Marvell).
GPU 和加速器（如 NVIDIA、AMD）以及定制 ASIC（如 Broadcom、Marvell）。

## Foundry 晶圆代工
TSMC leads advanced manufacturing; Samsung and Intel also compete.
台积电领先先进制程；三星和 Intel 也在竞争。

## Memory 存储
HBM and DRAM (for example SK hynix, Samsung, Micron).
HBM 和 DRAM（如 SK hynix、三星、Micron）。

## Equipment 设备
ASML, Applied Materials, Lam Research, KLA, Tokyo Electron supply fab equipment.
ASML、Applied Materials、Lam Research、KLA、Tokyo Electron 提供晶圆厂设备。

## Packaging and test 封装与测试
Advanced packaging (for example TSMC CoWoS), OSATs (for example ASE, Amkor) and Asia's back-end ecosystem.
先进封装（如台积电 CoWoS）、OSAT（如 ASE、Amkor）以及亚洲的后段生态。

## Servers, networking, power 服务器、网络与电力
Server makers, networking firms, power and cooling suppliers, utilities and data-centre builders.
服务器厂商、网络公司、电力和散热供应商、公用事业与数据中心建设商。

## Applications and monetisation 应用与变现
AI software and services. Revenue here determines whether the spending is justified.
AI 软件和服务。这里的收入决定上面的投入是否合理。

## How to read 如何使用
Money flows from demand down the chain. Order signals usually travel down in sequence, while revenue shows up with a lag (a typical pattern, not a law).
资金从需求端沿产业链向下流动。订单信号通常依次向下传导，收入体现则有滞后（常见规律，不是定律）。

## Related 相关
[[Hyperscaler Capex]], [[Semiconductors]], [[Read-Across]], [[Hyperscaler Capex to Chip Chain]]

## My notes 我的笔记
(Company names are examples and change over time. Verify before relying on them. 公司名称仅为例子，会随时间变化，使用前请核实。)

## Evidence, coverage and limitations / 证据、覆盖范围与限制
- Company names and competitive positions are examples, not a verified current constituent list. Check current filings and issuer sources before relying on any relationship.
- Separate direct disclosed customer/supplier relationships from indirect thematic inference.
- Record source date for market shares, capacity, product roadmaps, index weights and customer exposure; these can change quickly.
- Industry forecasts must identify publisher, publication date, period, scope and whether the number is actual or forecast.
- Avoid assuming every company in a theme benefits equally; margins, contract structure, capacity, customer concentration and valuation can produce different outcomes.
