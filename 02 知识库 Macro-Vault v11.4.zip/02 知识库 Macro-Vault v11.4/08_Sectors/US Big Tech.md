---
title: "US Big Tech 美国大型科技股"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [美国大型科技股]
tags: [sectors]
---
# US Big Tech 美国大型科技股

## Role 角色
A few very large companies make up a big share of US indices, so their results move the whole market (verify current weights).
少数超大公司占美国指数很大比重，因此它们的业绩会带动整个市场（请核实最新权重）。

## Two stories 两条主线
AI capex (cost side) and AI monetisation (revenue side). Markets judge whether the second justifies the first.
AI 资本开支（成本端）和 AI 变现（收入端）。市场判断后者是否足以支撑前者。

## Key numbers to watch 关键数字
Capex guidance, cloud growth, operating margin, free cash flow, advertising trends, AI revenue disclosures, buybacks.
资本开支指引、云业务增长、营业利润率、自由现金流、广告趋势、AI 收入披露、回购。

## Index effect 指数效应
Their moves feed straight into the S&P 500, Nasdaq and ETFs; see the mega-cap transmission chain.
它们的波动直接传导到标普 500、纳斯达克和 ETF；见超大市值传导链。

## Macro sensitivity 宏观敏感度
Long-duration growth stocks react to the 10-year yield and rate expectations.
长久期成长股对 10 年期收益率和利率预期敏感。

## Related 相关
[[Mega-Cap Earnings to Index]], [[Hyperscaler Capex]], [[Cloud and Software]], [[Treasury Yield to Equity Valuation]]
2026-10-27 新增公司档案：[[04_Companies/AAPL/Company Profile|Apple]]、[[04_Companies/META/Company Profile|Meta]]、[[04_Companies/AVGO/Company Profile|Broadcom]]、[[04_Companies/TSLA/Company Profile|Tesla]]

## My notes 我的笔记
(Company names are examples and change over time. Verify before relying on them. 公司名称仅为例子，会随时间变化，使用前请核实。)

## Evidence, coverage and limitations / 证据、覆盖范围与限制
- Company names and competitive positions are examples, not a verified current constituent list. Check current filings and issuer sources before relying on any relationship.
- Separate direct disclosed customer/supplier relationships from indirect thematic inference.
- Record source date for market shares, capacity, product roadmaps, index weights and customer exposure; these can change quickly.
- Industry forecasts must identify publisher, publication date, period, scope and whether the number is actual or forecast.
- Avoid assuming every company in a theme benefits equally; margins, contract structure, capacity, customer concentration and valuation can produce different outcomes.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Cross Asset Transmission|美债怎样影响股票、银行、房产、美元和黄金]]：先找收益率变化的来源，再分别解释估值、经营与融资。
