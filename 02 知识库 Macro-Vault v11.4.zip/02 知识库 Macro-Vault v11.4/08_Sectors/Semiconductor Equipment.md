---
title: "Semiconductor Equipment 半导体设备"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [半导体设备]
tags: [sectors]
---
# Semiconductor Equipment 半导体设备

## Role 角色
Supplies the machines used to build chips: lithography, deposition, etch, inspection.
提供制造芯片的机器：光刻、沉积、刻蚀、检测。

## Why it leads 为何领先
Chipmakers order equipment before expanding output, so orders often signal future capacity.
芯片厂在扩产前先订购设备，订单常预示未来产能。

## Key numbers to watch 关键数字
Orders, backlog, customer capex plans, share of sales to China.
订单、在手订单、客户资本开支计划、对中国销售占比。

## Main risk 主要风险
Export controls and customer capex cuts.
出口管制和客户削减资本开支。

## Related 相关
[[Geopolitics and Export Controls]], [[Capex Cycle]], [[Export Controls and Tariffs]]

## My notes 我的笔记
(Company names are examples and change over time. Verify before relying on them. 公司名称仅为例子，会随时间变化，使用前请核实。)

## Evidence, coverage and limitations / 证据、覆盖范围与限制
- Company names and competitive positions are examples, not a verified current constituent list. Check current filings and issuer sources before relying on any relationship.
- Separate direct disclosed customer/supplier relationships from indirect thematic inference.
- Record source date for market shares, capacity, product roadmaps, index weights and customer exposure; these can change quickly.
- Industry forecasts must identify publisher, publication date, period, scope and whether the number is actual or forecast.
- Avoid assuming every company in a theme benefits equally; margins, contract structure, capacity, customer concentration and valuation can produce different outcomes.
