---
title: "Consumer Staples and Discretionary"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [消费, 必需消费, 可选消费, Consumer]
tags: [sectors, global]
as_of: 2026-10
---
# Consumer Staples and Discretionary

## Definition 定义
Consumer staples sell everyday necessities; consumer discretionary sells goods and services people can postpone. Together they show the health of household spending.
必需消费品销售日常必需品；可选消费销售可推迟购买的商品和服务。两者合起来反映家庭支出的状况。

## Drivers and what to watch 驱动因素与观察点
- Staples: pricing power, input costs, volume; often steadier in slowdowns. 必需消费：提价能力、成本、销量，经济放缓时较稳。
- Discretionary: sensitive to jobs, wages, credit and confidence ([[Consumer Confidence]], [[Retail Sales]], [[Labor Market]]). 可选消费对就业、工资、信贷和信心敏感。
- Mix: higher-income and lower-income shoppers can behave differently; check company commentary. 不同收入群体表现可能不同。
- Credit: card delinquencies show stress ([[Consumer Spending to Retail and Credit]]). 信用卡违约反映压力。
- Tariffs and the dollar affect costs and overseas sales ([[Trade Tariffs and Supply Chains]]). 关税和美元影响成本和海外销售。

## Related 相关
[[US Consumer and Housing]], [[Consumer Spending to Retail and Credit]], [[US Sectors Map]], [[Sector Rotation]]
2026-10-27 新增公司档案：[[04_Companies/TSLA/Company Profile|Tesla]]、[[04_Companies/AAPL/Company Profile|Apple]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).

- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.
