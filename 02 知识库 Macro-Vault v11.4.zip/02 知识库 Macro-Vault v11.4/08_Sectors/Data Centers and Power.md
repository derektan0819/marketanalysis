---
title: "Data Centers and Power 数据中心与电力"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [数据中心与电力]
tags: [sectors]
---
# Data Centers and Power 数据中心与电力

## Role 角色
Data centres house AI servers. Power, cooling and grid connections are the physical limits on expansion.
数据中心容纳 AI 服务器。电力、散热和电网接入是扩张的物理限制。

## US angle 美国角度
Data-centre build-outs raise electricity demand, which matters for utilities, power producers and equipment makers. Large cloud companies increasingly sign long-term power deals (verify current examples).
数据中心建设推高用电需求，对公用事业、发电企业和设备制造商意义重大。大型云公司越来越多地签订长期购电协议（请核实最新例子）。

## Key numbers to watch 关键数字
Capex announcements, contracted power capacity, utility load forecasts, interconnection delays.
资本开支公告、已签约电力容量、公用事业负荷预测、并网延迟。

## Risks 风险
Power shortages, equipment lead times, permitting, regulation and the risk that AI demand disappoints.
电力短缺、设备交付周期、审批、监管，以及 AI 需求不及预期的风险。

## Related 相关
[[Hyperscaler Capex]], [[AI Value Chain]], [[Commodity Prices]]

## My notes 我的笔记
(Company names are examples and change over time. Verify before relying on them. 公司名称仅为例子，会随时间变化，使用前请核实。)

## Evidence, coverage and limitations / 证据、覆盖范围与限制
- Company names and competitive positions are examples, not a verified current constituent list. Check current filings and issuer sources before relying on any relationship.
- Separate direct disclosed customer/supplier relationships from indirect thematic inference.
- Record source date for market shares, capacity, product roadmaps, index weights and customer exposure; these can change quickly.
- Industry forecasts must identify publisher, publication date, period, scope and whether the number is actual or forecast.
- Avoid assuming every company in a theme benefits equally; margins, contract structure, capacity, customer concentration and valuation can produce different outcomes.
