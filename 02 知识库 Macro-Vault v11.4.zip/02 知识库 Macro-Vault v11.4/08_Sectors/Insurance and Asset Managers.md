---
title: "Insurance and Asset Managers"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [保险, 资产管理, Insurance, Asset managers]
tags: [sectors, global]
as_of: 2026-10
---
# Insurance and Asset Managers

## Definition 定义
Insurers earn from underwriting and by investing premiums (the 'float'). Asset managers earn fees on assets under management (AUM), so markets and flows drive revenue.
保险公司靠承保和投资保费（浮存金）获利。资产管理公司按管理资产规模（AUM）收费，所以市场和资金流决定收入。

## Drivers and what to watch 驱动因素与观察点
- Insurers: underwriting results, catastrophe losses, investment yield and duration ([[Duration and Convexity]]). 承保结果、巨灾赔付、投资收益率和久期。
- Higher yields can lift insurers' investment income but cause unrealised bond losses. 收益率上升提升投资收入，但带来未实现债券损失。
- Asset managers: AUM, net flows, fee rates; passive funds pressure fees ([[Passive Flows and ETFs]]). 资管：规模、净流入、费率。
- Private markets: growth in private credit and alternatives ([[Private Credit and Shadow Banking]]). 私募市场增长。
- Regulation and capital rules differ by country. 监管和资本规则因国而异。

## Related 相关
[[US Banks]], [[Bank Metrics]], [[Asset Allocation and Diversification]], [[US Sectors Map]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).

- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Cross Asset Transmission|美债怎样影响股票、银行、房产、美元和黄金]]：先找收益率变化的来源，再分别解释估值、经营与融资。
