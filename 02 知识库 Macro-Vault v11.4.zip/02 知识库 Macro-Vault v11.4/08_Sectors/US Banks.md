---
title: "US Banks 美国银行业"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [美国银行业]
tags: [sectors]
---
# US Banks 美国银行业

## Who 范围
Large banks (for example JPMorgan, Bank of America, Citigroup, Wells Fargo), investment banks (Goldman Sachs, Morgan Stanley) and regional banks.
大型银行（如 JPMorgan、Bank of America、Citigroup、Wells Fargo）、投资银行（Goldman Sachs、Morgan Stanley）和区域性银行。

## Earnings drivers 盈利驱动
Net interest income and margin, deposit costs, loan growth, charge-offs, investment banking fees, trading revenue.
净利息收入和息差、存款成本、贷款增长、核销、投行费用、交易收入。

## Regulation 监管
Fed stress tests influence capital requirements, dividends and buybacks.
美联储压力测试影响资本要求、股息和回购。

## Why they matter 重要性
Big banks open earnings season and their commentary on consumers and companies sets the tone. The 2023 regional bank stress showed how deposits and unrealised bond losses can create sudden risk.
大银行率先公布财报，其对消费者和企业的评论定下基调。2023 年区域银行风波显示存款和债券浮亏可能带来突发风险。

## Key numbers 关键数字
NII guidance, NIM, charge-offs, provisions, CET1, loan and deposit growth.
净利息收入指引、息差、核销、拨备、CET1、贷款和存款增长。

## Related 相关
[[Bank Metrics]], [[Bank Earnings to Market]], [[Fed Decision to Markets]], [[US 10-Year Treasury Yield]]

## My notes 我的笔记
(Company names are examples and change over time. Verify before relying on them. 公司名称仅为例子，会随时间变化，使用前请核实。)

## Evidence, coverage and limitations / 证据、覆盖范围与限制
- Company names and competitive positions are examples, not a verified current constituent list. Check current filings and issuer sources before relying on any relationship.
- Separate direct disclosed customer/supplier relationships from indirect thematic inference.
- Record source date for market shares, capacity, product roadmaps, index weights and customer exposure; these can change quickly.
- Industry forecasts must identify publisher, publication date, period, scope and whether the number is actual or forecast.
- Avoid assuming every company in a theme benefits equally; margins, contract structure, capacity, customer concentration and valuation can produce different outcomes.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Yield Curve Scenarios|曲线变化：牛陡、熊陡、牛平、熊平]]：先看哪一端在动，再解释增长、通胀与供给。
- [[21_US_Treasuries/Treasury Cross Asset Transmission|美债怎样影响股票、银行、房产、美元和黄金]]：先找收益率变化的来源，再分别解释估值、经营与融资。
