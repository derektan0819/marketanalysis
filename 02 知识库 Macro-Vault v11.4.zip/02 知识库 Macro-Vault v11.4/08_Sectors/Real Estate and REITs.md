---
title: "Real Estate and REITs"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [房地产, 房地产信托, REITs]
tags: [sectors, global]
as_of: 2026-10
---
# Real Estate and REITs

## Definition 定义
Real estate covers property developers and real estate investment trusts (REITs). A US REIT must distribute most of its taxable income to shareholders, so yield and financing costs matter.
房地产包括开发商和房地产投资信托（REITs）。美国 REIT 须把大部分应税收入分配给股东，所以收益率和融资成本很重要。

## Drivers and what to watch 驱动因素与观察点
- Rates: higher interest rates raise borrowing costs and compete with REIT yields ([[Interest Rates]], [[US 10-Year Treasury Yield]]). 利率上升抬高融资成本并与 REIT 收益率竞争。
- Property types differ: offices, retail, industrial, apartments, data centres and healthcare facilities behave differently. 不同物业类型差异很大。
- Credit: commercial real-estate loans are held by banks and funds ([[US Banks]], [[Private Credit and Shadow Banking]]). 商业地产贷款由银行和基金持有。
- Housing data ([[Housing Starts]], [[Case-Shiller Home Price Index]]) cover residential, not commercial, property. 住房数据不等于商业地产。
- Valuation: REITs use funds from operations (FFO) rather than net income. REIT 常用营运资金流量（FFO）。

## Related 相关
[[US Consumer and Housing]], [[US Sectors Map]], [[Credit Markets]], [[Valuation Multiples]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).

- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.

## 美债专题关联（v11.4）

- [[21_US_Treasuries/Treasury Cross Asset Transmission|美债怎样影响股票、银行、房产、美元和黄金]]：先找收益率变化的来源，再分别解释估值、经营与融资。
