---
title: "US Sectors Map 美国11大板块"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [美国11大板块]
tags: [sectors]
---
# US Sectors Map 美国11大板块

## Technology 科技
Semiconductors, software, hardware. Sensitive to yields and AI capex; one of the largest index weights (verify).
半导体、软件、硬件。对收益率和 AI 资本开支敏感；是指数中权重最大的板块之一（请核实）。

## Communication Services 通信服务
Internet platforms (for example Alphabet, Meta), telecom, media. Advertising is cyclical.
互联网平台（如 Alphabet、Meta）、电信、传媒。广告业务具有周期性。

## Consumer Discretionary 可选消费
Retailers, autos, travel (for example Amazon, Tesla). Sensitive to income, credit and rates.
零售、汽车、旅游（如 Amazon、Tesla）。对收入、信贷和利率敏感。

## Consumer Staples 必需消费
Food, beverages, household goods. Defensive; pricing power versus input costs matters.
食品、饮料、家庭用品。防御性；关键是定价能力与投入成本。

## Health Care 医疗保健
Pharma, biotech, insurers, devices. Defensive; drug pricing and policy risk.
制药、生物科技、保险、器械。防御性；面临药价和政策风险。

## Financials 金融
Banks, insurers, asset managers. Sensitive to the yield curve, credit and market activity.
银行、保险、资产管理。对收益率曲线、信贷和市场活跃度敏感。

## Industrials 工业
Aerospace, machinery, transport. Follows the capex cycle and PMIs.
航空航天、机械、运输。跟随资本开支周期和 PMI。

## Energy 能源
Oil and gas producers. Follows oil and gas prices and capital discipline.
油气生产商。跟随油气价格和资本纪律。

## Utilities 公用事业
Regulated power and gas. Bond-like and rate-sensitive; data-centre power demand adds a growth angle.
受监管的电力和燃气。类债券，对利率敏感；数据中心用电需求带来增长看点。

## Real Estate 房地产
REITs. Rate-sensitive; office, residential and data-centre REITs behave differently.
REITs。对利率敏感；写字楼、住宅和数据中心 REIT 表现各不相同。

## Materials 原材料
Chemicals, metals, mining. Follows global growth, the dollar and commodity prices.
化工、金属、矿业。跟随全球增长、美元和大宗商品价格。

## Added sector notes (v10)
[[Energy Oil and Gas]], [[Healthcare and Pharma]], [[Consumer Staples and Discretionary]], [[Industrials and Defense]], [[Real Estate and REITs]], [[Insurance and Asset Managers]]

## Related 相关
[[Sector Rotation]], [[US Equity Indices]], [[Index Weighting and Concentration]]
2026-10-27 新增板块：[[Utilities]]、[[Materials]]

## My notes 我的笔记
(Company names are examples and change over time. Verify before relying on them. 公司名称仅为例子，会随时间变化，使用前请核实。)

## Evidence, coverage and limitations / 证据、覆盖范围与限制
- Company names and competitive positions are examples, not a verified current constituent list. Check current filings and issuer sources before relying on any relationship.
- Separate direct disclosed customer/supplier relationships from indirect thematic inference.
- Record source date for market shares, capacity, product roadmaps, index weights and customer exposure; these can change quickly.
- Industry forecasts must identify publisher, publication date, period, scope and whether the number is actual or forecast.
- Avoid assuming every company in a theme benefits equally; margins, contract structure, capacity, customer concentration and valuation can produce different outcomes.
