---
title: "Semiconductors 半导体"
created: 2026-10-19
updated: 2026-10-27
source: "待补充"
aliases: [半导体]
tags: [sectors]
---
# Semiconductors 半导体

## Segments 细分
Logic, memory, analog, power and discrete devices.
逻辑芯片、存储、模拟、功率和分立器件。

## End-markets 终端市场
Data centre and AI, smartphones, PCs, autos, industrial.
数据中心和 AI、智能手机、PC、汽车、工业。

## What drives the cycle 周期驱动因素
Customer inventory, capacity additions, pricing and end demand. AI demand can diverge from the rest of the market.
客户库存、产能扩张、价格和终端需求。AI 需求可能与其他市场出现分化。

## Key numbers to watch 关键数字
Data-centre revenue, gross margin, inventory days, capex guidance, utilisation, next-quarter guidance.
数据中心收入、毛利率、库存天数、资本开支指引、产能利用率、下季度指引。

## Macro sensitivity 宏观敏感度
High-multiple stocks are sensitive to yields; global demand is sensitive to growth and trade policy.
高估值股票对收益率敏感；全球需求对增长和贸易政策敏感。

## Related 相关
[[SOX Index]], [[Global Semiconductor Sales]], [[Inventory Cycle]], [[Chip Earnings to AI Stocks]]
2026-10-27 新增公司档案：[[04_Companies/AVGO/Company Profile|Broadcom]]

## My notes 我的笔记
(Company names are examples and change over time. Verify before relying on them. 公司名称仅为例子，会随时间变化，使用前请核实。)

## Evidence, coverage and limitations / 证据、覆盖范围与限制
- Company names and competitive positions are examples, not a verified current constituent list. Check current filings and issuer sources before relying on any relationship.
- Separate direct disclosed customer/supplier relationships from indirect thematic inference.
- Record source date for market shares, capacity, product roadmaps, index weights and customer exposure; these can change quickly.
- Industry forecasts must identify publisher, publication date, period, scope and whether the number is actual or forecast.
- Avoid assuming every company in a theme benefits equally; margins, contract structure, capacity, customer concentration and valuation can produce different outcomes.
