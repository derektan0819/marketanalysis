---
title: "Utilities 公用事业"
aliases: [公用事业, 公用事业板块, Utilities Sector]
tags: [sectors]
created: 2026-10-27
updated: 2026-10-27
source: "MSCI / S&P Dow Jones Indices, Global Industry Classification Standard (GICS) https://www.msci.com/our-solutions/indexes/gics"
verified: 2026-10-27
as_of: 2026-10
---
# Utilities 公用事业

## Definition 定义
In the GICS classification, Utilities is one of 11 sectors. It covers electric, gas and water utilities, multi-utilities, and independent power and renewable electricity producers.
在 GICS 行业分类里，公用事业是 11 个板块之一，包括电力、燃气、水务公用事业，综合公用事业，以及独立发电商和可再生能源发电商。

## Drivers and what to watch 驱动因素与观察点
- **Regulation:** most US utilities earn a return set by state regulators through rate cases, so profits are steadier than in most sectors. 监管：多数美国公用事业的回报由州监管机构通过费率审批决定，利润比大多数板块稳定。
- **Rates:** utilities borrow heavily and pay steady dividends, so higher Treasury yields raise their funding costs and make their yields less attractive ([[Interest Rates]], [[US 10-Year Treasury Yield]]). 利率：负债高、分红稳，美债收益率上升会抬高融资成本，也削弱股息吸引力。
- **Power demand:** data centers and electrification can lift demand and investment needs ([[Data Centers and Power]], [[Hyperscaler Capex]]). 用电需求：数据中心和电气化可能推高需求和投资。
- **Fuel costs:** natural gas prices affect generation costs, usually passed to customers with a lag ([[Natural Gas Prices]]). 燃料成本：天然气价格影响发电成本，通常滞后转嫁给用户。
- **Capital spending:** grid and generation projects need debt and sometimes new shares, which can dilute holders. 资本开支：电网和发电项目需要举债，有时增发股票，可能稀释股东。
- **Weather and policy:** heat, storms and wildfire liability, plus energy policy, can move single names sharply. 天气与政策：高温、风暴、山火责任和能源政策可能让个股大幅波动。

## How it trades 交易特征
Utilities are usually treated as defensive and rate-sensitive: they often hold up better in selloffs but lag when yields rise. Independent power producers tied to data-center demand can behave more like growth stocks than regulated utilities.
公用事业通常被视为防御型、对利率敏感：大跌时往往更抗跌，但在收益率上升时落后。与数据中心需求挂钩的独立发电商，走势可能更像成长股而非受监管公用事业。

## Related 相关
[[US Sectors Map]], [[Sector Rotation]], [[Data Centers and Power]], [[Energy Oil and Gas]], [[Real Estate and REITs]], [[Risk-On Risk-Off]], [[Treasury Yield to Equity Valuation]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Sector membership follows GICS ([MSCI GICS](https://www.msci.com/our-solutions/indexes/gics); [GICS Sector Definitions](https://www.msci.com/downloads/documents/indexes/gics/GICS+Sector+Definitions+2023.pdf)). The industry list was confirmed from MSCI and S&P Dow Jones Indices materials on 2026-10-27; the full definitions PDF was read through a search summary, not opened directly. Sector weights change; check the current index fact sheet before quoting a weight.
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice. as_of: 2026-10 (general background, no live values).
