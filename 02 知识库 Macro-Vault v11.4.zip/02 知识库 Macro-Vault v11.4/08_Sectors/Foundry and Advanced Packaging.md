---
title: "Foundry and Advanced Packaging 晶圆代工与先进封装"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [晶圆代工与先进封装]
tags: [sectors]
---
# Foundry and Advanced Packaging 晶圆代工与先进封装

## Role 角色
Foundries manufacture chips designed by others; advanced packaging joins chips and memory into AI accelerators.
晶圆代工厂制造他人设计的芯片；先进封装把芯片和存储整合成 AI 加速器。

## Why it matters 重要性
Advanced packaging capacity has been a constraint on AI accelerator supply (verify current status).
先进封装产能曾是 AI 加速器供应的瓶颈（请核实最新情况）。

## Key numbers to watch 关键数字
Monthly revenue, utilisation, advanced-node share, capex guidance, pricing.
月度营收、产能利用率、先进制程占比、资本开支指引、价格。

## Related 相关
[[TSMC Monthly Revenue]], [[AI Value Chain]], [[Semiconductors]]

## My notes 我的笔记
(Company names are examples and change over time. Verify before relying on them. 公司名称仅为例子，会随时间变化，使用前请核实。)

## Evidence, coverage and limitations / 证据、覆盖范围与限制
- Company names and competitive positions are examples, not a verified current constituent list. Check current filings and issuer sources before relying on any relationship.
- Separate direct disclosed customer/supplier relationships from indirect thematic inference.
- Record source date for market shares, capacity, product roadmaps, index weights and customer exposure; these can change quickly.
- Industry forecasts must identify publisher, publication date, period, scope and whether the number is actual or forecast.
- Avoid assuming every company in a theme benefits equally; margins, contract structure, capacity, customer concentration and valuation can produce different outcomes.
