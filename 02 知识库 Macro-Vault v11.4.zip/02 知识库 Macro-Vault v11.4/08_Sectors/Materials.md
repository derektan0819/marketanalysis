---
title: "Materials 原材料"
aliases: [原材料, 原材料板块, 基础材料, Materials Sector]
tags: [sectors]
created: 2026-10-27
updated: 2026-10-27
source: "MSCI / S&P Dow Jones Indices, Global Industry Classification Standard (GICS) https://www.msci.com/our-solutions/indexes/gics"
verified: 2026-10-27
as_of: 2026-10
---
# Materials 原材料

## Definition 定义
In the GICS classification, Materials is one of 11 sectors. It has five industries: Chemicals, Construction Materials, Containers & Packaging, Metals & Mining, and Paper & Forest Products. Steel producers and gold miners sit here.
在 GICS 行业分类里，原材料是 11 个板块之一，分五个行业：化工、建筑材料、容器与包装、金属与采矿、纸业与林产品。钢铁公司和金矿公司都属于这个板块。

## Drivers and what to watch 驱动因素与观察点
- **Global industrial demand,** especially China, sets volumes and prices for metals and chemicals ([[China Linkages to US Markets]], [[China Policy to Commodities and Asia]], [[China Official PMI and Activity Data]]). 全球工业需求，尤其是中国，决定金属和化工的量与价。
- **Commodity prices** flow almost directly into miners' earnings ([[Commodity Prices]], [[Copper Price]], [[Gold Price]]). 商品价格几乎直接进入矿业公司利润。
- **The dollar:** commodities are priced in dollars, so a weaker dollar tends to help prices and US exporters ([[DXY]]). 美元：商品以美元计价，美元走弱通常利好价格和美国出口商。
- **Energy input costs:** natural gas is a key feedstock and fuel for chemicals ([[Natural Gas Prices]]). 能源成本：天然气是化工的关键原料和燃料。
- **Construction and housing** drive cement, aggregates and wood ([[Housing Starts]], [[US Consumer and Housing]]). 建筑与住房带动水泥、骨料和木材。
- **Trade policy:** tariffs on steel, aluminum and other materials change both costs and competition ([[Trade Tariffs and Supply Chains]], [[Tariffs to Prices and Earnings]]). 贸易政策：钢铝等关税同时改变成本与竞争格局。

## How it trades 交易特征
Materials is a cyclical sector: it usually does better when global manufacturing is accelerating and the dollar is soft, and worse in a goods slowdown. Gold miners are the exception, moving more with gold and real yields ([[Dollar and Real Yields to Gold and Crypto]]). The sector is usually a small part of the S&P 500, so it matters more for breadth and cyclical signals than for the index level.
原材料是周期板块：全球制造业加速、美元偏弱时通常表现较好，商品部门放缓时较差。金矿公司例外，更多跟随金价和实际利率。它在标普 500 中占比通常较小，对“市场广度”和周期信号的意义大于对指数点位的影响。

## Related 相关
[[US Sectors Map]], [[Sector Rotation]], [[Industrials and Defense]], [[Energy Oil and Gas]], [[Industrial Production and Capacity Utilization]], [[Market Breadth]], [[Gold]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Sector membership follows GICS ([MSCI GICS](https://www.msci.com/our-solutions/indexes/gics); [GICS Sector Definitions](https://www.msci.com/downloads/documents/indexes/gics/GICS+Sector+Definitions+2023.pdf)). The industry list was confirmed from MSCI and S&P Dow Jones Indices materials on 2026-10-27; the full definitions PDF was read through a search summary, not opened directly. The sector's index weight is not stated here: check the current S&P 500 fact sheet before quoting one (待核实).
- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice. as_of: 2026-10 (general background, no live values).
