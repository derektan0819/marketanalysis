---
title: "Sectors MOC — 板块与行业"
tags: [index, moc]
created: 2026-10-27
updated: 2026-10-27
source: "自动整理：完整列出 08_Sectors 的全部文件（2026-10-27）"
---

# Sectors MOC — 板块与行业

[[00_Index/Master Index|总索引]] · [[HOME|首页]]

本文件夹共 18 个文件，其中笔记 18 篇。以下按路径完整列出，笔记显示标题。

## 先读

- [[08_Sectors/US Sectors Map|US Sectors Map 美国11大板块]]

## 笔记

- [[08_Sectors/AI Value Chain|AI Value Chain AI产业链]]
- [[08_Sectors/Cloud and Software|Cloud and Software 云与软件]]
- [[08_Sectors/Consumer Staples and Discretionary|Consumer Staples and Discretionary]]
- [[08_Sectors/Data Centers and Power|Data Centers and Power 数据中心与电力]]
- [[08_Sectors/Energy Oil and Gas|Energy Oil and Gas]]
- [[08_Sectors/Foundry and Advanced Packaging|Foundry and Advanced Packaging 晶圆代工与先进封装]]
- [[08_Sectors/Healthcare and Pharma|Healthcare and Pharma]]
- [[08_Sectors/Industrials and Defense|Industrials and Defense]]
- [[08_Sectors/Insurance and Asset Managers|Insurance and Asset Managers]]
- [[08_Sectors/Materials|Materials 原材料]]
- [[08_Sectors/Memory Chips|Memory Chips 存储芯片]]
- [[08_Sectors/Real Estate and REITs|Real Estate and REITs]]
- [[08_Sectors/Semiconductor Equipment|Semiconductor Equipment 半导体设备]]
- [[08_Sectors/Semiconductors|Semiconductors 半导体]]
- [[08_Sectors/US Banks|US Banks 美国银行业]]
- [[08_Sectors/US Big Tech|US Big Tech 美国大型科技股]]
- [[08_Sectors/US Sectors Map|US Sectors Map 美国11大板块]]
- [[08_Sectors/Utilities|Utilities 公用事业]]
