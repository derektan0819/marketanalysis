---
title: "Cloud and Software 云与软件"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [云与软件]
tags: [sectors]
---
# Cloud and Software 云与软件

## Cloud leaders 云领先者
Amazon Web Services, Microsoft Azure and Google Cloud supply the computing that AI runs on.
Amazon Web Services、Microsoft Azure 和 Google Cloud 提供 AI 运行所需的算力。

## What to watch 关注点
Cloud revenue growth, backlog (remaining performance obligations), operating margin, free cash flow and capex.
云收入增长、在手订单（剩余履约义务）、营业利润率、自由现金流和资本开支。

## AI monetisation 变现
Do AI features raise cloud consumption or software pricing enough to justify the capex?
AI 功能是否足以提升云使用量或软件定价，从而支撑资本开支？

## Software 软件
Subscription software is sensitive to yields and to enterprise IT budgets; net revenue retention and billings show demand.
订阅软件对收益率和企业 IT 预算敏感；净收入留存率和账单反映需求。

## Related 相关
[[Hyperscaler Capex]], [[AI Value Chain]], [[US Big Tech]], [[Cash Flow and FCF]]

## My notes 我的笔记
(Company names are examples and change over time. Verify before relying on them. 公司名称仅为例子，会随时间变化，使用前请核实。)

## Evidence, coverage and limitations / 证据、覆盖范围与限制
- Company names and competitive positions are examples, not a verified current constituent list. Check current filings and issuer sources before relying on any relationship.
- Separate direct disclosed customer/supplier relationships from indirect thematic inference.
- Record source date for market shares, capacity, product roadmaps, index weights and customer exposure; these can change quickly.
- Industry forecasts must identify publisher, publication date, period, scope and whether the number is actual or forecast.
- Avoid assuming every company in a theme benefits equally; margins, contract structure, capacity, customer concentration and valuation can produce different outcomes.
