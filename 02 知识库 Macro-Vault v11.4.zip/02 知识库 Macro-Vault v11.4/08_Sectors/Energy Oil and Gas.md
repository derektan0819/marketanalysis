---
title: "Energy Oil and Gas"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [能源, 石油天然气, Energy sector]
tags: [sectors, global]
as_of: 2026-10
---
# Energy Oil and Gas

## Definition 定义
Energy companies explore, produce, transport and refine oil, gas and related products. Earnings follow commodity prices, costs and spending discipline.
能源公司勘探、生产、运输和炼化石油天然气。盈利随商品价格、成本和资本开支纪律变化。

## Drivers and what to watch 驱动因素与观察点
- Price link: crude and gas prices drive upstream revenue ([[WTI and Brent Crude]], [[Natural Gas Prices]]). 上游收入随油气价格变化。
- Segments: upstream (production), midstream (pipelines), refining and marketing; each reacts differently. 上游、中游和炼化反应不同。
- Capital discipline: spending, buybacks and dividends ([[Share Buybacks and Dividends]]). 资本开支与回馈股东。
- Demand: power demand from data centres is raising interest in gas ([[Data Centers and Power]]). 数据中心电力需求提升天然气关注度。
- Geopolitics: OPEC+ and shipping chokepoints ([[Middle East and Oil Exporters]]). 地缘政治。

## Related 相关
[[Oil Price Transmission]], [[Commodity Prices]], [[Middle East and Oil Exporters]], [[US Sectors Map]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).

- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.
