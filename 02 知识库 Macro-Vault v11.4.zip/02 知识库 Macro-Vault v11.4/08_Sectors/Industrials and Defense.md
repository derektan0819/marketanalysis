---
title: "Industrials and Defense"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [工业, 国防, Industrials, Defense]
tags: [sectors, global]
as_of: 2026-10
---
# Industrials and Defense

## Definition 定义
Industrials include machinery, transport, aerospace, construction and defence contractors. Many depend on the business cycle; defence depends on government budgets.
工业板块包括机械、运输、航空航天、建筑和国防承包商。多数随经济周期变化；国防取决于政府预算。

## Drivers and what to watch 驱动因素与观察点
- Cycle: orders, backlog, PMIs ([[PMI]], [[Business Cycle and Recession]]). 订单、在手订单和 PMI。
- Capex: factory, grid and data-centre spending drives equipment demand ([[Capex Cycle]]). 资本开支带动设备需求。
- Defence: multi-year government contracts and budget decisions. 国防：多年期政府合同和预算。
- Transport: freight volumes and fuel costs. 运输：货运量和燃料成本。
- Trade policy and supply chains ([[Trade Tariffs and Supply Chains]]). 贸易政策与供应链。

## Related 相关
[[US Sectors Map]], [[Capex Cycle]], [[Inventory Cycle]], [[Geopolitics and Export Controls]]

## My notes 我的笔记
(在这里补充你自己的理解、例子、课程内容)

## Evidence and limitations / 证据与限制
- Institutions, policies, rankings and levels change. Verify against the primary source before relying on anything here. as_of: 2026-10 (general background, no live values).

- Describing a mechanism does not prove it caused a specific market move; name an alternative explanation in any report.
- Educational background, not investment advice.
