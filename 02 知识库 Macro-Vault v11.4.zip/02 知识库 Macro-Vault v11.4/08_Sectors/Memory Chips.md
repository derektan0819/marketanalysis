---
title: "Memory Chips 存储芯片"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [存储芯片]
tags: [sectors]
---
# Memory Chips 存储芯片

## Products 产品
DRAM, NAND and HBM (high-bandwidth memory used with AI accelerators).
DRAM、NAND 以及 HBM（与 AI 加速器搭配的高带宽存储）。

## Why it is different 为何特殊
Pricing is commodity-like and highly cyclical, so profits swing sharply with prices.
价格接近大宗商品且周期性极强，因此利润随价格大幅波动。

## Key numbers to watch 关键数字
Contract prices, customer and supplier inventory, capex discipline, HBM share and qualification news.
合约价、客户和供应商库存、资本开支纪律、HBM 份额和认证消息。

## Read-across 关联传导
AI accelerator demand feeds HBM; PC and phone demand feeds standard DRAM and NAND.
AI 加速器需求带动 HBM；PC 和手机需求带动普通 DRAM 和 NAND。

## Related 相关
[[Memory Price Cycle]], [[DRAM Contract Prices]], [[Inventory Cycle]]

## My notes 我的笔记
(Company names are examples and change over time. Verify before relying on them. 公司名称仅为例子，会随时间变化，使用前请核实。)

## Evidence, coverage and limitations / 证据、覆盖范围与限制
- Company names and competitive positions are examples, not a verified current constituent list. Check current filings and issuer sources before relying on any relationship.
- Separate direct disclosed customer/supplier relationships from indirect thematic inference.
- Record source date for market shares, capacity, product roadmaps, index weights and customer exposure; these can change quickly.
- Industry forecasts must identify publisher, publication date, period, scope and whether the number is actual or forecast.
- Avoid assuming every company in a theme benefits equally; margins, contract structure, capacity, customer concentration and valuation can produce different outcomes.


See also: [[Korea Market and KOSPI]], [[Korea Memory Stocks and US Chip Stocks]], [[Korea Semiconductor Exports]], [[Case Study Samsung Q3 2026 Preliminary Earnings]]
