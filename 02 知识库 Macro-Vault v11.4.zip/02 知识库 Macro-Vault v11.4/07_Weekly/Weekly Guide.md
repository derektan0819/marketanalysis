---
title: "Weekly Reports"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [guide, weekly]
---
# Weekly Reports

Use a consistent ISO week naming convention such as `YYYY-Www.md`; define the week start/end and timezone. Use [[Weekly Summary]]. Keep the weekly calendar sourced and timestamped, and distinguish events confirmed by issuers/agencies from estimated dates.
