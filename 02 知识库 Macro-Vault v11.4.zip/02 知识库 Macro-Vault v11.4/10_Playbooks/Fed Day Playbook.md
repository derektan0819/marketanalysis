---
title: "Fed Day Playbook / FOMC 日分析流程"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [playbooks, fed]
---
# Fed Day Playbook / FOMC 日分析流程

## Before the decision
- Record current target range from the latest official Fed release.
- Record the policy expectation source and timestamp if discussing market pricing.
- Identify the upcoming statement, projections, press conference and minutes schedule from official sources.

## Read the decision in layers
1. Decision: target range and implementation details.
2. Statement changes: compare exact wording with previous statement.
3. Summary of Economic Projections: dot plot, growth, unemployment, inflation and policy-rate projections; these are individual participants' assessments, not a promise.
4. Press conference: distinguish explicit policy guidance from conditional remarks and answers to specific questions.
5. Balance sheet and implementation details when relevant.

## Market transmission
Track front-end yields, longer yields, real yields, USD, credit and equities with timestamps. A move may reflect positioning, liquidity, risk premium or growth expectations as well as policy expectations.

## Scenarios
- More hawkish than expected:
- More dovish than expected:
- Mixed / already priced:

For each, state the expected mechanism, confirming market evidence, alternative explanation and invalidation signal.

## Sources and checks
Use official FOMC materials at https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm and the relevant dated statement/projections. Complete [[Publication Gate]].


See also: [[Market-Implied Rate Expectations]], [[Fed Funds Futures]], [[Global Central Banks]]
