---
title: "Crypto and FX Daily Checklist 加密与外汇每日清单"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [加密与外汇每日清单, Crypto FX checklist]
tags: [playbook, daily, cross-asset]
as_of: 2026-10
---
# Crypto and FX Daily Checklist 加密与外汇每日清单

Use with [[Cross-Asset Daily Coverage]]. This is a prioritization routine, not a promise that live data is available. 这是优先级流程，不保证能取到实时数据。

## 1. Set the clock 先定时间
Choose a UTC cutoff. For weekends and US holidays, report crypto with a UTC timestamp and FX only for weekdays. 周末只写加密，外汇仅限工作日。

## 2. Snapshot 快照 (each with provider, UTC time, source)
- FX: [[DXY]], [[EUR-USD]], [[USD-JPY]], [[USD-CNH]], [[USD-MYR]]
- Crypto: [[Bitcoin and Ether Price]], [[Spot Bitcoin ETF Flows]], [[Crypto Funding Rate and Open Interest]], [[Stablecoin Supply]]
- Commodities: [[Gold Price]], [[WTI and Brent Crude]]
- Global indices: [[Global Equity Indices]]

## 3. Explain 解释
For each large move: observed fact → possible mechanism → alternative explanation. Test the chains in [[Dollar and Real Yields to Gold and Crypto]] and [[Yen Carry Unwind to Global Risk Assets]]. 每个大波动写事实、机制和另一种解释。

## 4. Write the cross-asset line 写跨资产结论
One or two sentences for the daily conclusion: which of FX, crypto, commodities and global indices matter today, whether they moved for one reason or separately, and the confidence. 在每日结论里写一到两句跨资产判断。

## 5. Log and gate 记录与检查
Log falsifiable judgments in [[Prediction Log]]. Run [[Publication Gate]]; keep status `Draft` unless it is completed.

## Rules 规则
- No unsourced numbers; if a provider is missing, write `Not verified`.
- Two providers that disagree: mark `Needs Review`.
- Intervention and regulation are risks, not predictions.
- Educational research, not investment advice.
