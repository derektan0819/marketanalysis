---
title: "Worked Example: Hyperscaler Capex Raise / 云厂商资本开支上调示例"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [playbooks, worked-example]
status: illustrative-framework-only
---
# Worked Example: Hyperscaler Capex Raise / 云厂商资本开支上调示例

> This is a **hypothetical reasoning example**, not a claim about a current company or quarter. Replace every illustrative input with sourced, dated facts before using it in a real report.

## Hypothetical observation
A cloud company raises its full-year capital expenditure guidance. This is not automatically bullish for every AI-related stock.

## Evidence to collect first
- Exact old and new guidance, currency, fiscal period and midpoint calculation.
- Management explanation: AI infrastructure, land/buildings, networking, depreciation, leases or other capex.
- Cloud revenue growth, backlog/remaining performance obligations where disclosed, and monetization commentary.
- Pre-release consensus from a named provider if available.
- Supplier disclosures, capacity constraints and lead times.

## Conditional transmission chain
1. Higher capex **may** indicate stronger infrastructure demand.
2. Demand may support server, networking, accelerator, memory, foundry, packaging, equipment, power and cooling suppliers, depending on where the spending is allocated.
3. Supplier revenue may appear with different lags and may be limited by capacity, yield, customer concentration or contract terms.
4. Higher capex also increases depreciation and cash outflow; returns depend on utilization and AI monetization.
5. A stock can fall despite a capex raise if the increase was expected, margins deteriorate, returns look weak or guidance elsewhere disappoints.

## Required tests
- Is the increase absolute or only relative to a previous plan that was already expected to rise?
- Is it cash capex, finance leases, purchases of property/equipment, or a broader management definition?
- Does the company identify the beneficiaries directly?
- Is supplier exposure disclosed or inferred?
- Are market expectations and valuation already elevated?

## Scenario table
| Scenario | Conditions | What to monitor |
|---|---|---|
| Bull | Spend is incremental, demand converts to orders, monetization and returns support investment | Supplier orders, backlog, cloud growth, margins |
| Base | Capex rises but timing and beneficiaries remain mixed | Quarterly conversion and guidance stability |
| Bear | Spend rises faster than monetization, capacity bottlenecks or returns weaken | FCF, depreciation, utilization, cancellations |

## Conclusion format
`[FACT]` sourced guidance change. `[CALC]` change versus prior guidance. `[INFERENCE]` conditional supply-chain implications. `[UNKNOWN]` unconfirmed supplier allocations. Never present the read-across as guaranteed.
