---
title: "Video Linking Playbook 视频资料连接流程"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [视频链接流程, Video linking, 视频资料连接]
tags: [playbook, video, linking]
as_of: 2026-10
---
# Video Linking Playbook 视频资料连接流程

Purpose: every video you add should connect to the notes already in the Vault, so a later analysis can use both sides, the video's view and the Vault's methods and sources. 目的：你加进来的每个视频都要连到库里已有的笔记，之后分析时能同时用两边。

Template: [[Video Note]]. Folder guide: [[Video Guide]]. Evidence rules: [[Citation and Evidence Standard]].

## Steps 步骤
1. **Capture.** Put the transcript, subtitle text or your own notes into a new file from [[Video Note]] in `18_Videos`. Video access depends on the active tools; otherwise use supplied transcripts. 把字幕或文字稿、或你自己的笔记放进新笔记；Claude 看不了视频，只能读文字。
2. **Summarise in your own words.** Short quotes only; do not paste a whole transcript as the note. 用自己的话写摘要，只留短引用。
3. **Split the claims.** One row per claim, with a timestamp. Mark each as a number, a fact, an opinion or a forecast. 每个说法一行，附时间戳和类型。
4. **Link each claim to the Vault.** Pick the closest concept, indicator, transmission, sector or company note, and write the relation: agrees, conflicts, extends or new. Aim for at least three links per video. 每个说法连到最近的概念、指标、传导链或行业笔记，并写关系；每个视频至少三条链接。
5. **Fill `related` in the properties.** Use quoted wikilinks. Obsidian then shows this video in the Backlinks panel of each linked note, so the connection works from both directions. 属性里填 `related`，对方笔记的反向链接面板会自动出现这个视频，两边都连得上。
6. **Verify what matters.** For numbers and dates, find the primary source from [[Source Registry]] and record the link. Otherwise leave `Not verified`. 重要数字找一手来源核对，否则写"未验证"。
7. **Set status.** `raw` → `linked` (links done) → `verified` (key claims checked) → `superseded`. 状态：raw → linked → verified → superseded。
8. **Add it to the index** in [[Video Guide]].

## Using both sides later 之后同时使用两边
When you ask Claude to analyse something, upload the video note together with the Vault notes in its `related` list (or the whole Vault zip). Claude should then:
- put **Vault knowledge** (definitions, mechanisms, source rules) and **video claims** in separate parts of the answer; 把库里的知识和视频的说法分开写；
- label video claims `[VIDEO-FACT]` or `[VIDEO-OPINION]` and keep them `unverified` until a primary source is attached; 视频说法保持未验证，直到有一手来源；
- for each topic say where the two **agree, conflict or extend** each other; 说明两边一致、冲突还是补充；
- on a conflict, mark `Needs Review` and name both, rather than choosing one silently; 冲突时标 Needs Review；
- use the video's date: a view from months ago is not today's market. 视频有日期，旧观点不等于当前行情。

## Filled-in example shape 填写示例（占位内容，不是真实视频）
```
related: ["[[Yen and Carry Trade]]", "[[USD-JPY]]"]
| 1 | 04:10 | Speaker says a sharp yen rise would force carry trades to close | opinion | [[Yen Carry Unwind to Global Risk Assets]] | agrees | Not verified |
| 2 | 09:30 | Speaker names a specific policy meeting date | fact | [[Global Central Banks]] | new | check the central bank calendar |
```

## Evidence and limitations / 证据与限制
- A video is a secondary source. Speakers can be wrong, out of date or promotional; disclose conflicts of interest if the video states them.
- A link in Obsidian shows a topic relationship. It does not prove the claim is true.
- Access depends on the active connection; retrieve relevant notes through the authorized local connection or supply them.
- Educational research, not investment advice.


## v11 override / 当前执行补充
以 [[CLAUDE]] v11 和 [[Daily Update Workflow]] 为准。前台最多三个重要变化；不强制每个期限都有方向。经营判断加入未来 1–4 季度。跨资产只报告有来源的情况，缺资料不得写无变化。观点分歧与事实冲突分开，实际能力取决于连接；时间和条件不得在登记中丢失。样本量与事件相关性需要披露，20 条不是可信阈值。
