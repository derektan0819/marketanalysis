---
title: "Market Selloff Playbook"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [下跌复盘流程, Selloff, 大跌]
tags: [playbook, global]
as_of: 2026-10
---
# Market Selloff Playbook

Use after a sharp market fall to separate cause from noise. 大幅下跌后用来区分原因和噪音。

## Steps 步骤
1. Measure the move: index, sector and breadth, with sessions and times ([[Market Breadth]], [[VIX]]). 测量跌幅、行业和广度。
2. Check rates, dollar, credit spreads and bond volatility ([[IG and HY Credit Spreads]], [[MOVE Index]]). 看利率、美元、信用利差和债券波动。
3. Look for positioning and leverage: funding, liquidations, options expiry ([[Market Volatility and Options Positioning]], [[Crypto Leverage and Liquidations]]). 看仓位和杠杆。
4. List candidate causes and the evidence for each; keep at least one alternative. 列出可能原因和证据，至少保留一个替代解释。
5. Check cross-region and cross-asset spread: did Asia, Europe, crypto and credit move together? 看是否跨地区跨资产同步。
6. Record what would confirm or end the stress. 写出确认或结束压力的信号。

## Rules 规则
- One story rarely explains everything.
- Do not call a bottom or a top.
- Mark conflicting data `Needs Review`.
- Educational research, not investment advice.

Related: [[Risk-On Risk-Off]], [[Liquidity]], [[Credit Markets]], [[Global Equity Indices]]
