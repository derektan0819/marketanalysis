---
title: "Market Overview Checklist 整体市场分析清单"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [playbook, market-overview]
aliases: [整体市场分析清单, Market Overview]
as_of: 2026-10
---
# Market Overview Checklist 整体市场分析清单

Use this when you want one overall view of the US market. Fill in [[Market Overview Analysis]] as you go.
当你想对美国市场形成整体判断时使用。边做边填 [[Market Overview Analysis]]。

## Principles 原则
1. Observe first, interpret second. Record each reading with source, timestamp and session. 先观察，后解释。每个读数都记录来源、时间和交易时段。
2. Look for agreement and conflict between signals. Do not average everything into one score. 看信号之间是一致还是矛盾，不要把所有信号平均成一个分数。
3. A regime label (risk-on, mixed, risk-off) is a hypothesis with a confidence level, not a forecast. 市场状态标签（风险偏好、混合、避险）是带置信度的假设，不是预测。
4. Missing data stays missing. Write `Not verified`; do not fill gaps. 缺失的数据保持缺失，写“未验证”，不要补。

## The eight blocks 八个模块
| # | Block 模块 | What to check 看什么 | Notes 笔记 |
|---|---|---|---|
| 1 | Policy and rate expectations 政策与利率预期 | Fed target range; market-implied path; has the path changed since last check? | [[Federal Funds Rate]], [[Fed and FOMC]], [[Market-Implied Rate Expectations]], [[Fed Funds Futures]] |
| 2 | Yields and valuation 收益率与估值 | 2Y and 10Y yields, curve shape, real yield, term premium | [[US 10-Year Treasury Yield]], [[Yield Curve]], [[Real Interest Rates]], [[Term Premium]], [[Treasury Yield to Equity Valuation]] |
| 3 | Dollar and global 美元与全球 | DXY, yen, other central banks, China | [[DXY]], [[Global Central Banks]], [[Yen and Carry Trade]], [[China Linkages to US Markets]], [[Global Rates Spillover to US Markets]], [[Korea Market and KOSPI]] |
| 4 | Credit and liquidity 信用与流动性 | IG and HY spreads, funding stress, bank conditions | [[Credit Spread]], [[Credit Markets]], [[Liquidity]], [[Bank Runs and Deposit Insurance]] |
| 5 | Volatility and positioning 波动率与仓位 | VIX level and term structure, short interest, positioning | [[VIX]], [[Short Interest and Positioning]], [[Options and Implied Move]], [[Crypto and Macro Linkages]], [[Crypto Leverage and Liquidations]] |
| 6 | Breadth and concentration 广度与集中度 | Equal-weight vs cap-weight, share of stocks above trend, mega-cap share | [[Market Breadth]], [[Index Weighting and Concentration]], [[US Equity Indices]] |
| 7 | Fundamentals 基本面 | Estimate revisions, guidance, capex, margins | [[Earnings Estimate Revisions]], [[Guidance]], [[Hyperscaler Capex]], [[Earnings Season]] |
| 8 | Macro data 宏观数据 | Inflation, labor, growth, consumer, housing | [[CPI]], [[PCE Inflation]], [[Nonfarm Payrolls]], [[Retail Sales]], [[PMI]], [[US GDP Report]], [[Housing Starts]] |

## Synthesis 综合
1. List signals that point to risk-on, signals that point to risk-off, and signals that conflict. 列出偏风险偏好的信号、偏避险的信号和相互矛盾的信号。
2. Label the regime as a hypothesis: risk-on / mixed / risk-off, with confidence (low, medium, high) and the reason for that confidence. 给出市场状态假设，附置信度和理由。
3. State what would change your view (invalidation signals) and give 2 to 3 `[SCENARIO]` paths. 写出什么会改变你的判断（失效信号），并给出2到3个情景。
4. Ask: which signals are about expectations (fast-moving) and which about data (slow-moving)? 区分哪些信号反映预期（变化快），哪些反映数据（变化慢）。

## Common mistakes 常见错误
- Treating one day's move as a trend. 把一天的走势当成趋势。
- Explaining every move with one story (for example, 'it was the Fed'). 用单一故事解释所有波动。
- Ignoring that markets move on changes versus expectations, not on levels alone. 忽略市场反应的是相对预期的变化，而不只是水平。
- Using stale readings from this vault as current values. 把库里旧的读数当成当前数值。

Related: [[Risk-On Risk-Off]], [[Daily 15-Minute Routine]], [[Data Release Playbook]], [[Fed Day Playbook]]

## 美债专项复核

利率驱动重要时，转到 [[10_Playbooks/US Treasury Research Playbook]]。先对齐时间窗口，再分别看政策路径、实际率／通胀补偿、期限溢价、拍卖供需和资金压力；按 [[21_US_Treasuries/US Treasury Knowledge Map|总览]] 读取相关解释，不把全部因子自动列为当日原因。
