---
title: "Earnings Read-Across Playbook / 财报关联传导手册"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [playbooks, earnings]
version: 2.0
---
# Earnings Read-Across Playbook / 财报关联传导手册

Use this for every material earnings release. The goal is not to guess the stock direction; it is to identify what changed, how strong the evidence is, and which second-order effects are plausible.

## Step 1 — Define scope and cutoff
Record company, ticker, fiscal period, release timestamp/timezone, report cutoff and exact question. Do not use information published after the cutoff to recreate the pre-release view.

## Step 2 — Collect primary sources
1. Company earnings release and investor presentation.
2. Relevant SEC filing (8-K exhibit, 10-Q, 10-K or amendment).
3. Earnings call / transcript if available; separate prepared remarks from Q&A.
4. Official segment or industry data needed to verify context.
5. Pre-release consensus from a named provider only if available and timestamped.
See [[SEC Filings and Earnings Release]] and [[Source Registry]].

## Step 3 — Build the evidence table before prose
Record revenue, EPS (GAAP and adjusted separately), margins, cash flow, balance sheet, segment KPIs and guidance. For each number capture period, unit, basis, source URL/location, publication timestamp and status. Mark missing values explicitly.

## Step 4 — Compare actuals correctly
- Actual vs pre-release consensus is different from actual vs prior year and different from guidance.
- Compare like-for-like periods, currencies, segment definitions and accounting basis.
- Show absolute difference as well as percentage surprise when meaningful.
- Do not calculate a misleading surprise percentage from a zero, negative or near-zero denominator.
- Record consensus provider and snapshot time. If unavailable, state that the consensus comparison is not verifiable.

## Step 5 — Diagnose drivers and quality
Separate price, volume, mix, FX, acquisition/disposal, utilization, backlog and accounting effects where disclosed. Check one-off gains/losses, stock-based compensation, working capital, cash conversion, capitalized costs, receivables, inventory and segment mix. Avoid claiming manipulation without evidence.

## Step 6 — Read guidance in context
Compare new guidance with prior guidance and pre-release consensus on the same period and basis. Record range and midpoint formula. Identify assumptions, seasonality, FX, supply constraints and demand conditions stated by management. Do not call a guidance raise a consensus beat unless the comparison is supported.

## Step 7 — Assess market reaction
Use timestamped prices and identify regular/extended session. Compare the move with a relevant benchmark. Options-implied move requires a stated method, expiry, strike selection and data source. Do not treat implied move as a directional forecast or guaranteed range.

## Step 8 — Map read-across
For each supplier, customer, competitor or index impact, classify the link:
- `Direct disclosed`: explicitly named or quantified in an official source.
- `Strongly supported`: multiple independent sources establish the relationship.
- `Indirect inference`: plausible but not directly confirmed.
- `Speculative`: insufficient evidence; keep out of the headline conclusion.

For each link, state mechanism, expected lag, offsetting effects, and evidence that would invalidate the view. Industry similarity alone is not proof of direct revenue exposure.

## Step 9 — Add macro and priced-in context
Check rates, real yields, USD, credit conditions, policy, valuation, recent performance and positioning only with dated sources. `Priced in` is a hypothesis, not a directly observable fact; state the proxy and uncertainty.

## Step 10 — Build scenarios, not a single prediction
Bull/base/bear scenarios must include assumptions, observable confirmation signals and invalidation conditions. Do not manufacture numerical price targets without a defensible valuation model and inputs.

## Step 11 — Complete and gate the report
Use [[Company Earnings Analysis]] or [[Earnings Read-Across Analysis]]. Add source and calculation ledgers. Run [[Publication Gate]]. Save as `Draft` or `Needs Review` if any material issue remains.

## Final questions
- What is new information versus what was already known?
- Which key numbers are verified from primary sources?
- Is consensus genuinely point-in-time?
- What is fact, calculation, inference and unknown?
- What would prove this interpretation wrong?


## v11 override / 当前执行补充
以 [[CLAUDE]] v11 和 [[Daily Update Workflow]] 为准。前台最多三个重要变化；不强制每个期限都有方向。经营判断加入未来 1–4 季度。跨资产只报告有来源的情况，缺资料不得写无变化。观点分歧与事实冲突分开，实际能力取决于连接；时间和条件不得在登记中丢失。样本量与事件相关性需要披露，20 条不是可信阈值。
