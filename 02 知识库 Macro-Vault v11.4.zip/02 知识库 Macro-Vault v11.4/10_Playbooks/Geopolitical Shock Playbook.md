---
title: "Geopolitical Shock Playbook"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [地缘政治冲击流程, Geopolitical shock]
tags: [playbook, global]
as_of: 2026-10
---
# Geopolitical Shock Playbook

Use when an event such as a conflict, sanction, shipping disruption or election could move several markets at once. 用于冲突、制裁、航运中断或选举可能同时影响多个市场时。

## Steps 步骤
1. Establish facts from primary or wire sources and separate them from rumours; record times. 先确认事实，与传闻分开，记录时间。
2. Name the channels: energy, shipping, sanctions, currencies, supply chains, defence budgets. 列出传导渠道。
3. Check first-moves in oil, gold, the dollar, yields, equities and crypto, with UTC times ([[Cross-Asset Daily Coverage]]). 检查各市场首波反应。
4. Compare with earlier episodes carefully; note how they differ. 谨慎与过去事件比较，写明差异。
5. Write scenarios `[SCENARIO]` with triggers and invalidation, not forecasts. 写情景，不写预测。
6. Re-check after 1–3 days and 1–4 weeks and update the log. 在 1–3 天和 1–4 周后复查。

## Rules 规则
- Headlines reverse quickly; avoid certainty.
- Separate first reaction from lasting effect.
- Safe-haven assets do not always behave as expected.
- Educational research, not investment advice.

Related: [[Geopolitics and Export Controls]], [[Middle East and Oil Exporters]], [[Oil Price Transmission]], [[Gold]], [[Risk-On Risk-Off]]
