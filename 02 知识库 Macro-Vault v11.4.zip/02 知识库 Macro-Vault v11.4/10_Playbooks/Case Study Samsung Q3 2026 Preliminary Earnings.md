---
title: "Case Study Samsung Q3 2026 Preliminary Earnings"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [case-study, korea, memory]
version: "11.0"
status: Needs Review
updated_at: "2026-10-19T07:15:13+00:00"
---
# Case Study Samsung Q3 2026 Preliminary Earnings

v11 已补充官方初步业绩公告。原文保留在 20_Archive/v10/10_Playbooks 中，不能把此次取得的证据倒填成旧分析当时已核实。

## 已核对的公告与计算
三星官方公告日期：2026-10-08；实际取得时间：2026-10-19T07:15:13+00:00。公告仅给出日期，精确发布时间未知。
来源：[Samsung official release](https://news.samsung.com/global/samsung-electronics-announces-earnings-guidance-for-third-quarter-2026)。
原文 source_id：SRC-01f576137f26e339d42bae12；原文和 hash 见 13_Sources/Raw/SRC-01f576137f26e339d42bae12.html 及对应 meta.json。

| 项目 | 数值 | 口径与位置 |
|---|---:|---|
| Q3 2026 销售额初步估计 | 195 万亿韩元 | K-IFRS；Consolidated Sales 段落 |
| Q3 2026 营业利润初步估计 | 107.40 万亿韩元 | K-IFRS；Consolidated Operating Profit 段落 |
| 上年同期营业利润 | 12.17 万亿韩元 | 官方公告比较表 2025.3Q |
| 上季营业利润 | 89.49 万亿韩元 | 官方公告比较表 2026.2Q |
| 推算营业利润率 | 55.08% | 107.40 / 195 × 100；基于初步估计 |
| 推算营业利润同比 | 782.50% | (107.40 / 12.17 − 1) × 100 |
| 推算营业利润环比 | 20.01% | (107.40 / 89.49 − 1) × 100 |

这些是初步业绩估计；不得直接标成已审计最终实际。该公告不能证明各业务分部的利润、需求原因或美国股票反应。

## 仍未核实的部分
发布前共识的原始快照、统一口径的收盘涨跌幅、详细分部利润、相应美国公司反应。旧案例的这些内容不继承为已核实结论。

## 修正因果判断
三星和 KOSPI 同日下跌，或跌幅接近，不能证明三星消息推动整个指数。应取得当日成分股权重、收益贡献、其他成分股表现和同日事件；无法取得则保留为假设。

## 条件式 read-across
只有详细披露支持内存需求/价格改善，且相关美国公司的产品与客户暴露相符时，才可加强产业链推断。若利润来自其他分部、一次性项目或预期早已反映，推断应减弱。

状态保持 Needs Review，因为市场预期与股价因果尚未完成核对。官方数字的核实不等于整个案例通过。

Related: [[Korea Market and KOSPI]], [[Earnings Read-Across Playbook]], [[Publication Gate]]

<!-- BEGIN GENERATED NAVIGATION -->
## 保存的官方原文

[[13_Sources/Records/SRC-01f576137f26e339d42bae12|Samsung 官方预告来源记录]]
<!-- END GENERATED NAVIGATION -->
