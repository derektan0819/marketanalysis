---
title: "Data Release Playbook / 宏观数据发布流程"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [playbooks, macro]
---
# Data Release Playbook / 宏观数据发布流程

1. **Confirm release** — official publisher, exact release time/timezone, reference period and release version.
2. **Capture actual and revisions** — record current value, prior value, revised prior, units, seasonal adjustment and table/series location.
3. **Capture consensus only if sourced** — provider, snapshot timestamp, measure (mean/median), contributors if available. Do not fabricate it.
4. **Interpret components** — headline versus core, breadth, trend, base effects and one-off factors. State what the release cannot prove.
5. **Map transmission** — data → policy expectations → nominal/real yields → FX/credit → equities/sectors. Each link is conditional.
6. **Observe market reaction** — use timestamped prices and specify whether reaction is intraday, close-to-close or another window. Correlation alone does not establish causality.
7. **Compare with prior hypotheses** — what changed, what did not, and which next release can confirm or invalidate the view?
8. **Cite and gate** — use [[Macro Event Analysis]] and [[Publication Gate]].

## Common pitfalls
- Confusing month-over-month with year-over-year.
- Comparing seasonally adjusted with unadjusted data.
- Ignoring revisions to prior releases.
- Treating a single print as a trend.
- Calling a result a beat without a timestamped consensus source.
- Assuming the same surprise has the same effect under every policy/positioning regime.
