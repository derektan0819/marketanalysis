---
title: "Global Central Bank Meeting Playbook"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [央行会议流程, ECB BoJ BoE meeting]
tags: [playbook, global]
as_of: 2026-10
---
# Global Central Bank Meeting Playbook

Use for ECB, Bank of Japan, Bank of England, People's Bank of China, Reserve Bank of India and other central-bank decisions. For the US Fed use [[Fed Day Playbook]]. 用于欧洲央行、日本央行、英国央行、中国人民银行和印度储备银行等；美联储用 Fed Day Playbook。

## Steps 步骤
1. Find the official calendar and time zone; convert to one time zone. 查官方日程并统一时区。
2. Record the decision, vote split and statement from the central bank's own site. 从央行官网记录决议、投票和声明。
3. Compare with market pricing before the decision (named provider and time); the surprise is the difference, not the decision itself. 与决议前市场定价比较，意外是差值而不是决议本身。
4. Check the press conference or minutes for forward guidance. 看发布会或纪要的前瞻指引。
5. Record reactions in the local currency, bond yields and equities, plus the dollar and related pairs, with times. 记录本币、债券、股票和美元的反应及时间。
6. Write the cross-region effect and an alternative explanation; log falsifiable judgments in [[Prediction Log]]. 写跨地区影响与另一种解释，并记录可验证判断。

## Rules 规则
- No market numbers without source and time.
- Do not infer policy intent from price moves alone.
- Check which region note applies: [[Euro Area and ECB]], [[United Kingdom and Bank of England]], [[Japan Economy and BoJ]], [[China Economy and Policy]], [[India Economy and Markets]].
- Educational research, not investment advice.

Related: [[Global Central Banks]], [[Regions Guide]], [[Cross-Asset Daily Coverage]]
