---
title: "Weekly Review Routine"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [每周复盘流程, Weekly review]
tags: [playbook, global]
as_of: 2026-10
---
# Weekly Review Routine

A weekly routine to roll up the week across US and foreign markets. 每周汇总美国与海外市场的流程。

## Steps 步骤
1. Gather the week's daily reports and the cross-asset lines. 收集本周日报和跨资产结论。
2. Fill [[Weekly Summary]] with weekly changes, defining the week in UTC for crypto and FX. 填写周总结，加密和外汇用 UTC 定义一周。
3. Check each region: [[Regions Guide]] and central-bank events of the week. 检查各区域和央行事件。
4. Run `复盘` on judgments in [[Prediction Log]] whose dates have passed. 复盘已到期判断。
5. Process the video notes added this week: link, verify key claims, update status ([[Video Guide]]). 处理本周新增视频：连接、核对、更新状态。
6. List the next week's calendar with official sources. 列出下周日历。

## Rules 规则
- Separate new evidence from repeated narratives.
- Report sample size and uncertainty; 20 entries is not a reliability threshold.
- Educational research, not investment advice.

Related: [[Weekly Summary]], [[Prediction Log]], [[Cross-Asset Daily Coverage]], [[Video Linking Playbook]]


## v11 override / 当前执行补充
以 [[CLAUDE]] v11 和 [[Daily Update Workflow]] 为准。前台最多三个重要变化；不强制每个期限都有方向。经营判断加入未来 1–4 季度。跨资产只报告有来源的情况，缺资料不得写无变化。观点分歧与事实冲突分开，实际能力取决于连接；时间和条件不得在登记中丢失。样本量与事件相关性需要披露，20 条不是可信阈值。
