---
title: "Cross-Asset Daily Coverage 跨资产每日覆盖"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
aliases: [跨资产覆盖, 全市场覆盖, Cross-Asset Daily Coverage]
tags: [playbook, daily, cross-asset]
as_of: 2026-10
---
# Cross-Asset Daily Coverage 跨资产每日覆盖

Which markets the daily update covers, what to check in each, and the traps specific to each. Company, coin and currency-pair names are examples, not a fixed list; change them in the watch list below. 每日更新覆盖哪些市场、每个市场看什么、各自的陷阱。名称只是例子，可以在下方清单里改。

Workflow: [[Daily Update Workflow]]. Template: [[Daily Impact Update]]. Step-by-step: [[Crypto and FX Daily Checklist]].

## Coverage map 覆盖地图
| Market 市场 | Check each day 每天看 | Typical drivers 常见驱动 | Vault notes 相关笔记 |
|---|---|---|---|
| US equities 美股 | S&P 500, Nasdaq, equal-weight, Dow, Russell 2000, breadth, VIX | rates, earnings, flows, concentration | [[US Equity Indices]], [[Market Breadth]], [[Index Weighting and Concentration]], [[VIX]] |
| AI and semiconductors | SOX, large chip and cloud names, memory, capex news | hyperscaler capex, memory prices, export controls, financing | [[AI Value Chain]], [[Semiconductors]], [[Memory Chips]], [[Hyperscaler Capex to Chip Chain]], [[Korea Memory Stocks and US Chip Stocks]] |
| Banks 银行 | large-bank results, net interest income, credit costs, trading revenue, capital rules | policy rate, curve, credit, regulation | [[US Banks]], [[Bank Metrics]], [[Bank Earnings to Market]], [[Bank Capital Rules to Bank Earnings]] |
| Rates and credit 利率与信用 | 2Y, 10Y, curve, real yield, IG/HY spreads, Treasury auctions and refunding | Fed path, inflation, term premium, supply | [[US 10-Year Treasury Yield]], [[Yield Curve]], [[Term Premium]], [[Credit Spread]], [[Market-Implied Rate Expectations]] |
| FX 外汇 | DXY, EUR/USD, USD/JPY, USD/CNH, optionally USD/MYR | rate differentials, central banks, energy prices, risk sentiment, intervention risk | [[DXY]], [[Exchange Rate]], [[Yen and Carry Trade]], [[Global Central Banks]], [[Strong USD to Ringgit]], [[EUR-USD]], [[USD-JPY]], [[USD-CNH]], [[USD-MYR]], [[FX Market Structure and Quoting]], [[FX Intervention and Currency Regimes]] |
| Crypto 加密货币 | BTC, ETH, spot ETF net flows, liquidations, stablecoin news | liquidity, rates, ETF flows, leverage, regulation | [[Crypto Assets Overview]], [[Spot Bitcoin ETFs and Flows]], [[Spot Bitcoin ETF Flows]], [[Crypto Leverage and Liquidations]], [[Stablecoins]], [[Crypto and Macro Linkages]], [[Crypto Sentiment to US Equities]], [[Bitcoin and Ether Price]], [[Crypto Funding Rate and Open Interest]], [[Stablecoin Supply]], [[Crypto Market Structure and Venues]] |
| Commodities 大宗商品 | WTI, Brent, gold, copper | geopolitics, supply, inventories, real yields, USD | [[Commodity Prices]], [[Gold]], [[Oil Price Transmission]], [[Gold Price]], [[WTI and Brent Crude]] |
| Global indices 全球指数 | KOSPI, Nikkei, Hang Seng, major European indices | local news, FX, US overnight moves | [[Korea Market and KOSPI]], [[China Linkages to US Markets]], [[Global Rates Spillover to US Markets]], [[Global Equity Indices]] |

## Rules that differ by market 各市场的特殊规则
1. **Different clocks.** US equities and Treasuries have sessions; FX trades 24 hours on weekdays; crypto trades 24/7. Always state the cutoff and timezone, and use UTC for crypto and FX readings. 各市场交易时间不同，加密和外汇一律写 UTC 时间。
2. **Crypto has no official close.** A 'daily close' is a convention (often 00:00 UTC). State which convention and which price provider; prices differ across providers. 加密货币没有官方收盘价，要写明约定和数据商。
3. **ETF flow and liquidation figures depend on the provider** (for example Farside, SoSoValue, CoinGlass). Record the provider; if two providers differ, mark `Needs Review`. 资金流和爆仓数据因数据商而异。
4. **FX quotes are pairs.** 'The dollar rose' needs the pair or index named. DXY is a basket and is heavy in the euro; a move in one pair is not a move in the dollar. 说“美元涨了”要指明货币对或指数。
5. **Commodities have many prices.** Name WTI or Brent, front-month or spot, and the contract date; gold spot differs from futures. 大宗商品要写明合约和现货/期货。
6. **Intervention and policy risk** (Japan for the yen, regulators for crypto) can reverse a move without any change in fundamentals. Record it as a risk, not as a prediction. 干预和监管风险写成风险，不当预测。
7. **No single story.** Cross-check: did oil, yields, the dollar, equities and crypto move together because of one driver, or separately? 检查各市场是否真的由同一个因素驱动。

## Cross-asset chains to test 要检验的跨资产链条
- Oil up → headline inflation up → yields up or risk-off → dollar and equities react ([[Oil Price Transmission]], [[Inflation Surprise Transmission]]). 油价 → 通胀 → 收益率 → 美元和股票。
- Fed path priced higher → rate differential vs Japan or Europe → dollar up, yen carry trades under pressure ([[Yen and Carry Trade]], [[Yen Carry Unwind to Global Risk Assets]]). 美联储路径 → 利差 → 美元和日元套利交易。
- Liquidity tightens or risk-off → leveraged crypto longs liquidated → crypto falls faster than equities ([[Crypto Leverage and Liquidations]], [[Crypto and Macro Linkages]]). 流动性收紧 → 加密多头爆仓。
- Real yields up → gold pressured, unless safe-haven demand offsets ([[Gold]], [[Real Interest Rates]], [[Dollar and Real Yields to Gold and Crypto]]). 实际收益率 → 黄金。

Each chain is a hypothesis; same-day co-movement does not prove it. 每条链都是假设，同日同向不等于因果。

## Watch list (edit freely) 关注清单
- Indices: S&P 500, Nasdaq, SOX, KOSPI
- FX: DXY, EUR/USD, USD/JPY, USD/CNH, USD/MYR
- Crypto: BTC, ETH, US spot BTC and ETH ETF flows
- Commodities: WTI, Brent, gold
- Banks and AI companies: chosen per day from reporting calendars

## Regions 区域
For non-US regions use [[Regions Guide]] and, for central-bank days, [[Global Central Bank Meeting Playbook]]. After a sharp fall use [[Market Selloff Playbook]]; for geopolitical events use [[Geopolitical Shock Playbook]]; for the weekly roll-up use [[Weekly Review Routine]]. 非美国区域见区域指南；央行日、大跌、地缘事件和周复盘各有对应流程。


## v11 override / 当前执行补充
以 [[CLAUDE]] v11 和 [[Daily Update Workflow]] 为准。前台最多三个重要变化；不强制每个期限都有方向。经营判断加入未来 1–4 季度。跨资产只报告有来源的情况，缺资料不得写无变化。观点分歧与事实冲突分开，实际能力取决于连接；时间和条件不得在登记中丢失。样本量与事件相关性需要披露，20 条不是可信阈值。
