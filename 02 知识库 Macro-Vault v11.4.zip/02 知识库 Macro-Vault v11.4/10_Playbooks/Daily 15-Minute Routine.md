---
title: "Daily 15-Minute Routine / 每日研究流程"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [playbooks, daily]
---
# Daily 15-Minute Routine / 每日研究流程

This is a prioritization routine, not a promise that live data is available.

1. **2 minutes — Calendar:** check official macro releases, Fed events and issuer earnings calendars; record timezone and source.
2. **3 minutes — Market snapshot:** capture index levels, Treasury yields, USD and major FX pairs, volatility, gold, oil, Bitcoin and Ether, and major global indices with timestamp/session/source (see [[Crypto and FX Daily Checklist]]).
3. **3 minutes — Largest moves:** identify unusually large sector/company moves; do not assume the headline explains the entire move.
4. **4 minutes — Evidence chain:** for the top one or two events, use the relevant transmission note and record facts, mechanism, alternative explanation and uncertainty.
5. **3 minutes — Write and check:** write one cross-asset line for the conclusion, fill [[Daily Summary]], cite external sources, record missing values and run [[Publication Gate]].

## Rules
- No unsourced number, no fabricated consensus, no stale value presented as current.
- If current market data cannot be retrieved, write `Not available at time of preparation`.
- A daily report should distinguish observation from explanation and avoid overfitting to one day's price action.


## v11 override / 当前执行补充
以 [[CLAUDE]] v11 和 [[Daily Update Workflow]] 为准。前台最多三个重要变化；不强制每个期限都有方向。经营判断加入未来 1–4 季度。跨资产只报告有来源的情况，缺资料不得写无变化。观点分歧与事实冲突分开，实际能力取决于连接；时间和条件不得在登记中丢失。样本量与事件相关性需要披露，20 条不是可信阈值。
