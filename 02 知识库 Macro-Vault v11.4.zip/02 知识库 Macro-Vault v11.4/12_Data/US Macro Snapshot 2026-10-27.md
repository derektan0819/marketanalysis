---
title: "美国宏观与市场数据快照 2026-10-27"
aliases: [美国宏观数据快照, 最新数据快照, US Macro Snapshot]
tags: [data, snapshot, macro]
created: 2026-10-27
updated: 2026-10-27
source: "美联储、BLS、BEA、美国财政部、EIA、S&P Dow Jones Indices、Nasdaq、Census、JPMorgan Chase、Bank Negara Malaysia；逐项网址见正文"
verified: 2026-10-27
data_cutoff: "2026-10-27 写入；各项数据日期见表"
---
# US Macro Snapshot 2026-10-27 — 美国宏观与市场数据快照

[[00_Index/Master Index|总索引]] · [[12_Data/Data MOC|数据 MOC]] · [[12_Data/US Release Calendar 2026-10-27|接下来的发布日历]]

> 这是一份带日期的观测记录，不是实时行情。按本库规则，常青笔记不写“最新值”，带日期的数字集中放在这里。每一行都写明来源、网址、数据日期和写入日期（统一为 2026-10-27）。数字照搬原发布口径，没有换算或估算；查不到的写“待核实”。

## 一眼看懂

- **利率：** 美联储 9 月加息 0.25 个百分点到 3.75%–4.00%，是 2026 年唯一一次调整。10 月 27–28 日的会议正在进行，结果 10-28 公布。
- **通胀：** 9 月 CPI 同比 3.7%，核心 CPI 2.6%；8 月 PCE 同比 3.4%，核心 PCE 3.0%。整体 CPI 比核心高 1.1 个百分点，说明食品和能源涨得比其他部分快；具体是哪些分项推高的，本页没有核对分项表（待核实）。
- **就业：** 9 月非农就业只增加 2.9 万，7 月被下修为减少 1.0 万；失业率 4.2%。
- **长端利率：** 10 年期美债 10-26 为 5.00%，月初 10-01 为 5.24%。
- **财政：** 2026 财年赤字约 1.99 万亿美元，比 2025 财年多约 2,171 亿美元。

## 1. 美联储政策利率

| 指标 | 旧值 → 新值 | 数据日期 | 来源 | 网址 | 写入日期 |
|---|---|---|---|---|---|
| 联邦基金利率目标区间 | 3.50%–3.75%（2025-12-11 起）→ **3.75%–4.00%** | 2026-09-16 决议，09-17 起生效；12 票赞成、0 票反对 | Federal Reserve，FOMC 声明 | https://www.federalreserve.gov/newsevents/pressreleases/monetary20260916a.htm | 2026-10-27 |
| 2026 年各次会议 | 1、3、4、6、7 月维持；9 月加息 25 个基点 | 2026-01 至 2026-09 | Federal Reserve，目标利率变动表（2026 年只有 09-17 一行） | https://www.federalreserve.gov/monetarypolicy/openmarket.htm | 2026-10-27 |
| 余下会议 | 10-27–28（进行中）；12-08–09（附经济预测 SEP） | 2026 日程 | Federal Reserve，FOMC 会议日历 | https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm | 2026-10-27 |

库内旧值：常青笔记 [[03_Indicators/Federal Funds Rate]] 按规则不存数值；[[06_Daily/2026-10-19]] 只写了“10-28 FOMC（预期维持）”，没有利率水平。

## 2. 通胀

| 指标 | 新值 | 数据日期 | 来源 | 网址 | 写入日期 |
|---|---|---|---|---|---|
| CPI-U 环比（季调） | 0.6% | 2026 年 9 月，10-14 发布 | BLS，CPI 新闻稿 | https://www.bls.gov/news.release/cpi.nr0.htm | 2026-10-27 |
| CPI-U 同比（未季调） | 3.7% | 2026 年 9 月 | BLS，同上 | 同上 | 2026-10-27 |
| 核心 CPI 环比 / 同比 | 0.3% / 2.6% | 2026 年 9 月 | BLS，同上 | 同上 | 2026-10-27 |
| PCE 价格指数 环比 / 同比 | 0.3% / 3.4% | 2026 年 8 月，09-30 发布 | BEA，Personal Income and Outlays | https://www.bea.gov/news/2026/personal-income-and-outlays-august-2026 | 2026-10-27 |
| 核心 PCE 环比 / 同比 | 0.2% / 3.0% | 2026 年 8 月 | BEA，同上 | 同上 | 2026-10-27 |

库内旧值：无（[[03_Indicators/CPI]]、[[03_Indicators/PCE Inflation]] 按规则不存数值）。

## 3. 就业与劳动成本

| 指标 | 旧值 → 新值 | 数据日期 | 来源 | 网址 | 写入日期 |
|---|---|---|---|---|---|
| 非农就业变化 | **+2.9 万** | 2026 年 9 月，10-02 发布 | BLS，Employment Situation | https://www.bls.gov/news.release/empsit.nr0.htm | 2026-10-27 |
| 7 月非农（修正） | +2.1 万 → **-1.0 万** | 2026 年 7 月，10-02 修正 | BLS，同上 | 同上 | 2026-10-27 |
| 8 月非农（修正） | +16.2 万 → **+13.3 万** | 2026 年 8 月，10-02 修正 | BLS，同上 | 同上 | 2026-10-27 |
| 失业率 | 4.2% | 2026 年 9 月 | BLS，同上 | 同上 | 2026-10-27 |
| 平均时薪 | 37.81 美元；环比 +0.1%，同比 +3.0% | 2026 年 9 月 | BLS，同上 | 同上 | 2026-10-27 |
| 就业成本指数（民用总薪酬） | 季环比 +0.9%（季调）；12 个月 +3.4%；其中工资 +3.2%、福利 +3.8% | 2026 年第二季度，07-31 发布 | BLS，ECI 新闻稿 | https://www.bls.gov/news.release/eci.nr0.htm | 2026-10-27 |

7 月、8 月的“旧值 → 新值”是 BLS 自己的修正，即同一数据的前后版本。

## 4. 增长与生产

| 指标 | 新值 | 数据日期 | 来源 | 网址 | 写入日期 |
|---|---|---|---|---|---|
| 实际 GDP（年化） | 2.2%（第三次估计）；第一季度修正为 2.5% | 2026 年第二季度，09-30 发布 | BEA，GDP | https://www.bea.gov/data/gdp/gross-domestic-product | 2026-10-27 |
| 工业生产 环比 | +0.7%；其中制造业 +0.3% | 2026 年 9 月，10-16 发布 | Federal Reserve，G.17 | https://www.federalreserve.gov/releases/g17/current/default.htm | 2026-10-27 |
| 产能利用率 | 76.9%，比 1972–2025 年长期均值低 2.5 个百分点 | 2026 年 9 月 | Federal Reserve，G.17 | 同上 | 2026-10-27 |
| 耐用品新订单（季调） | 3,384.58 亿美元 | 2026 年 8 月 | U.S. Census Bureau M3（经 FRED，系列 DGORDER，10-02 更新） | https://fred.stlouisfed.org/series/DGORDER | 2026-10-27 |
| 核心资本品新订单（非国防、不含飞机，季调） | 876.40 亿美元 | 2026 年 8 月 | U.S. Census Bureau M3（经 FRED，系列 NEWORDER） | https://fred.stlouisfed.org/series/NEWORDER | 2026-10-27 |

9 月耐用品预告报告按 FRED 日程在 10-27 发布，写入时 FRED 尚未更新，Census 官网当天访问失败，所以未纳入（待核实）。

## 5. 联邦财政

| 指标 | 旧值 → 新值 | 数据日期 | 来源 | 网址 | 写入日期 |
|---|---|---|---|---|---|
| 财年赤字 | 2025 财年 1.7754 万亿美元 → 2026 财年 **1.9925 万亿美元**（增加约 2,171.0 亿） | 2026 财年（2025-10-01 至 2026-09-30） | U.S. Treasury，Monthly Treasury Statement 表 1（Fiscal Data API） | https://api.fiscaldata.treasury.gov/services/api/fiscal_service/v1/accounting/mts/mts_table_1?filter=record_date:eq:2026-09-30 | 2026-10-27 |
| 财年收入 / 支出 | 5.4033 万亿 / 7.3958 万亿美元 | 2026 财年 | 同上 | 同上 | 2026-10-27 |
| 9 月单月 | 赤字 269.0 亿美元（2025 年 9 月为盈余 1,979.4 亿美元） | 2026-09 | 同上 | 同上 | 2026-10-27 |

原始数值（美元）：赤字 1,992,473,224,352.42；收入 5,403,326,758,960.81；支出 7,395,799,983,313.23；2025 财年赤字 1,775,369,189,818.35。MTS 的正式发布日期接口未给出（待核实）。

## 6. 美债收益率（财政部面值收益率曲线，%）

| 期限 | 旧值（10-01） → 新值（10-26） | 库内旧值 | 来源 | 网址 | 写入日期 |
|---|---|---|---|---|---|
| 3 个月 | 4.17 → **4.22** | 无 | U.S. Treasury，Daily Treasury Par Yield Curve Rates | https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/2026/all?type=daily_treasury_yield_curve&field_tdr_date_value=2026&page&_format=csv | 2026-10-27 |
| 2 年 | 4.78 → **4.68** | 无 | 同上 | 同上 | 2026-10-27 |
| 10 年 | 5.24 → **5.00** | 约 5.05%（10-19 亚洲时段，[[06_Daily/2026-10-19]]，二手来源 Business Recorder） | 同上 | 同上 | 2026-10-27 |
| 30 年 | 5.61 → **5.31** | 无 | 同上 | 同上 | 2026-10-27 |

计算值：10-26 的 10 年减 2 年利差 = 5.00 − 4.68 = 0.32 个百分点。

## 7. 美股指数与油价

| 指标 | 库内旧值 → 新值 | 数据日期 | 来源 | 网址 | 写入日期 |
|---|---|---|---|---|---|
| S&P 500 收盘 | 7,659.44（10-16 收盘，[[06_Daily/2026-10-19]]，二手来源 HDFC Sky、Investrade）→ **7,623.68** | 2026-10-23 | S&P Dow Jones Indices（经 FRED，系列 SP500） | https://fred.stlouisfed.org/series/SP500 | 2026-10-27 |
| 纳斯达克综合指数 收盘 | 26,140.03（10-16，同上，HDFC Sky）→ **26,169.38** | 2026-10-26 | Nasdaq, Inc.（经 FRED，系列 NASDAQCOM） | https://fred.stlouisfed.org/series/NASDAQCOM | 2026-10-27 |
| 道琼斯工业平均指数 收盘 | 52,002（10-16，同上，HDFC Sky）→ **52,361.58** | 2026-10-26 | S&P Dow Jones Indices（经 FRED，系列 DJIA） | https://fred.stlouisfed.org/series/DJIA | 2026-10-27 |
| WTI 原油现货（库欣） | 约 100.6 美元/桶（10-19 期货报道，口径不同）→ **107.89 美元/桶** | 2026-10-20 | U.S. EIA（经 FRED，系列 DCOILWTICO） | https://fred.stlouisfed.org/series/DCOILWTICO | 2026-10-27 |

注意：FRED 的 S&P 500 写入时只更新到 10-23，另两个指数到 10-26，日期不同，不能横向比较。旧油价是期货报道值，新值是 EIA 现货价，两者不能直接相减。

## 8. 库内重点公司：JPMorgan Chase 第三季度

| 指标 | 库内旧值（最新结构化季度 2026-06-30） → 新值（2026 年第三季度） | 来源 | 网址 | 写入日期 |
|---|---|---|---|---|
| 净利润 | 211.55 亿美元 → **153 亿美元**（同比 +6%）；剔除重大项目后 158 亿美元 | JPMorgan Chase，3Q26 Earnings Press Release（2026-10-13） | https://www.jpmorganchase.com/content/dam/jpmc/jpmorgan-chase-and-co/investor-relations/documents/quarterly-earnings/2026/3rd-quarter/6c1f8114-1be4-4174-8292-f75bbb59bc21.pdf | 2026-10-27 |
| 稀释每股收益 | 7.70 美元 → **5.57 美元**；剔除重大项目后 5.75 美元 | 同上 | 同上 | 2026-10-27 |
| 净利息收入 | 255.11 亿美元 → **271 亿美元**（同比 +13%） | 同上 | 同上 | 2026-10-27 |
| 营收 | — → 报告口径 502 亿美元；管理口径 509 亿美元（同比 +8%） | 同上 | 同上 | 2026-10-27 |

旧值出自 [[04_Companies/JPM/Latest Brief]]（SEC 结构化数据，截止 2026-10-19）。新旧两列是**不同季度**，不是同一季度的修正。第二季度的数字可能含一次性项目，本次没有核对第二季度原文，所以不要直接把两季相减解读为利润下滑。新闻稿 PDF 用本地解码读出正文核对；第三季度 10-Q 写入时尚未出现在库内快照中。

## 9. 马来西亚（少量）

| 指标 | 新值 | 数据日期 | 来源 | 网址 | 写入日期 |
|---|---|---|---|---|---|
| 隔夜政策利率 OPR | 2.75%，维持不变（2026 年 03-05、05-07、07-09 三次会议也维持） | 2026-09-03 MPC | Bank Negara Malaysia，OPR Decisions | https://www.bnm.gov.my/monetary-stability/opr-decisions | 2026-10-27 |

下一次 MPC 日期：待核实。

## 待核实

- 9 月 CPI 里推高整体通胀的具体分项。
- 9 月耐用品预告报告（10-27 发布）的数值。
- 2026 财年 MTS 的正式发布日期。
- BNM 下一次 MPC 日期。
- 第二季度 JPM 净利润是否含一次性项目。

## 限制

- 收益率是财政部面值收益率曲线，与交易终端的新券收益率可能略有差异。
- 新旧值多数是不同日期的观测，不是同一数据的修正；只有标明“修正”的行是修正。
- 本页只记录数字，不判断市场方向；解读请按 [[15_System/Research Protocol]] 另写报告。不是投资建议。

## Related 相关

[[03_Indicators/Federal Funds Rate]] · [[03_Indicators/CPI]] · [[03_Indicators/PCE Inflation]] · [[03_Indicators/Nonfarm Payrolls]] · [[03_Indicators/Unemployment Rate]] · [[03_Indicators/Employment Cost Index]] · [[03_Indicators/US GDP Report]] · [[03_Indicators/Industrial Production and Capacity Utilization]] · [[03_Indicators/Durable Goods Orders]] · [[03_Indicators/Federal Budget and Monthly Treasury Statement]] · [[03_Indicators/US 10-Year Treasury Yield]] · [[03_Indicators/US Equity Indices]] · [[03_Indicators/WTI and Brent Crude]] · [[11_Malaysia/OPR]]
