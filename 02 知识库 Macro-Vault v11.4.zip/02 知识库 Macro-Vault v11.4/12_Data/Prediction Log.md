---
title: "Prediction Log"
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
tags: [data, predictions]
version: "11.0"
status: active
---
# Prediction Log

正式条目保存在 12_Data/Predictions/P-*.json；结果单独追加在 12_Data/Outcomes。原判断不可修改，改观点产生新 ID 并填 supersedes。
v10 的六条记录保存在 20_Archive/v10/12_Data/Prediction Log.md.txt，因缺实际生成时间、条件不一致或来源口径未固定而不计入 v11 实时成绩。没有把这些原文删除或事后改成正确预测。

## 新记录
复制 99_Automation/examples/forecast.example.json，填入真实未来事件与已保存的证据 ID，然后：
```bash
python3 99_Automation/engine/vault.py log-forecast path/to/your-forecast.json
```
系统在执行时写入真实 created_at；不能传入早于当前的生成日期。模型候选先作为草案；自动登记开启且校验通过可登记，必须保留正文条件与来源报告。

## 到期核对
```bash
python3 99_Automation/engine/vault.py review
```
当前自动核对支持已导入的同实体、同季度、同指标、同口径财务数据。市场价格/政策事件尚无专用结果适配器，不能自动算命中。
结果：hit / miss / condition_not_met / pending_data / unresolvable。条件没发生和数据没取得分别处理；不能当 miss 或从统计中悄悄删除。
目标日期过去但尚未披露财报时保持 pending_data。结果带输入 ID 和复盘时间；后续修订产生新结果版本。

## 校准
显示全部样本数、已解决样本数、未解决原因，按事件群、期限、领域、置信度分别观察。20 条不构成可靠性门槛。
若事前保存概率和依据，可算 Brier score；基准概率必须同样事前有来源。主观概率不能称为已校准。方向正确与机制得到证据支持分开。
历史回顾不计实时成绩；最新修订数据不能冒充当年投资者已知数据。


预测结果汇总：[[Prediction Scorecard]]。
