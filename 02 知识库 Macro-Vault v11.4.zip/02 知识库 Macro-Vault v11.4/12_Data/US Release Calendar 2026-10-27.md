---
title: "美国数据与财报发布日历 2026-10-27"
aliases: [发布日历, 经济日历, US Release Calendar]
tags: [data, calendar, macro, earnings]
created: 2026-10-27
updated: 2026-10-27
source: "Federal Reserve、BLS、BEA、FRED、Microsoft、Alphabet、Amazon、Apple、Meta、JPMorgan Chase 官方页面；逐项网址见正文"
verified: 2026-10-27
---
# US Release Calendar 2026-10-27 — 美国数据与财报发布日历

[[00_Index/Master Index|总索引]] · [[12_Data/US Macro Snapshot 2026-10-27|最新数据快照]] · [[10_Playbooks/Data Release Playbook|数据发布手册]] · [[10_Playbooks/Fed Day Playbook|议息日手册]]

> 本页每一行的写入日期均为 2026-10-27，“日期”列就是该事件的数据日期。只收录能在官方页面确认的日期；时间统一换算为美东时间（ET），换算处另注。日程可能改期，使用前请回到原网址复核。

## 已经发生（本月）

| 日期 | 事件 | 来源 | 网址 |
|---|---|---|---|
| 10-02（周五） | BLS 9 月就业报告 | BLS | https://www.bls.gov/news.release/empsit.nr0.htm |
| 10-13（周二） | JPMorgan Chase 第三季度财报，8:30 a.m. ET 电话会 | JPMorgan Chase | https://www.jpmorganchase.com/content/dam/jpmc/jpmorgan-chase-and-co/investor-relations/documents/quarterly-earnings/2026/3rd-quarter/6c1f8114-1be4-4174-8292-f75bbb59bc21.pdf |
| 10-14（周三） | BLS 9 月 CPI | BLS | https://www.bls.gov/news.release/cpi.nr0.htm |
| 10-16（周五） | 美联储 G.17 9 月工业生产 | Federal Reserve | https://www.federalreserve.gov/releases/g17/current/default.htm |
| 10-21（周三） | Meta 第三季度财报（盘后） | Meta Investor Relations | https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-to-Announce-Third-Quarter-2026-Results/default.aspx |

## 接下来

| 日期（ET） | 事件 | 说明 | 来源 | 网址 |
|---|---|---|---|---|
| 10-27（周二） | Census 9 月耐用品订单预告 | FRED 系列页标注的下次发布日 | FRED（数据来自 U.S. Census Bureau） | https://fred.stlouisfed.org/series/DGORDER |
| 10-27–28（周二至周三） | FOMC 会议 | 声明 10-28 公布；按惯例 2:00 p.m. ET，本次时间未单独核实 | Federal Reserve | https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm |
| 10-28（周三） | Microsoft 2027 财年第一季度财报 | 盘后发布；网络直播 2:30 p.m. PT（5:30 p.m. ET） | Microsoft | https://news.microsoft.com/source/2026/10/07/microsoft-announces-quarterly-earnings-release-date-69/ |
| 10-28（周三） | Alphabet 第三季度财报电话会 | 1:30 p.m. PT（4:30 p.m. ET） | Alphabet Investor Relations | https://abc.xyz/investor/news/news-details/2026/Alphabet-Announces-Date-of-Third-Quarter-2026-Financial-Results-Conference-Call-2026-8tpGZsLS6v/default.aspx |
| 10-29（周四） | BEA 下次发布：GDP 与 PCE | GDP 页与 PCE 页都写“Next release: October 29, 2026”；具体内容以当天 BEA 发布为准 | BEA | https://www.bea.gov/data/gdp/gross-domestic-product · https://www.bea.gov/data/personal-consumption-expenditures-price-index |
| 10-29（周四） | Amazon 第三季度财报电话会 | 2:00 p.m. PT（5:00 p.m. ET） | Amazon Investor Relations | https://ir.aboutamazon.com/events/event-details/2026/Q3-2026-Amazoncom-Inc-Earnings-Conference-Call/default.aspx |
| 10-30（周五） | BLS 第三季度就业成本指数 ECI | 8:30 a.m. ET | BLS | https://www.bls.gov/schedule/news_release/eci.htm |
| 11-02（周一） | Apple 2026 财年第四季度业绩 | 2:00 p.m. PT（5:00 p.m. ET） | Apple Investor Relations | https://investor.apple.com/investor-relations/event-details/2026/FY-26-Fourth-Quarter-Results/default.aspx |
| 11-06（周五） | BLS 10 月就业报告 | 8:30 a.m. ET | BLS | https://www.bls.gov/news.release/empsit.nr0.htm |
| 11-10（周二） | BLS 10 月 CPI | 8:30 a.m. ET | BLS | https://www.bls.gov/news.release/cpi.nr0.htm |
| 11-24（周二） | 美联储 G.17 工业生产与产能利用率年度修订 | 历史数据会被改写 | Federal Reserve | https://www.federalreserve.gov/releases/g17/current/default.htm |
| 12-08–09（周二至周三） | FOMC 会议（附经济预测 SEP） | 声明 12-09 公布 | Federal Reserve | https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm |

## 待核实

- NVIDIA 2027 财年第三季度财报日期：官方页面只确认了 8-26 发布第二季度，未找到第三季度日期。
- 美联储 10 月高级信贷员调查（SLOOS）的发布日期。
- Bank Negara Malaysia 下一次 MPC 日期。

## 怎么用

- 数据发布当天按 [[10_Playbooks/Data Release Playbook]] 记录实际值、前值修正和发布时间；有命名的事前共识才能谈“超预期”。
- 大公司财报按 [[02_Transmission/Mega-Cap Earnings to Index]] 看对指数的影响，阅读步骤见 [[10_Playbooks/Financial Reading Coverage]]。
- 议息结果按 [[10_Playbooks/Fed Day Playbook]] 和 [[02_Transmission/Fed Decision to Markets]] 分析。
