---
title: "Structured Data Folder"
tags: [data, guide]
created: 2026-10-19
updated: 2026-10-19
source: "待补充"
---
# Structured Data Folder

Companies/<TICKER>/<run_id>.json：当前截止可得的结构化观察；每次快照保留。
Predictions/P-*.json：正式前瞻条目，不可覆盖。
Outcomes/：复盘追加记录，不修改原预测。
Runs/：每次运行、公司结果和例外。
Fetch Receipts.jsonl：实际获取记录，区分原文发布时间与抓取时间。
Cache/：URL 缓存指向 immutable raw source；失败不会变成成功空值。

来源原文在 13_Sources/Raw，计算 inputs 保存在 observation。历史序列采用当前截止可得版本；不能直接用作无前视偏差回测。
